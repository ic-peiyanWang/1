# How to build and run the app

1. Build the app with different options:
    * Debug build for aarch64 target: ./build.sh make
    * Release build for aarch64 target: MAZU_BUILD_TYPE=release ./build.sh make
    * Debug build for x86 target: MAZU_ARCH=x86 ./build.sh make
    * Release build for x86 target: MAZU_ARCH=x86 MAZU_BUILD_TYPE=release ./build.sh make    
2. After build successfully finished, a tar package will be found under ./build
3. To run the app:
   * On your host: ./run.sh
   * On target board: scp both the gerenated tar package and run.sh to the target, and then exract the tar package and execute run.sh on the target

> You can run ./build.sh clean to force cleaning both the docker container and the build results.

# How to customize the building process

Please reference scripts/dist.sh to see how to customize the distribution of your application to generate the tar package.
