#!/bin/bash

# Get the group of app repo
if [[ -z "$APP_ROOT" ]]; then
	APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
fi

APP_NAME=$(
	cd "$APP_ROOT"
	pwd | sed 's@.*/@@g'
)

# Get the group and release of app repo
if [ -z "$CI_COMMIT_REF_NAME" ]; then
	APP_BRANCH=$(
		cd "$APP_ROOT"
		git symbolic-ref --short -q HEAD
	)
else
	APP_BRANCH=$CI_COMMIT_REF_NAME
fi

if [ "$APP_BRANCH" == "master" ]; then
	APP_GROUP="main"
	APP_RELEASE=$(echo $APP_BRANCH | awk -F '[/]' '{print $2}')
elif [[ "$APP_BRANCH" == "stable/"* || "$APP_BRANCH" == "trial/"* ]]; then
	APP_GROUP=$(echo $APP_BRANCH | awk -F '[/]' '{print $2}')
	APP_RELEASE=$(echo $APP_BRANCH | awk -F '[/]' '{print $1}')/
fi

echo "APP_ROOT=${APP_ROOT}"
echo "APP_NAME=${APP_NAME}"
echo "APP_BRANCH=${APP_BRANCH}"
echo "APP_GROUP=${APP_GROUP}"
echo "APP_RELEASE=${APP_RELEASE}"

# Define the container name
CONTAINER_NAME=mazu-build-${APP_NAME}-$(whoami)

# Inside container: build
if [ "$MAZU_BUILD_ENV" == "$CONTAINER_NAME" ]; then
	# echo "Building mazu_message from group ${APP_GROUP} in container ${CONTAINER_NAME}..."

	USER=$(whoami)
	ARCH=$2
	TYPE=$3
	CI_FLAG=$4
	SYMBOL_TABLE=$5
	MAZU_REMOTE=$6

	echo "[INFO] build running in container..."
	if [ "$TYPE" == "release" ]; then
		DEBUG_OPTION="-c opt --copt -g --jobs $(nproc)"
	else
		DEBUG_OPTION="-c dbg --copt -DDEBUG --jobs $(nproc)"
	fi

	echo "Environment Variables List:
          MAZU_ARCH         : $ARCH
          MAZU_CI_FLAG      : $CI_FLAG
          MAZU_SYMBOL_TABLE : $SYMBOL_TABLE
          MAZU_BUILD_TYPE   : $TYPE  "

	# Check whether repo is dirty
	git status | grep "nothing to commit, working tree clean" >/dev/null
	if [ $? -ne 0 ]; then
		DIRTY="-dirty"
	else
		DIRTY=""
	fi

	set -e

	# create build folder and copy mazu_messages into it
	cp -rf /feature_app/.workspace /feature_app/build
	rsync -av /feature_app/common /feature_app/build
	rsync -av /feature_app/np /feature_app/build
	# rsync -av /mazu_messages/nad /mazu_messages/build
	rsync -av /feature_app/BUILD /feature_app/build

	# Update topics.json
	python3 /feature_app/.workspace/misc/parse_proto.py --messages_path=/feature_app --output=/feature_app/build/misc/topics.json
	/feature_app/.workspace/misc/parse_topic_config.sh -i /feature_app -o /feature_app/build/misc

	if [ ! -d /feature_app/.bazel-deps ]; then
		ln -s /home/.bazel-deps /feature_app/build/.bazel-deps
	fi
	set +e

	BUILD_RESOURCES="--local_cpu_resources=HOST_CPUS-1 --local_ram_resources=HOST_RAM*.9"
	echo "Limiting build resources: $BUILD_RESOURCES"

	set -e
	if [ "$ARCH" == "x86" ]; then
		cd /feature_app/build
		bazel build $BUILD_RESOURCES $DEBUG_OPTION //:nio_messages_cc_proto
	else
		cd /feature_app/build
		bazel build --config mazu $BUILD_RESOURCES $DEBUG_OPTION //:nio_messages_cc_proto
	fi
	set +e

	echo "[INFO] successfully built target: $ARCH $TYPE"

	DATETIME=$(date +%y%m%d.%H%M)
	COMMIT=$(git rev-parse --short HEAD)
	COMMIT_FULL=$(git rev-parse HEAD)
	COMMIT_TINY=${COMMIT:0:2}

	# Write the commit down in a file for the app to read
	echo "############################################"
	echo "[INFO] copying conf lib and header to src"
	echo ${COMMIT} >/feature_app/mazu_messages_commit
  sudo cp /feature_app/build/bazel-bin/np/apps/*.pb.h /feature_app/src/L2/fct_app/cal/include
	sudo cp /feature_app/build/bazel-bin/libnio_messages_proto.so /feature_app/src/L2/fct_app/cal/lib/libfct_conf_proto.so
	echo "[INFO] successfully build conf message"
  echo "############################################"

	# if [ "$CI_FLAG" == "temp" ]; then
	# 	# if [ -z "${APP_GROUP}" ]; then
	# 	# 	TAR_FILE=${APP_NAME}-local-${DATETIME}-${ARCH}-${TYPE}-${COMMIT}${DIRTY}.tar.gz
	# 	# else
	# 	# 	TAR_FILE=${APP_NAME}-${APP_GROUP}-local-${DATETIME}-${ARCH}-${TYPE}-${COMMIT}${DIRTY}.tar.gz
	# 	# fi
	# 	# REMOTE_PATH=${CI_FLAG}/$(whoami)
	# else
	if [ "$DIRTY" != "" ]; then
		echo "repo is dirty!"
		git status
	fi
	# 	# TAR_FILE=${APP_NAME}-${APP_GROUP}-${DATETIME}-${ARCH}-${TYPE}-${COMMIT}.tar.gz
	# 	# REMOTE_PATH=${CI_FLAG}/${APP_RELEASE}${APP_GROUP}/${ARCH}/${APP_NAME}/${TYPE}
	# fi

	# Override the REMOTE_PATH if it is defined
	# if [ "$MAZU_REMOTE" != "UNDEFINED" ]; then
	# 	REMOTE_PATH=${MAZU_REMOTE}
	# fi

	# set -e
	# echo "[INFO] Creating TAR_FILE: ${TAR_FILE}"
	# # bash -e /feature_app/build/scripts/dist.sh $ARCH $TYPE /feature_app/build/bazel-bin/dist/${ARCH}/${TYPE} $SYMBOL_TABLE
	# bash -e /feature_app/build/scripts/dist.sh $ARCH $TYPE /feature_app/build/bazel-bin/dist/${ARCH}/${TYPE} $SYMBOL_TABLE
	# cd /feature_app/build/bazel-bin/dist/${ARCH}/${TYPE} && tar --mtime="2022-01-24 00:00Z" --owner=0 --group=0 --numeric-owner --sort=name -zcf ../../../${TAR_FILE} *
	# echo "[INFO] successfully build ./bazel-bin/$TAR_FILE"
	# set +e

	# publish to dist only on CI build
	# if [[ "$MAZU_STAGE" == "false" ]]; then
	# 	echo "Uploading built mazu_messages to ${REMOTE_PATH}..."
	# 	if [[ "$CI_FLAG" == "temp" || "$CI_COMMIT_REF_NAME" == "master" ]]; then
	# 		curl -X POST -H "MAZU_ARTIFACT_TOKEN:ojFEP1pW4zvAQH1Ab9PMHw==" -F "file=@/feature_app/build/bazel-bin/${TAR_FILE}" -F "path=${REMOTE_PATH}" "https://api-mazu.nioint.com/upload"
	# 	else
	# 		curl -X POST -H "MAZU_ARTIFACT_TOKEN:oJS7qZKnHNvoZCatv+gC0g==" -F "file=@/feature_app/build/bazel-bin/${TAR_FILE}" -F "path=${REMOTE_PATH}" "https://api-mazu.nioint.com/upload" -F "latest=true"
	# 	fi
	# 	URL="https://mazu.nioint.com/${REMOTE_PATH}/${TAR_FILE}"
	# 	echo "$URL" >"/feature_app/mazu_messages_url"
	# 	echo "[INFO] published to $URL"
	# fi

	# if [ -z "$CI_COMMIT_REF_NAME" ]; then
	# 	echo ""
	# else
	# 	echo "CI build, renaming and uploading artifact to another place"
	# 	REMOTE_PATH_NEW="private/nobody/mazu_messages/${ARCH}/${COMMIT_TINY}"
	# 	TAR_FILE_NEW=${COMMIT_FULL}.tar.gz
	# 	mv /mazu_messages/build/bazel-bin/${TAR_FILE} /mazu_messages/build/bazel-bin/${TAR_FILE_NEW}
	# 	curl -X POST -F "file=@/mazu_messages/build/bazel-bin/${TAR_FILE_NEW}" -F "path=${REMOTE_PATH_NEW}" -F "isOverWrite=true" "https://api-mazu.nioint.com/upload"
	# 	URL="https://mazu.nioint.com/${REMOTE_PATH_NEW}/${TAR_FILE_NEW}"
	# 	echo "[INFO] published to another place $URL"
	# 	echo ""
	# fi

	exit 0
fi

# Outside container: create container and execute command inside it
# Clean container
if [ "$1" == "clean" ]; then
	# docker stop $CONTAINER_NAME
	# docker rm $CONTAINER_NAME
	rm -rf build
	# rm -f mazu_messages_commit
	# rm -f mazu_messages_url
	./build_ros.sh clean
	exit 0
fi

# Create container
docker ps | grep -c $CONTAINER_NAME >/dev/null
if [ $? -ne 0 ]; then
	echo "No build container found. creating..."
	#==================================================================

	if [[ "$MAZU_STAGE" == "" ]]; then
		MAZU_STAGE=false
	fi

	if [[ "$MAZU_SYMBOL_TABLE" == "" ]]; then
		MAZU_SYMBOL_TABLE=true
	fi

	set -e

	echo "creating container..."
	docker run -d -t \
		--name $CONTAINER_NAME \
		-e "TERM=xterm-256color" \
		-e "MAZU_BUILD_ENV=$CONTAINER_NAME" \
		-e "TZ=Asia/Shanghai" \
		-e CI_COMMIT_REF_NAME=$CI_COMMIT_REF_NAME \
		-e CI_COMMIT_TAG=$CI_COMMITTAG \
		-e MAZU_STAGE=$MAZU_STAGE \
		--cap-add=SYS_PTRACE \
		--security-opt seccomp=unconfined \
		-v $HOME/.ssh:/root/_ssh:ro \
		-v $APP_ROOT:/$APP_NAME \
		adas-hub.nioint.com/nvcr/drive-agx-orin-linux-aarch64-sdk-build-x86:6.0.2.0-0008-customized

	docker exec -u root $CONTAINER_NAME bash -c " \
	        userdel nvidia &&
			mkdir -p /home/$USER && \
			groupadd -g $(id -g) mazu && \
			useradd -d /home/$USER -s /bin/bash -u $(id -u) -g $(id -g) $USER && \
			cp -r /root/_ssh /home/$USER/.ssh && \
			chown -R $USER /home/$USER && \
			echo 'Done.' \
			"

	# docker exec -u root $CONTAINER_NAME apt-get install tzdata

	docker exec -u root $CONTAINER_NAME bash -c "echo $USER 'ALL=(ALL:ALL) NOPASSWD:ALL' >> /etc/sudoers"

	echo "Container setup accomplished."
	#==================================================================

fi

if [ "$MAZU_BUILD_TYPE" == "" ]; then
	MAZU_BUILD_TYPE=release
fi

if [ "$MAZU_ARCH" == "" ]; then
	MAZU_ARCH=aarch64
fi

if [ "$MAZU_TEMP" == "" ]; then
	MAZU_TEMP="false"
fi

if [[ "$CI_COMMIT_REF_NAME" == "master" || "$CI_COMMIT_REF_NAME" == "stable/"* || "$CI_COMMIT_REF_NAME" == "trial/"* ]] && [[ "$MAZU_TEMP" == "false" ]]; then
	MAZU_CI_FLAG="shared"
else
	MAZU_CI_FLAG="temp"
fi
echo "CI_COMMIT_REF_NAME: $CI_COMMIT_REF_NAME"
echo "MAZU_CI_FLAG: $MAZU_CI_FLAG"

if [ "$MAZU_REMOTE" == "" ]; then
	MAZU_REMOTE="UNDEFINED"
fi

if [ "$1" == "create" ]; then
	docker exec -u root $CONTAINER_NAME bash -c 'wget -q https://mazu.nioint.com/bazel/bazel -O /usr/bin/bazel'
	docker exec -u $USER -w /feature_app/messages $CONTAINER_NAME bash -c 'curl -sL https://mazu.nioint.com/bazel/bazel-deps-latest.tar.gz | tar xz'
	if [ "$2" != "" ]; then
		docker rename $CONTAINER_NAME $2
		echo "[INFO] created mazu_messages container: $2"
	else
		echo "[INFO] created mazu_messages container: $CONTAINER_NAME"
	fi
	exit 0

elif [ "$1" == "shell" ]; then

	docker exec -it -u $USER -w /feature_app $CONTAINER_NAME bash

elif [ "$1" == "make" ]; then

  echo "[INFO] build_ros..."
	# Generate .msg and .py
	./build_ros.sh make

	# Compile proto
	docker exec -u $USER -w /feature_app $CONTAINER_NAME bash build_msg.sh make $MAZU_ARCH $MAZU_BUILD_TYPE $MAZU_CI_FLAG $MAZU_SYMBOL_TABLE $MAZU_REMOTE

elif [ "$1" == "publish" ]; then
	# CI only
	echo

else
	error "unknown command: $1"
	error
	exit 1
fi
