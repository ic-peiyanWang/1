#!/usr/bin/env bash

if [[ -z "$APP_ROOT" ]]; then
    APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
fi

export MAZU_ARCH=${MAZU_ARCH}
export MAZU_BUILD_TYPE=${MAZU_BUILD_TYPE}
. $APP_ROOT/integration/scripts/app-run.sh $*
