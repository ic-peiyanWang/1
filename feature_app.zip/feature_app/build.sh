#!/usr/bin/env bash

if [[ -z "$APP_ROOT" ]]; then
    APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
fi

APP_NAME=$(
    cd "$APP_ROOT"
    pwd | sed 's@.*/@@g'
)

CONTAINER_NAME=mazu-build-$APP_NAME-$(whoami)

if [ "$1" == "clean" ]; then
    # Clean up all the containers; call app-clean.sh to clean up folders and files
    docker container ls -a | grep -q $CONTAINER_NAME
    if [[ $? == 0 ]]; then
        echo "stop $CONTAINER_NAME"
        docker stop $CONTAINER_NAME >/dev/null

        echo "remove $CONTAINER_NAME"
        docker rm $CONTAINER_NAME >/dev/null
    fi

    if [[ -f $APP_ROOT/integration/scripts/app-clean.sh ]]; then
        . $APP_ROOT/integration/scripts/app-clean.sh $*
    fi
else
    # Get integration tarball, call the app-build.sh script
    if [ "$MAZU_ARCH" == "" ]; then
        MAZU_ARCH=aarch64
    fi

    if [ "$MAZU_BUILD_TYPE" == "" ]; then
        MAZU_BUILD_TYPE=release
    fi

    if [ -z "$MAZU_INTEGRATION" ]; then
        MAZU_INTEGRATION="https://mazu.nioint.com/dist/integration_orin/${MAZU_ARCH}/${MAZU_BUILD_TYPE}/integration-${MAZU_ARCH}-${MAZU_BUILD_TYPE}-latest.tar.gz"
    fi
    echo "MAZU_INTEGRATION = $MAZU_INTEGRATION"

    if [[ ! -d $APP_ROOT/integration ]]; then
        mkdir -p $APP_ROOT/integration && cd $APP_ROOT/integration
        wget -q ${MAZU_INTEGRATION} --no-check-certificate
        tar -xzf *.tar.gz
        rm *.tar.gz
    fi

    export MAZU_ARCH=${MAZU_ARCH}
    export MAZU_BUILD_TYPE=${MAZU_BUILD_TYPE}
    export MAZU_INTEGRATION=${MAZU_INTEGRATION}
    . $APP_ROOT/integration/scripts/app-build.sh $*
fi
