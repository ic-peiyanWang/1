#!/bin/bash

if [[ -z "$APP_ROOT" ]]; then
    APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../" && pwd -P)"
fi
if [[ -z "$INTEGRATION_ROOT" ]]; then
    INTEGRATION_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../integration" && pwd -P)"
fi

. $INTEGRATION_ROOT/scripts/__log.sh

if [ "$MAZU_UPDATE_BASE" == "" ]; then
    MAZU_UPDATE_BASE=false
fi

if [ "$MAZU_BUILD_TYPE" == "" ]; then
    MAZU_BUILD_TYPE=release
fi

if [ "$MAZU_ARCH" == "" ]; then
    MAZU_ARCH=x86
fi

# Define the integration and mazu_messages that used
if [ -z "$MAZU_INTEGRATION" ]; then
    info "MAZU_INTEGRATION is undefined. Use default one."
    MAZU_INTEGRATION="https://mazu.nioint.com/dist/integration/${MAZU_ARCH}/${MAZU_BUILD_TYPE}/integration-${MAZU_ARCH}-${MAZU_BUILD_TYPE}-latest.tar.gz"
fi

if [ "$MAZU_MESSAGES" == "" ]; then
    info "MAZU_MESSAGES is undefined. Use default one."
    MAZU_MESSAGES="http://mazu.nioint.com/shared/main/${MAZU_ARCH}/mazu_messages/${MAZU_BUILD_TYPE}/mazu_messages-main-${MAZU_ARCH}-${MAZU_BUILD_TYPE}-latest.tar.gz"
fi

function usage() {
    warn "
    Usage:

        ./run.sh test <app_name> # run single app test suite
        ./run.sh <app_name> # run single app

        MAZU_UPDATE_BASE=false ./run.sh test <app_name> # run single app test and not download dependencies
        MAZU_UPDATE_BASE=false ./run.sh <app_name> # run single app and not download dependencies

    Description:
        MAZU_UPDATE_BASE : download runtime dependencies (third_party, common_lib and integration)
        MAZU_BUILD_TYPE  : specify the build type of the dependencies (debug/release)
        MAZU_ARCH        : specify the arch of the dependencies (aarch64/x86)
        MAZU_INTEGRATION : specify the integration that used (url)
        MAZU_MESSAGES    : specify the mazu_messages that used (url)

    "
}

if [ "$1" == "help" ] || [ "$1" == "" ]; then
    usage
    exit 0
fi

info "MAZU_UPDATE_BASE: $MAZU_UPDATE_BASE"
info " MAZU_BUILD_TYPE: $MAZU_BUILD_TYPE"
info "       MAZU_ARCH: $MAZU_ARCH"
info "MAZU_INTEGRATION: $MAZU_INTEGRATION"
info "   MAZU_MESSAGES: $MAZU_MESSAGES"

APP_NAME=$(
    cd "$APP_ROOT"
    pwd | sed 's@.*/@@g'
)
if [[ "$1" == "" ]]; then
    RUN_NAME=${APP_NAME}
else
    RUN_NAME="$1"
fi
echo "run app: $1"

# x86 env
if [[ $(uname -m) =~ "x86" ]]; then
    CONTAINER_NAME=mazu-build-$APP_NAME-$(whoami)
    docker exec -it -u $USER \
        $CONTAINER_NAME bash -c "
        mkdir -p /tmp/runtime/
        cd /tmp/runtime/
        export CYBER_PATH=/tmp/runtime/
        export LD_LIBRARY_PATH=/tmp/runtime/
        if [ \"${MAZU_UPDATE_BASE}\" == "true" ]; then
            wget $MAZU_INTEGRATION
            tar xf integration-*.tar.gz
            rm integration-*.tar.gz
            wget http://mazu.nioint.com/dist/3rdparty/$MAZU_ARCH/mazu-3rdparty-$MAZU_ARCH-latest.tar.gz
            tar xf mazu-3rdparty-$MAZU_ARCH-latest.tar.gz
            rm mazu-3rdparty-$MAZU_ARCH-latest.tar.gz
            wget $MAZU_MESSAGES
            tar xf mazu_messages-*.tar.gz
            rm mazu_messages-*.tar.gz
        fi
        "

    info "active $CONTAINER_NAME by export environment variables"
    FUNC_NAME=${RUN_NAME#*_}
    info "   FUNC_NAME: $FUNC_NAME"
    CONTAINER_NAME=mazu-build-$APP_NAME-$(whoami)
    docker exec -it -u $USER \
        $CONTAINER_NAME bash -c "
        export GTEST_FILTER=${GTEST_FILTER}
        cd /$APP_NAME/build/$MAZU_ARCH/src/L2/$FUNC_NAME/test
        export CYBER_PATH=/tmp/runtime/
        export LD_LIBRARY_PATH=/tmp/runtime/
        ./$RUN_NAME
        "
fi