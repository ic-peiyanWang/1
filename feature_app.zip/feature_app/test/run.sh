#!/usr/bin/env bash

if [[ -z "$TEST_ROOT" ]]; then
    TEST_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
fi

export MAZU_ARCH=${MAZU_ARCH}
export MAZU_BUILD_TYPE=${MAZU_BUILD_TYPE}
. $TEST_ROOT/app-run.sh $*
