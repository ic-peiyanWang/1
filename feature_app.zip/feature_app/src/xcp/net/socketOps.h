/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#pragma once

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

namespace net
{

struct sockaddr* sockaddr_cast( struct sockaddr_in* addr);
struct sockaddr_in* sockaddr_in_cast( struct sockaddr* addr);

class Socket
{
public:
    Socket();
    ~Socket();

    int socketBind(const struct sockaddr *addr);
    int socketListen();
    int socketAccept();
    int setTcpNoDelay(int on);
    int setReuseAddr(int on);
    int setReusePort(int on);
    void closeSocket();

    //disable copy and assign
    Socket(const Socket &ref) = delete;
    Socket & operator = (const Socket &ref) = delete;

private:
    int sockfd_;
    int socketAPICall(const char *info, int result);
};
}
