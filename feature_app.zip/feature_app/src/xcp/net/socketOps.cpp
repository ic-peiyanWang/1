/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#include "socketOps.h"

using namespace net;

struct sockaddr* sockaddr_cast(struct sockaddr_in* addr) {
  return reinterpret_cast<struct sockaddr*>(addr);
}

struct sockaddr_in* sockaddr_in_cast(struct sockaddr* addr) {
  return reinterpret_cast<struct sockaddr_in*>(addr);
}

Socket::Socket() {
  sockfd_ = socketAPICall("[socket]", socket(AF_INET, SOCK_STREAM, IPPROTO_TCP));
}

Socket::~Socket() {
  closeSocket();
}

int Socket::socketBind(const struct sockaddr* addr) {
  return socketAPICall("[bind]", bind(sockfd_, addr, sizeof(struct sockaddr)));
}

int Socket::socketListen() {
  return socketAPICall("[listen]", listen(sockfd_, SOMAXCONN));
}

// Not concern about client port and addr, set NULL.
int Socket::socketAccept() {
  return socketAPICall("[accept]", accept(sockfd_, NULL, NULL));
}

int Socket::setTcpNoDelay(int on) {
  return socketAPICall("[setsockopt no delay]", setsockopt(sockfd_, IPPROTO_TCP, TCP_NODELAY, (void*)&on, sizeof(int)));
}

int Socket::setReuseAddr(int on) {
  return socketAPICall("[setsockopt reuse addr]",
                       setsockopt(sockfd_, SOL_SOCKET, SO_REUSEADDR, (void*)&on, sizeof(int)));
}

int Socket::setReusePort(int on) {
  return socketAPICall("[setsockopt reuse port]",
                       setsockopt(sockfd_, SOL_SOCKET, SO_REUSEPORT, (void*)&on, sizeof(int)));
}

int Socket::socketAPICall(const char* info, int result) {
  if (result < 0) {
    // nlog_info("Socket API error:%s: %s", info, strerror(errno));
  }
  return result;
}

void Socket::closeSocket() {
  if (-1 != sockfd_) {
    shutdown(sockfd_, SHUT_RDWR);
    close(sockfd_);
  }
  sockfd_ = -1;
}
