/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#include "tcpServer.h"

using namespace net;

tcpServer::tcpServer(int port)
  : running_(false), serverAddr_(port), onConnctionFd_(-1), connectionState_(kDisconnected), messageCb_(NULL),
    connectionCb_(NULL), disconnectionCb_(NULL) {
  serverSocket_.setReuseAddr(true);
  serverSocket_.setReusePort(true);
  serverSocket_.setTcpNoDelay(true);
  serverSocket_.socketBind(serverAddr_.getSockAddr());
}

tcpServer::~tcpServer() {
  if (!stop_)
    stop();
}

int tcpServer::start() {
  int ret = 0;

  if (!running_) {
    running_ = true;
    if (!serviceThread.joinable()) {
      serviceThread = std::thread(&tcpServer::doService, this);
    } else {
      ret = -1;
    }
  }

  return ret;
}

void tcpServer::stop() {
  stop_ = true;
  if (serviceThread.joinable()) {
    serverSocket_.closeSocket();
    serviceThread.join();
  } else {
    /*do nothing*/
  }
}

void tcpServer::doService() {
  char revbuf[ETHDRV_BUF_SIZE];
  serverSocket_.socketListen();

  while (!stop_) {
    onConnctionFd_ = serverSocket_.socketAccept();

    if (onConnctionFd_ >= 0) {
      connectionState_ = kConnected;

      if (connectionCb_) {
        connectionCb_(onConnctionFd_);
      }

      while (connectionState_ == kConnected) {
        ssize_t nbytes = recv(onConnctionFd_, revbuf, ETHDRV_BUF_SIZE, 0);

        if (nbytes <= 0) {
          connectionState_ = kDisconnected;

          close(onConnctionFd_);

          if (disconnectionCb_) {
            disconnectionCb_(onConnctionFd_);
          }
          break;
        } else {
          if (messageCb_) {
            messageCb_(onConnctionFd_, revbuf, nbytes);
          }
        }
      }
    }
  }
}

int tcpServer::transmit(char* buf, int len) {
  int ret = -1;
  /* transmit  packet */
  if (connectionState_ == kConnected) {
    ret = send(onConnctionFd_, buf, len, MSG_NOSIGNAL);

    if (ret < 0) {
      // nlog_info("Disconnected port:%d send fail.",  serverAddr_.toPort());
    }
  }
  return ret;
}
