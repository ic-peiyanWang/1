/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#pragma once

#include <thread>
#include <atomic>
#include <functional>
#include "inetAddr.h"
#include "socketOps.h"

namespace net
{

class tcpServer
{
public:
    typedef std::function<void(int sockfd, char *buf, int len)>
        MessageCallback;
    typedef std::function<void(int sockfd)>
        ConnectionCallback;
    typedef std::function<void(int sockfd)>
        DissconnectionCallback;
    enum StateE { kDisconnected, kConnected };

    tcpServer(int port);
    ~tcpServer();
    int start();
    void stop();
    int transmit(char *buf, int len);

    void setMessageCallback(MessageCallback cb)
    {
        messageCb_    = cb;
    }
    void setConnectionCallback(ConnectionCallback cb)
    {
        connectionCb_ = cb;
    }
    void setDissconnectionCallback(DissconnectionCallback cb)
    {
        disconnectionCb_ = cb;
    }
    bool connectState() const
    {
        return connectionState_;
    }

    //disable copy and assign
    tcpServer(const tcpServer &ref) = delete;
    tcpServer & operator = (const tcpServer &ref) = delete;

private:
    bool                        running_;
    Socket                 serverSocket_;
    inetAddr                 serverAddr_;
    int                   onConnctionFd_;
    std::thread            serviceThread;
    std::atomic<StateE>   connectionState_;

    MessageCallback               messageCb_;
    ConnectionCallback         connectionCb_;
    DissconnectionCallback  disconnectionCb_;
    bool stop_ = false;

    void doService();
    const static int ETHDRV_BUF_SIZE = 200;
};

}