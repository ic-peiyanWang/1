/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#pragma once
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <string.h>

namespace net
{
class inetAddr
{
public:
    explicit inetAddr(unsigned short port)
    {
        addr_.sin_family = AF_INET;
        addr_.sin_addr.s_addr = INADDR_ANY;
        addr_.sin_port = htons(port);
    }

    explicit inetAddr(struct sockaddr_in addr)
    : addr_(addr)
    { }

    explicit inetAddr(struct sockaddr addr)
    {
        memcpy(&addr_, &addr, sizeof(struct sockaddr_in));
    }

    const char * toIp() const
    {
        return inet_ntoa(addr_.sin_addr);
    }

    unsigned short toPort() const
    {
        return ntohs(addr_.sin_port);
    }

    const struct sockaddr* getSockAddr()
    {
        return reinterpret_cast<const struct sockaddr*>(&addr_);
    }

private:
    struct sockaddr_in addr_;
};
}