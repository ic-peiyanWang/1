#ifndef XCP_IF_MOCK_H_SUPXKLYT
#define XCP_IF_MOCK_H_SUPXKLYT
/*
 * xcp_if_mock.h
 *
 * Copyright (c) 2017-2017 NIO Autonomous Driving
 * All rights reserved.
 *
 */

#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <memory>

#include "xcp_if.h"

using namespace ::testing;

//create mock class
class xcp_if_mock {
public:
	virtual ~xcp_if_mock() {}
	MOCK_METHOD0(xcp_if_init, void());
	MOCK_METHOD3(xcp_if_rx_callback, int(unsigned char in_srvno, char *in_buff, int in_length));
	MOCK_METHOD1(DSXCP_eth_init, void(unsigned int service_no));
	MOCK_METHOD3(DSXCP_eth_packet_receive, UInt8(unsigned int service_no, UInt8 *data, UInt16 *length));
	MOCK_METHOD3(DSXCP_eth_packet_send, UInt8(unsigned int service_no, UInt8 *data, UInt16 *length));
};

class xcp_if_fixture: public Test {
public:
    xcp_if_fixture(){
        xcp_if_mock_p.reset(new NiceMock<xcp_if_mock>());
    }
    ~xcp_if_fixture(){
        xcp_if_mock_p.reset();
    }
    virtual void SetUp(){}
    virtual void TearDown(){}

    // pointer for accessing mock
    static std::unique_ptr<xcp_if_mock> xcp_if_mock_p;
};

#endif /* end of include guard:  */
