/*
 * xcp_if_mock.cpp
 *
 * Copyright (c) 2017-2017 NIO Autonomous Driving
 * All rights reserved.
 *
 */

#include "xcp_if.h"
#include "xcp_if_mock.h"

//initiate mock pointer
std::unique_ptr<xcp_if_mock> xcp_if_fixture::xcp_if_mock_p;

void xcp_if_init(void)
{
    xcp_if_fixture::xcp_if_mock_p->xcp_if_init();
}

int xcp_if_rx_callback(unsigned char in_srvno, char *in_buff, int in_length)
{
    return xcp_if_fixture::xcp_if_mock_p->xcp_if_rx_callback(in_srvno, in_buff, in_length);
}

void DSXCP_eth_init(unsigned int service_no)
{
    xcp_if_fixture::xcp_if_mock_p->DSXCP_eth_init(service_no);
}

UInt8 DSXCP_eth_packet_receive(unsigned int service_no, UInt8 *data, UInt16 *length)
{
    return xcp_if_fixture::xcp_if_mock_p->DSXCP_eth_packet_receive(service_no, data, length);
}

UInt8 DSXCP_eth_packet_send(unsigned int service_no, UInt8 *data, UInt16 length)
{
    return xcp_if_fixture::xcp_if_mock_p->DSXCP_eth_packet_send(service_no, data, length);
}


