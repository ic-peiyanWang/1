/*******************************************************************************
*
*  FILE
*    xcp_prot.c
*
*  DESCRIPTION
*    This file contains the protocol layer of the dSPACE XCP Service.
*
*  COPYRIGHT
*    Copyright 2015, dSPACE GmbH. All rights reserved.
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*
*  AUTHOR(S)
*    Bastian Kellers
*
*  VERSION
*    2.4.0
*
*  $RCSfile: xcp_prot.c $ $Revision: 1.22 $ $Date: 2015/12/18 11:47:41MEZ $
*
*******************************************************************************/

#include "xcp_prot.h"
#include "ecu_if.h"
#include "xcp_gen.h"

/* dSPACE XCP service compilation check */
#ifndef DSXCP_SERVICE_DISABLED

/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

/* version number of the dSPACE XCP service */
#define XCP_DRIVER_VERSION                        0x24  /* version 2.4 */

/* status of pending tasks */
#define XCP_NO_PENDING                            0x00
#define XCP_PENDING_UPLOAD_INFO                   0x01
#define XCP_PENDING_EVENT                         0x02

/* status of seed (required for seeds larger than 1 XCP packet) */
#define XCP_SEED_INCOMPLETE                       0
#define XCP_SEED_COMPLETE                         1

/* status of DAQ pointer */
#define XCP_DAQ_PTR_INVALID                       0
#define XCP_DAQ_PTR_VALID                         1

/* status of event channels concerning assignment of DAQ lists */
#define XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED         0
#define XCP_EVENT_CHANNEL_DAQ_ASSIGNED            1

/* status of non-volatile memory programming */
#define XCP_PGM_STATUS_INACTIVE                   0x00
#define XCP_PGM_STATUS_ACTIVE                     0x01
#define XCP_PGM_STATUS_PREPARED                   0x02
#define XCP_PGM_STATUS_STARTED                    0x03

#define UNREFERENCED_PARAMETER(Param)             (void)(Param)

/* structure of a buffer element containing an XCP DTO packet */
typedef struct
{
  UInt32 length;
  UInt8  data[XCP_MAX_DTO_0];
} dto_buffer_element0_t;

#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
typedef struct
{
  UInt32 length;
  UInt8  data[XCP_MAX_DTO_1];
} dto_buffer_element1_t;
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */


/*******************************************************************************
  object declarations
*******************************************************************************/

/**** common objects **********************************************************/

/* XCP service struct */
static xcp_struct_t xcp_struct[XCP_NO_OF_SERVICE_INSTANCES];

/* variables containing specific properties for each service instance */
#if (XCP_NO_OF_SERVICE_INSTANCES == 1)
static const UInt8  xcp_max_cto[1]    = {XCP_MAX_CTO_0};
static const UInt16 xcp_max_dto[1]    = {XCP_MAX_DTO_0};
static const UInt8  xcp_tl_version[1] = {XCP_TRANSPORT_LAYER_VERSION_0};
static const UInt8  xcp_resource[1]   = {XCP_RESOURCE_0};
#else /* (XCP_NO_OF_SERVICE_INSTANCES == 2) */
static const UInt8  xcp_max_cto[2]    = {XCP_MAX_CTO_0, XCP_MAX_CTO_1};
static const UInt16 xcp_max_dto[2]    = {XCP_MAX_DTO_0, XCP_MAX_DTO_1};
static const UInt8  xcp_tl_version[2] = {XCP_TRANSPORT_LAYER_VERSION_0, XCP_TRANSPORT_LAYER_VERSION_1};
static const UInt8  xcp_resource[2]   = {XCP_RESOURCE_0, XCP_RESOURCE_1};
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 1) */


/**** objects for STD resource ************************************************/

#if (XCP_CHECKSUM_CALCULATION == XCP_ENABLED)

  #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16)
/* crc16 lookup table for checksum calculation */
static const UInt32 xcp_crc16_table[256] =
{
  0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
  0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
  0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
  0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
  0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
  0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
  0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
  0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
  0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
  0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
  0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
  0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
  0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
  0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
  0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
  0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
  0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
  0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
  0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
  0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
  0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
  0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
  0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
  0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
  0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
  0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
  0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
  0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
  0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
  0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
  0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
  0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};
  #endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16) */

  #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16_CCITT)
/* crc16 lookup table for checksum calculation */
static const UInt32 xcp_crc16ccitt_table[256] =
{
  0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
  0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
  0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
  0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
  0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
  0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
  0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
  0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
  0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
  0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
  0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
  0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
  0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
  0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
  0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
  0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
  0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
  0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
  0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
  0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
  0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
  0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
  0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
  0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
  0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
  0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
  0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
  0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
  0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
  0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
  0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
  0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};
  #endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16_CCITT) */

  #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_32)
/* crc32 lookup table for checksum calculation */
static const UInt32 xcp_crc32_table[256] =
{
  0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA,
  0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
  0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988,
  0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
  0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE,
  0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
  0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC,
  0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
  0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172,
  0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
  0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940,
  0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
  0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116,
  0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
  0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924,
  0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
  0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A,
  0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
  0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818,
  0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
  0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E,
  0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
  0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C,
  0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
  0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2,
  0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
  0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0,
  0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
  0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086,
  0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
  0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4,
  0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
  0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A,
  0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
  0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8,
  0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
  0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE,
  0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
  0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC,
  0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
  0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252,
  0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
  0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60,
  0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
  0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236,
  0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
  0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04,
  0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
  0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A,
  0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
  0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38,
  0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
  0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E,
  0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
  0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C,
  0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
  0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2,
  0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
  0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0,
  0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
  0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6,
  0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
  0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94,
  0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
};
  #endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_32) */
#endif /* #if (XCP_CHECKSUM_CALCULATION == XCP_ENABLED) */


/**** objects for CAL/PAG resource ********************************************/

#if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)
  #if (XCP_INFO_COMMANDS_CAL_PAG == XCP_ENABLED)

/* information on segments */
static const xcp_segment_info_t xcp_segment_info[XCP_MAX_SEGMENT] = XCP_SEGMENT_INFO_DATA;

/* information on pages */
static const xcp_page_info_t xcp_page_info[XCP_MAX_SEGMENT * XCP_MAX_PAGES] = XCP_PAGE_INFO_DATA;

  #endif /* #if (XCP_INFO_COMMANDS_CAL_PAG == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) */


/**** objects for DAQ/STIM resource *******************************************/

#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
  /* constant DAQ properties for each service instance */
  #if (XCP_NO_OF_SERVICE_INSTANCES == 1)

static const UInt8  xcp_min_daq[1]                 = {XCP_MIN_DAQ_0};

    #if (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED)

static const UInt8  xcp_daq_properties[1]          = {XCP_DAQ_PROPERTIES_0};

    #endif /* #if (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED) */

    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)

static const UInt8  xcp_daq_config_type_dynamic[1] = {XCP_DAQ_CONFIG_TYPE_DYNAMIC_0};
static const UInt32 xcp_daq_buffer_size[1]         = {XCP_DAQ_BUFFER_SIZE_0};

    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */

  #else /* (XCP_NO_OF_SERVICE_INSTANCES == 2) */

static const UInt8  xcp_min_daq[2]                 = {XCP_MIN_DAQ_0, XCP_MIN_DAQ_1};

    #if (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED)

static const UInt8  xcp_daq_properties[2]          = {XCP_DAQ_PROPERTIES_0, XCP_DAQ_PROPERTIES_1};

    #endif /* #if (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED) */

    #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))

static const UInt8  xcp_daq_config_type_dynamic[2] = {XCP_DAQ_CONFIG_TYPE_DYNAMIC_0, XCP_DAQ_CONFIG_TYPE_DYNAMIC_1};
static const UInt32 xcp_daq_buffer_size[2]         = {XCP_DAQ_BUFFER_SIZE_0, XCP_DAQ_BUFFER_SIZE_1};

    #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)) */
  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 1) */


  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)

/* DAQ buffer for dynamic DAQ list configuration */
static UInt8 xcp_daq_buffer_0[XCP_DAQ_BUFFER_SIZE_0];

    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
      #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
        #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)

/* STIM buffer pointer array for dynamic DAQ list configuration (double buffer and failsafe buffer) */
static dto_buffer_element0_t (*xcp_dto_buffer_0[3]);

        #else /* (XCP_FAILSAFE_BUFFER == XCP_DISABLED) */

/* STIM buffer pointer array for dynamic DAQ list configuration (double buffer) */
static dto_buffer_element0_t (*xcp_dto_buffer_0[2]);

        #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
      #else /* (XCP_DOUBLE_BUFFER == XCP_DISABLED) */

/* STIM buffer pointer array for dynamic DAQ list configuration (single buffer) */
static dto_buffer_element0_t (*xcp_dto_buffer_0[1]);

      #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)

/* DAQ buffer pointer array for dynamic DAQ list configuration (single buffer) */
static dto_buffer_element0_t (*xcp_dto_buffer_0[1]);

    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */

/* DAQ struct containing DAQ lists and ODT entries for static DAQ list configuration */
static struct
{
  /* DAQ list array for predefined and configurable static DAQ lists */
  xcp_daq_list_t daq_list[XCP_MAX_DAQ_0];

  /* entry array for predefined and configurable static DAQ lists */
  xcp_entry_t odt_entry[XCP_NO_OF_ODT_ENTRIES_0 * XCP_NO_OF_ODTS_0];
} xcp_daq_struct_0;

/* configuration data for predefined and configurable static DAQ lists */
static const xcp_daq_list_config_t xcp_daq_list_config_0[XCP_MAX_DAQ_0] = { XCP_NO_OF_ODTS_0, XCP_NO_OF_ODT_ENTRIES_0, 0 };//XCP_DAQ_LIST_CONFIG_DATA_0;

    #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED)

/* configuration data for predefined ODT entries */
static const xcp_entry_t xcp_predefined_odt_entries_0[XCP_NO_OF_PREDEFINED_ODT_ENTRIES_0] = XCP_PREDEFINED_ODT_ENTRIES_DATA_0;

    #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */

    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
      #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
        #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)

/* STIM buffer array for static DAQ list configuration (double buffer and failsafe buffer) */
static dto_buffer_element0_t xcp_dto_buffer_0[3][XCP_NO_OF_ODTS_0];

        #else /* (XCP_FAILSAFE_BUFFER == XCP_DISABLED) */

/* STIM buffer array for static DAQ list configuration (double buffer) */
static dto_buffer_element0_t xcp_dto_buffer_0[2][XCP_NO_OF_ODTS_0];

        #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
      #else /* (XCP_DOUBLE_BUFFER == XCP_DISABLED) */

/* STIM buffer array for static DAQ list configuration (single buffer) */
static dto_buffer_element0_t xcp_dto_buffer_0[1][XCP_NO_OF_ODTS_0];

      #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)

/* DAQ buffer array for dynamic DAQ list configuration (single buffer) */
static dto_buffer_element0_t xcp_dto_buffer_0[1][XCP_NO_OF_ODTS_0];

    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */


  #if (XCP_NO_OF_SERVICE_INSTANCES == 2)

    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)

/* DAQ buffer for dynamic DAQ list configuration */
static UInt8 xcp_daq_buffer_1[XCP_DAQ_BUFFER_SIZE_1];

      #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)

/* DAQ buffer pointer array for dynamic DAQ list configuration (single buffer) */
static dto_buffer_element1_t (*xcp_dto_buffer_1[1]);

      #endif /* (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */

    #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */

/* DAQ struct containing DAQ lists and ODT entries for static DAQ list configuration */
static struct
{
  /* DAQ list array for predefined and configurable static DAQ lists */
  xcp_daq_list_t daq_list[XCP_MAX_DAQ_1];

  /* entry array for predefined and configurable static DAQ lists */
  xcp_entry_t odt_entry[XCP_NO_OF_ODT_ENTRIES_1];
} xcp_daq_struct_1;

/* configuration data for predefined and configurable static DAQ lists */
static const xcp_daq_list_config_t xcp_daq_list_config_1[XCP_MAX_DAQ_1] = XCP_DAQ_LIST_CONFIG_DATA_1;

      #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED)

/* configuration data for predefined ODT entries */
static const xcp_entry_t xcp_predefined_odt_entries_1[XCP_NO_OF_PREDEFINED_ODT_ENTRIES_1] = XCP_PREDEFINED_ODT_ENTRIES_DATA_1;

      #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED) */

      #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)

/* DAQ buffer array for dynamic DAQ list configuration (single buffer) */
static dto_buffer_element1_t xcp_dto_buffer_1[1][XCP_NO_OF_ODTS_1];

      #endif /* (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */

    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

  #if (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)
/* information on event channels */
static const xcp_event_channel_info_t xcp_event_channel_info[XCP_MAX_EVENT_CHANNEL] = XCP_EVENT_CHANNEL_INFO_DATA;
  #endif /* #if (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED) */

#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


/**** objects for PGM resource ************************************************/

#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
  #if (XCP_INFO_COMMANDS_PGM == XCP_ENABLED)

/* information on sectors */
static const xcp_sector_info_t xcp_sector_info[XCP_MAX_SECTOR] = XCP_SECTOR_INFO_DATA;

  #endif /* #if (XCP_INFO_COMMANDS_PGM == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED) */


/*******************************************************************************
  function prototypes
*******************************************************************************/

static void xcp_pl_init(unsigned int service_no);
#if (XCP_EVENT_PROCESSING == XCP_ENABLED)
static void xcp_ev_proc(unsigned int service_no);
#endif /* #if (XCP_EVENT_PROCESSING == XCP_ENABLED) */
#if (XCP_CMD_SET_MTA == XCP_ENABLED)
static void xcp_set_mta(unsigned int service_no, UInt32 address, UInt8 extension);
#endif /* #if (XCP_CMD_SET_MTA == XCP_ENABLED) */
#if ((XCP_CMD_UPLOAD == XCP_ENABLED) || (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED))
static void xcp_upload_from_mta(unsigned int service_no, UInt8 *destination_address, UInt8 no_of_elements);
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) || (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED)) */
#if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED))
static void xcp_block_upload(unsigned int service_no);
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)) */
#if (XCP_CMD_DOWNLOAD == XCP_ENABLED)
static void xcp_download_to_mta(unsigned int service_no, UInt8 *source_address, UInt8 no_of_elements);
#endif /* #if (XCP_CMD_DOWNLOAD == XCP_ENABLED) */
#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED))
static void xcp_store_cal_request(unsigned int service_no);
#endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)) */
#if ((XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED) && (XCP_CHECKSUM_TYPE != XCP_CHECKSUM_TYPE_USER_DEFINED))
static UInt32 xcp_build_checksum(xcp_mta_ptr_t ptr, UInt32 size);
#endif /* #if ((XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED) && (XCP_CHECKSUM_TYPE != XCP_CHECKSUM_TYPE_USER_DEFINED)) */
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
static void xcp_daq_setup(unsigned int service_no);
static void xcp_daq_init(unsigned int service_no);
static void xcp_daq_list_clear(unsigned int service_no, UInt16 daq);
static void xcp_daq_list_start(unsigned int service_no, UInt16 daq);
static void xcp_daq_list_start_selected(unsigned int service_no);
static void xcp_daq_list_stop(unsigned int service_no, UInt16 daq);
static void xcp_daq_list_stop_all(unsigned int service_no);
static void xcp_daq_list_stop_selected(unsigned int service_no);
static void xcp_daq_list_select(unsigned int service_no, UInt16 daq);
static void xcp_daq_list_insert(unsigned int service_no, UInt16 event_channel, UInt16 daq);
static void xcp_daq_list_remove(unsigned int service_no, UInt16 event_channel, UInt16 daq);
static void xcp_check_daq_running(unsigned int service_no);
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
void xcp_prot_send_callback(unsigned int service_no);
#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
#if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
static unsigned int xcp_check_daq_memory_overflow(unsigned int service_no);
#endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
#if (XCP_RESUME_MODE == XCP_ENABLED)
static void xcp_resume_mode_init(unsigned int service_no);
static void xcp_store_daq_request(unsigned int service_no);
static void xcp_clear_daq_request(unsigned int service_no);
#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */

/*******************************************************************************
  function declarations
*******************************************************************************/

/******************************************************************************/
/* dSPACE XCP service layer API functions                                     */
/******************************************************************************/

/*******************************************************************************
*
*  FUNCTION
*    DSXCP_init
*
*
*  SYNTAX
*    void DSXCP_init(void)
*
*  DESCRIPTION
*    This function is the initialization function of the dSPACE XCP service.
*    It is called once during startup of the ECU code.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void DSXCP_init(void)
{
  unsigned int service_no;

  /* initialize external resources needed by the dSPACE XCP service */
  DSXCP_ext_init();

  for (service_no = 0; service_no < XCP_NO_OF_SERVICE_INSTANCES; service_no++)
  {
    /* initialize the protocol layer (without DAQ resource) */
    xcp_pl_init(service_no);

    /* initialize the transport layer */
    xcp_tl_init(service_no);

  #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
    /* setup fixed attributes of DAQ resource */
    xcp_daq_setup(service_no);

    /* initialize the DAQ resource */
    xcp_daq_init(service_no);

  #if (XCP_RESUME_MODE == XCP_ENABLED)
    /* initialize resume mode data (if active) */
    xcp_resume_mode_init(service_no);
  #endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
  #endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */
  }
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_background
*
*
*  SYNTAX
*    void DSXCP_background(void)
*
*  DESCRIPTION
*    This function is the background function of the dSPACE XCP service.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void DSXCP_background(void)
{
  unsigned int service_no;

  for (service_no = 0; service_no < XCP_NO_OF_SERVICE_INSTANCES; service_no++)
  {
  #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED))
    /* receive XCP packets in the background */
    UInt8  *rx_ptr;
    UInt8  pid_off_flag;
    UInt16 daq;

    /* try to get pointer to a new XCP packet of receive buffer */
    rx_ptr = xcp_receive_ptr_get(service_no, &pid_off_flag, &daq);

    /* check if a new XCP packet has been received */
    if (rx_ptr != NULL)
    {
    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
      if ((pid_off_flag == 1) || (rx_ptr[0] <= 0xBE))
      {
        /* a STIM packet has been received, call STIM processor */
        xcp_stim_proc(service_no, rx_ptr, pid_off_flag, daq);
        /* release the pointer to the STIM packet */
        xcp_receive_ptr_release(service_no);
      }
      else
    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
      {
        /* a CMD packet has been received, call CMD processor */
        xcp_cmd_proc(service_no, rx_ptr);
        /* the pointer to the CMD packet is released in xcp_cmd_proc() */
      }
    }
    else
  #endif /* #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED)) */
    {
    #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED))
      /* check if a block upload is pending */
      if (xcp_struct[service_no].no_of_sbm_bytes_remaining > 0)
      {
        xcp_block_upload(service_no);
      }
      else
    #endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)) */
    #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED))
      /* check if a STORE_CAL request is pending */
      if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_STORE_CAL_REQUEST)
      {
        xcp_store_cal_request(service_no);
      }
      else
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)) */
    #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED))
      /* check if a CLEAR_DAQ request is pending */
      if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_CLEAR_DAQ_REQUEST)
      {
        xcp_clear_daq_request(service_no);
      }
      /* check if a STORE_DAQ request is pending */
      else if (xcp_struct[service_no].session_status & (XCP_SESSION_STATUS_STORE_DAQ_REQUEST | XCP_SESSION_STATUS_STORE_DAQ_NO_RESUME_REQUEST))
      {
        xcp_store_daq_request(service_no);
      }
      else
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED)) */
      {
        /* perform EV processing */
      #if (XCP_EVENT_PROCESSING == XCP_ENABLED)
        xcp_ev_proc(service_no);
      #endif /* #if (XCP_EVENT_PROCESSING == XCP_ENABLED) */
      }

    #if (XCP_TX_INT == XCP_DISABLED)
      /* send XCP packets in the background */
      xcp_send_background(service_no);
      #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED))
      xcp_prot_send_callback(service_no);
      #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)) */
    #endif /* #if (XCP_TX_INT == XCP_DISABLED) */
    }
  }
}


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_service
*
*
*  SYNTAX
*    unsigned int DSXCP_service(unsigned int event_channel)
*
*  DESCRIPTION
*    This function is the foreground function of the dSPACE XCP service.
*    It performs data acquisition and data stimulation.
*
*  PARAMETERS
*    event_channel: event channel number
*
*  RETURNS
*    DSXCP_DAQ_ACTIVE
*    DSXCP_DAQ_INACTIVE
*    DSXCP_NEW_DATA
*    DSXCP_OLD_DATA
*    DSXCP_NO_DATA_COPIED
*    DSXCP_FAILSAFE_DATA
*    DSXCP_NO_DATA_AVAILABLE
*
*  REMARKS
*
*******************************************************************************/
unsigned int DSXCP_service(unsigned int event_channel)
{
  unsigned int global_return_value = DSXCP_NO_ERROR;

  if (event_channel < XCP_MAX_EVENT_CHANNEL)
  {
    unsigned int service_no;

    /* iterate over all service instances */
    for (service_no = 0; service_no < XCP_NO_OF_SERVICE_INSTANCES; service_no++)
    {
      unsigned int return_value = DSXCP_NO_ERROR;

      /* check if DAQ is active */
      if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_DAQ_RUNNING)
      {
        /* check if at least one DAQ list has been assigned to this event channel */
        if (xcp_struct[service_no].event_channel[event_channel].status == XCP_EVENT_CHANNEL_DAQ_ASSIGNED)
        {
          xcp_daq_list_t *daq_list_ptr;
          UInt16         daq;
          UInt16         next_daq;

          next_daq = xcp_struct[service_no].event_channel[event_channel].first_daq;

          /* iterate over all DAQ lists which are assigned to this event channel */
          do
          {
            daq = next_daq;
            daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

            /* check if DAQ list is started */
            if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_RUNNING)
            {
            #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
              /* distinguish direction of DAQ list */
              if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_DIRECTION)
              {
                /* data stimulation */
                unsigned int buffer_index      = 0; /* default: buffer index 0 */
                unsigned int no_data_copy_flag = 0; /* default: copy data */
              #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) || (XCP_CONSISTENCY_WAIT == XCP_ENABLED)
                unsigned int consistent_flag   = 0; /* default: DAQ list inconsistent */
              #endif

                /* check if DAQ list is consistent */
                if (daq_list_ptr->consistent_flag == 1)
                {
                  daq_list_ptr->consistent_flag = 0;
                #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) || (XCP_CONSISTENCY_WAIT == XCP_ENABLED)
                  consistent_flag = 1;
                #endif
                }
              #if (XCP_CONSISTENCY_WAIT == XCP_ENABLED)
                else if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_CONSISTENCY_WAIT)
                {
                  /* DAQ list is inconsistent, execute consistency wait mechanismus */
                           XCP_TIMESTAMP_TYPE start_ticks;
                           XCP_TIMESTAMP_TYPE end_ticks;
                  volatile XCP_TIMESTAMP_TYPE current_ticks;

                  start_ticks   = (XCP_TIMESTAMP_TYPE)DSXCP_get_timestamp();
                  end_ticks     = start_ticks + daq_list_ptr->timeout_ticks;
                  current_ticks = start_ticks;

                  /* wait for STIM data until DAQ list is consistent or timeout occurs */
                  while (consistent_flag == 0)
                  {
                    if (daq_list_ptr->consistent_flag == 1)
                    {
                      daq_list_ptr->consistent_flag = 0;
                      consistent_flag = 1;
                    }
                    else
                    {
                      DSXCP_background();
                    }

                    current_ticks = (XCP_TIMESTAMP_TYPE)DSXCP_get_timestamp();

                    /* check for timeout */
                    if (end_ticks > start_ticks)
                    {
                      if ((current_ticks < start_ticks) || (current_ticks > end_ticks))
                      {
                        break;
                      }
                    }
                    else
                    {
                      if ((current_ticks < start_ticks) && (current_ticks > end_ticks))
                      {
                        break;
                      }
                    }
                  }
                }
              #endif /* #if (XCP_CONSISTENCY_WAIT == XCP_ENABLED) */

                /* check if DAQ list has been consistent once */
                if (daq_list_ptr->once_consistent_flag == 0)
                {
                #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
                  /* check if failsafe buffer shall be used */
                  if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_FAILSAFE_BUFFER)
                  {
                    /* failsafe buffer is enabled, use data from failsafe buffer */
                    buffer_index = 2;
                    return_value |= DSXCP_FAILSAFE_DATA;
                  }
                  else
                  {
                    /* failsafe buffer is disabled and DAQ list was never consistent, copy no data */
                    no_data_copy_flag = 1;
                    return_value |= DSXCP_NO_DATA_AVAILABLE;
                  }
                #else /* (XCP_FAILSAFE_BUFFER == XCP_DISABLED) */
                  /* failsafe buffer is disabled and DAQ list was never consistent, copy no data */
                  no_data_copy_flag = 1;
                  return_value |= DSXCP_NO_DATA_AVAILABLE;
                #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
                }
                else
                {
                  /* yes, DAQ list has already been consistent */
                #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
                  if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_DOUBLE_BUFFER)
                  {
                    /* check if DAQ list is consistent */
                    if (consistent_flag == 1)
                    {
                      /* DAQ list is consistent, use data from consistent double buffer */
                      buffer_index = daq_list_ptr->double_buffer_active ^ 0x1;
                    #if (XCP_FAILURE_CHECKING == XCP_ENABLED)
                      daq_list_ptr->failure_count = 0;
                    #endif /* #if (XCP_FAILURE_CHECKING == XCP_ENABLED) */
                      return_value |= DSXCP_NEW_DATA;
                    }
                    else
                    {
                      /* DAQ list is inconsistent, distinguish buffer to use dependent on configuration */
                    #if (XCP_FAILURE_CHECKING == XCP_ENABLED)
                      if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_FAILURE_CHECKING)
                      {
                        /* failure checking is enabled, check if failure condition is true */
                        if (daq_list_ptr->failure_count == daq_list_ptr->failure_limit)
                        {
                        #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
                          /* failure condition is true, check if failsafe buffer shall be used */
                          if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_FAILSAFE_BUFFER)
                          {
                            /* failsafe buffer is enabled, use data from failsafe buffer */
                            buffer_index = 2;
                            return_value |= DSXCP_FAILSAFE_DATA;
                          }
                          else
                          {
                            /* failsafe buffer is disabled, copy no data */
                            no_data_copy_flag = 1;
                            return_value |= DSXCP_NO_DATA_COPIED;
                          }
                        #else /* (XCP_FAILSAFE_BUFFER == XCP_DISABLED) */
                          /* failsafe buffer is disabled, copy no data */
                          no_data_copy_flag = 1;
                          return_value |= DSXCP_NO_DATA_COPIED;
                        #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
                        }
                        else
                        {
                          /* failure condition is false, use data from consistent double buffer */
                          buffer_index = daq_list_ptr->double_buffer_active ^ 0x1;
                          /* increment failure count */
                          daq_list_ptr->failure_count++;
                          return_value |= DSXCP_OLD_DATA;
                        }
                      }
                      else
                      {
                        /* failure checking is disabled, use data from consistent double buffer */
                        buffer_index = daq_list_ptr->double_buffer_active ^ 0x1;
                        return_value |= DSXCP_OLD_DATA;
                      }
                    #else /* (XCP_FAILURE_CHECKING == XCP_DISABLED) */
                      /* failure checking is disabled, use data from consistent double buffer */
                      buffer_index = daq_list_ptr->double_buffer_active ^ 0x1;
                      return_value |= DSXCP_OLD_DATA;
                    #endif /* #if (XCP_FAILURE_CHECKING == XCP_ENABLED) */
                    }
                  }
                #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
                }

                /* check if data shall be copied */
                if (no_data_copy_flag == 0)
                {
                  UInt8         *data_ptr;
                  xcp_entry_t   *entry_ptr;
                  xcp_mta_ptr_t address_ptr;
                  UInt16        dto_length;
                  UInt8         odt;
                  UInt8         pid;

                  /* copy data */
                  /* set entry pointer to first ODT entry of DAQ list */
                  entry_ptr = &xcp_struct[service_no].odt_entry[daq_list_ptr->first_odt_entry];

                  pid = (UInt8)daq_list_ptr->first_odt;

                  /* iterate over all ODTs */
                  for (odt = 0; odt < daq_list_ptr->no_of_configured_odts; odt++)
                  {
                    UInt8 odt_entry;
                    UInt8 no_of_odt_entries;
                    UInt8 no_of_bytes;

                    DSXCP_INT_SAVE_AND_DISABLE();

                    /* set the data pointer to first STIM buffer element of current ODT */
                    data_ptr = (UInt8 *)xcp_dto_buffer_0[buffer_index][pid].data;

                  #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED)
                    /* check if PID OFF is enabled */
                    if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_PID_OFF)
                    {
                      /* no PID used */
                      dto_length = 0;
                    }
                    else
                  #endif /* #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED) */
                    {
                      /* ignore PID, increase data pointer */
                      data_ptr++;
                      dto_length = 1;
                    }

                  #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
                    /* check if time stamping is enabled */
                    if ((odt == 0) && (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_TIMESTAMP))
                    {
                        data_ptr += XCP_TIMESTAMP_SIZE;
                    }
                  #endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */

                    odt_entry = 0;

                  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                    if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                    {
                      no_of_odt_entries = xcp_struct[service_no].odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
                    }
                    else
                  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                    {
                      no_of_odt_entries = daq_list_ptr->no_of_odt_entries;
                    }

                   /*
                    * iterate over all ODT entries
                    * if current entry is not configured, continue with next ODT
                    */
                    while ((odt_entry < no_of_odt_entries) && (entry_ptr->size > 0) && (entry_ptr->size <= (xcp_max_dto[service_no] - dto_length)))
                    {
                    #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
                      #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                      /* check if address may be stimulated */
                      if ((DSXCP_memory_access_check(entry_ptr->address, entry_ptr->extension, entry_ptr->size, XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM) == DSXCP_NO_ERROR))
                      {
                        /* get address pointer */
                        address_ptr = DSXCP_get_address_pointer(entry_ptr->address, entry_ptr->extension);
                      #else /* #if (XCP_MEMORY_PROTECTION == XCP_DISABLED) */
                      {
                        /* get address pointer */
                        address_ptr = DSXCP_get_address_pointer(entry_ptr->address, entry_ptr->extension);
                      #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                    #else
                      {
                        address_ptr = entry_ptr->address_ptr;
                    #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */
                        /* check if current ODT entry represents a bit */
                        if (entry_ptr->bit_offset <= 0x07)
                        {
                          /* bit stimulation */
                          if (*data_ptr == 0)
                          {
                            /* clear bit */
                            *address_ptr &= ~((UInt8)0x1 << entry_ptr->bit_offset);
                          }
                          else
                          {
                            /* set bit */
                            *address_ptr |= (UInt8)0x1 << entry_ptr->bit_offset;
                          }

                          /* increase data pointer */
                          data_ptr++;
                        }
                        else
                        {
                          /* no bit stimulation, copy data byte-wise */
                          no_of_bytes = entry_ptr->size;
                          while (no_of_bytes)
                          {
                            *address_ptr++ = *data_ptr++;
                            no_of_bytes--;
                          }
                        }

                        dto_length += entry_ptr->size;
                        entry_ptr++;
                        odt_entry++;
                      }
                    }

                    /* set entry pointer to first entry of next ODT */
                    entry_ptr += (no_of_odt_entries - odt_entry);

                    pid++;

                    DSXCP_INT_RESTORE();
                  }
                }
              }
              else
            #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
              {
                /* data acquisition */
                /* check if DAQ list shall be processed in current cycle */
              #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
                daq_list_ptr->cycle--;
                if (daq_list_ptr->cycle == 0)
              #endif /* #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED) */
                {
                  UInt8         *data_ptr;
                  xcp_entry_t   *entry_ptr;
                  xcp_mta_ptr_t address_ptr;
                  UInt16        dto_length;
                  UInt8         odt;
                  UInt8         pid;

                #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
                  /* reset cycle to prescaler value */
                  daq_list_ptr->cycle = daq_list_ptr->prescaler;
                #endif /* #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED) */

                  /* set entry pointer to first ODT entry of DAQ list */
                  entry_ptr = &xcp_struct[service_no].odt_entry[daq_list_ptr->first_odt_entry];

                  pid = (UInt8)daq_list_ptr->first_odt;

                  /* iterate over all ODTs */
                  for (odt = 0; odt < daq_list_ptr->no_of_configured_odts; odt++)
                  {
                    DSXCP_INT_SAVE_AND_DISABLE();

                    /* try to get pointer to free buffer element of DAQ DTO buffer */
                  #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                    if (service_no == 0)
                    {
                      data_ptr = (UInt8 *)xcp_dto_buffer_0[0][daq_list_ptr->first_odt + odt].data;
                    }
                    #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
                    else
                    {
                      data_ptr = (UInt8 *)xcp_dto_buffer_1[0][daq_list_ptr->first_odt + odt].data;
                    }
                    #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */
                    if (daq_list_ptr->next_odt < daq_list_ptr->no_of_configured_odts)
                  #else
                    if ((data_ptr = (UInt8 *)xcp_daq_dto_ptr_get(service_no, daq)) == NULL)
                  #endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
                    {
                    #if (XCP_OVERLOAD_INDICATION == XCP_ENABLED)
                      #if (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)
                      daq_list_ptr->mode |= XCP_DAQ_LIST_MODE_OVERLOAD;
                      #else /* (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT) */
                      /* DAQ DTO buffer is full, increase overload counter */
                      xcp_struct[service_no].overload_count++;

                      /* check if condition for overload indication is true */
                      if (xcp_struct[service_no].overload_count == XCP_OVERLOAD_INDICATION_LIMIT)
                      {
                        /* yes, indicate overload condition */
                        xcp_struct[service_no].event_code = XCP_EV_DAQ_OVERLOAD;
                        xcp_struct[service_no].pending_status |= XCP_PENDING_EVENT;
                        xcp_struct[service_no].overload_count = 0;
                      }
                      #endif /* #if (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB) */
                    #endif /* #if (XCP_OVERLOAD_INDICATION == XCP_ENABLED) */
                    }
                    else
                    {
                      /* DAQ DTO buffer is not full, copy data */
                      UInt8 odt_entry;
                      UInt8 no_of_odt_entries;
                      UInt8 no_of_bytes;

                    #if (XCP_OVERLOAD_INDICATION == XCP_ENABLED)
                      #if (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)
                      /* in case of an overload set MSB of PID */
                      if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_OVERLOAD)
                      {
                        pid |= 0x80;
                        /* reset overload flag */
                        daq_list_ptr->mode &= ~XCP_DAQ_LIST_MODE_OVERLOAD;
                      }
                      #endif /* #if (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB) */
                    #endif /* #if (XCP_OVERLOAD_INDICATION == XCP_ENABLED) */

                    #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED)
                      /* check if PID OFF is enabled */
                      if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_PID_OFF)
                      {
                        /* no PID used */
                        dto_length = 0;
                      }
                      else
                    #endif /* #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED) */
                      {
                        /* copy PID, increase data pointer */
                        *data_ptr = pid;
                        data_ptr++;
                        dto_length = 1;
                      }

                    #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
                      /* check if timestamping is enabled */
                      if ((odt == 0) && (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_TIMESTAMP))
                      {
                        XCP_TIMESTAMP_TYPE timestamp;

                        timestamp = (XCP_TIMESTAMP_TYPE)DSXCP_get_timestamp();

                        /* copy timestamp behind PID of DAQ DTO */
                        ((UInt8 *)data_ptr)[0] = ((UInt8 *)&timestamp)[0];
                      #if (XCP_TIMESTAMP_SIZE == XCP_SIZE_WORD)
                        ((UInt8 *)data_ptr)[1] = ((UInt8 *)&timestamp)[1];
                      #endif
                      #if (XCP_TIMESTAMP_SIZE == XCP_SIZE_DWORD)
                        ((UInt8 *)data_ptr)[1] = ((UInt8 *)&timestamp)[1];
                        ((UInt8 *)data_ptr)[2] = ((UInt8 *)&timestamp)[2];
                        ((UInt8 *)data_ptr)[3] = ((UInt8 *)&timestamp)[3];
                      #endif
                        data_ptr += XCP_TIMESTAMP_SIZE;
                        dto_length += XCP_TIMESTAMP_SIZE;
                      }
                    #endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */

                      odt_entry = 0;

                    #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                      if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                      {
                        no_of_odt_entries = xcp_struct[service_no].odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
                      }
                      else
                    #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                      {
                        no_of_odt_entries = daq_list_ptr->no_of_odt_entries;
                      }

                      /*
                      * iterate over all ODT entries
                      * if current entry is not configured, continue with next ODT
                      */
                      while ((odt_entry < no_of_odt_entries) && (entry_ptr->size > 0) && (entry_ptr->size <= (xcp_max_dto[service_no] - dto_length)))
                      {
                      #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
                        /* get address pointer */
                        address_ptr = DSXCP_get_address_pointer(entry_ptr->address, entry_ptr->extension);
                      #else
                        address_ptr = entry_ptr->address_ptr;
                      #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */

                        /* check if current ODT entry represents a bit */
                        if (entry_ptr->bit_offset <= 0x07)
                        {
                          /* yes, copy bit value */
                          *data_ptr = (*address_ptr >> entry_ptr->bit_offset) & 0x1;

                          /* increase data pointer */
                          data_ptr++;
                        }
                        else
                        {
                          /* no bit access, copy data byte-wise */
                          no_of_bytes = entry_ptr->size;
                          while (no_of_bytes)
                          {
                            *data_ptr++ = *address_ptr++;
                            no_of_bytes--;
                          }
                        }
                        dto_length += entry_ptr->size;
                        entry_ptr++;
                        odt_entry++;
                      }

                      /* set entry pointer to first entry of next ODT */
                      entry_ptr += (no_of_odt_entries - odt_entry);

                      /* send DAQ DTO */
                    #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                      if (service_no == 0)
                      {
                        xcp_dto_buffer_0[0][daq_list_ptr->first_odt + odt].length = dto_length;
                      }
                      #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
                      else
                      {
                        xcp_dto_buffer_1[0][daq_list_ptr->first_odt + odt].length = dto_length;
                      }
                      #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */
                    #else
                      xcp_daq_dto_send(service_no, daq, dto_length);
                    #endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
                    }
                    pid++;

                    DSXCP_INT_RESTORE();
                  }
                #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                  daq_list_ptr->next_odt = 0;
                  if (daq_list_ptr->no_of_configured_odts > 0)
                  {
                    DSXCP_INT_SAVE_AND_DISABLE();

                    if (service_no == 0)
                    {
                      if (xcp_daq_dto_buffer_send(service_no, daq, (UInt16)xcp_dto_buffer_0[0][daq_list_ptr->first_odt].length, (UInt8 *)xcp_dto_buffer_0[0][daq_list_ptr->first_odt].data) == DSXCP_NO_ERROR)
                      {
                        daq_list_ptr->next_odt++;
                      }
                    }
                  #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
                    else
                    {
                      if (xcp_daq_dto_buffer_send(service_no, daq, (UInt16)xcp_dto_buffer_1[0][daq_list_ptr->first_odt].length, (UInt8 *)xcp_dto_buffer_1[0][daq_list_ptr->first_odt].data) == DSXCP_NO_ERROR)
                      {
                        daq_list_ptr->next_odt++;
                      }
                    }
                  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

                    DSXCP_INT_RESTORE();
                  }
                #endif
                }
              }
            }

            /* continue with next DAQ list */
            next_daq = daq_list_ptr->next_daq;
          }
          while (daq != next_daq);
          return_value |= DSXCP_DAQ_ACTIVE;
        }
      }
      else
      {
        return_value = DSXCP_DAQ_INACTIVE;
      }

    #if (XCP_NO_OF_SERVICE_INSTANCES == 1)
      global_return_value = return_value;
    #else /* (XCP_NO_OF_SERVICE_INSTANCES == 2) */
      global_return_value |= (return_value << ((service_no) << 3));
    #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 1) */
    }
  }
  return (global_return_value);
}
#endif /* (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


/******************************************************************************/
/* dSPACE XCP protocol layer internal functions                               */
/******************************************************************************/

#if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED))
/*******************************************************************************
*
*  FUNCTION
*    xcp_prot_send_callback
*
*
*  SYNTAX
*    xcp_prot_send_callback(unsigned int service_no)
*
*  DESCRIPTION
*    This function sends pending DAQ DTO packets stored in the DAQ DTO buffer
*    of the protocol layer.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_prot_send_callback(unsigned int service_no)
{
  if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_DAQ_RUNNING)
  {
    UInt16 daq;
    UInt16 abs_odt;
    xcp_daq_list_t *daq_list_ptr;

    for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
    {
      daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

      if ((daq_list_ptr->mode & XCP_DAQ_LIST_MODE_RUNNING) && (!(daq_list_ptr->mode & XCP_DAQ_LIST_MODE_DIRECTION)))
      {
        if (daq_list_ptr->next_odt < daq_list_ptr->no_of_configured_odts)
        {
        #if (XCP_TX_INT == XCP_DISABLED)
          DSXCP_INT_SAVE_AND_DISABLE();
        #endif /* #if (XCP_TX_INT == XCP_DISABLED) */

          abs_odt = daq_list_ptr->first_odt + daq_list_ptr->next_odt;

          if (service_no == 0)
          {
            if (xcp_daq_dto_buffer_send(service_no, daq, (UInt16)xcp_dto_buffer_0[0][abs_odt].length, (UInt8 *)xcp_dto_buffer_0[0][abs_odt].data) == DSXCP_NO_ERROR)
            {
              daq_list_ptr->next_odt++;
            }
          }
        #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
          else
          {
            if (xcp_daq_dto_buffer_send(service_no, daq, (UInt16)xcp_dto_buffer_1[0][abs_odt].length, (UInt8 *)xcp_dto_buffer_1[0][abs_odt].data) == DSXCP_NO_ERROR)
            {
              daq_list_ptr->next_odt++;
            }
          }
        #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

        #if (XCP_TX_INT == XCP_DISABLED)
          DSXCP_INT_RESTORE();
        #endif /* #if (XCP_TX_INT == XCP_DISABLED) */

          break;
        }
      }
    }
  }
}
#endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)) */


/*******************************************************************************
*
*  FUNCTION
*    xcp_pl_init
*
*
*  SYNTAX
*    xcp_pl_init(unsigned int service_no)
*
*  DESCRIPTION
*    This function initializes the protocol layer of the dSPACE XCP service.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_pl_init(unsigned int service_no)
{
  /* set session status to state "disconnected" */
  xcp_struct[service_no].session_status = XCP_SESSION_STATUS_DISCONNECTED;

  /* reset pending status */
  xcp_struct[service_no].pending_status = XCP_NO_PENDING;

#if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
  /* set protection status to default */
  xcp_struct[service_no].protection_status = XCP_RESOURCE_PROTECTION_DEFAULT;

  /* reset resource, which is requested to be unlocked */
  xcp_struct[service_no].resource_to_unlock = 0;

  /* reset seed flag */
  xcp_struct[service_no].seed_flag = XCP_SEED_INCOMPLETE;

  /* reset index of seed&key */
  xcp_struct[service_no].seed_key_index = 0;

  /* reset number of remaining bytes for seed&key */
  xcp_struct[service_no].no_of_seed_key_bytes_remaining = 0;
#endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */

#if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED))
  /* reset number of remaining bytes in slave block mode */
  xcp_struct[service_no].no_of_sbm_bytes_remaining = 0;
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)) */

#if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
  /* reset number of remaining bytes for uploading slave id or event channel name */
  xcp_struct[service_no].no_of_upload_info_bytes_remaining = 0;
#endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) && (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */

#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_MASTER_BLOCK_MODE == XCP_ENABLED))
  /* reset number of remaining bytes in master block mode */
  xcp_struct[service_no].no_of_mbm_bytes_remaining = 0;
#endif /* #if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_MASTER_BLOCK_MODE == XCP_ENABLED)) */

#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
  /* reset non-volatile memory programming status */
  xcp_struct[service_no].pgm_status = XCP_PGM_STATUS_INACTIVE;

#if (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED)
  /* reset number of remaining bytes in master block mode PGM */
  xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining = 0;
#endif /* #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED) */
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_cmd_proc
*
*
*  SYNTAX
*    void xcp_cmd_proc(unsigned int service_no, UInt8 *cmd_cto)
*
*  DESCRIPTION
*    This function is the command processor.
*    It processes the given CMD CTO packet and composes an appropriate RES CTO
*    packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    cmd_cto:    pointer to CMD CTO
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_cmd_proc(unsigned int service_no, UInt8 *cmd_cto)
{
  xcp_cmd_cto_t *cmd_cto_ptr;
  xcp_res_cto_t *res_cto_ptr;
  UInt8         res_cto_length;

  res_cto_length = 0; /* set default length of RES CTO packet to 0 */

  cmd_cto_ptr = (xcp_cmd_cto_t *)cmd_cto;

  /* try to get pointer to free buffer element of RES CTO buffer */
  if ((res_cto_ptr = (xcp_res_cto_t *)xcp_res_cto_ptr_get(service_no)) != NULL)
  {
    /* set default PID of RES CTO packet to 0xFF (positive response) */
    res_cto_ptr->pid = XCP_PID_RES;

    /*
     * The command CONNECT (and furthermore some transport layer commands e.g.
     * GET_SLAVE_ID with XCP on CAN) may be executed either in connected or
     * disconnected state.
     */
/**** CONNECT *****************************************************************/
    if (cmd_cto_ptr->pid == XCP_CMD_CODE_CONNECT)
    {
    #if (XCP_DEBUG == XCP_ENABLED)
      msg_info_printf(0, 0, "command received: CONNECT(%i)",
                      cmd_cto_ptr->connect.mode);
    #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

      {
        UInt8 mode;

        mode = cmd_cto_ptr->connect.mode;

      #if (XCP_ERROR_CHECK == XCP_ENABLED)
        if (mode > 1)
        {
          /* send error packet */
          res_cto_ptr->pid        = XCP_PID_ERR;
          res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
          res_cto_length = 2;
        }
        else
      #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
        {
          /* distinguish mode of CONNECT */
          if (mode == 1)
          {
            /* mode is "user defined" */
            /* go to a special user defined mode */
            DSXCP_user_mode();
          }

          /* set session status to state "connected" */
          xcp_struct[service_no].session_status |= XCP_SESSION_STATUS_CONNECTED;

          /* send command response packet */
          res_cto_ptr->connect.resource          = xcp_resource[service_no];
          res_cto_ptr->connect.comm_mode_basic   = XCP_COMM_MODE_BASIC;
          res_cto_ptr->connect.max_cto           = xcp_max_cto[service_no];
          res_cto_ptr->connect.max_dto           = xcp_max_dto[service_no];
          res_cto_ptr->connect.protocol_version  = XCP_PROTOCOL_LAYER_VERSION;
          res_cto_ptr->connect.transport_version = xcp_tl_version[service_no];
          res_cto_length = 8;
        }
      }
    }

/**** TRANSPORT_LAYER_CMD *****************************************************/
  #if (XCP_CMD_TRANSPORT_LAYER_CMD == XCP_ENABLED)
    else if (cmd_cto_ptr->pid == XCP_CMD_CODE_TRANSPORT_LAYER_CMD)
    {
    #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
      res_cto_length = xcp_tl_cmd_proc(service_no, (UInt8 *)cmd_cto_ptr, (UInt8 *)res_cto_ptr, xcp_struct[service_no].session_status, xcp_struct[service_no].max_daq);
    #else /* (XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED) */
      res_cto_length = xcp_tl_cmd_proc(service_no, (UInt8 *)cmd_cto_ptr, (UInt8 *)res_cto_ptr, xcp_struct[service_no].session_status, 0);
    #endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */
    }
  #endif /* #if (XCP_CMD_TRANSPORT_LAYER_CMD == XCP_ENABLED) */
    else
    {
      /* the following commands may be executed in connected state only */
      if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_CONNECTED)
      {
      #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
        /* check if current command belongs to a protected resource */
        unsigned int protected_flag;

        protected_flag = 0; /* default: resource is unprotected */

        if (xcp_struct[service_no].protection_status == 0)
        {
          protected_flag = 0;
        }
      #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG) && (XCP_RESOURCE_PROTECTION_CAL_PAG == XCP_ENABLED))
        else if ((cmd_cto_ptr->pid <= XCP_CMD_CODE_DOWNLOAD) && (cmd_cto_ptr->pid >= XCP_CMD_CODE_COPY_CAL_PAGE))
        {
          if (xcp_struct[service_no].protection_status & XCP_RESOURCE_CAL_PAG)
          {
            protected_flag = 1;
          }
        }
      #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG) && (XCP_RESOURCE_PROTECTION_CAL_PAG == XCP_ENABLED)) */
      #if ((XCP_RESOURCE_SUPPORTED_DAQ) && (XCP_RESOURCE_PROTECTION_DAQ == XCP_ENABLED))
        else if ((cmd_cto_ptr->pid <= XCP_CMD_CODE_CLEAR_DAQ_LIST) && (cmd_cto_ptr->pid >= XCP_CMD_CODE_ALLOC_ODT_ENTRY))
        {
          if (xcp_struct[service_no].protection_status & XCP_RESOURCE_DAQ)
          {
            protected_flag = 1;
          }
        }
      #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ) && (XCP_RESOURCE_PROTECTION_DAQ == XCP_ENABLED)) */
      #if ((XCP_RESOURCE_SUPPORTED_PGM) && (XCP_RESOURCE_PROTECTION_PGM == XCP_ENABLED))
        else if ((cmd_cto_ptr->pid <= XCP_CMD_CODE_PROGRAM_START) && (cmd_cto_ptr->pid >= XCP_CMD_CODE_PROGRAM_VERIFY))
        {
          if (xcp_struct[service_no].protection_status & XCP_RESOURCE_PGM)
          {
            protected_flag = 1;
          }
        }
      #endif /* #if ((XCP_RESOURCE_SUPPORTED_PGM) && (XCP_RESOURCE_PROTECTION_PGM == XCP_ENABLED)) */

        if (protected_flag == 1)
        {
          /* send error packet */
          res_cto_ptr->pid        = XCP_PID_ERR;
          res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
          res_cto_length = 2;
        }
        else /* current command is not protected */
      #endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */
        {
          switch (cmd_cto_ptr->pid)
          {
/**** DISCONNECT **************************************************************/
            case XCP_CMD_CODE_DISCONNECT:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: DISCONNECT()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* re-initialize the protocol layer (without DAQ resource) */
              xcp_pl_init(service_no);

              /* re-initialize the transport layer */
              xcp_tl_init(service_no);

            #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
              /* re-initialize the DAQ resource */
              xcp_daq_init(service_no);
            #endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */

              /* send command response packet */
              res_cto_length = 1;
              break;

/**** GET_STATUS **************************************************************/
            case XCP_CMD_CODE_GET_STATUS:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_STATUS()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_status.session_status    = xcp_struct[service_no].session_status;
            #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
              res_cto_ptr->get_status.protection_status = xcp_struct[service_no].protection_status;
            #else /* (XCP_RESOURCE_PROTECTION == XCP_DISABLED) */
              res_cto_ptr->get_status.protection_status = 0;
            #endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */
            #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED))
              res_cto_ptr->get_status.session_id        = xcp_struct[service_no].session_id;
            #else /* ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED) || (XCP_RESUME_MODE == XCP_DISABLED)) */
              res_cto_ptr->get_status.session_id        = 0;
            #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED)) */
              res_cto_length = 6;
              break;

/**** SYNCH *******************************************************************/
            case XCP_CMD_CODE_SYNCH:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SYNCH()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send error packet */
              res_cto_ptr->pid        = XCP_PID_ERR;
              res_cto_ptr->error.code = XCP_ERR_CMD_SYNCH;
              res_cto_length = 2;
              break;

/**** GET_COMM_MODE_INFO ******************************************************/
          #if (XCP_CMD_GET_COMM_MODE_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_COMM_MODE_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_COMM_MODE_INFO()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_comm_mode_info.optional       = XCP_COMM_MODE_OPTIONAL;
              res_cto_ptr->get_comm_mode_info.max_bs         = XCP_MAX_BS;
              res_cto_ptr->get_comm_mode_info.min_st         = XCP_MIN_ST;
              res_cto_ptr->get_comm_mode_info.queue_size     = 0; /* interleaved mode is not implemented */
              res_cto_ptr->get_comm_mode_info.driver_version = XCP_DRIVER_VERSION;
              res_cto_length = 8;
              break;
          #endif /* #if (XCP_CMD_GET_COMM_MODE_INFO == XCP_ENABLED) */

/**** GET_ID ******************************************************************/
          #if (XCP_CMD_GET_ID == XCP_ENABLED)
            case XCP_CMD_CODE_GET_ID:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_ID(%i)",
                              cmd_cto_ptr->get_id.type);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt32 length;

              #if (XCP_ID_TYPE_TEXT == XCP_ENABLED)
                if (cmd_cto_ptr->get_id.type == XCP_GET_ID_TYPE_ASCII)
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)XCP_ID_TYPE_TEXT_DATA;
                  length = XCP_ID_TYPE_TEXT_LENGTH;
                }
                else
              #endif /* #if (XCP_ID_TYPE_TEXT == XCP_ENABLED) */
              #if (XCP_ID_TYPE_A2L_NAME == XCP_ENABLED)
                if (cmd_cto_ptr->get_id.type == XCP_GET_ID_TYPE_A2L_NAME)
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)XCP_ID_TYPE_A2L_NAME_DATA;
                  length = XCP_ID_TYPE_A2L_NAME_LENGTH;
                }
                else
              #endif /* #if (XCP_ID_TYPE_A2L_NAME == XCP_ENABLED) */
              #if (XCP_ID_TYPE_A2L_PATH == XCP_ENABLED)
                if (cmd_cto_ptr->get_id.type == XCP_GET_ID_TYPE_A2L_PATH)
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)XCP_ID_TYPE_A2L_PATH_DATA;
                  length = XCP_ID_TYPE_A2L_PATH_LENGTH;
                }
                else
              #endif /* #if (XCP_ID_TYPE_A2L_PATH == XCP_ENABLED) */
              #if (XCP_ID_TYPE_A2L_URL == XCP_ENABLED)
                if (cmd_cto_ptr->get_id.type == XCP_GET_ID_TYPE_A2L_URL)
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)XCP_ID_TYPE_A2L_URL_DATA;
                  length = XCP_ID_TYPE_A2L_URL_LENGTH;
                }
                else
              #endif /* #if (XCP_ID_TYPE_A2L_URL == XCP_ENABLED) */
              #if (XCP_ID_TYPE_A2L_UPLOAD == XCP_ENABLED)
                if (cmd_cto_ptr->get_id.type == XCP_GET_ID_TYPE_A2L_UPLOAD)
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)XCP_ID_TYPE_A2L_UPLOAD_DATA;
                  length = XCP_ID_TYPE_A2L_UPLOAD_LENGTH;
                }
                else
              #endif /* #if (XCP_ID_TYPE_A2L_UPLOAD == XCP_ENABLED) */
                {
                  length = 0;
                }

                if (length > 0)
                {
                  xcp_struct[service_no].pending_status |= XCP_PENDING_UPLOAD_INFO;
                  xcp_struct[service_no].no_of_upload_info_bytes_remaining = length;
                }

                /* send command response packet */
                res_cto_ptr->get_id.mode   = 0; /* mode is always 0 */
                res_cto_ptr->get_id.length = length;
                res_cto_length = 8;
              }
              break;
          #endif /* #if (XCP_CMD_GET_ID == XCP_ENABLED) */

/**** SET_REQUEST *************************************************************/
          #if (XCP_CMD_SET_REQUEST == XCP_ENABLED)
            case XCP_CMD_CODE_SET_REQUEST:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_REQUEST(%i, %i)",
                              cmd_cto_ptr->set_request.mode,
                              cmd_cto_ptr->set_request.id);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 mode;

                mode = cmd_cto_ptr->set_request.mode;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
              #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED) || ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_DISABLED)))
                if (mode & (XCP_REQUEST_CLEAR_DAQ | XCP_REQUEST_STORE_DAQ | XCP_REQUEST_STORE_DAQ_NO_RESUME))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED) || ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_DISABLED))) */
              #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_DISABLED) || ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_DISABLED)))
                if (mode & XCP_REQUEST_STORE_CAL)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_DISABLED) || ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_DISABLED))) */
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_struct[service_no].session_status |= (mode & ((XCP_REQUEST_STORE_CAL | XCP_REQUEST_STORE_DAQ | XCP_REQUEST_STORE_DAQ_NO_RESUME | XCP_REQUEST_CLEAR_DAQ)));
                #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED))
                  xcp_struct[service_no].session_id = cmd_cto_ptr->set_request.id;
                #endif /* ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED)) */

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_SET_REQUEST == XCP_ENABLED) */

/**** GET_SEED ****************************************************************/
          #if (XCP_CMD_GET_SEED == XCP_ENABLED)
            case XCP_CMD_CODE_GET_SEED:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_SEED(%i, %i)",
                              cmd_cto_ptr->get_seed.mode,
                              cmd_cto_ptr->get_seed.resource);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 mode;

                mode = cmd_cto_ptr->get_seed.mode;

                /* check parameters */
              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (mode > 1)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt8 resource;
                  UInt8 length;

                  resource = cmd_cto_ptr->get_seed.resource & (XCP_RESOURCE_CAL_PAG | XCP_RESOURCE_DAQ | XCP_RESOURCE_STIM | XCP_RESOURCE_PGM);

                  if ((mode == 0) && ((resource != XCP_RESOURCE_CAL_PAG) &&
                                      (resource != XCP_RESOURCE_DAQ)     &&
                                      (resource != XCP_RESOURCE_STIM)    &&
                                      (resource != XCP_RESOURCE_PGM)))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                  }
                  else if ((mode == 1) && ((xcp_struct[service_no].seed_flag == XCP_SEED_COMPLETE) || (xcp_struct[service_no].seed_key_index == 0)))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                    res_cto_length = 2;
                  }
                  else /* parameters are correct */
                  {
                    UInt8 i;

                    if (mode == 0)
                    {
                      /* get seed for current resource */
                      length = DSXCP_get_seed(xcp_struct[service_no].seed, resource);

                      xcp_struct[service_no].resource_to_unlock = resource;
                      xcp_struct[service_no].seed_flag          = XCP_SEED_INCOMPLETE;
                      xcp_struct[service_no].seed_key_index     = 0;
                    }
                    else /* mode == 1 */
                    {
                      length = xcp_struct[service_no].no_of_seed_key_bytes_remaining;
                    }

                    i = 0;

                    /* copy seed to RES CTO */
                    while ((i < length) && (i < (xcp_max_cto[service_no] - 2)))
                    {
                      res_cto_ptr->get_seed.seed[i] = xcp_struct[service_no].seed[xcp_struct[service_no].seed_key_index + i];
                      i++;
                    }

                    xcp_struct[service_no].no_of_seed_key_bytes_remaining = length - i;

                    if (xcp_struct[service_no].no_of_seed_key_bytes_remaining == 0)
                    {
                      xcp_struct[service_no].seed_flag = XCP_SEED_COMPLETE;
                    }
                    else
                    {
                      xcp_struct[service_no].seed_key_index += i;
                    }

                    /* send command response packet */
                    res_cto_ptr->get_seed.length = length;
                    res_cto_length = i + 2;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_SEED == XCP_ENABLED) */

/**** UNLOCK ******************************************************************/
          #if (XCP_CMD_UNLOCK == XCP_ENABLED)
            case XCP_CMD_CODE_UNLOCK:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: UNLOCK(%i, %i)",
                              cmd_cto_ptr->unlock.length,
                              cmd_cto_ptr->unlock.key);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 length;

                length = cmd_cto_ptr->unlock.length;

                /* check parameters */
                if ((length == 0) || (length > XCP_MAX_KEY_SIZE))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else if ((xcp_struct[service_no].seed_flag == XCP_SEED_INCOMPLETE) ||
                         ((xcp_struct[service_no].no_of_seed_key_bytes_remaining > 0) &&
                          (xcp_struct[service_no].no_of_seed_key_bytes_remaining != length)))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                  res_cto_length = 2;
                }
                else /* parameters are correct */
                {
                  UInt8 i;

                  /* reset Seed&Key index in case of a new unlock sequence */
                  if (xcp_struct[service_no].no_of_seed_key_bytes_remaining == 0)
                  {
                    xcp_struct[service_no].seed_key_index = 0;
                  }

                  i = 0;

                  /* copy key from CMD CTO */
                  while ((i < length) && (i < (xcp_max_cto[service_no] - 2)))
                  {
                    xcp_struct[service_no].key[xcp_struct[service_no].seed_key_index + i] = cmd_cto_ptr->unlock.key[i];
                    i++;
                  }

                  xcp_struct[service_no].no_of_seed_key_bytes_remaining = length - i;
                  xcp_struct[service_no].seed_key_index += i;

                  /* check if unlock sequence has finished */
                  if (xcp_struct[service_no].no_of_seed_key_bytes_remaining == 0)
                  {
                    /* check if key is correct */
                    if (DSXCP_unlock(xcp_struct[service_no].seed, xcp_struct[service_no].key, xcp_struct[service_no].resource_to_unlock) == DSXCP_NO_ERROR)
                    {
                      /* key is correct, clear protected flag of resource */
                      xcp_struct[service_no].protection_status &= ~xcp_struct[service_no].resource_to_unlock;

                      /* send command response packet */
                      res_cto_ptr->unlock.protection_status = xcp_struct[service_no].protection_status;
                      res_cto_length = 2;
                    }
                    else /* key is not correct, go to disconnected state */
                    {
                      /* re-initialize the protocol layer (without DAQ resource) */
                      xcp_pl_init(service_no);

                      /* re-initialize the transport layer */
                      xcp_tl_init(service_no);

                    #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
                      /* re-initialize the DAQ resource */
                      xcp_daq_init(service_no);
                    #endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */

                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
                      res_cto_length = 2;
                    }
                  }
                  else
                  {
                    /* send command response packet */
                    res_cto_ptr->unlock.protection_status = xcp_struct[service_no].protection_status;
                    res_cto_length = 2;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_UNLOCK == XCP_ENABLED) */

/**** SET_MTA *****************************************************************/
          #if (XCP_CMD_SET_MTA == XCP_ENABLED)
            case XCP_CMD_CODE_SET_MTA:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_MTA(%i, 0x%x)",
                              cmd_cto_ptr->set_mta.extension,
                              cmd_cto_ptr->set_mta.address);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* set MTA */
              xcp_set_mta(service_no, cmd_cto_ptr->set_mta.address, cmd_cto_ptr->set_mta.extension);

#if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
              /* reset pending upload info flag */
              xcp_struct[service_no].pending_status &= ~XCP_PENDING_UPLOAD_INFO;
#endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */

              /* send command response packet */
              res_cto_length = 1;
              break;
          #endif /* #if (XCP_CMD_SET_MTA == XCP_ENABLED) */

/**** UPLOAD ******************************************************************/
          #if (XCP_CMD_UPLOAD == XCP_ENABLED)
            case XCP_CMD_CODE_UPLOAD:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: UPLOAD(%i)",
                              cmd_cto_ptr->upload.no_of_elements);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->upload.no_of_elements;

              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
              #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
                /* check address only if no upload of service information is pending */
                if (!(xcp_struct[service_no].pending_status & XCP_PENDING_UPLOAD_INFO) &&
                     (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_READ) == DSXCP_MEMORY_ACCESS_DENIED))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #else /* ((XCP_CMD_GET_ID == XCP_DISABLED) && (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_DISABLED)) */
                /* check address */
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_READ) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                {
                #if (XCP_ERROR_CHECK == XCP_ENABLED)
                #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
                  /* check number of elements if upload of service information is pending */
                  if ((xcp_struct[service_no].pending_status & XCP_PENDING_UPLOAD_INFO) && (no_of_elements > xcp_struct[service_no].no_of_upload_info_bytes_remaining))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */
                #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                  {
                    if (no_of_elements > (xcp_max_cto[service_no] - 1))
                    {
                      /* negative response, if upload data doesn't fit into RES packet when SBM is disabled */
                    #if (XCP_SLAVE_BLOCK_MODE == XCP_DISABLED)
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                      res_cto_length = 2;
                    #else /* (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED) */
                      /* upload data from MTA */
                      xcp_upload_from_mta(service_no, res_cto_ptr->upload.data, xcp_max_cto[service_no] - 1);
                      xcp_struct[service_no].no_of_sbm_bytes_remaining = no_of_elements - (xcp_max_cto[service_no] - 1);

                    #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
                      if (xcp_struct[service_no].pending_status & XCP_PENDING_UPLOAD_INFO)
                      {
                        xcp_struct[service_no].no_of_upload_info_bytes_remaining -= (xcp_max_cto[service_no] - 1);

                        if (xcp_struct[service_no].no_of_upload_info_bytes_remaining == 0)
                        {
                          xcp_struct[service_no].pending_status &= ~XCP_PENDING_UPLOAD_INFO;
                        }
                      }
                    #endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */

                      /* send command response packet */
                      res_cto_length = xcp_max_cto[service_no];
                    #endif /* #if (XCP_SLAVE_BLOCK_MODE == XCP_DISABLED) */
                    }
                    else
                    {
                      /* upload data from MTA */
                      xcp_upload_from_mta(service_no, res_cto_ptr->upload.data, no_of_elements);

                    #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
                      if (xcp_struct[service_no].pending_status & XCP_PENDING_UPLOAD_INFO)
                      {
                        xcp_struct[service_no].no_of_upload_info_bytes_remaining -= no_of_elements;

                        if (xcp_struct[service_no].no_of_upload_info_bytes_remaining == 0)
                        {
                          xcp_struct[service_no].pending_status &= ~XCP_PENDING_UPLOAD_INFO;
                        }
                      }
                    #endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */

                      /* send command response packet */
                      res_cto_length = no_of_elements + 1;
                    }
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_UPLOAD == XCP_ENABLED) */

/**** SHORT_UPLOAD ************************************************************/
          #if (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED)
            case XCP_CMD_CODE_SHORT_UPLOAD:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SHORT_UPLOAD(%i, %i, %x)",
                              cmd_cto_ptr->short_upload.no_of_elements,
                              cmd_cto_ptr->short_upload.extension,
                              cmd_cto_ptr->short_upload.address);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->short_upload.no_of_elements;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                /* negative response, if upload data doesn't fit into RES packet */
                if (no_of_elements > (xcp_max_cto[service_no] - 1))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt32 address;
                  UInt8  extension;

                  address   = cmd_cto_ptr->short_upload.address;
                  extension = cmd_cto_ptr->short_upload.extension;

                #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                  if (DSXCP_memory_access_check(address, extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_READ) == DSXCP_MEMORY_ACCESS_DENIED)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                  {
                    /* set MTA */
                    xcp_set_mta(service_no, address, extension);

                    /* upload data from MTA */
                    xcp_upload_from_mta(service_no, res_cto_ptr->short_upload.data, no_of_elements);

                    /* send command response packet */
                    res_cto_length = no_of_elements + 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED) */

/**** BUILD_CHECKSUM **********************************************************/
          #if (XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED)
            case XCP_CMD_CODE_BUILD_CHECKSUM:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: BUILD_CHECKSUM(%i)",
                              cmd_cto_ptr->build_checksum.block_size);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt32 block_size;

                block_size = cmd_cto_ptr->build_checksum.block_size;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_22) || (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_24)
                if (block_size % 2)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
                #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_44)
                if (block_size % 4)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
                #else
                /* no error check for other checksum types */
                #endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_22) || (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_24) */
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  if (block_size > XCP_MAX_CHECKSUM_BLOCKSIZE)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    *((UInt32 *)&res_cto_ptr->error.info[2]) = XCP_MAX_CHECKSUM_BLOCKSIZE;
                    res_cto_length = 8;
                  }
                  else
                  {
                  #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                    if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, block_size, XCP_MEMORY_ACCESS_TYPE_READ) == DSXCP_MEMORY_ACCESS_DENIED)
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                      res_cto_length = 2;
                    }
                    else
                  #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                    {
                      /* send command response packet */
                    #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_USER_DEFINED)
                      res_cto_ptr->build_checksum.type     = XCP_USER_DEFINED;
                      res_cto_ptr->build_checksum.checksum = DSXCP_build_checksum(xcp_struct[service_no].mta_ptr, block_size);
                    #else /* (XCP_CHECKSUM_TYPE != XCP_CHECKSUM_TYPE_USER_DEFINED) */
                      #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_11)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_11;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_12)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_12;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_14)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_14;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_22)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_22;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_24)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_24;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_44)
                      res_cto_ptr->build_checksum.type     = XCP_ADD_44;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16)
                      res_cto_ptr->build_checksum.type     = XCP_CRC_16;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16_CCITT)
                      res_cto_ptr->build_checksum.type     = XCP_CRC_16_CCITT;
                      #elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_32)
                      res_cto_ptr->build_checksum.type     = XCP_CRC_32;
                      #endif
                      res_cto_ptr->build_checksum.checksum = xcp_build_checksum(xcp_struct[service_no].mta_ptr, block_size);
                    #endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_USER_DEFINED) */
                      res_cto_length = 8;

                      /* post-increment MTA */
                      xcp_struct[service_no].mta_ptr += block_size;
                    #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                      xcp_struct[service_no].mta_info.address += block_size;
                    #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                    }
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED) */

/**** TRANSPORT_LAYER_CMD *****************************************************/
          #if (XCP_CMD_TRANSPORT_LAYER_CMD == XCP_ENABLED)
            case XCP_CMD_CODE_TRANSPORT_LAYER_CMD:
            #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
              res_cto_length = xcp_tl_cmd_proc(service_no, (UInt8 *)cmd_cto_ptr, (UInt8 *)res_cto_ptr, xcp_struct[service_no].session_status, xcp_struct[service_no].max_daq);
            #else /* (XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED) */
              res_cto_length = xcp_tl_cmd_proc(service_no, (UInt8 *)cmd_cto_ptr, (UInt8 *)res_cto_ptr, xcp_struct[service_no].session_status, 0);
            #endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */
              break;
          #endif /* #if (XCP_CMD_TRANSPORT_LAYER_CMD == XCP_ENABLED) */

/**** USER_CMD ****************************************************************/
          #if (XCP_CMD_USER_CMD == XCP_ENABLED)
            case XCP_CMD_CODE_USER_CMD:
              /*
               * if bypassing is enabled, some user commands are used to configure features
               * required for bypassing.
               */
              switch (cmd_cto_ptr->user_cmd.sub_pid)
              {
/**** GET_BYP_INFO ************************************************************/
              #if (XCP_CMD_GET_BYP_INFO == XCP_ENABLED)
                case XCP_CMD_CODE_GET_BYP_INFO:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: GET_BYP_INFO()");
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                  /* send command response packet */
                  res_cto_ptr->get_byp_info.properties = XCP_BYP_PROPERTIES;
                  res_cto_ptr->get_byp_info.d = 'D';
                  res_cto_ptr->get_byp_info.s = 'S';
                  res_cto_ptr->get_byp_info.x = 'X';
                  res_cto_ptr->get_byp_info.c = 'C';
                  res_cto_ptr->get_byp_info.p = 'P';
                  res_cto_length = 7;
                  break;
              #endif /* #if (XCP_CMD_GET_BYP_INFO == XCP_ENABLED) */

/**** SET_DAQ_LIST_BYP_MODE ***************************************************/
              #if (XCP_CMD_SET_DAQ_LIST_BYP_MODE == XCP_ENABLED)
                case XCP_CMD_CODE_SET_DAQ_LIST_BYP_MODE:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: SET_DAQ_LIST_BYP_MODE(%i, 0x%x, %i, 0x%x, %i)",
                                  cmd_cto_ptr->set_daq_list_byp_mode.daq,
                                  cmd_cto_ptr->set_daq_list_byp_mode.mode,
                                  cmd_cto_ptr->set_daq_list_byp_mode.timeout_cycle,
                                  cmd_cto_ptr->set_daq_list_byp_mode.timeout_unit,
                                  cmd_cto_ptr->set_daq_list_byp_mode.failure_limit);
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                  {
                    UInt16 daq;
                    UInt8  mode;

                    daq  = cmd_cto_ptr->set_daq_list_byp_mode.daq;
                    mode = cmd_cto_ptr->set_daq_list_byp_mode.mode;

                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    if ((daq >= xcp_struct[service_no].max_daq)         ||
                  #if (XCP_DOUBLE_BUFFER == XCP_DISABLED)
                        (mode & (XCP_DAQ_LIST_BYP_MODE_DOUBLE_BUFFER | XCP_DAQ_LIST_BYP_MODE_FAILSAFE_BUFFER | XCP_DAQ_LIST_BYP_MODE_FAILURE_CHECKING)) ||
                  #endif /* #if (XCP_DOUBLE_BUFFER == XCP_DISABLED) */
                  #if (XCP_FAILSAFE_BUFFER == XCP_DISABLED)
                        (mode & XCP_DAQ_LIST_BYP_MODE_FAILSAFE_BUFFER)  ||
                  #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_DISABLED) */
                  #if (XCP_FAILURE_CHECKING == XCP_DISABLED)
                        (mode & XCP_DAQ_LIST_BYP_MODE_FAILURE_CHECKING) ||
                  #endif /* #if (XCP_FAILURE_CHECKING == XCP_DISABLED) */
                  #if (XCP_CONSISTENCY_WAIT == XCP_DISABLED)
                        (mode & XCP_DAQ_LIST_BYP_MODE_CONSISTENCY_WAIT) ||
                  #endif /* #if (XCP_CONSISTENCY_WAIT == XCP_DISABLED) */
                        (0))
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                      res_cto_length = 2;
                    }
                    else
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                    {
                      xcp_struct[service_no].daq_list[daq].byp_mode      = mode;
                      xcp_struct[service_no].daq_list[daq].failure_limit = cmd_cto_ptr->set_daq_list_byp_mode.failure_limit;

                    #if (XCP_CONSISTENCY_WAIT == XCP_ENABLED)
                      if (mode & XCP_DAQ_LIST_BYP_MODE_CONSISTENCY_WAIT)
                      {
                        UInt8  timeout_cycle;
                        UInt8  timeout_unit;
                        UInt32 pot;

                        timeout_cycle = cmd_cto_ptr->set_daq_list_byp_mode.timeout_cycle;
                        timeout_unit  = cmd_cto_ptr->set_daq_list_byp_mode.timeout_unit;

                        /* calculate timeout ticks */
                        if ((timeout_unit < XCP_TIMESTAMP_UNIT) ||
                           ((timeout_unit == XCP_TIMESTAMP_UNIT) && (timeout_cycle < XCP_TIMESTAMP_TICKS)))
                        {
                          /* send error packet */
                          res_cto_ptr->pid        = XCP_PID_ERR;
                          res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                          res_cto_length = 2;
                        }
                        else
                        {
                          UInt8 i;

                          pot = 1;
                          for (i = 0; i < (timeout_unit - XCP_TIMESTAMP_UNIT); i++)
                          {
                            pot *= 10;
                          }

                          xcp_struct[service_no].daq_list[daq].timeout_ticks = (pot * timeout_cycle) / XCP_TIMESTAMP_TICKS;
                          xcp_struct[service_no].daq_list[daq].timeout_cycle = timeout_cycle;
                          xcp_struct[service_no].daq_list[daq].timeout_unit  = timeout_unit;

                          /* send command response packet */
                          res_cto_length = 1;
                        }
                      }
                      else
                    #endif /* #if (XCP_CONSISTENCY_WAIT == XCP_ENABLED) */
                      {
                        /* send command response packet */
                        res_cto_length = 1;
                      }
                    }
                  }
                  break;
              #endif /* #if (XCP_CMD_SET_DAQ_LIST_BYP_MODE == XCP_ENABLED) */

/**** GET_DAQ_LIST_BYP_MODE ***************************************************/
              #if (XCP_CMD_GET_DAQ_LIST_BYP_MODE == XCP_ENABLED)
                case XCP_CMD_CODE_GET_DAQ_LIST_BYP_MODE:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: GET_DAQ_LIST_BYP_MODE(%i)",
                                  cmd_cto_ptr->get_daq_list_byp_mode.daq);
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                  {
                    UInt16 daq;

                    daq = cmd_cto_ptr->get_daq_list_byp_mode.daq;

                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    if (daq >= xcp_struct[service_no].max_daq)
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                      res_cto_length = 2;
                    }
                    else
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                    {
                      /* send command response packet */
                      res_cto_ptr->get_daq_list_byp_mode.mode          = xcp_struct[service_no].daq_list[daq].byp_mode;
                      res_cto_ptr->get_daq_list_byp_mode.timeout_cycle = xcp_struct[service_no].daq_list[daq].timeout_cycle;
                      res_cto_ptr->get_daq_list_byp_mode.timeout_unit  = xcp_struct[service_no].daq_list[daq].timeout_unit;
                      res_cto_ptr->get_daq_list_byp_mode.failure_limit = xcp_struct[service_no].daq_list[daq].failure_limit;
                      res_cto_length = 5;
                    }
                  }
                  break;
              #endif /* #if (XCP_CMD_GET_DAQ_LIST_BYP_MODE == XCP_ENABLED) */

/**** SET_FAILSAFE_DATA_PTR ***************************************************/
              #if (XCP_CMD_SET_FAILSAFE_DATA_PTR == XCP_ENABLED)
                case XCP_CMD_CODE_SET_FAILSAFE_DATA_PTR:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: SET_FAILSAFE_DATA_PTR(%i, %i, %i)",
                                  cmd_cto_ptr->set_failsafe_data_ptr.daq,
                                  cmd_cto_ptr->set_failsafe_data_ptr.odt,
                                  cmd_cto_ptr->set_failsafe_data_ptr.odt_entry);
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                  {
                    UInt16 daq;
                    UInt8  odt;
                    UInt8  odt_entry;

                    daq       = cmd_cto_ptr->set_failsafe_data_ptr.daq;
                    odt       = cmd_cto_ptr->set_failsafe_data_ptr.odt;
                    odt_entry = cmd_cto_ptr->set_failsafe_data_ptr.odt_entry;

                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    if (daq >= xcp_struct[service_no].max_daq)
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                      res_cto_length = 2;
                    }
                    else
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                    {
                      UInt16 abs_odt;
                      UInt8  no_of_odts;
                      UInt8  no_of_odt_entries;

                      abs_odt    = xcp_struct[service_no].daq_list[daq].first_odt + odt;
                      no_of_odts = xcp_struct[service_no].daq_list[daq].no_of_odts;

    #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                      if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                      {
                        no_of_odt_entries = xcp_struct[service_no].odt[abs_odt].no_of_odt_entries;
                      }
                      else
    #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                      {
                        no_of_odt_entries = xcp_struct[service_no].daq_list[daq].no_of_odt_entries;
                      }

                    #if (XCP_ERROR_CHECK == XCP_ENABLED)
                      if ((odt >= no_of_odts) || (odt_entry >= no_of_odt_entries))
                      {
                        /* send error packet */
                        res_cto_ptr->pid        = XCP_PID_ERR;
                        res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                        res_cto_length = 2;
                      }
                      else
                    #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                      {
                        UInt16 abs_odt_entry;

                      #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                        if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                        {
                          abs_odt_entry = xcp_struct[service_no].odt[abs_odt].first_odt_entry + odt_entry;
                        }
                        else
                      #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                        {
                          abs_odt_entry = xcp_struct[service_no].daq_list[daq].first_odt_entry + (no_of_odt_entries * odt) + odt_entry;
                        }

                        /* set DAQ pointer for failsafe data */
                        xcp_struct[service_no].daq_byp_ptr.daq           = daq;
                        xcp_struct[service_no].daq_byp_ptr.abs_odt       = abs_odt;
                        xcp_struct[service_no].daq_byp_ptr.abs_odt_entry = abs_odt_entry;
                      #if (XCP_ERROR_CHECK == XCP_ENABLED)
                        xcp_struct[service_no].daq_byp_ptr.rel_odt       = odt;
                        xcp_struct[service_no].daq_byp_ptr.rel_odt_entry = odt_entry;
                        xcp_struct[service_no].daq_byp_ptr.valid_flag    = XCP_DAQ_PTR_VALID;
                      #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                        /* send command response packet */
                        res_cto_length = 1;
                      }
                    }
                  }
                  break;
              #endif /* #if (XCP_CMD_SET_FAILSAFE_DATA_PTR == XCP_ENABLED) */

/**** WRITE_FAILSAFE_DATA *****************************************************/
              #if (XCP_CMD_WRITE_FAILSAFE_DATA == XCP_ENABLED)
                case XCP_CMD_CODE_WRITE_FAILSAFE_DATA:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: WRITE_FAILSAFE_DATA(%i, %i)",
                                  cmd_cto_ptr->write_failsafe_data.size,
                                  *(UInt32*)cmd_cto_ptr->write_failsafe_data.data);
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                #if (XCP_ERROR_CHECK == XCP_ENABLED)
                  if (xcp_struct[service_no].daq_byp_ptr.valid_flag == XCP_DAQ_PTR_INVALID)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                  {
                    UInt8  size;
                    UInt16 daq;
                    UInt16 abs_odt;
                    UInt16 abs_odt_entry;

                    size          = cmd_cto_ptr->write_failsafe_data.size;
                    daq           = xcp_struct[service_no].daq_byp_ptr.daq;
                    abs_odt       = xcp_struct[service_no].daq_byp_ptr.abs_odt;
                    abs_odt_entry = xcp_struct[service_no].daq_byp_ptr.abs_odt_entry;

                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    if (size != xcp_struct[service_no].odt_entry[abs_odt_entry].size)
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                      res_cto_length = 2;
                    }
                    else
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                    {
                      UInt16 first_odt_entry;
                      UInt16 offset;
                      UInt16 i;

                    #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                      if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                      {
                        first_odt_entry = xcp_struct[service_no].odt[abs_odt].first_odt_entry;
                      }
                      else
                    #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                      {
                        first_odt_entry = xcp_struct[service_no].daq_list[daq].first_odt_entry;
                      }

                      offset = 0;

                      /* calculate offset in STIM buffer */
                      for (i = first_odt_entry; i < abs_odt_entry; i++)
                      {
                        offset += xcp_struct[service_no].odt_entry[i].size;
                      }

                      /* copy failsafe data to STIM buffer */
                      for (i = offset; i < size; i++)
                      {
                        xcp_dto_buffer_0[2][abs_odt].data[offset + i] = cmd_cto_ptr->write_failsafe_data.data[i];
                      }

                      /* move DAQ pointer to next ODT entry */
                      xcp_struct[service_no].daq_byp_ptr.abs_odt_entry++;
                    #if (XCP_ERROR_CHECK == XCP_ENABLED)
                      xcp_struct[service_no].daq_byp_ptr.rel_odt_entry++;

                      /* check if next ODT entry is available */
                    #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                      if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                      {
                        if (xcp_struct[service_no].daq_byp_ptr.rel_odt_entry == xcp_struct[service_no].odt[abs_odt].no_of_odt_entries)
                        {
                          xcp_struct[service_no].daq_byp_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                        }
                      }
                      else
                    #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                      {
                        if (xcp_struct[service_no].daq_byp_ptr.rel_odt_entry == xcp_struct[service_no].daq_list[daq].no_of_odt_entries)
                        {
                          xcp_struct[service_no].daq_byp_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                        }
                      }
                    #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                      /* send command response packet */
                      res_cto_length = 1;
                    }
                  }
                  break;
              #endif /* #if (XCP_CMD_WRITE_FAILSAFE_DATA == XCP_ENABLED) */

                default:
                #if (XCP_DEBUG == XCP_ENABLED)
                  msg_info_printf(0, 0, "command received: USER_CMD()");
                #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                  res_cto_length = 2;
              }
              break;
          #endif /* #if (XCP_CMD_USER_CMD == XCP_ENABLED) */

/**** DOWNLOAD ****************************************************************/
          #if (XCP_CMD_DOWNLOAD == XCP_ENABLED)
            case XCP_CMD_CODE_DOWNLOAD:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: DOWNLOAD(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->download.no_of_elements,
                              cmd_cto_ptr->download.data[0],
                              cmd_cto_ptr->download.data[1],
                              cmd_cto_ptr->download.data[2],
                              cmd_cto_ptr->download.data[3],
                              cmd_cto_ptr->download.data[4],
                              cmd_cto_ptr->download.data[5]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->download.no_of_elements;

              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_WRITE) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                {
                  if (no_of_elements > (xcp_max_cto[service_no] - 2))
                  {
                    /* negative response, if no_of_elements is 0 or download data doesn't fit into RES when MBM is disabled */
                  #if (XCP_MASTER_BLOCK_MODE == XCP_DISABLED)
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                  #else /* (XCP_MASTER_BLOCK_MODE == XCP_ENABLED) */
                    /* download data to MTA */
                    xcp_download_to_mta(service_no, cmd_cto_ptr->download.data, xcp_max_cto[service_no] - 2);
                    xcp_struct[service_no].no_of_mbm_bytes_remaining = no_of_elements - (xcp_max_cto[service_no] - 2);
                  #endif /* #if ((XCP_ERROR_CHECK == XCP_ENABLED) && (XCP_MASTER_BLOCK_MODE == XCP_DISABLED)) */
                  }
                  else
                  {
                    /* download data to MTA */
                    xcp_download_to_mta(service_no, cmd_cto_ptr->download.data, no_of_elements);

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_DOWNLOAD == XCP_ENABLED) */

/**** DOWNLOAD_NEXT ***********************************************************/
          #if (XCP_CMD_DOWNLOAD_NEXT == XCP_ENABLED)
            case XCP_CMD_CODE_DOWNLOAD_NEXT:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: DOWNLOAD_NEXT(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->download_next.no_of_elements,
                              cmd_cto_ptr->download_next.data[0],
                              cmd_cto_ptr->download_next.data[1],
                              cmd_cto_ptr->download_next.data[2],
                              cmd_cto_ptr->download_next.data[3],
                              cmd_cto_ptr->download_next.data[4],
                              cmd_cto_ptr->download_next.data[5]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (cmd_cto_ptr->download_next.no_of_elements != xcp_struct[service_no].no_of_mbm_bytes_remaining) /* check consistency */
              {
                /* send error packet */
                res_cto_ptr->pid           = XCP_PID_ERR;
                res_cto_ptr->error.code    = XCP_ERR_SEQUENCE;
                res_cto_ptr->error.info[0] = xcp_struct[service_no].no_of_mbm_bytes_remaining;
                res_cto_length = 3;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->download_next.no_of_elements;

                if (no_of_elements > (xcp_max_cto[service_no] - 2))
                {
                  /* download data to MTA */
                  xcp_download_to_mta(service_no, cmd_cto_ptr->download_next.data, xcp_max_cto[service_no] - 2);
                  xcp_struct[service_no].no_of_mbm_bytes_remaining = no_of_elements - (xcp_max_cto[service_no] - 2);
                }
                else
                {
                  /* download data to MTA */
                  xcp_download_to_mta(service_no, cmd_cto_ptr->download_next.data, no_of_elements);
                  xcp_struct[service_no].no_of_mbm_bytes_remaining = 0;

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_DOWNLOAD_NEXT == XCP_ENABLED) */

/**** DOWNLOAD_MAX ************************************************************/
          #if (XCP_CMD_DOWNLOAD_MAX == XCP_ENABLED)
            case XCP_CMD_CODE_DOWNLOAD_MAX:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: DOWNLOAD_MAX(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->download_max.data[0],
                              cmd_cto_ptr->download_max.data[1],
                              cmd_cto_ptr->download_max.data[2],
                              cmd_cto_ptr->download_max.data[3],
                              cmd_cto_ptr->download_max.data[4],
                              cmd_cto_ptr->download_max.data[5],
                              cmd_cto_ptr->download_max.data[6]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
              if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, xcp_max_cto[service_no] - 1, XCP_MEMORY_ACCESS_TYPE_WRITE) == DSXCP_MEMORY_ACCESS_DENIED)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
              {
                /* download data to MTA */
                xcp_download_to_mta(service_no, cmd_cto_ptr->download_max.data, xcp_max_cto[service_no] - 1);

                /* send command response packet */
                res_cto_length = 1;
              }
              break;
          #endif /* #if (XCP_CMD_DOWNLOAD_MAX == XCP_ENABLED) */

/**** SHORT_DOWNLOAD **********************************************************/
          #if (XCP_CMD_SHORT_DOWNLOAD == XCP_ENABLED)
            case XCP_CMD_CODE_SHORT_DOWNLOAD:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SHORT_DOWNLOAD(%i, %i, 0x%x)",
                              cmd_cto_ptr->short_download.no_of_elements,
                              cmd_cto_ptr->short_download.extension,
                              cmd_cto_ptr->short_download.address);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 no_of_elements;
                no_of_elements = cmd_cto_ptr->short_download.no_of_elements;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (no_of_elements > (xcp_max_cto[service_no] - 8))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt32 address;
                  UInt8  extension;

                  address   = cmd_cto_ptr->short_download.address;
                  extension = cmd_cto_ptr->short_download.extension;

                #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                  if (DSXCP_memory_access_check(address, extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_WRITE) == DSXCP_MEMORY_ACCESS_DENIED)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                  {
                    /* set MTA */
                    xcp_set_mta(service_no, address, extension);

                    /* download data to MTA */
                    xcp_download_to_mta(service_no, cmd_cto_ptr->short_download.data, no_of_elements);

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_SHORT_DOWNLOAD == XCP_ENABLED) */

/**** MODIFY_BITS *************************************************************/
          #if (XCP_CMD_MODIFY_BITS == XCP_ENABLED)
            case XCP_CMD_CODE_MODIFY_BITS:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: MODIFY_BITS(0x%x, 0x%x, 0x%x)",
                              cmd_cto_ptr->modify_bits.shift_value,
                              cmd_cto_ptr->modify_bits.and_mask,
                              cmd_cto_ptr->modify_bits.xor_mask);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (cmd_cto_ptr->modify_bits.shift_value > 16)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, 4, XCP_MEMORY_ACCESS_TYPE_WRITE) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                {
                  UInt32 temp = 0;

                  /* read 32 bit value at MTA */
                  ((UInt8 *)&temp)[0] = xcp_struct[service_no].mta_ptr[0];
                  ((UInt8 *)&temp)[1] = xcp_struct[service_no].mta_ptr[1];
                  ((UInt8 *)&temp)[2] = xcp_struct[service_no].mta_ptr[2];
                  ((UInt8 *)&temp)[3] = xcp_struct[service_no].mta_ptr[3];

                  /* modify bits */
                  temp = (temp & (~((UInt32)(((UInt32)((UInt16)~cmd_cto_ptr->modify_bits.and_mask)) << cmd_cto_ptr->modify_bits.shift_value)))) ^ ((UInt32)(((UInt32)cmd_cto_ptr->modify_bits.xor_mask) << cmd_cto_ptr->modify_bits.shift_value));

                  /* write 32 bit value to MTA */
                  xcp_struct[service_no].mta_ptr[0] = ((UInt8 *)&temp)[0];
                  xcp_struct[service_no].mta_ptr[1] = ((UInt8 *)&temp)[1];
                  xcp_struct[service_no].mta_ptr[2] = ((UInt8 *)&temp)[2];
                  xcp_struct[service_no].mta_ptr[3] = ((UInt8 *)&temp)[3];

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_MODIFY_BITS == XCP_ENABLED) */

/**** SET_CAL_PAGE ************************************************************/
          #if (XCP_CMD_SET_CAL_PAGE == XCP_ENABLED)
            case XCP_CMD_CODE_SET_CAL_PAGE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_CAL_PAGE(%i, %i, %i)",
                              cmd_cto_ptr->set_cal_page.mode,
                              cmd_cto_ptr->set_cal_page.segment,
                              cmd_cto_ptr->set_cal_page.page);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment;
                UInt8 page;

                segment = cmd_cto_ptr->set_cal_page.segment;
                page    = cmd_cto_ptr->set_cal_page.page;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else if (page >= XCP_MAX_PAGES)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_PAGE_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED)
                  UInt8 mode;
                  mode = cmd_cto_ptr->set_cal_page.mode;

                  if (DSXCP_set_cal_page(segment, page, mode) == DSXCP_NO_ERROR)
                  {
                    /* send command response packet */
                    res_cto_length = 1;
                  }
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MODE_NOT_VALID;
                    res_cto_length = 2;
                  }
                #else /* (XCP_CAL_PAGE_SWITCHING == XCP_DISABLED) */
                  /* send command response packet */
                  res_cto_length = 1;
                #endif /* #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) */
                }
              }
              break;
          #endif /* #if (XCP_CMD_SET_CAL_PAGE == XCP_ENABLED) */

/**** GET_CAL_PAGE ************************************************************/
          #if (XCP_CMD_GET_CAL_PAGE == XCP_ENABLED)
            case XCP_CMD_CODE_GET_CAL_PAGE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_CAL_PAGE(%i, %i)",
                              cmd_cto_ptr->get_cal_page.mode,
                              cmd_cto_ptr->get_cal_page.segment);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment;
                UInt8 mode;

                segment = cmd_cto_ptr->get_cal_page.segment;
                mode    = cmd_cto_ptr->get_cal_page.mode;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else if ((mode != 0x01) && (mode != 0x02))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_MODE_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  /* send command response packet */
                #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED)
                  res_cto_ptr->get_cal_page.page = DSXCP_get_cal_page(segment, mode);
                #else /* (XCP_CAL_PAGE_SWITCHING == XCP_DISABLED) */
                  res_cto_ptr->get_cal_page.page = 0;
                #endif /* #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) */
                  res_cto_length = 4;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_CAL_PAGE == XCP_ENABLED) */

/**** GET_PAG_PROCESSOR_INFO **************************************************/
          #if (XCP_CMD_GET_PAG_PROCESSOR_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_PAG_PROCESSOR_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_PAG_PROCESSOR_INFO()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_pag_processor_info.max_segment = XCP_MAX_SEGMENT;
              res_cto_ptr->get_pag_processor_info.properties  = XCP_PAG_PROPERTIES;
              res_cto_length = 3;

              break;
          #endif /* #if (XCP_CMD_GET_PAG_PROCESSOR_INFO == XCP_ENABLED) */

/**** GET_SEGMENT_INFO ********************************************************/
          #if (XCP_CMD_GET_SEGMENT_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_SEGMENT_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_SEGMENT_INFO(%i, %i, %i, %i)",
                              cmd_cto_ptr->get_segment_info.mode,
                              cmd_cto_ptr->get_segment_info.segment,
                              cmd_cto_ptr->get_segment_info.info,
                              cmd_cto_ptr->get_segment_info.index);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment;
                segment = cmd_cto_ptr->get_segment_info.segment;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt8 mode;
                  mode = cmd_cto_ptr->get_segment_info.mode;

                  if (mode == 0)        /* basic address info */
                  {
                    UInt8 info;
                    info = cmd_cto_ptr->get_segment_info.info;

                    if (info == 0)      /* address of segment */
                    {
                      res_cto_ptr->get_segment_info_mode0.basic_info = xcp_segment_info[segment].address;
                      res_cto_length = 8;
                    }
                    else if (info == 1) /* length of segment */
                    {
                      res_cto_ptr->get_segment_info_mode0.basic_info = xcp_segment_info[segment].length;
                      res_cto_length = 8;
                    }
                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    else
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                      res_cto_length = 2;
                    }
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                  }
                  else if (mode == 1)   /* standard_info */
                  {
                    /* send command response packet */
                    res_cto_ptr->get_segment_info_mode1.max_pages          = XCP_MAX_PAGES;
                    res_cto_ptr->get_segment_info_mode1.extension          = xcp_segment_info[segment].extension;
                    res_cto_ptr->get_segment_info_mode1.max_mapping        = xcp_segment_info[segment].max_mapping;
                    res_cto_ptr->get_segment_info_mode1.compression_method = xcp_segment_info[segment].compression_method;
                    res_cto_ptr->get_segment_info_mode1.encryption_method  = xcp_segment_info[segment].encryption_method;
                    res_cto_length = 6;
                  }
                  else if (mode == 2)   /* address mapping info (not supported) */
                  {
                    /* send command response packet */
                    res_cto_ptr->get_segment_info_mode2.mapping_info = 0;
                    res_cto_length = 8;

                    /* sending an error packet will fail with CalDesk */
                    /*
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                    */
                  }
                #if (XCP_ERROR_CHECK == XCP_ENABLED)
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                    res_cto_length = 2;
                  }
                #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_SEGMENT_INFO == XCP_ENABLED) */

/**** GET_PAGE_INFO ***********************************************************/
          #if (XCP_CMD_GET_PAGE_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_PAGE_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_PAGE_INFO(%i, %i)",
                              cmd_cto_ptr->get_page_info.segment,
                              cmd_cto_ptr->get_page_info.page);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment;
                UInt8 page;

                segment = cmd_cto_ptr->get_segment_info.segment;
                page = cmd_cto_ptr->get_page_info.page;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else if (page >= XCP_MAX_PAGES)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_PAGE_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  /* send command response packet */
                  res_cto_ptr->get_page_info.properties   = xcp_page_info[page + (segment * XCP_MAX_PAGES)].properties;
                  res_cto_ptr->get_page_info.init_segment = xcp_page_info[page + (segment * XCP_MAX_PAGES)].init_segment;
                  res_cto_length = 3;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_PAGE_INFO == XCP_ENABLED) */

/**** SET_SEGMENT_MODE ********************************************************/
          #if (XCP_CMD_SET_SEGMENT_MODE == XCP_ENABLED)
            case XCP_CMD_CODE_SET_SEGMENT_MODE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_SEGMENT_MODE(%i, %i)",
                              cmd_cto_ptr->set_segment_mode.mode,
                              cmd_cto_ptr->set_segment_mode.segment);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 mode;
                UInt8 segment;

                mode    = cmd_cto_ptr->set_segment_mode.mode;
                segment = cmd_cto_ptr->set_segment_mode.segment;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else if (!(mode & XCP_SEGMENT_MODE_FREEZE))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_MODE_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_struct[service_no].segment_mode[segment] = mode;

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_SET_SEGMENT_MODE == XCP_ENABLED) */

/**** GET_SEGMENT_MODE ********************************************************/
          #if (XCP_CMD_GET_SEGMENT_MODE == XCP_ENABLED)
            case XCP_CMD_CODE_GET_SEGMENT_MODE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_SEGMENT_MODE(%i)",
                              cmd_cto_ptr->get_segment_mode.segment);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment;

                segment = cmd_cto_ptr->get_segment_mode.segment;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (segment >= XCP_MAX_SEGMENT)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  /* send command response packet */
                  res_cto_ptr->get_segment_mode.mode = xcp_struct[service_no].segment_mode[segment];
                  res_cto_length = 3;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_SEGMENT_MODE == XCP_ENABLED) */

/**** COPY_CAL_PAGE ***********************************************************/
          #if (XCP_CMD_COPY_CAL_PAGE == XCP_ENABLED)
            case XCP_CMD_CODE_COPY_CAL_PAGE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: COPY_CAL_PAGE(%i, %i, %i, %i)",
                              cmd_cto_ptr->copy_cal_page.segment_source,
                              cmd_cto_ptr->copy_cal_page.page_source,
                              cmd_cto_ptr->copy_cal_page.segment_destination,
                              cmd_cto_ptr->copy_cal_page.page_destination);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 segment_source;
                UInt8 segment_destination;
                UInt8 page_source;
                UInt8 page_destination;

                segment_source      = cmd_cto_ptr->copy_cal_page.segment_source;
                segment_destination = cmd_cto_ptr->copy_cal_page.segment_destination;
                page_source         = cmd_cto_ptr->copy_cal_page.page_source;
                page_destination    = cmd_cto_ptr->copy_cal_page.page_destination;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if ((segment_source >= XCP_MAX_SEGMENT) || (segment_destination >= XCP_MAX_SEGMENT))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_SEGMENT_NOT_VALID;
                  res_cto_length = 2;
                }
                else if ((page_source >= XCP_MAX_PAGES) || (page_destination >= XCP_MAX_PAGES))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_PAGE_NOT_VALID;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  if (DSXCP_copy_cal_page(segment_source, page_source, segment_destination, page_destination) == DSXCP_NO_ERROR)
                  {
                    /* send command response packet */
                    res_cto_length = 1;
                  }
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                    res_cto_length = 2;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_COPY_CAL_PAGE == XCP_ENABLED) */

/**** CLEAR_DAQ_LIST **********************************************************/
          #if (XCP_CMD_CLEAR_DAQ_LIST == XCP_ENABLED)
            case XCP_CMD_CODE_CLEAR_DAQ_LIST:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: CLEAR_DAQ_LIST(%i)",
                              cmd_cto_ptr->clear_daq_list.daq);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;
                daq = cmd_cto_ptr->clear_daq_list.daq;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (daq >= xcp_struct[service_no].max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  /*
                   * If DAQ list has been assigned to an event channel, it has
                   * to be removed from the event channel before it is cleared.
                   */
                  if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_CONFIGURED)
                  {
                    xcp_daq_list_remove(service_no, xcp_struct[service_no].daq_list[daq].event_channel, daq);
                  }
                  xcp_daq_list_clear(service_no, daq);

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_CLEAR_DAQ_LIST == XCP_ENABLED) */

/**** SET_DAQ_PTR *************************************************************/
          #if (XCP_CMD_SET_DAQ_PTR == XCP_ENABLED)
            case XCP_CMD_CODE_SET_DAQ_PTR:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_DAQ_PTR(%i, %i, %i)",
                              cmd_cto_ptr->set_daq_ptr.daq,
                              cmd_cto_ptr->set_daq_ptr.odt,
                              cmd_cto_ptr->set_daq_ptr.odt_entry);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;
                UInt8  odt;
                UInt8  odt_entry;

                daq       = cmd_cto_ptr->set_daq_ptr.daq;
                odt       = cmd_cto_ptr->set_daq_ptr.odt;
                odt_entry = cmd_cto_ptr->set_daq_ptr.odt_entry;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (daq >= xcp_struct[service_no].max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt16 abs_odt;
                  UInt8  no_of_odts;
                  UInt8  no_of_odt_entries;

                  abs_odt    = xcp_struct[service_no].daq_list[daq].first_odt + odt;
                  no_of_odts = xcp_struct[service_no].daq_list[daq].no_of_odts;

              #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                  if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                  {
                    no_of_odt_entries = xcp_struct[service_no].odt[abs_odt].no_of_odt_entries;
                  }
                  else
              #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                  {
                    no_of_odt_entries = xcp_struct[service_no].daq_list[daq].no_of_odt_entries;
                  }

                #if (XCP_ERROR_CHECK == XCP_ENABLED)
                  if ((odt >= no_of_odts) || (odt_entry >= no_of_odt_entries))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                  {
                    UInt16 abs_odt_entry;

                  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                    if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                    {
                      abs_odt_entry = xcp_struct[service_no].odt[abs_odt].first_odt_entry + odt_entry;
                    }
                    else
                  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                    {
                      abs_odt_entry = xcp_struct[service_no].daq_list[daq].first_odt_entry + (no_of_odt_entries * odt) + odt_entry;
                    }

                    /* set DAQ list pointer */
                    xcp_struct[service_no].daq_ptr.daq           = daq;
                    xcp_struct[service_no].daq_ptr.abs_odt       = abs_odt;
                    xcp_struct[service_no].daq_ptr.abs_odt_entry = abs_odt_entry;
                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    xcp_struct[service_no].daq_ptr.rel_odt       = odt;
                    xcp_struct[service_no].daq_ptr.rel_odt_entry = odt_entry;
                    xcp_struct[service_no].daq_ptr.valid_flag    = XCP_DAQ_PTR_VALID;
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_SET_DAQ_PTR == XCP_ENABLED) */

/**** WRITE_DAQ ***************************************************************/
          #if (XCP_CMD_WRITE_DAQ == XCP_ENABLED)
            case XCP_CMD_CODE_WRITE_DAQ:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: WRITE_DAQ(0x%x, %i, %i, 0x%x)",
                              cmd_cto_ptr->write_daq.bit_offset,
                              cmd_cto_ptr->write_daq.size,
                              cmd_cto_ptr->write_daq.extension,
                              cmd_cto_ptr->write_daq.address);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if ((xcp_struct[service_no].daq_ptr.valid_flag == XCP_DAQ_PTR_INVALID) ||
                  (xcp_struct[service_no].daq_ptr.daq < xcp_min_daq[service_no]))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt8  size;
                UInt8  bit_offset;

                size = cmd_cto_ptr->write_daq.size;
                bit_offset = cmd_cto_ptr->write_daq.bit_offset;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (
                #if XCP_MAX_ODT_ENTRY_SIZE_DAQ < 255
                    ((bit_offset == 0xFF) && (size > XCP_MAX_ODT_ENTRY_SIZE_DAQ)) ||
                #endif
                    ((bit_offset <= 0x07) && (size != XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ)) ||
                    ((bit_offset >= 0x08) && (bit_offset < 0xFF)))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt32 address;
                  UInt8  extension;

                  address = cmd_cto_ptr->write_daq.address;
                  extension = cmd_cto_ptr->write_daq.extension;

                #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                  if (DSXCP_memory_access_check(address, extension, size, XCP_MEMORY_ACCESS_TYPE_DAQ_STIM) == DSXCP_MEMORY_ACCESS_DENIED)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                  {
                    UInt16 abs_odt_entry;

                    abs_odt_entry = xcp_struct[service_no].daq_ptr.abs_odt_entry;

                    /* configure ODT entry */
                    xcp_struct[service_no].odt_entry[abs_odt_entry].bit_offset  = bit_offset;
                    xcp_struct[service_no].odt_entry[abs_odt_entry].size        = size;
                    xcp_struct[service_no].odt_entry[abs_odt_entry].extension   = extension;
                  #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
                    xcp_struct[service_no].odt_entry[abs_odt_entry].address     = address;
                  #else
                    xcp_struct[service_no].odt_entry[abs_odt_entry].address_ptr = DSXCP_get_address_pointer(address, extension);
                  #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */

                    /* move DAQ pointer to next ODT entry */
                    xcp_struct[service_no].daq_ptr.abs_odt_entry++;
                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    xcp_struct[service_no].daq_ptr.rel_odt_entry++;

                    /* check if next ODT entry is available */
                  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                    if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                    {
                      if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].odt[xcp_struct[service_no].daq_ptr.abs_odt].no_of_odt_entries)
                      {
                        xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                      }
                    }
                    else
                  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                    {
                      if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].daq_list[xcp_struct[service_no].daq_ptr.daq].no_of_odt_entries)
                      {
                        xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                      }
                    }
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_WRITE_DAQ == XCP_ENABLED) */

/**** SET_DAQ_LIST_MODE *******************************************************/
          #if (XCP_CMD_SET_DAQ_LIST_MODE == XCP_ENABLED)
            case XCP_CMD_CODE_SET_DAQ_LIST_MODE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: SET_DAQ_LIST_MODE(%i, %i, %i, %i, %i)",
                              cmd_cto_ptr->set_daq_list_mode.mode,
                              cmd_cto_ptr->set_daq_list_mode.daq,
                              cmd_cto_ptr->set_daq_list_mode.event_channel,
                              cmd_cto_ptr->set_daq_list_mode.prescaler,
                              cmd_cto_ptr->set_daq_list_mode.priority);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;
                UInt16 event_channel;
                UInt8  mode;

                mode          = cmd_cto_ptr->set_daq_list_mode.mode;
                daq           = cmd_cto_ptr->set_daq_list_mode.daq;
                event_channel = cmd_cto_ptr->set_daq_list_mode.event_channel;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if ((daq >= xcp_struct[service_no].max_daq)  ||
                #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_DISABLED)
                    (mode & XCP_DAQ_LIST_MODE_DIRECTION)     ||
                #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_DISABLED) */
                #if (XCP_TIMESTAMP_SUPPORTED == XCP_DISABLED)
                    (mode & XCP_DAQ_LIST_MODE_TIMESTAMP)     ||
                #endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_DISABLED) */
                #if (XCP_PID_OFF_SUPPORTED == XCP_DISABLED)
                    (mode & XCP_DAQ_LIST_MODE_PID_OFF)       ||
                #endif /* #if (XCP_PID_OFF_SUPPORTED == XCP_DISABLED) */
                    (event_channel >= XCP_MAX_EVENT_CHANNEL))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
              #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
                #if ((XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) && (XCP_RESOURCE_PROTECTION_STIM == XCP_ENABLED))
                  if ((mode & XCP_DAQ_LIST_MODE_DIRECTION) && (xcp_struct[service_no].protection_status & XCP_RESOURCE_STIM))
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_ACCESS_LOCKED;
                    res_cto_length = 2;
                  }
                  else
                #endif /* #if ((XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) && (XCP_RESOURCE_PROTECTION_STIM == XCP_ENABLED)) */
              #endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */
                  {
                    if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_RUNNING)
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_DAQ_ACTIVE;
                      res_cto_length = 2;
                    }
                    else
                    {
                      xcp_daq_list_t *daq_list_ptr;

                      daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

                      daq_list_ptr->mode &= ~(XCP_DAQ_LIST_MODE_DIRECTION | XCP_DAQ_LIST_MODE_TIMESTAMP | XCP_DAQ_LIST_MODE_PID_OFF);
                      daq_list_ptr->mode |= (mode & (XCP_DAQ_LIST_MODE_DIRECTION | XCP_DAQ_LIST_MODE_TIMESTAMP | XCP_DAQ_LIST_MODE_PID_OFF));

                    #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
                      if (cmd_cto_ptr->set_daq_list_mode.prescaler > 0)
                      {
                        daq_list_ptr->prescaler = cmd_cto_ptr->set_daq_list_mode.prescaler;
                      }
                      else
                      {
                        daq_list_ptr->prescaler = 1;
                      }
                    #endif /* #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED) */

                      daq_list_ptr->priority = cmd_cto_ptr->set_daq_list_mode.priority;

                      /* check if DAQ list has already been configured before */
                      if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_CONFIGURED)
                      {
                        /*
                         * If DAQ list has been assigned to another event channel,
                         * remove it and assign it to the new event channel.
                         */
                        xcp_daq_list_remove(service_no, daq_list_ptr->event_channel, daq);
                        daq_list_ptr->event_channel = event_channel;
                        xcp_daq_list_insert(service_no, event_channel, daq);
                      }
                      else
                      {
                        daq_list_ptr->event_channel = event_channel;
                        xcp_daq_list_insert(service_no, event_channel, daq);
                        daq_list_ptr->mode |= XCP_DAQ_LIST_MODE_CONFIGURED;
                      }

                      /* send command response packet */
                      res_cto_length = 1;
                    }
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_SET_DAQ_LIST_MODE == XCP_ENABLED) */

/**** GET_DAQ_LIST_MODE *******************************************************/
          #if (XCP_CMD_GET_DAQ_LIST_MODE == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_LIST_MODE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_LIST_MODE(%i)",
                              cmd_cto_ptr->get_daq_list_mode.daq);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;

                daq = cmd_cto_ptr->get_daq_list_mode.daq;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (daq >= xcp_struct[service_no].max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_daq_list_t *daq_list_ptr;

                  daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

                  /* send command response packet */
                  res_cto_ptr->get_daq_list_mode.mode          = daq_list_ptr->mode;
                  res_cto_ptr->get_daq_list_mode.event_channel = daq_list_ptr->event_channel;
                #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
                  res_cto_ptr->get_daq_list_mode.prescaler     = daq_list_ptr->prescaler;
                #else /* (XCP_PRESCALER_SUPPORTED == XCP_DISABLED) */
                  res_cto_ptr->get_daq_list_mode.prescaler     = 1;
                #endif /* #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED) */
                  res_cto_ptr->get_daq_list_mode.priority      = daq_list_ptr->priority;
                  res_cto_length = 8;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_LIST_MODE == XCP_ENABLED) */

/**** START_STOP_DAQ_LIST *****************************************************/
          #if (XCP_CMD_START_STOP_DAQ_LIST == XCP_ENABLED)
            case XCP_CMD_CODE_START_STOP_DAQ_LIST:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: START_STOP_DAQ_LIST(%i, %i)",
                              cmd_cto_ptr->start_stop_daq_list.mode,
                              cmd_cto_ptr->start_stop_daq_list.daq);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;
                UInt8  mode;

                daq  = cmd_cto_ptr->start_stop_daq_list.daq;
                mode = cmd_cto_ptr->start_stop_daq_list.mode;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (daq >= xcp_struct[service_no].max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else if (cmd_cto_ptr->start_stop_daq_list.mode > 2)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  if (mode == 0)      /* stop */
                  {
                    xcp_daq_list_stop(service_no, daq);
                    xcp_check_daq_running(service_no);
                  }
                  else if (mode == 1) /* start */
                  {
                    xcp_daq_list_start(service_no, daq);
                  }
                  else if (mode == 2) /* select */
                  {
                    xcp_daq_list_select(service_no, daq);
                  }

                  /* send command response packet */
                  res_cto_ptr->start_stop_daq_list.first_pid = (UInt8)xcp_struct[service_no].daq_list[daq].first_odt;
                  res_cto_length = 2;
                }
              }
              break;
          #endif /* #if (XCP_CMD_START_STOP_DAQ_LIST == XCP_ENABLED) */

/**** START_STOP_SYNCH ********************************************************/
          #if (XCP_CMD_START_STOP_SYNCH == XCP_ENABLED)
            case XCP_CMD_CODE_START_STOP_SYNCH:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: START_STOP_SYNCH(%i)",
                              cmd_cto_ptr->start_stop_synch.mode);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 mode;

                mode = cmd_cto_ptr->start_stop_synch.mode;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (mode > 2)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  if (mode == 0)      /* stop all */
                  {
                    xcp_daq_list_stop_all(service_no);
                  }
                  else if (mode == 1) /* start selected */
                  {
                    xcp_daq_list_start_selected(service_no);
                  }
                  else  /* (mode == 2) stop selected */
                  {
                    xcp_daq_list_stop_selected(service_no);
                    xcp_check_daq_running(service_no);
                  }

                  /* send command response packet */
                  res_cto_length = 1;
                }
              }
              break;
          #endif /* #if (XCP_CMD_START_STOP_SYNCH == XCP_ENABLED) */

/**** GET_DAQ_CLOCK ***********************************************************/
          #if (XCP_CMD_GET_DAQ_CLOCK == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_CLOCK:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_CLOCK()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_daq_clock.timestamp = DSXCP_get_timestamp();
              res_cto_length = 8;
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_CLOCK == XCP_ENABLED) */

/**** READ_DAQ ****************************************************************/
          #if (XCP_CMD_READ_DAQ == XCP_ENABLED)
            case XCP_CMD_CODE_READ_DAQ:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: READ_DAQ()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (xcp_struct[service_no].daq_ptr.valid_flag == XCP_DAQ_PTR_INVALID)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt16 abs_odt_entry;

                abs_odt_entry = xcp_struct[service_no].daq_ptr.abs_odt_entry;

                res_cto_ptr->read_daq.bit_offset = xcp_struct[service_no].odt_entry[abs_odt_entry].bit_offset;
                res_cto_ptr->read_daq.size       = xcp_struct[service_no].odt_entry[abs_odt_entry].size;
                res_cto_ptr->read_daq.extension  = xcp_struct[service_no].odt_entry[abs_odt_entry].extension;
              #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
                res_cto_ptr->read_daq.address    = xcp_struct[service_no].odt_entry[abs_odt_entry].address;
              #else
              #pragma GCC diagnostic push
              #pragma GCC diagnostic ignored "-Wall"
              #pragma GCC diagnostic ignored "-Wextra"
                //res_cto_ptr->read_daq.address    = (UInt32)xcp_struct[service_no].odt_entry[abs_odt_entry].address_ptr;
                res_cto_ptr->read_daq.address    = (UInt32)(unsigned long)xcp_struct[service_no].odt_entry[abs_odt_entry].address_ptr;
              #pragma GCC diagnostic pop
              #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */

                /* move DAQ pointer to next ODT entry */
                xcp_struct[service_no].daq_ptr.abs_odt_entry++;
              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                xcp_struct[service_no].daq_ptr.rel_odt_entry++;

                /* check if next ODT entry is available */
              #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                {
                  if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].odt[xcp_struct[service_no].daq_ptr.abs_odt].no_of_odt_entries)
                  {
                    xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                  }
                }
                else
              #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                {
                  if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].daq_list[xcp_struct[service_no].daq_ptr.daq].no_of_odt_entries)
                  {
                    xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                  }
                }
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                /* send command response packet */
                res_cto_length = 8;
              }
              break;
          #endif /* #if (XCP_CMD_READ_DAQ == XCP_ENABLED) */

/**** GET_DAQ_PROCESSOR_INFO **************************************************/
          #if (XCP_CMD_GET_DAQ_PROCESSOR_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_PROCESSOR_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_PROCESSOR_INFO()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_daq_processor_info.properties        = xcp_daq_properties[service_no];
              res_cto_ptr->get_daq_processor_info.max_daq           = xcp_struct[service_no].max_daq;
              res_cto_ptr->get_daq_processor_info.max_event_channel = XCP_MAX_EVENT_CHANNEL;
              res_cto_ptr->get_daq_processor_info.min_daq           = xcp_min_daq[service_no];
              res_cto_ptr->get_daq_processor_info.key_byte          = XCP_DAQ_KEY_BYTE;
              res_cto_length = 8;
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_PROCESSOR_INFO == XCP_ENABLED) */

/**** GET_DAQ_RESOLUTION_INFO *************************************************/
          #if (XCP_CMD_GET_DAQ_RESOLUTION_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_RESOLUTION_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_RESOLUTION_INFO()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_daq_resolution_info.granularity_daq  = XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ;
              res_cto_ptr->get_daq_resolution_info.max_daq          = XCP_MAX_ODT_ENTRY_SIZE_DAQ;
            #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
              res_cto_ptr->get_daq_resolution_info.granularity_stim = XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM;
              res_cto_ptr->get_daq_resolution_info.max_stim         = XCP_MAX_ODT_ENTRY_SIZE_STIM;
            #else /* (XCP_RESOURCE_SUPPORTED_STIM == XCP_DISABLED) */
              res_cto_ptr->get_daq_resolution_info.granularity_stim = 0;
              res_cto_ptr->get_daq_resolution_info.max_stim         = 0;
            #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
            #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
              res_cto_ptr->get_daq_resolution_info.timestamp_mode   = XCP_TIMESTAMP_MODE;
              res_cto_ptr->get_daq_resolution_info.timestamp_ticks  = XCP_TIMESTAMP_TICKS;
            #else /* (XCP_TIMESTAMP_SUPPORTED == XCP_DISABLED) */
              res_cto_ptr->get_daq_resolution_info.timestamp_mode   = 0;
              res_cto_ptr->get_daq_resolution_info.timestamp_ticks  = 0;
            #endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */
              res_cto_length = 8;
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_RESOLUTION_INFO == XCP_ENABLED) */

/**** GET_DAQ_LIST_INFO *******************************************************/
          #if (XCP_CMD_GET_DAQ_LIST_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_LIST_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_LIST_INFO(%i)",
                              cmd_cto_ptr->get_daq_list_info.daq);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 daq;

                daq = cmd_cto_ptr->get_daq_list_info.daq;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (daq >= xcp_struct[service_no].max_daq)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_daq_list_t *daq_list_ptr;

                  daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

                  /* send command response packet */
                  res_cto_ptr->get_daq_list_info.properties      = daq_list_ptr->properties;
                  res_cto_ptr->get_daq_list_info.max_odt         = daq_list_ptr->no_of_odts;
                  res_cto_ptr->get_daq_list_info.max_odt_entries = daq_list_ptr->no_of_odt_entries;
                  res_cto_ptr->get_daq_list_info.fixed_event     = 0; /* no fixed event channel */
                  res_cto_length = 6;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_LIST_INFO == XCP_ENABLED) */

/**** GET_DAQ_EVENT_INFO ******************************************************/
          #if (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_DAQ_EVENT_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_DAQ_EVENT_INFO(%i)",
                              cmd_cto_ptr->get_daq_event_info.event_channel);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt16 event_channel;

                event_channel = cmd_cto_ptr->get_daq_event_info.event_channel;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (event_channel >= XCP_MAX_EVENT_CHANNEL)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_struct[service_no].mta_ptr = (xcp_mta_ptr_t)xcp_event_channel_info[event_channel].name;
                  xcp_struct[service_no].pending_status |= XCP_PENDING_UPLOAD_INFO;
                  xcp_struct[service_no].no_of_upload_info_bytes_remaining = xcp_event_channel_info[event_channel].name_length;

                  /* send command response packet */
                  res_cto_ptr->get_daq_event_info.properties   = xcp_event_channel_info[event_channel].properties;
                  res_cto_ptr->get_daq_event_info.max_daq_list = xcp_event_channel_info[event_channel].max_daq;
                  res_cto_ptr->get_daq_event_info.name_length  = xcp_event_channel_info[event_channel].name_length;
                  res_cto_ptr->get_daq_event_info.time_cycle   = xcp_event_channel_info[event_channel].time_cycle;
                  res_cto_ptr->get_daq_event_info.time_unit    = xcp_event_channel_info[event_channel].time_unit;
                  res_cto_ptr->get_daq_event_info.priority     = xcp_event_channel_info[event_channel].priority;
                  res_cto_length = 7;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED) */

/**** FREE_DAQ ****************************************************************/
          #if (XCP_CMD_FREE_DAQ == XCP_ENABLED)
            case XCP_CMD_CODE_FREE_DAQ:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: FREE_DAQ()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (xcp_daq_config_type_dynamic[service_no] == XCP_DISABLED)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                xcp_daq_init(service_no);
              }

              /* send command response packet */
              res_cto_length = 1;
              break;
          #endif /* #if (XCP_CMD_FREE_DAQ == XCP_ENABLED) */

/**** ALLOC_DAQ ***************************************************************/
          #if (XCP_CMD_ALLOC_DAQ == XCP_ENABLED)
            case XCP_CMD_CODE_ALLOC_DAQ:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: ALLOC_DAQ(%i)",
                              cmd_cto_ptr->alloc_daq.daq_count);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (xcp_daq_config_type_dynamic[service_no] == XCP_DISABLED)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              }
              else if ((xcp_struct[service_no].odt_count > 0) || (xcp_struct[service_no].odt_entries_count > 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt16 daq_count;

                daq_count = cmd_cto_ptr->alloc_daq.daq_count;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB))
                if (daq_count > 124)
                #else /* ((XCP_OVERLOAD_INDICATION == XCP_DISABLED) || (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */
                if (daq_count > 252)
                #endif /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)) */
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_struct[service_no].max_daq = daq_count;

                  if (xcp_check_daq_memory_overflow(service_no) == 1)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                    res_cto_length = 2;
                  }
                  else
                  {
                    /* set ODT pointer behind last DAQ list */
                    if (service_no == 0)
                    {
                    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
                      xcp_struct[0].odt = (xcp_odt_t *)&xcp_daq_buffer_0[daq_count * sizeof(xcp_daq_list_t)];
                    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
                    }
                  #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
                    else
                    {
                    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
                      xcp_struct[1].odt = (xcp_odt_t *)&xcp_daq_buffer_1[daq_count * sizeof(xcp_daq_list_t)];
                    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
                    }
                  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */
                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_ALLOC_DAQ == XCP_ENABLED) */

/**** ALLOC_ODT ***************************************************************/
          #if (XCP_CMD_ALLOC_ODT == XCP_ENABLED)
            case XCP_CMD_CODE_ALLOC_ODT:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: ALLOC_ODT(%i, %i)",
                              cmd_cto_ptr->alloc_odt.daq,
                              cmd_cto_ptr->alloc_odt.odt_count);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (xcp_daq_config_type_dynamic[service_no] == XCP_DISABLED)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              }
              else if ((xcp_struct[service_no].max_daq == 0) || (xcp_struct[service_no].odt_entries_count > 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt16 daq;
                UInt8  odt_count;

                daq       = cmd_cto_ptr->alloc_odt.daq;
                odt_count = cmd_cto_ptr->alloc_odt.odt_count;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if ((daq >= xcp_struct[service_no].max_daq) ||
                #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB))
                    ((xcp_struct[service_no].odt_count + odt_count) > 124))
                #else /* ((XCP_OVERLOAD_INDICATION == XCP_DISABLED) || (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */
                    ((xcp_struct[service_no].odt_count + odt_count) > 252))
                #endif /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)) */
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  xcp_struct[service_no].daq_list[daq].first_odt  = xcp_struct[service_no].odt_count;
                  xcp_struct[service_no].daq_list[daq].no_of_odts = odt_count;
                  xcp_struct[service_no].odt_count += odt_count;

                  if (xcp_check_daq_memory_overflow(service_no) == 1)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                    res_cto_length = 2;
                  }
                  else
                  {
                    /* set ODT entry pointer behind last ODT */
                    if (service_no == 0)
                    {
                    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
                    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
                      xcp_dto_buffer_0[0] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t))];
                    #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
                      xcp_dto_buffer_0[1] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t))];
                    #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
                      xcp_dto_buffer_0[2] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t) * 2)];
                    #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
                    #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
                    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                      xcp_dto_buffer_0[0] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t))];
                    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

                    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
                    #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
                    #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
                      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t) * 3)];
                    #else
                      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t) * 2)];
                    #endif
                    #else
                      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t))];
                    #endif
                    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element0_t))];
                    #else
                      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(xcp_struct[0].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t))];
                    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
                    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
                    }
                  #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
                    else
                    {
                    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
                    #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
                      xcp_dto_buffer_1[0] = (dto_buffer_element1_t *)&xcp_daq_buffer_1[(xcp_struct[1].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t))];
                      xcp_struct[1].odt_entry = (xcp_entry_t *)&xcp_daq_buffer_1[(xcp_struct[1].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t)) + (xcp_struct[service_no].odt_count * sizeof(dto_buffer_element1_t))];
                    #else
                      xcp_struct[1].odt_entry = (xcp_entry_t *)&xcp_daq_buffer_1[(xcp_struct[1].max_daq * sizeof(xcp_daq_list_t)) + (xcp_struct[service_no].odt_count * sizeof(xcp_odt_t))];
                    #endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
                    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
                    }
                  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_ALLOC_ODT == XCP_ENABLED) */

/**** ALLOC_ODT_ENTRY *********************************************************/
          #if (XCP_CMD_ALLOC_ODT_ENTRY == XCP_ENABLED)
            case XCP_CMD_CODE_ALLOC_ODT_ENTRY:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: ALLOC_ODT_ENTRY(%i, %i, %i)",
                              cmd_cto_ptr->alloc_odt_entry.daq,
                              cmd_cto_ptr->alloc_odt_entry.odt,
                              cmd_cto_ptr->alloc_odt_entry.odt_entries_count);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (xcp_daq_config_type_dynamic[service_no] == XCP_DISABLED)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              }
              else if ((xcp_struct[service_no].max_daq == 0) || (xcp_struct[service_no].odt_count == 0))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt16 daq;
                UInt8  odt;

                daq = cmd_cto_ptr->alloc_odt_entry.daq;
                odt = cmd_cto_ptr->alloc_odt_entry.odt;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if ((daq >= xcp_struct[service_no].max_daq) || (odt >= xcp_struct[service_no].daq_list[daq].no_of_odts))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt16 abs_odt;
                  UInt8  odt_entries_count;

                  odt_entries_count = cmd_cto_ptr->alloc_odt_entry.odt_entries_count;

                  if (odt == 0)
                  {
                    xcp_struct[service_no].daq_list[daq].first_odt_entry = xcp_struct[service_no].odt_entries_count;
                  }

                  abs_odt = xcp_struct[service_no].daq_list[daq].first_odt + odt;

                  xcp_struct[service_no].odt[abs_odt].first_odt_entry   = xcp_struct[service_no].odt_entries_count;
                  xcp_struct[service_no].odt[abs_odt].no_of_odt_entries = odt_entries_count;
                  xcp_struct[service_no].odt_entries_count += odt_entries_count;

                  if (xcp_check_daq_memory_overflow(service_no) == 1)
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_MEMORY_OVERFLOW;
                    res_cto_length = 2;
                  }
                  else
                  {
                    /* send command response packet */
                    res_cto_length = 1;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_ALLOC_ODT_ENTRY == XCP_ENABLED) */

/**** WRITE_DAQ_MULTIPLE ******************************************************/
          #if (XCP_CMD_WRITE_DAQ_MULTIPLE == XCP_ENABLED)
            #if ((XCP_MAX_CTO_0 >= 10) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_MAX_CTO_1 >= 10)))
            case XCP_CMD_CODE_WRITE_DAQ_MULTIPLE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: WRITE_DAQ_MULTIPLE(%i, 0x%x, %i, 0x%x, %i)",
                              cmd_cto_ptr->write_daq_multiple.no_of_daq_elements,
                              cmd_cto_ptr->write_daq_multiple_helper1.element[0].bit_offset,
                              cmd_cto_ptr->write_daq_multiple_helper1.element[0].size,
                              cmd_cto_ptr->write_daq_multiple_helper1.element[0].address,
                              cmd_cto_ptr->write_daq_multiple_helper2.element[0].extension);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              if (xcp_max_cto[service_no] < 10)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              }
              else
              {
              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if ((xcp_struct[service_no].daq_ptr.valid_flag == XCP_DAQ_PTR_INVALID) ||
                    (xcp_struct[service_no].daq_ptr.daq < xcp_min_daq[service_no]))
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_WRITE_PROTECTED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  UInt8  no_of_daq_elements;
                  UInt8  element;
                  UInt8  size;
                  UInt8  bit_offset;
                  UInt32 address;
                  UInt8  extension;

                  no_of_daq_elements = cmd_cto_ptr->write_daq_multiple.no_of_daq_elements;

                  for (element = 0; element < no_of_daq_elements; element++)
                  {
                    size       = cmd_cto_ptr->write_daq_multiple_helper1.element[element].size;
                    bit_offset = cmd_cto_ptr->write_daq_multiple_helper1.element[element].bit_offset;

                  #if (XCP_ERROR_CHECK == XCP_ENABLED)
                    if (
                    #if XCP_MAX_ODT_ENTRY_SIZE_DAQ < 255
                        ((bit_offset == 0xFF) && (size > XCP_MAX_ODT_ENTRY_SIZE_DAQ)) ||
                    #endif
                        ((bit_offset <= 0x07) && (size != XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ)) ||
                        ((bit_offset >= 0x08) && (bit_offset < 0xFF)))
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_CMD_SYNTAX;
                      res_cto_length = 2;
                      break;
                    }
                    else
                  #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                    {
                      address = cmd_cto_ptr->write_daq_multiple_helper1.element[element].address;
                      extension = cmd_cto_ptr->write_daq_multiple_helper2.element[element].extension;

                    #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                      if (DSXCP_memory_access_check(address, extension, size, XCP_MEMORY_ACCESS_TYPE_DAQ_STIM) == DSXCP_MEMORY_ACCESS_DENIED)
                      {
                        /* send error packet */
                        res_cto_ptr->pid        = XCP_PID_ERR;
                        res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                        res_cto_length = 2;
                        break;
                      }
                      else
                    #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                      {
                        UInt16 abs_odt_entry;

                        abs_odt_entry = xcp_struct[service_no].daq_ptr.abs_odt_entry;

                        /* configure ODT entry */
                        xcp_struct[service_no].odt_entry[abs_odt_entry].bit_offset  = bit_offset;
                        xcp_struct[service_no].odt_entry[abs_odt_entry].size        = size;
                        xcp_struct[service_no].odt_entry[abs_odt_entry].extension   = extension;
                      #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
                        xcp_struct[service_no].odt_entry[abs_odt_entry].address     = address;
                      #else
                        xcp_struct[service_no].odt_entry[abs_odt_entry].address_ptr = DSXCP_get_address_pointer(address, extension);
                      #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */

                        /* move DAQ pointer to next ODT entry */
                        xcp_struct[service_no].daq_ptr.abs_odt_entry++;
                      #if (XCP_ERROR_CHECK == XCP_ENABLED)
                        xcp_struct[service_no].daq_ptr.rel_odt_entry++;

                        /* check if next ODT entry is available */
                      #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
                        if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
                        {
                          if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].odt[xcp_struct[service_no].daq_ptr.abs_odt].no_of_odt_entries)
                          {
                            xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                          }
                        }
                        else
                      #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
                        {
                          if (xcp_struct[service_no].daq_ptr.rel_odt_entry == xcp_struct[service_no].daq_list[xcp_struct[service_no].daq_ptr.daq].no_of_odt_entries)
                          {
                            xcp_struct[service_no].daq_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
                          }
                        }
                      #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

                        /* send command response packet */
                        res_cto_length = 1;
                      }
                    }
                  }
                }
              }
              break;
            #endif /* ((XCP_MAX_CTO_0 >= 10) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_MAX_CTO_1 >= 10))) */
          #endif /* #if (XCP_CMD_WRITE_DAQ_MULTIPLE == XCP_ENABLED) */

/**** PROGRAM_START ***********************************************************/
          #if (XCP_CMD_PROGRAM_START == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_START:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_START()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* check if non-volatile memory programming is currently allowed */
            #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
              if (!(xcp_struct[service_no].pgm_status & XCP_PGM_STATUS_PREPARED))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_GENERIC;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED) */
              {
                /* perform implementation specific actions (if required) */
                if (DSXCP_program_start() != DSXCP_NO_ERROR)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_GENERIC;
                  res_cto_length = 2;
                }
                else
                {
                  xcp_struct[service_no].pgm_status |= XCP_PGM_STATUS_STARTED;
                  /*
                   * If a flash kernel has been downloaded with PROGRAM_PREPARE,
                   * the MTA must have been set to its entry point.
                   */
                #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
                  ((void (*) (void))xcp_struct[service_no].mta_ptr)();
                  /* response to PROGRAM_START will be send by the flash kernel */
                #else /* (XCP_FLASH_KERNEL_DOWNLOAD == XCP_DISABLED) */
                  /* send command response packet */
                  res_cto_ptr->program_start.comm_mode_pgm  = XCP_COMM_MODE_PGM;
                  res_cto_ptr->program_start.max_cto_pgm    = xcp_max_cto[service_no];
                  res_cto_ptr->program_start.max_bs_pgm     = XCP_MAX_BS_PGM;
                  res_cto_ptr->program_start.min_st_pgm     = XCP_MIN_ST_PGM;
                  res_cto_ptr->program_start.queue_size_pgm = 0;  /* interleaved mode is not implemented */
                  res_cto_length = 7;
                #endif /* #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED) */
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_START == XCP_ENABLED) */

/**** PROGRAM_CLEAR ***********************************************************/
          #if (XCP_CMD_PROGRAM_CLEAR == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_CLEAR:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_CLEAR(%i, 0x%x)",
                              cmd_cto_ptr->program_clear.mode,
                              cmd_cto_ptr->program_clear.range);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (!(xcp_struct[service_no].pgm_status & XCP_PGM_STATUS_STARTED))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt32 range;

                range = cmd_cto_ptr->program_clear.range;

              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, range, XCP_MEMORY_ACCESS_TYPE_PGM) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                /* only absolute mode supported */
                if (DSXCP_program_clear(xcp_struct[service_no].mta_ptr, range) == DSXCP_NO_ERROR)
                {
                  /* send command response packet */
                  res_cto_length = 1;
                }
                else
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_GENERIC;
                  res_cto_length = 2;
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_CLEAR == XCP_ENABLED) */

/**** PROGRAM *****************************************************************/
          #if (XCP_CMD_PROGRAM == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->program.no_of_elements,
                              cmd_cto_ptr->program.data[0],
                              cmd_cto_ptr->program.data[1],
                              cmd_cto_ptr->program.data[2],
                              cmd_cto_ptr->program.data[3],
                              cmd_cto_ptr->program.data[4],
                              cmd_cto_ptr->program.data[5]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (!(xcp_struct[service_no].pgm_status & XCP_PGM_STATUS_STARTED))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->program.no_of_elements;

              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, no_of_elements, XCP_MEMORY_ACCESS_TYPE_PGM) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                {
                  if (no_of_elements > (xcp_max_cto[service_no] - 2))
                  {
                  /* negative response, if no_of_elements is 0 or program data doesn't fit into RES when MBM for PGM is disabled */
                  #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_DISABLED)
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                    res_cto_length = 2;
                  #else /* (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED) */
                    if (DSXCP_program(xcp_struct[service_no].mta_ptr, xcp_max_cto[service_no] - 2, cmd_cto_ptr->program.data) == DSXCP_NO_ERROR)
                    {
                      /* post-increment MTA by number of elements */
                      xcp_struct[service_no].mta_ptr += xcp_max_cto[service_no] - 2;
                    #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                      xcp_struct[service_no].mta_info.address += xcp_max_cto[service_no] - 2;
                    #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                      xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining = no_of_elements - (xcp_max_cto[service_no] - 2);
                    }
                    else
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_GENERIC;
                      res_cto_length = 2;
                    }
                  #endif /* #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_DISABLED) */
                  }
                  else
                  {
                    if (DSXCP_program(xcp_struct[service_no].mta_ptr, no_of_elements, cmd_cto_ptr->program.data) == DSXCP_NO_ERROR)
                    {
                      /* post-increment MTA by number of elements */
                      xcp_struct[service_no].mta_ptr += no_of_elements;
                    #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                      xcp_struct[service_no].mta_info.address += no_of_elements;
                    #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                      /* send command response packet */
                      res_cto_length = 1;
                    }
                    else
                    {
                      /* send error packet */
                      res_cto_ptr->pid        = XCP_PID_ERR;
                      res_cto_ptr->error.code = XCP_ERR_GENERIC;
                      res_cto_length = 2;
                    }
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM == XCP_ENABLED) */

/**** PROGRAM_RESET ***********************************************************/
          #if (XCP_CMD_PROGRAM_RESET == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_RESET:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_RESET()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (!(xcp_struct[service_no].pgm_status & XCP_PGM_STATUS_STARTED))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                if (DSXCP_program_reset() == DSXCP_NO_ERROR)
                {
                  /* send command response packet */
                  res_cto_length = 1;
                }
                else
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_GENERIC;
                  res_cto_length = 2;
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_RESET == XCP_ENABLED) */

/**** GET_PGM_PROCESSOR_INFO **************************************************/
          #if (XCP_CMD_GET_PGM_PROCESSOR_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_PGM_PROCESSOR_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_PGM_PROCESSOR_INFO()");
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* send command response packet */
              res_cto_ptr->get_pgm_processor_info.properties = XCP_PGM_PROPERTIES;
              res_cto_ptr->get_pgm_processor_info.max_sector = XCP_MAX_SECTOR;
              res_cto_length = 3;
              break;
          #endif /* #if (XCP_CMD_GET_PGM_PROCESSOR_INFO == XCP_ENABLED) */

/**** GET_SECTOR_INFO *********************************************************/
          #if (XCP_CMD_GET_SECTOR_INFO == XCP_ENABLED)
            case XCP_CMD_CODE_GET_SECTOR_INFO:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: GET_SECTOR_INFO(%i, %i)",
                              cmd_cto_ptr->get_sector_info.mode,
                              cmd_cto_ptr->get_sector_info.sector);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              {
                UInt8 sector;

                sector = cmd_cto_ptr->get_sector_info.sector;

              #if (XCP_ERROR_CHECK == XCP_ENABLED)
                if (sector >= XCP_MAX_SECTOR)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_OUT_OF_RANGE;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
                {
                  /* send command response packet */
                  if (cmd_cto_ptr->get_sector_info.mode == 0)
                  {
                    res_cto_ptr->get_sector_info.info = xcp_sector_info[sector].address;
                  }
                  else
                  {
                    res_cto_ptr->get_sector_info.info = xcp_sector_info[sector].length;
                  }
                  res_cto_ptr->get_sector_info.clear_number   = xcp_sector_info[sector].clear_sequence_number;
                  res_cto_ptr->get_sector_info.program_number = xcp_sector_info[sector].program_sequence_number;
                  res_cto_ptr->get_sector_info.method         = xcp_sector_info[sector].programming_method;
                  res_cto_length = 8;
                }
              }
              break;
          #endif /* #if (XCP_CMD_GET_SECTOR_INFO == XCP_ENABLED) */

/**** PROGRAM_PREPARE *********************************************************/
          #if (XCP_CMD_PROGRAM_PREPARE == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_PREPARE:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_PREPARE(%i)",
                              cmd_cto_ptr->program_prepare.codesize);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              /* check if download of flash kernel is currently allowed */
              if (DSXCP_program_prepare(xcp_struct[service_no].mta_ptr, cmd_cto_ptr->program_prepare.codesize) != DSXCP_NO_ERROR)
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_GENERIC;
                res_cto_length = 2;
              }
              else
              {
                xcp_struct[service_no].pgm_status |= XCP_PGM_STATUS_PREPARED;

                /* send command response packet */
                res_cto_length = 1;
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_PREPARE == XCP_ENABLED) */

/**** PROGRAM_FORMAT **********************************************************/
          #if (XCP_CMD_PROGRAM_FORMAT == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_FORMAT:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_FORMAT(%i, %i, %i, %i)",
                              cmd_cto_ptr->program_format.compression,
                              cmd_cto_ptr->program_format.encryption,
                              cmd_cto_ptr->program_format.programming,
                              cmd_cto_ptr->program_format.access);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

                /* Not implemented yet. */
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
                res_cto_length = 2;
              break;
          #endif /* #if (XCP_CMD_PROGRAM_FORMAT == XCP_ENABLED) */

/**** PROGRAM_NEXT ************************************************************/
          #if (XCP_CMD_PROGRAM_NEXT == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_NEXT:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_NEXT(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->program_next.no_of_elements,
                              cmd_cto_ptr->program_next.data[0],
                              cmd_cto_ptr->program_next.data[1],
                              cmd_cto_ptr->program_next.data[2],
                              cmd_cto_ptr->program_next.data[3],
                              cmd_cto_ptr->program_next.data[4],
                              cmd_cto_ptr->program_next.data[5]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (cmd_cto_ptr->program_next.no_of_elements != xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining) /* check consistency */
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_ptr->error.info[0] = xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining;
                res_cto_length = 3;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
                UInt8 no_of_elements;

                no_of_elements = cmd_cto_ptr->program_next.no_of_elements;

                if (no_of_elements > (xcp_max_cto[service_no] - 2))
                {
                  if (DSXCP_program(xcp_struct[service_no].mta_ptr, xcp_max_cto[service_no] - 2, cmd_cto_ptr->program_next.data) == DSXCP_NO_ERROR)
                  {
                    /* post-increment MTA by number of elements */
                    xcp_struct[service_no].mta_ptr += xcp_max_cto[service_no] - 2;
                  #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                    xcp_struct[service_no].mta_info.address += xcp_max_cto[service_no] - 2;
                  #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                    xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining = no_of_elements - (xcp_max_cto[service_no] - 2);
                  }
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_GENERIC;
                    res_cto_length = 2;
                  }
                }
                else
                {
                  if (DSXCP_program(xcp_struct[service_no].mta_ptr, no_of_elements, cmd_cto_ptr->program_next.data) == DSXCP_NO_ERROR)
                  {
                    /* post-increment MTA by number of elements */
                    xcp_struct[service_no].mta_ptr += no_of_elements;
                  #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                    xcp_struct[service_no].mta_info.address += no_of_elements;
                  #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                    xcp_struct[service_no].no_of_mbm_pgm_bytes_remaining = 0;

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_GENERIC;
                    res_cto_length = 2;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_NEXT == XCP_ENABLED) */

/**** PROGRAM_MAX *************************************************************/
          #if (XCP_CMD_PROGRAM_MAX == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_MAX:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_MAX(%i, %i, %i, %i, %i, %i, %i)",
                              cmd_cto_ptr->program_max.data[0],
                              cmd_cto_ptr->program_max.data[1],
                              cmd_cto_ptr->program_max.data[2],
                              cmd_cto_ptr->program_max.data[3],
                              cmd_cto_ptr->program_max.data[4],
                              cmd_cto_ptr->program_max.data[5],
                              cmd_cto_ptr->program_max.data[6]);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

            #if (XCP_ERROR_CHECK == XCP_ENABLED)
              if (!(xcp_struct[service_no].pgm_status & XCP_PGM_STATUS_STARTED))
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_SEQUENCE;
                res_cto_length = 2;
              }
              else
            #endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
              {
              #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                if (DSXCP_memory_access_check(xcp_struct[service_no].mta_info.address, xcp_struct[service_no].mta_info.extension, xcp_max_cto[service_no] - 1, XCP_MEMORY_ACCESS_TYPE_PGM) == DSXCP_MEMORY_ACCESS_DENIED)
                {
                  /* send error packet */
                  res_cto_ptr->pid        = XCP_PID_ERR;
                  res_cto_ptr->error.code = XCP_ERR_ACCESS_DENIED;
                  res_cto_length = 2;
                }
                else
              #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
                {
                  if (DSXCP_program(xcp_struct[service_no].mta_ptr, xcp_max_cto[service_no] - 1, cmd_cto_ptr->program_max.data) == DSXCP_NO_ERROR)
                  {
                    /* post-increment MTA by number of elements */
                    xcp_struct[service_no].mta_ptr += xcp_max_cto[service_no] - 1;
                  #if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
                    xcp_struct[service_no].mta_info.address += xcp_max_cto[service_no] - 1;
                  #endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */

                    /* send command response packet */
                    res_cto_length = 1;
                  }
                  else
                  {
                    /* send error packet */
                    res_cto_ptr->pid        = XCP_PID_ERR;
                    res_cto_ptr->error.code = XCP_ERR_GENERIC;
                    res_cto_length = 2;
                  }
                }
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_MAX == XCP_ENABLED) */

/**** PROGRAM_VERIFY **********************************************************/
          #if (XCP_CMD_PROGRAM_VERIFY == XCP_ENABLED)
            case XCP_CMD_CODE_PROGRAM_VERIFY:
            #if (XCP_DEBUG == XCP_ENABLED)
              msg_info_printf(0, 0, "command received: PROGRAM_VERIFY(%i, %i, %i)",
                              cmd_cto_ptr->program_verify.mode,
                              cmd_cto_ptr->program_verify.type,
                              cmd_cto_ptr->program_verify.value);
            #endif /* #if (XCP_DEBUG == XCP_ENABLED) */

              if (DSXCP_program_verify(cmd_cto_ptr->program_verify.mode, cmd_cto_ptr->program_verify.type, cmd_cto_ptr->program_verify.value) == DSXCP_NO_ERROR)
              {
                /* send command response packet */
                res_cto_length = 1;
              }
              else
              {
                /* send error packet */
                res_cto_ptr->pid        = XCP_PID_ERR;
                res_cto_ptr->error.code = XCP_ERR_VERIFY;
                res_cto_length = 2;
              }
              break;
          #endif /* #if (XCP_CMD_PROGRAM_VERIFY == XCP_ENABLED) */

            default:
              /* send error packet */
              res_cto_ptr->pid        = XCP_PID_ERR;
              res_cto_ptr->error.code = XCP_ERR_CMD_UNKNOWN;
              res_cto_length = 2;
              break;
          }
        }
      }
    }
  }

#if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED))
  /* release the pointer to the CMD packet before sending the RES packet */
  xcp_receive_ptr_release(service_no);
#endif /* #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED)) */

  /* check if a response packet needs to be sent */
  if (res_cto_length > 0)
  {
    /* send RES CTO */
    xcp_res_cto_send(service_no, res_cto_length);
  }
}


#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_stim_proc
*
*
*  SYNTAX
*    void xcp_stim_proc(unsigned int service_no, UInt8 *stim_dto, UInt8 pid_off_flag, UInt16 daq_list_no)
*
*  DESCRIPTION
*    This function is the data stimulation processor.
*
*  PARAMETERS
*    service_no:   service instance number (0 or 1)
*    stim_dto:     pointer to STIM DTO
*    pid_off_flag: flag if PID_OFF is used (1) or not (0)
*    daq_list_no:  daq list number (if pid_off_flag is 1)
*
*  RETURNS
*    none
*
*  REMARKS
*    STIM is only implemented for service instance 0.
*
*******************************************************************************/
void xcp_stim_proc(unsigned int service_no, UInt8 *stim_dto, UInt8 pid_off_flag, UInt16 daq_list_no)
{
  /* service_no must equal 0 and DAQ must be running */
  if ((service_no == 0) && (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_DAQ_RUNNING))
  {
    xcp_stim_dto_t *stim_dto_ptr;
    UInt16         daq = 0;
    UInt8          pid = 0;
    UInt8          valid_flag = 0;  /* default: DAQ list number is invalid */

    stim_dto_ptr = (xcp_stim_dto_t *)stim_dto;

  #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED)
    if (pid_off_flag == 1)
    {
      /* corresponding DAQ list is stored in parameter "daq_list_no" */
      daq = daq_list_no;

      /* check if DAQ list number is valid */
      if (daq < xcp_struct[service_no].max_daq)
      {
        if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_PID_OFF)
        {
          pid = (UInt8)xcp_struct[service_no].daq_list[daq].first_odt;
          valid_flag = 1;
        }
      }
    }
  #else
    UNREFERENCED_PARAMETER(pid_off_flag);
    UNREFERENCED_PARAMETER(daq_list_no);
  #endif /* #if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED) */
    if (valid_flag == 0)
    {
      UInt8 last_pid;

      daq      = 0;
      pid      = stim_dto_ptr->data[0];
      last_pid = xcp_struct[service_no].daq_list[daq].no_of_odts - 1;

      /* get corresponding DAQ list from PID by iterating over all DAQ lists */
      while ((daq < xcp_struct[service_no].max_daq) && (pid > last_pid))
      {
        daq++;
        last_pid += xcp_struct[service_no].daq_list[daq].no_of_odts;
      }

      /* check if DAQ list number is valid */
      if (daq < xcp_struct[service_no].max_daq)
      {
        valid_flag = 1;
      }
    }

    /* copy data only if DAQ list number is valid */
    if (valid_flag == 1)
    {
      xcp_daq_list_t *daq_list_ptr;

      DSXCP_INT_SAVE_AND_DISABLE();

      daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

      /* DAQ list must be running and have direction STIM */
      if ((daq_list_ptr->mode & XCP_DAQ_LIST_MODE_RUNNING) && (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_DIRECTION))
      {
        unsigned int i;

      #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
        unsigned int write_buffer;

        /* write_buffer points to buffer, which is not consistent */
        write_buffer = daq_list_ptr->double_buffer_active;
      #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */

        daq_list_ptr->consistent_flag = 0;

        /* copy STIM data into buffer */
        for (i = 0; i < XCP_MAX_DTO_0; i++)
        {
        #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
          xcp_dto_buffer_0[write_buffer][pid].data[i] = stim_dto_ptr->data[i];
        #else /* (XCP_DOUBLE_BUFFER == XCP_DISABLED) */
          xcp_dto_buffer_0[0][pid].data[i] = stim_dto_ptr->data[i];
        #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
        }

        /* check if DAQ list is consistent */
        /* if (pid == (daq_list_ptr->first_odt + daq_list_ptr->no_of_configured_odts - 1)) */
        if ((pid + 1) == (daq_list_ptr->first_odt + daq_list_ptr->no_of_configured_odts))
        {
          /* DAQ list is consistent */
          daq_list_ptr->once_consistent_flag = 1;
          daq_list_ptr->consistent_flag = 1;

        #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
          /* switch active double buffer to inconsistent one */
          if (daq_list_ptr->byp_mode & XCP_DAQ_LIST_BYP_MODE_DOUBLE_BUFFER)
          {
            daq_list_ptr->double_buffer_active ^= 0x1;
          }
        #endif
        }
        else
        {
          /* DAQ list is not consistent */
          daq_list_ptr->consistent_flag = 0;
        }
      }

      DSXCP_INT_RESTORE();
    }
  }
}
#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */


#if (XCP_EVENT_PROCESSING == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_ev_proc
*
*
*  SYNTAX
*    void xcp_ev_proc(unsigned int service_no)
*
*  DESCRIPTION
*    This function is the event processor.
*    It checks for a pending event and sends an appropriate EV packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_ev_proc(unsigned int service_no)
{
  if (xcp_struct[service_no].pending_status & XCP_PENDING_EVENT)
  {
    xcp_res_cto_t *res_cto_ptr;

    /* try to get pointer to free buffer element of RES CTO buffer */
    if ((res_cto_ptr = (xcp_res_cto_t *)xcp_res_cto_ptr_get(service_no)) != NULL)
    {
      res_cto_ptr->pid        = XCP_PID_EV;
      res_cto_ptr->event.code = xcp_struct[service_no].event_code;

    #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED))
      if (xcp_struct[service_no].event_code == XCP_EV_RESUME_MODE)
      {
        *((UInt16*)&res_cto_ptr->event.info[0]) = xcp_struct[service_no].session_id;
      #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
        /* send resume mode event with timestamp */
        *((UInt32*)&res_cto_ptr->event.info[2]) = DSXCP_get_timestamp();
        xcp_res_cto_send(service_no, 8);
      #else /* (XCP_TIMESTAMP_SUPPORTED == XCP_DISABLED) */
        /* send resume mode event without timestamp */
        xcp_res_cto_send(service_no, 4);
      #endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */

        xcp_struct[service_no].pending_status &= ~XCP_PENDING_EVENT;
      }
      else
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED)) */
      {
        /* send EV CTO */
        xcp_res_cto_send(service_no, 2);

        xcp_struct[service_no].pending_status &= ~XCP_PENDING_EVENT;
      }
    }
  }
}
#endif /* #if (XCP_EVENT_PROCESSING == XCP_ENABLED) */


#if (XCP_CMD_SET_MTA == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_set_mta
*
*
*  SYNTAX
*    void xcp_set_mta(unsigned int service_no, UInt32 address, UInt8 extension)
*
*  DESCRIPTION
*    This function sets the MTA to the given address and extension.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    address:    address
*    extension:  address extension
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_set_mta(unsigned int service_no, UInt32 address, UInt8 extension)
{
#if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
  xcp_struct[service_no].mta_info.address   = address;
  xcp_struct[service_no].mta_info.extension = extension;
#endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
  xcp_struct[service_no].mta_ptr            = DSXCP_get_address_pointer(address, extension);
}
#endif /* #if (XCP_CMD_SET_MTA == XCP_ENABLED) */


#if ((XCP_CMD_UPLOAD == XCP_ENABLED) || (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED))
/*******************************************************************************
*
*  FUNCTION
*    xcp_upload_from_mta
*
*
*  SYNTAX
*    void xcp_upload_from_mta(unsigned int service_no, UInt8 *destination_address, UInt8 no_of_elements)
*
*  DESCRIPTION
*    This function uploads the given number of elements starting at the current
*    address of the MTA to the given destination address.
*
*  PARAMETERS
*    service_no:          service instance number (0 or 1)
*    destination_address: destination address
*    no_of_elements:      number of elements
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_upload_from_mta(unsigned int service_no, UInt8 *destination_address, UInt8 no_of_elements)
{
  /* copy data from MTA to destination address */
  while (no_of_elements > 0)
  {
    *destination_address = *xcp_struct[service_no].mta_ptr;
    destination_address++;
    xcp_struct[service_no].mta_ptr++;
    no_of_elements--;
  }

#if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
  /* post-increment MTA by number of elements */
  xcp_struct[service_no].mta_info.address += no_of_elements;
#endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
}
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) || (XCP_CMD_SHORT_UPLOAD == XCP_ENABLED)) */


#if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED))
/*******************************************************************************
*
*  FUNCTION
*    xcp_block_upload
*
*
*  SYNTAX
*    void xcp_block_upload(unsigned int service_no)
*
*  DESCRIPTION
*    This function is called if a slave block mode is pending.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_block_upload(unsigned int service_no)
{
  xcp_res_cto_t *res_cto_ptr;

  /* try to get pointer to free buffer element of RES CTO buffer */
  if ((res_cto_ptr = (xcp_res_cto_t *)xcp_res_cto_ptr_get(service_no)) != NULL)
  {
    UInt8 no_of_elements;

    if (xcp_struct[service_no].no_of_sbm_bytes_remaining > (xcp_max_cto[service_no] - 1))
    {
      no_of_elements = xcp_max_cto[service_no] - 1;
    }
    else
    {
      no_of_elements = xcp_struct[service_no].no_of_sbm_bytes_remaining;
    }

    /* upload data from MTA */
    xcp_upload_from_mta(service_no, res_cto_ptr->upload.data, no_of_elements);
    xcp_struct[service_no].no_of_sbm_bytes_remaining -= no_of_elements;

  #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
    if (xcp_struct[service_no].pending_status & XCP_PENDING_UPLOAD_INFO)
    {
      xcp_struct[service_no].no_of_upload_info_bytes_remaining -= no_of_elements;
      if (xcp_struct[service_no].no_of_upload_info_bytes_remaining == 0)
      {
        xcp_struct[service_no].pending_status &= ~XCP_PENDING_UPLOAD_INFO;
      }
    }
  #endif /* #if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED)) */

    /* send command response packet */
    res_cto_ptr->pid = XCP_PID_RES;

    /* send RES CTO */
    xcp_res_cto_send(service_no, no_of_elements + 1);
  }
}
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)) */


#if (XCP_CMD_DOWNLOAD == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_download_to_mta
*
*
*  SYNTAX
*    void xcp_download_to_mta(unsigned int service_no, UInt8 *source_address, UInt8 no_of_elements)
*
*  DESCRIPTION
*    This function downloads the given number of elements starting at the given
*    source address to the current address of the MTA.
*
*  PARAMETERS
*    service_no:     service instance number (0 or 1)
*    source_address: source address
*    no_of_elements: number of elements
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_download_to_mta(unsigned int service_no, UInt8 *source_address, UInt8 no_of_elements)
{
  /* copy data from source address to MTA */
  while (no_of_elements > 0)
  {
    *xcp_struct[service_no].mta_ptr = *source_address;
    xcp_struct[service_no].mta_ptr++;
    source_address++;
    no_of_elements--;
  }

#if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
  /* post-increment MTA by number of elements */
  xcp_struct[service_no].mta_info.address += no_of_elements;
#endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
}
#endif /* #if (XCP_CMD_DOWNLOAD == XCP_ENABLED) */


#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED))
/*******************************************************************************
*
*  FUNCTION
*    xcp_store_cal_request
*
*
*  SYNTAX
*    void xcp_store_cal_request(unsigned int service_no)
*
*  DESCRIPTION
*    This function executes the request to save the calibration data of the
*    active page of all selected segments into non-volatile memory.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_store_cal_request(unsigned int service_no)
{
  UInt8 segment;
  UInt8 pending_flag;

  segment = 0;
  pending_flag = 0;

  /* iterate over all segments */
  while ((segment < XCP_MAX_SEGMENT) && (pending_flag == 0))
  {
    /* check if segment is in freeze mode */
    if (xcp_struct[service_no].segment_mode[segment] == XCP_SEGMENT_MODE_FREEZE)
    {
      /* current segment is in freeze mode, store calibration page */
      if (DSXCP_store_cal_page(segment) == DSXCP_NO_ERROR)
      {
        /* storing of calibration page successful, reset freeze mode flag */
        xcp_struct[service_no].segment_mode[segment] = 0;
      }
      else
      {
        pending_flag = 1;
      }
    }
    segment++;
  }

  /* if no segment is in freeze mode, update session status and send EV CTO */
  if (pending_flag == 0)
  {
    xcp_struct[service_no].session_status &= ~XCP_SESSION_STATUS_STORE_CAL_REQUEST;
    xcp_struct[service_no].pending_status |= XCP_PENDING_EVENT;
    xcp_struct[service_no].event_code = XCP_EV_STORE_CAL;
  }
}
#endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)) */


#if ((XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED) && (XCP_CHECKSUM_TYPE != XCP_CHECKSUM_TYPE_USER_DEFINED))
/*******************************************************************************
*
*  FUNCTION
*    xcp_build_checksum
*
*
*  SYNTAX
*    UInt32 xcp_build_checksum(xcp_mta_ptr_t ptr, UInt32 size)
*
*  DESCRIPTION
*    This function calculates the checksum of the memory range specified
*    by ptr and size.
*    The type of the calculated checksum depends on the configuration option
*    XCP_CHECKSUM_TYPE.
*
*  PARAMETERS
*    ptr:  pointer to start of memory range
*    size: size of memory range
*
*  RETURNS
*    checksum
*
*  REMARKS
*
*******************************************************************************/
static UInt32 xcp_build_checksum(xcp_mta_ptr_t ptr, UInt32 size)
{
#if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_11)

  UInt8 checksum = 0x00;

  while (size-- > 0)
  {
    checksum += *(ptr++);
  }
  return ((UInt32)checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_12)

  UInt16 checksum = 0x0000;

  while (size-- > 0)
  {
    checksum += *(ptr++);
  }
  return ((UInt32)checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_14)

  UInt32 checksum = 0x00000000;

  while (size-- > 0)
  {
    checksum += *(ptr++);
  }
  return ((UInt32)checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_22)

  UInt16 checksum = 0x0000;
  UInt16 temp;

  while (size > 0)
  {
    ((UInt8 *)&temp)[0] = ptr[0];
    ((UInt8 *)&temp)[1] = ptr[1];
    checksum += temp;
    ptr = ptr + 2;
    size = size - 2;
  }
  return ((UInt32)checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_24)

  UInt32 checksum = 0x00000000;
  UInt16 temp;

  while (size > 0)
  {
    ((UInt8 *)&temp)[0] = ptr[0];
    ((UInt8 *)&temp)[1] = ptr[1];
    checksum += temp;
    ptr = ptr + 2;
    size = size - 2;
  }
  return (checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_44)

  UInt32 checksum = 0x00000000;
  UInt32 temp;

  while (size > 0)
  {
    ((UInt8 *)&temp)[0] = ptr[0];
    ((UInt8 *)&temp)[1] = ptr[1];
    ((UInt8 *)&temp)[2] = ptr[2];
    ((UInt8 *)&temp)[3] = ptr[3];
    checksum += temp;
    ptr = ptr + 4;
    size = size - 4;
  }
  return (checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16)

  UInt16 checksum = 0x0000;

  while (size-- > 0)
  {
    checksum = ((checksum >> 8) & 0x00FF) ^ xcp_crc16_table[(checksum ^ *(ptr++)) & 0x00FF];
  }
  return ((UInt32)checksum);

#elif (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_16_CCITT)

  UInt16 checksum = 0xFFFF;

  while (size-- > 0)
  {
    checksum = ((checksum << 8) & 0xFF00) ^ xcp_crc16ccitt_table[((checksum >> 8) ^ *(ptr++)) & 0x00FF];
  }
  return ((UInt32)checksum);

#else /* (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_CRC_32) */

  UInt32 checksum = 0xFFFFFFFF;

  while (size-- > 0)
  {
    checksum = ((checksum >> 8) & 0x00FFFFFF) ^ xcp_crc32_table[(checksum ^ *(ptr++)) & 0x000000FF];
  }
  return (checksum ^ 0xFFFFFFFF);

#endif /* #if (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_ADD_11) */
}
#endif /* #if ((XCP_CMD_BUILD_CHECKSUM == XCP_ENABLED) && (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_USER_DEFINED)) */


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_setup
*
*
*  SYNTAX
*    void xcp_daq_setup(unsigned int service_no)
*
*  DESCRIPTION
*    This function sets up all fixed structures and properties of static DAQ
*    lists.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_setup(unsigned int service_no)
{
  if (service_no == 0)
  {
    /* initialization of service instance 0 */

  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
    /* set DAQ list pointer to beginning of DAQ buffer */
    xcp_struct[0].daq_list = (xcp_daq_list_t *)&xcp_daq_buffer_0[0];
    /* all other pointers are configured during dynamic DAQ list allocation */

  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */
    UInt16 daq;
    UInt16 odt;
    UInt16 odt_entry;
    UInt8  no_of_odts;
    UInt8  no_of_odt_entries;

    xcp_struct[0].daq_list  = &xcp_daq_struct_0.daq_list[0];
    xcp_struct[0].odt_entry = &xcp_daq_struct_0.odt_entry[0];
    xcp_struct[0].max_daq   = XCP_MAX_DAQ_0;

    odt       = 0;
    odt_entry = 0;

    /* initialize fixed attributes of all DAQ lists */
    for (daq = 0; daq < XCP_MAX_DAQ_0; daq++)
    {
      no_of_odts        = xcp_daq_list_config_0[daq].no_of_odts;
      no_of_odt_entries = xcp_daq_list_config_0[daq].no_of_odt_entries;

      xcp_struct[0].daq_list[daq].first_odt_entry   = odt_entry;
      xcp_struct[0].daq_list[daq].no_of_odts        = no_of_odts;
      xcp_struct[0].daq_list[daq].no_of_odt_entries = no_of_odt_entries;
      xcp_struct[0].daq_list[daq].first_odt         = odt;
      xcp_struct[0].daq_list[daq].properties        = xcp_daq_list_config_0[daq].properties;

      odt       += no_of_odts;
      odt_entry += (no_of_odts * no_of_odt_entries);
    }

  #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED)
    /* initialize ODT entries of predefined DAQ lists */
    for (odt_entry = 0; odt_entry < XCP_NO_OF_PREDEFINED_ODT_ENTRIES_0; odt_entry++)
    {
    #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
      xcp_struct[0].odt_entry[odt_entry].address     = xcp_predefined_odt_entries_0[odt_entry].address;
    #else
      xcp_struct[0].odt_entry[odt_entry].address_ptr = xcp_predefined_odt_entries_0[odt_entry].address_ptr;
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */
      xcp_struct[0].odt_entry[odt_entry].extension   = xcp_predefined_odt_entries_0[odt_entry].extension;
      xcp_struct[0].odt_entry[odt_entry].size        = xcp_predefined_odt_entries_0[odt_entry].size;
      xcp_struct[0].odt_entry[odt_entry].bit_offset  = xcp_predefined_odt_entries_0[odt_entry].bit_offset;
    }
  #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
  }
#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  else
  {
    /* initialization of service instance 1 */
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
    /* set DAQ list pointer to beginning of DAQ buffer */
    xcp_struct[1].daq_list = (xcp_daq_list_t *)&xcp_daq_buffer_1[0];
    /* all other pointers are configured during dynamic DAQ list allocation */

  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */
    UInt16 daq;
    UInt16 odt;
    UInt16 odt_entry;
    UInt8  no_of_odts;
    UInt8  no_of_odt_entries;

    xcp_struct[1].daq_list  = &xcp_daq_struct_1.daq_list[0];
    xcp_struct[1].odt_entry = &xcp_daq_struct_1.odt_entry[0];
    xcp_struct[1].max_daq   = XCP_MAX_DAQ_1;

    odt       = 0;
    odt_entry = 0;

    /* initialize fixed attributes of all DAQ lists */
    for (daq = 0; daq < XCP_MAX_DAQ_1; daq++)
    {
      no_of_odts        = xcp_daq_list_config_1[daq].no_of_odts;
      no_of_odt_entries = xcp_daq_list_config_1[daq].no_of_odt_entries;

      xcp_struct[1].daq_list[daq].first_odt_entry   = odt_entry;
      xcp_struct[1].daq_list[daq].no_of_odts        = no_of_odts;
      xcp_struct[1].daq_list[daq].no_of_odt_entries = no_of_odt_entries;
      xcp_struct[1].daq_list[daq].first_odt         = odt;
      xcp_struct[1].daq_list[daq].properties        = xcp_daq_list_config_1[daq].properties;

      odt       += no_of_odts;
      odt_entry += (no_of_odts * no_of_odt_entries);
    }

  #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED)
    /* initialize ODT entries of predefined DAQ lists */
    for (odt_entry = 0; odt_entry < XCP_NO_OF_PREDEFINED_ODT_ENTRIES_1; odt_entry++)
    {
    #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
      xcp_struct[1].odt_entry[odt_entry].address     = xcp_predefined_odt_entries_1[odt_entry].address;
    #else
      xcp_struct[1].odt_entry[odt_entry].address_ptr = xcp_predefined_odt_entries_1[odt_entry].address_ptr;
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */
      xcp_struct[1].odt_entry[odt_entry].extension  = xcp_predefined_odt_entries_1[odt_entry].extension;
      xcp_struct[1].odt_entry[odt_entry].size       = xcp_predefined_odt_entries_1[odt_entry].size;
      xcp_struct[1].odt_entry[odt_entry].bit_offset = xcp_predefined_odt_entries_1[odt_entry].bit_offset;
    }
  #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED) */
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
  }
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_init
*
*
*  SYNTAX
*    void xcp_daq_init(unsigned int service_no)
*
*  DESCRIPTION
*    This function initializes all DAQ lists.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_init(unsigned int service_no)
{
  UInt32 i;

  /* reset DAQ flag of session status */
  xcp_struct[service_no].session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;

  if (service_no == 0)
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
    /* reset DAQ buffer for dynamic DAQ list configuration */
    for (i = 0; i < XCP_DAQ_BUFFER_SIZE_0; i++)
    {
      xcp_daq_buffer_0[i] = 0;
    }

    /* reset counters for dynamic DAQ list configuration */
    xcp_struct[0].max_daq           = 0;
    xcp_struct[0].odt_count         = 0;
    xcp_struct[0].odt_entries_count = 0;

  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */
    UInt16 daq;

    /* clear all DAQ lists */
    for (daq = 0; daq < XCP_MAX_DAQ_0; daq++)
    {
      xcp_daq_list_clear(0, daq);
    }
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
  }
#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  else
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
    /* reset DAQ buffer for dynamic DAQ list configuration */
    for (i = 0; i < XCP_DAQ_BUFFER_SIZE_1; i++)
    {
      xcp_daq_buffer_1[i] = 0;
    }

    /* reset counters for dynamic DAQ list configuration */
    xcp_struct[1].max_daq           = 0;
    xcp_struct[1].odt_count         = 0;
    xcp_struct[1].odt_entries_count = 0;

  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */
    UInt16 daq;

    /* clear all DAQ lists */
    for (daq = 0; daq < XCP_MAX_DAQ_1; daq++)
    {
      xcp_daq_list_clear(1, daq);
    }
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
  }
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

#if (XCP_ERROR_CHECK == XCP_ENABLED)
  xcp_struct[service_no].daq_ptr.valid_flag     = XCP_DAQ_PTR_INVALID;
#endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */

#if ((XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) && (XCP_ERROR_CHECK == XCP_ENABLED))
  xcp_struct[service_no].daq_byp_ptr.valid_flag = XCP_DAQ_PTR_INVALID;
#endif /* #if ((XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) && (XCP_ERROR_CHECK == XCP_ENABLED)) */

#if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT))
  xcp_struct[service_no].overload_count = XCP_OVERLOAD_INDICATION_LIMIT - 1;
#endif /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */

  /* reset status of all event channels */
  for (i = 0; i < XCP_MAX_EVENT_CHANNEL; i++)
  {
    xcp_struct[service_no].event_channel[i].first_daq = 0;
    xcp_struct[service_no].event_channel[i].status    = XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED;
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_clear
*
*
*  SYNTAX
*    void xcp_daq_list_clear(unsigned int service_no, UInt16 daq)
*
*  DESCRIPTION
*    This function clears a DAQ list.
*    It resets the values for address and size of all ODT entries of the
*    DAQ list to zero and the bit offset to 0xFF.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_clear(unsigned int service_no, UInt16 daq)
{
  xcp_daq_list_t *daq_list_ptr;
  xcp_entry_t    *odt_entry_ptr;
  UInt16         no_of_odt_entries;
  UInt16         odt_entry;

  daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

  daq_list_ptr->mode                 = 0;
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  daq_list_ptr->byp_mode             = 0;
  daq_list_ptr->timeout_cycle        = 0;
  daq_list_ptr->timeout_unit         = 0;
  daq_list_ptr->double_buffer_active = 0;
  daq_list_ptr->consistent_flag      = 0;
  daq_list_ptr->failure_limit        = 0;
  daq_list_ptr->failure_count        = 0;
  daq_list_ptr->once_consistent_flag = 0;
  daq_list_ptr->timeout_ticks        = 0;
#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

  /* if DAQ list is configurable, clear all ODT entries */
  if (daq >= xcp_min_daq[service_no])
  {
    /* odt_entry_ptr points to first ODT entry of first ODT of DAQ list */
    odt_entry_ptr = &xcp_struct[service_no].odt_entry[daq_list_ptr->first_odt_entry];

    /* determine the total number of ODT entries of DAQ list */
  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
    if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
    {
      UInt8 odt;

      no_of_odt_entries = 0;

      for (odt = 0; odt < daq_list_ptr->no_of_odts; odt++)
      {
        no_of_odt_entries += xcp_struct[service_no].odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
      }
    }
    else
  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
    {
      /* no_of_odt_entries is the total number of ODT entries in current DAQ list */
      no_of_odt_entries = daq_list_ptr->no_of_odts * daq_list_ptr->no_of_odt_entries;
    }

    /* clear all ODT entries */
    for (odt_entry = 0; odt_entry < no_of_odt_entries; odt_entry++)
    {
    #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
      odt_entry_ptr->address     = 0;
    #else
      odt_entry_ptr->address_ptr = 0;
    #endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */
      odt_entry_ptr->extension   = 0;
      odt_entry_ptr->size        = 0;
      odt_entry_ptr->bit_offset  = 0xFF;
      odt_entry_ptr++;
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_start
*
*
*  SYNTAX
*    void xcp_daq_list_start(unsigned int service_no, UInt16 daq)
*
*  DESCRIPTION
*    This function starts a DAQ list.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_start(unsigned int service_no, UInt16 daq)
{
  xcp_daq_list_t *daq_list_ptr;

  daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

  if (daq_list_ptr->mode & XCP_DAQ_LIST_MODE_CONFIGURED)
  {
    UInt8  odt;
    UInt8  no_of_configured_odts;
    UInt16 entry_offset;

    entry_offset          = 0;
    no_of_configured_odts = 0;

    /* determine number of configured ODTs */
  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
    if (xcp_daq_config_type_dynamic[service_no] == XCP_ENABLED)
    {
      entry_offset = xcp_struct[service_no].odt[daq_list_ptr->first_odt].first_odt_entry;

      for (odt = 0; odt < daq_list_ptr->no_of_odts; odt++)
      {
        if (xcp_struct[service_no].odt_entry[entry_offset].size == 0)
        {
          break;
        }
        else
        {
          no_of_configured_odts++;
          entry_offset += xcp_struct[service_no].odt[daq_list_ptr->first_odt + odt].no_of_odt_entries;
        }
      }
    }
    else
  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
    {
      for (odt = 0; odt < daq_list_ptr->no_of_odts; odt++)
      {
        if (xcp_struct[service_no].odt_entry[daq_list_ptr->first_odt_entry + entry_offset].size == 0)
        {
          break;
        }
        else
        {
          no_of_configured_odts++;
          entry_offset += daq_list_ptr->no_of_odt_entries;
        }
      }
    }

    daq_list_ptr->no_of_configured_odts = no_of_configured_odts;

  #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
    daq_list_ptr->cycle = 1;                /* DAQ list will be processed at next event */
  #endif /* #if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED) */

  #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
    daq_list_ptr->double_buffer_active = 0;
    daq_list_ptr->consistent_flag      = 0;
    daq_list_ptr->failure_count        = 0;
    daq_list_ptr->once_consistent_flag = 0;
  #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

  #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
    daq_list_ptr->next_odt = no_of_configured_odts;
  #endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */

    daq_list_ptr->mode &= ~XCP_DAQ_LIST_MODE_SELECTED;
    daq_list_ptr->mode |= XCP_DAQ_LIST_MODE_RUNNING;

    /* set session status to state "DAQ running" */
    xcp_struct[service_no].session_status |= XCP_SESSION_STATUS_DAQ_RUNNING;
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_start_selected
*
*
*  SYNTAX
*    void xcp_daq_list_start_selected(unsigned int service_no)
*
*  DESCRIPTION
*    This function starts all selected DAQ lists.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_start_selected(unsigned int service_no)
{
  UInt16 daq;

  for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
  {
    if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_SELECTED)
    {
      xcp_daq_list_start(service_no, daq);
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_stop
*
*
*  SYNTAX
*    void xcp_daq_list_stop(unsigned int service_no, UInt16 daq)
*
*  DESCRIPTION
*    This function stops a DAQ list.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_stop(unsigned int service_no, UInt16 daq)
{
  xcp_struct[service_no].daq_list[daq].mode &= ~(XCP_DAQ_LIST_MODE_SELECTED | XCP_DAQ_LIST_MODE_RUNNING);
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_stop_selected
*
*
*  SYNTAX
*    void xcp_daq_list_stop_selected(unsigned int service_no)
*
*  DESCRIPTION
*    This function stops all selected DAQ lists.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_stop_selected(unsigned int service_no)
{
  UInt16 daq;

  for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
  {
    if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_SELECTED)
    {
      xcp_daq_list_stop(service_no, daq);
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_stop_all
*
*
*  SYNTAX
*    void xcp_daq_list_stop_all(unsigned int service_no)
*
*  DESCRIPTION
*    This function stops all DAQ lists and resets the DAQ flag of the session
*    status.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_stop_all(unsigned int service_no)
{
  UInt16 daq;

  for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
  {
    xcp_daq_list_stop(service_no, daq);
  }

  xcp_struct[service_no].session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_select
*
*
*  SYNTAX
*    void xcp_daq_list_select(unsigned int service_no, UInt16 daq)
*
*  DESCRIPTION
*    This function selects a DAQ list.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_select(unsigned int service_no, UInt16 daq)
{
  xcp_struct[service_no].daq_list[daq].mode |= XCP_DAQ_LIST_MODE_SELECTED;
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_insert
*
*
*  SYNTAX
*    void xcp_daq_list_insert(unsigned int service_no, UInt16 event_channel, UInt16 daq)
*
*  DESCRIPTION
*    This function adds a DAQ list to the list of DAQ lists of an event
*    channel. The DAQ list will be inserted according to its priority.
*
*  PARAMETERS
*    service_no:    service instance number (0 or 1)
*    event_channel: event channel number
*    daq:           DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_insert(unsigned int service_no, UInt16 event_channel, UInt16 daq)
{
  xcp_daq_list_t *daq_list_ptr;

  daq_list_ptr = &xcp_struct[service_no].daq_list[daq];

  /* if no DAQ list has been assigned to the event channel, the DAQ list
     is assigned as the first one */
  if (xcp_struct[service_no].event_channel[event_channel].status == XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED)
  {
    daq_list_ptr->next_daq = daq;
    xcp_struct[service_no].event_channel[event_channel].first_daq = daq;
    xcp_struct[service_no].event_channel[event_channel].status    = XCP_EVENT_CHANNEL_DAQ_ASSIGNED;
  }
  /* another DAQ list has already been assigned to the event channel; the DAQ list
     is assigned to the event channel according its priority */
  else
  {
    UInt16 first_daq;

    first_daq = xcp_struct[service_no].event_channel[event_channel].first_daq;

    /* if the priority of the DAQ list is higher than the first DAQ list of the
       event channel, the DAQ list is assigned as the first one */
    if (daq_list_ptr->priority > xcp_struct[service_no].daq_list[first_daq].priority)
    {
      daq_list_ptr->next_daq = first_daq;
      xcp_struct[service_no].event_channel[event_channel].first_daq = daq;
    }
    else
    {
      UInt16 current_daq;
      UInt16 next_daq;

      current_daq = first_daq;
      next_daq    = xcp_struct[service_no].daq_list[current_daq].next_daq;

      /* insert the DAQ list before a DAQ list with a lower priority */
      while (current_daq != next_daq)
      {
        if (daq_list_ptr->priority > xcp_struct[service_no].daq_list[next_daq].priority)
        {
          daq_list_ptr->next_daq = next_daq;
          xcp_struct[service_no].daq_list[current_daq].next_daq = daq;
          break;
        }

        current_daq = next_daq;
        next_daq    = xcp_struct[service_no].daq_list[current_daq].next_daq;
      }

      if (current_daq == next_daq)
      {
        daq_list_ptr->next_daq = daq;
        xcp_struct[service_no].daq_list[next_daq].next_daq = daq;
      }
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_daq_list_remove
*
*
*  SYNTAX
*    void xcp_daq_list_remove(unsigned int service_no, UInt16 event_channel, UInt16 daq)
*
*  DESCRIPTION
*    This function removes a DAQ list from the list of DAQ lists of an event
*    channel.
*
*  PARAMETERS
*    service_no:    service instance number (0 or 1)
*    event_channel: event channel number
*    daq:           DAQ list number
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_daq_list_remove(unsigned int service_no, UInt16 event_channel, UInt16 daq)
{
  UInt16 next_daq;

  next_daq = xcp_struct[service_no].event_channel[event_channel].first_daq;

  /* check if there is only one DAQ list assigned to the event channel */
  if (next_daq == xcp_struct[service_no].daq_list[next_daq].next_daq)
  {
    xcp_struct[service_no].event_channel[event_channel].status = XCP_EVENT_CHANNEL_NO_DAQ_ASSIGNED;
  }
  else
  {
    UInt16 first_daq;

    first_daq = xcp_struct[service_no].event_channel[event_channel].first_daq;

    if (first_daq == daq)
    {
      xcp_struct[service_no].event_channel[event_channel].first_daq = xcp_struct[service_no].daq_list[first_daq].next_daq;
    }
    else
    {
      UInt16 current_daq;

      current_daq = first_daq;
      next_daq    = xcp_struct[service_no].daq_list[current_daq].next_daq;

      /* insert the DAQ list before a DAQ list with a lower priority */
      while (current_daq != next_daq)
      {
        if (daq == next_daq)
        {
          if (xcp_struct[service_no].daq_list[next_daq].next_daq == next_daq)
          {
            xcp_struct[service_no].daq_list[current_daq].next_daq = current_daq;
          }
          else
          {
            xcp_struct[service_no].daq_list[current_daq].next_daq = xcp_struct[service_no].daq_list[next_daq].next_daq;
          }
          break;
        }

        current_daq = next_daq;
        next_daq    = xcp_struct[service_no].daq_list[current_daq].next_daq;
      }
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_check_daq_running
*
*
*  SYNTAX
*    void xcp_check_daq_running(unsigned int service_no)
*
*  DESCRIPTION
*    This function checks, if at least one DAQ list is still started after
*    stopping one or more DAQ lists.
*    It affects the session status of the dSPACE XCP service accordingly.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_check_daq_running(unsigned int service_no)
{
  UInt16 daq;

  /* iterate over all DAQ lists */
  for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
  {
    /* check if current DAQ list is started */
    if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_RUNNING)
    {
      return;
    }
  }
  /* no DAQ list is started, reset DAQ flag of session status */
  xcp_struct[service_no].session_status &= ~XCP_SESSION_STATUS_DAQ_RUNNING;
}


#if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
/*******************************************************************************
*
*  FUNCTION
*    xcp_check_daq_memory_overflow
*
*
*  SYNTAX
*    unsigned int xcp_check_daq_memory_overflow(unsigned int service_no)
*
*  DESCRIPTION
*    This function checks for a memory overflow in case of dynamic DAQ
*    configuration.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    0 if there is no memory overflow, else 1
*
*  REMARKS
*
*******************************************************************************/
static unsigned int xcp_check_daq_memory_overflow(unsigned int service_no)
{
  UInt32 size = 0;

  /* determine the required size for the current DAQ configuration */
  if (service_no == 0)
  {
#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
    size = (xcp_struct[service_no].max_daq           * sizeof(xcp_daq_list_t)) +
           (xcp_struct[service_no].odt_count         * sizeof(xcp_odt_t)) +
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
           (xcp_struct[service_no].odt_count         * sizeof(dto_buffer_element0_t)) +
#if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
           (xcp_struct[service_no].odt_count         * sizeof(dto_buffer_element0_t)) +
#if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
           (xcp_struct[service_no].odt_count         * sizeof(dto_buffer_element0_t)) +
#endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
#endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
#elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
           (xcp_struct[service_no].odt_count         * sizeof(dto_buffer_element0_t)) +
#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
          (xcp_struct[service_no].odt_entries_count * sizeof(xcp_entry_t));
#endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
  }
#if ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))
  else
  {
    size = (xcp_struct[service_no].max_daq           * sizeof(xcp_daq_list_t)) +
           (xcp_struct[service_no].odt_count         * sizeof(xcp_odt_t)) +
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
           (xcp_struct[service_no].odt_count         * sizeof(dto_buffer_element1_t)) +
#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
          (xcp_struct[service_no].odt_entries_count * sizeof(xcp_entry_t));
  }
#endif /* #if ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)) */
  /* check if required size exceeds DAQ buffer size */
  if (size > xcp_daq_buffer_size[service_no])
  {
    /* reset number of DAQ lists to 0 */
    xcp_struct[service_no].max_daq = 0;

    /* return memory overflow */
    return (1);
  }
  else
  {
    /* return no memory overflow */
    return (0);
  }
}
#endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */


#if (XCP_RESUME_MODE == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_resume_mode_init
*
*
*  SYNTAX
*    void xcp_resume_mode_init(unsigned int service_no)
*
*  DESCRIPTION
*    This function initializes all DAQ data required to start in resume mode.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_resume_mode_init(unsigned int service_no)
{
  UInt16 session_id;
  UInt16 max_daq;
  UInt8  *pl_data_ptr;
  UInt8  *tl_data_ptr;
  UInt32 pl_data_size;
  UInt32 tl_data_size;

  if (service_no == 0)
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
    pl_data_ptr  = &xcp_daq_buffer_0[0];
    pl_data_size = sizeof(xcp_daq_buffer_0);
  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */
    pl_data_ptr  = (UInt8 *)&xcp_daq_struct_0;
    pl_data_size = sizeof(xcp_daq_struct_0);
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
  }
#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  else
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
    pl_data_ptr  = &xcp_daq_buffer_1[0];
    pl_data_size = sizeof(xcp_daq_buffer_1);
  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */
    pl_data_ptr  = (UInt8 *)&xcp_daq_struct_1;
    pl_data_size = sizeof(xcp_daq_struct_1);
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
  }
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

  tl_data_ptr = xcp_tl_resume_data_ptr_get(service_no, &tl_data_size);

  if (DSXCP_init_resume_mode_data(service_no, &session_id, &max_daq, pl_data_ptr, pl_data_size, tl_data_ptr, tl_data_size) == DSXCP_NO_ERROR)
  {
    UInt16 daq;
    UInt16 no_of_odts;

    no_of_odts = 0;

    /*
     * configure pointer to ODTs
     */
    for (daq = 0; daq < max_daq; daq++)
    {
      no_of_odts += xcp_struct[service_no].daq_list[daq].no_of_odts;
    }

    if (service_no == 0)
    {
    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
      xcp_struct[0].odt         = (xcp_odt_t *)&xcp_daq_buffer_0[max_daq * sizeof(xcp_daq_list_t)];
    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
      xcp_dto_buffer_0[0] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t))];
    #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
      xcp_dto_buffer_0[1] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t))];
    #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
      xcp_dto_buffer_0[2] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t) * 2)];
    #endif /* #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED) */
    #endif /* #if (XCP_DOUBLE_BUFFER == XCP_ENABLED) */
    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
      xcp_dto_buffer_0[0] = (dto_buffer_element0_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t))];
    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */

    #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
    #if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
    #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t) * 3)];
    #else
      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t) * 2)];
    #endif
    #else
      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t))];
    #endif
    #elif (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element0_t))];
    #else
      xcp_struct[0].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_0[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t))];
    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
    }
  #if (XCP_NO_OF_SERVICE_INSTANCES == 2)
    else
    {
    #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
      xcp_struct[1].odt         = (xcp_odt_t *)&xcp_daq_buffer_1[max_daq * sizeof(xcp_daq_list_t)];
    #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
      xcp_dto_buffer_1[0] = (dto_buffer_element1_t *)&xcp_daq_buffer_1[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t))];
      xcp_struct[1].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_1[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t)) + (no_of_odts * sizeof(dto_buffer_element1_t))];
    #else
      xcp_struct[1].odt_entry   = (xcp_entry_t *)&xcp_daq_buffer_1[(max_daq * sizeof(xcp_daq_list_t)) + (no_of_odts * sizeof(xcp_odt_t))];
    #endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
    #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
    }
  #endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

    /*
     * assign all DAQ lists which are in resume mode to the corresponding event
     * channels and start them
     */
    for (daq = 0; daq < max_daq; daq++)
    {
      xcp_daq_list_insert(service_no, xcp_struct[service_no].daq_list[daq].event_channel, daq);

      if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_RESUME)
      {
        xcp_daq_list_start(service_no, daq);
      }
    }

    /* set session configuration id which belongs to the resume mode data */
    xcp_struct[service_no].session_id = session_id;

    /* set the number of DAQ lists  */
    xcp_struct[service_no].max_daq = max_daq;

    if (xcp_struct[service_no].session_status |= XCP_SESSION_STATUS_DAQ_RUNNING)
    {
      /* set session status to state "resume mode" */
      xcp_struct[service_no].session_status |= XCP_SESSION_STATUS_RESUME;

      /* send event packet */
      xcp_struct[service_no].event_code     = XCP_EV_RESUME_MODE;
      xcp_struct[service_no].pending_status = XCP_PENDING_EVENT;
      xcp_ev_proc(service_no);
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_store_daq_request
*
*
*  SYNTAX
*    void xcp_store_daq_request(unsigned int service_no)
*
*  DESCRIPTION
*    This function executes the request to store all selected DAQ lists into
*    non-volatile memory.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_store_daq_request(unsigned int service_no)
{
  UInt8  *pl_data_ptr;
  UInt8  *tl_data_ptr;
  UInt32 pl_data_size;
  UInt32 tl_data_size;
  UInt16 daq;

  if (service_no == 0)
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
    pl_data_ptr = &xcp_daq_buffer_0[0];
    pl_data_size = sizeof(xcp_daq_buffer_0);
  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */
    pl_data_ptr = (UInt8 *)&xcp_daq_struct_0;
    pl_data_size = sizeof(xcp_daq_struct_0);
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */
  }
#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  else
  {
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
    pl_data_ptr = &xcp_daq_buffer_1[0];
    pl_data_size = sizeof(xcp_daq_buffer_1);
  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */
    pl_data_ptr = (UInt8 *)&xcp_daq_struct_1;
    pl_data_size = sizeof(xcp_daq_struct_1);
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
  }
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

  tl_data_ptr = xcp_tl_resume_data_ptr_get(service_no, &tl_data_size);

  for (daq = 0; daq < xcp_struct[service_no].max_daq; daq++)
  {
    if (xcp_struct[service_no].daq_list[daq].mode & XCP_DAQ_LIST_MODE_SELECTED)
    {
      /* clear SELECTED flag of DAQ list */
      xcp_struct[service_no].daq_list[daq].mode &= ~XCP_DAQ_LIST_MODE_SELECTED;

      if (xcp_struct[service_no].session_status & XCP_SESSION_STATUS_STORE_DAQ_REQUEST)
      {
        /* set RESUME_MODE flag of DAQ list */
        xcp_struct[service_no].daq_list[daq].mode |= XCP_DAQ_LIST_MODE_RESUME;
      }
    }
  }

  if (DSXCP_store_resume_mode_data(service_no, xcp_struct[service_no].session_id, xcp_struct[service_no].max_daq, pl_data_ptr, pl_data_size, tl_data_ptr, tl_data_size) == DSXCP_NO_ERROR)
  {
    xcp_struct[service_no].session_status &= ~(XCP_SESSION_STATUS_STORE_DAQ_REQUEST | XCP_SESSION_STATUS_STORE_DAQ_NO_RESUME_REQUEST);
    xcp_struct[service_no].event_code = XCP_EV_STORE_DAQ;
    xcp_struct[service_no].pending_status |= XCP_PENDING_EVENT;
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_clear_daq_request
*
*
*  SYNTAX
*    void xcp_clear_daq_request(unsigned int service_no)
*
*  DESCRIPTION
*    This function executes the request to clear all DAQ lists in non-volatile
*    memory.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
static void xcp_clear_daq_request(unsigned int service_no)
{
  if (DSXCP_clear_resume_mode_data(service_no) == DSXCP_NO_ERROR)
  {
    xcp_struct[service_no].session_status &= ~XCP_SESSION_STATUS_CLEAR_DAQ_REQUEST;
    xcp_struct[service_no].event_code = XCP_EV_CLEAR_DAQ;
    xcp_struct[service_no].pending_status |= XCP_PENDING_EVENT;
  }
}

#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */

#endif /* #ifndef DSXCP_SERVICE_DISABLED */
