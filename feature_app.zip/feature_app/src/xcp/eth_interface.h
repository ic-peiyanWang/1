/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must retain this notice.
 *
 */
#pragma  once

#include <memory>

#include "inetAddr.h"
#include "tcpServer.h"

void TcpServerStart(int port);

extern net::tcpServer TCPServerDBG;
extern net::tcpServer TCPServerSIN;
extern net::tcpServer TCPServerTOT;
extern std::unique_ptr<net::tcpServer> TCPServerXCP;
