/*******************************************************************************
*
*  FILE
*    xcp_prot_cfg.h
*
*  DESCRIPTION
*    This file contains configuration options for the protocol layer of the
*    dSPACE XCP Service, which must be configured by the ECU developer in the
*    outlined sections. All other parts of this file must remain unaltered.
*
*  COPYRIGHT
*    Copyright 2015, dSPACE GmbH. All rights reserved.
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*    Only outlined sections may be edited by the ECU developer. All other
*    sections must remain unaltered!
*
*  AUTHOR(S)
*    Bastian Kellers
*    Artur Wolf
*
*  VERSION
*    2.4.0
*
*  $RCSfile: xcp_prot_cfg.h $ $Revision: 1.22 $ $Date: 2015/12/15 17:37:40MEZ $
*
*******************************************************************************/
#ifndef __XCP_PROT_CFG_H__
#define __XCP_PROT_CFG_H__

/**** start of implementation specific code ***********************************/

#include "xcp_veos.h"

/**** end of implementation specific code *************************************/


/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

#ifndef NULL
  #define NULL (nullptr)
#endif

/* defines for enabling/disabling XCP features */
#ifndef XCP_DISABLED
  #define XCP_DISABLED                            0
#endif
#ifndef XCP_ENABLED
  #define XCP_ENABLED                             1
#endif

/* transport layer types */
#define XCP_TRANSPORT_LAYER_TYPE_CAN              1
#define XCP_TRANSPORT_LAYER_TYPE_USB              2
#define XCP_TRANSPORT_LAYER_TYPE_ETH              3
#define XCP_TRANSPORT_LAYER_TYPE_FLX              4

/* byte order */
#define XCP_BYTE_ORDER_INTEL                      0
#define XCP_BYTE_ORDER_MOTOROLA                   1

/* XCP sizes */
#define XCP_SIZE_BYTE                             1
#define XCP_SIZE_WORD                             2
#define XCP_SIZE_DWORD                            4
#define XCP_SIZE_QWORD                            8

/* XCP checksum types */
#define XCP_CHECKSUM_TYPE_ADD_11                  0x01
#define XCP_CHECKSUM_TYPE_ADD_12                  0x02
#define XCP_CHECKSUM_TYPE_ADD_14                  0x03
#define XCP_CHECKSUM_TYPE_ADD_22                  0x04
#define XCP_CHECKSUM_TYPE_ADD_24                  0x05
#define XCP_CHECKSUM_TYPE_ADD_44                  0x06
#define XCP_CHECKSUM_TYPE_CRC_16                  0x07
#define XCP_CHECKSUM_TYPE_CRC_16_CCITT            0x08
#define XCP_CHECKSUM_TYPE_CRC_32                  0x09
#define XCP_CHECKSUM_TYPE_USER_DEFINED            0xFF

/* DAQ timestamp unit */
#define XCP_TIMESTAMP_UNIT_1NS                    0
#define XCP_TIMESTAMP_UNIT_10NS                   1
#define XCP_TIMESTAMP_UNIT_100NS                  2
#define XCP_TIMESTAMP_UNIT_1US                    3
#define XCP_TIMESTAMP_UNIT_10US                   4
#define XCP_TIMESTAMP_UNIT_100US                  5
#define XCP_TIMESTAMP_UNIT_1MS                    6
#define XCP_TIMESTAMP_UNIT_10MS                   7
#define XCP_TIMESTAMP_UNIT_100MS                  8
#define XCP_TIMESTAMP_UNIT_1S                     9
#define XCP_TIMESTAMP_UNIT_1PS                    10
#define XCP_TIMESTAMP_UNIT_10PS                   11
#define XCP_TIMESTAMP_UNIT_100PS                  12

/* DAQ overload indication types */
#define XCP_OVERLOAD_INDICATION_TYPE_MSB          1
#define XCP_OVERLOAD_INDICATION_TYPE_EVENT        2


/**** start of implementation specific code ***********************************/



/**** configuration of common/global features *********************************/

/* type definition of the MTA pointer */
typedef unsigned char* xcp_mta_ptr_t;

/* Message id for XCP */
#define XCP_MODULE_ID                       212

#ifdef VEOS_DEBUG
  #define XCP_DEBUG                         XCP_ENABLED
  #define msg_info_printf(moduleNumber, serviceNumber, format, ...) VEOS_MsgApi_LogMessage(XCP_MODULE_ID, serviceNumber, format, ##__VA_ARGS__)
#else
  #define XCP_DEBUG                         XCP_DISABLED
  #define msg_info_printf
#endif

/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

/* This define specifies the number of service instances (1 or 2) */
#define XCP_NO_OF_SERVICE_INSTANCES         2

/*
 * This define specifies the kind of transport layer for each service instance
 * Supported transport layers:
 * XCP_TRANSPORT_LAYER_TYPE_ETH
 */
#define XCP_TRANSPORT_LAYER_TYPE_0          XCP_TRANSPORT_LAYER_TYPE_ETH
#define XCP_TRANSPORT_LAYER_TYPE_1          XCP_TRANSPORT_LAYER_TYPE_ETH

/* error check of command parameters */
#define XCP_ERROR_CHECK                     XCP_ENABLED

/* memory protection */
#define XCP_MEMORY_PROTECTION               XCP_ENABLED


/**** configuration of communication features *********************************/

/*
 * If CTO packets are received via the CAN RX interrupt,
 * this option must be enabled. Else, the XCP service
 * polls for new CTO packets in the background.
 */
#define XCP_RX_INT                          XCP_DISABLED

/*
 * If this option is enabled, the XCP service uses the
 * CAN TX interrupt for sending high priority DTO packets
 * via callback.
 * Else, those DTO packets will be sent in the background.
 */
#define XCP_TX_INT                          XCP_DISABLED

/*
 * If this option is enabled, XCP commands are processed
 * in the background independent from the configuration if
 * the CAN RX interrupt is used or not.
 * If this option is disabled XCP commands are processed
 * in the foreground. In this case the CAN RX interrupt must
 * be enabled, else this setting will be ignored and XCP
 * commands are processed in the background instead.
 */
#define XCP_COMMAND_MODE_BACKGROUND         XCP_ENABLED

/* slave block mode */
#define XCP_SLAVE_BLOCK_MODE                XCP_ENABLED

/* master block mode */
#define XCP_MASTER_BLOCK_MODE               XCP_DISABLED


/**** standard XCP features ***************************************************/

/*
 * The dSPACE XCP service supports the following XCP resources:
 * CAL/PAG, DAQ and PGM
 */
#define XCP_RESOURCE_SUPPORTED_CAL_PAG      XCP_ENABLED
#define XCP_RESOURCE_SUPPORTED_DAQ          XCP_ENABLED
#define XCP_RESOURCE_SUPPORTED_PGM          XCP_DISABLED

/*
 * The dSPACE XCP service supports the protection of the following XCP
 * resources:
 * CAL/PAG (only together), DAQ, STIM and PGM
 * If the configuration option XCP_RESOURCE_PROTECTION is enabled, all XCP
 * resources may be configured individually to be protected or not.
 */
#define XCP_RESOURCE_PROTECTION             XCP_DISABLED

/* protected resources */
#define XCP_RESOURCE_PROTECTION_CAL_PAG     XCP_DISABLED
#define XCP_RESOURCE_PROTECTION_DAQ         XCP_DISABLED
#define XCP_RESOURCE_PROTECTION_STIM        XCP_DISABLED
#define XCP_RESOURCE_PROTECTION_PGM         XCP_DISABLED

/* checksum calculation */
#define XCP_CHECKSUM_CALCULATION            XCP_ENABLED

/* checksum type */
#define XCP_CHECKSUM_TYPE                   XCP_CHECKSUM_TYPE_CRC_32

/* maximum block size for checksum calculation */
#define XCP_MAX_CHECKSUM_BLOCKSIZE          0x32000

/* info commands STD */
#define XCP_INFO_COMMANDS_STD               XCP_DISABLED

/* slave identification */
#define XCP_SLAVE_IDENTIFICATION            XCP_DISABLED

/* transport layer commands */
#define XCP_TRANSPORT_LAYER_COMMANDS        XCP_DISABLED


/**** online calibration and calibration page switching features **************/

/* calibration page switching */
#define XCP_CAL_PAGE_SWITCHING              XCP_DISABLED

/* calibration page copying */
#define XCP_CAL_PAGE_COPYING                XCP_DISABLED

/* calibration page freezing */
#define XCP_CAL_PAGE_FREEZING               XCP_DISABLED

/* number of segments for online calibration and page switching */
#define XCP_MAX_SEGMENT                     1

/* bit modification */
#define XCP_BIT_MODIFICATION                XCP_ENABLED

/* info commands CAL/PAG */
#define XCP_INFO_COMMANDS_CAL_PAG           XCP_DISABLED


/**** synchronous data acquisition features ***********************************/

/* granularity of ODT entries for DAQ */
#define XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ  XCP_SIZE_BYTE

/* maximum size of ODT entries for DAQ */
#define XCP_MAX_ODT_ENTRY_SIZE_DAQ          255

/* prescaler of DAQ lists */
#define XCP_PRESCALER_SUPPORTED             XCP_ENABLED

/* overload indication */
#define XCP_OVERLOAD_INDICATION             XCP_DISABLED

/* PID off feature */
#define XCP_PID_OFF_SUPPORTED               XCP_DISABLED

/* timestamps of DAQ lists */
#define XCP_TIMESTAMP_SUPPORTED             XCP_ENABLED

/* resume mode */
#define XCP_RESUME_MODE                     XCP_DISABLED

/* info commands DAQ */
#define XCP_INFO_COMMANDS_DAQ               XCP_DISABLED

/* DAQ DTO buffer in the protocol layer */
#define XCP_PL_DAQ_DTO_BUFFER               XCP_DISABLED

/* special handling for DAQ/STIM of calibration parameters */
#define XCP_CAL_PAGE_DAQ_STIM               XCP_DISABLED


/**** DAQ configuration of service instance 0 *********************************/

/* static or dynamic DAQ list configuration */
#define XCP_DAQ_CONFIG_TYPE_DYNAMIC_0       XCP_DISABLED


/**** DAQ configuration of service instance 1 *********************************/

/* static or dynamic DAQ list configuration */
#define XCP_DAQ_CONFIG_TYPE_DYNAMIC_1       XCP_ENABLED


/**** synchronous data stimulation features ***********************************/

/* granularity of ODT entries for STIM */
#define XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM XCP_SIZE_BYTE

/* maximum size of ODT entries for STIM */
#define XCP_MAX_ODT_ENTRY_SIZE_STIM         XCP_SIZE_QWORD

/* double buffer mechanism */
#define XCP_DOUBLE_BUFFER                   XCP_DISABLED

/* failsafe buffer mechanism */
#define XCP_FAILSAFE_BUFFER                 XCP_DISABLED

/* wait mechanism */
#define XCP_CONSISTENCY_WAIT                XCP_DISABLED

/* failure checking mechanism */
#define XCP_FAILURE_CHECKING                XCP_DISABLED

/* info commands for bypassing */
#define XCP_INFO_COMMANDS_STIM              XCP_DISABLED

/**** Generated part of the configuration *************************************/

/* Include the generated part of the configuration. */
#include "Xcp_Prot_Cfg_generated.h"

/**** end of implementation specific code *************************************/

#endif /* __XCP_PROT_CFG_H__ */
