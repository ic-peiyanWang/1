/*
 * xcp_if.cpp
 *
 * Copyright (c) 2017-2017 NIO Autonomous Driving
 * All rights reserved.
 *
 */
#include "xcp_if.h"

#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "xcp_eth.h"
#include "xcp_veos.h"
#include "eth_interface.h"
// #include "loop.h"

/**** start of implementation specific code ***********************************/

#include "xcp_veos.h"

/**** end of implementation specific code *************************************/

/* XCP Service compilation check */
#ifndef DSXCP_SERVICE_DISABLED

#if (XCP_NO_OF_TRANSPORT_LAYERS_ETH > 0)

/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

/**** start of implementation specific code ***********************************/

#define XCP_ETH_HEADER_LENGTH 4
#define UNREFERENCED_PARAMETER(Param) (void)(Param)

/**** end of implementation specific code *************************************/


/*******************************************************************************
  object declarations
*******************************************************************************/

/**** start of implementation specific code ***********************************/

UInt8 g_Xcp_MemorySectionBasic = 0;
static UInt8 g_Xcp_BusyIndicationFlag = 0;
static bool g_Xcp_NewData = 0;
static UInt8 g_Xcp_CurrentService = 0;
static UInt8* g_Xcp_CurrentData = 0;
static UInt16 g_Xcp_CurrentDataLength = 0;

/**** end of implementation specific code *************************************/


/*******************************************************************************
  function declarations
*******************************************************************************/
void xcp_if_init(void)
{
    xcp_eth_init(0);
    /* Use 0 as BaseAddress because it is not used currently */
    Xcp_Initialize(0);
}

void xcp_if_service(void)
{
    static long timecnt = 0;

    timecnt ++;
    Xcp_Service(0,timecnt);
}

/**** start of implementation specific code ***********************************/

int xcp_if_rx_callback(unsigned char in_srvno, char *in_buff, int in_length)
{
    g_Xcp_NewData = 1;
    g_Xcp_CurrentService = in_srvno;
    g_Xcp_CurrentData = (UInt8*)in_buff;
    if ((unsigned int)in_length > 0xFFFFU) {
        g_Xcp_CurrentDataLength = 0xFFFFU;
    }
    else if (in_length < 0) {
        g_Xcp_CurrentDataLength = 0;
    }
    else {
        g_Xcp_CurrentDataLength = (UInt16)(in_length & 0xFFFFU);
    }

    do
    {
        g_Xcp_BusyIndicationFlag = 0;
        DSXCP_background();
    } while (g_Xcp_BusyIndicationFlag != 0);

    return 0;
}

/**** end of implementation specific code *************************************/


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_eth_init
*
*
*  SYNTAX
*    void DSXCP_eth_init(unsigned int service_no)
*
*  DESCRIPTION
*    This function initializes the Ethernet controller.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void DSXCP_eth_init(unsigned int service_no)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(service_no);

/**** end of implementation specific code *************************************/
}

/*******************************************************************************
*
*  FUNCTION
*    DSXCP_eth_packet_receive
*
*
*  SYNTAX
*    UInt8 DSXCP_eth_packet_receive(unsigned int service_no, UInt8 *data, UInt16 *length)
*
*  DESCRIPTION
*    This function receives a new ETH packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    data:       pointer to data of Ethernet packet
*    length:     pointer to length of Ethernet packet
*
*  RETURNS
*    DSXCP_NO_ERROR:          new Ethernet packet received
*    DSXCP_NO_NEW_ETH_PACKET: no new Ethernet packet received
*
*  REMARKS
*
*******************************************************************************/
int test_cnt = 0;
UInt8 DSXCP_eth_packet_receive(unsigned int service_no, UInt8* data, UInt16* length)
{
/**** start of implementation specific code ***********************************/

    if (service_no == g_Xcp_CurrentService && g_Xcp_NewData == 1)
    {
        memcpy(data, g_Xcp_CurrentData, g_Xcp_CurrentDataLength);

        *length = g_Xcp_CurrentDataLength;

        g_Xcp_NewData = 0;

        g_Xcp_BusyIndicationFlag = 1;

        return DSXCP_NO_ERROR;
    }

    *length = 0;
    return DSXCP_NO_NEW_ETH_PACKET;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_eth_packet_send
*
*
*  SYNTAX
*    UInt8 DSXCP_eth_packet_send(unsigned int service_no, UInt8 *data, UInt16 length)
*
*  DESCRIPTION
*    This function sends an Ethernet packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    data:       pointer to data of Ethernet packet
*    length:     length of Ethernet packet
*
*  RETURNS
*    DSXCP_NO_ERROR:              Ethernet packet sent successfully
*    DSXCP_ETH_PACKET_SEND_ERROR: Ethernet packet not sent
*
*  REMARKS
*
*******************************************************************************/
UInt8 DSXCP_eth_packet_send(unsigned int service_no, UInt8* data, UInt16 length)
{
/**** start of implementation specific code ***********************************/

    // VEOS_ApiSuccessType result;

    if (length > XCP_ETH_MAX_DTO_0 + XCP_ETH_HEADER_LENGTH)
    {
        return DSXCP_ETH_PACKET_SEND_ERROR;
    }

    g_Xcp_BusyIndicationFlag = 1;

    TCPServerXCP->transmit((char *)data, length);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}

#endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH > 0) */

#endif /* #ifndef DSXCP_SERVICE_DISABLED */
