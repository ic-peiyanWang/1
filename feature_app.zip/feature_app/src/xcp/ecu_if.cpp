/*******************************************************************************
*
*  FILE
*    ecu_if.c
*
*  DESCRIPTION
*    This file contains the customization layer (ECU target interface) of
*    the dSPACE XCP Service.
*    These external functions are needed by the dSPACE XCP Service and must
*    be implemented by the ECU developer in the outlined sections. All other
*    parts of this file must remain unaltered.
*
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*    Only outlined sections may be edited by the ECU developer. All other
*    sections must remain unaltered!
*
*
*******************************************************************************/

#include "ecu_if.h"

/**** start of implementation specific code ***********************************/

#include "xcp_eth.h"
#include "xcp_veos.h"

#if defined(XCP_DS_RPT_BYPASS_EXTENSION) || defined(XCP_DS_RPT_BYPASS_OFFSET)
#include "SmartFeatureManagers.h"
#endif

/**** end of implementation specific code *************************************/

/* dSPACE XCP service compilation check */
#ifndef DSXCP_SERVICE_DISABLED


/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

/* resources for seed&key mechanism */
#define XCP_SEED_KEY_RESOURCE_CAL_PAG             0x01
#define XCP_SEED_KEY_RESOURCE_DAQ                 0x04
#define XCP_SEED_KEY_RESOURCE_STIM                0x08
#define XCP_SEED_KEY_RESOURCE_PGM                 0x10

/* modes for switching a calibration page */
#define XCP_CAL_PAGE_MODE_ECU                     0x01
#define XCP_CAL_PAGE_MODE_XCP                     0x02
#define XCP_CAL_PAGE_MODE_ALL                     0x80

#define UNREFERENCED_PARAMETER(Param)             (void)(Param)

/**** start of implementation specific code ***********************************/

/**** end of implementation specific code *************************************/


/*******************************************************************************
  object declarations
*******************************************************************************/

/**** start of implementation specific code ***********************************/

static VEOS_uint32 g_Xcp_BaseAddress = 0;
static VEOS_uint32 g_Xcp_Timestamp = 0;
static bool g_Xcp_BypassEnabled = 0;

/**** end of implementation specific code *************************************/


/*******************************************************************************
  function prototypes
*******************************************************************************/

/**** start of implementation specific code ***********************************/

VEOS_ApiSuccessType Xcp_Initialize(const VEOS_uint32 BaseAddress)
{
	g_Xcp_BaseAddress = BaseAddress;
	DSXCP_init();

	return VEOS_E_OK;
}

VEOS_ApiSuccessType Xcp_Service(const UInt16 ServiceId, const VEOS_float64 CurrentSimulationTime)
{
    /* + 0.5 to fix possible rounding errors */
    g_Xcp_Timestamp = (VEOS_uint32)(XCP_TIMESTAMP_FACTOR * CurrentSimulationTime + 0.5);
    DSXCP_service(ServiceId);

    return VEOS_E_OK;
}

VEOS_ApiSuccessType Xcp_EnableBypass(const bool Enabled)
{
    g_Xcp_BypassEnabled = Enabled;

    return VEOS_E_OK;
}

/**** end of implementation specific code *************************************/


/*******************************************************************************
  function declarations
*******************************************************************************/

/**** start of implementation specific code ***********************************/

/**** end of implementation specific code *************************************/


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_ext_init
*
*
*  SYNTAX
*    void DSXCP_ext_init(void)
*
*  DESCRIPTION
*    This function initializes additional external resources.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void DSXCP_ext_init(void)
{
/**** start of implementation specific code ***********************************/

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_user_mode
*
*
*  SYNTAX
*    void DSXCP_user_mode(void)
*
*  DESCRIPTION
*    This function performs actions of a special user defined mode.
*    It is called, if the dSPACE XCP service receives a CONNECT(user defined).
*
*  PARAMETERS
*    none
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void DSXCP_user_mode(void)
{
/**** start of implementation specific code ***********************************/

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_get_address_pointer
*
*
*  SYNTAX
*    xcp_mta_ptr_t DSXCP_get_address_pointer(UInt32 address, UInt8 extension)
*
*  DESCRIPTION
*    This function calculates a pointer to a memory location from a given
*    logical XCP address and extension.
*    It is called by the protocol layer to get both calibration and data
*    acquisition addresses.
*    Especially for software based calibration page switching, the offset
*    calculation will be implemented here.
*
*  PARAMETERS
*    address:   address
*    extension: address extension
*
*  RETURNS
*    pointer to memory location
*
*  REMARKS
*
*******************************************************************************/
xcp_mta_ptr_t DSXCP_get_address_pointer(UInt32 address, UInt8 extension)
{
/**** start of implementation specific code ***********************************/

#ifdef XCP_DS_RPT_BYPASS_EXTENSION
    /* Address extension support */
    if (extension == XCP_DS_RPT_BYPASS_EXTENSION)
    {
        return (xcp_mta_ptr_t)dsECUIntByp_getAddressPtr(address);
    }
#else
    UNREFERENCED_PARAMETER(extension);
#endif

#ifdef XCP_DS_RPT_BYPASS_OFFSET
    /* Address offset support */
    if (address > XCP_DS_RPT_BYPASS_OFFSET)
    {
        return (xcp_mta_ptr_t)dsECUIntByp_getAddressPtr(address - XCP_DS_RPT_BYPASS_OFFSET);
    }
#endif

    return (xcp_mta_ptr_t)static_cast<long>(address + g_Xcp_BaseAddress);

/**** end of implementation specific code *************************************/
}


#if ((XCP_CHECKSUM_CALCULATION == XCP_ENABLED) && (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_USER_DEFINED))
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_build_checksum
*
*
*  SYNTAX
*    UInt32 DSXCP_build_checksum(xcp_mta_ptr_t ptr, UInt32 size)
*
*  DESCRIPTION
*    This function calculates a checksum of a memory range specified by ptr
*    and size with a user defined algorithm.
*
*  PARAMETERS
*    ptr:  pointer to start of memory range
*    size: size of memory range
*
*  RETURNS
*    checksum
*
*  REMARKS
*    This function will only be compiled if user defined checksum calculation
*    is enabled.
*
*******************************************************************************/
UInt32 DSXCP_build_checksum(xcp_mta_ptr_t ptr, UInt32 size)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(ptr);
    UNREFERENCED_PARAMETER(size);

    return 0;

/**** end of implementation specific code *************************************/
}
#endif /* #if ((XCP_CHECKSUM_CALCULATION == XCP_ENABLED) && (XCP_CHECKSUM_TYPE == XCP_CHECKSUM_TYPE_USER_DEFINED)) */


#if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_memory_access_check
*
*
*  SYNTAX
*    UInt8 DSXCP_memory_access_check(UInt32 address, UInt8 extension, UInt32 length, UInt8 type)
*
*  DESCRIPTION
*    This function checks, if an access to the given memory range is allowed
*    for the given access type.
*
*  PARAMETERS
*    address:   start address of memory range
*    extension: address extension
*    length:    length of memory range
*    type:      access type (XCP_MEMORY_ACCESS_TYPE_READ,
*                            XCP_MEMORY_ACCESS_TYPE_WRITE,
*                            XCP_MEMORY_ACCESS_TYPE_DAQ_STIM,
*                            XCP_MEMORY_ACCESS_TYPE_PGM,
*                            XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM)
*
*  RETURNS
*    DSXCP_NO_ERROR:            : memory access allowed
*    DSXCP_MEMORY_ACCESS_DENIED : memory access not allowed
*
*  REMARKS
*    This function will only be compiled if the memory protection mechanism is
*    enabled.
*
*******************************************************************************/
UInt8 DSXCP_memory_access_check(UInt32 address, UInt8 extension, UInt32 length, UInt8 type)
{
/**** start of implementation specific code ***********************************/

#ifdef XCP_DS_RPT_BYPASS_EXTENSION
    /* Address extension support */
    if (extension == XCP_DS_RPT_BYPASS_EXTENSION && !g_Xcp_BypassEnabled)
    {
        return DSXCP_MEMORY_ACCESS_DENIED;
    }
#else
    UNREFERENCED_PARAMETER(extension);
#endif

#ifdef XCP_DS_RPT_BYPASS_OFFSET
    /* Address offset support */
    if (address > XCP_DS_RPT_BYPASS_OFFSET && !g_Xcp_BypassEnabled)
    {
        return DSXCP_MEMORY_ACCESS_DENIED;
    }
#endif

    switch (type)
    {
    case XCP_MEMORY_ACCESS_TYPE_READ:
    case XCP_MEMORY_ACCESS_TYPE_WRITE:
    case XCP_MEMORY_ACCESS_TYPE_DAQ_STIM:
    case XCP_MEMORY_ACCESS_TYPE_PGM:
    case XCP_MEMORY_ACCESS_TYPE_CAL_PAGE_STIM:
        if ((address > 0x00000000) && (address < 0xFFFFFFFF) && ((address + length) < 0xFFFFFFFF) && ((address + length) > address))
        {
            return DSXCP_NO_ERROR;
        }

        break;

    default:
        break;
    }

    return DSXCP_MEMORY_ACCESS_DENIED;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */


#if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_get_seed
*
*
*  SYNTAX
*    UInt8 DSXCP_get_seed(UInt8 *seed, UInt8 resource)
*
*  DESCRIPTION
*    This function calculates a random seed to unlock a resource.
*
*  PARAMETERS
*    seed:     random seed
*    resource: XCP resource, which is requested to be unlocked
*
*  RETURNS
*    length of seed
*
*  REMARKS
*    This function will only be compiled if the seed&key mechanism is enabled.
*
*******************************************************************************/
UInt8 DSXCP_get_seed(UInt8 *seed, UInt8 resource)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(seed);
    UNREFERENCED_PARAMETER(resource);

    return 0;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_unlock
*
*
*  SYNTAX
*    UInt8 DSXCP_unlock(UInt8 *seed, UInt8 *key, UInt8 resource)
*
*  DESCRIPTION
*    This function checks the given seed and key to unlock a resource.
*
*  PARAMETERS
*    seed:     current seed calculated by DSXCP_get_seed()
*    key:      corresponding key of seed
*    resource: XCP resource, which is requested to be unlocked
*
*  RETURNS
*    DSXCP_NO_ERROR:      key is correct
*    DSXCP_UNLOCK_DENIED: key is not correct
*
*  REMARKS
*    This function will only be compiled if the seed&key mechanism is enabled.
*
*******************************************************************************/
UInt8 DSXCP_unlock(UInt8 *seed, UInt8 *key, UInt8 resource)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(seed);
    UNREFERENCED_PARAMETER(key);
    UNREFERENCED_PARAMETER(resource);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */


#if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)

#if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_set_cal_page
*
*
*  SYNTAX
*    UInt8 DSXCP_set_cal_page(UInt8 segment, UInt8 page, UInt8 mode)
*
*  DESCRIPTION
*    This function sets the active calibration page of a segment.
*
*  PARAMETERS
*    segment: segment number
*    page:    page number
*    mode:    mode
*
*  RETURNS
*    DSXCP_NO_ERROR:            setting of calibration page successful
*    DSXCP_SET_CAL_PAGE_FAILED: setting of calibration page not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource CAL/PAG and
*    calibration page switching are enabled.
*
*******************************************************************************/
UInt8 DSXCP_set_cal_page(UInt8 segment, UInt8 page, UInt8 mode)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(segment);
    UNREFERENCED_PARAMETER(page);
    UNREFERENCED_PARAMETER(mode);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_get_cal_page
*
*
*  SYNTAX
*    UInt8 DSXCP_get_cal_page(UInt8 segment, UInt8 mode)
*
*  DESCRIPTION
*    This function returns the active calibration page of a segment.
*
*  PARAMETERS
*    segment: segment number
*    mode:    mode
*
*  RETURNS
*    active calibration page
*
*  REMARKS
*    This function will only be compiled if the XCP resource CAL/PAG and
*    calibration page switching are enabled.
*
*******************************************************************************/
UInt8 DSXCP_get_cal_page(UInt8 segment, UInt8 mode)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(segment);
    UNREFERENCED_PARAMETER(mode);

    return 0;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) */

#if (XCP_CAL_PAGE_COPYING == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_copy_cal_page
*
*
*  SYNTAX
*    UInt8 DSXCP_copy_cal_page(UInt8 segment_source, UInt8 page_source, UInt8 segment_destination, UInt8 page_destination)
*
*  DESCRIPTION
*    This function copies one calibration page to another one.
*
*  PARAMETERS
*    segment_source:      source segment
*    page_source:         source page
*    segment_destination: destination segment
*    page_destination:    destination page
*
*  RETURNS
*    DSXCP_NO_ERROR:             copying of calibration page successful
*    DSXCP_COPY_CAL_PAGE_FAILED: copying of calibration page not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource CAL/PAG and
*    calibration page copying are enabled.
*
*******************************************************************************/
UInt8 DSXCP_copy_cal_page(UInt8 segment_source, UInt8 page_source, UInt8 segment_destination, UInt8 page_destination)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(segment_source);
    UNREFERENCED_PARAMETER(page_source);
    UNREFERENCED_PARAMETER(segment_destination);
    UNREFERENCED_PARAMETER(page_destination);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_CAL_PAGE_COPYING == XCP_ENABLED) */


#if (XCP_CAL_PAGE_FREEZING  == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_store_cal_page
*
*
*  SYNTAX
*    UInt8 DSXCP_store_cal_page(UInt8 segment)
*
*  DESCRIPTION
*    This function stores the active calibration page of the given segment into
*    non-volatile memory.
*    The calibration page may either be stored once or sequentially. In the
*    first case DSXCP_NO_ERROR must be returned, in the latter case
*    DSXCP_STORE_CAL_PAGE_PENDING.
*    The protocol layer will call DSXCP_store_cal_page() as long as
*    DSXCP_NO_ERROR is returned finally.
*
*  PARAMETERS
*    segment: segment number
*
*  RETURNS
*    DSXCP_NO_ERROR:               storing of calibration page successful
*    DSXCP_STORE_CAL_PAGE_PENDING: storing of calibration page pending
*
*  REMARKS
*    This function will only be compiled if the XCP resource CAL/PAG and
*    calibration page freezing are enabled.
*
*******************************************************************************/
UInt8 DSXCP_store_cal_page(UInt8 segment)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(segment);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_CAL_PAGE_FREEZING  == XCP_ENABLED) */

#endif /* #if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) */


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)

#if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_get_timestamp
*
*
*  SYNTAX
*    UInt32 DSXCP_get_timestamp(void)
*
*  DESCRIPTION
*    This function returns a timestamp.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    current timestamp
*
*  REMARKS
*    This function will only be compiled if the XCP resource DAQ and the
*    time stamping feature are enabled.
*
*******************************************************************************/
UInt32 DSXCP_get_timestamp(void)
{
/**** start of implementation specific code ***********************************/

    return g_Xcp_Timestamp;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */


#if (XCP_RESUME_MODE == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_init_resume_mode_data
*
*
*  SYNTAX
*    UInt8 DSXCP_init_resume_mode_data(unsigned int service_no,
*                                      UInt16       *session_id,
*                                      UInt16       *max_daq,
*                                      UInt8        *pl_data,
*                                      UInt32       pl_size,
*                                      UInt8        *tl_data,
*                                      UInt32       tl_size)
*
*  DESCRIPTION
*    This function initializes the resume mode data stored by the function
*    DSXCP_store_resume_mode_data().
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    session_id: session configuration id
*    max_daq:    number of DAQ lists
*    pl_data:    pointer to where the resume mode data of the protocol layer
*                will be copied.
*    pl_size:    size of the resume mode data of the protocol layer
*    tl_data:    pointer to where the resume mode data of the transport layer
*                will be copied.
*    tl_size:    size of the resume mode data of the transport layer
*
*  RETURNS
*    DSXCP_NO_ERROR:                     initialization successful
*    DSXCP_INIT_RESUME_MODE_DATA_FAILED: initialization failed
*
*  REMARKS
*    This function will only be compiled if the XCP resource DAQ and the
*    resume mode feature are enabled.
*
*******************************************************************************/
UInt8 DSXCP_init_resume_mode_data(unsigned int service_no, UInt16 *session_id, UInt16 *max_daq, UInt8 *pl_data, UInt32 pl_size, UInt8 *tl_data, UInt32 tl_size)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(service_no);
    UNREFERENCED_PARAMETER(session_id);
    UNREFERENCED_PARAMETER(max_daq);
    UNREFERENCED_PARAMETER(pl_data);
    UNREFERENCED_PARAMETER(pl_size);
    UNREFERENCED_PARAMETER(tl_data);
    UNREFERENCED_PARAMETER(tl_size);

    return DSXCP_INIT_RESUME_MODE_DATA_FAILED;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_store_resume_mode_data
*
*
*  SYNTAX
*    UInt8 DSXCP_store_resume_mode_data(unsigned int service_no,
*                                       UInt16       session_id,
*                                       UInt16       max_daq,
*                                       UInt8        *pl_data,
*                                       UInt32       pl_size,
*                                       UInt8        *tl_data,
*                                       UInt32       tl_size)
*
*  DESCRIPTION
*    This function stores the resume mode data into non-volatile memory.
*    The resume mode data consists of the session configuration id, the number
*    of DAQ lists, the protocol layer data and the transport layer data.
*    The resume mode data may either be stored once or sequentially. In the
*    first case DSXCP_NO_ERROR must be returned, in the latter case
*    DSXCP_STORE_RESUME_MODE_DATA_PENDING.
*    The protocol layer will call DSXCP_store_resume_mode_data() as long as
*    DSXCP_NO_ERROR is returned finally.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    session_id: session configuration id
*    max_daq:    number of DAQ lists
*    pl_data:    pointer to where the resume mode data of the protocol layer
*                is located.
*    pl_size:    size of the resume mode data of the protocol layer
*    tl_data:    pointer to where the resume mode data of the transport layer
*                is located.
*    tl_size:    size of the resume mode data of the transport layer
*
*  RETURNS
*    DSXCP_NO_ERROR:                       storing of resume mode data
*                                          successful
*    DSXCP_STORE_RESUME_MODE_DATA_PENDING: storing of resume mode data
*                                          pending
*
*  REMARKS
*    This function will only be compiled if the XCP resource DAQ and the
*    resume mode feature are enabled.
*
*******************************************************************************/
UInt8 DSXCP_store_resume_mode_data(unsigned int service_no, UInt16 session_id, UInt16 max_daq, UInt8 *pl_data, UInt32 pl_size, UInt8 *tl_data, UInt32 tl_size)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(service_no);
    UNREFERENCED_PARAMETER(session_id);
    UNREFERENCED_PARAMETER(max_daq);
    UNREFERENCED_PARAMETER(pl_data);
    UNREFERENCED_PARAMETER(pl_size);
    UNREFERENCED_PARAMETER(tl_data);
    UNREFERENCED_PARAMETER(tl_size);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_clear_resume_mode_data
*
*
*  SYNTAX
*    UInt8 DSXCP_clear_resume_mode_data(unsigned int service_no)
*
*  DESCRIPTION
*    This function clears the resume mode data stored in non-volatile memory.
*    The resume mode data may be either cleared once or sequentially. In the
*    latter case DSXCP_CLEAR_RESUME_MODE_DATA_PENDING must be returned.
*    The protocol layer will call DSXCP_clear_resume_mode_data() as long as
*    DSXCP_NO_ERROR is returned.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    DSXCP_NO_ERROR:                       clearing of resume mode data
*                                          successful
*    DSXCP_STORE_RESUME_MODE_DATA_PENDING: clearing of resume mode data
*                                          pending
*
*  REMARKS
*    This function will only be compiled if the XCP resource DAQ and the
*    resume mode feature are enabled.
*
*******************************************************************************/
UInt8 DSXCP_clear_resume_mode_data(unsigned int service_no)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(service_no);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */

#endif /* (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program_start
*
*
*  SYNTAX
*    UInt8 DSXCP_program_start(void)
*
*  DESCRIPTION
*    This function indicates the beginning of a non-volatile memory programming
*    sequence.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    DSXCP_NO_ERROR:             programming is allowed
*    DSXCP_PROGRAM_START_FAILED: programming is currently not allowed
*
*  REMARKS
*    This function will only be compiled if the XCP resource PGM is enabled.
*
*******************************************************************************/
UInt8 DSXCP_program_start(void)
{
/**** start of implementation specific code ***********************************/

    return DSXCP_PROGRAM_START_FAILED;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program_clear
*
*
*  SYNTAX
*    UInt8 DSXCP_program_clear(xcp_mta_ptr_t address, UInt32 length)
*
*  DESCRIPTION
*    This function clears a part of non-volatile memory.
*
*  PARAMETERS
*    address: pointer to start address of memory range
*    length:  length of memory range
*
*  RETURNS
*    DSXCP_NO_ERROR:             clearing successful
*    DSXCP_PROGRAM_CLEAR_FAILED: clearing not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource PGM is enabled.
*
*******************************************************************************/
UInt8 DSXCP_program_clear(xcp_mta_ptr_t address, UInt32 length)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(address);
    UNREFERENCED_PARAMETER(length);

    return DSXCP_PROGRAM_CLEAR_FAILED;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program
*
*
*  SYNTAX
*    UInt8 DSXCP_program(xcp_mta_ptr_t address, UInt8 length, UInt8 *data)
*
*  DESCRIPTION
*    This function writes data into non-volatile memory.
*
*  PARAMETERS
*    address: pointer to start address of memory range
*    length:  length of memory range
*    data:    pointer to PGM data
*
*  RETURNS
*    DSXCP_NO_ERROR:       programming successful
*    DSXCP_PROGRAM_FAILED: programming not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource PGM is enabled.
*
*******************************************************************************/
UInt8 DSXCP_program(xcp_mta_ptr_t address, UInt8 length, UInt8 *data)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(address);
    UNREFERENCED_PARAMETER(length);
    UNREFERENCED_PARAMETER(data);

    return DSXCP_PROGRAM_FAILED;

/**** end of implementation specific code *************************************/
}


/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program_reset
*
*
*  SYNTAX
*    UInt8 DSXCP_program_reset(void)
*
*  DESCRIPTION
*    This function indicates the end of a non-volatile memory programming
*    sequence.
*
*  PARAMETERS
*    none
*
*  RETURNS
*    DSXCP_NO_ERROR:             resetting successful
*    DSXCP_PROGRAM_RESET_FAILED: resetting not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource PGM is enabled.
*
*******************************************************************************/
UInt8 DSXCP_program_reset(void)
{
/**** start of implementation specific code ***********************************/

    return DSXCP_PROGRAM_RESET_FAILED;

/**** end of implementation specific code *************************************/
}


#if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program_prepare
*
*
*  SYNTAX
*    UInt8 DSXCP_program_prepare(xcp_mta_ptr_t address, UInt32 codesize)
*
*  DESCRIPTION
*    This function indicates the begin of a code download as a precondition for
*    non-volatile memory programming.
*
*  PARAMETERS
*    address:  pointer to address where code will be downloaded
*    codesize: size of code
*
*  RETURNS
*    DSXCP_NO_ERROR:               preparing successful
*    DSXCP_PROGRAM_PREPARE_FAILED: preparing not successful
*
*  REMARKS
*
*******************************************************************************/
UInt8 DSXCP_program_prepare(xcp_mta_ptr_t address, UInt32 codesize)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(address);
    UNREFERENCED_PARAMETER(codesize);

    return DSXCP_NO_ERROR;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED) */


#if (XCP_PGM_VERIFICATION == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    DSXCP_program_verify
*
*
*  SYNTAX
*    UInt8 DSXCP_program_verify(UInt8 mode, UInt8 type, UInt32 value)
*
*  DESCRIPTION
*    This function verifies non-volatile memory.
*
*  PARAMETERS
*    mode:  verification mode (0: internal test, 1: verification value
*    type:  project specific verification type
*    value: project specific verification value (only for verification mode 1)
*
*  RETURNS
*    DSXCP_NO_ERROR:              resetting successful
*    DSXCP_PROGRAM_VERIFY_FAILED: verification not successful
*
*  REMARKS
*    This function will only be compiled if the XCP resource PGM and the
*    verification feature are enabled.
*
*******************************************************************************/
UInt8 DSXCP_program_verify(UInt8 mode, UInt8 type, UInt32 value)
{
/**** start of implementation specific code ***********************************/

    UNREFERENCED_PARAMETER(mode);
    UNREFERENCED_PARAMETER(type);
    UNREFERENCED_PARAMETER(value);

    return DSXCP_PROGRAM_VERIFY_FAILED;

/**** end of implementation specific code *************************************/
}
#endif /* #if (XCP_PGM_VERIFICATION == XCP_ENABLED) */

#endif /* #if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED) */

#endif /* #ifndef DSXCP_SERVICE_DISABLED */
