/**************************************************************************************************\
 *** xcp_veos.h
 ***
 *** XCP API for VEOS.
 ***
 *** Author: Artur Wolf
 *** Since:  2015-12-14
 ***
 *** Copyright 2015 by dSPACE GmbH, Paderborn, Germany.
 *** All Rights Reserved.
\**************************************************************************************************/

/* $RCSfile: xcp_veos.h $ $Revision: 1.9 $ $Date: 2015/12/16 16:18:35MEZ $
 * $ProjectName: e:/ARC/Configurations/BaseSystems/OfflineSimulator/VEOS_3.6/TargetSw/XcpService/Sources/Export/project.pj $
 */

#ifndef _XCP_VEOS_H_
#define _XCP_VEOS_H_

/*------------------------------------------------------------------------------------------------*\
  INCLUDES
\*------------------------------------------------------------------------------------------------*/

//#include "VEOS.h"
//#include "dbcparser.h"

typedef unsigned short UInt16;
typedef unsigned int UInt32;
typedef unsigned char UInt8;
typedef unsigned int VEOS_uint32;
typedef double VEOS_float64;

typedef enum
{
	VEOS_E_OK
}VEOS_ApiSuccessType;

/*------------------------------------------------------------------------------------------------*\
  FUNCTION PROTOTYPES
\*------------------------------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************************************\
 *** FUNCTION:
 ***     Xcp_Initialize
 ***
 *** DESCRIPTION:
 ***     Initializes the XCP service.
 ***
 *** PARAMETERS:
 ***     Type                               Name            Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     const VEOS_uint32                  BaseAddress     Incoming argument: The base address.
 ***
 *** RETURNS:
 ***     VEOS_ApiSuccessType    If no error occurs, VEOS_E_OK will be returned. If any error
 ***                            occurs, an error code will be the result. See VEOS_Types.h for
 ***                            details.
\**************************************************************************************************/
extern VEOS_ApiSuccessType Xcp_Initialize(const VEOS_uint32 BaseAddress);

/**************************************************************************************************\
 *** FUNCTION:
 ***     Xcp_HandleRxEvent
 ***
 *** DESCRIPTION:
 ***     Handles an XCP RX event.
 ***
 *** PARAMETERS:
 ***     Type                               Name            Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     UInt8                         Service         Incoming argument: The service number.
 ***     UInt8*                        pData           Incoming argument: The data.
 ***     UInt16                        DataLength      Incoming argument: The data length.
 ***
 *** RETURNS:
 ***     VEOS_ApiSuccessType    If no error occurs, VEOS_E_OK will be returned. If any error
 ***                            occurs, an error code will be the result. See VEOS_Types.h for
 ***                            details.
\**************************************************************************************************/
extern VEOS_ApiSuccessType Xcp_HandleRxEvent(
    const UInt8 Service,
    const UInt8* pData,
    const UInt16 DataLength);

/**************************************************************************************************\
 *** FUNCTION:
 ***     Xcp_Service
 ***
 *** DESCRIPTION:
 ***     XCP foreground service.
 ***
 *** PARAMETERS:
 ***     Type                               Name            Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     const UInt16                  Raster          Incoming argument: The raster.
 ***     const VEOS_float64                 TimeStamp       Incoming argument: The time stamp.
 ***
 *** RETURNS:
 ***     VEOS_ApiSuccessType    If no error occurs, VEOS_E_OK will be returned. If any error
 ***                            occurs, an error code will be the result. See VEOS_Types.h for
 ***                            details.
\**************************************************************************************************/
extern VEOS_ApiSuccessType Xcp_Service(const UInt16 Raster, const VEOS_float64 TimeStamp);

/**************************************************************************************************\
 *** FUNCTION:
 ***     Xcp_EnableBypass
 ***
 *** DESCRIPTION:
 ***     Enables the bypassing for the XCP service.
 ***
 *** PARAMETERS:
 ***     Type                               Name            Description
 ***     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ***     const bool                 Enabled         Incoming argument: The enabled flag.
 ***
 *** RETURNS:
 ***     VEOS_ApiSuccessType    If no error occurs, VEOS_E_OK will be returned. If any error
 ***                            occurs, an error code will be the result. See VEOS_Types.h for
 ***                            details.
\**************************************************************************************************/
extern VEOS_ApiSuccessType Xcp_EnableBypass(const bool Enabled);

#ifdef __cplusplus
}
#endif

#endif /* _XCP_VEOS_H_ */

/*------------------------------------------------------------------------------------------------*\
  END OF FILE
\*------------------------------------------------------------------------------------------------*/
