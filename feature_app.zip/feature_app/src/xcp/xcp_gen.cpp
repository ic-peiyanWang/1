/*******************************************************************************
*
*  FILE
*    xcp_gen.c
*
*  DESCRIPTION
*    This file contains the generic transport layer of the dSPACE XCP Service.
*    It builds an interface between the protocol layer and the specific
*    transport layer(s).
*
*  COPYRIGHT
*    Copyright 2015, dSPACE GmbH. All rights reserved.
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*
*  AUTHOR(S)
*    Bastian Kellers
*
*  VERSION
*    2.4.0
*
*  $RCSfile: xcp_gen.c $ $Revision: 1.7 $ $Date: 2015/11/06 14:49:16MEZ $
*
*******************************************************************************/

#include "xcp_gen.h"
#include "xcp_prot.h"

/* dSPACE XCP service compilation check */
#ifndef DSXCP_SERVICE_DISABLED

/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/


/*******************************************************************************
  object declarations
*******************************************************************************/


/*******************************************************************************
  function prototypes
*******************************************************************************/


/*******************************************************************************
  function declarations
*******************************************************************************/

#if ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_TRANSPORT_LAYER_TYPE_0 != XCP_TRANSPORT_LAYER_TYPE_1))
static void (* const _xcp_tl_init[2])(unsigned int service_no)                                                                                    = {XCP_TL_INIT_0, XCP_TL_INIT_1};
#if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED))
static UInt8 *(* const _xcp_receive_ptr_get[2])(unsigned int service_no, UInt8 *pid_off_flag, UInt16 *daq)                                        = {XCP_RECEIVE_PTR_GET_0, XCP_RECEIVE_PTR_GET_1};
static void (* const _xcp_receive_ptr_release[2])(unsigned int service_no)                                                                        = {XCP_RECEIVE_PTR_RELEASE_0, XCP_RECEIVE_PTR_RELEASE_1};
#endif /* #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED)) */
static UInt8 *(* const _xcp_res_cto_ptr_get[2])(unsigned int service_no)                                                                          = {XCP_RES_CTO_PTR_GET_0, XCP_RES_CTO_PTR_GET_1};
static void (* const _xcp_res_cto_send[2])(unsigned int service_no, UInt8 length)                                                                 = {XCP_RES_CTO_SEND_0, XCP_RES_CTO_SEND_1};
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
  #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
static void (* const _xcp_daq_dto_buffer_send[2])(unsigned int service_no, UInt16 daq, UInt16 length, UInt8 *data)                                = {XCP_DAQ_DTO_BUFFER_SEND_0, XCP_DAQ_DTO_BUFFER_SEND_1};
  #else /* (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED) */
static UInt8 *(* const _xcp_daq_dto_ptr_get[2])(unsigned int service_no, UInt16 daq)                                                              = {XCP_DAQ_DTO_PTR_GET_0, XCP_DAQ_DTO_PTR_GET_1};
static void (* const _xcp_daq_dto_send[2])(unsigned int service_no, UInt16 daq, UInt16 length)                                                    = {XCP_DAQ_DTO_SEND_0, XCP_DAQ_DTO_SEND_1};
  #endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
  #if (XCP_RESUME_MODE == XCP_ENABLED)
static UInt8 *(* const _xcp_tl_resume_data_ptr_get[2])(unsigned int service_no, UInt32 *size)                                                     = {XCP_TL_RESUME_DATA_PTR_GET_0, XCP_TL_RESUME_DATA_PTR_GET_1};
  #endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */
#if (XCP_TX_INT == XCP_DISABLED)
static void (* const _xcp_send_background[2])(unsigned int service_no)                                                                            = {XCP_SEND_BACKGROUND_0, XCP_SEND_BACKGROUND_1};
#endif /* #if (XCP_TX_INT == XCP_DISABLED) */
#if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED)
static UInt8 (* const _xcp_tl_cmd_proc[2])(unsigned int service_no, UInt8 *cmd_cto_ptr, UInt8 *res_cto_ptr, UInt8 session_status, UInt16 max_daq) = {XCP_TL_CMD_PROC_0, XCP_TL_CMD_PROC_1};
#endif /* #if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED) */


void xcp_tl_init(unsigned int service_no)
{
  _xcp_tl_init[service_no](0);
}


#if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED))
UInt8 *xcp_receive_ptr_get(unsigned int service_no, UInt8 *pid_off_flag, UInt16 *daq)
{
  return (_xcp_receive_ptr_get[service_no](0, pid_off_flag, daq));
}


void xcp_receive_ptr_release(unsigned int service_no)
{
  _xcp_receive_ptr_release[service_no](0);
}
#endif /* #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED)) */


UInt8 *xcp_res_cto_ptr_get(unsigned int service_no)
{
  return (_xcp_res_cto_ptr_get[service_no](0));
}


void xcp_res_cto_send(unsigned int service_no, UInt8 length)
{
  _xcp_res_cto_send[service_no](0, length);
}


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
UInt8 xcp_daq_dto_buffer_send(unsigned int service_no, UInt16 daq, UInt16 length, UInt8 *data)
{
  return(_xcp_daq_dto_buffer_send[service_no](0, daq, length, data));
}

#else /* (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED) */

UInt8 *xcp_daq_dto_ptr_get(unsigned int service_no, UInt16 daq)
{
  return (_xcp_daq_dto_ptr_get[service_no](0, daq));
}


void xcp_daq_dto_send(unsigned int service_no, UInt16 daq, UInt16 length)
{
  _xcp_daq_dto_send[service_no](0, daq, length);
}
#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */


#if (XCP_RESUME_MODE == XCP_ENABLED)
UInt8 *xcp_tl_resume_data_ptr_get(unsigned int service_no, UInt32 *size)
{
  return (_xcp_tl_resume_data_ptr_get[service_no](0, size));
}
#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


#if (XCP_TX_INT == XCP_DISABLED)
void xcp_send_background(unsigned int service_no)
{
  _xcp_send_background[service_no](0);
}
#endif /* #if (XCP_TX_INT == XCP_DISABLED) */


#if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED)
UInt8 xcp_tl_cmd_proc(unsigned int service_no, UInt8 *cmd_cto_ptr, UInt8 *res_cto_ptr, UInt8 session_status, UInt16 max_daq)
{
  return (_xcp_tl_cmd_proc[service_no](0, cmd_cto_ptr, res_cto_ptr, session_status, max_daq));
}
#endif /* #if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED) */


#else /* (XCP_NO_OF_SERVICE_INSTANCES == 1) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_1)) */


void xcp_tl_init(unsigned int service_no)
{
  XCP_TL_INIT_0(service_no);
}


#if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED))
UInt8 *xcp_receive_ptr_get(unsigned int service_no, UInt8 *pid_off_flag, UInt16 *daq)
{
  return (XCP_RECEIVE_PTR_GET_0(service_no, pid_off_flag, daq));
}


void xcp_receive_ptr_release(unsigned int service_no)
{
  XCP_RECEIVE_PTR_RELEASE_0(service_no);
}
#endif /* #if ((XCP_RX_INT == XCP_DISABLED) || (XCP_COMMAND_MODE_BACKGROUND == XCP_ENABLED)) */


UInt8 *xcp_res_cto_ptr_get(unsigned int service_no)
{
  return (XCP_RES_CTO_PTR_GET_0(service_no));
}


void xcp_res_cto_send(unsigned int service_no, UInt8 length)
{
  XCP_RES_CTO_SEND_0(service_no, length);
}


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
UInt8 xcp_daq_dto_buffer_send(unsigned int service_no, UInt16 daq, UInt16 length, UInt8 *data)
{
  return(XCP_DAQ_DTO_BUFFER_SEND_0(service_no, daq, length, data));
}

#else /* (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED) */

UInt8 *xcp_daq_dto_ptr_get(unsigned int service_no, UInt16 daq)
{
  return (XCP_DAQ_DTO_PTR_GET_0(service_no, daq));
}


void xcp_daq_dto_send(unsigned int service_no, UInt16 daq, UInt16 length)
{
  XCP_DAQ_DTO_SEND_0(service_no, daq, length);
}


#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */


#if (XCP_RESUME_MODE == XCP_ENABLED)
UInt8 *xcp_tl_resume_data_ptr_get(unsigned int service_no, UInt32 *size)
{
  return (XCP_TL_RESUME_DATA_PTR_GET_0(service_no, size));
}
#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


#if (XCP_TX_INT == XCP_DISABLED)
void xcp_send_background(unsigned int service_no)
{
  XCP_SEND_BACKGROUND_0(service_no);
}
#endif /* #if (XCP_TX_INT == XCP_DISABLED) */


#if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED)
UInt8 xcp_tl_cmd_proc(unsigned int service_no, UInt8 *cmd_cto_ptr, UInt8 *res_cto_ptr, UInt8 session_status, UInt16 max_daq)
{
  return (XCP_TL_CMD_PROC_0(service_no, cmd_cto_ptr, res_cto_ptr, session_status, max_daq));
}
#endif /* #if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED) */

#endif /* #if ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_TRANSPORT_LAYER_TYPE_0 != XCP_TRANSPORT_LAYER_TYPE_1)) */

#endif /* #ifndef DSXCP_SERVICE_DISABLED */
