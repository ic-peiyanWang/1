/*
 * Copyright (c) 2018, NIO, Inc.  All rights reserved.
 *
 * Any use, reproduction, distribution, and/or transfer of this file is strictly
 * prohibited without the express written permission of the current copyright
 * owner.
 *
 * Any licensed derivative work must  retain this notice.
 *
 */
#include "eth_interface.h"
#include "xcp_if.h"

// DEBUG DATA
// net::tcpServer TCPServerDBG(9991);
// SIN DATA
// net::tcpServer TCPServerSIN(9992);
// SIN + DABUG
// net::tcpServer TCPServerTOT(9998);
// XCP
// net::tcpServer TCPServerXCP(9999);
std::unique_ptr<net::tcpServer> TCPServerXCP;

void TcpServerStart(int port) {
  TCPServerXCP.reset(new (std::nothrow) net::tcpServer(port));
#if DEBUG_DATA
  //////////////////////////////////////////////////
  ////////////////DEBUG PORT 9991///////////////////
  //////////////////////////////////////////////////
  TCPServerDBG.setConnectionCallback([](int sockfd) {
    // nlog_info("Connected:port 9991(DBG) ");
  });

  TCPServerDBG.setDissconnectionCallback([](int sockfd) {
    // nlog_info("Disconnected:port 9991(DBG) ");
  });
#endif
#if DEBUG_SIN
  //////////////////////////////////////////////////
  //////////////////SIN PORT 9992///////////////////
  //////////////////////////////////////////////////
  TCPServerSIN.setConnectionCallback([](int sockfd) {
    // nlog_info("Connected:port 9992(SIN)");
  });

  TCPServerSIN.setDissconnectionCallback([](int sockfd) {
    // nlog_info("Disconnected:port 9992(SIN)");
  });
#endif
#if DEBUG_SIN_DATA
  //////////////////////////////////////////////////
  ////////OLD SIN + DBG PORT 9998///////////////////
  //////////////////////////////////////////////////
  TCPServerTOT.setConnectionCallback([](int sockfd) {
    // nlog_info("Connected:port 9998(SIN_DBG)");
  });

  TCPServerTOT.setDissconnectionCallback([](int sockfd) {
    // nlog_info("Disconnected:port 9998(SIN_DBG)");
  });
#endif
  //////////////////////////////////////////////////
  //////////////////XCP PORT 9999///////////////////
  //////////////////////////////////////////////////
  TCPServerXCP->setMessageCallback([](int sockfd, char* buf, int len) { xcp_if_rx_callback(XCP_SRVNO, buf, len); });

  TCPServerXCP->setConnectionCallback([](int sockfd) {
    // nlog_info("Connected:port 9999(XCP)");
  });

  TCPServerXCP->setDissconnectionCallback([](int sockfd) {
    // nlog_info("Disconnected:port 9999(XCP)");
  });

  /*start service*/
  // TCPServerSIN.start();
  // TCPServerDBG.start();
  // TCPServerTOT.start();
  TCPServerXCP->start();
}
