/*******************************************************************************
*
*  FILE
*    xcp_eth.c
*
*  DESCRIPTION
*    This file contains the Ethernet transport layer of the dSPACE XCP Service.
*
*  COPYRIGHT
*    Copyright 2015, dSPACE GmbH. All rights reserved.
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*
*  AUTHOR(S)
*    Alex Rudel
*    Bastian Kellers
*
*  VERSION
*    2.4.0
*
*  $RCSfile: xcp_eth.c $ $Revision: 1.10 $ $Date: 2015/12/18 11:49:41MEZ $
*
*******************************************************************************/

#include "xcp_eth.h"
#include "xcp_if.h"
#include "ecu_if.h"

/* dSPACE XCP service compilation check */
#ifndef DSXCP_SERVICE_DISABLED

#if (XCP_NO_OF_TRANSPORT_LAYERS_ETH > 0)

/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

/* the maximum length of an Ethernet packet is fixed to 1412 bytes */
#define XCP_MAX_ETH_PACKET_LENGTH                 1412

/* length of XCPonEthernet header */
#define XCP_ETH_HEADER_LENGTH                     4

#define UNREFERENCED_PARAMETER(Param)             (void)(Param)

/* structure of an XCPonEthernet packet */
typedef struct
{
  UInt16 len;
  UInt16 ctr;
  UInt8  data[XCP_MAX_ETH_PACKET_LENGTH - XCP_ETH_HEADER_LENGTH];
} xcp_eth_packet_t;


/* structure of an Ethernet buffer element */
typedef struct
{
  UInt32 reserved;   /* for alignment */
  UInt16 length;
  UInt16 index;
  union
  {
    UInt8            raw_data[XCP_MAX_ETH_PACKET_LENGTH];
    xcp_eth_packet_t xcp_packet;
  } data;
} xcp_eth_buffer_element_t;


/* structure of a buffer status for a Ethernet packet buffer */
typedef struct
{
  UInt8 size;
  UInt8 rp;
  UInt8 wp;
} xcp_eth_buffer_status_t;


/* macro for converting the header length of an XCPonEthernet packet to Intel format */
#if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL)
#define XCP_ETH_HEADER_LENGTH_INTEL_FORMAT(length) (length)
#else /* (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTROLA) */
#define XCP_ETH_HEADER_LENGTH_INTEL_FORMAT(length) ((UInt16)(((UInt16)length) >> 8) + (((UInt16)length & 0xFF) << 8))
#endif /* #if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL) */

/* macro for converting the header counter of an XCPonEthernet packet to Intel format */
#if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL)
#define XCP_ETH_HEADER_CTR_INTEL_FORMAT(ctr)  (ctr)
#else /* (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTROLA) */
#define XCP_ETH_HEADER_CTR_INTEL_FORMAT(ctr)  ((UInt16)(((UInt16)ctr) >> 8) + (((UInt16)ctr & 0xFF) << 8))
#endif /* #if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL) */


/*******************************************************************************
  object declarations
*******************************************************************************/

/* buffers for XCP packets */
#if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1)
static xcp_eth_buffer_element_t xcp_receive_buffer[1];
static xcp_eth_buffer_element_t xcp_res_cto_buffer[1];
  #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED))
static xcp_eth_buffer_element_t xcp_daq_dto_buffer[XCP_ETH_FIFO_SIZE_DAQ_DTO_0];
static xcp_eth_buffer_status_t  xcp_daq_dto_buffer_status[1];
  #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED)) */
#else /* (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 2) */
static xcp_eth_buffer_element_t xcp_receive_buffer[2];
static xcp_eth_buffer_element_t xcp_res_cto_buffer[2];
  #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED))
static xcp_eth_buffer_element_t xcp_daq_dto_buffer[XCP_ETH_FIFO_SIZE_DAQ_DTO_0 + XCP_ETH_FIFO_SIZE_DAQ_DTO_1];
static xcp_eth_buffer_status_t  xcp_daq_dto_buffer_status[2];
  #endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED)) */
#endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1) */

/* TX packet counter for XCPonEthernet packets */
static UInt16 xcp_tx_packet_ctr[XCP_NO_OF_TRANSPORT_LAYERS_ETH];


/*******************************************************************************
  function prototypes
*******************************************************************************/


/*******************************************************************************
  function declarations
*******************************************************************************/

/******************************************************************************/
/* dSPACE XCP Ethernet transport layer API functions                          */
/******************************************************************************/

/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_init
*
*
*  SYNTAX
*    void xcp_eth_init(unsigned int service_no)
*
*  DESCRIPTION
*    This function initializes the Ethernet transport layer of the dSPACE XCP
*    service.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_eth_init(unsigned int service_no)
{
  /* initialize the Ethernet driver */
  DSXCP_eth_init(service_no);

  /* initialize all buffer statuses */
  xcp_receive_buffer[service_no].length = 0;
  xcp_res_cto_buffer[service_no].length = 0;

#if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED))
  xcp_daq_dto_buffer_status[service_no].size = 0;

  #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1)
  xcp_daq_dto_buffer_status[service_no].rp = 0;
  xcp_daq_dto_buffer_status[service_no].wp = 0;
  #else /* (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 2) */
  if (service_no == 0)
  {
    xcp_daq_dto_buffer_status[service_no].rp = 0;
    xcp_daq_dto_buffer_status[service_no].wp = 0;
  }
  else
  {
    xcp_daq_dto_buffer_status[service_no].rp = XCP_ETH_FIFO_SIZE_DAQ_DTO_0;
    xcp_daq_dto_buffer_status[service_no].wp = XCP_ETH_FIFO_SIZE_DAQ_DTO_0;
  }
  #endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1) */
#endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED)) */

  /* initialize TX packet counter */
  xcp_tx_packet_ctr[service_no] = 0;
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_receive_ptr_get
*
*
*  SYNTAX
*    UInt8 *xcp_eth_receive_ptr_get(unsigned int service_no, UInt8 *pid_off_flag, UInt16 *daq)
*
*  DESCRIPTION
*    This function polls the Ethernet driver for a new Ethernet packet and
*    either returns a pointer to the new XCP packet or a NULL pointer.
*
*  PARAMETERS
*    service_no:   service instance number (0 or 1)
*    pid_off_flag: flag if PID_OFF is used (1) or not (0)
*    daq:          daq list number (if pid_off_flag is 1)
*
*  RETURNS
*    pointer to received XCP packet (CMD CTO or STIM DTO packet) or NULL
*
*  REMARKS
*
*******************************************************************************/
UInt8 *xcp_eth_receive_ptr_get(unsigned int service_no, UInt8 *pid_off_flag, UInt16 *daq)
{
  UNREFERENCED_PARAMETER(daq);

  if (xcp_receive_buffer[service_no].length == 0)
  {
    /* poll for a new Ethernet packet */
    if (DSXCP_eth_packet_receive(service_no, xcp_receive_buffer[service_no].data.raw_data, &xcp_receive_buffer[service_no].length) == DSXCP_NO_ERROR)
    {
      *pid_off_flag = 0;

      /* a new Ethernet packet has been received, check for valid XCP packet */
      if (xcp_receive_buffer[service_no].length > XCP_ETH_HEADER_LENGTH)
      {
        if (xcp_receive_buffer[service_no].length >= (xcp_receive_buffer[service_no].data.raw_data[0] + (xcp_receive_buffer[service_no].data.raw_data[1] << 8) + XCP_ETH_HEADER_LENGTH))
        {
          xcp_receive_buffer[service_no].index = 0;

          /* return pointer to data of XCP packet */
          return (xcp_receive_buffer[service_no].data.xcp_packet.data);
        }
        else
        {
          /* invalid Ethernet packet received, return NULL */
          xcp_receive_buffer[service_no].length = 0;
          return (NULL);
        }
      }
      else
      {
        /* invalid Ethernet packet received, return NULL */
        xcp_receive_buffer[service_no].length = 0;
        return (NULL);
      }
    }
    else
    {
      /* no Ethernet packet received, return NULL */
      return (NULL);
    }
  }
  else
  {
    /* further XCP packet is pending in receive buffer */
    if (xcp_receive_buffer[service_no].index > (XCP_MAX_ETH_PACKET_LENGTH - XCP_ETH_HEADER_LENGTH))
    {
      xcp_receive_buffer[service_no].length = 0;
      return (NULL);
    }

    *pid_off_flag = 0;

  #ifndef XCP_ETH_DISABLE_ALIGNMENT_CHECK
    /* check if pending XCP packet is aligned to a 4 byte boundary */
    if (xcp_receive_buffer[service_no].index % 4)
    {
      /* XCP packet is unaligned */
      UInt16 i;
      UInt16 xcp_packet_length;

      xcp_packet_length = xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index] + (xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index + 1] << 8);

      /* copy XCP packet to beginning of buffer for alignment purposes */
      for (i = 0; i < (xcp_packet_length + XCP_ETH_HEADER_LENGTH); i++)
      {
        xcp_receive_buffer[service_no].data.raw_data[i] = xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index + i];
      }

      /* return pointer to data of XCP packet */
      return (xcp_receive_buffer[service_no].data.xcp_packet.data);
    }
    else
  #endif
    {
      /* XCP packet is aligned */
      xcp_eth_packet_t *xcp_eth_packet;

      xcp_eth_packet = (xcp_eth_packet_t*)&xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index];

      /* return pointer to data of XCP packet */
      return (xcp_eth_packet->data);
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_receive_ptr_release
*
*
*  SYNTAX
*    void xcp_eth_receive_ptr_release(unsigned int service_no)
*
*  DESCRIPTION
*    This function releases the receive pointer requested by the function
*    xcp_eth_receive_ptr_get(). After this function has been called, the XCP
*    packet stored in the receive buffer is obsolete and may be overwritten by
*    a new XCP packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_eth_receive_ptr_release(unsigned int service_no)
{
  if (xcp_receive_buffer[service_no].length > 0)
  {
    UInt16 xcp_packet_length;

    xcp_packet_length = xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index] + (xcp_receive_buffer[service_no].data.raw_data[xcp_receive_buffer[service_no].index + 1] << 8);
    xcp_receive_buffer[service_no].index += xcp_packet_length + XCP_ETH_HEADER_LENGTH;

    if (xcp_receive_buffer[service_no].index == xcp_receive_buffer[service_no].length)
    {
      xcp_receive_buffer[service_no].length = 0;
    }
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_res_cto_ptr_get
*
*
*  SYNTAX
*    UInt8 *xcp_eth_res_cto_ptr_get(unsigned int service_no)
*
*  DESCRIPTION
*    This function returns a pointer to the buffer for RES/ERR/EV/SERV CTO
*    packets. If the buffer is full, it will return a NULL pointer.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    pointer to RES/ERR/EV/SERV CTO or NULL
*
*  REMARKS
*
*******************************************************************************/
UInt8 *xcp_eth_res_cto_ptr_get(unsigned int service_no)
{
  /* if RES/ERR/EV/SERV CTO buffer is empty, return pointer else NULL */
  if (xcp_res_cto_buffer[service_no].length == 0)
  {
    return (xcp_res_cto_buffer[service_no].data.xcp_packet.data);
  }
  else
  {
    return (NULL);
  }
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_res_cto_send
*
*
*  SYNTAX
*    void xcp_eth_res_cto_send(unsigned int service_no, UInt8 length)
*
*  DESCRIPTION
*    This function sends a RES/ERR/EV/SERV CTO packet.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    length:     length of RES/ERR/EV/SERV CTO packet
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_eth_res_cto_send(unsigned int service_no, UInt8 length)
{
  DSXCP_INT_SAVE_AND_DISABLE();

  /* configure header of XCPonEthernet packet */
  xcp_res_cto_buffer[service_no].data.xcp_packet.len = XCP_ETH_HEADER_LENGTH_INTEL_FORMAT(length);
  xcp_res_cto_buffer[service_no].data.xcp_packet.ctr = XCP_ETH_HEADER_CTR_INTEL_FORMAT(xcp_tx_packet_ctr[service_no]);

  /* try to send RES/ERR/EV/SERV CTO packet */
  if (DSXCP_eth_packet_send(service_no, xcp_res_cto_buffer[service_no].data.raw_data, length + XCP_ETH_HEADER_LENGTH) != DSXCP_NO_ERROR)
  {
    /* sending was not successful, RES/ERR/EV/SERV CTO packet will be kept in the buffer */
    xcp_res_cto_buffer[service_no].length = length + XCP_ETH_HEADER_LENGTH;
  }
  else
  {
	  //MOD: psw@2016.10.28
	  xcp_res_cto_buffer[service_no].length = 0;
    /* increment TX packet counter */
    xcp_tx_packet_ctr[service_no]++;
  }

  DSXCP_INT_RESTORE();
}


#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_daq_dto_buffer_send
*
*
*  SYNTAX
*    UInt8 xcp_eth_daq_dto_buffer_send(unsigned int service_no, UInt16 daq, UInt16 length, UInt8 *data)
*
*  DESCRIPTION
*    This function sends a DAQ DTO, which is buffered in the DTO buffer of the
*    protocol layer.
*    If no former DAQ DTO packet is pending, the current DAQ DTO packet will
*    be sent directly, else it will be kept in the DAQ DTO buffer.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*    length:     length of DAQ DTO
*    data:       data of DAQ DTO
*
*  RETURNS
*    DSXCP_NO_ERROR:              DAQ DTO sent successfully
*    DSXCP_ETH_PACKET_SEND_ERROR: DAQ DTO not sent
*
*  REMARKS
*    This function will only be compiled, if the resource DAQ is enabled.
*
*******************************************************************************/
UInt8 xcp_eth_daq_dto_buffer_send(unsigned int service_no, UInt16 daq, UInt16 length, UInt8 *data)
{
  xcp_eth_packet_t xcp_eth_packet;
  UInt8            i;

  /* prepare XCPonEthernet packet */
  xcp_eth_packet.len = XCP_ETH_HEADER_LENGTH_INTEL_FORMAT(length);
  xcp_eth_packet.ctr = XCP_ETH_HEADER_CTR_INTEL_FORMAT(xcp_tx_packet_ctr[service_no]);
  for (i = 0; i < length; i++)
  {
    xcp_eth_packet.data[i] = data[i];
  }

  /* try to send DAQ DTO packet */
  if (DSXCP_eth_packet_send(service_no, (UInt8 *)&xcp_eth_packet, length + XCP_ETH_HEADER_LENGTH) == DSXCP_NO_ERROR)
  {
    /* increment TX packet counter */
    xcp_tx_packet_ctr[service_no]++;

    return (DSXCP_NO_ERROR);
  }
  else
  {
    return (DSXCP_ETH_PACKET_SEND_ERROR);
  }
}

#else /* (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED) */

/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_daq_dto_ptr_get
*
*
*  SYNTAX
*    UInt8 *xcp_eth_daq_dto_ptr_get(unsigned int service_no, UInt16 daq)
*
*  DESCRIPTION
*    This function returns a pointer to the next free space in the send buffer
*    (FIFO) for DAQ DTO packets. If no space is left, it will return a NULL pointer.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*
*  RETURNS
*    pointer to DAQ DTO or NULL
*
*  REMARKS
*    This function will only be compiled, if the resource DAQ is enabled.
*    The parameter daq is not used here, since there is only one buffer for
*    all DAQ lists implemented. Therefore a differentiation is not necessary.
*
*******************************************************************************/
UInt8 *xcp_eth_daq_dto_ptr_get(unsigned int service_no, UInt16 daq)
{
  UNREFERENCED_PARAMETER(daq);

  /* if DAQ DTO buffer is not full, return pointer else NULL */
#if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1)
  if (xcp_daq_dto_buffer_status[service_no].size < XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
  {
    return (xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.xcp_packet.data);
  }
  else
  {
    return (NULL);
  }
#else /* (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 2) */
  if (service_no == 0)
  {
    if (xcp_daq_dto_buffer_status[service_no].size < XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
    {
      return (xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.xcp_packet.data);
    }
    else
    {
      return (NULL);
    }
  }
  else
  {
    if (xcp_daq_dto_buffer_status[service_no].size < XCP_ETH_FIFO_SIZE_DAQ_DTO_1)
    {
      return (xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.xcp_packet.data);
    }
    else
    {
      return (NULL);
    }
  }
#endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1) */
}


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_daq_dto_send
*
*
*  SYNTAX
*    void xcp_eth_daq_dto_send(unsigned int service_no, UInt16 daq, UInt16 length)
*
*  DESCRIPTION
*    This function sends a DAQ DTO.
*    If no former DAQ DTO packet is pending, the current DAQ DTO packet will
*    be sent directly, else it will be kept in the DAQ DTO buffer.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    daq:        DAQ list number
*    length:     length of DAQ DTO
*
*  RETURNS
*    none
*
*  REMARKS
*    This function will only be compiled, if the resource DAQ is enabled.
*
*******************************************************************************/
void xcp_eth_daq_dto_send(unsigned int service_no, UInt16 daq, UInt16 length)
{
  UInt8 send_flag = 0;  /* flag if sending of DAQ packet was successful (default: not successful) */
  UNREFERENCED_PARAMETER(daq);

  /* configure header of XCPonEthernet packet */
  xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.xcp_packet.len = XCP_ETH_HEADER_LENGTH_INTEL_FORMAT(length);
  xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.xcp_packet.ctr = XCP_ETH_HEADER_CTR_INTEL_FORMAT(xcp_tx_packet_ctr[service_no]);

#ifndef XCP_ETH_DISABLE_FOREGROUND_SENDING
  /* send DAQ DTO only, if no former DAQ DTO packet is pending */
  if (xcp_daq_dto_buffer_status[service_no].size == 0)
  {
    /* try to send DAQ DTO packet */
    if (DSXCP_eth_packet_send(service_no, xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].data.raw_data, length + XCP_ETH_HEADER_LENGTH) == DSXCP_NO_ERROR)
    {
      /* increment TX packet counter */
      xcp_tx_packet_ctr[service_no]++;

      send_flag = 1;
    }
	else
	{
		send_flag = 0;
	}
  }
#endif /* #ifndef XCP_ETH_DISABLE_FOREGROUND_SENDING */

  /* if DAQ DTO packet should not be sent or sending was not successful, DAQ DTO packet will be kept in the buffer */
  if (send_flag == 0)
  {
    xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].wp].length = length + XCP_ETH_HEADER_LENGTH;
    xcp_daq_dto_buffer_status[service_no].size++;
    xcp_daq_dto_buffer_status[service_no].wp++;

    /* check for DAQ DTO buffer wraparound */
  #if (CXP_NO_OF_TRANSPORT_LAYERS_ETH == 1)
    if (xcp_daq_dto_buffer_status[service_no].wp == XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
    {
      xcp_daq_dto_buffer_status[service_no].wp = 0;
    }
  #else /* (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 2) */
    if (service_no == 0)
    {
      if (xcp_daq_dto_buffer_status[service_no].wp == XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
      {
        xcp_daq_dto_buffer_status[service_no].wp = 0;
      }
    }
    else
    {
      if (xcp_daq_dto_buffer_status[service_no].wp == (XCP_ETH_FIFO_SIZE_DAQ_DTO_0 + XCP_ETH_FIFO_SIZE_DAQ_DTO_1))
      {
        xcp_daq_dto_buffer_status[service_no].wp = XCP_ETH_FIFO_SIZE_DAQ_DTO_0;
      }
    }
  #endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1) */
  }
}
#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */


#if (XCP_RESUME_MODE == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_resume_data_ptr_get
*
*
*  SYNTAX
*    UInt8 *xcp_eth_resume_data_ptr_get(unsigned int service_no, UInt32* size)
*
*  DESCRIPTION
*    This function returns a pointer to Ethernet transport layer specific data,
*    which must be stored into non-volatile memory, if the resume mode is
*    enabled.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*    size:       pointer to size of resume mode data
*
*  RETURNS
*    pointer to resume mode data
*
*  REMARKS
*    This function will only be compiled, if the resource DAQ and the resume
*    mode feature are enabled.
*
*******************************************************************************/
UInt8 *xcp_eth_resume_data_ptr_get(unsigned int service_no, UInt32 *size)
{
  *size = 0;
  return (NULL);
}
#endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */

#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */


/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_send_background
*
*
*  SYNTAX
*    void xcp_eth_send_background(unsigned int service_no)
*
*  DESCRIPTION
*    This function sends RES/ERR/EV/SERV CTO and DAQ DTO packets and is
*    called in the background function of the dSPACE XCP service.
*
*  PARAMETERS
*    service_no: service instance number (0 or 1)
*
*  RETURNS
*    none
*
*  REMARKS
*
*******************************************************************************/
void xcp_eth_send_background(unsigned int service_no)
{
  /* check, if RES/ERR/EV/SERV CTO packet or a DAQ DTO packet is pending */
  if (xcp_res_cto_buffer[service_no].length > 0)
  {
    DSXCP_INT_SAVE_AND_DISABLE();

    /* update counter of XCPonEthernet packet */
    xcp_res_cto_buffer[service_no].data.xcp_packet.ctr = XCP_ETH_HEADER_CTR_INTEL_FORMAT(xcp_tx_packet_ctr[service_no]);

    /* try to send RES/ERR/EV/SERV CTO packet */
    if (DSXCP_eth_packet_send(service_no, xcp_res_cto_buffer[service_no].data.raw_data, xcp_res_cto_buffer[service_no].length) == DSXCP_NO_ERROR)
    {
      /* sending was successful, remove RES/ERR/EV/SERV CTO packet from the buffer */
      xcp_res_cto_buffer[service_no].length = 0;

      /* increment TX packet counter */
      xcp_tx_packet_ctr[service_no]++;
    }

    DSXCP_INT_RESTORE();
  }
#if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED))
  else if (xcp_daq_dto_buffer_status[service_no].size > 0)
  {
  #ifdef XCP_ETH_ENABLE_BLOCK_SENDING
    UInt8 no_of_packets;

    no_of_packets = xcp_daq_dto_buffer_status[service_no].size;
    while (no_of_packets-- > 0)
  #endif // #ifdef XCP_ETH_ENABLE_BLOCK_SENDING
    {
      DSXCP_INT_SAVE_AND_DISABLE();

      /* update counter of XCPonEthernet packet */
      xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].rp].data.xcp_packet.ctr = XCP_ETH_HEADER_CTR_INTEL_FORMAT(xcp_tx_packet_ctr[service_no]);

      /* try to send DAQ DTO packet */
      if (DSXCP_eth_packet_send(service_no, xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].rp].data.raw_data, xcp_daq_dto_buffer[xcp_daq_dto_buffer_status[service_no].rp].length) == DSXCP_NO_ERROR)
      {
        /* sending was successful, remove DAQ DTO packet from the buffer */
        xcp_daq_dto_buffer_status[service_no].size--;
        xcp_daq_dto_buffer_status[service_no].rp++;

        /* check for DAQ DTO buffer wraparound */
      #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1)
        if (xcp_daq_dto_buffer_status[service_no].rp == XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
        {
          xcp_daq_dto_buffer_status[service_no].rp = 0;
        }
      #else /* (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 2) */
        if (service_no == 0)
        {
          if (xcp_daq_dto_buffer_status[service_no].rp == XCP_ETH_FIFO_SIZE_DAQ_DTO_0)
          {
            xcp_daq_dto_buffer_status[service_no].rp = 0;
          }
        }
        else
        {
          if (xcp_daq_dto_buffer_status[service_no].rp == (XCP_ETH_FIFO_SIZE_DAQ_DTO_0 + XCP_ETH_FIFO_SIZE_DAQ_DTO_1))
          {
            xcp_daq_dto_buffer_status[service_no].rp = XCP_ETH_FIFO_SIZE_DAQ_DTO_0;
          }
        }
      #endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH == 1) */

        /* increment TX packet counter */
        xcp_tx_packet_ctr[service_no]++;
      }

      DSXCP_INT_RESTORE();
    }
  }
#endif /* #if ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_PL_DAQ_DTO_BUFFER == XCP_DISABLED)) */
}


#if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED)
/*******************************************************************************
*
*  FUNCTION
*    xcp_eth_cmd_proc
*
*
*  SYNTAX
*    UInt8 xcp_eth_cmd_proc(unsigned int service_no, UInt8 *cmd_cto_ptr, UInt8 *res_cto_ptr, UInt8 session_status, UInt16 max_daq)
*
*  DESCRIPTION
*    This function is the command processor for Ethernet transport layer specific
*    commands.
*
*  PARAMETERS
*    service_no:     service instance number (0 or 1)
*    cmd_cto_ptr:    pointer to CMD CTO packet
*    res_cto_ptr:    pointer to RES CTO packet
*    session_status: current session status
*    max_daq:        number of available DAQ lists
*
*  RETURNS
*    length of RES CTO packet
*
*  REMARKS
*    This function will only be compiled, if transport layer commands are
*    enabled.
*
*******************************************************************************/
UInt8 xcp_eth_cmd_proc(unsigned int service_no, UInt8 *cmd_cto_ptr, UInt8 *res_cto_ptr, UInt8 session_status, UInt16 max_daq)
{
  return (0);
}
#endif /* #if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED) */

#endif /* #if (XCP_NO_OF_TRANSPORT_LAYERS_ETH > 0) */

#endif /* #ifndef DSXCP_SERVICE_DISABLED */
