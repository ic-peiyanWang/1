/*******************************************************************************
*
*  FILE
*    xcp_prot.h
*
*  DESCRIPTION
*    This file contains the protocol layer of the dSPACE XCP Service.
*
*  COPYRIGHT
*    Copyright 2015, dSPACE GmbH. All rights reserved.
*
*  LICENSE AGREEMENT FOR THE dSPACE XCP SERVICE
*
*    IMPORTANT - USE OF THIS SERVICE IS SUBJECT TO LICENSE RESTRICTIONS
*    READ THIS LICENSE AGREEMENT CAREFULLY BEFORE USING THE SERVICE
*
*    This license is a legal Agreement between you, the end user, either
*    individually or as an authorized representative of the company acquiring
*    the license, and dSPACE GmbH acting directly or through its subsidiaries or
*    authorized distributors (collectively "dSPACE"), concerning the use of the
*    C code containing the dSPACE XCP Service (hereinafter referred to as "the
*    Service") together with any other materials which are provided for use in
*    connection with the Service, including without limitation the executable
*    for installation of the Service, any associated user manual and internal
*    documentation (hereinafter collectively referred to as "the Program"). BY
*    IMPLEMENTING THE EXECUTABLE AND INSTALLING THE PROGRAM, YOU AGREE TO COMPLY
*    WITH THE FOLLOWING TERMS AND RESTRICTIONS. IF YOU DO NOT AGREE TO THE TERMS
*    OF THIS AGREEMENT, DO NOT INSTALL OR USE THE PROGRAM AND PROMPTLY RETURN IT
*    TO THE PLACE WHERE YOU OBTAINED IT, OR DELETE THE PROGRAM IF YOU RECEIVED
*    IT ELECTRONICALLY.
*
*
*    1. Grant of License
*
*    Unless explicitly agreed otherwise, dSPACE grants you a nonexclusive
*    license to use the Program and execute the Service as described in the
*    respective product description or documentation for the sole purpose of
*    product development involving dSPACE tools.
*
*    2. Restrictions of Use
*
*    You may not market, distribute or transfer copies of the Program, in whole
*    or in part, to third parties (including any subsidiary, affiliate or
*    company under common control with you) or transfer the Program (directly or
*    indirectly) via Internet or network applications (such as Citrix, Microsoft
*    Remote Desktop or other terminal servers) or grant third parties any access
*    to the Program by any means. You may not rent, lease or loan the Program.
*
*    These restrictions do not prevent you from providing compiled object code
*    versions of the Service as part of your own ECU code to third parties,
*    subject to the condition that
*
*    a) This takes place in the course of a project where (amongst others)
*       dSPACE tools are used, and
*    b) The code is used for the sole purpose of product development and not for
*       use in any end product or production.
*
*    The recipient of your respective ECU code needs to be instructed
*    accordingly and shall undertake to comply with these restrictions and to
*    agree to the Limitation of Liability according to Clause 4 hereunder.
*    dSPACE reserves the right to ask for written confirmation that appropriate
*    instructions have been issued.
*
*    Upon request and at the sole discretion of dSPACE, you may be granted
*    permission to provide the Service itself, in whole or in part, to third
*    parties as part of your own ECU source code, subject to the conditions
*    stated above. To be valid, such permission needs to be granted in writing
*    by dSPACE.
*
*    For the avoidance of doubt, in any case any transfer of or granting of
*    access to parts of the Program other than the Service itself is explicitly
*    prohibited.
*
*    3. Confidentiality
*
*    dSPACE considers the Program to contain valuable intellectual property of
*    dSPACE, the unauthorized disclosure of which could cause irreparable harm
*    to dSPACE. You agree to use reasonable efforts not to disclose the Program
*    to any third parties (including any subsidiary, affiliate or company under
*    common control with you) and not to use the Program other than for the
*    purposes authorized by dSPACE.
*
*    4. Limitation of Liability
*
*    The Program was designed and tested solely for use in research and product
*    development and is supplied to you by dSPACE exclusively for this purpose.
*    It must be put into operation exclusively by suitably trained and expert
*    operating personnel under strict compliance with the safety measures
*    described in the software documentation. Any use of the Program or compiled
*    object code versions of the Service for purposes and under conditions other
*    than the above, including but not only any use in end products, constitutes
*    inappropriate use.
*
*    Any liability by dSPACE under mandatory law, including but not restricted
*    to product liability law, for damages of any kind that may be caused by
*    using the Program or compiled object code versions of the Service in areas
*    other than product development shall be limited, even to the point of total
*    exclusion, as the case may be. In the event of claims by third parties
*    against dSPACE that are due to such inappropriate use of the Program or of
*    compiled object code versions of the Service by you or with your
*    permission, you agree to indemnify dSPACE against all such claims.
*
*    In addition, the regulations on liability according to the General Terms
*    and Conditions of dSPACE GmbH as attached to any dSPACE offer apply
*    accordingly. A copy of the General Terms and Conditions can also be
*    obtained at: info@dspace.de.
*
*    5. Miscellaneous
*
*    Any amendments or additions to this Agreement must be made in writing and
*    must be expressly marked as such. This also applies to this written form
*    requirement.
*
*    In the event that any of the above terms is or becomes invalid, the
*    remaining terms shall continue in full force and effect.
*
*    Any failure to enforce, or any waiver of, any right under this Agreement by
*    dSPACE shall not be construed as a waiver of future rights.
*
*    The legal regulations shall apply in addition to the terms of this
*    Agreement, except in cases where they conflict with said terms. This
*    Agreement shall be governed by the laws of the Federal Republic of Germany,
*    excluding the UN Convention on Contracts for the International Sale of
*    Goods (CISG).
*
*    Paderborn, Germany, is agreed as the exclusive place of jurisdiction for
*    all disputes arising from or in connection with this Agreement, unless a
*    different place of jurisdiction is mandatory on the basis of legal
*    requirements.
*
*  REMARKS
*
*  AUTHOR(S)
*    Bastian Kellers
*
*  VERSION
*    2.4.0
*
*  $RCSfile: xcp_prot.h $ $Revision: 1.9 $ $Date: 2015/11/06 14:49:42MEZ $
*
*******************************************************************************/
#ifndef __XCP_PROT_H__
#define __XCP_PROT_H__

#include "xcp_prot_cfg.h"


/**** configuration checks ****************************************************/

/* check of XCP_NO_OF_SERVICE_INSTANCES */
#if (XCP_NO_OF_SERVICE_INSTANCES != 1) && (XCP_NO_OF_SERVICE_INSTANCES != 2)
  #error DSXCP configuration error: The number of service instances must be 1 or 2.
#endif

/* check of XCP_TRANSPORT_LAYER_TYPE_0 */
#if ((XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_CAN) || \
     (XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_USB) || \
     (XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_ETH) || \
     (XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_FLX) || \
     (XCP_TRANSPORT_LAYER_TYPE_0 == XCP_TRANSPORT_LAYER_TYPE_SHMEM))
  /* XCP_TRANSPORT_LAYER_TYPE_0 is valid */
#else
  #error "DSXCP configuration error: XCP_TRANSPORT_LAYER_TYPE_0 is invalid."
#endif

#if (XCP_NO_OF_SERVICE_INSTANCES == 2)

/* check of XCP_TRANSPORT_LAYER_TYPE_1 */
#if ((XCP_TRANSPORT_LAYER_TYPE_1 == XCP_TRANSPORT_LAYER_TYPE_CAN) || \
     (XCP_TRANSPORT_LAYER_TYPE_1 == XCP_TRANSPORT_LAYER_TYPE_USB) || \
     (XCP_TRANSPORT_LAYER_TYPE_1 == XCP_TRANSPORT_LAYER_TYPE_ETH) || \
     (XCP_TRANSPORT_LAYER_TYPE_1 == XCP_TRANSPORT_LAYER_TYPE_FLX) || \
     (XCP_TRANSPORT_LAYER_TYPE_1 == XCP_TRANSPORT_LAYER_TYPE_SHMEM))
  /* XCP_TRANSPORT_LAYER_TYPE_1 is valid */
#else
  #error "DSXCP configuration error: XCP_TRANSPORT_LAYER_TYPE_1 is invalid."
#endif

#endif /* (XCP_NO_OF_SERVICE_INSTANCES == 2) */

/* check of XCP_BYTE_ORDER */
#if ((XCP_BYTE_ORDER == XCP_BYTE_ORDER_INTEL) || (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTOROLA))
  /* XCP_BYTE_ORDER is valid */
#else
  #error "DSXCP configuration error: XCP_BYTE_ORDER is invalid."
#endif

#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)

/* check of XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ */
#if ((XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_BYTE)  || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_WORD)  || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_DWORD) || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ == XCP_SIZE_QWORD))
  /* XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ is valid */
#else
  #error "DSXCP configuration error: XCP_GRANULARITY_ODT_ENTRY_SIZE_DAQ is invalid."
#endif

#if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)

/* check of XCP_TIMESTAMP_UNIT */
#if ((XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_1NS)   || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_10NS)  || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_100NS) || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_1US)   || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_10US)  || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_100US) || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_1MS)   || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_10MS)  || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_100MS) || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_1S)    || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_1PS)   || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_10PS)  || \
     (XCP_TIMESTAMP_UNIT == XCP_TIMESTAMP_UNIT_100PS))
  /* XCP_TIMESTAMP_UNIT is valid */
#else
  #error "DSXCP configuration error: XCP_TIMESTAMP_UNIT is invalid."
#endif

/* check of XCP_TIMESTAMP_SIZE */
#if ((XCP_TIMESTAMP_SIZE == XCP_SIZE_BYTE)    || \
     (XCP_TIMESTAMP_SIZE == XCP_SIZE_WORD)    || \
     (XCP_TIMESTAMP_SIZE == XCP_SIZE_DWORD))
  /* XCP_TIMESTAMP_SIZE is valid */
#else
  #error "DSXCP configuration error: XCP_TIMESTAMP_SIZE is invalid."
#endif

#endif /* #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED) */

#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED)

#if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB))

#if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED)

/* check of XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 */
#if ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0) > 124)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 must be <= 124."
#endif

/* check of XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0 */
#if ((XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0) > 124)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0 must be <= 124."
#endif

#else /* (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_DISABLED) */

/* check of XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 */
#if ((XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 > 124))
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 must be <= 124."
#endif

/* check of XCP_NO_OF_CONFIGURABLE_ODTS_0 */
#if (XCP_NO_OF_CONFIGURABLE_ODTS_0 > 124)
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_ODTS_0 must be <= 124."
#endif

#endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */

#else /* ((XCP_OVERLOAD_INDICATION == XCP_DISABLED) || (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */

#if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED)

/* check of XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 */
#if ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0) > 252)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_DAQ_LISTS_0 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 must be <= 252."
#endif

/* check of XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0 */
#if ((XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0) > 252)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_ODTS_0 + XCP_NO_OF_CONFIGURABLE_ODTS_0 must be <= 252."
#endif

#else /* (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_DISABLED) */

/* check of XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 */
#if ((XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 > 252))
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0 must be <= 252."
#endif

/* check of XCP_NO_OF_CONFIGURABLE_ODTS_0 */
#if (XCP_NO_OF_CONFIGURABLE_ODTS_0 > 252)
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_ODTS_0 must be <= 252."
#endif

#endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */

#endif /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)) */

#endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */

#if (XCP_NO_OF_SERVICE_INSTANCES == 2)

#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED)

#if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB))

#if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED)

/* check of XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 */
#if ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1) > 124)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 must be <= 124."
#endif

/* check of XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1 */
#if ((XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1) > 124)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1 must be <= 124."
#endif

#else /* (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_DISABLED) */

/* check of XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 */
#if ((XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 > 124))
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 must be <= 124."
#endif

/* check of XCP_NO_OF_CONFIGURABLE_ODTS_1 */
#if (XCP_NO_OF_CONFIGURABLE_ODTS_1 > 124)
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_ODTS_1 must be <= 124."
#endif

#endif /* #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED) */

#else /* ((XCP_OVERLOAD_INDICATION == XCP_DISABLED) || (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */

#if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED)

/* check of XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 */
#if ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1) > 252)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_DAQ_LISTS_1 + XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 must be <= 252."
#endif

/* check of XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1 */
#if ((XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1) > 252)
  #error "DSXCP configuration error: XCP_NO_OF_PREDEFINED_ODTS_1 + XCP_NO_OF_CONFIGURABLE_ODTS_1 must be <= 252."
#endif

#else /* (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_DISABLED) */

/* check of XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 */
#if ((XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 > 252))
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1 must be <= 252."
#endif

/* check of XCP_NO_OF_CONFIGURABLE_ODTS_1 */
#if (XCP_NO_OF_CONFIGURABLE_ODTS_1 > 252)
  #error "DSXCP configuration error: XCP_NO_OF_CONFIGURABLE_ODTS_1 must be <= 252."
#endif

#endif /* #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED) */

#endif /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)) */

#endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */

#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */

#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)

/* check of XCP_RESOURCE_SUPPORTED_STIM */
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_DISABLED)
  #error "DSXCP configuration error: XCP_RESOURCE_SUPPORTED_STIM cannot be enabled, if XCP_RESOURCE_SUPPORTED_DAQ is disabled."
#endif

/* check of XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM */
#if ((XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM == XCP_SIZE_BYTE)  || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM == XCP_SIZE_WORD)  || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM == XCP_SIZE_DWORD) || \
     (XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM == XCP_SIZE_QWORD))
  /* XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM is valid */
#else
  #error "DSXCP configuration error: XCP_GRANULARITY_ODT_ENTRY_SIZE_STIM is invalid."
#endif

#if (XCP_DOUBLE_BUFFER == XCP_DISABLED)

/* check of XCP_FAILSAFE_BUFFER */
#if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
  #error "DSXCP configuration error: XCP_FAILSAFE_BUFFER cannot be enabled, if XCP_DOUBLE_BUFFER is disabled."
#endif

/* check of XCP_FAILURE_CHECKING */
#if (XCP_FAILURE_CHECKING == XCP_ENABLED)
  #error "DSXCP configuration error: XCP_FAILURE_CHECKING cannot be enabled, if XCP_DOUBLE_BUFFER is disabled."
#endif

#endif /* #if (XCP_DOUBLE_BUFFER == XCP_DISABLED) */

/* check of XCP_CONSISTENCY_WAIT and XCP_TIMESTAMP_SUPPORTED */
#if ((XCP_CONSISTENCY_WAIT == XCP_ENABLED) && (XCP_TIMESTAMP_SUPPORTED == XCP_DISABLED))
  #error "DSXCP configuration error: XCP_CONSISTENCY_WAIT cannot be enabled, if XCP_TIMESTAMP_SUPPORTED is disabled."
#endif

#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */


/*******************************************************************************
  constant, macro and type definitions
*******************************************************************************/

/* return values of DSXCP_service() */
#ifndef DSXCP_NO_ERROR
#define DSXCP_NO_ERROR                            0x00
#endif
#define DSXCP_DAQ_ACTIVE                          0x00
#define DSXCP_DAQ_INACTIVE                        0x01
#define DSXCP_NEW_DATA                            0x00
#define DSXCP_OLD_DATA                            0x02
#define DSXCP_NO_DATA_COPIED                      0x04
#define DSXCP_FAILSAFE_DATA                       0x08
#define DSXCP_NO_DATA_AVAILABLE                   0x10

/* defines for DAQ list configuration */
#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
  #define XCP_MIN_DAQ_0                           0
  #define XCP_MAX_DAQ_0                           0
  #define XCP_NO_OF_ODTS_0                        0
  #define XCP_NO_OF_ODT_ENTRIES_0                 0
#else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_DISABLED) */
  #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED)
    #define XCP_MIN_DAQ_0                           (XCP_NO_OF_PREDEFINED_DAQ_LISTS_0)
    #define XCP_MAX_DAQ_0                           ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_0)   + (XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0))
    #define XCP_NO_OF_ODTS_0                        ((XCP_NO_OF_PREDEFINED_ODTS_0)        + (XCP_NO_OF_CONFIGURABLE_ODTS_0))
    #define XCP_NO_OF_ODT_ENTRIES_0                 ((XCP_NO_OF_PREDEFINED_ODT_ENTRIES_0) + (XCP_NO_OF_CONFIGURABLE_ODT_ENTRIES_0))
  #else /* (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_DISABLED) */
    #define XCP_MIN_DAQ_0                         0
    #define XCP_MAX_DAQ_0                         1//(XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_0)
    #define XCP_NO_OF_ODTS_0                      20//(XCP_NO_OF_CONFIGURABLE_ODTS_0)
    #define XCP_NO_OF_ODT_ENTRIES_0               200//(XCP_NO_OF_CONFIGURABLE_ODT_ENTRIES_0)
  #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */
#endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) */

#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
    #define XCP_MIN_DAQ_1                         0
    #define XCP_MAX_DAQ_1                         0
    #define XCP_NO_OF_ODTS_1                      0
    #define XCP_NO_OF_ODT_ENTRIES_1               0
  #else /* (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_DISABLED) */
    #if (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_ENABLED)
      #define XCP_MIN_DAQ_1                       (XCP_NO_OF_PREDEFINED_DAQ_LISTS_1)
      #define XCP_MAX_DAQ_1                       ((XCP_NO_OF_PREDEFINED_DAQ_LISTS_1)   + (XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1))
      #define XCP_NO_OF_ODTS_1                    ((XCP_NO_OF_PREDEFINED_ODTS_1)        + (XCP_NO_OF_CONFIGURABLE_ODTS_1))
      #define XCP_NO_OF_ODT_ENTRIES_1             ((XCP_NO_OF_PREDEFINED_ODT_ENTRIES_1) + (XCP_NO_OF_CONFIGURABLE_ODT_ENTRIES_1))
    #else /* (XCP_PREDEFINED_DAQ_LISTS_1 == XCP_DISABLED) */
      #define XCP_MIN_DAQ_1                       0
      #define XCP_MAX_DAQ_1                       (XCP_NO_OF_CONFIGURABLE_DAQ_LISTS_1)
      #define XCP_NO_OF_ODTS_1                    (XCP_NO_OF_CONFIGURABLE_ODTS_1)
      #define XCP_NO_OF_ODT_ENTRIES_1             (XCP_NO_OF_CONFIGURABLE_ODT_ENTRIES_1)
    #endif /* #if (XCP_PREDEFINED_DAQ_LISTS_0 == XCP_ENABLED) */
  #endif /* #if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED) */
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

/* define for support of event processing */
#if (((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && ((XCP_RESUME_MODE == XCP_ENABLED) || ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)))) || \
     ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)))
  #define XCP_EVENT_PROCESSING                    XCP_ENABLED
#else
  #define XCP_EVENT_PROCESSING                    XCP_DISABLED
#endif

/* define for number of pages in all segments */
#if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED)
  #define XCP_MAX_PAGES                           2
#else /* (XCP_CAL_PAGE_SWITCHING == XCP_DISABLED) */
  #define XCP_MAX_PAGES                           1
#endif /* #if (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) */

/* protocol layer version (1.x) */
#define XCP_PROTOCOL_LAYER_VERSION                0x01

/**** symbolic definitions of command codes ***********************************/

/* standard commands */
#define XCP_CMD_CODE_CONNECT                      0xFF
#define XCP_CMD_CODE_DISCONNECT                   0xFE
#define XCP_CMD_CODE_GET_STATUS                   0xFD
#define XCP_CMD_CODE_SYNCH                        0xFC
#define XCP_CMD_CODE_GET_COMM_MODE_INFO           0xFB
#define XCP_CMD_CODE_GET_ID                       0xFA
#define XCP_CMD_CODE_SET_REQUEST                  0xF9
#define XCP_CMD_CODE_GET_SEED                     0xF8
#define XCP_CMD_CODE_UNLOCK                       0xF7
#define XCP_CMD_CODE_SET_MTA                      0xF6
#define XCP_CMD_CODE_UPLOAD                       0xF5
#define XCP_CMD_CODE_SHORT_UPLOAD                 0xF4
#define XCP_CMD_CODE_BUILD_CHECKSUM               0xF3

#define XCP_CMD_CODE_TRANSPORT_LAYER_CMD          0xF2
#define XCP_CMD_CODE_USER_CMD                     0xF1

/* calibration commands */
#define XCP_CMD_CODE_DOWNLOAD                     0xF0
#define XCP_CMD_CODE_DOWNLOAD_NEXT                0xEF
#define XCP_CMD_CODE_DOWNLOAD_MAX                 0xEE
#define XCP_CMD_CODE_SHORT_DOWNLOAD               0xED
#define XCP_CMD_CODE_MODIFY_BITS                  0xEC

/* page switching commands */
#define XCP_CMD_CODE_SET_CAL_PAGE                 0xEB
#define XCP_CMD_CODE_GET_CAL_PAGE                 0xEA
#define XCP_CMD_CODE_GET_PAG_PROCESSOR_INFO       0xE9
#define XCP_CMD_CODE_GET_SEGMENT_INFO             0xE8
#define XCP_CMD_CODE_GET_PAGE_INFO                0xE7
#define XCP_CMD_CODE_SET_SEGMENT_MODE             0xE6
#define XCP_CMD_CODE_GET_SEGMENT_MODE             0xE5
#define XCP_CMD_CODE_COPY_CAL_PAGE                0xE4

/* data acquisition and stimulation commands */
#define XCP_CMD_CODE_CLEAR_DAQ_LIST               0xE3
#define XCP_CMD_CODE_SET_DAQ_PTR                  0xE2
#define XCP_CMD_CODE_WRITE_DAQ                    0xE1
#define XCP_CMD_CODE_SET_DAQ_LIST_MODE            0xE0
#define XCP_CMD_CODE_GET_DAQ_LIST_MODE            0xDF
#define XCP_CMD_CODE_START_STOP_DAQ_LIST          0xDE
#define XCP_CMD_CODE_START_STOP_SYNCH             0xDD
#define XCP_CMD_CODE_GET_DAQ_CLOCK                0xDC
#define XCP_CMD_CODE_READ_DAQ                     0xDB
#define XCP_CMD_CODE_GET_DAQ_PROCESSOR_INFO       0xDA
#define XCP_CMD_CODE_GET_DAQ_RESOLUTION_INFO      0xD9
#define XCP_CMD_CODE_GET_DAQ_LIST_INFO            0xD8
#define XCP_CMD_CODE_GET_DAQ_EVENT_INFO           0xD7
#define XCP_CMD_CODE_FREE_DAQ                     0xD6
#define XCP_CMD_CODE_ALLOC_DAQ                    0xD5
#define XCP_CMD_CODE_ALLOC_ODT                    0xD4
#define XCP_CMD_CODE_ALLOC_ODT_ENTRY              0xD3
#define XCP_CMD_CODE_WRITE_DAQ_MULTIPLE           0xC7

/* non-volatile memory programming commands */
#define XCP_CMD_CODE_PROGRAM_START                0xD2
#define XCP_CMD_CODE_PROGRAM_CLEAR                0xD1
#define XCP_CMD_CODE_PROGRAM                      0xD0
#define XCP_CMD_CODE_PROGRAM_RESET                0xCF
#define XCP_CMD_CODE_GET_PGM_PROCESSOR_INFO       0xCE
#define XCP_CMD_CODE_GET_SECTOR_INFO              0xCD
#define XCP_CMD_CODE_PROGRAM_PREPARE              0xCC
#define XCP_CMD_CODE_PROGRAM_FORMAT               0xCB
#define XCP_CMD_CODE_PROGRAM_NEXT                 0xCA
#define XCP_CMD_CODE_PROGRAM_MAX                  0xC9
#define XCP_CMD_CODE_PROGRAM_VERIFY               0xC8

/* user commands required for bypassing */
#define XCP_CMD_CODE_GET_BYP_INFO                 0xFF
#define XCP_CMD_CODE_SET_DAQ_LIST_BYP_MODE        0xFE
#define XCP_CMD_CODE_GET_DAQ_LIST_BYP_MODE        0xFD
#define XCP_CMD_CODE_SET_FAILSAFE_DATA_PTR        0xFC
#define XCP_CMD_CODE_WRITE_FAILSAFE_DATA          0xFB


/**** symbolic definitions of error codes *************************************/

#define XCP_ERR_CMD_SYNCH                         0x00
#define XCP_ERR_CMD_BUSY                          0x10
#define XCP_ERR_DAQ_ACTIVE                        0x11
#define XCP_ERR_PGM_ACTIVE                        0x12
#define XCP_ERR_CMD_UNKNOWN                       0x20
#define XCP_ERR_CMD_SYNTAX                        0x21
#define XCP_ERR_OUT_OF_RANGE                      0x22
#define XCP_ERR_WRITE_PROTECTED                   0x23
#define XCP_ERR_ACCESS_DENIED                     0x24
#define XCP_ERR_ACCESS_LOCKED                     0x25
#define XCP_ERR_PAGE_NOT_VALID                    0x26
#define XCP_ERR_MODE_NOT_VALID                    0x27
#define XCP_ERR_SEGMENT_NOT_VALID                 0x28
#define XCP_ERR_SEQUENCE                          0x29
#define XCP_ERR_DAQ_CONFIG                        0x2A
#define XCP_ERR_MEMORY_OVERFLOW                   0x30
#define XCP_ERR_GENERIC                           0x31
#define XCP_ERR_VERIFY                            0x32
#define XCP_ERR_TEMPORARY_NOT_ACCESSIBLE          0x33


/**** symbolic definitions of event codes *************************************/

#define XCP_EV_RESUME_MODE                        0x00
#define XCP_EV_CLEAR_DAQ                          0x01
#define XCP_EV_STORE_DAQ                          0x02
#define XCP_EV_STORE_CAL                          0x03
#define XCP_EV_CMD_PENDING                        0x05
#define XCP_EV_DAQ_OVERLOAD                       0x06
#define XCP_EV_SESSION_TERMINATED                 0x07
#define XCP_EV_TIME_SYNC                          0x08
#define XCP_EV_STIM_TIMEOUT                       0x09
#define XCP_EV_SLEEP                              0x0A
#define XCP_EV_WAKE_UP                            0x0B
#define XCP_EV_USER                               0xFE
#define XCP_EV_TRANSPORT                          0xFF


/**** symbolic definitions of service request codes ***************************/

#define XCP_SERV_RESET                            0x00
#define XCP_SERV_TEXT                             0x01


/**** symbolic definitions of PID types ***************************************/

#define XCP_PID_RES                               0xFF
#define XCP_PID_ERR                               0xFE
#define XCP_PID_EV                                0xFD
#define XCP_PID_SERV                              0xFC


/**** symbolic definitions of bit mask coded parameters ***********************/

/* RESOURCE parameter in CONNECT and GET_SEED */
#define XCP_RESOURCE_CAL_PAG                      0x01
#define XCP_RESOURCE_DAQ                          0x04
#define XCP_RESOURCE_STIM                         0x08
#define XCP_RESOURCE_PGM                          0x10

/* COMM_MODE_BASIC parameter in CONNECT */
#define XCP_COMM_MODE_BASIC_BYTE_ORDER            0x01
#define XCP_COMM_MODE_BASIC_ADRR_GRANULARITY_0    0x02
#define XCP_COMM_MODE_BASIC_ADRR_GRANULARITY_1    0x04
#define XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE      0x40
#define XCP_COMM_MODE_BASIC_OPTIONAL              0x80

/* COMM_MODE_OPTIONAL parameter in GET_COMM_MODE_INFO */
#define XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE  0x01
#define XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE   0x02

/* COMM_MODE_PGM parameter in PROGRAM_START */
#define XCP_COMM_MODE_PGM_MASTER_BLOCK_MODE       0x01
#define XCP_COMM_MODE_PGM_INTERLEAVED_MODE        0x02
#define XCP_COMM_MODE_PGM_SLAVE_BLOCK_MODE        0x40

/* Current Resource Protection Status parameter in GET_STATUS and UNLOCK */
#define XCP_PROTECTION_STATUS_CAL_PAG             0x01
#define XCP_PROTECTION_STATUS_DAQ                 0x04
#define XCP_PROTECTION_STATUS_STIM                0x08
#define XCP_PROTECTION_STATUS_PGM                 0x10

/* Mode parameter in SET_REQUEST */
#define XCP_REQUEST_STORE_CAL                     0x01
#define XCP_REQUEST_STORE_DAQ_NO_RESUME           0x02
#define XCP_REQUEST_STORE_DAQ                     0x04
#define XCP_REQUEST_CLEAR_DAQ                     0x08

/* Current Session Status parameter in GET_STATUS */
#define XCP_SESSION_STATUS_DISCONNECTED                 0x00  /* internal */
#define XCP_SESSION_STATUS_STORE_CAL_REQUEST            0x01
#define XCP_SESSION_STATUS_STORE_DAQ_NO_RESUME_REQUEST  0x02
#define XCP_SESSION_STATUS_STORE_DAQ_REQUEST            0x04
#define XCP_SESSION_STATUS_CLEAR_DAQ_REQUEST            0x08
#define XCP_SESSION_STATUS_CONNECTED                    0x10  /* internal */
#define XCP_SESSION_STATUS_CONNECTED_USER               0x20  /* internal */
#define XCP_SESSION_STATUS_DAQ_RUNNING                  0x40
#define XCP_SESSION_STATUS_RESUME                       0x80

/* DAQ_KEY_BYTE parameter in GET_DAQ_PROCESSOR_INFO */
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_0           0x01
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_1           0x02
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_2           0x04
#define XCP_DAQ_KEY_OPTIMISATION_TYPE_3           0x08
#define XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT         0x10
#define XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ         0x20
#define XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0   0x40
#define XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1   0x80

/* DAQ_PROPERTIES parameter in GET_DAQ_PROCESSOR_INFO */
#define XCP_DAQ_PROPERTY_CONFIG_TYPE              0x01
#define XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED      0x02
#define XCP_DAQ_PROPERTY_RESUME_SUPPORTED         0x04
#define XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED       0x08
#define XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED      0x10
#define XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED        0x20
#define XCP_DAQ_PROPERTY_OVERLOAD_MSB             0x40
#define XCP_DAQ_PROPERTY_OVERLOAD_EVENT           0x80

/* Mode parameter in SET_DAQ_LIST_MODE / GET_DAQ_LIST_MODE */
#define XCP_DAQ_LIST_MODE_SELECTED                0x01
#define XCP_DAQ_LIST_MODE_DIRECTION               0x02
#define XCP_DAQ_LIST_MODE_CONFIGURED              0x04  /* internal */
#define XCP_DAQ_LIST_MODE_OVERLOAD                0x08  /* internal */
#define XCP_DAQ_LIST_MODE_TIMESTAMP               0x10
#define XCP_DAQ_LIST_MODE_PID_OFF                 0x20
#define XCP_DAQ_LIST_MODE_RUNNING                 0x40
#define XCP_DAQ_LIST_MODE_RESUME                  0x80

/* DAQ_LIST_PROPERTIES parameter in GET_DAQ_LIST_INFO */
#define XCP_DAQ_LIST_PROPERTY_PREDEFINED          0x01
#define XCP_DAQ_LIST_PROPERTY_EVENT_FIXED         0x02
#define XCP_DAQ_LIST_PROPERTY_DAQ                 0x04
#define XCP_DAQ_LIST_PROPERTY_STIM                0x08

/* DAQ_EVENT_PROPERTIES parameter in GET_DAQ_EVENT_INFO */
#define XCP_EVENT_PROPERTY_DAQ                    0x04
#define XCP_EVENT_PROPERTY_STIM                   0x08

/* TIMESTAMP_MODE parameter in GET_DAQ_RESOLUTION_INFO */
#define XCP_TIMESTAMP_MODE_SIZE_0                 0x01
#define XCP_TIMESTAMP_MODE_SIZE_1                 0x02
#define XCP_TIMESTAMP_MODE_SIZE_2                 0x04
#define XCP_TIMESTAMP_MODE_TIMESTAMP_FIXED        0x08
#define XCP_TIMESTAMP_MODE_UNIT_0                 0x10
#define XCP_TIMESTAMP_MODE_UNIT_1                 0x20
#define XCP_TIMESTAMP_MODE_UNIT_2                 0x40
#define XCP_TIMESTAMP_MODE_UNIT_3                 0x80

/* PAG_PROPERTIES parameter in GET_PAG_PROCESSOR_INFO */
#define XCP_PAG_PROPERTY_FREEZE_SUPPORTED         0x01

/* Mode parameter in SET_SEGMENT_MODE / GET_SEGMENT_MODE */
#define XCP_SEGMENT_MODE_FREEZE                   0x01

/* PAGE_PROPERTIES parameter in GET_PAGE_INFO */
#define XCP_PAGE_PROPERTY_ECU_ACCESS_WITHOUT_XCP        0x01
#define XCP_PAGE_PROPERTY_ECU_ACCESS_WITH_XCP           0x02
#define XCP_PAGE_PROPERTY_XCP_READ_ACCESS_WITHOUT_ECU   0x04
#define XCP_PAGE_PROPERTY_XCP_READ_ACCESS_WITH_ECU      0x08
#define XCP_PAGE_PROPERTY_XCP_WRITE_ACCESS_WITHOUT_ECU  0x10
#define XCP_PAGE_PROPERTY_XCP_WRITE_ACCESS_WITH_ECU     0x20

/* Mode parameter in SET_CAL_PAGE */
#define XCP_PAGE_MODE_ECU                         0x01
#define XCP_PAGE_MODE_XCP                         0x02
#define XCP_PAGE_MODE_ALL                         0x80

/* PGM_PROPERTIES parameter in GET_PGM_PROCESSOR_INFO */
#define XCP_PGM_PROPERTY_ABSOLUTE_MODE            0x01
#define XCP_PGM_PROPERTY_FUNCTIONAL_MODE          0x02
#define XCP_PGM_PROPERTY_COMPRESSION_SUPPORTED    0x04
#define XCP_PGM_PROPERTY_COMPRESSION_REQUIRED     0x08
#define XCP_PGM_PROPERTY_ENCRYPTION_SUPPORTED     0x10
#define XCP_PGM_PROPERTY_ENCRYPTION_REQUIRED      0x20
#define XCP_PGM_PROPERTY_NON_SEQ_PGM_SUPPORTED    0x40
#define XCP_PGM_PROPERTY_NON_SEQ_PGM_REQUIRED     0x80

/* BYP_PROPERTIES parameter in GET_BYP_INFO */
#define XCP_BYP_PROPERTY_DOUBLE_BUFFER_SUPPORTED    0x01
#define XCP_BYP_PROPERTY_FAILSAFE_BUFFER_SUPPORTED  0x02
#define XCP_BYP_PROPERTY_CONSISTENCY_WAIT_SUPPORTED 0x04
#define XCP_BYP_PROPERTY_FAILURE_CHECKING_SUPPORTED 0x08

/* Mode parameter in SET_DAQ_LIST_BYP_MODE / GET_DAQ_LIST_BYP_MODE */
#define XCP_DAQ_LIST_BYP_MODE_DOUBLE_BUFFER      0x01
#define XCP_DAQ_LIST_BYP_MODE_FAILSAFE_BUFFER    0x02
#define XCP_DAQ_LIST_BYP_MODE_CONSISTENCY_WAIT   0x04
#define XCP_DAQ_LIST_BYP_MODE_FAILURE_CHECKING   0x08


/**** symbolic definitions of fixed bit mask coded parameters *****************/

/* RESOURCE parameter */
#if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)
  #define _XCP_RESOURCE_CAL_PAG                   XCP_RESOURCE_CAL_PAG
#else
  #define _XCP_RESOURCE_CAL_PAG                   0
#endif
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
  #define _XCP_RESOURCE_DAQ                       XCP_RESOURCE_DAQ
#else
  #define _XCP_RESOURCE_DAQ                       0
#endif
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  #define _XCP_RESOURCE_STIM                      XCP_RESOURCE_STIM
#else
  #define _XCP_RESOURCE_STIM                      0
#endif
#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
  #define _XCP_RESOURCE_PGM                       XCP_RESOURCE_PGM
#else
  #define _XCP_RESOURCE_PGM                       0
#endif

#define XCP_RESOURCE_0 (_XCP_RESOURCE_CAL_PAG | \
                        _XCP_RESOURCE_DAQ     | \
                        _XCP_RESOURCE_STIM    | \
                        _XCP_RESOURCE_PGM)

#if (XCP_NO_OF_SERVICE_INSTANCES == 2)
  /* Hint: STIM is currently not supported for second service instance. */
  #define XCP_RESOURCE_1 (_XCP_RESOURCE_CAL_PAG | \
                          _XCP_RESOURCE_DAQ     | \
                          _XCP_RESOURCE_PGM)
#endif /* #if (XCP_NO_OF_SERVICE_INSTANCES == 2) */

/* COMM_MODE_BASIC parameter */
#if (XCP_BYTE_ORDER == XCP_BYTE_ORDER_MOTOROLA)
  #define _XCP_COMM_MODE_BASIC_BYTE_ORDER         XCP_COMM_MODE_BASIC_BYTE_ORDER
#else
  #define _XCP_COMM_MODE_BASIC_BYTE_ORDER         0
#endif
#define _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_0   0 /* address granularity is always BYTE */
#define _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_1   0
#if (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)
  #define _XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE   XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE
#else
  #define _XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE   0
#endif
#if (XCP_INFO_COMMANDS_STD == XCP_ENABLED)
  #define _XCP_COMM_MODE_BASIC_OPTIONAL           XCP_COMM_MODE_BASIC_OPTIONAL
#else
  #define _XCP_COMM_MODE_BASIC_OPTIONAL           0
#endif
#define XCP_COMM_MODE_BASIC  (_XCP_COMM_MODE_BASIC_BYTE_ORDER         | \
                              _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_0 | \
                              _XCP_COMM_MODE_BASIC_ADDR_GRANULARITY_1 | \
                              _XCP_COMM_MODE_BASIC_SLAVE_BLOCK_MODE   | \
                              _XCP_COMM_MODE_BASIC_OPTIONAL)

/* COMM_MODE_OPTIONAL parameter */
#if (XCP_MASTER_BLOCK_MODE == XCP_ENABLED)
  #define _XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE
#else
  #define _XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE 0
#endif
#define _XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE    0
#define XCP_COMM_MODE_OPTIONAL (_XCP_COMM_MODE_OPTIONAL_MASTER_BLOCK_MODE |\
                                _XCP_COMM_MODE_OPTIONAL_INTERLEAVED_MODE)

/* Current Resource Protection Status parameter */
#if (XCP_RESOURCE_PROTECTION_CAL_PAG == XCP_ENABLED)
  #define _XCP_RESOURCE_PROTECTION_CAL_PAG          XCP_PROTECTION_STATUS_CAL_PAG
#else
  #define _XCP_RESOURCE_PROTECTION_CAL_PAG          0
#endif
#if (XCP_RESOURCE_PROTECTION_DAQ == XCP_ENABLED)
  #define _XCP_RESOURCE_PROTECTION_DAQ              XCP_PROTECTION_STATUS_DAQ
#else
  #define _XCP_RESOURCE_PROTECTION_DAQ              0
#endif
#if (XCP_RESOURCE_PROTECTION_STIM == XCP_ENABLED)
  #define _XCP_RESOURCE_PROTECTION_STIM             XCP_PROTECTION_STATUS_STIM
#else
  #define _XCP_RESOURCE_PROTECTION_STIM             0
#endif
#if (XCP_RESOURCE_PROTECTION_PGM == XCP_ENABLED)
  #define _XCP_RESOURCE_PROTECTION_PGM              XCP_PROTECTION_STATUS_PGM
#else
  #define _XCP_RESOURCE_PROTECTION_PGM              0
#endif

#define XCP_RESOURCE_PROTECTION_DEFAULT  (_XCP_RESOURCE_PROTECTION_CAL_PAG  | \
                                          _XCP_RESOURCE_PROTECTION_DAQ      | \
                                          _XCP_RESOURCE_PROTECTION_STIM     | \
                                          _XCP_RESOURCE_PROTECTION_PGM)

/* DAQ_KEY_BYTE parameter */
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0  0 /* IDENTIFICATION_FIELD_TYPE_ABSOLUTE */
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1  0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_0          0 /* OPTIMIZATION_TYPE_DEFAULT */
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_1          0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_2          0
#define _XCP_DAQ_KEY_OPTIMISATION_TYPE_3          0
#define _XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT        0 /* ADDRESS_EXTENSION_FREE */
#define _XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ        0
#define _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE    XCP_IDENTIFICATION_FIELD_TYPE
#define XCP_DAQ_KEY_BYTE (_XCP_DAQ_KEY_OPTIMISATION_TYPE_0          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_1          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_2          |\
                          _XCP_DAQ_KEY_OPTIMISATION_TYPE_3          |\
                          _XCP_DAQ_KEY_ADDRESS_EXTENSION_ODT        |\
                          _XCP_DAQ_KEY_ADDRESS_EXTENSION_DAQ        |\
                          _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_0  |\
                          _XCP_DAQ_KEY_IDENTIFICATION_FIELD_TYPE_1)

/* DAQ_PROPERTIES parameter */
#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_CONFIG_TYPE_0         XCP_DAQ_PROPERTY_CONFIG_TYPE
#else
  #define _XCP_DAQ_PROPERTY_CONFIG_TYPE_0         0
#endif
#if (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_CONFIG_TYPE_1         XCP_DAQ_PROPERTY_CONFIG_TYPE
#else
  #define _XCP_DAQ_PROPERTY_CONFIG_TYPE_1         0
#endif
#if (XCP_PRESCALER_SUPPORTED == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED   XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED
#else
  #define _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED   0
#endif
#if (XCP_RESUME_MODE == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_RESUME_SUPPORTED      XCP_DAQ_PROPERTY_RESUME_SUPPORTED
#else
  #define _XCP_DAQ_PROPERTY_RESUME_SUPPORTED      0
#endif
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED    XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED
#else
  #define _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED    0
#endif
#if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED   XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED
#else
  #define _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED   0
#endif
#if (XCP_PID_OFF_SUPPORTED == XCP_ENABLED)
  #define _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED     XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED
#else
  #define _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED     0
#endif
#if (XCP_OVERLOAD_INDICATION == XCP_ENABLED)
  #if (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_MSB)
    #define _XCP_DAQ_PROPERTY_OVERLOAD_MSB        XCP_DAQ_PROPERTY_OVERLOAD_MSB
    #define _XCP_DAQ_PROPERTY_OVERLOAD_EVENT      0
  #else
    #define _XCP_DAQ_PROPERTY_OVERLOAD_MSB        0
    #define _XCP_DAQ_PROPERTY_OVERLOAD_EVENT      XCP_DAQ_PROPERTY_OVERLOAD_EVENT
  #endif
#else
  #define _XCP_DAQ_PROPERTY_OVERLOAD_MSB          0
  #define _XCP_DAQ_PROPERTY_OVERLOAD_EVENT        0
#endif
#define XCP_DAQ_PROPERTIES_0 (_XCP_DAQ_PROPERTY_CONFIG_TYPE_0       | \
                              _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_RESUME_SUPPORTED    | \
                              _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED  | \
                              _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED   | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_MSB        | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_EVENT)

#define XCP_DAQ_PROPERTIES_1 (_XCP_DAQ_PROPERTY_CONFIG_TYPE_1       | \
                              _XCP_DAQ_PROPERTY_PRESCALER_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_RESUME_SUPPORTED    | \
                              _XCP_DAQ_PROPERTY_BIT_STIM_SUPPORTED  | \
                              _XCP_DAQ_PROPERTY_TIMESTAMP_SUPPORTED | \
                              _XCP_DAQ_PROPERTY_PID_OFF_SUPPORTED   | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_MSB        | \
                              _XCP_DAQ_PROPERTY_OVERLOAD_EVENT)


/* DAQ list properties */
#define XCP_DAQ_LIST_PROPERTIES_PREDEFINED       (XCP_DAQ_LIST_PROPERTY_PREDEFINED  | \
                                                  XCP_DAQ_LIST_PROPERTY_DAQ         | \
                                                  XCP_DAQ_LIST_PROPERTY_STIM)

#define XCP_DAQ_LIST_PROPERTIES_CONFIGURABLE     (XCP_DAQ_LIST_PROPERTY_DAQ         | \
                                                  XCP_DAQ_LIST_PROPERTY_STIM)

/* event channel properties */
#define XCP_EVENT_CHANNEL_PROPERTIES             (XCP_EVENT_PROPERTY_DAQ  | \
                                                  XCP_EVENT_PROPERTY_STIM)

/* timestamp mode */
#define XCP_TIMESTAMP_MODE                        ((XCP_TIMESTAMP_UNIT << 4) | XCP_TIMESTAMP_SIZE)

/* timestamp type */
#if (XCP_TIMESTAMP_SIZE == XCP_SIZE_BYTE)
  #define XCP_TIMESTAMP_TYPE                      UInt8
#elif (XCP_TIMESTAMP_SIZE == XCP_SIZE_WORD)
  #define XCP_TIMESTAMP_TYPE                      UInt16
#elif (XCP_TIMESTAMP_SIZE == XCP_SIZE_DWORD)
  #define XCP_TIMESTAMP_TYPE                      UInt32
#endif

/* PAG_PROPERTIES parameter */
#if (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)
  #define _XCP_PAG_PROPERTY_FREEZE_SUPPORTED      XCP_PAG_PROPERTY_FREEZE_SUPPORTED
#else
  #define _XCP_PAG_PROPERTY_FREEZE_SUPPORTED      0
#endif
#define XCP_PAG_PROPERTIES (_XCP_PAG_PROPERTY_FREEZE_SUPPORTED)

/* PGM_PROPERTIES parameter */
#define _XCP_PGM_PROPERTY_ABSOLUTE_MODE           XCP_PGM_PROPERTY_ABSOLUTE_MODE
#define _XCP_PGM_PROPERTY_FUNCTIONAL_MODE         0
#define _XCP_PGM_PROPERTY_COMPRESSION_SUPPORTED   0
#define _XCP_PGM_PROPERTY_COMPRESSION_REQUIRED    0
#define _XCP_PGM_PROPERTY_ENCRYPTION_SUPPORTED    0
#define _XCP_PGM_PROPERTY_ENCRYPTION_REQUIRED     0
#define _XCP_PGM_PROPERTY_NON_SEQ_PGM_SUPPORTED   0
#define _XCP_PGM_PROPERTY_NON_SEQ_PGM_REQUIRED    0
#define XCP_PGM_PROPERTIES (_XCP_PGM_PROPERTY_ABSOLUTE_MODE         |\
                            _XCP_PGM_PROPERTY_FUNCTIONAL_MODE       |\
                            _XCP_PGM_PROPERTY_COMPRESSION_SUPPORTED |\
                            _XCP_PGM_PROPERTY_COMPRESSION_REQUIRED  |\
                            _XCP_PGM_PROPERTY_ENCRYPTION_SUPPORTED  |\
                            _XCP_PGM_PROPERTY_ENCRYPTION_REQUIRED   |\
                            _XCP_PGM_PROPERTY_NON_SEQ_PGM_SUPPORTED |\
                            _XCP_PGM_PROPERTY_NON_SEQ_PGM_REQUIRED)

/* COMM_MODE_PGM parameter */
#define _XCP_COMM_MODE_PGM_MASTER_BLOCK_MODE      0
#define _XCP_COMM_MODE_PGM_INTERLEAVED_MODE       0
#define _XCP_COMM_MODE_PGM_SLAVE_BLOCK_MODE       0
#define XCP_COMM_MODE_PGM  (_XCP_COMM_MODE_PGM_MASTER_BLOCK_MODE  |\
                            _XCP_COMM_MODE_PGM_INTERLEAVED_MODE   |\
                            _XCP_COMM_MODE_PGM_SLAVE_BLOCK_MODE)

/* BYP_PROPERTIES parameter */
#if (XCP_DOUBLE_BUFFER == XCP_ENABLED)
  #define _XCP_BYP_PROPERTY_DOUBLE_BUFFER_SUPPORTED     XCP_BYP_PROPERTY_DOUBLE_BUFFER_SUPPORTED
#else
  #define _XCP_BYP_PROPERTY_DOUBLE_BUFFER_SUPPORTED     0
#endif
#if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
  #define _XCP_BYP_PROPERTY_FAILSAFE_BUFFER_SUPPORTED   XCP_BYP_PROPERTY_FAILSAFE_BUFFER_SUPPORTED
#else
  #define _XCP_BYP_PROPERTY_FAILSAFE_BUFFER_SUPPORTED   0
#endif
#if (XCP_CONSISTENCY_WAIT == XCP_ENABLED)
  #define _XCP_BYP_PROPERTY_CONSISTENCY_WAIT_SUPPORTED  XCP_BYP_PROPERTY_CONSISTENCY_WAIT_SUPPORTED
#else
  #define _XCP_BYP_PROPERTY_CONSISTENCY_WAIT_SUPPORTED  0
#endif
#if (XCP_FAILURE_CHECKING == XCP_ENABLED)
  #define _XCP_BYP_PROPERTY_FAILUE_CHECKING_SUPPORTED   XCP_BYP_PROPERTY_FAILURE_CHECKING_SUPPORTED
#else
  #define _XCP_BYP_PROPERTY_FAILUE_CHECKING_SUPPORTED   0
#endif
#define XCP_BYP_PROPERTIES (_XCP_BYP_PROPERTY_DOUBLE_BUFFER_SUPPORTED    | \
                            _XCP_BYP_PROPERTY_FAILSAFE_BUFFER_SUPPORTED  | \
                            _XCP_BYP_PROPERTY_CONSISTENCY_WAIT_SUPPORTED | \
                            _XCP_BYP_PROPERTY_FAILUE_CHECKING_SUPPORTED)


/**** symbolic definitions of supported commands ******************************/

/* standard commands (mandatory) */
#define XCP_CMD_CONNECT                           XCP_ENABLED
#define XCP_CMD_DISCONNECT                        XCP_ENABLED
#define XCP_CMD_GET_STATUS                        XCP_ENABLED
#define XCP_CMD_SYNCH                             XCP_ENABLED

/* standard commands (optional) */
#if (XCP_INFO_COMMANDS_STD == XCP_ENABLED)
  #define XCP_CMD_GET_COMM_MODE_INFO              XCP_ENABLED
#else
  #define XCP_CMD_GET_COMM_MODE_INFO              XCP_DISABLED
#endif
#if (XCP_SLAVE_IDENTIFICATION == XCP_ENABLED)
  #define XCP_CMD_GET_ID                          XCP_ENABLED
#else
  #define XCP_CMD_GET_ID                          XCP_DISABLED
#endif
#if (((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) && (XCP_RESUME_MODE == XCP_ENABLED)) || ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)))
  #define XCP_CMD_SET_REQUEST                     XCP_ENABLED
#else
  #define XCP_CMD_SET_REQUEST                     XCP_DISABLED
#endif
#if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
  #define XCP_CMD_GET_SEED                        XCP_ENABLED
  #define XCP_CMD_UNLOCK                          XCP_ENABLED
#else
  #define XCP_CMD_GET_SEED                        XCP_DISABLED
  #define XCP_CMD_UNLOCK                          XCP_DISABLED
#endif
#if ((XCP_CHECKSUM_CALCULATION == XCP_ENABLED)        || \
     (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)  || \
     (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED))
  #define XCP_CMD_SET_MTA                         XCP_ENABLED
#else
  #define XCP_CMD_SET_MTA                         XCP_DISABLED
#endif
#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)  || \
     (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)      || \
    ((XCP_INFO_COMMANDS_STD == XCP_ENABLED)           && \
     (XCP_SLAVE_IDENTIFICATION == XCP_ENABLED))       || \
    ((XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)      && \
     (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED)))
  #define XCP_CMD_UPLOAD                          XCP_ENABLED
#else
  #define XCP_CMD_UPLOAD                          XCP_DISABLED
#endif
#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)  || \
     (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED))
  #define XCP_CMD_SHORT_UPLOAD                    XCP_ENABLED
#else
  #define XCP_CMD_SHORT_UPLOAD                    XCP_DISABLED
#endif
#if (XCP_CHECKSUM_CALCULATION == XCP_ENABLED)
  #define XCP_CMD_BUILD_CHECKSUM                  XCP_ENABLED
#else
  #define XCP_CMD_BUILD_CHECKSUM                  XCP_DISABLED
#endif
#if (XCP_TRANSPORT_LAYER_COMMANDS == XCP_ENABLED)
  #define XCP_CMD_TRANSPORT_LAYER_CMD             XCP_ENABLED
#else
  #define XCP_CMD_TRANSPORT_LAYER_CMD             XCP_DISABLED
#endif

/* user commands required for bypassing */
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  #define XCP_CMD_USER_CMD                        XCP_ENABLED
  #if (XCP_INFO_COMMANDS_STIM == XCP_ENABLED)
    #define XCP_CMD_GET_BYP_INFO                  XCP_ENABLED
  #else
    #define XCP_CMD_GET_BYP_INFO                  XCP_DISABLED
  #endif
  #define XCP_CMD_SET_DAQ_LIST_BYP_MODE           XCP_ENABLED
  #define XCP_CMD_GET_DAQ_LIST_BYP_MODE           XCP_ENABLED
  #if (XCP_FAILSAFE_BUFFER == XCP_ENABLED)
    #define XCP_CMD_SET_FAILSAFE_DATA_PTR         XCP_ENABLED
    #define XCP_CMD_WRITE_FAILSAFE_DATA           XCP_ENABLED
  #else
    #define XCP_CMD_SET_FAILSAFE_DATA_PTR         XCP_DISABLED
    #define XCP_CMD_WRITE_FAILSAFE_DATA           XCP_DISABLED
  #endif
#else
  #define XCP_CMD_USER_CMD                        XCP_DISABLED
  #define XCP_CMD_GET_BYP_INFO                    XCP_DISABLED
  #define XCP_CMD_SET_DAQ_LIST_BYP_MODE           XCP_DISABLED
  #define XCP_CMD_GET_DAQ_LIST_BYP_MODE           XCP_DISABLED
  #define XCP_CMD_SET_FAILSAFE_DATA_PTR           XCP_DISABLED
  #define XCP_CMD_WRITE_FAILSAFE_DATA             XCP_DISABLED
#endif

/* calibration and page switching commands */
#if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)
  #define XCP_CMD_DOWNLOAD                        XCP_ENABLED
  #if (XCP_MASTER_BLOCK_MODE == XCP_ENABLED)
    #define XCP_CMD_DOWNLOAD_NEXT                 XCP_ENABLED
  #else
    #define XCP_CMD_DOWNLOAD_NEXT                 XCP_DISABLED
  #endif
  #define XCP_CMD_DOWNLOAD_MAX                    XCP_ENABLED
  #define XCP_CMD_SHORT_DOWNLOAD                  XCP_DISABLED  /* always disabled */
  #if (XCP_BIT_MODIFICATION == XCP_ENABLED)
    #define XCP_CMD_MODIFY_BITS                   XCP_ENABLED
  #else
    #define XCP_CMD_MODIFY_BITS                   XCP_DISABLED
  #endif
  #define XCP_CMD_SET_CAL_PAGE                    XCP_ENABLED
  #define XCP_CMD_GET_CAL_PAGE                    XCP_ENABLED
  #if (XCP_INFO_COMMANDS_CAL_PAG == XCP_ENABLED)
    #define XCP_CMD_GET_PAG_PROCESSOR_INFO        XCP_ENABLED
    #define XCP_CMD_GET_SEGMENT_INFO              XCP_ENABLED
    #define XCP_CMD_GET_PAGE_INFO                 XCP_ENABLED
  #else
    #define XCP_CMD_GET_PAG_PROCESSOR_INFO        XCP_DISABLED
    #define XCP_CMD_GET_SEGMENT_INFO              XCP_DISABLED
    #define XCP_CMD_GET_PAGE_INFO                 XCP_DISABLED
  #endif
  #if (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)
    #define XCP_CMD_SET_SEGMENT_MODE              XCP_ENABLED
    #define XCP_CMD_GET_SEGMENT_MODE              XCP_ENABLED
  #else
    #define XCP_CMD_SET_SEGMENT_MODE              XCP_DISABLED
    #define XCP_CMD_GET_SEGMENT_MODE              XCP_DISABLED
  #endif
  #if (XCP_CAL_PAGE_COPYING == XCP_ENABLED)
    #define XCP_CMD_COPY_CAL_PAGE                 XCP_ENABLED
  #else
    #define XCP_CMD_COPY_CAL_PAGE                 XCP_DISABLED
  #endif
#else
  #if ((XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED) && (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED))
    #define XCP_CMD_DOWNLOAD                      XCP_ENABLED
    #if (XCP_MASTER_BLOCK_MODE == XCP_ENABLED)
      #define XCP_CMD_DOWNLOAD_NEXT               XCP_ENABLED
    #else
      #define XCP_CMD_DOWNLOAD_NEXT               XCP_DISABLED
    #endif
    #define XCP_CMD_DOWNLOAD_MAX                  XCP_ENABLED
    #define XCP_CMD_SHORT_DOWNLOAD                XCP_DISABLED  /* always disabled */
  #else
    #define XCP_CMD_DOWNLOAD                      XCP_DISABLED
    #define XCP_CMD_DOWNLOAD_NEXT                 XCP_DISABLED
    #define XCP_CMD_DOWNLOAD_MAX                  XCP_DISABLED
    #define XCP_CMD_SHORT_DOWNLOAD                XCP_DISABLED
  #endif
  #define XCP_CMD_MODIFY_BITS                     XCP_DISABLED
  #define XCP_CMD_SET_CAL_PAGE                    XCP_DISABLED
  #define XCP_CMD_GET_CAL_PAGE                    XCP_DISABLED
  #define XCP_CMD_SET_SEGMENT_MODE                XCP_DISABLED
  #define XCP_CMD_GET_SEGMENT_MODE                XCP_DISABLED
  #define XCP_CMD_COPY_CAL_PAGE                   XCP_DISABLED
#endif


/* data acquisition and stimulation commands */
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
  #define XCP_CMD_CLEAR_DAQ_LIST                  XCP_ENABLED
  #define XCP_CMD_SET_DAQ_PTR                     XCP_ENABLED
  #define XCP_CMD_WRITE_DAQ                       XCP_ENABLED
  #define XCP_CMD_SET_DAQ_LIST_MODE               XCP_ENABLED
  #define XCP_CMD_GET_DAQ_LIST_MODE               XCP_ENABLED
  #define XCP_CMD_START_STOP_DAQ_LIST             XCP_ENABLED
  #define XCP_CMD_START_STOP_SYNCH                XCP_ENABLED
  #if (XCP_TIMESTAMP_SUPPORTED == XCP_ENABLED)
    #define XCP_CMD_GET_DAQ_CLOCK                 XCP_ENABLED
  #else
    #define XCP_CMD_GET_DAQ_CLOCK                 XCP_DISABLED
  #endif
  #define XCP_CMD_READ_DAQ                        XCP_ENABLED
  #if (XCP_INFO_COMMANDS_DAQ == XCP_ENABLED)
    #define XCP_CMD_GET_DAQ_PROCESSOR_INFO        XCP_ENABLED
    #define XCP_CMD_GET_DAQ_RESOLUTION_INFO       XCP_ENABLED
    #define XCP_CMD_GET_DAQ_LIST_INFO             XCP_ENABLED
    #define XCP_CMD_GET_DAQ_EVENT_INFO            XCP_ENABLED
  #else
    #define XCP_CMD_GET_DAQ_PROCESSOR_INFO        XCP_DISABLED
    #define XCP_CMD_GET_DAQ_RESOLUTION_INFO       XCP_DISABLED
    #define XCP_CMD_GET_DAQ_LIST_INFO             XCP_DISABLED
    #define XCP_CMD_GET_DAQ_EVENT_INFO            XCP_DISABLED
  #endif
  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
    #define XCP_CMD_FREE_DAQ                      XCP_ENABLED
    #define XCP_CMD_ALLOC_DAQ                     XCP_ENABLED
    #define XCP_CMD_ALLOC_ODT                     XCP_ENABLED
    #define XCP_CMD_ALLOC_ODT_ENTRY               XCP_ENABLED
  #else
    #define XCP_CMD_FREE_DAQ                      XCP_DISABLED
    #define XCP_CMD_ALLOC_DAQ                     XCP_DISABLED
    #define XCP_CMD_ALLOC_ODT                     XCP_DISABLED
    #define XCP_CMD_ALLOC_ODT_ENTRY               XCP_DISABLED
  #endif
  #define XCP_CMD_WRITE_DAQ_MULTIPLE              XCP_ENABLED
#else
  #define XCP_CMD_CLEAR_DAQ_LIST                  XCP_DISABLED
  #define XCP_CMD_SET_DAQ_PTR                     XCP_DISABLED
  #define XCP_CMD_WRITE_DAQ                       XCP_DISABLED
  #define XCP_CMD_SET_DAQ_LIST_MODE               XCP_DISABLED
  #define XCP_CMD_GET_DAQ_LIST_MODE               XCP_DISABLED
  #define XCP_CMD_START_STOP_DAQ_LIST             XCP_DISABLED
  #define XCP_CMD_START_STOP_SYNCH                XCP_DISABLED
  #define XCP_CMD_GET_DAQ_CLOCK                   XCP_DISABLED
  #define XCP_CMD_READ_DAQ                        XCP_DISABLED
  #define XCP_CMD_GET_DAQ_PROCESSOR_INFO          XCP_DISABLED
  #define XCP_CMD_GET_DAQ_RESOLUTION_INFO         XCP_DISABLED
  #define XCP_CMD_GET_DAQ_LIST_INFO               XCP_DISABLED
  #define XCP_CMD_GET_DAQ_EVENT_INFO              XCP_DISABLED
  #define XCP_CMD_FREE_DAQ                        XCP_DISABLED
  #define XCP_CMD_ALLOC_DAQ                       XCP_DISABLED
  #define XCP_CMD_ALLOC_ODT                       XCP_DISABLED
  #define XCP_CMD_ALLOC_ODT_ENTRY                 XCP_DISABLED
  #define XCP_CMD_WRITE_DAQ_MULTIPLE              XCP_DISABLED
#endif

/* non-volatile memory programming commands */
#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
  #define XCP_CMD_PROGRAM_START                   XCP_ENABLED
  #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
    #define XCP_CMD_PROGRAM_CLEAR                 XCP_DISABLED
    #define XCP_CMD_PROGRAM                       XCP_DISABLED
  #else
    #define XCP_CMD_PROGRAM_CLEAR                 XCP_ENABLED
    #define XCP_CMD_PROGRAM                       XCP_ENABLED
  #endif
    #define XCP_CMD_PROGRAM_RESET                 XCP_ENABLED
#if (XCP_INFO_COMMANDS_PGM == XCP_ENABLED)
    #define XCP_CMD_GET_PGM_PROCESSOR_INFO        XCP_ENABLED
    #define XCP_CMD_GET_SECTOR_INFO               XCP_ENABLED
  #else
    #define XCP_CMD_GET_PGM_PROCESSOR_INFO        XCP_DISABLED
    #define XCP_CMD_GET_SECTOR_INFO               XCP_DISABLED
  #endif
  #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
    #define XCP_CMD_PROGRAM_PREPARE               XCP_ENABLED
  #else
    #define XCP_CMD_PROGRAM_PREPARE               XCP_DISABLED
  #endif
  #define XCP_CMD_PROGRAM_FORMAT                  XCP_DISABLED
  #if (XCP_FLASH_KERNEL_DOWNLOAD == XCP_ENABLED)
    #define XCP_CMD_PROGRAM_NEXT                  XCP_DISABLED
    #define XCP_CMD_PROGRAM_MAX                   XCP_DISABLED
  #else
    #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED)
      #define XCP_CMD_PROGRAM_NEXT                XCP_ENABLED
    #else
      #define XCP_CMD_PROGRAM_NEXT                XCP_DISABLED
    #endif
    #define XCP_CMD_PROGRAM_MAX                   XCP_ENABLED
  #endif
  #if (XCP_PGM_VERIFICATION == XCP_ENABLED)
    #define XCP_CMD_PROGRAM_VERIFY                XCP_ENABLED
  #else
    #define XCP_CMD_PROGRAM_VERIFY                XCP_DISABLED
  #endif
#else
  #define XCP_CMD_PROGRAM_START                   XCP_DISABLED
  #define XCP_CMD_PROGRAM_CLEAR                   XCP_DISABLED
  #define XCP_CMD_PROGRAM                         XCP_DISABLED
  #define XCP_CMD_PROGRAM_RESET                   XCP_DISABLED
  #define XCP_CMD_GET_PGM_PROCESSOR_INFO          XCP_DISABLED
  #define XCP_CMD_GET_SECTOR_INFO                 XCP_DISABLED
  #define XCP_CMD_PROGRAM_PREPARE                 XCP_DISABLED
  #define XCP_CMD_PROGRAM_FORMAT                  XCP_DISABLED
  #define XCP_CMD_PROGRAM_NEXT                    XCP_DISABLED
  #define XCP_CMD_PROGRAM_MAX                     XCP_DISABLED
  #define XCP_CMD_PROGRAM_VERIFY                  XCP_DISABLED
#endif


/**** symbolic definitions of additional command parameters *******************/

/* ID types (GET_ID) */
#define XCP_GET_ID_TYPE_ASCII                     0
#define XCP_GET_ID_TYPE_A2L_NAME                  1
#define XCP_GET_ID_TYPE_A2L_PATH                  2
#define XCP_GET_ID_TYPE_A2L_URL                   3
#define XCP_GET_ID_TYPE_A2L_UPLOAD                4

/* DAQ list start/stop modes (START_STOP_DAQ_LIST) */
#define XCP_DAQ_LIST_STOP                         0x00
#define XCP_DAQ_LIST_START                        0x01
#define XCP_DAQ_LIST_SELECT                       0x02

/* DAQ list start/stop modes (START_STOP_SYNCH) */
#define XCP_DAQ_LIST_STOP_ALL                     0x00
#define XCP_DAQ_LIST_START_SELECTED               0x01
#define XCP_DAQ_LIST_STOP_SELECTED                0x02

/* checksum types */
#define XCP_ADD_11                                0x01
#define XCP_ADD_12                                0x02
#define XCP_ADD_14                                0x03
#define XCP_ADD_22                                0x04
#define XCP_ADD_24                                0x05
#define XCP_ADD_44                                0x06
#define XCP_CRC_16                                0x07
#define XCP_CRC_16_CCITT                          0x08
#define XCP_CRC_32                                0x09
#define XCP_USER_DEFINED                          0xFF


/**** type definitions ********************************************************/

/* structure of an XCP CMD CTO packet */
typedef union
{
  UInt8 pid;
  UInt8 data[1];

  /*********************************************************************
  * command CONNECT
  * position:     type:   description:
  * 0             BYTE    command code = 0xFF
  * 1             BYTE    mode
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
  } connect;

  /*********************************************************************
  * command DISCONNECT
  * position:     type:   description:
  * 0             BYTE    command code = 0xFE
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } disconnect;

  /*********************************************************************
  * command GET_STATUS:
  * position:     type:   description:
  * 0             BYTE    command code = 0xFD
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_status;

  /*********************************************************************
  * command SYNCH
  * position:     type:   description:
  * 0             BYTE    command code = 0xFC
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } synch;

  /*********************************************************************
  * command GET_COMM_MODE_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xFB
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_comm_mode_info;

  /*********************************************************************
  * command GET_ID
  * position:     type:   description:
  * 0             BYTE    command code = 0xFA
  * 1             BYTE    requested identification type
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   type;
  } get_id;

  /*********************************************************************
  * command SET_REQUEST:
  * position:     type:   description:
  * 0             BYTE    command code = 0xF9
  * 1             BYTE    mode
  * 2,3           WORD    session configuration id
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  id;
  } set_request;

  /*********************************************************************
  * command GET_SEED
  * position:     type:   description:
  * 0             BYTE    command code = 0xF8
  * 1             BYTE    mode
  * 2             BYTE    resource
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   resource;
  } get_seed;

  /*********************************************************************
  * command UNLOCK
  * position:     type:   description:
  * 0             BYTE    command code = 0xF7
  * 1             BYTE    (remaining) length of key
  * 2..MAX_CTO-1  BYTE    key
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   length;
    UInt8   key[1];
  } unlock;

  /*********************************************************************
  * command SET_MTA
  * position:     type:   description:
  * 0             BYTE    command code = 0xF6
  * 1,2           BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   extension;
    UInt32  address;
  } set_mta;

  /*********************************************************************
  * command UPLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF5
  * 1             BYTE    number of data elements
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
  } upload;

  /*********************************************************************
  * command SHORT_UPLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF4
  * 1             BYTE    number of data elements
  * 2             BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   reserved;
    UInt8   extension;
    UInt32  address;
  } short_upload;

  /*********************************************************************
  * command BUILD_CHECKSUM
  * position:     type:   description:
  * 0             BYTE    command code = 0xF3
  * 1..3          BYTE    reserved
  * 4..7          DWORD   block size
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   reserved3;
    UInt32  block_size;
  } build_checksum;

  /*********************************************************************
  * command TRANSPORT_LAYER_CMD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF2
  * 1             BYTE    sub command code
  * 2...          BYTE    parameters
  **********************************************************************/
  struct
  {
    UInt8 pid;
    UInt8 sub_pid;
    UInt8 data[1];
  } transport_layer_cmd;

  /*********************************************************************
  * command USER_CMD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code
  * 2..           BYTE    parameters
  **********************************************************************/
  struct
  {
    UInt8 pid;
    UInt8 sub_pid;
    UInt8 data[1];
  } user_cmd;

  /*********************************************************************
  * command GET_BYP_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   sub_code;
  } get_byp_info;

  /*********************************************************************
  * command SET_DAQ_LIST_BYP_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFE
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    mode
  * 5             BYTE    DAQ list timeout cycle
  * 6             BYTE    DAQ list timeout unit
  * 7             BYTE    failure_limit
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   sub_code;
    UInt16  daq;
    UInt8   mode;
    UInt8   timeout_cycle;
    UInt8   timeout_unit;
    UInt8   failure_limit;
  } set_daq_list_byp_mode;

  /*********************************************************************
  * command GET_DAQ_LIST_BYP_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFD
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   sub_code;
    UInt16  daq;
  } get_daq_list_byp_mode;

  /*********************************************************************
  * command SET_FAILSAFE_DATA_PTR
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xFA
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRY_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   sub_code;
    UInt16  daq;
    UInt8   odt;
    UInt8   odt_entry;
  } set_failsafe_data_ptr;

  /*********************************************************************
  * command WRITE_FAILSAFE_DATA
  * position:     type:   description:
  * 0             BYTE    command code = 0xF1
  * 1             BYTE    sub command code = 0xF9
  * 2             BYTE    size
  * 3             BYTE    qword_nibble
  * 4..7          BYTE    data
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   sub_code;
    UInt8   size;
    UInt8   qword_nibble;
    UInt8   data[4];
  } write_failsafe_data;

  /*********************************************************************
  * command DOWNLOAD
  * position:     type:   description:
  * 0             BYTE    command code = 0xF0
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   data[1];
  } download;

  /*********************************************************************
  * command DOWNLOAD_NEXT
  * position:     type:   description:
  * 0             BYTE    command code = 0xEF
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   data[1];
  } download_next;

  /*********************************************************************
  * command DOWNLOAD_MAX
  * position:     type:   description:
  * 0             BYTE    command code = 0xEE
  * 2..MAX_CTO-1  BYTE    data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   data[1];
  } download_max;

  /*********************************************************************
  * command SHORT_DOWNLOAD (not usable with XCP on CAN)
  * position:     type:   description:
  * 0             BYTE    command code = 0xED
  * 1             BYTE    number of data elements
  * 2             BYTE    reserved
  * 3             BYTE    address extension
  * 4..7          DWORD   address
  * 8..MAX-CTO-1  BYTE    data elements
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   reserved;
    UInt8   extension;
    UInt32  address;
    UInt8   data[1];
  } short_download;

  /*********************************************************************
  * command MODIFY_BITS
  * position:     type:   description:
  * 0             BYTE    command code = 0xEC
  * 1             BYTE    shift value
  * 2,3           WORD    AND mask
  * 4,5           WORD    XOR mask
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   shift_value;
    UInt16  and_mask;
    UInt16  xor_mask;
  } modify_bits;

  /*********************************************************************
  * command SET_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xEB
  * 1             BYTE    mode
  * 2             BYTE    logical data segment number
  * 3             BYTE    logical data page number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   segment;
    UInt8   page;
  } set_cal_page;

  /*********************************************************************
  * command GET_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xEA
  * 1             BYTE    access mode
  * 2             BYTE    logical data segment number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   segment;
  } get_cal_page;

  /*********************************************************************
  * command GET_PAG_PROCESSOR_INFO
  * position:     type:     description:
  * 0             BYTE    command code = 0xE9
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_pag_processor_info;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xE8
  * 1             BYTE    mode
  * 2             BYTE    SEGMENT_NUMBER
  * 3             BYTE    SEGMENT_INFO
  * 4             BYTE    MAPPING_INDEX
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   segment;
    UInt8   info;
    UInt8   index;
  } get_segment_info;

  /*********************************************************************
  * command GET_PAGE_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xE7
  * 1             BYTE    reserved
  * 2             BYTE    SEGMENT_NUMBER
  * 3             BYTE    PAGE_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt8   segment;
    UInt8   page;
  } get_page_info;

  /*********************************************************************
  * command SET_SEGMENT_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE6
  * 1             BYTE    mode
  * 2             BYTE    SEGMENT_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   segment;
  } set_segment_mode;

  /*********************************************************************
  * command GET_SEGMENT_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE5
  * 1             BYTE    reserved
  * 2             BYTE    SEGMENT_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt8   segment;
  } get_segment_mode;

  /*********************************************************************
  * command COPY_CAL_PAGE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE4
  * 2             BYTE    logical data segment number source
  * 3             BYTE    logical data page number source
  * 4             BYTE    logical data segment number destination
  * 5             BYTE    logical data page number destination
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   segment_source;
    UInt8   page_source;
    UInt8   segment_destination;
    UInt8   page_destination;
  } copy_cal_page;

  /*********************************************************************
  * command CLEAR_DAQ_LIST
  * position:     type:   description:
  * 0             BYTE    command code = 0xE3
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
  } clear_daq_list;

  /*********************************************************************
  * command SET_DAQ_PTR
  * position:     type:   description:
  * 0             BYTE    command code = 0xE2
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRY_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
    UInt8   odt;
    UInt8   odt_entry;
  } set_daq_ptr;

  /*********************************************************************
  * command WRITE_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xE1
  * 1             BYTE    BIT_OFFSET
  * 2             BYTE    size of DAQ element
  * 3             BYTE    address extension of DAQ element
  * 4..7          DWORD   address of DAQ element
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   bit_offset;
    UInt8   size;
    UInt8   extension;
    UInt32  address;
  } write_daq;

  /*********************************************************************
  * command SET_DAQ_LIST_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xE0
  * 1             BYTE    mode
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4,5           WORD    event channel number
  * 6             BYTE    transmission rate prescaler
  * 7             BYTE    DAQ list priority
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  daq;
    UInt16  event_channel;
    UInt8   prescaler;
    UInt8   priority;
  } set_daq_list_mode;

  /*********************************************************************
  * GET_DAQ_LIST_MODE
  * position:     type:   description:
  * 0             BYTE    command code = 0xDF
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
  } get_daq_list_mode;

  /*********************************************************************
  * command START_STOP_DAQ_LIST
  * position:     type:   description:
  * 0             BYTE    command code = 0xDE
  * 1             BYTE    mode
  * 2             WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  daq;
  } start_stop_daq_list;

  /*********************************************************************
  * command START_STOP_SYNCH
  * position:     type:   description:
  * 0             BYTE    command code = 0xDD
  * 1             BYTE    mode
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
  } start_stop_synch;

  /*********************************************************************
  * command GET_DAQ_CLOCK
  * position:     type:   description:
  * 0             BYTE    command code = 0xDC
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_daq_clock;

  /*********************************************************************
  * command READ_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xDB
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } read_daq;

  /*********************************************************************
  * command GET_DAQ_PROCESSOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xDA
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_daq_processor_info;

  /*********************************************************************
  * command GET_DAQ_RESOLUTION_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD9
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_daq_resolution_info;

  /*********************************************************************
  * command GET_DAQ_LIST_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD8
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
  } get_daq_list_info;

  /*********************************************************************
  * command GET_DAQ_EVENT_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xD7
  * 1             BYTE    reserved
  * 2,3           WORD    event channel number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  event_channel;
  } get_daq_event_info;

  /*********************************************************************
  * command FREE_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = 0xD6
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } free_daq;

  /*********************************************************************
  * command ALLOC_DAQ
  * position:     type:   description:
  * 0             BYTE    command code = D5
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_COUNT
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq_count;
  } alloc_daq;

  /*********************************************************************
  * command ALLOC_ODT
  * position:     type:   description:
  * 0             BYTE    command code = 0xD4
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_COUNT
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
    UInt8   odt_count;
  } alloc_odt;

  /*********************************************************************
  * command ALLOC_ODT_ENTRY
  * position:     type:   description:
  * 0             BYTE    command code = 0xD3
  * 1             BYTE    reserved
  * 2,3           WORD    DAQ_LIST_NUMBER
  * 4             BYTE    ODT_NUMBER
  * 5             BYTE    ODT_ENTRIES_COUNT
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  daq;
    UInt8   odt;
    UInt8   odt_entries_count;
  } alloc_odt_entry;

  /*********************************************************************
  * command WRITE_DAQ_MULTIPLE
  * position:     type:   description:
  * 0             BYTE    command code = 0xC7
  * 1             BYTE    number of consecutive DAQ elements
  * 2             BYTE    BIT_OFFSET
  * 3             BYTE    size of 1st DAQ element
  * 4..7          DWORD   address of 1st DAQ element
  * 8             BYTE    address extension of 1st DAQ element
  * 9             BYTE    dummy for alignment of next element
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_daq_elements;
  } write_daq_multiple;

  struct
  {
    struct
    {
      UInt16  reserved;
      UInt8   bit_offset;
      UInt8   size;
      UInt32  address;
    } element[1];
  } write_daq_multiple_helper1;

  struct
  {
    UInt32  reserved1;
    struct
    {
      UInt32  reserved2;
      UInt8   extension;
      UInt8   alignment;
      UInt16  reserved3;
    } element[1];
  } write_daq_multiple_helper2;

  /*********************************************************************
  * command PROGRAM_START
  * position:     type:   description:
  * 0             BYTE    command code = 0xD2
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_start;

  /*********************************************************************
  * command PROGRAM_CLEAR
  * position:     type:   description:
  * 0             BYTE    command code = 0xD1
  * 1             BYTE    mode
  * 2,3           WORD    reserved
  * 4..7          DWORD   clear range
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  reserved;
    UInt32  range;
  } program_clear;

  /*********************************************************************
  * command PROGRAM
  * position:     type:   description:
  * 0             BYTE    command code = 0xD0
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   data[1];
  } program;

  /*********************************************************************
  * command PROGRAM_RESET
  * position:     type:   description:
  * 0             BYTE    command code = 0xCF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_reset;

  /*********************************************************************
  * command GET_PGM_PROCESSOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xCE
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } get_pgm_processor_info;

  /*********************************************************************
  * command GET_SECTOR_INFO
  * position:     type:   description:
  * 0             BYTE    command code = 0xCD
  * 1             BYTE    mode
  * 2             BYTE    SECTOR_NUMBER
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   sector;
  } get_sector_info;

  /*********************************************************************
  * command PROGRAM_PREPARE
  * position:     type:   description:
  * 0             BYTE    command code = 0xCC
  * 1             BYTE    not used
  * 2,3           WORD    codesize
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt16  codesize;
  } program_prepare;

  /*********************************************************************
  * command PROGRAM_FORMAT
  * position:     type:   description:
  * 0             BYTE    command code = 0xCB
  * 1             BYTE    compression method
  * 2             BYTE    encryption method
  * 3             BYTE    programming method
  * 4             BYTE    access method
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   compression;
    UInt8   encryption;
    UInt8   programming;
    UInt8   access;
  } program_format;

  /*********************************************************************
  * command PROGRAM_NEXT
  * position:     type:   description:
  * 0             BYTE    command code = 0xCA
  * 1             BYTE    number of data elements
  * 2..MAX_CTO-1  ELEMENT data elements (+fill word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   no_of_elements;
    UInt8   data[1];
  } program_next;

  /*********************************************************************
  * command PROGRAM_MAX
  * position:     type:   description:
  * 0             BYTE    command code = 0xC9
  * 1..MAX_CTO-1  ELEMENT data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   data[1];
  } program_max;

  /*********************************************************************
  * command PROGRAM_VERIFY
  * position:     type:   description:
  * 0             BYTE    command code = 0xC8
  * 1             BYTE    verification mode
  * 2,3           WORD    verification type
  * 4..7          DWORD   verification value
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   type;
    UInt32  value;
  } program_verify;
} xcp_cmd_cto_t;


/* structure of an XCP RES/ERR/EV/SERV CTO packet */
typedef union
{
  UInt8 pid;
  UInt8 data[1];

  /*********************************************************************
  * error message
  * negative response:
  * position:       type:   description:
  * 0               BYTE    packet ID : 0xFE
  * 1               BYTE    error code
  * 2..             BYTE    additional information
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   code;
    UInt8   info[1];
  } error;

  /*********************************************************************
  * event message
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFD
  * 1             BYTE    event code
  * 2..           BYTE    additional information
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   code;
    UInt8   info[1];
  } event;

  /*********************************************************************
  * command CONNECT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    RESOURCE
  * 2             BYTE    COMM_MODE_BASIC
  * 3             BYTE    MAX_CTO, maximum CTO size
  * 4,5           WORD    MAX_DTO, maximum DTO size
  * 6             BYTE    XCP protocol layer version number
  * 7             BYTE    XCP transport layer version number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   resource;
    UInt8   comm_mode_basic;
    UInt8   max_cto;
    UInt16  max_dto;
    UInt8   protocol_version;
    UInt8   transport_version;
  } connect;

  /*********************************************************************
  * command DISCONNECT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    command code = 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } disconnect;

  /*********************************************************************
  * command GET_STATUS:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current session status
  * 2             BYTE    current resource protection status
  * 3             BYTE    reserved
  * 4,5           WORD    session configuration id
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   session_status;
    UInt8   protection_status;
    UInt8   reserved;
    UInt16  session_id;
  } get_status;

  /*********************************************************************
  * command SYNCH
  * positive response: none
  **********************************************************************/

  /*********************************************************************
  * command GET_COMM_MODE_INFO:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    COMM_MODE_OPTIONAL
  * 3             BYTE    reserved
  * 4             BYTE    MAX_BS
  * 5             BYTE    MIN_ST
  * 6             BYTE    QUEUE_SIZE
  * 7             BYTE    XCP driver version number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   optional;
    UInt8   reserved2;
    UInt8   max_bs;
    UInt8   min_st;
    UInt8   queue_size;
    UInt8   driver_version;
  } get_comm_mode_info;

  /*********************************************************************
  * command GET_ID
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    mode
  * 2,3           WORD    reserved
  * 4,7           DWORD   length
  * 7..MAX_CTO-1  BYTE    identification
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  reserved;
    UInt32  length;
  } get_id;

  /*********************************************************************
  * command SET_REQUEST:
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_request;

  /*********************************************************************
  * command GET_SEED
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    length of seed
  * 2..MAX_CTO-1  BYTE    seed
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   length;
    UInt8   seed[1];
  } get_seed;

  /*********************************************************************
  * command UNLOCK
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current resource protection status
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   protection_status;
  } unlock;

  /*********************************************************************
  * command SET_MTA
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_mta;

  /*********************************************************************
  * command UPLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..MAX_CTO-1  BYTE    data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   data[1];
  } upload;

  /*********************************************************************
  * command SHORT_UPLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..MAX_CTO-1  BYTE    data elements (+fill byte/word for alignment)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   data[1];
  } short_upload;

  /*********************************************************************
  * command BUILD_CHECKSUM
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    checksum type
  * 2,3           WORD    reserved
  * 4..7          DWORD   checksum
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   type;
    UInt16  reserved;
    UInt32  checksum;
  } build_checksum;

  /*********************************************************************
  * command GET_BYP_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID : 0xFF
  * 1             BYTE    BYP_PROPERTIES
  * 2             BYTE    0x44 (ASCII = D)
  * 3             BYTE    0x53 (ASCII = S)
  * 4             BYTE    0x58 (ASCII = X)
  * 5             BYTE    0x43 (ASCII = C)
  * 6             BYTE    0x50 (ASCII = P)
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt8   d;
    UInt8   s;
    UInt8   x;
    UInt8   c;
    UInt8   p;
  } get_byp_info;

  /*********************************************************************
  * command SET_DAQ_LIST_BYP_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_daq_list_byp_mode;

  /*********************************************************************
  * command GET_DAQ_LIST_BYP_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    mode
  * 2             BYTE    DAQ list timeout cycle
  * 3             BYTE    DAQ list timeout unit
  * 4             BYTE    failure limit
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt8   timeout_cycle;
    UInt8   timeout_unit;
    UInt8   failure_limit;
  } get_daq_list_byp_mode;

  /*********************************************************************
  * command SET_FAILSAFE_DATA_PTR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_failsafe_data_ptr;

  /*********************************************************************
  * command WRITE_FAILSAFE_DATA
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } write_failsafe_data;

  /*********************************************************************
  * command DOWNLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } download;

  /*********************************************************************
  * command DOWNLOAD_MAX
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } download_max;

  /*********************************************************************
  * command DOWNLOAD_NEXT
  * positive response: none
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } download_next;

  /*********************************************************************
  * command SHORT_DOWNLOAD
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } short_download;

  /*********************************************************************
  * command MODIFY_BITS
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } modify_bits;

  /*********************************************************************
  * command SET_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_cal_page;

  /*********************************************************************
  * command GET_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    reserved
  * 3             BYTE    logical data page number
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   page;
  } get_cal_page;

  /*********************************************************************
  * command GET_PAG_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    MAX_SEGMENT
  * 2             BYTE    PAG_PROPERTIES
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   max_segment;
    UInt8   properties;
  } get_pag_processor_info;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 0):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   BASIC_INFO
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   reserved3;
    UInt32  basic_info;
  } get_segment_info_mode0;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 1):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    MAX_PAGES
  * 2             BYTE    ADDRESS_EXTENSION
  * 3             BYTE    MAX_MAPPING
  * 4             BYTE    compression method
  * 5             BYTE    encryption method
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   max_pages;
    UInt8   extension;
    UInt8   max_mapping;
    UInt8   compression_method;
    UInt8   encryption_method;
  } get_segment_info_mode1;

  /*********************************************************************
  * command GET_SEGMENT_INFO
  * positive response (mode 2):
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   MAPPING_INFO
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   reserved3;
    UInt32  mapping_info;
  } get_segment_info_mode2;

  /*********************************************************************
  * command GET_PAGE_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    PAGE_PROPERTIES
  * 2             BYTE    INIT_SEGMENT
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt8   init_segment;
  } get_page_info;

  /*********************************************************************
  * command SET_SEGMENT_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_segment_mode;

  /*********************************************************************
  * command GET_SEGMENT_MODE
  * positive response:
  * position:   type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    mode
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt8   mode;
  } get_segment_mode;

  /*********************************************************************
  * command COPY_CAL_PAGE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } copy_cal_page;

  /*********************************************************************
  * command CLEAR_DAQ_LIST
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } clear_daq_list;

  /*********************************************************************
  * command SET_DAQ_PTR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_daq_ptr;

  /*********************************************************************
  * command WRITE_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } write_daq;

  /*********************************************************************
  * command SET_DAQ_LIST_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } set_daq_list_mode;

  /*********************************************************************
  * GET_DAQ_LIST_MODE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    current mode
  * 2,3           WORD    reserved
  * 4,5           WORD    current event channel number
  * 6             BYTE    current prescaler
  * 7             BYTE    current DAQ list priority
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   mode;
    UInt16  reserved;
    UInt16  event_channel;
    UInt8   prescaler;
    UInt8   priority;
  } get_daq_list_mode;

  /*********************************************************************
  * command START_STOP_DAQ_LIST
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    FIRST_PID
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   first_pid;
  } start_stop_daq_list;

  /*********************************************************************
  * command START_STOP_SYNCH
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } start_stop_synch;

  /*********************************************************************
  * command GET_DAQ_CLOCK
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1..3          BYTE    reserved
  * 4..7          DWORD   receive timestamp
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved1;
    UInt8   reserved2;
    UInt8   reserved3;
    UInt32  timestamp;
  } get_daq_clock;

  /*********************************************************************
  * command READ_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    BIT_OFFSET
  * 2             BYTE    size of DAQ element
  * 3             BYTE    address extension of DAQ element
  * 4..7          DWORD   address of DAQ element
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   bit_offset;
    UInt8   size;
    UInt8   extension;
    UInt32  address;
  } read_daq;

  /*********************************************************************
  * command GET_DAQ_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_PROPERTIES
  * 2,3           WORD    MAX_DAQ
  * 4,5           WORD    MAX_EVENT_CHANNEL
  * 6             BYTE    MIN_DAQ
  * 7             BYTE    DAQ_KEY_BYTE
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt16  max_daq;
    UInt16  max_event_channel;
    UInt8   min_daq;
    UInt8   key_byte;
  } get_daq_processor_info;

  /*********************************************************************
  * command GET_DAQ_RESOLUTION_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    GRANULARITY_ODT_ENTRY_SIZE_DAQ
  * 2             BYTE    MAX_ODT_ENTRY_SIZE_DAQ
  * 3             BYTE    GRANULARITY_ODT_ENTRY_SIZE_STIM
  * 4             BYTE    MAX_ODT_ENTRY_SIZE_STIM
  * 5             BYTE    TIMESTAMP_MODE
  * 6,7           WORD    TIMESTAMP_TICKS
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   granularity_daq;
    UInt8   max_daq;
    UInt8   granularity_stim;
    UInt8   max_stim;
    UInt8   timestamp_mode;
    UInt16  timestamp_ticks;
  } get_daq_resolution_info;

  /*********************************************************************
  * command GET_DAQ_LIST_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_LIST_PROPERTIES
  * 2             BYTE    MAX_ODT
  * 3             BYTE    MAX_ODT_ENTRIES
  * 4,5           WORD    FIXED_EVENT
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt8   max_odt;
    UInt8   max_odt_entries;
    UInt16  fixed_event;
  } get_daq_list_info;

  /*********************************************************************
  * command GET_DAQ_EVENT_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    DAQ_EVENT_PROPERTIES
  * 2             BYTE    MAX_DAQ_LIST
  * 3             BYTE    event channel name length
  * 4             BYTE    event channel time cycle
  * 5             BYTE    event channel time unit
  * 6             BYTE    event channel priority
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt8   max_daq_list;
    UInt8   name_length;
    UInt8   time_cycle;
    UInt8   time_unit;
    UInt8   priority;
  } get_daq_event_info;

  /*********************************************************************
  * command FREE_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } free_daq;

  /*********************************************************************
  * command ALLOC_DAQ
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } alloc_daq;

  /*********************************************************************
  * command ALLOC_ODT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } alloc_odt;

  /*********************************************************************
  * command ALLOC_ODT_ENTRY
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } alloc_odt_entry;

  /*********************************************************************
  * command WRITE_DAQ_MULTIPLE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } write_daq_multiple;

  /*********************************************************************
  * command PROGRAM_START
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    reserved
  * 2             BYTE    COMM_MODE_PGM
  * 3             BYTE    MAX_CTO_PGM
  * 4             BYTE    MAX_BS_PGM
  * 5             BYTE    MIN_ST_PGM
  * 6             BYTE    QUEUE_SIZE_PGM
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   reserved;
    UInt8   comm_mode_pgm;
    UInt8   max_cto_pgm;
    UInt8   max_bs_pgm;
    UInt8   min_st_pgm;
    UInt8   queue_size_pgm;
  } program_start;

  /*********************************************************************
  * command PROGRAM_CLEAR
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_clear;

  /*********************************************************************
  * command PROGRAM
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program;

  /*********************************************************************
  * command PROGRAM_RESET
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_reset;

  /*********************************************************************
  * command GET_PGM_PROCESSOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    PGM_PROPERTIES
  * 2             BYTE    MAX_SECTOR
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   properties;
    UInt8   max_sector;
  } get_pgm_processor_info;

  /*********************************************************************
  * command GET_SECTOR_INFO
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  * 1             BYTE    clear sequence number
  * 2             BYTE    program sequence number
  * 3             BYTE    programming method
  * 4..7          DWORD   SECTOR_INFO
  **********************************************************************/
  struct
  {
    UInt8   pid;
    UInt8   clear_number;
    UInt8   program_number;
    UInt8   method;
    UInt32  info;
  } get_sector_info;

  /*********************************************************************
  * command PROGRAM_PREPARE
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_prepare;

  /*********************************************************************
  * command PROGRAM_FORMAT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_format;

  /*********************************************************************
  * command PROGRAM_NEXT
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_next;

  /*********************************************************************
  * command PROGRAM_MAX
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_max;

  /*********************************************************************
  * command PROGRAM_VERIFY
  * positive response:
  * position:     type:   description:
  * 0             BYTE    packet ID: 0xFF
  **********************************************************************/
  struct
  {
    UInt8   pid;
  } program_verify;
} xcp_res_cto_t;


/* structure of an XCP DAQ DTO packet */
typedef union
{
  UInt8 pid;
  UInt8 data[1];
} xcp_daq_dto_t;


/* structure of an XCP STIM DTO packet */
typedef union
{
  UInt8 pid;
  UInt8 data[1];
} xcp_stim_dto_t;


/* structure of the memory transfer address (used for memory protection) */
typedef struct
{
  UInt32 address;                     /* memory address */
  UInt8  extension;                   /* memory address extension */
} xcp_mta_info_t;


/* structure of a memory page */
typedef struct
{
  UInt8 properties;                   /* properties (write access etc.) */
  UInt8 init_segment;                 /* init segment, which initializes this page */
} xcp_page_info_t;


/* structure of a memory segment */
typedef struct
{
  UInt32 address;                     /* address of segment */
  UInt32 length;                      /* segment length */
  UInt8  extension;                   /* address extension */
  UInt8  max_pages;                   /* number of pages */
  UInt8  max_mapping;                 /* number of address ranges with address mapping */
  UInt8  compression_method;          /* compression method */
  UInt8  encryption_method;           /* encryption method */
} xcp_segment_info_t;


/* structure of an ODT entry */
typedef struct
{
#if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED))
  UInt32 address;                     /* address of ECU variable */
#else
  xcp_mta_ptr_t address_ptr;          /* pointer to address of ECU variable */
#endif /* #if ((XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) && (XCP_CAL_PAGE_SWITCHING == XCP_ENABLED) && (XCP_CAL_PAGE_DAQ_STIM == XCP_ENABLED)) */
  UInt8 extension;                    /* address extension */
  UInt8 size;                         /* size of ECU variable */
  UInt8 bit_offset;                   /* bit offset */
  UInt8 reserved;                     /* for alignment */
} xcp_entry_t;


/* structure of an ODT (only required for dynamic DAQ lists) */
typedef struct
{
  UInt16 first_odt_entry;             /* first ODT entry of ODT in entry array (absolute) */
  UInt8 no_of_odt_entries;            /* number of entries in ODT */
  UInt8 status;                       /* status of ODT (not used) */
} xcp_odt_t;


/* structure of configuration data of a DAQ list */
typedef struct
{
  UInt8  no_of_odts;                  /* number of ODTs */
  UInt8  no_of_odt_entries;           /* number of entries in each odt */
  UInt8  properties;                  /* properties (read only, STIM/DAQ etc.) */
} xcp_daq_list_config_t;


/* structure of a DAQ list */
typedef struct
{
  UInt16 first_odt;                   /* first ODT of DAQ list (absolute), equals to first PID */
  UInt16 first_odt_entry;             /* first ODT entry of DAQ list (absolute) */
  UInt8  no_of_odts;                  /* number of ODTs */
  UInt8  no_of_odt_entries;           /* number of ODT entries in each ODT */
  UInt8  properties;                  /* properties (read only, STIM/DAQ etc.) */
  UInt8  no_of_configured_odts;       /* number of configured ODTs */
  UInt16 event_channel;               /* assigned event channel */
  UInt16 next_daq;                    /* next DAQ list in same event channel */
  UInt8  prescaler;                   /* transmission rate prescaler */
  UInt8  cycle;                       /* current cycle */
  UInt8  mode;                        /* mode (resume, direction, stopped, started etc.) */
  UInt8  priority;                    /* priority of DAQ list */
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  UInt8  byp_mode;                    /* bypassing mode of DAQ list */
  UInt8  consistent_flag;             /* flag if DAQ list is consistent */
  UInt8  once_consistent_flag;        /* flag, if DAQ list has been consistent once */
  UInt8  double_buffer_active;        /* number of active buffer */
  UInt32 timeout_ticks;               /* ticks of timeout */
  UInt8  timeout_cycle;               /* cycle of timeout */
  UInt8  timeout_unit;                /* unit of timeout */
  UInt8  failure_limit;               /* limit of failures until failsafe buffer is active */
  UInt8  failure_count;               /* current number of failures */
#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
#if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED)
  UInt16 next_odt;
  UInt16 last_odt;
#endif /* #if (XCP_PL_DAQ_DTO_BUFFER == XCP_ENABLED) */
} xcp_daq_list_t;


/* structure of the DAQ pointer */
typedef struct
{
  UInt16 daq;                         /* DAQ list index */
  UInt16 abs_odt;                     /* ODT index (absolute) */
  UInt16 abs_odt_entry;               /* ODT entry index (absolute) */
#if (XCP_ERROR_CHECK == XCP_ENABLED)
  UInt8  rel_odt;                     /* ODT index (relative) */
  UInt8  rel_odt_entry;               /* ODT entry index (relative) */
#endif /* #if (XCP_ERROR_CHECK == XCP_ENABLED) */
  UInt8  valid_flag;                  /* flag, if reference to DAQ list is valid */
} xcp_daq_ptr_t;


/* structure of information data of an event channel */
typedef struct
{
  UInt8 max_daq;                      /* maximum number of DAQ lists in event channel */
  UInt8 properties;                   /* properties */
  UInt8 time_cycle;                   /* time cycle */
  UInt8 time_unit;                    /* time unit */
  UInt8 priority;                     /* priority */
  UInt8 name_length;                  /* length of event channel name */
  char  *name;                        /* pointer to name of event channel */
} xcp_event_channel_info_t;


/* structure of an event channel */
typedef struct
{
  UInt16 first_daq;                   /* first assigned DAQ list */
  UInt8  status;                      /* status */
} xcp_event_channel_t;


/* structure of information data of a sector */
typedef struct
{
  UInt32 address;                     /* address of sector */
  UInt32 length;                      /* length of sector */
  UInt8  clear_sequence_number;       /* clear sequence number */
  UInt8  program_sequence_number;     /* program sequence number */
  UInt8  programming_method;          /* programming method */
} xcp_sector_info_t;


/* XCP service structure */
typedef struct
{
  xcp_mta_ptr_t       mta_ptr;                              /* memory transfer address pointer */
#if (XCP_MEMORY_PROTECTION == XCP_ENABLED)
  xcp_mta_info_t      mta_info;                             /* MTA adress info (for memory protection) */
#endif /* #if (XCP_MEMORY_PROTECTION == XCP_ENABLED) */
  UInt8               session_status;                       /* session status */
  UInt8               pending_status;                       /* pending status */
  UInt8               event_code;                           /* code of EV packet */
#if (XCP_RESOURCE_PROTECTION == XCP_ENABLED)
  UInt8               protection_status;                    /* protection status */
  UInt8               resource_to_unlock;                   /* resource, which is requested to be unlocked */
  UInt8               seed_flag;                            /* flag, if whole seed has been received */
  UInt8               seed[XCP_MAX_SEED_SIZE];              /* current seed */
  UInt8               key[XCP_MAX_KEY_SIZE];                /* current key */
  UInt8               seed_key_index;                       /* index in current seed or key */
  UInt8               no_of_seed_key_bytes_remaining;       /* number of remaining bytes for seeds and keys larger than 1 XCP packet */
#endif /* #if (XCP_RESOURCE_PROTECTION == XCP_ENABLED) */
#if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED))
  UInt8               no_of_sbm_bytes_remaining;            /* number of remaining bytes in a block upload */
#endif /* #if ((XCP_CMD_UPLOAD == XCP_ENABLED) && (XCP_SLAVE_BLOCK_MODE == XCP_ENABLED)) */
#if ((XCP_CMD_GET_ID == XCP_ENABLED) || (XCP_CMD_GET_DAQ_EVENT_INFO == XCP_ENABLED))
  UInt32              no_of_upload_info_bytes_remaining; /* number of remaining bytes for uploading XCP service information */
#endif
#if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED)
  #if (XCP_MASTER_BLOCK_MODE == XCP_ENABLED)
  UInt8               no_of_mbm_bytes_remaining;            /* number of remaining bytes in a block download */
  #endif /* #if (XCP_MASTER_BLOCK_MODE == XCP_ENABLED) */
  #if (XCP_CAL_PAGE_FREEZING == XCP_ENABLED)
  UInt8               segment_mode[XCP_MAX_SEGMENT];        /* modes of memory segments */
  #endif /* #if (XCP_CAL_PAGE_FREEZING == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_CAL_PAG == XCP_ENABLED) */
#if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
  UInt16              max_daq;                              /* number of predefined and configurable static DAQ lists or allocated dynamic DAQ lists */
  #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED)))
  UInt16              odt_count;                            /* number of allocated ODTs */
  UInt16              odt_entries_count;                    /* number of allocated ODT entries */
  xcp_odt_t           *odt;                                 /* pointer to first ODT (absolute) */
  #endif /* #if ((XCP_DAQ_CONFIG_TYPE_DYNAMIC_0 == XCP_ENABLED) || ((XCP_NO_OF_SERVICE_INSTANCES == 2) && (XCP_DAQ_CONFIG_TYPE_DYNAMIC_1 == XCP_ENABLED))) */
  xcp_daq_ptr_t       daq_ptr;                              /* DAQ pointer */
  xcp_daq_list_t      *daq_list;                            /* pointer to first DAQ list (absolute) */
  xcp_entry_t         *odt_entry;                           /* pointer to first ODT entry (absolute) */
  xcp_event_channel_t event_channel[XCP_MAX_EVENT_CHANNEL]; /* status of event channels */
  #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT))
  UInt8               overload_count;                       /* number of DAQ overloads */
  #endif  /* #if ((XCP_OVERLOAD_INDICATION == XCP_ENABLED) && (XCP_OVERLOAD_INDICATION_TYPE == XCP_OVERLOAD_INDICATION_TYPE_EVENT)) */
  #if (XCP_RESUME_MODE == XCP_ENABLED)
  UInt16              session_id;                           /* session configuration id */
  #endif /* #if (XCP_RESUME_MODE == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED) */
#if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED)
  xcp_daq_ptr_t       daq_byp_ptr;                          /* DAQ pointer for failsafe mechanism */
#endif /* #if (XCP_RESOURCE_SUPPORTED_STIM == XCP_ENABLED) */
#if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED)
  UInt8               pgm_status;                           /* status of non-volatile memory programming */
  #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED)
  UInt8               no_of_mbm_pgm_bytes_remaining;        /* number of remaining bytes in a block PGM */
  #endif /* #if (XCP_MASTER_BLOCK_MODE_PGM == XCP_ENABLED) */
#endif /* #if (XCP_RESOURCE_SUPPORTED_PGM == XCP_ENABLED) */
} xcp_struct_t;

/*******************************************************************************
  function prototypes
*******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*
 * If the dSPACE service shall be compiled, the service layer API functions
 * are declared, else dummy macros.
 */
#ifndef DSXCP_SERVICE_DISABLED

extern void         DSXCP_init(void);
extern void         DSXCP_background(void);
  #if (XCP_RESOURCE_SUPPORTED_DAQ == XCP_ENABLED)
extern unsigned int DSXCP_service(unsigned int event_channel);
  #else
#define DSXCP_service(event_channel)  DSXCP_DAQ_INACTIVE
  #endif

#else
#define DSXCP_init()
#define DSXCP_background()
#define DSXCP_service(event_channel)  DSXCP_DAQ_INACTIVE

#endif /* #ifndef DSXCP_SERVICE_DISABLED */

/* declaration of functions called by the transport layer(s) */
extern void xcp_cmd_proc(unsigned int service_no, UInt8 *cmd_cto);
extern void xcp_stim_proc(unsigned int service_no, UInt8 *stim_dto, UInt8 pid_off_info, UInt16 daq);

#ifdef __cplusplus
}
#endif

#endif /* __XCP_PROT_H__ */
