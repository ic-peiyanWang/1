#include "fct_me_param.h"

MES_VAR double ME_LeftLine_Role_mp;
MES_VAR double ME_LeftLine_C0_mp;
MES_VAR double ME_LeftLine_C1_mp;
MES_VAR double ME_LeftLine_C2_mp;
MES_VAR double ME_LeftLine_C3_mp;
MES_VAR double ME_LeftLine_start_mp;
MES_VAR double ME_LeftLine_end_mp;
MES_VAR double ME_LeftLine_conf_mp;
MES_VAR double ME_RightLine_Role_mp;
MES_VAR double ME_RightLine_C0_mp;
MES_VAR double ME_RightLine_C1_mp;
MES_VAR double ME_RightLine_C2_mp;
MES_VAR double ME_RightLine_C3_mp;
MES_VAR double ME_RightLine_start_mp;
MES_VAR double ME_RightLine_end_mp;
MES_VAR double ME_RightLine_conf_mp;
MES_VAR double ME_LaneWidth_mp;