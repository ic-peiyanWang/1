#include "fct_timestamps_param.h"

MES_VAR uint32_t FCT_TimestampsLow_mp;
MES_VAR uint32_t FCT_TimestampsHigh_mp;
