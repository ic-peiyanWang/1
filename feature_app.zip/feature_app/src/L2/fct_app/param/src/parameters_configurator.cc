#include <algorithm>
#include <cmath>
#include "parameters_configurator.h"
#include "fct_conf.pb.h"
#include "ids_mil.h"
#include "LongCtrl.h"

namespace nio {
namespace ad {
namespace fctapp {

ParametersConfigurator fct_conf_data;

void ParametersConfigurator::LoadModeConf_(const std::string& conf_file) {
  auto conf_path = niodds::GetConfigPath();
  conf_path      = conf_path + "/" + conf_file;
  WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_path;
  if (!GetProtoFromFile(conf_path, &mode_conf_)) {
    if (LoadConfSts_e::UPDATED == mode_conf_load_sts_) {
      mode_conf_load_sts_ = LoadConfSts_e::LOADED;
    }
    WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_file << " failed";
  } else {
    mode_conf_load_sts_ = LoadConfSts_e::UPDATED;
  }
}

void ParametersConfigurator::LoadModeConf_() {
  if (is_feature_conf_data_loaded()) {
    if (feature_conf_data_.has_load_mode_conf_data()) {
      mode_conf_          = feature_conf_data_.load_mode_conf_data();
      mode_conf_load_sts_ = feature_conf_data_load_sts_;
    }
  }
}

void ParametersConfigurator::LoadFeatureConf_(const std::string& conf_file) {
  auto conf_path = niodds::GetConfigPath();
  conf_path      = conf_path + "/" + conf_file;
  WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_path;
  if (!GetProtoFromFile(conf_path, &feature_conf_)) {
    if (LoadConfSts_e::UPDATED == feature_conf_load_sts_) {
      feature_conf_load_sts_ = LoadConfSts_e::LOADED;
    }
    WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_file << " failed";
  } else {
    feature_conf_load_sts_ = LoadConfSts_e::UPDATED;
  }
}

void ParametersConfigurator::LoadFeatureConf_() {
  if (is_feature_conf_data_loaded()) {
    if (feature_conf_data_.has_feature_conf_data()) {
      feature_conf_          = feature_conf_data_.feature_conf_data();
      feature_conf_load_sts_ = feature_conf_data_load_sts_;
    }
  }
}

void ParametersConfigurator::LoadFeatureConfData_(const std::string& conf_file) {
  auto conf_path = niodds::GetConfigPath();
  conf_path      = conf_path + "/" + conf_file;
  WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_path;
  if (!GetProtoFromFile(conf_path, &feature_conf_data_)) {
    if (LoadConfSts_e::UPDATED == feature_conf_data_load_sts_) {
      feature_conf_data_load_sts_ = LoadConfSts_e::LOADED;
    }
    WARN_LOG_FIRST_N(2) << "Open conf file: " << conf_file << " failed";
  } else {
    feature_conf_data_load_sts_ = LoadConfSts_e::UPDATED;
  }
}

void ParametersConfigurator::SetVehicleType(const int veh_type) {
  vehicle_type = static_cast<VehProjectTyp_e>(veh_type);
}

bool ParametersConfigurator::UpdateConf() {

  if (mode_conf_.has_conf_load_mode()) {
    mode_conf_load_sts_ = feature_conf_data_load_sts_;
    WARN_LOG_FIRST_N(2) << "load mode: " << (uint16_t)mode_conf_.conf_load_mode();
    load_mode_ = static_cast<ConfLoadMode_e>(mode_conf_.conf_load_mode());
  }

  if (ConfLoadMode_e::ON_INIT != load_mode_) {
    if (is_feature_conf_loaded()) {
      if (feature_conf_.has_is_alc_enable()) {
        WARN_LOG_FIRST_N(2) << "alc enable: " << (uint16_t)feature_conf_.is_alc_enable();
      }
      if (feature_conf_.has_alc_enable_set_speed_min()) {
        WARN_LOG_FIRST_N(2) << "alc enable speed: " << feature_conf_.alc_enable_set_speed_min();
        LatCtrl_vLCAActvMinVehSpd_C = feature_conf_.alc_enable_set_speed_min();
      }
      if (feature_conf_.has_alc_to_manual_time_max()) {
        WARN_LOG_FIRST_N(2) << "alc to manual time: " << feature_conf_.alc_to_manual_time_max();
        LatCtrl_secAlcMaxT2Manu_C = feature_conf_.alc_to_manual_time_max();
      }
      if (feature_conf_.has_auto_resume_time_max()) {
        WARN_LOG_FIRST_N(2) << "auto resume time: " << feature_conf_.auto_resume_time_max();
      }
      if (feature_conf_.has_da_set_speed_max()) {
        WARN_LOG_FIRST_N(2) << "da set speed max: " << feature_conf_.da_set_speed_max();
        ACCSC_kphMaxSetSpd_C      = feature_conf_.da_set_speed_max();
        ACCSC_kphMaxSetSpdPilot_C = feature_conf_.da_set_speed_max();
      }
      if (feature_conf_.has_is_elk_enable()) {
        WARN_LOG_FIRST_N(2) << "is elk enable: " << (uint16_t)feature_conf_.is_elk_enable();
        LatCtrl_flgElkEnByParam_C = feature_conf_.is_elk_enable();
      }
      if (feature_conf_.has_alc_bflcatakeoversprsmask()) {
        WARN_LOG_FIRST_N(2) << "alc take over sprs mask: " << feature_conf_.alc_bflcatakeoversprsmask();
        LatCtrl_bfLCATakeOverSprsMask_C = feature_conf_.alc_bflcatakeoversprsmask();
      }
      if (feature_conf_.has_alc_bflcprpractvsprsmask()) {
        WARN_LOG_FIRST_N(2) << "alc prpr actv sprs mask: " << feature_conf_.alc_bflcprpractvsprsmask();
        Mtn_Plan_bfLCPrprActvSprsMask_C = feature_conf_.alc_bflcprpractvsprsmask();
      }
      if (feature_conf_.has_alc_flguseeuodd()) {
        WARN_LOG_FIRST_N(2) << "alc flg use eu odd: " << feature_conf_.alc_flguseeuodd();
        LatCtrl_flgUseEUODD_C = feature_conf_.alc_flguseeuodd();
      }
      if (feature_conf_.has_flgenouthighwaysprs()) {
        WARN_LOG_FIRST_N(2) << "LatCtrl_flgenoutHighwaySprs_C: " << feature_conf_.flgenouthighwaysprs();
        LatCtrl_flgenoutHighwaySprs_C = feature_conf_.flgenouthighwaysprs();
      }
      if (feature_conf_.has_tilcawaitdelt()) {
        WARN_LOG_FIRST_N(2) << "LatCtrl_tiLCAWaitDelT_C: " << feature_conf_.tilcawaitdelt();
        LatCtrl_tiLCAWaitDelT_C = feature_conf_.tilcawaitdelt();
      }
      if (feature_conf_.has_bflcaoddsprsmask()) {
        WARN_LOG_FIRST_N(2) << "LatCtrl_bfLCAODDSprsMask_C: " << feature_conf_.bflcaoddsprsmask();
        LatCtrl_bfLCAODDSprsMask_C = feature_conf_.bflcaoddsprsmask();
      }
      if (feature_conf_.has_perlksovlyimdt()) {
        LatCtrl_perLksOvlyImdt_C = feature_conf_.perlksovlyimdt();
      }
      // if (feature_conf_.has_stnormsteeringstrength()) {
      //   LatCtrl_stNormSteeringStrength_C = feature_conf_.stnormsteeringstrength();
      // }
      // if (feature_conf_.has_sthardsteeringstrength()) {
      //   LatCtrl_stHardSteeringStrength_C = feature_conf_.sthardsteeringstrength();
      // }
      // if (feature_conf_.has_stsoftsteeringstrength()) {
      //   LatCtrl_stSoftSteeringStrength_C = feature_conf_.stsoftsteeringstrength();
      // }
      if (feature_conf_.has_tqepsreqtypetqthron()) {
        LatCtrl_tqEPSReqTypeTqThrOn_C = feature_conf_.tqepsreqtypetqthron();
      }
      if (feature_conf_.has_tqepsreqtypetqthroff()) {
        LatCtrl_tqEPSReqTypeTqThrOff_C = feature_conf_.tqepsreqtypetqthroff();
      }
      if (feature_conf_.has_tiepsacitsusupchgtstep()) {
        LatCtrl_tiEPSACITsuSupChgTStep_C = feature_conf_.tiepsacitsusupchgtstep();
      }

      // if (feature_conf_.has_elk_tsu_set()) {
      //   WARN_LOG_FIRST_N(2) << "elk tsu set: " << (uint16_t)feature_conf_.elk_tsu_set();
      //   if (feature_conf_.elk_tsu_set() <= 0x07) {
      //     LatCtrl_Elk_stEPSACITsuSet_C = (uint8_t)feature_conf_.elk_tsu_set();
      //   } else {
      //     LatCtrl_Elk_stEPSACITsuSet_C = 0x07;
      //   }
      // }
      //
      if (feature_conf_.has_veh_param_conf()) {
        WARN_LOG_FIRST_N(2) << "veh type for choose params: " << (int32_t)vehicle_type;
        // Force
        if (VehProjectTyp_e::VehProjectTyp_FORCE == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_force()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_force().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_force().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_force().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_force().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_force().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_force().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_force().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_force().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_force().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_force().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_force().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_force().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_force().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_force().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_force().charac_speed();
            }
          }
        }
        // Gemini
        if (VehProjectTyp_e::VehProjectTyp_GEMINI == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_gemini()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_gemini().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_gemini().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_gemini().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_gemini().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_gemini().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_gemini().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_gemini().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_gemini().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_gemini().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_gemini().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_gemini().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_gemini().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_gemini().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_gemini().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_gemini().charac_speed();
            }
          }
        }
        // Pegasus
        if (VehProjectTyp_e::VehProjectTyp_PEGASUS == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_pegasus()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_pegasus().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_pegasus().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_pegasus().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_pegasus().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: "
                                  << feature_conf_.veh_param_conf().veh_param_pegasus().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_pegasus().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_pegasus().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_pegasus().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_pegasus().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_pegasus().charac_speed();
            }
            // forward feedback gain
            if (feature_conf_.veh_param_conf().veh_param_pegasus().has_forward_feedback_gain()) {
              WARN_LOG_FIRST_N(2) << "forward feedback gain: "
                                  << feature_conf_.veh_param_conf().veh_param_pegasus().forward_feedback_gain();
              LatCtrl_Lks_forwardFeedbackGain_C = feature_conf_.veh_param_conf().veh_param_pegasus().forward_feedback_gain();
            }
          }
        }
        // Aries
        if (VehProjectTyp_e::VehProjectTyp_ARIES == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_aries()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_aries().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_aries().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_aries().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_aries().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_aries().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_aries().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_aries().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_aries().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_aries().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_aries().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_aries().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_aries().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_aries().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_aries().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_aries().charac_speed();
            }
          }
        }
        // Sirius
        if (VehProjectTyp_e::VehProjectTyp_SIRIUS == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_sirius()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_sirius().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_sirius().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_sirius().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_sirius().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_sirius().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_sirius().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_sirius().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_sirius().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_sirius().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_sirius().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_sirius().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_sirius().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_sirius().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_sirius().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_sirius().charac_speed();
            }
          }
        }
        // Libra
        if (VehProjectTyp_e::VehProjectTyp_LIBRA == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_libra()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_libra().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_libra().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_libra().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_libra().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_libra().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_libra().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_libra().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_libra().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_libra().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_libra().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_libra().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_libra().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_libra().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_libra().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_libra().charac_speed();
            }
          }
        }
        // Orion
        if (VehProjectTyp_e::VehProjectTyp_ORION == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_orion()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_orion().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_orion().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_orion().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_orion().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_orion().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_orion().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_orion().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_orion().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_orion().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_orion().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_orion().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_orion().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_orion().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_orion().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_orion().charac_speed();
            }
          }
        }
        // Lyra
        if (VehProjectTyp_e::VehProjectTyp_LYRA == vehicle_type) {
          if (feature_conf_.veh_param_conf().has_veh_param_lyra()) {
            // wheelbase
            if (feature_conf_.veh_param_conf().veh_param_lyra().has_wheelbase()) {
              WARN_LOG_FIRST_N(2) << "vehicle wheelbase: "
                                  << feature_conf_.veh_param_conf().veh_param_lyra().wheelbase();
              IDS_lVehWhlBase_C = feature_conf_.veh_param_conf().veh_param_lyra().wheelbase();
            }
            // length
            if (feature_conf_.veh_param_conf().veh_param_lyra().has_length()) {
              WARN_LOG_FIRST_N(2) << "vehicle length: " << feature_conf_.veh_param_conf().veh_param_lyra().length();
              SIN_lVehOveralLngth_C = feature_conf_.veh_param_conf().veh_param_lyra().length();
            }
            // steer ratio
            if (feature_conf_.veh_param_conf().veh_param_lyra().has_steer_ratio()) {
              WARN_LOG_FIRST_N(2) << "steer ratio: " << feature_conf_.veh_param_conf().veh_param_lyra().steer_ratio();
              IDS_facSteerRatio_C = feature_conf_.veh_param_conf().veh_param_lyra().steer_ratio();
            }
            // width
            if (feature_conf_.veh_param_conf().veh_param_lyra().has_width_wo_mirror()) {
              WARN_LOG_FIRST_N(2) << "vehicle width: "
                                  << feature_conf_.veh_param_conf().veh_param_lyra().width_wo_mirror();
              IDS_lVehWdth_C = feature_conf_.veh_param_conf().veh_param_lyra().width_wo_mirror();
            }
            // charactor speed
            if (feature_conf_.veh_param_conf().veh_param_lyra().has_charac_speed()) {
              WARN_LOG_FIRST_N(2) << "charactor speed: "
                                  << feature_conf_.veh_param_conf().veh_param_lyra().charac_speed();
              LatCtrl_Lks_vVehCharactorSpd_C = feature_conf_.veh_param_conf().veh_param_lyra().charac_speed();
            }
          }
        }
      }

      if (feature_conf_.has_is_load_calb_cipv_max_range()) {
        WARN_LOG_FIRST_N(2) << "is load calb cipv max range: " << feature_conf_.is_load_calb_cipv_max_range();
        ACCSC_flgUseCalbCIPVmaxRng_C = feature_conf_.is_load_calb_cipv_max_range();
      }
      if (feature_conf_.has_cipv_max_range()) {
        if (feature_conf_.cipv_max_range().cipv_max_range_table_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "cipv max range table size: "
                              << (uint16_t)feature_conf_.cipv_max_range().cipv_max_range_table_size();
          for (const auto table_ : feature_conf_.cipv_max_range().cipv_max_range_table()) {
            if (table_.has_mps_veh_spd() && table_.has_max_range()) {
              x[size_] = table_.mps_veh_spd();
              y[size_] = table_.max_range();
              WARN_LOG << "cipv max range table [" << static_cast<uint32_t>(size_)
                       << "] = " << static_cast<double_t>(x[size_]) << "   " << static_cast<double_t>(y[size_]);
              size_++;
            }
          }
          if (size_ > 0) {
            acc_m_cipv_max_range_table_.init(x, y, size_);
          }
        }
      }

      if (feature_conf_.has_is_load_calb_no_brk_rng_lmt()) {
        WARN_LOG_FIRST_N(2) << "is load calb no brake range: " << feature_conf_.is_load_calb_no_brk_rng_lmt();
        ACCSC_flgUseCalbNoBrkRngLmt_C = feature_conf_.is_load_calb_no_brk_rng_lmt();
      }
      if (feature_conf_.has_no_brake_range()) {
        if (feature_conf_.no_brake_range().no_brake_range_table_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "no brake range table size: "
                              << (uint16_t)feature_conf_.no_brake_range().no_brake_range_table_size();
          for (const auto table_ : feature_conf_.no_brake_range().no_brake_range_table()) {
            if (table_.has_mps_veh_spd() && table_.has_no_brk_range()) {
              x[size_] = table_.mps_veh_spd();
              y[size_] = table_.no_brk_range();
              WARN_LOG << "no brake range table [" << static_cast<uint32_t>(size_)
                       << "] = " << static_cast<double_t>(x[size_]) << "   " << static_cast<double_t>(y[size_]);
              size_++;
            }
          }
          if (size_ > 0) {
            acc_m_no_bake_range_table_.init(x, y, size_);
          }
        }
      }

      if (feature_conf_.has_is_load_cur_lmt_spd_table()) {
        WARN_LOG_FIRST_N(2) << "is load cur lmt spd table: " << feature_conf_.is_load_cur_lmt_spd_table();
        ACCSC_flgUseCalCurLmtSpdTable_C = feature_conf_.is_load_cur_lmt_spd_table();
      }
      if (feature_conf_.has_cur_spd_lmt()) {
        if (feature_conf_.cur_spd_lmt().cur_spd_lmt_table_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "cur lmt spd table size: "
                              << (uint16_t)feature_conf_.cur_spd_lmt().cur_spd_lmt_table_size();
          for (const auto table_ : feature_conf_.cur_spd_lmt().cur_spd_lmt_table()) {
            if (table_.has_lne_avl_c2() && table_.has_cur_spd_lmt_target()) {
              x[size_] = table_.lne_avl_c2();
              y[size_] = table_.cur_spd_lmt_target();
              WARN_LOG << "cur spd lmt table[: " << static_cast<uint32_t>(size_)
                       << "] = " << static_cast<double_t>(x[size_]) << "   " << static_cast<double_t>(y[size_]);
              size_++;
            }
          }
          if (size_ > 0) {
            acc_kph_cur_lmt_spd_table_.init(x, y, size_);
          }
        }
      }
      if (feature_conf_.has_lka_gain()) {
        if (feature_conf_.lka_gain().has_is_lka_conf_enable()) {
          WARN_LOG_FIRST_N(2) << "is lka conf enable: " << (uint16_t)feature_conf_.lka_gain().is_lka_conf_enable();
          LatCtrl_Lka_flgLoadLkaConfEnbl_C = feature_conf_.lka_gain().is_lka_conf_enable();
        }
        if (feature_conf_.lka_gain().has_low_sensitivity()) {

          if (feature_conf_.lka_gain().low_sensitivity().has_predictive_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().low_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "low sensitivity predictive c1 angle inner shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .low_sensitivity()
                                       .predictive_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_low_predictive_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().low_sensitivity().has_predictive_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().low_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "low sensitivity predictive c1 angle outer shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .low_sensitivity()
                                       .predictive_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_low_predictive_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().low_sensitivity().has_actual_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().low_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "low sensitivity actual c1 inner angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .low_sensitivity()
                                       .actual_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_low_actual_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().low_sensitivity().has_actual_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().low_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "low sensitivity actual c1 outer angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .low_sensitivity()
                                       .actual_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_low_actual_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().low_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.lka_gain().low_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "low sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .low_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_low_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().low_sensitivity().has_zone_border_min()) {
            if (feature_conf_.lka_gain().low_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "low sensitivity min zone border size: "
                << (uint16_t)feature_conf_.lka_gain().low_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().low_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_low_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }

        if (feature_conf_.lka_gain().has_normal_sensitivity()) {

          if (feature_conf_.lka_gain().normal_sensitivity().has_predictive_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().normal_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "normal sensitivity predictive c1 angle inner shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .normal_sensitivity()
                                       .predictive_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_normal_predictive_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().normal_sensitivity().has_predictive_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().normal_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "normal sensitivity predictive c1 angle outer shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .normal_sensitivity()
                                       .predictive_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_normal_predictive_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().normal_sensitivity().has_actual_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().normal_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "normal sensitivity actual c1 inner angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .normal_sensitivity()
                                       .actual_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_normal_actual_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().normal_sensitivity().has_actual_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().normal_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "normal sensitivity actual c1 outer angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .normal_sensitivity()
                                       .actual_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_normal_actual_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().normal_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.lka_gain().normal_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "normal sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .normal_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_normal_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().normal_sensitivity().has_zone_border_min()) {
            if (feature_conf_.lka_gain().normal_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "normal sensitivity min zone border size: "
                << (uint16_t)feature_conf_.lka_gain().normal_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().normal_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_normal_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }

        if (feature_conf_.lka_gain().has_high_sensitivity()) {

          if (feature_conf_.lka_gain().high_sensitivity().has_predictive_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().high_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "high sensitivity predictive c1 angle inner shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .high_sensitivity()
                                       .predictive_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().predictive_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_high_predictive_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().high_sensitivity().has_predictive_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().high_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "high sensitivity predictive c1 angle outer shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .high_sensitivity()
                                       .predictive_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().predictive_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_high_predictive_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().high_sensitivity().has_actual_c1_inner_offset_gain()) {
            if (feature_conf_.lka_gain().high_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "high sensitivity actual c1 inner angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .high_sensitivity()
                                       .actual_c1_inner_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().actual_c1_inner_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_high_actual_c1_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().high_sensitivity().has_actual_c1_outer_offset_gain()) {
            if (feature_conf_.lka_gain().high_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "high sensitivity actual c1 outer angle shift gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .high_sensitivity()
                                       .actual_c1_outer_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().actual_c1_outer_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                lka_high_actual_c1_outer_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().high_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.lka_gain().high_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "high sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.lka_gain()
                                       .high_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_high_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.lka_gain().high_sensitivity().has_zone_border_min()) {
            if (feature_conf_.lka_gain().high_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "high sensitivity min zone border size: "
                << (uint16_t)feature_conf_.lka_gain().high_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.lka_gain().high_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                lka_high_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }
      }

      if (feature_conf_.has_ldw_gain()) {
        if (feature_conf_.ldw_gain().has_is_ldw_conf_enable()) {
          WARN_LOG_FIRST_N(2) << "is ldw conf enable: " << (uint16_t)feature_conf_.ldw_gain().is_ldw_conf_enable();
          Ldw_flgLoadLdwConfEnbl_C = feature_conf_.ldw_gain().is_ldw_conf_enable();
        }
        if (feature_conf_.ldw_gain().has_low_sensitivity()) {

          if (feature_conf_.ldw_gain().low_sensitivity().has_actual_c1_offset_gain()) {
            if (feature_conf_.ldw_gain().low_sensitivity().actual_c1_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "ldw low sensitivity actual c1 offset gain size: "
                << (uint16_t)feature_conf_.ldw_gain().low_sensitivity().actual_c1_offset_gain().angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().low_sensitivity().actual_c1_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                ldw_low_actual_c1_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().low_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.ldw_gain().low_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "ldw low sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.ldw_gain()
                                       .low_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().low_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_low_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().low_sensitivity().has_zone_border_min()) {
            if (feature_conf_.ldw_gain().low_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "ldw low sensitivity min zone border size: "
                << (uint16_t)feature_conf_.ldw_gain().low_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().low_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_low_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }

        if (feature_conf_.ldw_gain().has_normal_sensitivity()) {

          if (feature_conf_.ldw_gain().normal_sensitivity().has_actual_c1_offset_gain()) {
            if (feature_conf_.ldw_gain().normal_sensitivity().actual_c1_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "ldw normal sensitivity predictive c1 angle shift gain size: "
                                  << (uint16_t)feature_conf_.ldw_gain()
                                       .normal_sensitivity()
                                       .actual_c1_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().normal_sensitivity().actual_c1_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                ldw_normal_actual_c1_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().normal_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.ldw_gain().normal_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "ldw normal sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.ldw_gain()
                                       .normal_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().normal_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_normal_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().normal_sensitivity().has_zone_border_min()) {
            if (feature_conf_.ldw_gain().normal_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "ldw normal sensitivity min zone border size: "
                << (uint16_t)feature_conf_.ldw_gain().normal_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().normal_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_normal_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }

        if (feature_conf_.ldw_gain().has_high_sensitivity()) {

          if (feature_conf_.ldw_gain().high_sensitivity().has_actual_c1_offset_gain()) {
            if (feature_conf_.ldw_gain().high_sensitivity().actual_c1_offset_gain().angle_shift_gain_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "ldw high sensitivity predictive c1 angle shift gain size: "
                                  << (uint16_t)feature_conf_.ldw_gain()
                                       .high_sensitivity()
                                       .actual_c1_offset_gain()
                                       .angle_shift_gain_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().high_sensitivity().actual_c1_offset_gain().angle_shift_gain()) {
                if (table_.has_angle() && table_.has_gain()) {
                  size_++;
                  x[size_] = table_.angle();
                  y[size_] = table_.gain();
                }
              }
              if (size_ > 0) {
                ldw_high_actual_c1_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().high_sensitivity().has_lnwidth_c0_inner_offset_gain()) {
            if (feature_conf_.ldw_gain().high_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset_size()
                > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2) << "ldw high sensitivity lane width c0 inner offset gain size: "
                                  << (uint16_t)feature_conf_.ldw_gain()
                                       .high_sensitivity()
                                       .lnwidth_c0_inner_offset_gain()
                                       .lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().high_sensitivity().lnwidth_c0_inner_offset_gain().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_high_lnwidth_c0_inner_offset_table_.init(x, y, size_);
              }
            }
          }

          if (feature_conf_.ldw_gain().high_sensitivity().has_zone_border_min()) {
            if (feature_conf_.ldw_gain().high_sensitivity().zone_border_min().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "ldw high sensitivity min zone border size: "
                << (uint16_t)feature_conf_.ldw_gain().high_sensitivity().zone_border_min().lane_width_offset_size();
              for (const auto table_ :
                   feature_conf_.ldw_gain().high_sensitivity().zone_border_min().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                ldw_high_zone_border_min_table_.init(x, y, size_);
              }
            }
          }
        }
      }

      if (feature_conf_.has_is_elk_conf_enable()) {
        WARN_LOG_FIRST_N(2) << "is elk conf enable: " << (uint16_t)feature_conf_.is_elk_conf_enable();
        LatCtrl_Elk_flgLoadElkConfEnbl_C = feature_conf_.is_elk_conf_enable();
        if (LatCtrl_Elk_flgLoadElkConfEnbl_C) {
          if (feature_conf_.has_predictive_c1_inner_offset_gain()) {
            WARN_LOG_FIRST_N(2) << "predictive c1 inner offset gain: "
                                << feature_conf_.predictive_c1_inner_offset_gain();
            LatCtrl_Elk_facZoneBrdPrdvLtrlVelInnrShftGain_C = feature_conf_.predictive_c1_inner_offset_gain();
          }

          if (feature_conf_.has_predictive_c1_outer_offset_gain()) {
            WARN_LOG_FIRST_N(2) << "predictive c1 outer offset gain: "
                                << feature_conf_.predictive_c1_outer_offset_gain();
            LatCtrl_Elk_facZoneBrdPrdvLtrlVelOutrShftGain_C = feature_conf_.predictive_c1_outer_offset_gain();
          }

          if (feature_conf_.has_actual_c1_inner_offset_gain()) {
            WARN_LOG_FIRST_N(2) << "actual c1 inner offset gain: " << feature_conf_.actual_c1_inner_offset_gain();
            LatCtrl_Elk_facZoneBrdActLtrlVelInnrShftGain_C = feature_conf_.actual_c1_inner_offset_gain();
          }

          if (feature_conf_.has_actual_c1_outer_offset_gain()) {
            WARN_LOG_FIRST_N(2) << "actual c1 outer offset gain: " << feature_conf_.actual_c1_outer_offset_gain();
            LatCtrl_Elk_facZoneBrdActLtrlVelOutrShftGain_C = feature_conf_.actual_c1_outer_offset_gain();
          }

          if (feature_conf_.has_solid_line_conf()) {
            if (feature_conf_.solid_line_conf().has_inner_lane_width_offset()) {

              if (feature_conf_.solid_line_conf().inner_lane_width_offset().lane_width_offset_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2)
                  << "solid line inner lane width offset size: "
                  << (uint16_t)feature_conf_.solid_line_conf().inner_lane_width_offset().lane_width_offset_size();
                for (const auto table_ :
                     feature_conf_.solid_line_conf().inner_lane_width_offset().lane_width_offset()) {
                  if (table_.has_lane_width() && table_.has_offset()) {
                    size_++;
                    x[size_] = table_.lane_width();
                    y[size_] = table_.offset();
                  }
                }
                if (size_ > 0) {
                  solid_line_lane_width_offset_table_.init(x, y, size_);
                }
              }
            }
          }
        }

        if (feature_conf_.has_road_edge_conf()) {
          if (feature_conf_.road_edge_conf().has_inner_lane_width_offset()) {

            if (feature_conf_.road_edge_conf().inner_lane_width_offset().lane_width_offset_size() > 0) {
              float       x[100], y[100];
              std::size_t size_ = 0;
              WARN_LOG_FIRST_N(2)
                << "road edge inner lane width offset size: "
                << (uint16_t)feature_conf_.road_edge_conf().inner_lane_width_offset().lane_width_offset_size();
              for (const auto table_ : feature_conf_.road_edge_conf().inner_lane_width_offset().lane_width_offset()) {
                if (table_.has_lane_width() && table_.has_offset()) {
                  size_++;
                  x[size_] = table_.lane_width();
                  y[size_] = table_.offset();
                }
              }
              if (size_ > 0) {
                road_edge_lane_width_offset_table_.init(x, y, size_);
              }
            }
          }
        }
      }

      if (feature_conf_.has_oncoming_conf()) {
        if (feature_conf_.oncoming_conf().has_inner_lane_width_offset()) {

          if (feature_conf_.oncoming_conf().inner_lane_width_offset().lane_width_offset_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "oncoming inner lane width offset size: "
              << (uint16_t)feature_conf_.oncoming_conf().inner_lane_width_offset().lane_width_offset_size();
            for (const auto table_ : feature_conf_.oncoming_conf().inner_lane_width_offset().lane_width_offset()) {
              if (table_.has_lane_width() && table_.has_offset()) {
                size_++;
                x[size_] = table_.lane_width();
                y[size_] = table_.offset();
              }
            }
            if (size_ > 0) {
              oncoming_lane_width_offset_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.oncoming_conf().has_enable_ttc()) {
          if (feature_conf_.oncoming_conf().enable_ttc().ttc_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2) << "oncoming enable ttc size: "
                                << (uint16_t)feature_conf_.oncoming_conf().enable_ttc().ttc_size();
            for (const auto table_ : feature_conf_.oncoming_conf().enable_ttc().ttc()) {
              if (table_.has_speed() && table_.has_ttc()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.ttc();
              }
            }
            if (size_ > 0) {
              oncoming_enable_ttc_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.oncoming_conf().has_enable_predictive_lateral_range()) {
          if (feature_conf_.oncoming_conf().enable_predictive_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "oncoming enable predictive lateral range size: "
              << (uint16_t)feature_conf_.oncoming_conf().enable_predictive_lateral_range().range_size();
            for (const auto table_ : feature_conf_.oncoming_conf().enable_predictive_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              oncoming_enable_predictive_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.oncoming_conf().has_disable_predictive_lateral_range()) {
          if (feature_conf_.oncoming_conf().disable_predictive_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "oncoming disable predictive lateral range size: "
              << (uint16_t)feature_conf_.oncoming_conf().disable_predictive_lateral_range().range_size();
            for (const auto table_ : feature_conf_.oncoming_conf().disable_predictive_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              oncoming_disable_predictive_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.oncoming_conf().has_enable_current_lateral_range()) {
          if (feature_conf_.oncoming_conf().enable_current_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2) << "oncoming enable current lateral range size: "
                                << (uint16_t)feature_conf_.oncoming_conf().enable_current_lateral_range().range_size();
            for (const auto table_ : feature_conf_.oncoming_conf().enable_current_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              oncoming_enable_current_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.oncoming_conf().has_disable_current_lateral_range()) {
          if (feature_conf_.oncoming_conf().disable_current_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2) << "oncoming disable current lateral range size: "
                                << (uint16_t)feature_conf_.oncoming_conf().disable_current_lateral_range().range_size();
            for (const auto table_ : feature_conf_.oncoming_conf().disable_current_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              oncoming_disable_current_lateral_range_table_.init(x, y, size_);
            }
          }
        }
      }

      if (feature_conf_.has_overtaking_conf()) {
        if (feature_conf_.overtaking_conf().has_inner_lane_width_offset()) {

          if (feature_conf_.overtaking_conf().inner_lane_width_offset().lane_width_offset_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "overtaking inner lane width offset size: "
              << (uint16_t)feature_conf_.overtaking_conf().inner_lane_width_offset().lane_width_offset_size();
            for (const auto table_ : feature_conf_.overtaking_conf().inner_lane_width_offset().lane_width_offset()) {
              if (table_.has_lane_width() && table_.has_offset()) {
                size_++;
                x[size_] = table_.lane_width();
                y[size_] = table_.offset();
              }
            }
            if (size_ > 0) {
              overtaking_lane_width_offset_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.overtaking_conf().has_enable_ttc()) {
          if (feature_conf_.overtaking_conf().enable_ttc().ttc_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2) << "overtaking enable ttc size: "
                                << (uint16_t)feature_conf_.overtaking_conf().enable_ttc().ttc_size();
            for (const auto table_ : feature_conf_.overtaking_conf().enable_ttc().ttc()) {
              if (table_.has_speed() && table_.has_ttc()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.ttc();
              }
            }
            if (size_ > 0) {
              overtaking_enable_ttc_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.overtaking_conf().has_enable_predictive_lateral_range()) {
          if (feature_conf_.overtaking_conf().enable_predictive_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "overtaking enable predictive lateral range size: "
              << (uint16_t)feature_conf_.overtaking_conf().enable_predictive_lateral_range().range_size();
            for (const auto table_ : feature_conf_.overtaking_conf().enable_predictive_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              overtaking_enable_predictive_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.overtaking_conf().has_disable_predictive_lateral_range()) {
          if (feature_conf_.overtaking_conf().disable_predictive_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "overtaking disable predictive lateral range size: "
              << (uint16_t)feature_conf_.overtaking_conf().disable_predictive_lateral_range().range_size();
            for (const auto table_ : feature_conf_.overtaking_conf().disable_predictive_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              overtaking_disable_predictive_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.overtaking_conf().has_enable_current_lateral_range()) {
          if (feature_conf_.overtaking_conf().enable_current_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "overtaking enable current lateral range size: "
              << (uint16_t)feature_conf_.overtaking_conf().enable_current_lateral_range().range_size();
            for (const auto table_ : feature_conf_.overtaking_conf().enable_current_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              overtaking_enable_current_lateral_range_table_.init(x, y, size_);
            }
          }
        }
        if (feature_conf_.overtaking_conf().has_disable_current_lateral_range()) {
          if (feature_conf_.overtaking_conf().disable_current_lateral_range().range_size() > 0) {
            float       x[100], y[100];
            std::size_t size_ = 0;
            WARN_LOG_FIRST_N(2)
              << "overtaking disable current lateral range size: "
              << (uint16_t)feature_conf_.overtaking_conf().disable_current_lateral_range().range_size();
            for (const auto table_ : feature_conf_.overtaking_conf().disable_current_lateral_range().range()) {
              if (table_.has_speed() && table_.has_range()) {
                size_++;
                x[size_] = table_.speed();
                y[size_] = table_.range();
              }
            }
            if (size_ > 0) {
              overtaking_disable_current_lateral_range_table_.init(x, y, size_);
            }
          }
        }
      }

      if (feature_conf_.has_ego_lateral_accl()) {
        if (feature_conf_.ego_lateral_accl().lateral_accl_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "ego lateral accl size: "
                              << (uint16_t)feature_conf_.ego_lateral_accl().lateral_accl_size();
          for (const auto table_ : feature_conf_.ego_lateral_accl().lateral_accl()) {
            if (table_.has_speed() && table_.has_accl()) {
              size_++;
              x[size_] = table_.speed();
              y[size_] = table_.accl();
            }
          }
          if (size_ > 0) {
            ego_lateral_accl_table_.init(x, y, size_);
          }
        }
      }
      if (feature_conf_.has_elk_c0_angle_gain()) {
        if (feature_conf_.elk_c0_angle_gain().angle_gain_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "elk c0 angle gain size: "
                              << (uint16_t)feature_conf_.elk_c0_angle_gain().angle_gain_size();
          for (const auto table_ : feature_conf_.elk_c0_angle_gain().angle_gain()) {
            if (table_.has_speed() && table_.has_gain()) {
              size_++;
              x[size_] = table_.speed();
              y[size_] = table_.gain();
            }
          }
          if (size_ > 0) {
            elk_c0_angle_gain_table_.init(x, y, size_);
          }
        }
      }
      if (feature_conf_.has_elk_c1_angle_gain()) {
        if (feature_conf_.elk_c1_angle_gain().angle_gain_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "elk c1 angle gain size: "
                              << (uint16_t)feature_conf_.elk_c1_angle_gain().angle_gain_size();
          for (const auto table_ : feature_conf_.elk_c1_angle_gain().angle_gain()) {
            if (table_.has_speed() && table_.has_gain()) {
              size_++;
              x[size_] = table_.speed();
              y[size_] = table_.gain();
            }
          }
          if (size_ > 0) {
            elk_c1_angle_gain_table_.init(x, y, size_);
          }
        }
      }
      if (feature_conf_.has_elk_c2_inner_angle_gain()) {
        if (feature_conf_.elk_c2_inner_angle_gain().angle_gain_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "elk c2 inner angle gain size: "
                              << (uint16_t)feature_conf_.elk_c2_inner_angle_gain().angle_gain_size();
          for (const auto table_ : feature_conf_.elk_c2_inner_angle_gain().angle_gain()) {
            if (table_.has_speed() && table_.has_gain()) {
              size_++;
              x[size_] = table_.speed();
              y[size_] = table_.gain();
            }
          }
          if (size_ > 0) {
            elk_c2_inner_angle_gain_table_.init(x, y, size_);
          }
        }
      }
      if (feature_conf_.has_elk_c2_outer_angle_gain()) {
        if (feature_conf_.elk_c2_outer_angle_gain().angle_gain_size() > 0) {
          float       x[100], y[100];
          std::size_t size_ = 0;
          WARN_LOG_FIRST_N(2) << "elk c2 outer angle gain size: "
                              << (uint16_t)feature_conf_.elk_c2_outer_angle_gain().angle_gain_size();
          for (const auto table_ : feature_conf_.elk_c2_outer_angle_gain().angle_gain()) {
            if (table_.has_speed() && table_.has_gain()) {
              size_++;
              x[size_] = table_.speed();
              y[size_] = table_.gain();
            }
          }
          if (size_ > 0) {
            elk_c2_outer_angle_gain_table_.init(x, y, size_);
          }
        }
      }

      if (feature_conf_.has_is_lat_acc_k_gain_conf_enable()) {
        WARN_LOG_FIRST_N(2) << "is latAcc k gain factor conf enable: "
                            << (uint16_t)feature_conf_.is_lat_acc_k_gain_conf_enable();
        LatCtrl_Lks_flgLoadLatAccGainFacConfEnbl_C = feature_conf_.is_lat_acc_k_gain_conf_enable();
        if (feature_conf_.has_lat_acc_k_gain_conf()) {
          WARN_LOG_FIRST_N(2) << "et7 veh type for choose lat acc k gain factor: " << (int32_t)vehicle_type;
          // Force
          if (VehProjectTyp_e::VehProjectTyp_FORCE == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_force()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_force().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_force()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_force().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Gemini
          if (VehProjectTyp_e::VehProjectTyp_GEMINI == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_gemini()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_gemini().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_gemini()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_gemini().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Pegasus
          if (VehProjectTyp_e::VehProjectTyp_PEGASUS == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_pegasus()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_pegasus().lat_acc_k_gain_factor_size()
                  > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_pegasus()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_pegasus().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Aries
          if (VehProjectTyp_e::VehProjectTyp_ARIES == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_aries()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_aries().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_aries()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_aries().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Sirius
          if (VehProjectTyp_e::VehProjectTyp_SIRIUS == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_sirius()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_sirius().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_sirius()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_sirius().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Libra
          if (VehProjectTyp_e::VehProjectTyp_LIBRA == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_libra()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_libra().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_libra()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_libra().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Orion
          if (VehProjectTyp_e::VehProjectTyp_ORION == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_orion()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_orion().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_orion()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_orion().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
          // Lyra
          if (VehProjectTyp_e::VehProjectTyp_LYRA == vehicle_type) {
            if (feature_conf_.lat_acc_k_gain_conf().has_lat_acc_k_gain_factor_lyra()) {
              if (feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_lyra().lat_acc_k_gain_factor_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lateral acc k gain factor range size: "
                                    << (uint16_t)feature_conf_.lat_acc_k_gain_conf()
                                         .lat_acc_k_gain_factor_lyra()
                                         .lat_acc_k_gain_factor_size();
                for (const auto table_ :
                     feature_conf_.lat_acc_k_gain_conf().lat_acc_k_gain_factor_lyra().lat_acc_k_gain_factor()) {
                  if (table_.has_speed() && table_.has_factor()) {
                    x[size_] = table_.speed();
                    y[size_] = table_.factor();
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_acc_k_gain_factor_table_.init(x, y, size_);
                }
              }
            }
          }
        }
      }
      if (feature_conf_.has_is_lat_eps_steer_ratio_conf_enable()) {
        WARN_LOG_FIRST_N(2) << "is lat eps steer ratio enable: "
                            << (uint16_t)feature_conf_.is_lat_eps_steer_ratio_conf_enable();
        LatCtrl_flgLoadEpsGearRatioConfEnbl_C = feature_conf_.is_lat_eps_steer_ratio_conf_enable();
        if (feature_conf_.has_lat_eps_steer_ratio_conf()) {
          WARN_LOG_FIRST_N(2) << "veh type for choose eps steer ratio: " << (int32_t)vehicle_type;
          // Force
          if (VehProjectTyp_e::VehProjectTyp_FORCE == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_force()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_force().lat_eps_steer_ratio_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_force()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_force().lat_eps_steer_ratio()) {
                  if (table_.has_pinion_ag() && table_.has_gear_ratio()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Gemini
          if (VehProjectTyp_e::VehProjectTyp_GEMINI == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_gemini()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_gemini().lat_eps_steer_ratio_size()
                  > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_gemini()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_gemini().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Pegasus
          if (VehProjectTyp_e::VehProjectTyp_PEGASUS == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_pegasus()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_pegasus().lat_eps_steer_ratio_size()
                  > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_pegasus()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_pegasus().lat_eps_steer_ratio()) {
                  if (table_.has_pinion_ag() && table_.has_gear_ratio()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Aries
          if (VehProjectTyp_e::VehProjectTyp_ARIES == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_aries()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_aries().lat_eps_steer_ratio_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_aries()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_aries().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Sirius
          if (VehProjectTyp_e::VehProjectTyp_SIRIUS == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_sirius()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_sirius().lat_eps_steer_ratio_size()
                  > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_sirius()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_sirius().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Libra
          if (VehProjectTyp_e::VehProjectTyp_LIBRA == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_libra()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_libra().lat_eps_steer_ratio_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_libra()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_libra().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Orion
          if (VehProjectTyp_e::VehProjectTyp_ORION == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_orion()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_orion().lat_eps_steer_ratio_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_orion()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_orion().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
          // Lyra
          if (VehProjectTyp_e::VehProjectTyp_LYRA == vehicle_type) {
            if (feature_conf_.lat_eps_steer_ratio_conf().has_lat_eps_steer_ratio_lyra()) {
              if (feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_lyra().lat_eps_steer_ratio_size() > 0) {
                float       x[100], y[100];
                std::size_t size_ = 0;
                WARN_LOG_FIRST_N(2) << "lat eps steer ratio range size: "
                                    << (uint16_t)feature_conf_.lat_eps_steer_ratio_conf()
                                         .lat_eps_steer_ratio_lyra()
                                         .lat_eps_steer_ratio_size();
                for (const auto table_ :
                     feature_conf_.lat_eps_steer_ratio_conf().lat_eps_steer_ratio_lyra().lat_eps_steer_ratio()) {
                  if (table_.has_gear_ratio() && table_.has_pinion_ag()) {
                    x[size_] = table_.pinion_ag();
                    y[size_] = table_.gear_ratio();
                    WARN_LOG << "table[: " << static_cast<uint32_t>(size_) << "] = " << static_cast<double_t>(x[size_])
                             << static_cast<double_t>(y[size_]);
                    size_++;
                  }
                }
                if (size_ > 0) {
                  lat_eps_steer_ratio_table_.init(x, y, size_);
                }
              }
            }
          }
        }
      }
    }
  }
  return true;
}

bool ParametersConfigurator::UpdateConf(const std::string& conf_file) {
  LoadFeatureConfData_(conf_file);
  LoadModeConf_();
  LoadFeatureConf_();
  UpdateConf();
  return true;
}

void ParametersConfigurator::UpdateCalTable() {
  if (LatCtrl_Elk_flgLoadElkConfEnbl_C) {
    if (ego_lateral_accl_table_.size() > 0) {
      LatCtrl_Elk_aEgoLtrlAccl_C =
        ego_lateral_accl_table_.interpolate(std::abs(LatCtrl_Elk_mpsTrgtIntvEgoVehLatVel_mp));
      if (std::abs(LatCtrl_Elk_aEgoLtrlAccl_C) < 1e-6) {
        LatCtrl_Elk_aEgoLtrlAccl_C = 0.1;
      }
    }
    if (oncoming_enable_ttc_table_.size() > 0) {
      LatCtrl_Elk_sOncmngTrgtIntvEnblTTCMax_C = oncoming_enable_ttc_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (oncoming_enable_predictive_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOncmngTrgtIntvEnblEstdLtrlRngMax_C =
        oncoming_enable_predictive_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (oncoming_disable_predictive_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOncmngTrgtIntvEnblEstdLtrlRngMin_C =
        oncoming_disable_predictive_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (oncoming_enable_current_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOncmngTrgtIntvEnblLtrlCrrntRngMax_C =
        oncoming_enable_current_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (oncoming_disable_current_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOncmngTrgtIntvEnblLtrlCrrntRngMin_C =
        oncoming_disable_current_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (overtaking_enable_ttc_table_.size() > 0) {
      LatCtrl_Elk_sOvrtkngTrgtIntvEnblTTCMax_C = overtaking_enable_ttc_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (overtaking_enable_predictive_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOvrtkngTrgtIntvEnblEstdLtrlRngMax_C =
        overtaking_enable_predictive_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (overtaking_disable_predictive_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOvrtkngTrgtIntvEnblEstdLtrlRngMin_C =
        overtaking_disable_predictive_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (overtaking_enable_current_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOvrtkngTrgtIntvEnblLtrlCrrntRngMax_C =
        overtaking_enable_current_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (overtaking_disable_current_lateral_range_table_.size() > 0) {
      LatCtrl_Elk_mOvrtkngTrgtIntvEnblLtrlCrrntRngMin_C =
        overtaking_disable_current_lateral_range_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (solid_line_lane_width_offset_table_.size() > 0) {
      LatCtrl_Elk_mSldLineInrZoneBrdLnWdthShft_C =
        solid_line_lane_width_offset_table_.interpolate(LatCtrl_Elk_mSldLineLnWdth_mp);
    }
    if (road_edge_lane_width_offset_table_.size() > 0) {
      LatCtrl_Elk_mRdEdgInrZoneBrdLnWdthShft_C =
        road_edge_lane_width_offset_table_.interpolate(LatCtrl_Elk_mRdEdgLnWdth_mp);
    }
    if (oncoming_lane_width_offset_table_.size() > 0) {
      LatCtrl_Elk_mOncmngTrgtInrZoneBrdLnWdthShft_C =
        oncoming_lane_width_offset_table_.interpolate(LatCtrl_Elk_mOncmngTrgtLnWdth_mp);
    }
    if (overtaking_lane_width_offset_table_.size() > 0) {
      LatCtrl_Elk_mOvrtkngTrgtInrZoneBrdLnWdthShft_C =
        overtaking_lane_width_offset_table_.interpolate(LatCtrl_Elk_mOvrtkngTrgtLnWdth_mp);
    }
    if (elk_c0_angle_gain_table_.size() > 0) {
      LatCtrl_Elk_facAgCtrlActvLtrlDstGain_C = elk_c0_angle_gain_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (elk_c1_angle_gain_table_.size() > 0) {
      LatCtrl_Elk_facAgCtrlYawAgGain_C = elk_c1_angle_gain_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (elk_c2_inner_angle_gain_table_.size() > 0) {
      LatCtrl_Elk_facAgCtrlInnrCurvGain_C = elk_c2_inner_angle_gain_table_.interpolate(LDW_vVehSpd_mp);
    }
    if (elk_c2_outer_angle_gain_table_.size() > 0) {
      LatCtrl_Elk_facAgCtrlOutrCurvGain_C = elk_c2_outer_angle_gain_table_.interpolate(LDW_vVehSpd_mp);
    }
  }

  if (LatCtrl_Lka_flgLoadLkaConfEnbl_C) {
    if (lka_low_predictive_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facLowSensiZoneBrdPrdvLtrlVelInnerShftGain_C =
        lka_low_predictive_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_low_predictive_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facLowSensiZoneBrdPrdvLtrlVelOuterShftGain_C =
        lka_low_predictive_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_low_actual_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facLowSensiZoneBrdLtrlVelInnrShftGain_C =
        lka_low_actual_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_low_actual_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facLowSensiZoneBrdLtrlVelOutrShftGain_C =
        lka_low_actual_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_low_lnwidth_c0_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_mLowSensiInrBrdLnWdthShft_C =
        lka_low_lnwidth_c0_inner_offset_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }
    if (lka_low_zone_border_min_table_.size() > 0) {
      LatCtrl_Lka_facLowSensiZoneBrdMin_C = lka_low_zone_border_min_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }

    if (lka_normal_predictive_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facNorSensiZoneBrdPrdvLtrlVelInnerShftGain_C =
        lka_normal_predictive_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_normal_predictive_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facNorSensiZoneBrdPrdvLtrlVelOuterShftGain_C =
        lka_normal_predictive_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_normal_actual_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facNorSensiZoneBrdLtrlVelInnrShftGain_C =
        lka_normal_actual_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_normal_actual_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facNorSensiZoneBrdLtrlVelOutrShftGain_C =
        lka_normal_actual_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_normal_lnwidth_c0_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_mNorSensiInrBrdLnWdthShft_C =
        lka_normal_lnwidth_c0_inner_offset_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }
    if (lka_normal_zone_border_min_table_.size() > 0) {
      LatCtrl_Lka_facNorSensiZoneBrdMin_C = lka_normal_zone_border_min_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }

    if (lka_high_predictive_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facHighSensiZoneBrdPrdvLtrlVelInnerShftGain_C =
        lka_high_predictive_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_high_predictive_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facHighSensiZoneBrdPrdvLtrlVelOuterShftGain_C =
        lka_high_predictive_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_high_actual_c1_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_facHighSensiZoneBrdLtrlVelInnrShftGain_C =
        lka_high_actual_c1_inner_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_high_actual_c1_outer_offset_table_.size() > 0) {
      LatCtrl_Lka_facHighSensiZoneBrdLtrlVelOutrShftGain_C =
        lka_high_actual_c1_outer_offset_table_.interpolate(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp);
    }
    if (lka_high_lnwidth_c0_inner_offset_table_.size() > 0) {
      LatCtrl_Lka_mHighSensiInrBrdLnWdthShft_C =
        lka_high_lnwidth_c0_inner_offset_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }
    if (lka_high_zone_border_min_table_.size() > 0) {
      LatCtrl_Lka_facHighSensiZoneBrdMin_C = lka_high_zone_border_min_table_.interpolate(LatCtrl_Lka_lEgoLaWdth_mp);
    }

    if (ldw_low_actual_c1_offset_table_.size() > 0) {
      Ldw_facLowSensiZoneBrdLtrlVelShftGain_C =
        ldw_low_actual_c1_offset_table_.interpolate(LDW_phiAgVeh2LaneCntrRaw_mp);
    }
    if (ldw_low_lnwidth_c0_inner_offset_table_.size() > 0) {
      Ldw_facLowSensiInrZoneBrdLnWdthShft_C = ldw_low_lnwidth_c0_inner_offset_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }
    if (ldw_low_zone_border_min_table_.size() > 0) {
      Ldw_facLowSensiZoneBrdMin_C = ldw_low_zone_border_min_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }

    if (ldw_normal_actual_c1_offset_table_.size() > 0) {
      Ldw_facNorSensiZoneBrdLtrlVelShftGain_C =
        ldw_normal_actual_c1_offset_table_.interpolate(LDW_phiAgVeh2LaneCntrRaw_mp);
    }
    if (ldw_normal_lnwidth_c0_inner_offset_table_.size() > 0) {
      Ldw_facNorSensiInrZoneBrdLnWdthShft_C =
        ldw_normal_lnwidth_c0_inner_offset_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }
    if (ldw_normal_zone_border_min_table_.size() > 0) {
      Ldw_facNorSensiZoneBrdMin_C = ldw_normal_zone_border_min_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }

    if (ldw_high_actual_c1_offset_table_.size() > 0) {
      Ldw_facHighSensiZoneBrdLtrlVelShftGain_C =
        ldw_high_actual_c1_offset_table_.interpolate(LDW_phiAgVeh2LaneCntrRaw_mp);
    }
    if (ldw_high_lnwidth_c0_inner_offset_table_.size() > 0) {
      Ldw_facHighSensiInrZoneBrdLnWdthShft_C =
        ldw_high_lnwidth_c0_inner_offset_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }
    if (ldw_high_zone_border_min_table_.size() > 0) {
      Ldw_facHighSensiZoneBrdMin_C = ldw_high_zone_border_min_table_.interpolate(LDW_lEgoLaWdthRaw_mp);
    }
  }

  if (LatCtrl_Lks_flgLoadLatAccGainFacConfEnbl_C) {
    if (lat_acc_k_gain_factor_table_.size() > 0) {
      LatCtrl_Lks_facLatAccKGain_C = lat_acc_k_gain_factor_table_.interpolate(LatCtrl_Lks_vVehSpdFacLatAcc_mp);
    }
    LatCtrl_Lks_facLatAccKGain_C = (LatCtrl_Lks_facLatAccKGain_C < 3.0f) ? LatCtrl_Lks_facLatAccKGain_C : 3.0f;
    LatCtrl_Lks_facLatAccKGain_C = (LatCtrl_Lks_facLatAccKGain_C > 1.0f) ? LatCtrl_Lks_facLatAccKGain_C : 1.0f;
  }

  if (LatCtrl_flgLoadEpsGearRatioConfEnbl_C) {
    if (lat_eps_steer_ratio_table_.size() > 0) {
      LatCtrl_facEpsGearRatio_C = lat_eps_steer_ratio_table_.interpolate(LatCtrl_EpsPinionAg_mp);
    }
    LatCtrl_facEpsGearRatio_C = (LatCtrl_facEpsGearRatio_C <= 20.0f) ? LatCtrl_facEpsGearRatio_C : 16.0f;
    LatCtrl_facEpsGearRatio_C = (LatCtrl_facEpsGearRatio_C >= 14.0f) ? LatCtrl_facEpsGearRatio_C : 16.0f;
  }
  if (ACCSC_flgUseCalCurLmtSpdTable_C) {
    if (acc_kph_cur_lmt_spd_table_.size() > 0) {
      ACCSC_kphCurLmtSpd_C = acc_kph_cur_lmt_spd_table_.interpolate(ACCSC_CurAdjSpdLimtCur_mp);
    }
  }
  if (ACCSC_flgUseCalbCIPVmaxRng_C) {
    if (acc_m_cipv_max_range_table_.size() > 0) {
      ACCSC_maxCalbCIPVTrgtSeletRng_Cur = acc_m_cipv_max_range_table_.interpolate(ACCSC_mpsVehSpdForCIPVTrgtSelet_mp);
    }
  }
  if (ACCSC_flgUseCalbNoBrkRngLmt_C) {
    if (acc_m_no_bake_range_table_.size() > 0) {
      ACCCT_mCalbNoBrkRangeLim_Cur = acc_m_no_bake_range_table_.interpolate(ACCSC_mpsVehSpdForCIPVTrgtSelet_mp);
    }
  }
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
