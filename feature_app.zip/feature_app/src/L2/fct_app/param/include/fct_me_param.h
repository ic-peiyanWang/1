
#pragma once
#include "niodds/application/application.h"
#include "asimov_compiler.h"


    extern MES_VAR double ME_LeftLine_Role_mp;
    extern MES_VAR double ME_LeftLine_C0_mp;
    extern MES_VAR double ME_LeftLine_C1_mp;
    extern MES_VAR double ME_LeftLine_C2_mp;
    extern MES_VAR double ME_LeftLine_C3_mp;
    extern MES_VAR double ME_LeftLine_start_mp;
    extern MES_VAR double ME_LeftLine_end_mp;
    extern MES_VAR double ME_LeftLine_conf_mp;
    extern MES_VAR double ME_RightLine_Role_mp;
    extern MES_VAR double ME_RightLine_C0_mp;
    extern MES_VAR double ME_RightLine_C1_mp;
    extern MES_VAR double ME_RightLine_C2_mp;
    extern MES_VAR double ME_RightLine_C3_mp;
    extern MES_VAR double ME_RightLine_start_mp;
    extern MES_VAR double ME_RightLine_end_mp;
    extern MES_VAR double ME_RightLine_conf_mp;
    extern MES_VAR double ME_LaneWidth_mp;