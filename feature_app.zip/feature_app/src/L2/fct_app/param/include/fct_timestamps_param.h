
#pragma once
#include "niodds/application/application.h"
#include "asimov_compiler.h"

    extern MES_VAR uint32_t FCT_TimestampsLow_mp;
    extern MES_VAR uint32_t FCT_TimestampsHigh_mp;
