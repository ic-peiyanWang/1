#pragma once
#include <string>
#include "ehy_math/nio_vmath.h"
#include "fct_conf.pb.h"
#include "niodds/application/application.h"
#include "proto_file.h"

namespace nio {
namespace ad {
namespace fctapp {

using namespace nio::ad::messages::fct_conf;
using namespace feature::math;

enum ConfLoadMode_e : uint16_t {
  ON_INIT   = 0,
  ON_CYCLE  = 1,
  ON_CHANGE = 2,
  ON_SECOND = 3,
};

enum LoadConfSts_e : uint16_t {
  NOT_LOADED = 0,
  LOADED     = 1,
  UPDATED    = 2,
};

enum VehProjectTyp_e : int {
  VehProjectTyp_INVALID_VEH_PROJECT = 0,
  VehProjectTyp_FORCE = 1,
  VehProjectTyp_GEMINI = 2,
  VehProjectTyp_PEGASUS = 3,
  VehProjectTyp_ARIES = 4,
  VehProjectTyp_SIRIUS = 5,
  VehProjectTyp_LIBRA = 6,
  VehProjectTyp_ORION = 7,
  VehProjectTyp_LYRA = 8
};
class ParametersConfigurator {
 public:
  ParametersConfigurator(){};
  ~ParametersConfigurator(){};
  bool UpdateConf();
  bool UpdateConf(const std::string& conf_file);
  void UpdateCalTable();
  void SetVehicleType(const int veh_type);

  ModeConf get_mode_conf() const {
    return mode_conf_;
  }

  FeatureConf get_feature_conf() const {
    return feature_conf_;
  }

  bool is_mode_conf_loaded() const {
    return LoadConfSts_e::NOT_LOADED != mode_conf_load_sts_;
  }

  bool is_feature_conf_data_loaded() const {
    return LoadConfSts_e::NOT_LOADED != feature_conf_data_load_sts_;
  }

  bool is_feature_conf_loaded() const {
    return LoadConfSts_e::NOT_LOADED != feature_conf_load_sts_;
  }

 private:
  void            LoadModeConf_(const std::string& conf_file);
  void            LoadModeConf_();
  void            LoadFeatureConf_(const std::string& conf_file);
  void            LoadFeatureConf_();
  void            LoadFeatureConfData_(const std::string& conf_file);
  FeatureConfData feature_conf_data_;
  LoadConfSts_e   feature_conf_data_load_sts_ = LoadConfSts_e::NOT_LOADED;
  ConfLoadMode_e  load_mode_                  = ConfLoadMode_e::ON_INIT;
  ModeConf        mode_conf_;
  LoadConfSts_e   mode_conf_load_sts_ = LoadConfSts_e::NOT_LOADED;
  FeatureConf     feature_conf_;
  LoadConfSts_e   feature_conf_load_sts_ = LoadConfSts_e::NOT_LOADED;
  VehProjectTyp_e vehicle_type = VehProjectTyp_e::VehProjectTyp_INVALID_VEH_PROJECT;

  LinearInterpolator<float> solid_line_lane_width_offset_table_;
  LinearInterpolator<float> road_edge_lane_width_offset_table_;
  LinearInterpolator<float> oncoming_lane_width_offset_table_;
  LinearInterpolator<float> overtaking_lane_width_offset_table_;
  LinearInterpolator<float> ego_lateral_accl_table_;
  LinearInterpolator<float> oncoming_enable_ttc_table_;
  LinearInterpolator<float> oncoming_enable_predictive_lateral_range_table_;
  LinearInterpolator<float> oncoming_disable_predictive_lateral_range_table_;
  LinearInterpolator<float> oncoming_enable_current_lateral_range_table_;
  LinearInterpolator<float> oncoming_disable_current_lateral_range_table_;
  LinearInterpolator<float> overtaking_enable_ttc_table_;
  LinearInterpolator<float> overtaking_enable_predictive_lateral_range_table_;
  LinearInterpolator<float> overtaking_disable_predictive_lateral_range_table_;
  LinearInterpolator<float> overtaking_enable_current_lateral_range_table_;
  LinearInterpolator<float> overtaking_disable_current_lateral_range_table_;
  LinearInterpolator<float> elk_c0_angle_gain_table_;
  LinearInterpolator<float> elk_c1_angle_gain_table_;
  LinearInterpolator<float> elk_c2_inner_angle_gain_table_;
  LinearInterpolator<float> elk_c2_outer_angle_gain_table_;

  LinearInterpolator<float> lka_low_predictive_c1_inner_offset_table_;
  LinearInterpolator<float> lka_low_predictive_c1_outer_offset_table_;
  LinearInterpolator<float> lka_low_actual_c1_inner_offset_table_;
  LinearInterpolator<float> lka_low_actual_c1_outer_offset_table_;
  LinearInterpolator<float> lka_low_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> lka_low_zone_border_min_table_;

  LinearInterpolator<float> lka_normal_predictive_c1_inner_offset_table_;
  LinearInterpolator<float> lka_normal_predictive_c1_outer_offset_table_;
  LinearInterpolator<float> lka_normal_actual_c1_inner_offset_table_;
  LinearInterpolator<float> lka_normal_actual_c1_outer_offset_table_;
  LinearInterpolator<float> lka_normal_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> lka_normal_zone_border_min_table_;

  LinearInterpolator<float> lka_high_predictive_c1_inner_offset_table_;
  LinearInterpolator<float> lka_high_predictive_c1_outer_offset_table_;
  LinearInterpolator<float> lka_high_actual_c1_inner_offset_table_;
  LinearInterpolator<float> lka_high_actual_c1_outer_offset_table_;
  LinearInterpolator<float> lka_high_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> lka_high_zone_border_min_table_;

  LinearInterpolator<float> ldw_low_actual_c1_offset_table_;
  LinearInterpolator<float> ldw_low_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> ldw_low_zone_border_min_table_;

  LinearInterpolator<float> ldw_normal_actual_c1_offset_table_;
  LinearInterpolator<float> ldw_normal_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> ldw_normal_zone_border_min_table_;

  LinearInterpolator<float> ldw_high_actual_c1_offset_table_;
  LinearInterpolator<float> ldw_high_lnwidth_c0_inner_offset_table_;
  LinearInterpolator<float> ldw_high_zone_border_min_table_;

  LinearInterpolator<float> lat_acc_k_gain_factor_table_;
  LinearInterpolator<float> lat_eps_steer_ratio_table_;
  LinearInterpolator<float> acc_kph_cur_lmt_spd_table_;
  LinearInterpolator<float> acc_m_cipv_max_range_table_;
  LinearInterpolator<float> acc_m_no_bake_range_table_;
};

extern ParametersConfigurator fct_conf_data;

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
