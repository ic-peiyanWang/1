#pragma once
#include "asimov_compiler.h"
#include "fct_diag.h"
#include "fim_encoder.h"
#include "niodds/application/application.h"

extern CAL_VAR uint32_t gFctInitMask;
extern CAL_VAR uint32_t gFctLossMask;
extern CAL_VAR uint32_t gLKALossMask;
extern CAL_VAR uint32_t gLDWLossMask;
extern CAL_VAR uint32_t gELKLossMask;
extern CAL_VAR uint32_t gAHCLossMask;
extern CAL_VAR uint32_t gDALossMask;
extern CAL_VAR uint32_t giACCLossMask;
extern CAL_VAR uint32_t gEASLossMask;
extern CAL_VAR uint32_t gSASLossMask;
extern CAL_VAR uint32_t gHeaterLossMask;
extern CAL_VAR uint32_t gGoNotifyLossMask;
extern CAL_VAR uint32_t gVsnNoReadyMask;
extern CAL_VAR uint16_t kFailsafeMskByte;
extern CAL_VAR uint16_t kLaneAssistFailsafeMskByte;
extern CAL_VAR uint16_t kLaneAssistFailsafeSideCamMskByte;
extern CAL_VAR uint16_t kAHC_FWfsMskByte;
extern CAL_VAR uint16_t kAHC_FNfsMskByte;
extern CAL_VAR uint16_t kLidarFailsafeMskByte;
extern CAL_VAR uint32_t gNOPLossMask;
// extern CAL_VAR uint16_t kFailsafeFWNMskByte;
extern CAL_VAR uint16_t kPSPFailsafeMskByte;

extern CAL_VAR uint8_t kGlobLkaMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobLdwMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobElkMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobElkRiRudderMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobAlcCamMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobAlcRadMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobEasMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobEasLgtMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobEasLatMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotNPMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotAcmMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotBcmMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotBcuMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotScmMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotVcuMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotSwcMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotDmsMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotF30MskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotSvcMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotApaMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotBgwMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotCdcMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotF120MskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotRadfcMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotRadfsMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotRadrsMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotCamfsMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotCamrsMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPilotCanBusOffMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobHeaterMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobGoNotifyUSSMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobGoNotifySysMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobNOPMskByte[DIAG_FIM_MAX_MASK_NUM];
extern CAL_VAR uint8_t kGlobPSPMskByte[DIAG_FIM_MAX_MASK_NUM];

extern CAL_VAR uint64_t gVsnInitCheckWindow;
extern CAL_VAR uint64_t gLdwFimInitCheckWindow;
extern CAL_VAR uint64_t gLkaFimInitCheckWindow;
extern CAL_VAR uint64_t gElkFimInitCheckWindow;
// extern CAL_VAR uint8_t  kGlobAAIntErrMskByte[DIAG_FIM_MAX_MASK_NUM];

extern MES_VAR uint8_t gLkaFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gLdwFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gElkFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gElkRiRudderFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotNPByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotAcmByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotBcmByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotBcuByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotScmByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotVcuByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotSwcByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotDmsByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotF30Byte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotSvcByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotApaByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotBgwByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotCdcByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotF120Byte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotRadfcByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotRadfsByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotRadrsByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotCamfsByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotCamrsByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPilotCanBusOffByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gHeaterFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gGoNotifyUSSFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gGoNotifySysFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gAlcCamFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gAlcRadFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gEasFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gEasLgtFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gEasLatFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gNOPFimByte[DIAG_FIM_MAX_MASK_NUM];
extern MES_VAR uint8_t gPSPFimByte[DIAG_FIM_MAX_MASK_NUM];

// extern MES_VAR uint8_t gAAappInterFimByte[DIAG_FIM_MAX_MASK_NUM];
