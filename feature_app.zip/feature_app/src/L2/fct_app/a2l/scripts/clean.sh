cd ..

rm src/*.cpp
rm -rf out
# rm output/*
rm fct_app.map
