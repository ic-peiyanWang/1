#!/bin/bash

MAZU_ARCH=$1
MAZU_TYPE=$2

cp ../../param/src/fct_timestamps_param.cpp ../src
cp ../../param/src/fct_me_param.cpp ../src
cp ../../feature_autogen/ldw/src/LDW.cpp ../src
cp ../../feature_autogen/lat_ctrl/src/ELKCore.cpp ../src
cp ../../feature_autogen/lat_ctrl/src/LCACore.cpp ../src
cp ../../feature_autogen/lat_ctrl/src/LKACore.cpp ../src
cp ../../feature_autogen/lat_ctrl/src/LKSCore.cpp ../src
cp ../../feature_autogen/lat_ctrl/src/LKS_LCA.cpp ../src
cp ../../feature_autogen/lon_ctrl/src/LongCtrl.cpp ../src
cp ../../feature_autogen/mtn_sal/src/MtnCtrl_SAL.cpp ../src
cp ../../feature_autogen/ids_mil/src/ids_mil.cpp ../src
cp ../../ahc/src/ahc_param.cpp ../src

cp ../../../../../build/${MAZU_ARCH}/src/L2/fct_app/fct_app.map ..

#generate
cd ..

cd src
FILES=$(ls *.cpp)
for FILE in $FILES
do
    NEWFILE=${FILE%.*}'.a2l'
    ../scripts/a2lgenerator.py $FILE $NEWFILE
done

cd ..
mkdir out
cp src/*.a2l out
rm src/*.a2l

#merge
cd out
../scripts/a2lmerge.py ../scripts/header.a2l *.a2l ../merge/*.a2l out.a2l

#update
#OFFSET='0x100C8000'
OFFSET='0x0'
cd ..
./scripts/a2lUpdater.py out/out.a2l fct_app.map info.txt fct_app.a2l $OFFSET

# move 
mv info.txt out/info.txt
mv fct_app.a2l ../../../../build/dist/${MAZU_ARCH}/${MAZU_TYPE}/a2l/

cd scripts
