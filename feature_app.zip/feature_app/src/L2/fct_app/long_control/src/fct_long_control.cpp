#include "fct_long_control.h"

namespace nio {
namespace ad {
namespace fctapp {
namespace {
constexpr double   kTLWComfortDeceleration             = -3.0;  // m/s^2
constexpr double   kTLWttcThreshold                    = 2.0;   // s
constexpr double   kTLWEgoSpeedThreshold               = 4.17;  // 15 kph
constexpr uint64_t kTrafficLightWarningWtiMaxTime      = 5e9;   // 5s = 5 * 1e9 ns;
constexpr uint64_t kTrafficLightWarningWtiDebounceTime = 30e9;  // 30s = 30 * 1e9 ns;
constexpr double   front_bumper_to_rear_axle           = 4.0;   // m

inline double toSecond(uint64_t t) {
  return static_cast<double>(t) / 1000000000.0;
}
}  // namespace

FctLongControl fct_long_control;

FctLongControl::FctLongControl() {}
FctLongControl::~FctLongControl() {}

void FctLongControl::fctLongControlMainFunction(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                                             std::shared_ptr<planner::IOAdapter>& ioadapter) {
  AERROR << "************Enter_fctLongControlMainFunction************";
  if (ioadapter == nullptr) {
    AERROR << "ioadapter == nullptr";
    return;
  }
  updateLongCtrlHMIInfo(fctout, veh50ms, ioadapter);
}

void FctLongControl::updateLongCtrlHMIInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                                           std::shared_ptr<planner::IOAdapter>& ioadapter) {
  AERROR << "************Enter_updateLongCtrlHMIInfo************";
  if (ioadapter == nullptr) {
    AERROR << "ioadapter == nullptr";
    return;
  }
  updateMD2ADInfo(fctout, veh50ms, ioadapter);
}

void FctLongControl::updateMD2ADInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                                     std::shared_ptr<planner::IOAdapter>& ioadapter) {
  AERROR << "************Enter_updateMD2ADInfo************";
  if (ioadapter == nullptr || fctout.mutable_manual_drive_to_adhmi() == nullptr) {
    AERROR << "ioadapter == nullpt || fctout.mutable_manual_drive_to_adhmi() == nullptr";
    return;
  }
  md_to_adinfo_bit_flag_ = 0;
  updateTrafficLightWarningInfo(fctout, veh50ms, ioadapter);

  AERROR << "md_to_adinfo_bit_flag_ = " << md_to_adinfo_bit_flag_;
  fctout.mutable_manual_drive_to_adhmi()->set_md_to_adinfo(md_to_adinfo_bit_flag_);  // write value to md_to_adinfo wti proto

  if (fctout.mutable_manual_drive_to_adhmi()->has_md_to_adinfo()) {
    AERROR << "fctout.mutable_manual_drive_to_adhmi()->md_to_adinfo() = "
           << fctout.mutable_manual_drive_to_adhmi()->md_to_adinfo();
  }
}

void FctLongControl::updateTrafficLightWarningInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                                                   std::shared_ptr<planner::IOAdapter>& ioadapter) {
  AERROR << "************Enter_updateTrafficLightWarningInfo************";
  if (ioadapter == nullptr || ioadapter->getInputManager().car_state_.GetLatest() == nullptr || dynamic_map == nullptr
      || AdasMap_info.empty() || AdasMap_info.back() == nullptr || ioadapter->getFramePtr() == nullptr
      || ioadapter->getInputManager().car_info_.GetLatest() == nullptr) {
    AERROR << "traffic light warning wti init failed";
    AERROR << "ioadapter == nullptr is " << static_cast<bool>(ioadapter == nullptr);
    AERROR << "dynamic_map == nullptr is " << static_cast<bool>(dynamic_map == nullptr);
    AERROR << "AdasMap_info.empty()  is " << static_cast<bool>(AdasMap_info.empty() );
    // AERROR << "AdasMap_info.back() == nullptr is " << static_cast<bool>(AdasMap_info.back() == nullptr);

    if (ioadapter != nullptr) {
      AERROR << "ioadapter->getInputManager().car_state_.GetLatest() == nullptr is "
             << static_cast<bool>(ioadapter->getInputManager().car_state_.GetLatest() == nullptr);
      AERROR << "ioadapter->getFramePtr() == nullptr is " << static_cast<bool>(ioadapter->getFramePtr() == nullptr);
    }

    return;
  }

  AERROR << "updateTrafficLightWarningInfo code dump debug flag 1";
  const auto& last_frame_ptr = ioadapter->getFramePtr();
  const auto& car_state = ioadapter->getInputManager().car_state_.GetLatest();
  const auto ego_speed = car_state->speed();
  const auto  car_info       = ioadapter->getInputManager().car_info_.GetLatest();

  AERROR << "updateTrafficLightWarningInfo code dump debug flag 2";
  bool sales_region_is_cn = tl_gonotifier.SalesRegion() == SalesRegionTyp_e::CN;
  bool platform_is_nt3 = ioadapter->getMidOutputManager().getPlatformNt3Flag();
  bool gear_is_drive = false;

  AERROR << "updateTrafficLightWarningInfo code dump debug flag 3";
  if(car_state->has_gear()) {
    gear_is_drive = car_state->gear() == nio::proto::CarState::DRIVE;
  }
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 4";
  uint32_t road_class = 0;
  if (AdasMap_info.back()->adas_info().segment().size() > 0) {
    road_class = static_cast<nio::proto::AdasRoadClass>(AdasMap_info.back()->adas_info().segment(0).road_class());
  }
  bool road_class_is_not_highway = road_class != nio::proto::AdasRoadClass::ROAD_CLASS_UNKNOWN
                                   && road_class != nio::proto::AdasRoadClass::HIGH_WAY_EXPRESS_WAY;

  AERROR << "updateTrafficLightWarningInfo code dump debug flag 5";
  const auto da_nad_status = static_cast<DaNadSts_e>(ioadapter->getMidOutputManager().getDAMainState().nadsts);
  bool da_nad_status_is_md = da_nad_status == DaNadSts_e::MdOff || da_nad_status == DaNadSts_e::MdPassive
                             || da_nad_status == DaNadSts_e::MdRdy || da_nad_status == DaNadSts_e::MdAccStby
                             || da_nad_status == DaNadSts_e::MdPilotStby;
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 11";
  bool brake_pedal_is_not_pressd = brk_sys.BrkPdl.BrkPedlSts != BrkPdlSts_e::Prssd;
  bool ego_speed_is_fast = ego_speed > kTLWEgoSpeedThreshold;
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 12";
  bool switch_is_on = false;
  if (nullptr != car_info && car_info->np_drv_info().adfuncfg().has_trafficlightwarningonoff()) {
    switch_is_on = static_cast<int>(car_info->np_drv_info().adfuncfg().trafficlightwarningonoff()) == true;
  }

  AERROR << "trafficlightwarningonoff :" << switch_is_on;
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 6";
  bool is_TLW_enable = sales_region_is_cn && platform_is_nt3 && gear_is_drive && road_class_is_not_highway
                      && da_nad_status_is_md && brake_pedal_is_not_pressd && ego_speed_is_fast && switch_is_on;
  AERROR << "sales_region_is_cn " << sales_region_is_cn << " platform_is_nt3 " << platform_is_nt3 << "  gear_is_drive "
         << gear_is_drive;
  AERROR << " road_class_is_not_highway " << road_class_is_not_highway << " da_nad_status_is_md " << da_nad_status_is_md
         << " brake_pedal_is_not_pressd " << brake_pedal_is_not_pressd << " ego_speed_is_fast " << ego_speed_is_fast
         << " switch_is_on " << switch_is_on;
  bool is_inhibit_traffic_light =
    tl_gonotifier.EsdTrafficLight().tld_valid == 1   // tld_valid; 0:无效 1：有效
    && (tl_gonotifier.EsdTrafficLight().tld_color == 1 || tl_gonotifier.EsdTrafficLight().tld_color == 2);   // tld_color; 0：Unknown, 1：Red, 2：Yellow, 3：Green 4:Gray
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 7";
  double distance_to_enter_point = std::numeric_limits<double>::max();
  if (dynamic_map && dynamic_map->has_navi_map() && dynamic_map->navi_map().has_long_range_info()) {
    for (const auto& navi_stub : dynamic_map->navi_map().long_range_info().navi_stub()) {
      const double& distance = navi_stub.distance_to_intersection_entry();
      if (distance >= 0.0) {
        distance_to_enter_point = std::min(distance_to_enter_point, distance);
      }
    }
  }
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 8";
  // const auto& traffic_light_info = last_frame_ptr->getTrafficLightInfo();
  // const auto& stop_line_s = traffic_light_info.stop_line_s;
  const double stop_line_s       = tl_gonotifier.DistanceToEntry() - front_bumper_to_rear_axle;
  bool ttc_is_small = stop_line_s > 0.1 ? stop_line_s / std::max(ego_speed, 0.1) < kTLWttcThreshold : false;
  bool is_uncomfort_deceleration = stop_line_s > 0.1 ? -ego_speed * ego_speed / (2.0 * kTLWComfortDeceleration) > stop_line_s : false;
  bool is_trigger_tlw_wti = is_TLW_enable && is_inhibit_traffic_light && (ttc_is_small || is_uncomfort_deceleration);

  AERROR << "updateTrafficLightWarningInfo code dump debug flag 9";
  const uint64_t current_time = ncyber::Time::Now().ToNanosecond();
  if (is_trigger_tlw_wti) {
    if (start_time_of_traffic_light_warning_wti_ == 0) {
      start_time_of_traffic_light_warning_wti_ = current_time;
    }
    auto trigger_duration = current_time - start_time_of_traffic_light_warning_wti_;
    auto debounce_duration = current_time - last_trigger_time_of_traffic_light_warning_wti_;
    AERROR << " trigger_duration " << trigger_duration << " debounce_duration " << debounce_duration;
    if (trigger_duration <= kTrafficLightWarningWtiMaxTime && debounce_duration > kTrafficLightWarningWtiDebounceTime) {
      AERROR << "ACTIVATE TLW";
      md_to_adinfo_bit_flag_ |= (1LL << 0);
    } else {
      AERROR << "current time: " << current_time
             << ", start_time_of_traffic_light_warning_wti_: " << start_time_of_traffic_light_warning_wti_;
    }
  } else {
    start_time_of_traffic_light_warning_wti_ = 0;
  }
  AERROR << "md_to_adinfo_bit_flag_  " << md_to_adinfo_bit_flag_;
  AERROR << "updateTrafficLightWarningInfo code dump debug flag 10";
  if (last_start_time_of_traffic_light_warning_wti_ != 0 && start_time_of_traffic_light_warning_wti_ == 0) {
    last_trigger_time_of_traffic_light_warning_wti_ = current_time;
  }
  last_start_time_of_traffic_light_warning_wti_ = start_time_of_traffic_light_warning_wti_;

  AERROR << "tl_gonotifier.SalesRegion() = " << static_cast<int>(tl_gonotifier.SalesRegion());
  AERROR << "ioadapter->getMidOutputManager().getPlatformNt3Flag() = "
         << static_cast<bool>(ioadapter->getMidOutputManager().getPlatformNt3Flag());
  AERROR << "car_state->gear() = " << static_cast<int>(car_state->gear());
  AERROR << "road_class = " << static_cast<int>(road_class);
  AERROR << "da_nad_status = " << static_cast<int>(da_nad_status);
  AERROR << "brk_sys.BrkPdl.BrkPedlSts = " << static_cast<int>(brk_sys.BrkPdl.BrkPedlSts);
  AERROR << "ego_speed = " << static_cast<double>(ego_speed);
  // if (car_info->np_drv_info().adfuncfg().has_trafficlightwarningonoff()) {
  //   AERROR << "veh50ms.drvin().adfuncfg().trafficlightwarningonoff() = "
  //          << static_cast<int>(veh50ms.drvin().adfuncfg().trafficlightwarningonoff());
  // }
  AERROR << "switch_is_on = " << switch_is_on;
  AERROR << "is_TLW_enable = " << is_TLW_enable;
  AERROR << "tl_gonotifier.EsdTrafficLight().tld_valid = "
         << static_cast<int>(tl_gonotifier.EsdTrafficLight().tld_valid);
  AERROR << "tl_gonotifier.EsdTrafficLight().tld_color = "
         << static_cast<int>(tl_gonotifier.EsdTrafficLight().tld_color);
  AERROR << "distance_to_enter_point = " << distance_to_enter_point;
  AERROR << "stop_line_s = " << stop_line_s;
  AERROR << "stop_line_s / std::max(ego_speed, 0.1)  = "
         << static_cast<double>(stop_line_s / std::max(ego_speed, 0.1));
  AERROR << " -ego_speed * ego_speed / (2.0 * kTLWComfortDeceleration)  = "
         << static_cast<double>(-ego_speed * ego_speed / (2.0 * kTLWComfortDeceleration));
  AERROR << "is_inhibit_traffic_light = " << is_inhibit_traffic_light;
  AERROR << "ttc_is_small = " << ttc_is_small;
  AERROR << "is_uncomfort_deceleration = " << is_uncomfort_deceleration;
  AERROR << "is_trigger_tlw_wti = " << is_trigger_tlw_wti;
  AERROR << "current_time = " << current_time;
  AERROR << "start_time_of_traffic_light_warning_wti_ = " << start_time_of_traffic_light_warning_wti_;
  AERROR << "last_start_time_of_traffic_light_warning_wti_ = "
         << last_start_time_of_traffic_light_warning_wti_;
  AERROR << "last_trigger_time_of_traffic_light_warning_wti_ = "
         << last_trigger_time_of_traffic_light_warning_wti_;
  AERROR << "trigger_duration = " << toSecond(current_time - start_time_of_traffic_light_warning_wti_);
  AERROR << "debounce_duration = " << toSecond(current_time - last_trigger_time_of_traffic_light_warning_wti_);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
