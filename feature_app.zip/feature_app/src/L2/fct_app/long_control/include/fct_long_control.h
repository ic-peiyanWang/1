#include "common/proto/car_state.pb.h"
#include "common/proto/dynamic_map.pb.h"
#include "cyber/common/log.h"
#include "fct_dastatemachine_adapter.h"
#include "fct_input_adapter.h"
#include "go_notifier.h"
#include "np/apps/fct_out.pb.h"
#include "planner/io_manager/io_adapter.h"

using namespace std;
using nio::ad::messages::FctOut;

namespace nio {
namespace ad {
namespace fctapp {

class FctLongControl { // it is to write the long control policy on the outside of the Matlab Model.

 public:
  FctLongControl();
  ~FctLongControl();

  void fctLongControlMainFunction(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                               std::shared_ptr<planner::IOAdapter>& ioadapter);

 private:
  void updateLongCtrlHMIInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                             std::shared_ptr<planner::IOAdapter>& ioadapter);
  void updateMD2ADInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                       std::shared_ptr<planner::IOAdapter>& ioadapter);
  void updateTrafficLightWarningInfo(FctOut& fctout, const nio::ad::messages::VEH50ms& veh50ms,
                                     std::shared_ptr<planner::IOAdapter>& ioadapter);

  uint64_t start_time_of_traffic_light_warning_wti_ = 0;
  uint64_t last_start_time_of_traffic_light_warning_wti_ = 0;
  uint64_t last_trigger_time_of_traffic_light_warning_wti_ = 0;
  bool current_trigger_traffic_light_warning_wti_ = false;
  uint32_t md_to_adinfo_bit_flag_ = 0;
};

extern FctLongControl fct_long_control;

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
