#include <gtest/gtest.h>
#include <iostream>
#include "ahc_main.h"
#include "ahc_param.h"
#include "ahc_type.h"
#include "fct_diag.h"
#include "fct_input_adapter.h"

namespace nio {
namespace ad {
namespace fctapp {

// fusion
class AHCdiagTest : public testing::Test {
 public:
  nio::ad::messages::CameraFimInfo           camera_fim_info_tmp;
  nio::ad::messages::FimCanInfo              can_fim_info_tmp;
  nio::ad::messages::FimSoftwareInfo         sw_fim_info_tmp;
  nio::ad::messages::CanFeatureFimInfo       fim_can_fea_info_tmp;
  nio::ad::messages::PowerFimInfo            fim_power_info_tmp;
  nio::ad::messages::MCUWithSOCFimInfo       fim_mcu_soc_info_tmp;
  nio::ad::messages::LidarFimInfo            fim_lidar_info_tmp;
  nio::ad::messages::McuSystemFimInfo        fim_mcu_sys_info_tmp;
  nio::ad::messages::PerceptionFimInfo       fim_perception_info_tmp;
  nio::ad::messages::FailSafeDetection       failsafe_camera_info_tmp;
  nio::ad::messages::Lidar_FailSafeDetection failsafe_lidar_info_tmp;
  // nio::ad::messages::VEH50ms                 veh50ms_info_tmp;
  proto::CarInfo                             veh_info_tmp;

  std::shared_ptr<nio::ad::messages::CameraFimInfo> camera_fim_info_ptr =
    std::make_shared<nio::ad::messages::CameraFimInfo>(camera_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimCanInfo> can_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimCanInfo>(can_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimSoftwareInfo> sw_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimSoftwareInfo>(sw_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::CanFeatureFimInfo> fim_can_fea_info_ptr =
    std::make_shared<nio::ad::messages::CanFeatureFimInfo>(fim_can_fea_info_tmp);
  std::shared_ptr<nio::ad::messages::PowerFimInfo> fim_power_info_ptr =
    std::make_shared<nio::ad::messages::PowerFimInfo>(fim_power_info_tmp);
  std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo> fim_mcu_soc_info_ptr =
    std::make_shared<nio::ad::messages::MCUWithSOCFimInfo>(fim_mcu_soc_info_tmp);
  std::shared_ptr<nio::ad::messages::LidarFimInfo> fim_lidar_info_ptr =
    std::make_shared<nio::ad::messages::LidarFimInfo>(fim_lidar_info_tmp);
  std::shared_ptr<nio::ad::messages::McuSystemFimInfo> fim_mcu_sys_info_ptr =
    std::make_shared<nio::ad::messages::McuSystemFimInfo>(fim_mcu_sys_info_tmp);
  std::shared_ptr<nio::ad::messages::PerceptionFimInfo> fim_perception_info_ptr =
    std::make_shared<nio::ad::messages::PerceptionFimInfo>(fim_perception_info_tmp);
  std::shared_ptr<nio::ad::messages::FailSafeDetection> failsafe_camera_info_ptr =
    std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_camera_info_tmp);
  std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> failsafe_lidar_info_ptr =
    std::make_shared<nio::ad::messages::Lidar_FailSafeDetection>(failsafe_lidar_info_tmp);
  std::shared_ptr<proto::CarInfo > veh_info_ptr =
    std::make_shared<proto::CarInfo >(veh_info_tmp);

  void gTest_main() {
    fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
                  fim_mcu_sys_info_ptr, fim_mcu_soc_info_ptr, fim_lidar_info_ptr, fim_perception_info_ptr,
                  failsafe_camera_info_ptr, failsafe_lidar_info_ptr, veh_info_ptr);
    ahc_main();
  }

 protected:
  virtual void SetUp() {
    // Set init state
    camera_fim_info_tmp.Clear();
    can_fim_info_tmp.Clear();
    sw_fim_info_tmp.Clear();
    fim_can_fea_info_tmp.Clear();
    fim_power_info_tmp.Clear();
    fim_mcu_soc_info_tmp.Clear();
    fim_lidar_info_tmp.Clear();

    stSetHMA                                         = SetHMA_e::SetHMA_On;
    stMainLghtSet                                    = MainLightSet_e::MnLght_Auto;
    flgFcmAHBC                                       = true;
    stVehSt                                          = VehState_e::VehSt_DrvrPrsnt;
    nio::ad::fctapp::func_arb.FunctionReq[2].FuncReq = FunctionRequest_e::ReqSandby;
    gAHCLossMask                                     = 0;
  }

  virtual void TearDown() {
    // Clean Env. before exit
  }
};

TEST_F(AHCdiagTest, failsafe) {
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gAHCPassiveSt is : " << (int)gAHCPassiveSt << std::endl;
  std::cout << "gFctTopicNoInit is : " << (int)gFctTopicNoInit << std::endl;
  std::cout << "gFctTopicLoss is : " << (int)gFctTopicLoss << std::endl;
  std::cout << "gFNfailsafe.high is : " << (int)gFNFailsafe.high << std::endl;
  EXPECT_TRUE(gAHCPassiveSt != FimFault_e::NoFault);

  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(0);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFNfailsafe.high is : " << (int)gFNFailsafe.high << std::endl;
  std::cout << "ct_diag_interface.is_AHC_TopicFault is : " << (int)fct_diag_interface.is_AHC_TopicFault << std::endl;
  EXPECT_TRUE(gAHCPassiveSt == FimFault_e::NoFault);
}

TEST_F(AHCdiagTest, CANFault) {
  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_hilowbeampushswtsts_invalid(true);
  fct_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();  // OFF--Passive
  std::cout << "AHCSysSt_e is : " << (int)AHCSm.Get_AutoHiBeamSysSts() << std::endl;
  gTest_main();  // Passive--Fault
  std::cout << "........................................................" << std::endl;
  std::cout << "AHCSysSt_e is : " << (int)AHCSm.Get_AutoHiBeamSysSts() << std::endl;
  std::cout << "gAHCFaultSt is : " << (int)gAHCFaultSt << std::endl;
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(gAHCFaultSt != FimFault_e::NoFault);
  EXPECT_TRUE(AHCSm.Get_AutoHiBeamSysSts() == AHCSM::AHCSysSt_e::TEMP_FAIL);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_hilowbeampushswtsts_invalid(false);
  fct_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAHCFaultSt == FimFault_e::NoFault);
  EXPECT_TRUE(AHCSm.Get_AutoHiBeamSysSts() != AHCSM::AHCSysSt_e::TEMP_FAIL);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_latavalsts_invalid(true);
  fct_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAHCPassiveSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_latavalsts_invalid(false);
  fct_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAHCPassiveSt == FimFault_e::NoFault);
}

TEST_F(AHCdiagTest, CameraFault) {

  // // f120 physical linkage error
  // camera_fim_info_ptr->mutable_f120_adc_fim_info()->set_fim_f120physicallinkage_error(true);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // gTest_main();
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::RevFault);

  // camera_fim_info_ptr->mutable_f120_adc_fim_info()->set_fim_f120physicallinkage_error(false);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // gTest_main();
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::NoFault);

  // // f30 physical linkage error
  // camera_fim_info_ptr->mutable_f30_adc_fim_info()->set_fim_f30physicallinkage_error(true);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
  //               fim_mcu_soc_info_ptr, fim_lidar_info_ptr);
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::RevFault);

  // camera_fim_info_ptr->mutable_f30_adc_fim_info()->set_fim_f30physicallinkage_error(false);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
  //               fim_mcu_soc_info_ptr, fim_lidar_info_ptr);
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::NoFault);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
