
#include <gtest/gtest.h>
#include <iostream>
#include "fct_diag.h"
#include "fct_input_adapter.h"
#include "fct_main.h"

#include "LongCtrl.h"

namespace nio {
namespace ad {
namespace fctapp {

// fusion
// class SasSlifTest : public testing::Test {
//  public:
//   nio::ad::messages::VEH10ms            veh10ms_tmp;
//   nio::ad::messages::VEH50ms            veh50ms_tmp;
//   nio::ad::messages::EHYRmeOutputs      ehy_rme_tmp;
//   nio::ad::messages::FctOut             fct_out_tmp;
//   nio::ad::messages::debug::FCTDebugOut fct_debug_out_tmp;

//   std::shared_ptr<nio::ad::messages::VEH10ms> veh10ms_tmp_ptr =
//     std::make_shared<nio::ad::messages::VEH10ms>(veh10ms_tmp);
//   std::shared_ptr<nio::ad::messages::VEH50ms> veh50ms_tmp_ptr =
//     std::make_shared<nio::ad::messages::VEH50ms>(veh50ms_tmp);
//   std::shared_ptr<nio::ad::messages::EHYRmeOutputs> ehy_rme_tmp_ptr =
//     std::make_shared<nio::ad::messages::EHYRmeOutputs>(ehy_rme_tmp);
//   std::shared_ptr<nio::ad::messages::FctOut> fct_out_tmp_ptr = std::make_shared<nio::ad::messages::FctOut>(fct_out_tmp);
//   std::shared_ptr<nio::ad::messages::debug::FCTDebugOut> fct_debug_out_tmp_ptr =
//     std::make_shared<nio::ad::messages::debug::FCTDebugOut>(fct_debug_out_tmp);
//   APP_state_e fct_state;

//  protected:
//   virtual void SetUp() {
//     // Set init state
//     veh10ms_tmp.Clear();
//     veh50ms_tmp.Clear();
//     ehy_rme_tmp.Clear();
//     fct_out_tmp.Clear();
//     fct_debug_out_tmp.Clear();
//     fct_state = APP_state_e::FullActive;

//     veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
//       nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
//     veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
//       nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
//     veh10ms_tmp_ptr->mutable_strsys()->set_hosts(nio::ad::messages::StrSysInfo_HOSts_e_HOSts_HandsOn);
//   }

//   virtual void TearDown() {
//     // Clean Env. before exit
//   }
// };

// TEST_F(SasSlifTest, Slif_normal_2) {
//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 0);

//   // set input
//   ehy_rme_tmp_ptr->mutable_hdmap_info()->add_ngp_list()->set_recom_speed_src(2);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   // run logic
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   // result
//   // std::cout << int(ACCSC_SpdLimSrcC_mp) << std::endl;
//   EXPECT_EQ(HWA_out.LNGCTRL.SLIFState, 2);
//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 2);
// }

// TEST_F(SasSlifTest, Slif_normal_3) {
//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 0);

//   // set input
//   ehy_rme_tmp_ptr->mutable_hdmap_info()->add_ngp_list()->set_recom_speed_src(3);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   // run logic
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   // result
//   // std::cout << int(ACCSC_SpdLimSrcC_mp) << std::endl;
//   EXPECT_EQ(HWA_out.LNGCTRL.SLIFState, 3);
//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 3);
// }

// TEST_F(SasSlifTest, Slif_fault) {
//   // Drive Assist Activation Prevention on AWB active
//   // [DA-20210712-15]

//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 0);

//   // set input
//   veh50ms_tmp_ptr->mutable_drvin()->mutable_cdceqpmt()->set_icsts(1);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   // run logic
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   // result
//   // std::cout << int(ACCSC_SpdLimSrcC_mp) << std::endl;
//   EXPECT_EQ(HWA_out.LNGCTRL.SLIFState, 5);
//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 5);
// }

// TEST_F(SasSlifTest, sas_spd_60) {
//   // Drive Assist Activation Prevention on AWB active
//   // [DA-20210712-15]

//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   EXPECT_EQ(fct_out_tmp.sas().slifstate(), 0);

//   // set input
//   veh50ms_tmp_ptr->mutable_drvin()->mutable_cdceqpmt()->set_icsts(0);
//   veh50ms_tmp_ptr->mutable_drvin()->mutable_adfuncfg()->set_setswf(
//     nio::ad::messages::DrvInfo_AdFunCfgInfo_SetSWFType_e_SetSWFType_SpdWarnWithSud);
//   ehy_rme_tmp_ptr->mutable_hdmap_info()->add_ngp_list()->set_recom_speed(60);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   // run logic
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   // result
//   std::cout << "ACCSC_kphLnSpdLimC_mp : " << int(ACCSC_kphLnSpdLimC_mp) << std::endl;
//   std::cout << "ACCCT_iAccSpdLmtValue : " << int(HWA_out.LNGCTRL.ACCCT_iAccSpdLmtValue) << std::endl;
//   EXPECT_EQ(HWA_out.LNGCTRL.ACCCT_iAccSpdLmtValue, 60);
//   EXPECT_EQ(fct_out_tmp.sas().speedlimitvalue(), 60);
// }

// TEST_F(SasSlifTest, slwf_trigger) {
//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);
//   fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//   fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);

//   EXPECT_EQ(fct_out_tmp.sas().slwfwarntrigger(), 0);

//   // set input
//   veh10ms_tmp_ptr->mutable_vehdyn()->mutable_vehspd()->set_vehdispspd(60);
//   veh50ms_tmp_ptr->mutable_drvin()->mutable_adfuncfg()->set_setswf(
//     nio::ad::messages::DrvInfo_AdFunCfgInfo_SetSWFType_e_SetSWFType_SpdWarnWithoSud);
//   ehy_rme_tmp_ptr->mutable_hdmap_info()->add_ngp_list()->set_recom_speed(50);

//   fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
//   fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
//   fct_ehy_rme.push_back(ehy_rme_tmp_ptr);

//   // run logic
//   for (int i = 0; i < 3; i++) {
//     fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
//     fct_output_fill(fct_out_tmp, fct_debug_out_tmp, fct_state);
//     std::cout << "ACCSC_kphVehDispSpd_mp : " << int(ACCSC_kphVehDispSpd_mp) << std::endl;
//   }

//   // result
//   std::cout << "ACCSC_kphLnSpdLimC_mp : " << int(ACCSC_kphLnSpdLimC_mp) << std::endl;
//   std::cout << "ACCCT_stSLWFWarnTrg_mp : " << int(ACCCT_stSLWFWarnTrg_mp) << std::endl;

//   EXPECT_EQ(HWA_out.LNGCTRL.SLWFWarnTrg, 1);
//   EXPECT_EQ(fct_out_tmp.sas().slwfwarntrigger(), 1);
// }
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
