#include <gtest/gtest.h>
#include <iostream>
#include "fct_diag.h"
#include "fct_input_adapter.h"

namespace nio {
namespace ad {
namespace fctapp {

// fusion
class FctDiagFimTest : public testing::Test {
 public:
 public:
  nio::ad::messages::CameraFimInfo           camera_fim_info_tmp;
  nio::ad::messages::FimCanInfo              can_fim_info_tmp;
  nio::ad::messages::FimSoftwareInfo         sw_fim_info_tmp;
  nio::ad::messages::CanFeatureFimInfo       fim_can_fea_info_tmp;
  nio::ad::messages::PowerFimInfo            fim_power_info_tmp;
  nio::ad::messages::MCUWithSOCFimInfo       fim_mcu_soc_info_tmp;
  nio::ad::messages::LidarFimInfo            fim_lidar_info_tmp;
  nio::ad::messages::McuSystemFimInfo        fim_mcu_sys_info_tmp;
  nio::ad::messages::PerceptionFimInfo       fim_perception_info_tmp;
  nio::ad::messages::FailSafeDetection       failsafe_camera_info_tmp;
  nio::ad::messages::Lidar_FailSafeDetection failsafe_lidar_info_tmp;
  // nio::ad::messages::VEH50ms                 veh50ms_info_tmp;
  proto::CarInfo                             veh_info_tmp;

  std::shared_ptr<nio::ad::messages::CameraFimInfo> camera_fim_info_ptr =
    std::make_shared<nio::ad::messages::CameraFimInfo>(camera_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimCanInfo> can_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimCanInfo>(can_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimSoftwareInfo> sw_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimSoftwareInfo>(sw_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::CanFeatureFimInfo> fim_can_fea_info_ptr =
    std::make_shared<nio::ad::messages::CanFeatureFimInfo>(fim_can_fea_info_tmp);
  std::shared_ptr<nio::ad::messages::PowerFimInfo> fim_power_info_ptr =
    std::make_shared<nio::ad::messages::PowerFimInfo>(fim_power_info_tmp);
  std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo> fim_mcu_soc_info_ptr =
    std::make_shared<nio::ad::messages::MCUWithSOCFimInfo>(fim_mcu_soc_info_tmp);
  std::shared_ptr<nio::ad::messages::LidarFimInfo> fim_lidar_info_ptr =
    std::make_shared<nio::ad::messages::LidarFimInfo>(fim_lidar_info_tmp);
  std::shared_ptr<nio::ad::messages::McuSystemFimInfo> fim_mcu_sys_info_ptr =
    std::make_shared<nio::ad::messages::McuSystemFimInfo>(fim_mcu_sys_info_tmp);
  std::shared_ptr<nio::ad::messages::PerceptionFimInfo> fim_perception_info_ptr =
    std::make_shared<nio::ad::messages::PerceptionFimInfo>(fim_perception_info_tmp);
  std::shared_ptr<nio::ad::messages::FailSafeDetection> failsafe_camera_info_ptr =
    std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_camera_info_tmp);
  std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> failsafe_lidar_info_ptr =
    std::make_shared<nio::ad::messages::Lidar_FailSafeDetection>(failsafe_lidar_info_tmp);
  std::shared_ptr<proto::CarInfo> veh_info_ptr =
    std::make_shared<proto::CarInfo>(veh_info_tmp);

  void gTest_main() {
    fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
                  fim_mcu_sys_info_ptr, fim_mcu_soc_info_ptr, fim_lidar_info_ptr, fim_perception_info_ptr,
                  failsafe_camera_info_ptr, failsafe_lidar_info_ptr, veh_info_ptr);
  }

 protected:
  virtual void SetUp() {
    // Set init state
    camera_fim_info_tmp.Clear();
    can_fim_info_tmp.Clear();
    sw_fim_info_tmp.Clear();
    fim_can_fea_info_tmp.Clear();
    fim_power_info_tmp.Clear();
    fim_mcu_soc_info_tmp.Clear();
    fim_lidar_info_tmp.Clear();
    failsafe_camera_info_tmp.Clear();
    failsafe_lidar_info_tmp.Clear();
  }

  virtual void TearDown() {
    // Clean Env. before exit
  }
};
TEST_F(FctDiagFimTest, NullFailsafeTest) {
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_rain(3);
  // fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 1);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 0);

  // fct_failsafe_detection.push_back(failsafe_camera_calib_null_ptr);
  gTest_main();
  std::cout << "..................NullFailsafeTest......................................" << std::endl;
  std::cout << gFNFailsafe.high << std::endl;
  std::cout << "..................NullFailsafeTest......................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
}

TEST_F(FctDiagFimTest, AnotherFailsafeTest) {
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_rain(0);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << gFNFailsafe.high << std::endl;

  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(0);
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_rain(3);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << gFNFailsafe.high << std::endl;
}

TEST_F(FctDiagFimTest, FailsafeClearTest) {
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_rain(0);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << gFNFailsafe.high << std::endl;

  std::cout << int(failsafe_camera_info_ptr->mutable_failsafe_fn()->has_fs_snow()) << std::endl;
  failsafe_camera_info_ptr->mutable_failsafe_fn()->clear_fs_snow();
  failsafe_camera_info_ptr->mutable_failsafe_fn()->clear_fs_rain();
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << gFNFailsafe.high << std::endl;
  std::cout << "........................................................" << std::endl;
  std::cout << int(failsafe_camera_info_ptr->mutable_failsafe_fn()->has_fs_snow()) << std::endl;
}

TEST_F(FctDiagFimTest, FailSafe_Test) {

  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 1);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 0);

  failsafe_camera_info_ptr->mutable_failsafe_fn()->set_fs_snow(0);
  failsafe_camera_info_ptr->mutable_failsafe_r()->set_fs_snow(3);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamR_FailSafe == 1);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamSVCRr_FailSafe == 0);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 1);

  failsafe_camera_info_ptr->mutable_failsafe_r()->set_fs_snow(0);
  failsafe_camera_info_ptr->mutable_failsafe_svc_rear()->set_fs_snow(3);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamR_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamSVCRr_FailSafe == 1);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 1);

  failsafe_camera_info_ptr->mutable_failsafe_svc_rear()->set_fs_snow(0);
  failsafe_lidar_info_ptr->mutable_failsafe()->set_fs_rain_snow(3);
  fct_failsafe_detection.push_back(failsafe_camera_info_ptr);
  fct_failsafe_lidar_info.push_back(failsafe_lidar_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 1);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamR_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamSVCRr_FailSafe == 0);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 0);

  // EXPECT_EQ(ACCSC_uFailSafeTDSoftInh1_mp & 0x00, 0x00);
  // EXPECT_EQ(ACCSC_uFailSafeTDSoftInh1_mp & 0x01, 0x00);
  // EXPECT_EQ(ACCSC_uFailSafeTDSoftInh1_mp & 0x03, 0x00);

  failsafe_lidar_info_ptr->mutable_failsafe()->set_fs_rain_snow(0);
  fct_failsafe_lidar_info.push_back(failsafe_lidar_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  EXPECT_TRUE(fct_fim.da_FailSafe.is_Lidar_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFW_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamFN_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamR_FailSafe == 0);
  EXPECT_TRUE(fct_fim.da_FailSafe.is_CamSVCRr_FailSafe == 0);
  EXPECT_TRUE(fct_fim.is_ALCS_Failsafe == 0);
}

TEST_F(FctDiagFimTest, CameraFault) {

  // sidefl physical linkage error
  camera_fim_info_ptr->mutable_sidefl_adc_fim_info()->set_fim_sideflphysicallinkage_error(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_ALCS_Cam_Fim == 1);

  camera_fim_info_ptr->mutable_sidefl_adc_fim_info()->set_fim_sideflphysicallinkage_error(false);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_ALCS_Cam_Fim == 0);

  camera_fim_info_ptr->mutable_fn_adc_fim_info()->set_fim_fnphysicallinkage_error(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_ALCS_Cam_Fim == 0);

  // camera_fim_info_ptr->mutable_f120_adc_fim_info()->set_fim_f120physicallinkage_error(false);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
  //               fim_mcu_soc_info_ptr, fim_lidar_info_ptr);
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::NoFault);

  // // f30 physical linkage error
  // camera_fim_info_ptr->mutable_f30_adc_fim_info()->set_fim_f30physicallinkage_error(true);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
  //               fim_mcu_soc_info_ptr, fim_lidar_info_ptr);
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::RevFault);

  // camera_fim_info_ptr->mutable_f30_adc_fim_info()->set_fim_f30physicallinkage_error(false);
  // fct_fim_camera_info.push_back(camera_fim_info_ptr);
  // fct_fim_can_info.push_back(can_fim_info_ptr);
  // fct_fim_sw_info.push_back(sw_fim_info_ptr);
  // fct_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
  //               fim_mcu_soc_info_ptr, fim_lidar_info_ptr);
  // EXPECT_TRUE(gPilotFaultSt == FimFault_e::NoFault);
}

TEST_F(FctDiagFimTest, DMSRelatedFault) {
  std::cout << "....................GTest-BL110-DMSRelatedFault.........................." << std::endl;

  // dms physical linkage error
  camera_fim_info_ptr->mutable_dms_adc_fim_info()->set_fim_dmsphysicallinkage_error(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_dms_fault == 1);
  // license not available
  camera_fim_info_ptr->mutable_dms_adc_fim_info()->set_fim_dms_license_notavailable(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_dms_fault == 1);
  // function not available
  camera_fim_info_ptr->mutable_dms_adc_fim_info()->set_fim_dms_function_notavailable(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_dms_fault == 1);
  // dms no image receivew
  camera_fim_info_ptr->mutable_dms_adc_fim_info()->set_fim_dms_no_image_recv(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_dms_fault == 1);

  // dms is occluded
  camera_fim_info_ptr->mutable_dms_adc_fim_info()->set_fim_dms_camera_occluded(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_dms_camera_occluded == 1);
  std::cout << "........................................................" << std::endl;
}

TEST_F(FctDiagFimTest, FrontCamLidarFault) {
  std::cout << "....................GTest-BL110-FrontCamLidarFault.........................." << std::endl;
  // fw cal
  camera_fim_info_ptr->mutable_fw_adc_fim_info()->set_fim_fw_camera_cal_error(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);
  // fn cal
  camera_fim_info_ptr->mutable_fn_adc_fim_info()->set_fim_fn_camera_cal_error(true);
  fct_fim_camera_info.push_back(camera_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);
  // fw data
  fim_perception_info_ptr->set_fim_fw_camera_data_error(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);
  // fn data
  fim_perception_info_ptr->set_fim_fn_camera_data_error(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);

  // lidar data
  fim_perception_info_ptr->set_fim_lidar_data_error(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);

  // lidar com
  fim_lidar_info_ptr->set_fim_lidar_com_error(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);

  // lidar cal
  fim_lidar_info_ptr->set_fim_lidar_cal_error(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);

  // lidar fault1
  fim_lidar_info_ptr->set_fim_lidar_internal_fault1(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_frontCam_lidar_fault == 1);
  std::cout << "........................................................" << std::endl;
}

TEST_F(FctDiagFimTest, LidarOverheating) {
  std::cout << "....................GTest-BL110-LidarOverheating.........................." << std::endl;
  // lidar overheating2
  fim_lidar_info_ptr->set_fim_lidar_overheat2(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_overheating == 1);

  // lidar overheating3
  fim_lidar_info_ptr->set_fim_lidar_overheat3(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_overheating == 1);
  std::cout << "........................................................" << std::endl;
}

TEST_F(FctDiagFimTest, LidarBlocked) {

  std::cout << "....................GTest-BL110-LidarBlocked.........................." << std::endl;
  // lidar blockage1
  fim_lidar_info_ptr->set_fim_lidar_window_blockage1(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_blocked == 1);

  // lidar blockage2
  fim_lidar_info_ptr->set_fim_lidar_window_blockage2(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_blocked == 1);

  // lidar blockage3
  fim_lidar_info_ptr->set_fim_lidar_window_blockage3(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_blocked == 1);

  // lidar blockage4
  fim_lidar_info_ptr->set_fim_lidar_window_blockage4(true);
  fct_fim_lidar_info.push_back(fim_lidar_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.da_np_fim.is_lidar_blocked == 1);
  std::cout << "........................................................" << std::endl;
}

TEST_F(FctDiagFimTest, AAappInternalFault) {

  std::cout << "....................GTest-BL110-AAappInternalFault.........................." << std::endl;
  // FIM_NOP_Plus_Internal_Error
  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_stop_vehicle_standstil(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Stop_Vehicle_Standstil == 1);

  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_deactivate_function(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Deactivate_Function == 1);

  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_lateral_control_suppression(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Lateral_Control_Suppression == 1);

  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_longitudinal_control_suppression(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Longitudinal_Control_Suppression == 1);

  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_takeover_warning(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Takeover_Warning == 1);

  fim_perception_info_ptr->mutable_fim_nop_plus_internal_error()->set_attention_warning(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_nop_internal_fault.Attention_Warning == 1);

  // FIM_DA_Internal_Error
  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_stop_vehicle_standstil(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Stop_Vehicle_Standstil == 1);

  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_deactivate_function(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Deactivate_Function == 1);

  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_lateral_control_suppression(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Lateral_Control_Suppression == 1);

  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_longitudinal_control_suppression(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Longitudinal_Control_Suppression == 1);

  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_takeover_warning(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Takeover_Warning == 1);

  fim_perception_info_ptr->mutable_fim_da_internal_error()->set_attention_warning(true);
  fct_fim_perception_info.push_back(fim_perception_info_ptr);
  gTest_main();
  EXPECT_TRUE(fct_fim.is_AAapp_da_internal_fault.Attention_Warning == 1);
  std::cout << "........................................................" << std::endl;

}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
