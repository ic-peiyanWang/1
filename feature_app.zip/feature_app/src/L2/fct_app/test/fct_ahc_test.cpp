#include <gtest/gtest.h>
#include "ahc_type.h"
#include "ahc_main.h"

static void set_sm_st_off(void)
{
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(false);    
    AHCSm.Set_CamBlk(false);    
    AHCSm.Set_SysTempFail(false);    
    AHCSm.Set_SysPermFail(false);    

    ahc_main();

    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

static void set_sm_st_passive(void)
{
    set_sm_st_off();
//OFF to PASSIVE
    AHCSm.Set_SwitchedON(true);
    AHCSm.Set_DrvPrsnt(true);
    AHCSm.Set_HighBeamSprsn(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

static void set_sm_st_standby(void)
{
    set_sm_st_passive();
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(false);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
     
}

static void set_sm_st_camblk(void)
{
    set_sm_st_passive();
    AHCSm.Set_CamBlk(true);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::CAM_BLK,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

static void set_sm_st_tempfail(void)
{
    set_sm_st_passive();
    AHCSm.Set_SysTempFail(true);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

static void set_sm_st_permfail(void)
{
    set_sm_st_passive();
    AHCSm.Set_SysPermFail(true);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());

}

static void set_sm_st_active(void){
    set_sm_st_passive();
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(true,AHCSm.Get_AutoHiBeamReq());
}

TEST(SMtst,StOff)
{
//Default OFF
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//OFF to PASSIVE
    set_sm_st_off();
    AHCSm.Set_SwitchedON(true);
    AHCSm.Set_DrvPrsnt(true);
    AHCSm.Set_HighBeamSprsn(true);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//OFF to ACITVE
    set_sm_st_off();
    AHCSm.Set_SwitchedON(true);
    AHCSm.Set_DrvPrsnt(true);
    AHCSm.Set_HighBeamSprsn(false);    
    AHCSm.Set_EnvNeedHiBm(true);    
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//off to cam blk
    set_sm_st_off();
    AHCSm.Set_CamBlk(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//off to temp fail 
    set_sm_st_off();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//off to perm fail 
    set_sm_st_off();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

TEST(SMtst,StPassive)
{
//passive to off 
    set_sm_st_passive();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//passive to standby
    set_sm_st_passive();
    AHCSm.Set_HighBeamSprsn(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//passive to active
    set_sm_st_passive();
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(true,AHCSm.Get_AutoHiBeamReq());
//passive to cam blk
    set_sm_st_passive();
    AHCSm.Set_CamBlk(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::CAM_BLK,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//passive to temp fail 
    set_sm_st_passive();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//passive to temp fail 
    set_sm_st_passive();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

TEST(SMtst,StStandby)
{
//standby to off
    set_sm_st_standby();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//standby to passive 
    set_sm_st_standby();
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_standby();
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//standby to active
    set_sm_st_standby();
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::ACTIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(true,AHCSm.Get_AutoHiBeamReq());
//standby to cam blk
    set_sm_st_standby();
    AHCSm.Set_CamBlk(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::CAM_BLK,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//standby to temp fail 
    set_sm_st_standby();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//standby to perm fail 
    set_sm_st_standby();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    
}

TEST(SMtst,StActive)
{
//active to off
    set_sm_st_active();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//active to passive
    set_sm_st_active();
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_active();
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//active to standby
    set_sm_st_active();
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//active to cam blk
    set_sm_st_active();
    AHCSm.Set_CamBlk(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::CAM_BLK,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//active to temp fail 
    set_sm_st_active();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//active to perm fail 
    set_sm_st_active();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

TEST(SMtst,StCamBlk)
{  
//camblk to off
    set_sm_st_camblk();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//camblk to passive
    set_sm_st_camblk();
    AHCSm.Set_CamBlk(false);
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//camblk to standby 
    set_sm_st_camblk();
    AHCSm.Set_CamBlk(false);
    AHCSm.Set_HighBeamSprsn(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//camblk to temp fail 
    set_sm_st_camblk();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//camblk to perm fail 
    set_sm_st_camblk();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}

TEST(SMtst,Stsystempfail)
{
//tempfail to off
    set_sm_st_tempfail();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_tempfail();
    AHCSm.Set_SwitchedON(true);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_tempfail();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//tempfail to passive
    set_sm_st_tempfail();
    AHCSm.Set_SysTempFail(false);    
    AHCSm.Set_HighBeamSprsn(true);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//tempfail to standby
    set_sm_st_tempfail();
    AHCSm.Set_SysTempFail(false);    
    AHCSm.Set_HighBeamSprsn(false);
    AHCSm.Set_EnvNeedHiBm(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::STANDBY,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//tempfail to camblk 
    set_sm_st_tempfail();
    AHCSm.Set_CamBlk(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::TEMP_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    AHCSm.Set_CamBlk(false); 
//tempfail to permfail 
    set_sm_st_tempfail();
    AHCSm.Set_SysPermFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());

}

TEST(SMtst,Stsyspermfail)
{
//permfail to off
    set_sm_st_permfail();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(true);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_permfail();
    AHCSm.Set_SwitchedON(true);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
    set_sm_st_permfail();
    AHCSm.Set_SwitchedON(false);
    AHCSm.Set_DrvPrsnt(false);
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::OFF,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::OFF,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
//permfail to tempfail
    set_sm_st_permfail();
    AHCSm.Set_SysTempFail(true); 
    ahc_main();
    EXPECT_EQ(AHCSM::AHCSysSt_e::PASSIVE,AHCSm.Get_AutoHiBeamSysSts());
    EXPECT_EQ(AHCSM::AHCSt_e::PERMANENT_FAIL,AHCSm.Get_AutoHiBeamSts());
    EXPECT_EQ(false,AHCSm.Get_AutoHiBeamReq());
}
