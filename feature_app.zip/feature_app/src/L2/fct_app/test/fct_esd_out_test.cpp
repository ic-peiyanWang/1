#include <gtest/gtest.h>
#include <iostream>

#include "fct_esd_out.h"
#include "fct_input_adapter.h"
#include "fct_main.h"
#include "fct_out_proc.h"
#include "fct_timestamps_param.h"
#include "func_arb_type.h"
#include "ids_mil.h"
#include "niodds/application/application.h"
#include "fct_dastatemachine_adapter.h"
#include "planner/io_manager/io_adapter.h"

namespace nio {
namespace ad {
namespace fctapp {

class ESDTEST : public testing::Test {
 public:
  nio::ad::messages::EHYTppOutputs                  ehy_tpp;
  std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_ptr =
    std::make_shared<nio::ad::messages::EHYTppOutputs>(ehy_tpp);

  nio::ad::messages::esd_np_feature                  esdout;
  std::shared_ptr<nio::ad::messages::esd_np_feature> esdout_ptr =
    std::make_shared<nio::ad::messages::esd_np_feature>(esdout);

  nio::ad::messages::VEH10ms                  veh10ms_tmp;
  nio::ad::messages::VEH50ms                  veh50ms_tmp;
  nio::ad::messages::FctOut                   fct_out_tmp;
  nio::ad::messages::debug::FCTDebugOut       fct_debug_out_tmp;
  std::shared_ptr<nio::ad::messages::VEH10ms> veh10ms_tmp_ptr =
    std::make_shared<nio::ad::messages::VEH10ms>(veh10ms_tmp);
  std::shared_ptr<nio::ad::messages::VEH50ms> veh50ms_tmp_ptr =
    std::make_shared<nio::ad::messages::VEH50ms>(veh50ms_tmp);
  std::shared_ptr<nio::ad::messages::FctOut> fct_out_tmp_ptr = std::make_shared<nio::ad::messages::FctOut>(fct_out_tmp);
  std::shared_ptr<nio::ad::messages::debug::FCTDebugOut> fct_debug_out_tmp_ptr =
    std::make_shared<nio::ad::messages::debug::FCTDebugOut>(fct_debug_out_tmp);

 protected:
  virtual void SetUp() {
    // Set init state
    ehy_tpp.Clear();
    veh10ms_tmp.Clear();
    veh50ms_tmp.Clear();
    fct_out_tmp.Clear();
    fct_debug_out_tmp.Clear();

    veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
      nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
    veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
      nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
    veh10ms_tmp_ptr->mutable_strsys()->set_hosts(nio::ad::messages::StrSysInfo_HOSts_e_HOSts_HandsOn);
  }

  virtual void TearDown() {
    // Clean Env. before exit
  }
};

TEST_F(ESDTEST, actshift) {

  ehy_tpp_ptr->add_shift_object_id(20);
  ehy_tpp_ptr->set_act_shift_status(1);
  fct_ehy_tpp.push_back(ehy_tpp_ptr);
  std::shared_ptr<nio::planner::IOAdapter> adapter = std::make_shared<nio::planner::IOAdapter>();
  fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
           adapter);

  fct_esd_output_processing(*fct_out_tmp_ptr);

  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_id() == 20);
  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_da() == 2);
  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_level() == 2);

  ehy_tpp_ptr->add_shift_object_id(20);
  ehy_tpp_ptr->set_act_shift_status(0);

  fct_ehy_tpp.push_back(ehy_tpp_ptr);
  fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
           adapter);

  fct_esd_output_processing(*fct_out_tmp_ptr);

  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_id() == 0);
  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_da() == 0);
  EXPECT_TRUE(esdout_ptr->esd_np_object().at(5).esd_np_obj_level() == 0);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
