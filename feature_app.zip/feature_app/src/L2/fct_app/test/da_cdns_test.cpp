#include <gtest/gtest.h>
#include <iostream>
#include "fct_input_adapter.h"
#include "fct_main.h"
#include "LongCtrl.h"
#include "MainState.h"
#include "fct_dastatemachine_adapter.h"
#include "planner/io_manager/io_adapter.h"

namespace nio{
namespace ad{
namespace fctapp{

//fusion
class DAActPrevCdn : public testing::Test{
    public:
        nio::ad::messages::VEH10ms veh10ms_tmp;
        nio::ad::messages::VEH50ms veh50ms_tmp;
        nio::ad::messages::FctOut fct_out_tmp;
        nio::ad::messages::debug::FCTDebugOut fct_debug_out_tmp;
        std::shared_ptr<nio::ad::messages::VEH10ms>veh10ms_tmp_ptr =
            std::make_shared<nio::ad::messages::VEH10ms>(veh10ms_tmp);
        std::shared_ptr<nio::ad::messages::VEH50ms>veh50ms_tmp_ptr =
            std::make_shared<nio::ad::messages::VEH50ms>(veh50ms_tmp);
        std::shared_ptr<nio::ad::messages::FctOut>fct_out_tmp_ptr =
            std::make_shared<nio::ad::messages::FctOut>(fct_out_tmp);
        std::shared_ptr<nio::ad::messages::debug::FCTDebugOut>fct_debug_out_tmp_ptr =
            std::make_shared<nio::ad::messages::debug::FCTDebugOut>(fct_debug_out_tmp);
    protected:
        virtual void SetUp(){
            // Set init state
            veh10ms_tmp.Clear();
            veh50ms_tmp.Clear();
            fct_out_tmp.Clear();
            fct_debug_out_tmp.Clear();

            veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
                nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
            veh50ms_tmp.mutable_vehbody()->mutable_lightsts()->add_foglifctactvsts(
                nio::ad::messages::VehBodyInfo_LightsInfo_FogLiStType_e_FogLi_Off);
            veh10ms_tmp_ptr->mutable_strsys()->set_hosts(nio::ad::messages::StrSysInfo_HOSts_e_HOSts_HandsOn);
        }

        virtual void TearDown(){
            // Clean Env. before exit
        }
};

TEST_F(DAActPrevCdn, BrkFun) {

    // Drive Assist Activation Prevention on ABA active
    // [DA-20210713-19]
    // Drive Assist Activation Prevention on ABP active
    // [DA-20210713-20]
    // Drive Assist Activation Prevention on AWB active
    // [DA-20210712-15]

    std::shared_ptr<nio::planner::IOAdapter> adapter = std::make_shared<nio::planner::IOAdapter>();
    // fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
    // fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
    fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
                adapter);

    EXPECT_EQ(ACCSC_uAebFun_mp & 0x07, 0x00);
    EXPECT_EQ(ACCSC_uActPrev1_mp & ~ACCSC_uBitMaskActPrev1_C, 0x00);
    EXPECT_EQ(ACCSC_uActPrev_mp & ~ACCSC_uBitMaskActPrev_C, 0x00);
    EXPECT_EQ(ACCSC_flgActPrev_mp, false);
    // EXPECT_EQ(ACCSC_uResuPrev1_mp & ~ACCSC_uBitMaskResuPrev1_C, 0x00);
    // EXPECT_EQ(ACCSC_uResuPrev_mp & ~ACCSC_uBitMaskResuPrev_C, 0x00);
    EXPECT_EQ(ACCSC_flgResuPrev_mp, false);

    // set input
    veh10ms_tmp_ptr->mutable_brksys()->mutable_brkfunst()->set_abaactv(true);
    veh10ms_tmp_ptr->mutable_brksys()->mutable_brkfunst()->set_abpactv(true);
    veh10ms_tmp_ptr->mutable_brksys()->mutable_brkfunst()->set_awbactv(true);
    veh10ms_tmp_ptr->mutable_brksys()->mutable_brkpdl()->set_brkpedlsts(nio::ad::messages::BrkPdlSt_Prssd);

    // fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
    // fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);

    // run logic
    fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
             adapter);

    EXPECT_EQ(ACCSC_uAebFun_mp & 0x07, 0x07);
    EXPECT_EQ(ACCSC_uActPrev1_mp & ~ACCSC_uBitMaskActPrev1_C, 0x01);
    EXPECT_EQ(ACCSC_uActPrev_mp & ~ACCSC_uBitMaskActPrev_C, 0x01);
    EXPECT_EQ(ACCSC_flgActPrev_mp, true);
    // EXPECT_EQ(ACCSC_uResuPrev1_mp & ~ACCSC_uBitMaskResuPrev1_C, 0x01);
    // EXPECT_EQ(ACCSC_uResuPrev_mp & ~ACCSC_uBitMaskResuPrev_C, 0x01);
    EXPECT_EQ(ACCSC_flgResuPrev_mp, true);
}

TEST_F(DAActPrevCdn, DMS) {

    // Drive Assist Activation Prevention on Driver Distracted
    // [DA-20210926-03]
    // Drive Assist Activation Prevention on Driver Hands-Off
    // [DA-20210722-03]

    // set input
    // veh10ms_tmp_ptr->mutable_brksys()->mutable_brkfunst()->set_abaactv(true);

    // fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
    // fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);
    std::shared_ptr<nio::planner::IOAdapter> adapter = std::make_shared<nio::planner::IOAdapter>();

    // run logic
    // fct_main(veh10ms_tmp, veh50ms_tmp,
    //             &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
    fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
             adapter);

    std::cout << "IMPORTANT!!! THIS CASE NOT READY!!!" << std::endl;
    EXPECT_TRUE(false);
}

TEST_F(DAActPrevCdn, HOD) {

    // Drive Assist Activation Prevention on Driver Distracted
    // [DA-20210926-03]
    // Drive Assist Activation Prevention on Driver Hands-Off
    // [DA-20210722-03]
    std::shared_ptr<nio::planner::IOAdapter> adapter = std::make_shared<nio::planner::IOAdapter>();

    // fct_main(veh10ms_tmp, veh50ms_tmp,
    //             &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
    fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
             adapter);

    EXPECT_EQ(ACCSC_uActPrev1_mp & ~ACCSC_uBitMaskActPrev1_C, 0x00);
    EXPECT_EQ(ACCSC_uActPrev_mp & ~ACCSC_uBitMaskActPrev_C, 0x00);
    EXPECT_EQ(ACCSC_flgActPrev_mp, false);
    // EXPECT_EQ(ACCSC_uResuPrev1_mp & ~ACCSC_uBitMaskResuPrev1_C, 0x00);
    // EXPECT_EQ(ACCSC_uResuPrev_mp & ~ACCSC_uBitMaskResuPrev_C, 0x00);
    EXPECT_EQ(ACCSC_flgResuPrev_mp, false);

    // set input
    veh10ms_tmp_ptr->mutable_strsys()->set_hosts(nio::ad::messages::StrSysInfo_HOSts_e_HOSts_HandsOff);

    // fct_vehicle_input_10.push_back(veh10ms_tmp_ptr);
    // fct_vehicle_input_50.push_back(veh50ms_tmp_ptr);

    // std::cout << "abaactv   : " << int(veh10ms_tmp.brksys().brkfunst().abaactv()) << std::endl;
    // std::cout << "abaactv   : " << int(fct_vehicle_input_10.back()->brksys().brkfunst().abaactv()) << std::endl;
    // std::cout << "foglifc   : " << int(veh50ms_tmp.vehbody().lightsts().foglifctactvsts(0)) << std::endl;
    // ERROR std::cout << "foglifc   : " << int(fct_vehicle_input_50.back()->vehbody().lightsts().foglifctactvsts(1)) << std::endl;

    // run logic
    // fct_main(veh10ms_tmp, veh50ms_tmp,
    //             &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp);
    fct_main(veh10ms_tmp, veh50ms_tmp, &fct_input_adapter_, fct_out_tmp, fct_debug_out_tmp, &da_statemachine_adapter,
             adapter);
    EXPECT_EQ(ACCSC_uActPrev1_mp & ~ACCSC_uBitMaskActPrev1_C, 0x04);
    EXPECT_EQ(ACCSC_flgActPrev_mp, true);
    // EXPECT_EQ(ACCSC_uResuPrev1_mp & ~ACCSC_uBitMaskResuPrev1_C, 0x04);
    EXPECT_EQ(ACCSC_flgResuPrev_mp, true);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
