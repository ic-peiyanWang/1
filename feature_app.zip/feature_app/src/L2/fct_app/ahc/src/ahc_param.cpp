#include "ahc_param.h"
#define uchar unsigned char
CAL_VAR double  AHC_vVehSpdThres_C        = 15.0;
CAL_VAR double  AHC_vVehSpdThresHys_C     = 10.0;
CAL_VAR double  AHC_dphiYawrateThres_C    = 0.2;
CAL_VAR double  AHC_dphiYawrateThresHys_C = 0;
CAL_VAR double  AHC_aVehLatAccThres_C     = 0.300001;
CAL_VAR double  AHC_aVehLatAccThresHys_C  = 0.01;
VehState_e      stVehSt                   = VehState_e::VehSt_Parked;
CAL_VAR double  kphVehSpd                 = 0.0;
MES_VAR bool    flgSetHMAInvld            = false;
MES_VAR bool    flgMainLghtSetInvld       = false;
MES_VAR bool    flgHiBeamInvld            = false;
MES_VAR bool    flgLowBeamInvld           = false;
MES_VAR bool    flgFrntWiperInvld         = false;
MES_VAR bool    flgHiLowBeamSwtInvld      = false;
MES_VAR bool    flgHiBeamCmdInvld         = false;
FogLiSts_e      stFogLiFrntFctActvSts     = FogLiSts_e::FogLi_Off;
FogLiSts_e      stFogLiReFctActvSts       = FogLiSts_e::FogLi_Off;
FrntWiprSts_e   stFrntWiperSts            = FrntWiprSts_e::FrntWpr_Off;
ActGear_e       stActGear                 = ActGear_e::ActGear_Neutral;
MainLightSet_e  stMainLghtSet             = MainLightSet_e::MnLght_Off;
SetHMA_e        stSetHMA                  = SetHMA_e::SetHMA_Off;
MES_VAR float   AHC_illuminance           = 0;
MES_VAR bool    illuminance_supress       = 0;
MES_VAR uint8_t AHC_supress_age           = 0;
MES_VAR uint8_t AHC_recover_age           = 0;
MES_VAR bool    flgFcmAHBC                = true;
MES_VAR bool    flgGearInvld              = false;
MES_VAR bool    flgYawrateInvld           = false;
MES_VAR bool    flgLatAccValInvld         = false;
MES_VAR bool    flgVehSpdInvld            = false;
MES_VAR bool    flgVehStInld              = false;
MES_VAR bool    flgACMLossCommFault       = false;
MES_VAR bool    flgBcuLossCommFault       = false;
MES_VAR bool    flgCgwLossCommFault       = false;
MES_VAR bool    flgScmLossCommFault       = false;
MES_VAR bool    flgCdcLossCommFault       = false;
MES_VAR bool    flgBcmLossCommFault       = false;
MES_VAR bool    flgVcuLossCommFault       = false;
MES_VAR bool    flgCdcLossCommAdasFault   = false;
MES_VAR bool    flgAdcInternalFault       = false;
MES_VAR bool    flgEq4NonRecoverableFault = false;
MES_VAR bool    flgEq4RecoverableFault    = false;
MES_VAR bool    flgCamBlock               = false;
MES_VAR bool    flgFSTsrOutOfCalibMode    = false;
MES_VAR bool    flgFsBlurredImage         = false;
MES_VAR bool    flgRain                   = false;
MES_VAR bool    flgFsFoggySpots           = false;
MES_VAR bool    flgFsOutOfFucos           = false;
MES_VAR bool    flgFsFrozenWindshield     = false;
MES_VAR bool    flgEq4Coredump            = false;
MES_VAR double  dphiYawRate               = 0.0;
MES_VAR bool    flgAutoBrkgActv           = false;
MES_VAR bool    flgVDCActv                = false;
MES_VAR bool    flgABSActv                = false;
MES_VAR double  gVehLatAcc                = 0.0;
MES_VAR uchar   AHC_stHiBeamAssistSts_mp  = 0;
MES_VAR uint8_t gAHCFaultFimByte[DIAG_FIM_MAX_MASK_NUM];
MES_VAR uint8_t gAHCPassiveFimByte[DIAG_FIM_MAX_MASK_NUM];
CAL_VAR double  AHC_illuminance_highThr                       = 1.9;
CAL_VAR double  AHC_illuminance_lowThr                        = 1.8;
CAL_VAR uint8_t AHC_supress_Thr                               = 10;
CAL_VAR uint8_t AHC_recover_Thr                               = 30;
CAL_VAR double  AHC_kphYawrateThrHys_x[8]                     = { 0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0 };
CAL_VAR double  AHC_dphiYawrateThresHys_cur[8]                = { 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01 };
bool            flgDrvReqAHC                                  = false;
CAL_VAR uint8_t kGlobAHCPassiveMskByte[DIAG_FIM_MAX_MASK_NUM] = {
  0xFF, 0x5C, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 00~09
  0xFE, 0xFF, 0xDF, 0xBB, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 10~19
  0xFF, 0xFF, 0xFF, 0xFF, 0xF7, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 20~29
  0xFF, 0xFC, 0xFF, 0xFF, 0x5E, 0xFF, 0xFF, 0xBE, 0xBA, 0xFf,  // byte 30~39
  0xFC, 0xFF, 0xBF, 0x7D, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 40~49
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE,  // byte 50~59
  0xF7, 0xDF, 0xBF, 0xFF, 0xBF, 0xFF, 0xFD, 0xEF, 0x7F, 0xFF,  // byte 60~69
  0xFF, 0xFF, 0xDF, 0x7F, 0xFF, 0xFF, 0x03, 0xE0, 0xFF, 0xFF,  // byte 70~79
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 80~89
  0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xE4, 0xFF,  // byte 90~99
  0xEC, 0xFF, 0xFF, 0xFF, 0xFF, 0xFD, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 100~109
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 110~119
  0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 120~129
};
CAL_VAR uint8_t kGlobAHCFaultMskByte[DIAG_FIM_MAX_MASK_NUM] = {
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xF8,  // byte 00~09
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 10~19
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 20~29
  0xEF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE,  // byte 30~39
  0xFF, 0xDF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 40~49
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 50~59
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 60~69
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 70~79
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 80~89
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 90~99
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 100~109
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 110~119
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 120~129
};
