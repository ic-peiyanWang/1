#include "ahc_main.h"
#include "ahc_param.h"
#include "ahc_sigproc.h"
#include "ahc_type.h"
#include "fct_diag.h"
#include "fct_input_adapter.h"
#include "niodds/application/application.h"
#include <algorithm>
#include <iostream>
AHCSM    AHCSm;
AHC      AHCFun;
FAMSts_e AHC_FAMSts;

AHCSM::AHCSM() {}
AHCSM::~AHCSM() {}

void AHCSM::Set_SwitchedON(bool ahcon) {
  flgAHCOn = ahcon;
}

bool AHCSM::Get_SwitchedON() {
  return flgAHCOn;
}
void AHCSM::Set_DrvPrsnt(bool drvprsnt) {
  flgDrvPrsnt = drvprsnt;
}

bool AHCSM::Get_DrvPrsnt() {
  return flgDrvPrsnt;
}

bool AHCSM::Get_SystemFail(void) {
  return (flgCamBlk || flgTempFail || flgPermFail);
}

void AHCSM::Set_CamBlk(bool fail) {
  flgCamBlk = fail;
}

bool AHCSM::Get_CamBlk() {
  return flgCamBlk;
}

void AHCSM::Set_SysTempFail(bool fail) {
  flgTempFail = fail;
}
bool AHCSM::Get_SysTempFail() {
  return flgTempFail;
}

void AHCSM::Set_SysPermFail(bool fail) {
  flgPermFail = fail;
}

bool AHCSM::Get_SysPermFail() {
  return flgPermFail;
}

void AHCSM::Set_HighBeamSprsn(bool hibmspr) {
  flgHiBmSpr = hibmspr;
}

bool AHCSM::Get_HighBeamSprsn() {
  return flgHiBmSpr;
}

void AHCSM::Set_BeamChngSprsn(bool bmchngspr) {
  flgBmChngSpr = bmchngspr;
}

bool AHCSM::Get_BeamChngSprsn() {
  return flgBmChngSpr;
}

void AHCSM::Set_EnvNeedHiBm(bool hibmshallon) {
  flgEnvNeedHiBm = hibmshallon;
}

bool AHCSM::Get_EnvNeedHiBm() {
  return flgEnvNeedHiBm;
}

void AHCSM::UpdateStateMachine(void) {
  // std::cout<<"in ahc state machine================="<<std::endl;
  // std::cout<<"flgBmChngSpr is " << (int)flgBmChngSpr<<std::endl;
  if (nio::ad::fctapp::func_arb.FunctionReq[2].FuncReq == FunctionRequest_e::ReqSandby) {

  if (AHCSts == AHCSt_e::OFF) {
    AHCSts     = AHCSt_e::OFF;
    AHCSysSt   = AHCSysSt_e::OFF;
    flgHiBmReq = false;
    if (flgAHCOn && flgDrvPrsnt) {
      // std::cout << "flgHiBmSpr is" << flgHiBmSpr << std::endl;
      // std::cout << "AHC off to passive===================="<< std::endl;
      AHCSts     = AHCSt_e::PASSIVE;
      AHCSysSt   = AHCSysSt_e::PASSIVE;
      flgHiBmReq = false;
      // if(!flgDrvReqAHC){
      //     AHCSts   = AHCSt_e::PASSIVE;
      //     AHCSysSt = AHCSysSt_e::PASSIVE;
      //     flgHiBmReq = false;
      // } else {
      //     AHCSts     = AHCSt_e::STANDBY;
      //     AHCSysSt   = AHCSysSt_e::ACTIVE;
      //     flgHiBmReq = false;
      // }
    } else {
      /**/
    }
  } else if (AHCSts == AHCSt_e::PASSIVE) {
    AHCSts     = AHCSt_e::PASSIVE;
    AHCSysSt   = AHCSysSt_e::PASSIVE;
    flgHiBmReq = false;
    if (!flgAHCOn || !flgDrvPrsnt) {
      AHCSts   = AHCSt_e::OFF;
      AHCSysSt = AHCSysSt_e::OFF;
    } else if (Get_SystemFail()) {
      if (flgPermFail) {
        AHCSts   = AHCSt_e::PERMANENT_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgTempFail) {
        AHCSts   = AHCSt_e::TEMP_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgCamBlk) {
        AHCSts   = AHCSt_e::CAM_BLK;
        AHCSysSt = AHCSysSt_e::CAM_BLK;
      } else {
      }
    } else if (!flgHiBmSpr && flgEnvNeedHiBm) {  //&& PsvTimer <= 0.0){
      AHCSts     = AHCSt_e::ACTIVE;
      AHCSysSt   = AHCSysSt_e::ACTIVE;
      flgHiBmReq = true;
    } else if (flgDrvReqAHC && (nio::ad::fctapp::gAHCPassiveSt == nio::ad::FimFault_e::NoFault)) {
      AHCSts     = AHCSt_e::STANDBY;
      AHCSysSt   = AHCSysSt_e::ACTIVE;
      flgHiBmReq = false;
    } else {
      PsvTimer = std::max(0.0, PsvTimer - AHCFun.sampletime);
    }
  } else if (AHCSts == AHCSt_e::STANDBY) {
    AHCSts     = AHCSt_e::STANDBY;
    AHCSysSt   = AHCSysSt_e::ACTIVE;
    flgHiBmReq = false;
    if (!flgAHCOn || !flgDrvPrsnt) {
      AHCSts   = AHCSt_e::OFF;
      AHCSysSt = AHCSysSt_e::OFF;
    } else if (Get_SystemFail()) {
      if (flgPermFail) {
        AHCSts   = AHCSt_e::PERMANENT_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgTempFail) {
        AHCSts   = AHCSt_e::TEMP_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgCamBlk) {
        AHCSts   = AHCSt_e::CAM_BLK;
        AHCSysSt = AHCSysSt_e::CAM_BLK;
      } else {
      }
    } else if (!flgHiBmSpr && flgEnvNeedHiBm && !flgBmChngSpr) {
      AHCSts     = AHCSt_e::ACTIVE;
      AHCSysSt   = AHCSysSt_e::ACTIVE;
      flgHiBmReq = true;
    } else if (!flgDrvReqAHC || (nio::ad::fctapp::gAHCPassiveSt != nio::ad::FimFault_e::NoFault)) {
      AHCSts   = AHCSt_e::PASSIVE;
      AHCSysSt = AHCSysSt_e::PASSIVE;
    } else {
      PsvTimer = std::max(0.0, PsvTimer - AHCFun.sampletime);
    }
  } else if (AHCSts == AHCSt_e::ACTIVE) {
    AHCSts     = AHCSt_e::ACTIVE;
    AHCSysSt   = AHCSysSt_e::ACTIVE;
    flgHiBmReq = true;
    if (!flgAHCOn || !flgDrvPrsnt) {
      AHCSts     = AHCSt_e::OFF;
      AHCSysSt   = AHCSysSt_e::OFF;
      flgHiBmReq = false;
    } else if (Get_SystemFail()) {
      if (flgPermFail) {
        AHCSts   = AHCSt_e::PERMANENT_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgTempFail) {
        AHCSts   = AHCSt_e::TEMP_FAIL;
        AHCSysSt = AHCSysSt_e::TEMP_FAIL;
      } else if (flgCamBlk) {
        AHCSts   = AHCSt_e::CAM_BLK;
        AHCSysSt = AHCSysSt_e::CAM_BLK;
      } else {
      }
      flgHiBmReq = false;
    } else if ((flgHiBmSpr || !flgEnvNeedHiBm) && flgDrvReqAHC
               && (nio::ad::fctapp::gAHCPassiveSt == nio::ad::FimFault_e::NoFault) && !flgBmChngSpr) {
      AHCSts     = AHCSt_e::STANDBY;
      AHCSysSt   = AHCSysSt_e::ACTIVE;
      flgHiBmReq = false;
    } else if (!flgDrvReqAHC || (nio::ad::fctapp::gAHCPassiveSt != nio::ad::FimFault_e::NoFault)) {
      AHCSts     = AHCSt_e::PASSIVE;
      AHCSysSt   = AHCSysSt_e::PASSIVE;
      flgHiBmReq = false;
    } else {
    }
  } else if (AHCSts == AHCSt_e::CAM_BLK) {
    AHCSts     = AHCSt_e::CAM_BLK;
    AHCSysSt   = AHCSysSt_e::CAM_BLK;
    flgHiBmReq = false;
    if (!flgAHCOn || !flgDrvPrsnt) {
      // std::cout << "AHC block to off =========================="<< std::endl;
      AHCSts   = AHCSt_e::OFF;
      AHCSysSt = AHCSysSt_e::OFF;
    } else if (flgPermFail) {
      AHCSts   = AHCSt_e::PERMANENT_FAIL;
      AHCSysSt = AHCSysSt_e::TEMP_FAIL;
    } else if (flgTempFail) {
      AHCSts   = AHCSt_e::TEMP_FAIL;
      AHCSysSt = AHCSysSt_e::TEMP_FAIL;
    } else if (!flgCamBlk) {
      if (!flgDrvReqAHC || (nio::ad::fctapp::gAHCPassiveSt != nio::ad::FimFault_e::NoFault)) {
        AHCSts   = AHCSt_e::PASSIVE;
        AHCSysSt = AHCSysSt_e::PASSIVE;
      } else {
        AHCSts   = AHCSt_e::STANDBY;
        AHCSysSt = AHCSysSt_e::ACTIVE;
      }
    } else {
    }

  } else if (AHCSts == AHCSt_e::TEMP_FAIL) {
    AHCSts     = AHCSt_e::TEMP_FAIL;
    AHCSysSt   = AHCSysSt_e::TEMP_FAIL;
    flgHiBmReq = false;
    if (!flgAHCOn || !flgDrvPrsnt) {
      // std::cout << "AHC tmpfail to off =========================="<< std::endl;
      AHCSts   = AHCSt_e::OFF;
      AHCSysSt = AHCSysSt_e::OFF;
    } else if (flgPermFail) {
      AHCSts   = AHCSt_e::PERMANENT_FAIL;
      AHCSysSt = AHCSysSt_e::TEMP_FAIL;
    } else if (!flgTempFail) {
      AHCSts   = AHCSt_e::PASSIVE;
      AHCSysSt = AHCSysSt_e::PASSIVE;
    } else {
    }
  } else if (AHCSts == AHCSt_e::PERMANENT_FAIL) {
    AHCSts     = AHCSt_e::PERMANENT_FAIL;
    AHCSysSt   = AHCSysSt_e::TEMP_FAIL;
    flgHiBmReq = false;
    if (!flgAHCOn || !flgDrvPrsnt) {
      // std::cout << "AHC perm fail to off =========================="<< std::endl;
      AHCSts   = AHCSt_e::OFF;
      AHCSysSt = AHCSysSt_e::OFF;
    } else {
    }
  } else {
    // std::cout << "AHC default off =========================="<< std::endl;
    AHCSts     = AHCSt_e::OFF;
    AHCSysSt   = AHCSysSt_e::OFF;
    flgHiBmReq = false;
  }
  // std::cout<<"AHCSts is"<<(int)AHCSts<<std::endl;
  // std::cout<<"AHCSysSt is"<<(int)AHCSysSt<<std::endl;
  } else if (nio::ad::fctapp::func_arb.FunctionReq[2].FuncReq == FunctionRequest_e::ReqLoaded) {
    AHCSts     = AHCSt_e::PASSIVE;
    AHCSysSt   = AHCSysSt_e::PASSIVE;
    flgHiBmReq = false;
  }

  if (AHCSysSt == AHCSysSt_e::OFF) {
    AHC_FAMSts = FAMSts_e::AHC_Loaded;
  } else if (AHCSysSt == AHCSysSt_e::ACTIVE) {
    AHC_FAMSts = FAMSts_e::AHC_Running;
  } else {
    AHC_FAMSts = FAMSts_e::AHC_Checking;
  }
}

AHCSM::AHCSysSt_e AHCSM::Get_AutoHiBeamSysSts(void) {
  return AHCSysSt;
}

AHCSM::AHCSt_e AHCSM::Get_AutoHiBeamSts(void) {
  return AHCSts;
}

bool AHCSM::Get_AutoHiBeamReq(void) {
  return flgHiBmReq;
}

AHC::AHC() {}
AHC::~AHC() {}
void ahc_main(void) {
  // INFO_LOG << "ahc_main start";
  ahc_sys_signal_process();
  AHCSm.UpdateStateMachine();
  AHC_stHiBeamAssistSts_mp = (unsigned char)AHCSm.Get_AutoHiBeamSysSts();
  // INFO_LOG << "ahc_main complete";
}
void ahc_init(void) {}
