#include <algorithm>
#include <iostream>
#include <math.h>
#include "ahc_param.h"
#include "ahc_type.h"
#include "fct_diag.h"
#include "fct_in_proc.h"
#include "ids_lib.h"
#include "fct_input_adapter.h"

HystrssLLORHO YawRateHysis, LatAccHysis;
HystrssLHORLO SpdSprHysis;
double        lookup1D_binlcapw(double u0, const double bp0[], const double table[], unsigned int maxIndex) {
  double       y;
  double       frac;
  unsigned int iRght;
  unsigned int iLeft;
  unsigned int bpIdx;

  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac  = 0.0;
  } else if (u0 < bp0[maxIndex]) {
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex;
    frac  = 0.0;
  }

  if (iLeft == maxIndex) {
    y = table[iLeft];
  } else {
    y = (table[iLeft + 1U] - table[iLeft]) * frac + table[iLeft];
  }

  return y;
}
static void ahc_sys_switch_status(AHCSM& ahcsm) {

  bool ahcon = false;

  if (stSetHMA == SetHMA_On && stMainLghtSet == MnLght_Auto && flgFcmAHBC) {
    ahcon = true;
  } else if (stSetHMA == SetHMA_Off || stMainLghtSet == MnLght_Off || stMainLghtSet == MnLght_PositionLight
             || stMainLghtSet == MnLght_LowBeam || !flgFcmAHBC) {
    ahcon = false;
  }

  // ahcon = stSetHMA == SetHMA_On
  //      && stMainLghtSet == MnLght_Auto
  //      && flgFcmAHBC;
  // std::cout << "stSetHMA is " <<(int)stSetHMA <<std::endl;
  // std::cout << "stMainLghtSet is " <<(int)stMainLghtSet <<std::endl;
  // std::cout << "flgFcmAHBC is " <<(int)flgFcmAHBC <<std::endl;
  // std::cout << "ahcon is " <<(int)ahcon <<std::endl;

  ahcsm.Set_SwitchedON(ahcon);
}

static void ahc_sys_driver_present(AHCSM& ahcsm) {

  bool drvprsnt = false;
  drvprsnt      = (stVehSt == VehSt_DrvrPrsnt || stVehSt == VehSt_Driving);
  // std::cout << "stVehSt is " <<(int)stVehSt <<"VehSt_Parked = 0,  VehSt_DrvrPrsnt = 1, VehSt_Driving = 2,
  // VehSt_SwUpdate = 3,"<<std::endl;
  ahcsm.Set_DrvPrsnt(drvprsnt);
}

static void ahc_sys_temp_error(AHCSM& ahcsm) {

  int temperr = 0;
  int tempfim = 0;

  temperr = flgSetHMAInvld + (flgMainLghtSetInvld << 0) + (flgHiBeamInvld << 2) + (flgLowBeamInvld << 3)
            + (flgFrntWiperInvld << 4) + (flgHiLowBeamSwtInvld << 5) + (flgHiBeamCmdInvld << 6);

  tempfim = flgGearInvld + (flgYawrateInvld << 1) + (flgLatAccValInvld << 2) + (flgVehSpdInvld << 3)
            + (flgVehStInld << 4) + (flgACMLossCommFault << 5) + (flgBcuLossCommFault << 6) + (flgCgwLossCommFault << 7)
            + (flgScmLossCommFault << 8) + (flgCdcLossCommFault << 9) + (flgBcmLossCommFault << 10)
            + (flgVcuLossCommFault << 11) + (flgCdcLossCommAdasFault << 12);

  ahcsm.Set_SysTempFail(temperr || tempfim || (nio::ad::fctapp::gAHCFaultSt != nio::ad::FimFault_e::NoFault));
}

static void ahc_sys_high_beam_supression(AHCSM& ahcsm) {

  int sprst = 0;

  if (AHC_illuminance > AHC_illuminance_highThr) {
    AHC_supress_age++;
    AHC_recover_age = 0;
  } else if (AHC_illuminance < AHC_illuminance_lowThr) {
    AHC_recover_age++;
    AHC_supress_age = 0;
  } else {
    AHC_supress_age = 0;
    AHC_recover_age = 0;
  }
  AHC_supress_age = std::min(AHC_supress_age, (uint8_t)250);
  AHC_recover_age = std::min(AHC_recover_age, (uint8_t)250);
  if (AHC_supress_age >= AHC_supress_Thr) {
    illuminance_supress = 1;
  } else {
    // nothing
  }
  if (AHC_recover_age >= AHC_recover_Thr) {
    illuminance_supress = 0;
  } else {
    // nothing
  }

  const auto &sales_region = static_cast<int>(nio::ad::fctapp::veh_param.VarCodeInfo.sales_region);

  double ahc_min_vel_trs = 0;
  double ahc_max_vel_trs = 0;
  if(sales_region == 2) {
    ahc_min_vel_trs = 27;
    ahc_max_vel_trs = 40;
  }else {
    ahc_min_vel_trs = AHC_vVehSpdThres_C;
    ahc_max_vel_trs = AHC_vVehSpdThres_C + AHC_vVehSpdThresHys_C;
  }

  sprst = stFogLiFrntFctActvSts != FogLi_Off || stFogLiReFctActvSts != FogLi_Off || stFrntWiperSts == FrntWpr_SpdHigh
          || stActGear == ActGear_Reverse
          || SpdSprHysis.Hysteresis_LHO_RLO(kphVehSpd, ahc_min_vel_trs, ahc_max_vel_trs)
          || illuminance_supress;
  // std::cout<<"kphVehSpd is "<< kphVehSpd <<std::endl;
  // std::cout<<"AHC_vVehSpdThres_C is "<< AHC_vVehSpdThres_C <<std::endl;
  // std::cout<<"AHC_vVehSpdThres_C + AHC_vVehSpdThresHys_C is "<< AHC_vVehSpdThres_C + AHC_vVehSpdThresHys_C
  // <<std::endl;

  ahcsm.Set_HighBeamSprsn(sprst);
  // std::cout<<"sprfim is "<< (int)sprfim <<std::endl;
  // std::cout<<"sprst is "<< (int)sprst <<std::endl;
  // std::cout<<"stFogLiFrntFctActvSts is "<< (int)stFogLiFrntFctActvSts <<std::endl;
  // std::cout<<"stFogLiReFctActvSts is "<< (int)stFogLiReFctActvSts <<std::endl;
  // std::cout<<"stFrntWiperSts is "<< (int)stFrntWiperSts <<std::endl;
  // std::cout<<"stActGear is "<< (int)stActGear <<std::endl;
  // std::cout<<"SpdSprHysis.Hysteresis_LHO_RLO is "<< SpdSprHysis.Hysteresis_LHO_RLO(kphVehSpd, AHC_vVehSpdThres_C,
  // AHC_vVehSpdThres_C + AHC_vVehSpdThresHys_C) <<std::endl;
}

static void ahc_sys_cam_blk(AHCSM& ahcsm) {

  int camblk = 0;

  camblk = flgAdcInternalFault + (flgEq4NonRecoverableFault << 1) + (flgEq4RecoverableFault << 2) + (flgCamBlock << 3)
           + (flgFSTsrOutOfCalibMode << 4) + (flgFsBlurredImage << 5) + (flgRain << 6) + (flgFsFoggySpots << 7)
           + (flgFsOutOfFucos << 8) + (flgFsFrozenWindshield << 9) + (flgEq4Coredump << 10);

  ahcsm.Set_CamBlk(camblk);
}

static void ahc_sys_permanent_fail(AHCSM& ahcsm) {
  int permfail = 0;
  ahcsm.Set_SysPermFail(permfail);
}

static void ahc_sys_beam_change_supression(AHCSM& ahcsm) {

  int    bmchgspr      = 0;
  double absdpsyawrate = 0.0;

  absdpsyawrate = std::fabs(dphiYawRate) * M_PI / 180;

  // double yawratethrhys =
  //   lookup1D_binlcapw(absdpsyawrate, (&(AHC_kphYawrateThrHys_x[0])), (&(AHC_dphiYawrateThresHys_cur[0])), 7U);

  bmchgspr = flgAutoBrkgActv || flgVDCActv || flgABSActv || absdpsyawrate > AHC_dphiYawrateThres_C
             || std::abs(gVehLatAcc) > AHC_aVehLatAccThres_C;

  // bmchgspr = flgAutoBrkgActv
  //     ||  flgVDCActv
  //     ||  flgABSActv
  //     ||  YawRateHysis.Hysteresis_LLO_RHO(absdpsyawrate,
  //         //AHC_dphiYawrateThres_C - AHC_dphiYawrateThresHys_C,
  //         AHC_dphiYawrateThres_C - yawratethrhys,
  //         AHC_dphiYawrateThres_C)
  //     ||  LatAccHysis.Hysteresis_LLO_RHO(std::abs(gVehLatAcc),
  //         AHC_aVehLatAccThres_C-AHC_aVehLatAccThresHys_C,
  //         AHC_aVehLatAccThres_C);

  ahcsm.Set_BeamChngSprsn(bmchgspr);
}

static void ahc_sys_env_need_high_beam(AHCSM& ahcsm) {
  bool ndhibm = nio::ad::fctapp::VISION_FLG.HLB_decision && flgDrvReqAHC;
  // std::cout <<"ndhibm is " << (int)ndhibm <<std::endl;
  // std::cout << "nio::ad::fctapp::VISION_FLG.HLB_decision is " << (int)nio::ad::fctapp::VISION_FLG.HLB_decision <<
  // std::endl; std::cout <<"flgDrvReqAHC is " << (int)flgDrvReqAHC <<std::endl;

  ahcsm.Set_EnvNeedHiBm(ndhibm);
}

void ahc_sys_signal_process(void) {

  ahc_sys_switch_status(AHCSm);
  ahc_sys_driver_present(AHCSm);
  ahc_sys_temp_error(AHCSm);
  ahc_sys_high_beam_supression(AHCSm);
  ahc_sys_cam_blk(AHCSm);
  ahc_sys_permanent_fail(AHCSm);
  ahc_sys_beam_change_supression(AHCSm);
  ahc_sys_env_need_high_beam(AHCSm);
}
