#include "ahc_proc.h"
#include "ahc_main.h"
#include "ahc_param.h"
#include "fct_input_adapter.h"

namespace nio {
namespace ad {
namespace fctapp {


void ahc_proc(const proto::CarInfo& veh_info,
              const nio::ad::messages::IlluminanceFeatures& illuminance_info) {
  ahc_input(veh_info, illuminance_info);
  ahc_main();
}

void ahc_input(const proto::CarInfo& veh_info,
               const nio::ad::messages::IlluminanceFeatures& illuminance_info) {
  stVehSt   = static_cast<VehState_e>(veh_info.np_vehicle_body_info().vehstatus().vehstate());
  kphVehSpd = veh_info.np_vehicle_dyn_info().vehspd().vehspdkph();
  if (2 <= veh_info.np_vehicle_body_info().lightsts().foglifctactvsts_size()){
    stFogLiFrntFctActvSts =
      static_cast<FogLiSts_e>(veh_info.np_vehicle_body_info().lightsts().foglifctactvsts(0));  // FogLiSts_e::FogLi_Off;
    stFogLiReFctActvSts =
      static_cast<FogLiSts_e>(veh_info.np_vehicle_body_info().lightsts().foglifctactvsts(1));  // FogLiSts_e::FogLi_Off;
  }
  stFrntWiperSts =
    static_cast<FrntWiprSts_e>(veh_info.np_vehicle_body_info().wippersts().frntwiprsts());   // FrntWiprSts_e::FrntWpr_Off;
  stActGear     = static_cast<ActGear_e>(veh_info.np_powertrain_info().gear().actgear());       // ActGear_e::ActGear_Neutral;
  stMainLghtSet = static_cast<MainLightSet_e>(veh_info.np_vehicle_body_info().mailiset());   // MainLightSet_e::MnLght_Off;
  stSetHMA      = static_cast<SetHMA_e>(veh_info.np_drv_info().adfuncfg().sethma());  // SetHMA_e::SetHMA_Off;
  flgDrvReqAHC  = veh_info.np_drv_info().hibeamscmcmd() == nio::ad::messages::DrvInfo_HiBmCmdType_e_HiBmCmd_High;
  // Taowen 20210701: proto is not updating this value, short term solution
  // flgDrvReqAHC = 1;
  // flgAutoBrkgActv = veh_info.brksys();
  flgVDCActv      = veh_info.np_brake_info().brkfunst().vdcactv();
  flgAutoBrkgActv = veh_info.np_vehicle_ctrl_info().lngctrlif().autobrkgactv();
  flgABSActv      = veh_info.np_brake_info().brkfunst().absactv();
  gVehLatAcc      = veh_info.np_vehicle_dyn_info().latsaeag() * -1;
  dphiYawRate     = veh_info.np_vehicle_dyn_info().yawratesaedps() * -1;
  AHC_illuminance = illuminance_info.illum().avg_illuminance();
}
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
