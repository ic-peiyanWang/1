#ifndef AHC_TYPE_H
#define AHC_TYPE_H

#define GTEST
    typedef enum {
        SetHMA_Off = 0,
        SetHMA_On  = 1,
        SetHMA_Reserved = 2,
        SetHMA_Invalid = 3,
    }SetHMA_e;

    typedef enum{
        MnLght_Off = 0,
        MnLght_PositionLight = 1,
        MnLght_LowBeam = 2,
        MnLght_Auto = 3,
        MnLght_Reserved4 = 4,
        MnLght_Reserved5 = 5,
        MnLght_Reserved6 = 6,
        MnLght_Invalid = 7,
    }MainLightSet_e;

    typedef enum{
        HiBeam_Off  = 0,
        HiBeam_On   = 1,
        HiBeam_Reserved = 2,
        HiBeam_Invalid = 3,
    }HiBeamSts_e;

     typedef enum{
        LowBeam_Off  = 0,
        LowBeam_On   = 1,
        LowBeam_Reserved = 2,
        LowBeam_Invalid = 3,
    }LowBeamSts_e;

    typedef enum{
        FrntWpr_Off = 0,
        FrntWpr_SpdLow = 1,
        FrntWpr_SpdHigh = 2,
        FrntWpr_Reserved3 = 3,
        FrntWpr_Reserved4 = 4,
        FrntWpr_Reserved5 = 5,
        FrntWpr_Reserved6 = 6,
        FrntWpr_Invalid = 7,
    }FrntWiprSts_e;

    typedef enum{
        TrnIndcrLi_Off = 0,
        TrnIndcrLi_On  = 1,
        TrnIndcrLi_Reserved = 2,
        TrnIndcrLi_Invalid = 3,
    }TrnIndcrLiSts_e;

    typedef enum{
        BeamPushSwt_Default = 0,
        BeamPushSwt_Flash = 1,
        BeamPushSwt_LowOrHigh = 2,
        BeamPushSwt_Invalid = 3,
    }HiLowBeamPushSwtSts_e;

    typedef enum{
        TurnIndcrSwt_Default = 0,
        TurnIndcrSwt_LeftOn  = 1,
        TurnIndcrSwt_RightOn  = 2,
        TurnIndcrSwt_Invalid  = 3,
    }TurnIndcrSwtSts_e;

    typedef enum{
        FogLiSCM_Off = 0,
        FogLiSCM_RearOnly = 1,
        FogLiSCM_FrntRear = 2,
        FogLiSCM_Invalid = 3,
    }FogLiSCMCmd_e;

    typedef enum{
        ActGear_Neutral = 0,
        ActGear_Drive = 1,
        ActGear_Reverse = 2,
        ActGear_Parking = 3,
        ActGear_Rsrvd4 = 4,
        ActGear_Rsrvd5 = 5,
        ActGear_Rsrvd6 = 6,
        ActGear_Invalid = 7,
    }ActGear_e;

    typedef enum{
        YawRate_valid = 0,
        YawRate_Invalid = 1,
        YawRate_Reserved = 2,
        YawRate_Initializing = 3,
    }YawRateValSts_e;

    typedef enum{
        LgtA_valid = 0,
        LgtA_Invalid = 1,
        LgtA_Reserved = 2,
        LgtA_Initializing = 3,
    }LgtAValSts_e;

    typedef enum{
        LatA_valid = 0,
        LatA_Invalid = 1,
        LatA_Reserved = 2,
        LatA_Initializing = 3,
    }LatAValSts_e;

    typedef enum{
        Valid = 0,
        Invalid = 1,
    }ZeroAsValidIf_e;

    typedef enum{
        VehSt_Parked = 0,
        VehSt_DrvrPrsnt = 1,
        VehSt_Driving = 2,
        VehSt_SwUpdate = 3,
        VehSt_Rsrvd4 = 4,
        VehSt_Rsrvd5 = 5,
        VehSt_Rsrvd6 = 6,
        VehSt_Rsrvd7 = 7,
        VehSt_Rsrvd8 = 8,
        VehSt_Rsrvd9 = 9,
        VehSt_Rsrvd10 = 10,
        VehSt_Rsrvd11 = 11,
        VehSt_Rsrvd12 = 12,
        VehSt_Rsrvd13 = 13,
        VehSt_Rsrvd14 = 14,
        VehSt_Invalid = 15,
    }VehState_e;

    //HiBeamSCMCmd

    typedef enum{
        HiBeamCmd_Low  = 0,
        HiBeamCmd_High  = 1,
        HiBeamCmd_Reserved  = 2,
        HiBeamCmd_Invalid  = 3,
    }HiBeamSCMCmd_e;

    typedef enum{
        FogLi_Off = 0,
        FogLi_On = 1,
        FogLi_Reserved = 2,
        FogLi_Invalid = 3,
    }FogLiSts_e;

class AHCSM{

    public:
    enum class AHCSysSt_e{
    //  0 OFF:            HMA Off
    //  1 PASSIVE:        HMA passive
    //  2 ACTIVE:         HMA active
    //  3 TEMP_FAIL:      HMA not available, temporary failure
    //  4 CAM_BLK:        HMA not avaialble, camera blocked
    //  5 PERMANENT_FAIL: HMA not available, permanent failure
    //  6 reserved
    //  7 Invalid
        OFF = 0,
        PASSIVE = 1,
        ACTIVE = 2,
        TEMP_FAIL = 3,
        CAM_BLK = 4,
        PERMANENT_FAIL = 5,
        reserved = 6,
        Invalid = 7,
    };

    enum class AHCSt_e{
    //  0 OFF:            HMA Off
    //  1 PASSIVE:        HMA passive
    //  2 ACTIVE:         HMA active
    //  3 TEMP_FAIL:      HMA not available, temporary failure
    //  4 CAM_BLK:        HMA not avaialble, camera blocked
    //  5 PERMANENT_FAIL: HMA not available, permanent failure
    //  7 Invalid
        OFF = 0,
        PASSIVE = 1,
        ACTIVE = 2,
        TEMP_FAIL = 3,
        CAM_BLK = 4,
        PERMANENT_FAIL = 5,
        STANDBY= 6,
        Invalid = 7,
    };

    private:
        AHCSt_e     AHCSts;
    	AHCSysSt_e	AHCSysSt;
        double      PsvTimer;
        bool  flgBeamAvl;
    	bool  flgAHCOn;
    	bool  flgDrvPrsnt;
    	bool  flgSysFail;
    	bool  flgHiBmSpr;
    	bool  flgBmChngSpr;
    	bool  flgEnvNeedHiBm;
        bool  flgCamBlk;
        bool  flgTempFail;
        bool  flgPermFail;
        bool  flgAHCFail;

    private:
    	bool  flgHiBmReq;
    public:
    	void  Set_SwitchedON(bool);
    	void  Set_DrvPrsnt(bool);
	    void  Set_HighBeamSprsn(bool);
	    void  Set_BeamChngSprsn(bool);
    	void  Set_EnvNeedHiBm(bool);
        void  Set_CamBlk(bool);
        void  Set_SysTempFail(bool);
        void  Set_SysPermFail(bool);
        void  Set_DrvReqAHC(bool);
    public:
	    bool  Get_SwitchedON();
	    bool  Get_DrvPrsnt();
	    bool  Get_HighBeamSprsn();
    	bool  Get_BeamChngSprsn();
	    bool  Get_EnvNeedHiBm();
        bool  Get_CamBlk();
        bool  Get_SysTempFail();
        bool  Get_SysPermFail();
        bool  Get_SystemFail();
	    void  UpdateStateMachine(void);
        AHCSysSt_e Get_AutoHiBeamSysSts(void) ;
        AHCSt_e Get_AutoHiBeamSts(void);
        bool  Get_AutoHiBeamReq(void) ;
        bool  Get_DrvReqAHC(void);
    public:
	AHCSM();
	~AHCSM();
};


class AHC
{

    public:
	const double sampletime = 0.05;
        /**/
    public:
        /*output*/
       // void ahc_main(void);
        AHC();
        ~AHC();
};
extern AHCSM AHCSm;
extern AHC   AHCFun;
#endif
