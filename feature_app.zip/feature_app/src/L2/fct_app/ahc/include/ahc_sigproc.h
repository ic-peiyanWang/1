#ifndef AHC_SIGPROC_H
#define AHC_SIGPROC_H
extern void ahc_sys_signal_process(void);
#endif
