#ifndef AHC_MAIN_H
#define AHC_MAIN_H
typedef enum { AHC_OFF = 0, AHC_Loaded, AHC_Checking, AHC_Standby, AHC_Running } FAMSts_e;
extern void     ahc_init(void);
extern void     ahc_main(void);
extern FAMSts_e AHC_FAMSts;
#endif