#ifndef AHC_PROC_H
#define AHC_PROC_H
#include "fct_input_adapter.h"
namespace nio {
namespace ad {
namespace fctapp {

extern void ahc_proc(const proto::CarInfo& veh_info,
                     const nio::ad::messages::IlluminanceFeatures& illuminance_info);
extern void ahc_input(const proto::CarInfo& veh_info,
                      const nio::ad::messages::IlluminanceFeatures& illuminance_info);
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
#endif