#ifndef AHC_PARAM_H
#define AHC_PARAM_H
#include "ahc_type.h"
#include "asimov_compiler.h"
#include "fim_encoder.h"
// #define pi 3.1415926
extern double         AHC_vVehSpdThres_C;
extern double         AHC_vVehSpdThresHys_C;
extern double         AHC_dphiYawrateThres_C;
extern double         AHC_dphiYawrateThresHys_C;
extern double         AHC_aVehLatAccThres_C;
extern double         AHC_aVehLatAccThresHys_C;
extern VehState_e     stVehSt;
extern double         kphVehSpd;
extern bool           flgSetHMAInvld;
extern bool           flgMainLghtSetInvld;
extern bool           flgHiBeamInvld;
extern bool           flgLowBeamInvld;
extern bool           flgFrntWiperInvld;
extern bool           flgHiLowBeamSwtInvld;
extern bool           flgHiBeamCmdInvld;
extern FogLiSts_e     stFogLiFrntFctActvSts;
extern FogLiSts_e     stFogLiReFctActvSts;
extern FrntWiprSts_e  stFrntWiperSts;
extern ActGear_e      stActGear;
extern MainLightSet_e stMainLghtSet;
extern SetHMA_e       stSetHMA;
extern float          AHC_illuminance;
extern bool           illuminance_supress;
extern uint8_t        AHC_supress_age;
extern uint8_t        AHC_recover_age;
extern bool           flgFcmAHBC;
extern bool           flgGearInvld;
extern bool           flgYawrateInvld;
extern bool           flgLatAccValInvld;
extern bool           flgVehSpdInvld;
extern bool           flgVehStInld;
extern bool           flgACMLossCommFault;
extern bool           flgBcuLossCommFault;
extern bool           flgCgwLossCommFault;
extern bool           flgScmLossCommFault;
extern bool           flgCdcLossCommFault;
extern bool           flgBcmLossCommFault;
extern bool           flgVcuLossCommFault;
extern bool           flgCdcLossCommAdasFault;
extern bool           flgAdcInternalFault;
extern bool           flgEq4NonRecoverableFault;
extern bool           flgEq4RecoverableFault;
extern bool           flgCamBlock;
extern bool           flgFSTsrOutOfCalibMode;
extern bool           flgFsBlurredImage;
extern bool           flgRain;
extern bool           flgFsFoggySpots;
extern bool           flgFsOutOfFucos;
extern bool           flgFsFrozenWindshield;
extern bool           flgEq4Coredump;
extern double         dphiYawRate;
extern bool           flgAutoBrkgActv;
extern bool           flgVDCActv;
extern bool           flgABSActv;
extern double         gVehLatAcc;
extern unsigned char  AHC_stHiBeamAssistSts_mp;
extern double         AHC_dphiYawrateThresHys_cur[];
extern double         AHC_kphYawrateThrHys_x[];
extern bool           flgDrvReqAHC;
extern double         AHC_illuminance_highThr;
extern double         AHC_illuminance_lowThr;
extern uint8_t        AHC_supress_Thr;
extern uint8_t        AHC_recover_Thr;
extern uint8_t        gAHCFaultFimByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t        gAHCPassiveFimByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t        kGlobAHCPassiveMskByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t        kGlobAHCFaultMskByte[DIAG_FIM_MAX_MASK_NUM];

#endif
