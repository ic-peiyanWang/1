#include <gtest/gtest.h>
#include "ahc_type.h"
#include "ahc_param.h"
#include "ahc_sigproc.h"

//TEST(testcasename, testname) no _ is allowed in the two arguments.
//{
//}

TEST(testcasename, testname)
{
    flgSetHMAInvld = true;
    ahc_sys_signal_process();
    EXPECT_EQ(false, AHCSm.Get_SwitchedON());
    EXPECT_EQ(false, AHCSm.Get_DrvPrsnt());
    EXPECT_EQ(true, AHCSm.Get_HighBeamSprsn());
    EXPECT_EQ(false, AHCSm.Get_BeamChngSprsn());
    EXPECT_EQ(false, AHCSm.Get_EnvNeedHiBm());
    EXPECT_EQ(false, AHCSm.Get_CamBlk());
    EXPECT_EQ(true, AHCSm.Get_SysTempFail());
    EXPECT_EQ(false, AHCSm.Get_SysPermFail());
}

TEST(ahcSwOn, on)
{
    ahc_sys_signal_process();
    EXPECT_EQ(false, AHCSm.Get_SwitchedON());
    stSetHMA = SetHMA_On;
    flgFcmAHBC = true;
    stMainLghtSet = MainLightSet_e::MnLght_Auto;
    ahc_sys_signal_process();
    EXPECT_EQ(true, AHCSm.Get_SwitchedON());
}

TEST(ahcSwOn, off)
{
    stSetHMA = SetHMA_On;
    flgFcmAHBC = true;
    stMainLghtSet = MainLightSet_e::MnLght_Auto;
    ahc_sys_signal_process();
    EXPECT_EQ(true, AHCSm.Get_SwitchedON());
    flgFcmAHBC = false;
    ahc_sys_signal_process();
    EXPECT_EQ(false, AHCSm.Get_SwitchedON());

}

TEST(ahcdrvprsnt, on)
{
    ahc_sys_signal_process();
    EXPECT_EQ(false, AHCSm.Get_DrvPrsnt());
    stVehSt = VehSt_DrvrPrsnt;
    ahc_sys_signal_process();
    EXPECT_EQ(true, AHCSm.Get_DrvPrsnt());
}

TEST(ahcdrvprsnt, off)
{
    stVehSt = VehSt_DrvrPrsnt;
    ahc_sys_signal_process();
    EXPECT_EQ(true, AHCSm.Get_DrvPrsnt());
    stVehSt = VehSt_Parked;
    ahc_sys_signal_process();
    EXPECT_EQ(false, AHCSm.Get_DrvPrsnt());
}
#if 1
int main(int argc, char* argv[])
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
#endif
