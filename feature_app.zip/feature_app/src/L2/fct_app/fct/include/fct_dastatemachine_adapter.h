#ifndef _FCT_DASTATEMACHINE_ADAPTER_
#define _FCT_DASTATEMACHINE_ADAPTER_

#include <mutex>
#include "common/ncyber/ncyber.h"
#include "diagnostic/include/fct_diag_interface.h"
#include "feature_autogen/ids_mil/include/ids_mil.h"
#include "feature_autogen/ids_mil/include/ids_mil_types.h"
#include "global_localization_type.h"
#include "hd_link_type.h"
#include "niodds/application/application.h"
#include "nop_power_taskstate.h"
#include "veh_drv_type.h"

namespace nio::planner {
class IOAdapter;
}
namespace nio {
namespace ad {
namespace fctapp {

enum class FeatureFuncSts_e : uint8_t {  // status 	of function
  OFF      = 0,                          // app not loaded // not in BL07X
  LOADED   = 1,                          // app loaded, but not doing anything
  CHECKING = 2,                          // app loaded and conducting self-checks
  STANDBY  = 3,                          // app loaded, no inhibit, within ODD
  RUNNING  = 4,                          // function running
};
enum NOPFunctionSts_e : uint8_t {
  REQ_OFF      = 0,
  REQ_CHECKING = 1,
  REQ_STANDBY  = 2,
  REQ_RUNNING  = 3,
};
enum PSPFunctionSts_e : uint8_t {
  REQ_PSP_OFF      = 0,
  REQ_PSP_CHECKING = 1,
  REQ_PSP_STANDBY  = 2,
  REQ_PSP_RUNNING  = 3,
};
enum class DaNadSts_e : uint8_t {
  MdOff             = 1,
  MdPassive         = 2,
  MdRdy             = 3,
  MdAccStby         = 4,
  MdPilotStby       = 5,
  DaAccActv         = 6,
  DaActvLongLat     = 7,
  DaActvLong        = 8,
  DaNOPActv         = 9,
  DaNADEngaged      = 10,  // NAD engaged
  DaNADTrsnDmd      = 11,  // NAD Transition Demand
  Da_NADEngagedBETA = 12,  // NAD engaged BETA
};

enum class NOPStatus_e : uint8_t {
  NOPStatus_NotAvaliable = 0,
  NOPStatus_Avaliable    = 1,
  NOPStatus_Reserved     = 2,
  NOPStatus_RequestPSP   = 3,
  NOPStatus_RequestUrban = 4,
};

enum class UrbanStatus_e : uint8_t {
  UrbanStatus_NotAvaliable = 0,
  UrbanStatus_Avaliable    = 1,
  UrbanStatus_RequestNOP   = 2,
  UrbanStatus_RequestPSP   = 3,
};

enum class PSPSts_e : uint8_t {
  PSPSts_NotAvailable   = 0,
  PSPSts_Available      = 1,
  PSPSts_ReqEngageNOP   = 2,
  PSPSts_Reserved       = 3,
  PSPSts_ReqEngageUrban = 4,
};

enum class DAiAccNOPPSPNADAvl_e : uint8_t {
  DA_NOTAVAIABLE = 0,
  DA_AVAIABLE = 1,
  DA_ENGAGED = 2,
  DA_ACTIVATEFAILED = 3,
};

enum class DAPilotAvl_e : uint8_t {
  DA_PILOT_NOTAVAIABLE = 0,
  DA_PILOT_AVAIABLE_LONGONLY = 1,
  DA_PILOT_AVAIABLE_LONGLAT = 2,
  DA_PILOT_ENGAGED_LONGONLY = 3,
  DA_PILOT_ENGAGED_LONGLAT = 4,
  DA_PILOT_ACTIVATEFAILED_LONGONLY = 5,
  DA_PILOT_ACTIVATEFAILED_LONGLAT = 6,
  DA_PILOT_RESERVED = 7,
};

class DAStateMachineAdapter {
 public:
  DAStateMachineAdapter();
  ~DAStateMachineAdapter();

  bool fct_getNopActvTrigger() const { return nop_activation_trigger_; }
  bool fct_getNopDeactvTrigger() const { return nop_deactivation_trigger_; }
  uint16_t fct_getNopTriggerFim() const { return m_uBitNOPDebug; }
  uint16_t fct_getUrbanDebugFim() const { return m_uBitUrbanDebug; }
  NOPStatus_e fct_getNopStatus() const {return m_nop_status; }
  UrbanStatus_e fct_getUrbanStatus() const {return m_urban_status; }
  void setioadapter(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fct_procNopTrigger(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out,const VEHDRVR& vehdrvrptr,
                          const std::shared_ptr<planner::IOAdapter>& ioadapter, const GLOBALLOCALIZATION& global_locali,
                          const NopPowerPilotState& power_pilot_state);
  void fct_procUrbanStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out,const VEHDRVR& vehdrvrptr,
                           const std::shared_ptr<planner::IOAdapter>& ioadapter,
                           const GLOBALLOCALIZATION& global_locali, const NopPowerPilotState& power_pilot_state);
  void fct_outputNopFuncStatus(std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fct_outputPSPFuncStatus(std::shared_ptr<planner::IOAdapter>& ioadapter);
  void proc_nop_funcStatus(const MainState_outputs_T& mainstate,const DASM_Info& da_state_out,
                           std::shared_ptr<planner::IOAdapter>& ioadapter);
  void proc_psp_funcStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out);
  void processDANBCAvlStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out,
                             const VEHDRVR& vehdrvrptr, const FUNCARB& funcarb);

  void setPSPStatus(const std::vector<HDLINK>& HdLink, const GLOBALLOCALIZATION& global_locali,
                    const NopPowerPilotState& power_pilot_state, const std::shared_ptr<planner::IOAdapter>& ioadapter);

  bool getnopsubscribeavail() const { return (is_subscribtion_nop || is_subscribtion_nad); }

  PSPSts_e getPSPStatus() const { return psp_status; }

  bool getnpactvationprevnt() const { return np_activation_prevention; }

  int32_t getIsInMapArea() const { return m_is_in_map_area; }

  PSPSts_e getPSPStatusDaWti() const { return psp_status_dawti; }

  bool getFlagNopTransToPSPFailed(const std::shared_ptr<planner::IOAdapter>& ioadapter,
                                  const GLOBALLOCALIZATION&                  global_locali);

  TaskState_e getPSPTaskStatus() const { return m_pspTaskStatus; }

  uint8_t getPSPTaskResult() const { return m_pspTaskResult; }

  PriorityRoadClass_e getPriorityRoadClacc() const { return m_priorityRoadClass; }

  DAiAccNOPPSPNADAvl_e getDAiACCAvl() const {return da_iacc_avl; }
  DAiAccNOPPSPNADAvl_e getDANOPAvl() const {return da_nop_avl; }
  DAiAccNOPPSPNADAvl_e getDAPSPAvl() const {return da_psp_avl; }
  DAiAccNOPPSPNADAvl_e getDANADAvl() const {return da_nad_avl; }
  DAPilotAvl_e getDAPilotAvl() const {return da_pilot_avl; }

 private:
  bool                 nop_activation_trigger_      = false;
  bool                 nop_deactivation_trigger_    = false;
  bool                 is_nop_ctrlCmd_lossCom       = true;
  bool                 is_subscribtion_nop          = false;
  bool                 is_nop_scenemgmt_ok          = false;
  bool                 is_nop_control               = false;
  bool                 nop_takeover_req             = false;
  bool                 np_activation_prevention     = false;
  unsigned int         m_daInhibit                  = 0;
  int                  m_strAssType                 = 0;
  int                  m_daCurvSpdAss               = 0;
  int                  m_switchDA_NOP               = 0;
  NOPFunctionSts_e     nop_function_sts_            = NOPFunctionSts_e::REQ_OFF;
  PSPFunctionSts_e     psp_function_sts_            = PSPFunctionSts_e::REQ_PSP_OFF;
  FeatureFuncSts_e     m_da_funcSts                 = FeatureFuncSts_e::OFF;
  DaNadSts_e           m_danadsts                   = DaNadSts_e::MdOff;
  uint16_t             m_uBitNOPDebug               = 0;
  uint16_t             m_uBitUrbanDebug             = 0;
  NOPStatus_e          m_nop_status                 = NOPStatus_e::NOPStatus_NotAvaliable;
  UrbanStatus_e        m_urban_status               = UrbanStatus_e::UrbanStatus_NotAvaliable;
  PSPSts_e             psp_status                   = PSPSts_e::PSPSts_NotAvailable;
  uint64_t             m_currLinkId                 = 0;
  PriorityRoadClass_e  m_priorityRoadClass          = PriorityRoadClass_e::MOTORWAY;
  bool                 m_isInMapArea                = false;
  TaskState_e          m_pspTaskStatus              = TaskState_e::FINISH;
  int32_t              m_is_in_map_area             = 0;
  PSPSts_e             psp_status_dawti             = PSPSts_e::PSPSts_NotAvailable;
  bool                 is_planner_sts               = false;
  bool                 is_planner_sts_last          = false;
  bool                 last_planner_sts             = false;
  int                  planner_sts_activate_timer   = 0;
  int                  planner_sts_deactivate_timer = 0;
  bool                 is_canbus_sts                = false;
  bool                 flag_nop_status_standby      = false;
  bool                 is_local_route_end           = false;
  uint8_t              m_pspTaskResult              = 0;
  bool                 is_subscribtion_nad          = false;
  uint8_t              sales_region                 = 0;
  DAiAccNOPPSPNADAvl_e da_iacc_avl                  = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  DAiAccNOPPSPNADAvl_e da_nop_avl                   = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  DAiAccNOPPSPNADAvl_e da_psp_avl                   = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  DAiAccNOPPSPNADAvl_e da_nad_avl                   = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  DAPilotAvl_e         da_pilot_avl                 = DAPilotAvl_e::DA_PILOT_NOTAVAIABLE;

  // planner io-adapter
  std::shared_ptr<planner::IOAdapter> io_adapter_;

  void setPSPTaskStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void setGlobaLocalizationInfo(const GLOBALLOCALIZATION& global_locali);
  void setDAMain_Attributes(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out);
  void setVehInfoConfig(const VEHDRVR& vehdrvrptr);
  void setNopRelatedConditions(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void setNopPlannerSts(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_nop_status_avaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_nop_status_unavaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_nop_requestToPSP(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_nop_requestToUrban(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_urban_requestToPSP(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_urban_requestToNOP(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_urban_status_avaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool proc_urban_status_unavaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter);

  void DebugInfoForNOPStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void DebugInfoForUrbanStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter);
};

extern DAStateMachineAdapter da_statemachine_adapter;
extern uint16_t uBitNopStatusTriggerSup;
extern uint16_t uBitUrbanStatusTrigggerSup;
extern bool flagNopStatusActvTigger;
extern bool flagNopStatusDectvTigger;
extern void fct_fillNopStatus_debug_out(DAStateMachineAdapter* dastatemachine_adapter, uint16_t* uBit, bool* avtvflg,
                                        bool* deactvflg);
extern void fct_fillUrbanStatus_debug_out(DAStateMachineAdapter* dastatemachine_adapter, uint16_t* uBit);
extern uint16_t priority_road_class_mp;
extern uint64_t curr_link_id_mp;
extern int32_t  is_in_map_area_mp;
extern uint16_t nop_task_state_mp;
extern uint8_t nop_task_result_mp;
extern uint8_t  psp_status_mp;
extern uint8_t  np_activation_prevention_mp;
extern uint8_t  nop_status_mp;
extern bool     is_planner_sts_mp;
extern bool     is_nop_control_mp;
extern uint8_t  psp_status_dawti_mp;

}  // namespace fctapp
}  // namespace ad
}  // namespace nio

#endif
