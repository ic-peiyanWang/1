#include "common/diagnostic/fim/fim_can_feature.pb.h"
#include "fct_input_adapter.h"
#include "np/apps/fct_out.pb.h"

using nio::ad::messages::FctOut;

namespace nio {
namespace ad {
namespace fctapp {

extern void fct_edr_processing(const VEHPARAM* veh_param_ptr, const NopVehicleOut* nop_vehicleout_ptr, FctOut& fct_out);
extern void fct_edr_default(FctOut& fct_out);

}  // namespace fctapp
}  // namespace ad
}  // namespace nio