#pragma once
#include "common/ncyber/ncyber.h"
#include "nlohmann/json.hpp"
#include "common/proto/car_state.pb.h"
#include "gflags/gflags.h"
#include "fct_input_adapter.h"
#include <unordered_map>
#include <map>
#include <vector>

namespace nio {
namespace ad {
namespace fctapp {

DECLARE_string(labelling_input_json_file);

enum class ModeType { LANE_KEEP = 0, LANE_CHANGE, LANE_MERGE, MAX_INDEX };

enum class LabelLaneChangeType { LEFT_LANE_CHANGE_SAFE = 0, RIGHT_LANE_CHANGE_SAFE, MAX_INDEX };

struct KeepBadcase {
  int obstacle_id;
  int predict;
  int label;
};

inline LabelLaneChangeType toLabelLaneChangeType(const std::string lane_change_safety_str_type) {
  if (lane_change_safety_str_type == "RIGHT_SAFE") {
    return LabelLaneChangeType::RIGHT_LANE_CHANGE_SAFE;
  } else if (lane_change_safety_str_type == "LEFT_SAFE") {
    return LabelLaneChangeType::LEFT_LANE_CHANGE_SAFE;
  }
  return LabelLaneChangeType::MAX_INDEX;
};

inline ModeType convertModeTypeEnum(const std::string& decision) {
  if (decision == "LaneKeep") {
    return ModeType::LANE_KEEP;

  } else if (decision == "LaneChange") {
    return ModeType::LANE_CHANGE;

  } else if (decision == "LaneMerge") {
    return ModeType::LANE_MERGE;
  }

  AERROR << "some thing wrong while convert decision = " << decision;
  return ModeType::MAX_INDEX;
};

struct DecisionLabel {
  int obstacle_id;
  std::string mode;
  // size 2:long or lat,Yield or other
  std::vector<std::string> decision;
  // size 2:start duration time,end duration time
  std::vector<double> duration_second;
};

struct EgoTriggerLaneChangeLabel {
  std::string lane_change_type;
  std::vector<double> duration_second;
};

struct LabellingFormat {
  std::string clip_id;
  std::string evaluation_id;
  std::vector<DecisionLabel> decision_labels;
  std::vector<EgoTriggerLaneChangeLabel> ego_lane_change_labels;
};

enum class DecisionType {
  YIELD = 0,
  NOT_YIELD = 1,
  LEFT_NUDGE = 4,
  RIGHT_NUDGE = 16,
  IGNORE = 64,
  MAX_INDEX
};

inline DecisionType convertDecisionTypeEnum(const std::string& decision) {
  if (decision == "YIELD") {
    return DecisionType::YIELD;
  } else if (decision == "NOT_YIELD") {
    return DecisionType::NOT_YIELD;
  }
  AERROR << "some thing wrong while convert decision = " << decision;
  return DecisionType::MAX_INDEX;
};


struct LabelDecisionObject {
  int obstacle_id;
  ModeType mode;
  DecisionType decision_type;
  double start_time;
  double end_time;
};

struct LabellingMatchResult {
  std::unordered_map<int, LabelDecisionObject> keep_label_object_dict;
  // keep, <obstacle_id, <predict, label>>
  std::unordered_map<int, int> single_lane_match_label;

  std::unordered_map<int, std::pair<int, int>> keep_obstacle_predict_label_dict;
};

struct DecisionStrategyOutput{
  std::unordered_map<int,DecisionType> decision_strategy_output;
};

/**
 * 1. get json file correspond with clips
 * 2. get proposal result run with clips
 */
class LabellingMatch {
 public:
  LabellingMatch(const std::string& json_file);

  const nlohmann::json& getLabellingResultJson() const { return labelling_result_json_; }

  bool run(const apollo::cyber::Time forward_init_time,
           std::unordered_map<int,DecisionType>& decision_strategy_output);

  bool match(const apollo::cyber::Time forward_init_time,
      LabellingMatchResult* labelling_match_result);

  void calculateBadcase(std::unordered_map<int,DecisionType>& decision_strategy_output,
                        LabellingMatchResult* labelling_match_result);

  const LabellingMatchResult& getLabellingMatchResult() const;

  const std::unordered_multimap<int, LabelDecisionObject>& getLabelObjectDict() const;

  void CalculateCutinID (const int& cutin_index,
                        std::unordered_map<int, DecisionType>* cutin_predict_decision_dict);

  void labelmatch (const int& cutin_result, const apollo::cyber::Time eval_time_in);

 private:

  bool loadLabellingJsonFile(const std::string& json_filepath);

  void matchLaneKeep(const std::unordered_map<int, LabelDecisionObject>& label_object_array,
                     const std::unordered_map<int, DecisionType>& single_lane_proposal,
                     std::unordered_map<int, int>* single_lane_match_label);

  void calculateKeepBadcase(
      const std::unordered_map<int, int>& keep_label_decision_dict,
      std::unordered_map<int, DecisionType>& keep_predict_decision_dict,
      std::unordered_map<int, std::pair<int, int>>* keep_obstacle_predict_label_dict);


 private:
  nio::proto::CarState car_state_;
  apollo::cyber::Time init_time_;
  apollo::cyber::Duration evaluation_case_offset_time_;
  double relative_time_to_start_time_;
  nlohmann::json labelling_result_json_;
  LabellingFormat labelling_format_;

  std::unordered_multimap<int, LabelDecisionObject> label_object_dict_;
  LabellingMatchResult labelling_match_result_;

  std::unordered_map<LabelLaneChangeType, std::pair<double, double>> lane_change_safety_;

};

}  // namespace fctapp
}  // namespace ad
}  // namespace nio