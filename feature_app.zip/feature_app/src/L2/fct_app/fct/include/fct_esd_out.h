#ifndef FCT_ESD_OUT_H
#define FCT_ESD_OUT_H
#include "common/esd/esd_np_feature.pb.h"
#include "np/apps/fct_out.pb.h"
//#include "np/debug/dgb_fct.pb.h"
#include "fct_input_adapter.h"
#include "np/apps/ehy_obf_outputs.pb.h"
#include "topic_status.h"

using nio::ad::messages::EHYObfOutputs;
using nio::ad::messages::esd_np_feature;
using nio::ad::messages::FctOut;

namespace nio {
namespace ad {
namespace fctapp {
struct BSD_LCA_Obj {
  uint64_t obj_id;
  uint64_t obj_type;
};

const uint8_t   TarSize = 12;
extern uint32_t TarIndex[TarSize];
extern uint8_t  TarLevel[TarSize];

const uint8_t      ObjSize = 2;
extern BSD_LCA_Obj bsd_obj[ObjSize];
extern BSD_LCA_Obj lca_obj[ObjSize];

extern void fct_esd_output_processing(FctOut& fct_out);
extern void fct_esd_output_default(FctOut& fct_out);
void        fct_esd_match();
void        fct_esd_arb();

}  // namespace fctapp
}  // namespace ad
}  // namespace nio

#endif