#pragma once
#include "np/apps/fct_da_inhibit.pb.h"
#include "np/apps/fct_out.pb.h"
#include "np/debug/dgb_fct.pb.h"
#include "fct_dastatemachine_adapter.h"
#include "topic_status.h"
#include "fct_input_adapter.h"

namespace nio::planner {
class IOAdapter;
}
namespace nio {
namespace ad {
namespace fctapp {
extern void accsa_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void accct_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void accsc_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void hwasm_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void hwa_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void latctrl_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void mtn_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void ldw_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void me_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void reserved_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out, APP_state_e APP_state);
extern void elkct_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void elkss_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void elkh_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void gonotifier_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void tl_gonotifier_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void fim_debug_proc(nio::ad::messages::FctOut& fctout, nio::ad::messages::debug::FCTDebugOut& fct_debug_out);
extern void dainhibit_debug_proc(std::shared_ptr<nio::ad::messages::FctDaInhibit>& fctdainhibt, APP_state_e APP_state);
extern void fct_debug_output_processing(nio::ad::messages::FctOut&                        fctout,
                                        nio::ad::messages::debug::FCTDebugOut&            fct_debug_out,
                                        std::shared_ptr<nio::ad::messages::FctDaInhibit>& fctdainhibt,
                                        APP_state_e APP_state, std::shared_ptr<planner::IOAdapter>& ioadapter);

extern const float kHeroButtonTrigDelayTime_s;
extern const float kFctStepTime;

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
