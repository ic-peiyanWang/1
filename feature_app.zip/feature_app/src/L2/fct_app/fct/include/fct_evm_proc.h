#include "common/diagnostic/fim/fim_can_feature.pb.h"
#include "fct_input_adapter.h"
#include "np/apps/fct_out.pb.h"

using nio::ad::messages::FctOut;

namespace nio {
namespace ad {
namespace fctapp {

extern void fct_evm_processing(const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                               FctOut&                                                      fctout);
extern void fct_evm_default(FctOut& fct_out);
}  // namespace fctapp
}  // namespace ad
}  // namespace nio