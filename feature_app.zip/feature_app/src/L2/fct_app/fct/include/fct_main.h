#ifndef FCT_MAIN_H
#define FCT_MAIN_H
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "fct_dastatemachine_adapter.h"
#include "fct_debug_out_proc.h"
#include "fct_dlb_out_proc.h"
#include "fct_input_adapter.h"
#include "fct_out_proc.h"
#include "topic_status.h"
#include "common/proto/planner_evaluation.pb.h"
#include "common/ncyber/ncyber.h"
#include "LongCtrl.h"

using nio::ad::messages::FctOut;
using nio::ad::messages::VEH10ms;
using nio::ad::messages::VEH50ms;
using nio::ad::messages::FctDaInhibit;

#if defined(__aarch64_defined__)
#include "fault_tsp_log.h"
#endif
namespace nio::planner {
class IOAdapter;
}
namespace nio {
namespace ad {
namespace fctapp {

#if defined(__aarch64_defined__)
extern DiagTsp_log np_tsp_log;
#endif

#if defined(__aarch64_defined__)
extern DiagTsp_log nop_tsp_log;
#endif

extern void fct_init(void);
extern void fct_main(const VEH10ms& veh10ms, const VEH50ms& veh50ms, FCTInputAdapter* fctinput, FctOut& fctout,
                     FCTDebugOut& fct_debug_out, DAStateMachineAdapter* dastatemachine_adapter,
                     std::shared_ptr<planner::IOAdapter>& ioadapter);
extern void fct_output_fill(FctOut& fctout, FCTDebugOut& fct_debug_out, FCTDlbOut& fct_dlb_out, APP_state_e APP_state,
                            nio::ad::messages::esd_np_feature& esdout, DAStateMachineAdapter* dastatemachine_adapter,
                            std::shared_ptr<FctDaInhibit>& fctdainhibit, std::shared_ptr<planner::IOAdapter>& ioadapter);

extern void np_fault_log(FctOut& fctout, APP_state_e APP_state, FCTDlbOut& fct_dlb_out);
extern void nop_fault_log(FctOut& fctout, APP_state_e APP_state);
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
#endif
