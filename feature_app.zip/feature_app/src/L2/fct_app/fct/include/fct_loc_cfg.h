#pragma once
#ifdef DEBUG
#define FCT_DEBUG
#define FCT_XCP_ENABLED
#endif

// #define OFF_ALL_SAS_OUTPUT
#define ENABLE_BSD_LCA_ESD
#define ENABLE_ACTSHIFT_ESD
// #define RUN_DA_SM_IN_IDSMIL
// #if defined(__x86_Sim_debug_mode_defined__)
//   #define RUN_DA_SM_IN_IDSMIL
// #endif