#ifndef FCT_OUT_PROC_H
#define FCT_OUT_PROC_H
#include "fct_dastatemachine_adapter.h"
#include "fct_diag.h"
#include "fct_esd_out.h"
#include "fct_input_adapter.h"
#include "np/apps/fct_out.pb.h"
#include "np/debug/dgb_fct.pb.h"
#include "topic_status.h"

using nio::ad::messages::FctOut;

namespace nio::planner {
class IOAdapter;
}
namespace nio {
namespace ad {
namespace fctapp {
  extern void fct_output_processing(FctOut& fctout, APP_state_e APP_state,
                                    std::shared_ptr<planner::IOAdapter>& ioadapter);
  extern void fct_nopFuncStatus_output_processing(DAStateMachineAdapter* dastatemachine_adapter, APP_state_e APP_state,
                                                  std::shared_ptr<planner::IOAdapter>& ioadapter);
  extern bool turnon_delay(bool flag, float& timer, float timer_limit);
  extern void fct_user_interface_fill(std::shared_ptr<planner::IOAdapter>& ioadapter, APP_state_e APP_state);
  extern const float kstepTime_s;
  extern const float kplatform_debouceTime_s;
}  // namespace fctapp
}  // namespace ad
}  // namespace nio

#endif
