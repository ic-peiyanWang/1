#ifndef _FCT_USERINTERFACE_PROC
#define _FCT_USERINTERFACE_PROC
#include "fct_input_adapter.h"
#include "ids_mil.h"
namespace nio {
namespace ad {
namespace fctapp {
class FCTNopUserInterface {
 private:
  bool  nop_rain_mode  = false;
  float nop_tau_gap    = 1.0f;
  int   cdc_kphdispspd = 0u;
  void  updateNopRainMode(bool value);
  void  NopTauGap_proc(const uint8_t& taugap_level);

 public:
  FCTNopUserInterface();
  ~FCTNopUserInterface();
  void  fct_nop_user_interface_processing(const VEHDYN& veh_dyn_info, const HWA_outputs_T& hwa_out_info);
  bool  getNopRainMode();
  float getNopTauGap();
  int   getCDCKphDispSpd();
};
extern FCTNopUserInterface fct_nop_user_interface;
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
#endif