#ifndef FCT_IN_PROC_H
#define FCT_IN_PROC_H
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "common/perception/vision_feature_flag.pb.h"
#include "veh_in_type.h"
#include "vision_flg.h"
#include "fct_input_adapter.h"
#include "ids_mil.h"
#include "fct_dastatemachine_adapter.h"

namespace nio{
namespace ad{
namespace fctapp{
extern vision_flg_s VISION_FLG;
extern vision_flg_s VISION_FLG;
extern uint32_t ldw_sensitivity_cnt;
extern uint32_t ldw_sensitivity_input;
extern uint32_t ldw_sensitivity_input_lf;
extern LnAssistSnvty_e ldw_sensitivity_output;
extern bool driver_no_dms_warn;
extern bool driver_change_set;

extern void vision_flag_proc(const nio::ad::messages::Features&);
extern void fct_input_processing(FCTInputAdapter* fctinput, std::shared_ptr<planner::IOAdapter>& ioadapter);
extern void fct_input_nop_trigger(FCTInputAdapter* fctinput, const std::shared_ptr<planner::IOAdapter>& ioadapter);
extern void fct_nop_trigger_processing(DAStateMachineAdapter*               dastatemachine_adapter,
                                       const std::shared_ptr<planner::IOAdapter>& ioadapter);
extern bool update_elk_shadow (VEHPARAM* veh_param);
extern bool update_elk_solidline_enable (VEHPARAM* veh_param);
extern void fill_info_to_comm_proc(std::shared_ptr<planner::IOAdapter>& ioadapter,
                                 const bool& is_vehconf_uploaded);
extern void fill_comm_proc_info(CommonProc_Info* common_proc_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter);
extern void update_lka_sensitivity (VEHDRVR* veh_drvr_ptr);
extern void dms_process_ldw(VEHDRVR* veh_drvr_ptr, DMS* dms_ptr);
extern void update_oncoming_validity (EHYVisionRoad* vision_road_ptr, EHYTSI* ehy_tsi_ptr, VEHDYN* veh_dyn_ptr);

}  // namespace fctapp
}  // namespace ad
}  // namespace nio

#endif
