#pragma once
#include "np/apps/fct_dlb.pb.h"
#include "fct_out_proc.h"
#include "fct_debug_out_proc.h"

#include "fct_diag.h"

using nio::ad::messages::FCTDlbOut;
using nio::ad::messages::FctOut;
using nio::ad::messages::debug::FCTDebugOut;

namespace nio {
namespace ad {
namespace fctapp {
extern void accsa_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void accct_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void accsc_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void hwasm_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void hwa_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void latctrl_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void mtn_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void ldw_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void reserved_proc(FCTDlbOut& fct_dlb_out, APP_state_e APP_state);
extern void elkct_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void elkss_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void elkh_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void gonotifier_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void fim_dlb_proc(FctOut& fctout, FCTDebugOut& fct_debug_out, FCTDlbOut& fct_dlb_out);
extern void appstate_dlb_proc(FCTDlbOut& fct_dlb_out, APP_state_e APP_state);
extern void func_info_dlb_proc(FCTDlbOut& fct_dlb_out);
extern void fct_dlb_output_processing(FctOut& fctout, FCTDebugOut& fct_debug_out, FCTDlbOut& fct_dlb_out, APP_state_e APP_state);
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
