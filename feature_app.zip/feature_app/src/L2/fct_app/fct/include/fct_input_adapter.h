#ifndef FEATURE_FCT_INPUT_ADAPTER_H_
#define FEATURE_FCT_INPUT_ADAPTER_H_

#include "common/cfgmgr/cfg_task_switch.pb.h"
#include "common/diagnostic/fault/fault_lidar_internal.pb.h"
#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_can_feature.pb.h"
#include "common/diagnostic/fim/fim_lidar.pb.h"
#include "common/diagnostic/fim/fim_mcu_system.pb.h"
#include "common/diagnostic/fim/fim_mcuwithsoc_can.pb.h"
#include "common/diagnostic/fim/fim_perception.pb.h"
#include "common/diagnostic/fim/fim_power_rail.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"
#include "common/diagnostic/fault/fault_software.pb.h"
#include "common/dms/adms.pb.h"
#include "common/dms/dms_drive_assist.pb.h"
#include "common/dms/dms_result.pb.h"
#include "common/function_arb/function_arb_out.pb.h"
#include "common/map_engine/sd_map.pb.h"
// #include "common/nop/nop_chassis_control.pb.h"
// #include "common/nop/nop_functionstatus.pb.h"
// #include "common/nop/nop_scenemgmt.pb.h"
// #include "common/nop/nop_speed.pb.h"
#include "common/nop/nop_speedlimitvalue.pb.h"
// #include "common/nop/nop_vehicleout.pb.h"
#include "common/localization/global_localization.pb.h"
#include "common/map_engine/hd_link_info.pb.h"
#include "common/nop/task_scheduler/power_swap_pilot_state.pb.h"
#include "common/esd/esd_np_feature.pb.h"
#include "common/perception/lidar_failsafe.pb.h"
#include "common/perception/perception_objects.pb.h"
#include "common/perception/radar_object.pb.h"
#include "common/perception/side_feature.pb.h"
#include "common/perception/vision_failsafe.pb.h"
#include "common/perception/vision_illumnance_flag.pb.h"
#include "common/perception/vision_road_detection.pb.h"
#include "common/perception/vision_road_sign.pb.h"
#include "common/proto/perception_object.pb.h"
#include "common/platform/mcu_proxy/vehicle/vehicle_variant_code.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "common/vehicle_out/ads.pb.h"
#include "common/proto/car_info.pb.h"
#include "common/proto/dynamic_map.pb.h"
#include "niodds/application/application.h"
#include "np/apps/ehy_evd_outputs.pb.h"
#include "np/apps/ehy_ha_outputs.pb.h"
#include "np/apps/ehy_lpp_outputs.pb.h"
#include "np/apps/ehy_obf_outputs.pb.h"
#include "np/apps/ehy_rme_road_base.pb.h"
#include "np/apps/ehy_rme_road_outputs.pb.h"
#include "np/apps/ehy_target_base.pb.h"
#include "np/apps/ehy_tpp_outputs.pb.h"
#include "np/apps/ehy_tse_outputs.pb.h"
#include "np/apps/ehy_tsi_outputs.pb.h"
#include "np/apps/ehy_tsr_outputs.pb.h"
#include "np/apps/fcts_out.pb.h"
#include "np/apps/road_model_adasmap.pb.h"
#include "common/diagnostic/fim/fault_function.pb.h"
#include "np/apps/parking_outputs.pb.h"
#include "common/platform/mcu_proxy/vehicle/vehicle_adf_fod.pb.h"

#include "aebout_type.h"
#include "brk_sys_type.h"
#include "bsd_sts.h"
#include "cam_fim_type.h"
#include "dms_type.h"
#include "ehy_evd_type.h"
#include "ehy_ha_type.h"
#include "ehy_line_type.h"
#include "ehy_tar_type.h"
#include "func_arb_type.h"
#include "lidar_internalfault_type.h"
#include "sdmap_type.h"
#include "common_proc.h"
#include "str_sys_type.h"
#include "veh_body_type.h"
#include "veh_ctrl_type.h"
#include "veh_drv_type.h"
#include "veh_dyn_type.h"
#include "veh_param.h"
#include "veh_pt_type.h"
#include "veh_suspn_type.h"
#include "veh_upa_type.h"
#include "veh_whl_type.h"
#include "vision_failsafe.h"
#include "vision_road_type.h"
#include "ads_out.h"
#include "da_sm.h"
#include "perception_fim_type.h"
#include "lidar_fim_type.h"

#include "ehy_math/nio_vmath.h"
#include "ehy_obf/object.h"
#include "parameters_configurator.h"

#include <mutex>
#include <vector>
#include "cfgtaskmgr_type.h"
#include "danop_sm.h"
#include "esd_np_feature.h"
#include "fct_dastatemachine_adapter.h"
#include "nop_chassis.h"
#include "nop_functionstatus.h"
#include "nop_power_taskstate.h"
#include "nop_speed.h"
#include "nop_speedlimitvalue.h"
#include "nop_vehicleout.h"
#include "global_localization_type_for_mil.h"
#include "planner/common_data_process/common_data_process.h"
#include "planner/planner_common/data_structure.h"

namespace nio {
namespace planner {
class IOAdapter;
}
namespace ad {
namespace fctapp {
extern VEHDYN              veh_dyn;
extern VEHDRVR             veh_drvr;
extern VEHWHL              veh_whl;
extern VEHPT               veh_pt;
extern VEHCTRL             veh_ctrl;
extern VEHBODY             veh_body;
extern VEHUPA              veh_upa;
extern STRSYS              str_sys;
extern BRKSYS              brk_sys;
extern EHYVisionRoad       vision_road;
extern VisionRoadSign      vision_road_sign;
extern EHYEVD              ehy_evd;
extern EHYHA               ehy_ha;
extern EHYRME              ehy_rme;
extern EHYTPP              ehy_tpp;
extern EHYLPP              ehy_lpp;
extern EHYTSI              ehy_tsi;
extern EHYTSE              ehy_tse;
extern EHYVisionRoad       me_vision_road;
extern DMS                 dms_sys;
extern FUNCARB             func_arb;
extern VisionFailSafe      vision_failsafe;
extern CAMFIMINFO          cam_fim;
extern VEHPARAM            veh_param;
extern BSDSTS              bsd_sts;
extern SDMAP               sdmap_info;
extern NopVehicleOut       nop_vehicleout;
extern NopFunctionstatus   nop_functionstatus;
extern NopSpeed            nop_speed;
extern NopSpeedLimitValue  nop_speedlimitvalue;
extern NopChassisControl   nop_chassisctrl;
extern EHYOBF              ehy_obf;
extern LIDARFAULTINFO      lidar_internalfault;
extern AEBOUT              aebout_info;
extern CfgTskSwt           cfgtaskmgr_info;
extern DANOPSM             danop_sm;
extern GlobalLocation      glb_loc_mil_info;
extern GLOBALLOCALIZATION  global_locali_info;
extern std::vector<HDLINK> hd_link_info;
extern NopPowerPilotState  nop_powerpilotstate;
extern EsdNpFeature        esd_np_feature_info;
extern CommonProc_Info     common_proc_info;
extern ADSOUT              ads_out_info;
extern PERCEPTIONFIMINFO   perception_fim;
extern LIDARFIMINFO        lidar_fim;

extern std::shared_ptr<proto::DynamicMap> dynamic_map;
extern std::shared_ptr<nio::ad::messages::SWFaultInfo> faut_software;
extern bool is_eas_inhibit;
extern apollo::cyber::Time last_fault_function_topic_time;
extern uint64_t last_fault_function_ptp_ts;

extern nio::planner::SasFunctionOut      sas_func_out;
extern DASM_Info                         da_sm_info;

extern std::vector<feature::ehy::Object> fused_obj;

extern uint32_t configure_received_;

extern std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>       fct_radar_data;
extern std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>  fct_vision_objects;
extern std::vector<std::shared_ptr<proto::CarInfo>>                       fct_vehicle_input;
extern std::vector<std::shared_ptr<nio::ad::messages::UPAInfo>>           fct_veh_upa_info;
extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>     fct_road_detection;
extern std::vector<std::shared_ptr<proto::PerceptionObjects>>             fct_fusion_object;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>     fct_ehy_evd;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>      fct_ehy_ha;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>     fct_ehy_lpp;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>     fct_ehy_rme;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>>     fct_ehy_tpp;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>>     fct_ehy_tsi;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>     fct_ehy_tse;
extern std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>     fct_fim_camera_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>        fct_fim_can_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>   fct_fim_sw_info;
extern std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>> fct_fim_can_fea_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>      fct_fim_power_info;
extern std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>> fct_fim_mcu_soc_info;
extern std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>      fct_fim_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::McuSystemFimInfo>>  fct_fim_mcu_sys_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PerceptionFimInfo>> fct_fim_perception_info;
// extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>           fct_me_road_detection;
extern std::vector<std::shared_ptr<nio::ad::messages::DMS_DA>>                  fct_dms_da_info;
extern std::vector<std::shared_ptr<nio::ad::messages::ADMS>>                    fct_adms_info;
extern std::vector<std::shared_ptr<nio::ad::messages::DMS_Result>>              fct_dms_result_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       fct_failsafe_detection;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       fct_failsafe_detection;
extern std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> fct_failsafe_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FunctionRequestBook>>     fct_func_arb_info;
extern std::vector<std::shared_ptr<nio::ad::messages::ParkingOut>>              fct_parkingout_info;
extern std::vector<std::shared_ptr<nio::ad::messages::VehVariantCode>>          fct_var_code_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       fct_failsafe_vision_calib;
extern std::vector<std::shared_ptr<nio::ad::messages::IlluminanceFeatures>>     fct_vision_illuminance_info;
//extern std::vector<std::shared_ptr<nio::ad::messages::SdMap>>                   SdMap_info;
extern std::vector<std::shared_ptr<nio::ad::messages::AdasMap>>                 AdasMap_info;
extern std::vector<std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo>>  fct_lidar_internalfault_info;
// extern std::vector<std::shared_ptr<nio::ad::messages::NopVehicleOut>>           NOP_vehicleout;
// extern std::vector<std::shared_ptr<nio::ad::messages::NopFunctionStatus>>       NopFunction_Status;
// extern std::vector<std::shared_ptr<nio::ad::messages::NopSpeed>>                NOP_speed;
extern std::vector<std::shared_ptr<nio::ad::messages::NopSpeedLimitValue>> NOP_speedlimitvalue;
// extern std::vector<std::shared_ptr<nio::ad::messages::NopChassisControl>>  Nop_chassisctrl;
// extern std::vector<std::shared_ptr<nio::ad::messages::NopSceneMgmt>>            Nop_scenemgmt;
extern std::vector<std::shared_ptr<nio::ad::messages::FctsOut>>             FctsOut_info;
extern std::vector<std::shared_ptr<nio::ad::messages::CfgTaskSwitch>>       fct_cfgtaskswitch_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PowerSwapPilotState>> fct_Nop_powerpilotstate;
extern std::vector<std::shared_ptr<nio::ad::messages::GlobalLocalization>>  fct_global_locali_info;
extern std::vector<std::shared_ptr<nio::ad::messages::ADS>>                 fct_ads_info;
// extern std::vector<std::shared_ptr<nio::ad::messages::HdLinkInfoList>>      fct_hd_link_info;
extern std::vector<std::shared_ptr<nio::ad::messages::VehicleAdfFod>>       fct_veh_adf_fod_info;

extern uint16_T construction_wti_cnt;

struct cone_num {
  uint8_T current_lane = 0;
  uint8_T left_lane = 0;
  uint8_T right_lane = 0;
  uint8_T left_line = 0;
  uint8_T right_line = 0;
};
class FCTInputAdapter {
 private:
  // bool fill_vis_obj_input(const std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs, EHYVisionObjects
  // *ehy_vis_obj);
  bool fill_vis_road_sign_input(const std::shared_ptr<planner::IOAdapter>& ioadapter, VisionRoadSign *vis_road_sign);
  bool fill_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> road_det,
                           EHYVisionRoad*                                          vision_road,
                           const VEHPARAM*                                         veh_param_ptr);
  // bool fill_rdr_input(const std::shared_ptr<nio::ad::messages::RadarSensor> rdr_info, EHYRadarSensor
  // *ehy_rdr_sensor);
  bool fill_ehy_evd_input(const std::shared_ptr<nio::ad::messages::EHYEvdOutputs> ehy_evd_out, EHYEVD* ehy_evd_ptr);
  bool fill_ehy_ha_input(const std::shared_ptr<nio::ad::messages::EHYHaOutputs> ehy_ha_out, EHYHA* ehy_ha_ptr);
  bool fill_ehy_lpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_out, EHYLPP* ehy_lpp_ptr);
  bool fill_ehy_rme_input(const std::shared_ptr<nio::ad::messages::EHYRmeOutputs> ehy_rme_out, EHYRME* ehy_rme_ptr);
  bool fill_ehy_tpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_out, EHYTPP* ehy_tpp_ptr);
  bool fill_ehy_tsi_input(const std::shared_ptr<nio::ad::messages::EHYTsiOutputs> ehy_tsi_out, EHYTSI* ehy_tsi_ptr);
  bool fill_ehy_tse_input(const std::shared_ptr<nio::ad::messages::EHYTseOutputs> ehy_tse_out, EHYTSE* ehy_tse_ptr);
  bool fill_veh10ms_input(const std::shared_ptr<proto::CarInfo> fct_vehicle_input, VEHDYN* vehdyn_ptr,
                          VEHWHL* vehwhl_ptr, VEHPT* vehpt_ptr, VEHCTRL* vehctrl_ptr, STRSYS* strsys_ptr,
                          BRKSYS* brksys_ptr, std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool fill_veh50ms_input(const std::shared_ptr<proto::CarInfo> fct_vehicle_input, VEHDRVR* vehdrvr_ptr,
                          VEHBODY* vehbody_ptr, VEHUPA* vehupa_ptr, DANOPSM* danop_ptr);
  // bool fill_veh_50_input(const std::shared_ptr<nio::ad::messages::VEH50ms> vehicle_info, FCTSIN *fct_sin);
  // bool fill_obf_input(const std::shared_ptr<nio::ad::messages::EHYObfOutputs> obf_info,
  // std::vector<feature::ehy::Object> *fusion_object_ ); bool fill_fct_vis_obj_input(const
  // std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs, std::vector<feature::ehy::Object> *vision_object_);
  bool fill_me_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> road_det,
                              EHYVisionRoad*                                          vision_road);
  bool fill_dms_input(const std::shared_ptr<nio::ad::messages::DMS_DA>     dms_da_out,
                      const std::shared_ptr<nio::ad::messages::DMS_Result> dms_result_out,
                      const std::shared_ptr<nio::ad::messages::ADMS> adms_out, DMS* dms_ptr,
                      std::shared_ptr<planner::IOAdapter>& ioadapter);
  bool fill_vis_failsafe_input(const std::shared_ptr<nio::ad::messages::FailSafeDetection> failsafe_det,
                               VisionFailSafe*                                             vision_failsafe);
  bool fill_arb_input(const std::shared_ptr<nio::ad::messages::FunctionRequestBook> func_arb_out,
                      FUNCARB*                                                      func_arb_ptr);
  bool fill_funcstatus_input(const std::shared_ptr<nio::ad::messages::ParkingOut> func_parkingout, FUNCARB* func_arb_ptr);
  bool fill_cam_fim_input(const std::shared_ptr<nio::ad::messages::CameraFimInfo> cam_fim_out, CAMFIMINFO* cam_fim_ptr);

  bool fill_perception_fim_input(const std::shared_ptr<nio::ad::messages::PerceptionFimInfo> perception_fim_out, PERCEPTIONFIMINFO* perception_fim_ptr);

  bool fill_lidar_fim_input(const std::shared_ptr<nio::ad::messages::LidarFimInfo> lidar_fim_out, LIDARFIMINFO* lidar_fim_ptr);

  void fill_veh_param_input(const std::shared_ptr<nio::ad::messages::VehVariantCode> veh_var_code_out,
                            const std::shared_ptr<nio::ad::messages::VehicleAdfFod> veh_adf_fod_out,
                            VEHPARAM*                                                veh_param_ptr);
  void fill_adasmap_input(const std::shared_ptr<nio::ad::messages::AdasMap> AdasMap_out, SDMAP* sdmap_ptr);

  // void fill_nop_vehicleout_input(const std::shared_ptr<nio::ad::messages::NopVehicleOut> NopVehicle_out,
  //                                NopVehicleOut*                                          nopvehicle_ptr);
  void fill_nop_vehicleout_input(NopVehicleOut* nopvehicle_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter);

  // void fill_nop_chassis_ctrl_input(const std::shared_ptr<nio::ad::messages::NopChassisControl> Nop_ChassisCtrl,
  //                                  NopChassisControl*                                          nopchassis_ptr);
  void fill_nop_chassis_ctrl_input(NopChassisControl*                         nopchassis_ptr,
                                   const std::shared_ptr<planner::IOAdapter>& ioadapter);
  // void fill_nop_chassis_ctrl_input(const std::shared_ptr<proto::ControlCommand>& Nop_Control_cmd,
  //                                  NopChassisControl* nopchassis_ptr, STRSYS* strsys_ptr, VEHDYN* vehdyn_ptr);

  void fill_nop_functionstatus_input(NopFunctionstatus*                         nopfucntion_ptr,
                                     const std::shared_ptr<planner::IOAdapter>& ioadapter);

  // void fill_nop_speed_input(const std::shared_ptr<nio::ad::messages::NopSpeed> NopSpeed_out, NopSpeed*
  // nopspeed_ptr);
  void fill_nop_speed_input(NopSpeed* nopspeed_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void
  fill_nop_speedlimitvalue_input(const std::shared_ptr<nio::ad::messages::NopSpeedLimitValue> NopSpeedLimitValue_out,
                                 NopSpeedLimitValue*                                          nopspeedlimitvalue_ptr);
  void
  fill_nop_powerpilotstate_input(const std::shared_ptr<nio::ad::messages::PowerSwapPilotState> NopPowerPilotState_out,
                                 NopPowerPilotState*                                           noppowerpilotstate_ptr);

  bool fill_obf_input(const std::shared_ptr<proto::PerceptionObjects> obf_info,
                      std::vector<feature::ehy::Object>* fusion_object_, EHYOBF* ehy_obf_out);
  bool fill_side_feature(const std::shared_ptr<nio::ad::messages::ForceSideFeatures> side_feature_info,
                         BSDSTS*                                                     bsd_sts_ptr);
  bool fill_lidar_internalfault_input(
    const std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo> lidar_internalfault_info,
    LIDARFAULTINFO*                                                  lidar_internalfault_ptr);

  bool fill_fault_software_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);

  bool fill_fault_function_input(const std::shared_ptr<nio::ad::messages::FunctionInfo>& fault_function_info);

  void fill_aebout_input(const std::shared_ptr<nio::ad::messages::FctsOut> FctsOut_out, AEBOUT* aebout_ptr);
  void fill_cfgtaskswitch_input(const std::shared_ptr<nio::ad::messages::CfgTaskSwitch> cfgtaskswitch_out,
                                CfgTskSwt*                                              cfgtaskmgr_ptr);
  void fill_esdnpfeature_input(EsdNpFeature* esdnpfeature_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void receive_update();

  void fill_globallocalization_input(
  const std::shared_ptr<nio::ad::messages::GlobalLocalization> Global_Localization,
  GLOBALLOCALIZATION* global_locali_info_ptr, GlobalLocation* glb_loc_mil_info_ptr);
  void fill_hd_link_input(const std::shared_ptr<nio::ad::messages::HdLinkInfoList> hd_link,
                          std::vector<HDLINK>*                                     hd_link_info);
  void fill_ads_out_input(const std::shared_ptr<nio::ad::messages::ADS> ads_out,
                          ADSOUT*                                       ads_out_info);
  void fill_dynamic_map_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);

  void fill_active_prevention_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fill_ad_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fill_td_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fill_eas_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);
  void fill_hard_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter);

  uint64_t veh10ms_publish_ptp_ts = 0;
  uint64_t veh50ms_publish_ptp_ts = 0;
  uint64_t wm_dynamic_publish_ptp_ts_ = 0;
  bool fim_rel_loc_abnoraml_flag_ = false;
  bool fim_aa_app_abnoraml_flag_ = false;
  bool fim_map_loc_app_abnoraml_flag_ = false;
  bool fim_trafficlight_error_flag_ = false;

 public:
  FCTInputAdapter();
  ~FCTInputAdapter();

  bool MainFcn(EHYVisionRoad* vision_road_ptr, VEHDYN* veh_dyn_ptr, VEHDRVR* veh_drvr_ptr, VEHWHL* veh_whl_ptr,
               VEHPT* veh_pt_ptr, VEHCTRL* veh_ctrl_ptr, VEHBODY* veh_body_ptr, STRSYS* str_sys_ptr,
               BRKSYS* brk_sys_ptr, EHYEVD* ehy_evd_ptr, EHYHA* ehy_ha_ptr, EHYRME* ehy_rme_ptr, EHYTPP* ehy_tpp_ptr,
               EHYLPP* ehy_lpp_ptr, EHYTSI* ehy_tsi_ptr, EHYTSE* ehy_tse_ptr, EHYVisionRoad* me_vision_road_ptr,
               DMS* dms_ptr, VisionFailSafe* vision_failsafe, FUNCARB* func_arb_ptr, CAMFIMINFO* cam_fim_ptr,
               VEHUPA* veh_upa_ptr, VEHPARAM* veh_param_ptr, BSDSTS* bsd_sts_ptr, SDMAP* sdmap_ptr,
               NopVehicleOut* nopvehicle_ptr, NopFunctionstatus* nopfucntion_ptr, NopChassisControl* nopchassis_ptr,
               NopSpeed* nopspeed_ptr, NopSpeedLimitValue* nopspeedlimitvalue_ptr,
               std::vector<feature::ehy::Object>* fused_obj_ptr, EHYOBF* ehy_obf_ptr,
               LIDARFAULTINFO* lidar_internalfault_ptr, AEBOUT* aebout_ptr, CfgTskSwt* cfgtaskmgr_ptr,
               NopPowerPilotState* noppowerpilotstate_ptr, GLOBALLOCALIZATION* global_locali_ptr,
               GlobalLocation* global_loc_mil_ptr, std::vector<HDLINK>* hdlink_ptr, EsdNpFeature* esdnpfeature_ptr,
               std::shared_ptr<planner::IOAdapter>& ioadapter, ADSOUT* ads_ptr, PERCEPTIONFIMINFO* perception_fim_ptr,
               LIDARFIMINFO* lidar_fim_ptr, DANOPSM* danop_ptr, VisionRoadSign *road_sign_ptr);
  bool fill_npnopsm_input(DANOPSM* danop_ptr, DAStateMachineAdapter* statemachine_adapter,
                          VEHDRVR* veh_drvr_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter);
};


extern FCTInputAdapter fct_input_adapter_;
}  // namespace fctapp
}  // namespace ad
}  // namespace nio

#endif
