#include "fct_user_interface_proc.h"

namespace nio {
namespace ad {
namespace fctapp {

FCTNopUserInterface fct_nop_user_interface;
FCTNopUserInterface ::FCTNopUserInterface() {}
FCTNopUserInterface::~FCTNopUserInterface() {}
void FCTNopUserInterface::updateNopRainMode(const bool value) {
  this->nop_rain_mode = value;
}
bool FCTNopUserInterface::getNopRainMode() {
  return (this->nop_rain_mode);
}
float FCTNopUserInterface::getNopTauGap() {
  return (this->nop_tau_gap);
}

void FCTNopUserInterface::NopTauGap_proc(const uint8_t& taugap_level) {
  const std::array<float, 5> default_taugap_dict            = { 1.0, 1.4, 1.8, 2.2, 2.6 };
  const std::array<float, 5> rainmode_lowspeed_taugap_dict  = { 1.3, 1.7, 2.1, 2.5, 2.9 };
  const std::array<float, 5> rainmode_midspeed_taugap_dict  = { 1.6, 2.0, 2.4, 2.8, 3.2 };
  const std::array<float, 5> rainmode_highspeed_taugap_dict = { 1.9, 2.3, 2.7, 3.1, 3.5 };

  const std::array<float, 5>* taugap_dict = &default_taugap_dict;

  const float cur_ego_v_in_kmh    = this->cdc_kphdispspd;
  const float midspeed_thredhold  = 60.0;
  const float highspeed_thredhold = 90.0;
  if (this->nop_rain_mode) {
    if (cur_ego_v_in_kmh < midspeed_thredhold) {
      taugap_dict = &rainmode_lowspeed_taugap_dict;
    } else if (cur_ego_v_in_kmh < highspeed_thredhold) {
      taugap_dict = &rainmode_midspeed_taugap_dict;
    } else {
      taugap_dict = &rainmode_highspeed_taugap_dict;
    }
  }
  if (taugap_level < taugap_dict->size()) {
    this->nop_tau_gap = taugap_dict->at(taugap_level);
  }
}

void FCTNopUserInterface::fct_nop_user_interface_processing(const VEHDYN&        veh_dyn_info,
                                                            const HWA_outputs_T& hwa_out_info) {
  // deprecated
  return;
}
}  // namespace fctapp
}  // namespace ad
}  // namespace nio