#include "fct_input_adapter.h"
#include "common/esd/esd_np_feature.pb.h"
#include "fct_loc_cfg.h"
#include "fct_me_param.h"
#include "fct_timestamps_param.h"
#include "io_manager/io_adapter.h"
#include "planner/flags/planner_gflags.h"
#include "common/vehicle_in/pwrswapstn_can.pb.h"
#include "heater.h"
namespace nio {
namespace ad {
namespace fctapp {

VEHDYN              veh_dyn;
VEHDRVR             veh_drvr;
VEHWHL              veh_whl;
VEHPT               veh_pt;
VEHCTRL             veh_ctrl;
VEHBODY             veh_body;
VEHUPA              veh_upa;
STRSYS              str_sys;
BRKSYS              brk_sys;
EHYVisionRoad       vision_road;
VisionRoadSign      vision_road_sign;
EHYEVD              ehy_evd;
EHYHA               ehy_ha;
EHYRME              ehy_rme;
EHYTPP              ehy_tpp;
EHYLPP              ehy_lpp;
EHYTSI              ehy_tsi;
EHYTSE              ehy_tse;
EHYVisionRoad       me_vision_road;
DMS                 dms_sys;
VisionFailSafe      vision_failsafe;
FUNCARB             func_arb;
CAMFIMINFO          cam_fim;
VEHPARAM            veh_param;
BSDSTS              bsd_sts;
SDMAP               sdmap_info;
NopVehicleOut       nop_vehicleout;
NopFunctionstatus   nop_functionstatus;
NopChassisControl   nop_chassisctrl;
NopSpeed            nop_speed;
NopSpeedLimitValue  nop_speedlimitvalue;
EHYOBF              ehy_obf;
LIDARFAULTINFO      lidar_internalfault;
AEBOUT              aebout_info;
CfgTskSwt           cfgtaskmgr_info;
DANOPSM             danop_sm;
GlobalLocation      glb_loc_mil_info;
GLOBALLOCALIZATION  global_locali_info;
std::vector<HDLINK> hd_link_info;
NopPowerPilotState  nop_powerpilotstate;
EsdNpFeature        esd_np_feature_info;
PERCEPTIONFIMINFO   perception_fim;
LIDARFIMINFO        lidar_fim;
std::shared_ptr<proto::DynamicMap> dynamic_map = nullptr;
std::shared_ptr<nio::ad::messages::SWFaultInfo> faut_software = nullptr;
bool is_eas_inhibit = false;
apollo::cyber::Time last_fault_function_topic_time = ncyber::Time::Now();
uint64_t last_fault_function_ptp_ts = 0;

CommonProc_Info    common_proc_info;
ADSOUT             ads_out_info;
nio::planner::SasFunctionOut sas_func_out;
DASM_Info                    da_sm_info;
constexpr double kMaxConeDistance = 100.0;
constexpr double kMinConeDistance = -5.0;
constexpr uint16_T kOneConstructionConditionTime = 6000;   // 5min
constexpr uint16_T kNextConstructionConditionTime = 400;  // 20s
constexpr double kEpsilon = 1e-3;
constexpr uint8_T kMaxConenum = 5;
constexpr double override_cooling_time_buffer = 3.0;
uint16_T construction_wti_cnt = 0;

std::vector<feature::ehy::Object> fused_obj = std::vector<feature::ehy::Object>(128, feature::ehy::Object());

FCTInputAdapter fct_input_adapter_;

uint32_t configure_received_ = 0;

std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>        fct_radar_data;
std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>   fct_vision_objects;
std::vector<std::shared_ptr<proto::CarInfo>>                        fct_vehicle_input;
std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>      fct_road_detection;
std::vector<std::shared_ptr<proto::PerceptionObjects>>              fct_fusion_object;
std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>      fct_ehy_evd;
std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>       fct_ehy_ha;
std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>      fct_ehy_lpp;
std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>      fct_ehy_rme;
std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>>      fct_ehy_tpp;
std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>>      fct_ehy_tsi;
std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>      fct_ehy_tse;
std::vector<std::shared_ptr<nio::ad::messages::VehVariantCode>>     fct_var_code_info;
//std::vector<std::shared_ptr<nio::ad::messages::SdMap>>              SdMap_info;
// std::vector<std::shared_ptr<nio::ad::messages::NopVehicleOut>>      NOP_vehicleout;
// std::vector<std::shared_ptr<nio::ad::messages::NopFunctionStatus>>  NopFunction_Status;
// std::vector<std::shared_ptr<nio::ad::messages::NopSpeed>>           NOP_speed;
std::vector<std::shared_ptr<nio::ad::messages::NopSpeedLimitValue>> NOP_speedlimitvalue;
// std::vector<std::shared_ptr<nio::ad::messages::NopChassisControl>>  Nop_chassisctrl;
// std::vector<std::shared_ptr<nio::ad::messages::NopSceneMgmt>>       Nop_scenemgmt;
std::vector<std::shared_ptr<nio::ad::messages::FctsOut>>             FctsOut_info;
std::vector<std::shared_ptr<nio::ad::messages::CfgTaskSwitch>>       fct_cfgtaskswitch_info;
std::vector<std::shared_ptr<nio::ad::messages::PowerSwapPilotState>> fct_Nop_powerpilotstate;

std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>       fct_fim_camera_info;
std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>          fct_fim_can_info;
std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>     fct_fim_sw_info;
std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>>   fct_fim_can_fea_info;
std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>        fct_fim_power_info;
std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>>   fct_fim_mcu_soc_info;
std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>        fct_fim_lidar_info;
std::vector<std::shared_ptr<nio::ad::messages::ADMS>>                fct_adms_info;
std::vector<std::shared_ptr<nio::ad::messages::DMS_DA>>              fct_dms_da_info;
std::vector<std::shared_ptr<nio::ad::messages::DMS_Result>>          fct_dms_result_info;
std::vector<std::shared_ptr<nio::ad::messages::McuSystemFimInfo>>    fct_fim_mcu_sys_info;
std::vector<std::shared_ptr<nio::ad::messages::PerceptionFimInfo>>   fct_fim_perception_info;
std::vector<std::shared_ptr<nio::ad::messages::FunctionRequestBook>> fct_func_arb_info;
std::vector<std::shared_ptr<nio::ad::messages::ParkingOut>>          fct_parkingout_info;

// std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>           fct_me_road_detection;
std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> fct_failsafe_lidar_info;
std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       fct_failsafe_detection;
std::vector<std::shared_ptr<nio::ad::messages::ForceSideFeatures>>       fct_side_feature_;
std::vector<std::shared_ptr<nio::ad::messages::IlluminanceFeatures>>     fct_vision_illuminance_info;
std::vector<std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo>>  fct_lidar_internalfault_info;
std::vector<std::shared_ptr<nio::ad::messages::GlobalLocalization>>      fct_global_locali_info;
// std::vector<std::shared_ptr<nio::ad::messages::HdLinkInfoList>>          fct_hd_link_info;
std::vector<std::shared_ptr<nio::ad::messages::esd_np_feature>>          fct_esd_np_feature_info;
std::vector<std::shared_ptr<nio::ad::messages::AdasMap>>                 AdasMap_info;
std::vector<std::shared_ptr<nio::ad::messages::ADS>>                     fct_ads_info;
std::vector<std::shared_ptr<nio::ad::messages::VehicleAdfFod>>           fct_veh_adf_fod_info;

int cfgtaskswitch_status_last_ = 0;
int cfgtaskswitch_size_last_   = 255;  // default
uint speed_unit_last_ = 0;

FCTInputAdapter::FCTInputAdapter() {}

FCTInputAdapter::~FCTInputAdapter() {}

void FCTInputAdapter::receive_update() {}

bool FCTInputAdapter::fill_vis_road_sign_input(const std::shared_ptr<planner::IOAdapter>& ioadapter, VisionRoadSign *vis_road_sign) {
  auto sub_vision_road_sign =
        ioadapter->getInputManager().m_sub_vision_road_sign_.GetLatest();
  vis_road_sign->road_sign.clear();
  if(sub_vision_road_sign) {
    int len = sub_vision_road_sign->roadsign().size();
    std::vector<RoadSign> cur_road_sign;
    for(auto i = 0; i < len; i++) {
      RoadSign local_road_sign;
      local_road_sign.roadsign_lane_assign = static_cast<int>(sub_vision_road_sign->roadsign()[i].roadsign_lane_assign());
      local_road_sign.roadsign_class = static_cast<int>(sub_vision_road_sign->roadsign()[i].roadsign_class());
      local_road_sign.center_x = sub_vision_road_sign->roadsign()[i].roadsign_center_x();
      cur_road_sign.emplace_back(local_road_sign);
    }
    vis_road_sign->road_sign = cur_road_sign;
    return true;
  }
  return false;
}

bool FCTInputAdapter::fill_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> road_det,
                                          EHYVisionRoad*                                          vision_road,
                                          const VEHPARAM*                                         veh_param_ptr) {
  // Lane info fill in
  vision_road->lane.crossing_flag   = road_det->laneline().ld_crossing_flag();
  vision_road->lane.host_lane_width = road_det->laneline().ld_lane_width();
  int line_size                     = MAX(road_det->laneline().line_size(), kNumVisionLaneMarker);

  // eu tempLaneLines parm
  std::vector<PolyLine_s> yellow_line;
  std::vector<float> yellow_line_preview_c0;
  float preview_dist = 8.99;
  float width_min = 1.0;
  float width_max = 4.0;
  uint8_t debounce_period = 200;

  int line_index = 0;
  for (int i_line = 0; i_line < line_size; ++i_line) {
    // ehy input struct predefined with max 8 lines
    if (i_line < road_det->laneline().line_size()) {
      const uint32_T ld_filter = road_det->laneline().line(i_line).ld_filter();
      if (!(static_cast<bool>(ld_filter & 2))) {
        continue;
      }
      vision_road->lane.lines[line_index].confidence          = road_det->laneline().line(i_line).ld_confidence();
      vision_road->lane.lines[line_index].crossing            = road_det->laneline().line(i_line).ld_crossing();
      vision_road->lane.lines[line_index].crossing_ID         = road_det->laneline().line(i_line).ld_crossing_id();
      vision_road->lane.lines[line_index].dash_average_gap    = road_det->laneline().line(i_line).ld_dash_average_gap();
      vision_road->lane.lines[line_index].dash_average_length = road_det->laneline().line(i_line).ld_dash_average_length();
      vision_road->lane.lines[line_index].first_line.color =
        (LDColor_e)road_det->laneline().line(i_line).ld_first_line().ld_color();
      vision_road->lane.lines[line_index].first_line.type =
        (LDType_e)road_det->laneline().line(i_line).ld_first_line().ld_type();
      vision_road->lane.lines[line_index].first_line.start = road_det->laneline().line(i_line).ld_first_line().ld_start();
      vision_road->lane.lines[line_index].first_line.end   = road_det->laneline().line(i_line).ld_first_line().ld_end();
      vision_road->lane.lines[line_index].first_line.end_reason =
        (LDEndReason_e)road_det->laneline().line(i_line).ld_first_line().ld_end_reason();
      vision_road->lane.lines[line_index].first_line.line.c0 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c0();
      vision_road->lane.lines[line_index].first_line.line.c1 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c1();
      vision_road->lane.lines[line_index].first_line.line.c2 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c2();
      vision_road->lane.lines[line_index].first_line.line.c3 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c3();
      // save yellow_line parm
      if ((LDColor_e)road_det->laneline().line(i_line).ld_first_line().ld_color() == LDColor_e::LDColor_Yellow) {
        yellow_line.push_back(vision_road->lane.lines[line_index].first_line.line);
      }
      vision_road->lane.lines[line_index].second_line.color =
        (LDColor_e)road_det->laneline().line(i_line).ld_second_line().ld_color();
      vision_road->lane.lines[line_index].second_line.type =
        (LDType_e)road_det->laneline().line(i_line).ld_second_line().ld_type();
      vision_road->lane.lines[line_index].second_line.start = road_det->laneline().line(i_line).ld_second_line().ld_start();
      vision_road->lane.lines[line_index].second_line.end   = road_det->laneline().line(i_line).ld_second_line().ld_end();
      vision_road->lane.lines[line_index].second_line.end_reason =
        (LDEndReason_e)road_det->laneline().line(i_line).ld_second_line().ld_end_reason();
      vision_road->lane.lines[line_index].second_line.line.c0 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c0();
      vision_road->lane.lines[line_index].second_line.line.c1 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c1();
      vision_road->lane.lines[line_index].second_line.line.c2 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c2();
      vision_road->lane.lines[line_index].second_line.line.c3 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c3();
      vision_road->lane.lines[line_index].is_multi_clothoid = road_det->laneline().line(i_line).ld_is_multi_clothoid();
      vision_road->lane.lines[line_index].marker_width      = road_det->laneline().line(i_line).ld_marker_width();
      vision_road->lane.lines[line_index].measure_status =
        (LDMeasureStatus_e)road_det->laneline().line(i_line).ld_measuring_status();
      vision_road->lane.lines[line_index].is_multi_clothoid = road_det->laneline().line(i_line).ld_is_multi_clothoid();
      // int i_px_pt_size = MIN(road_det->laneline().line(i_line).ld_pixel_point_size(), kNumVisionLaneMarkerPoint);
      // for (int i_pix_pt = 0; i_pix_pt < kNumVisionLaneMarkerPoint; ++i_pix_pt)
      // {
      //     // ehy input struct predefined pixel point size is 300
      //     if (i_pix_pt < i_px_pt_size)
      //     {
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lat =
      //         road_det->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_lat();
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lon =
      //         road_det->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_long();
      //     } else {
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lat = 0;
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lon = 0;
      //     }
      // }
      int i_line_pt_size = MIN(road_det->laneline().line(i_line).ld_point_size(), kNumVisionLaneMarkerPoint);
      for (int i_line_pt = 0; i_line_pt < kNumVisionLaneMarkerPoint; ++i_line_pt) {
        // ehy input struct predefined point size is 300
        if (i_line_pt < i_line_pt_size) {
          vision_road->lane.lines[line_index].point[i_line_pt].lat =
            road_det->laneline().line(i_line).ld_point(i_line_pt).ld_point_lat();
          vision_road->lane.lines[line_index].point[i_line_pt].lon =
            road_det->laneline().line(i_line).ld_point(i_line_pt).ld_point_long();
        } else {
          vision_road->lane.lines[line_index].point[i_line_pt].lat = 0;
          vision_road->lane.lines[line_index].point[i_line_pt].lon = 0;
        }
      }
      vision_road->lane.lines[line_index].predict_reason =
        (LDPredictReason_e)road_det->laneline().line(i_line).ld_prediction_reason();
      vision_road->lane.lines[line_index].quality = (LDQuality_e)road_det->laneline().line(i_line).ld_quality();
      vision_road->lane.lines[line_index].role    = (LDRole_e)road_det->laneline().line(i_line).ld_role();

      // vision_road->lane.lines[i_line].source =
      // (LDCameraSource_e)road_det->laneline().line(i_line).ld_camera_source();
      vision_road->lane.lines[line_index].special_point.lat =
        road_det->laneline().line(i_line).ld_special_point().ld_point_lat();
      vision_road->lane.lines[line_index].special_point.lon =
        road_det->laneline().line(i_line).ld_special_point().ld_point_long();
      vision_road->lane.lines[line_index].special_point_is_detected =
        road_det->laneline().line(i_line).ld_special_point_is_detected();
      vision_road->lane.lines[line_index].special_point_type =
        (LDSpecialPointType_e)road_det->laneline().line(i_line).ld_special_point_type();
      vision_road->lane.lines[line_index].track_age = road_det->laneline().line(i_line).ld_track_age();
      vision_road->lane.lines[line_index].track_ID  = road_det->laneline().line(i_line).ld_track_id();
    } else {
      vision_road->lane.lines[line_index].confidence             = 0;
      vision_road->lane.lines[line_index].crossing               = 0;
      vision_road->lane.lines[line_index].crossing_ID            = 0;
      vision_road->lane.lines[line_index].dash_average_gap       = 0;
      vision_road->lane.lines[line_index].dash_average_length    = 0;
      vision_road->lane.lines[line_index].first_line.color       = (LDColor_e)0;
      vision_road->lane.lines[line_index].first_line.type        = (LDType_e)0;
      vision_road->lane.lines[line_index].first_line.start       = 0;
      vision_road->lane.lines[line_index].first_line.end         = 0;
      vision_road->lane.lines[line_index].first_line.end_reason  = (LDEndReason_e)0;
      vision_road->lane.lines[line_index].first_line.line.c0     = 0;
      vision_road->lane.lines[line_index].first_line.line.c1     = 0;
      vision_road->lane.lines[line_index].first_line.line.c2     = 0;
      vision_road->lane.lines[line_index].first_line.line.c3     = 0;
      vision_road->lane.lines[line_index].second_line.color      = (LDColor_e)0;
      vision_road->lane.lines[line_index].second_line.type       = (LDType_e)0;
      vision_road->lane.lines[line_index].second_line.start      = 0;
      vision_road->lane.lines[line_index].second_line.end        = 0;
      vision_road->lane.lines[line_index].second_line.end_reason = (LDEndReason_e)0;
      vision_road->lane.lines[line_index].second_line.line.c0    = 0;
      vision_road->lane.lines[line_index].second_line.line.c1    = 0;
      vision_road->lane.lines[line_index].second_line.line.c2    = 0;
      vision_road->lane.lines[line_index].second_line.line.c3    = 0;
      vision_road->lane.lines[line_index].is_multi_clothoid      = 0;
      vision_road->lane.lines[line_index].marker_width           = 0;
      vision_road->lane.lines[line_index].measure_status         = (LDMeasureStatus_e)0;
      vision_road->lane.lines[line_index].is_multi_clothoid      = 0;
      for (int i_pix_pt = 0; i_pix_pt < kNumVisionLaneMarkerPoint; ++i_pix_pt) {

        vision_road->lane.lines[line_index].pixel_point[i_pix_pt].lat = 0;
        vision_road->lane.lines[line_index].pixel_point[i_pix_pt].lon = 0;
      }
      for (int i_line_pt = 0; i_line_pt < kNumVisionLaneMarkerPoint; ++i_line_pt) {
        vision_road->lane.lines[line_index].point[i_line_pt].lat = 0;
        vision_road->lane.lines[line_index].point[i_line_pt].lon = 0;
      }
      vision_road->lane.lines[line_index].predict_reason = (LDPredictReason_e)0;
      vision_road->lane.lines[line_index].quality        = (LDQuality_e)0;
      vision_road->lane.lines[line_index].role           = (LDRole_e)0;

      vision_road->lane.lines[line_index].source                    = (LDCameraSource_e)0;
      vision_road->lane.lines[line_index].special_point.lat         = 0;
      vision_road->lane.lines[line_index].special_point.lon         = 0;
      vision_road->lane.lines[line_index].special_point_is_detected = 0;
      vision_road->lane.lines[line_index].special_point_type        = (LDSpecialPointType_e)0;
      vision_road->lane.lines[line_index].track_age                 = 0;
      vision_road->lane.lines[line_index].track_ID                  = 0;
    }
    line_index += 1;
    if (line_index >= kNumVisionLaneMarker - 1) {
      break;
    }
  }

  // yellow lane detection
  bool yellow_lane = false;
  if (yellow_line.size() > 1) {
    float preview_dist_2 = pow(preview_dist, 2);
    float preview_dist_3 = pow(preview_dist, 3);
    for (auto line : yellow_line) {
      yellow_line_preview_c0.push_back(
        line.c0 + line.c1 * preview_dist + line.c2 * preview_dist_2 + line.c3 * preview_dist_3);
    }
    std::sort(yellow_line_preview_c0.begin(), yellow_line_preview_c0.end());
    for (int i = 0; i < yellow_line_preview_c0.size()-1; i++) {
      float temp_dist = abs(yellow_line_preview_c0[i+1]-yellow_line_preview_c0[i]);
      if (temp_dist >= width_min && temp_dist <= width_max) {
        yellow_lane = true;
        break;
      } else {
        yellow_lane = false;
      }
    }
  } else {
    yellow_lane = false;
  }
  // debounce
  static int no_yellow_lane_num = 0;
  static bool eu_construction_area = false;
  if (yellow_lane == false) {
    if (no_yellow_lane_num >= debounce_period) {
      no_yellow_lane_num = debounce_period;
    } else {
      no_yellow_lane_num += 1;
    }
  } else {
    no_yellow_lane_num = 0;
  }
  // eu_construction_area_detection
  if (yellow_lane == true && veh_param_ptr->VarCodeInfo.sales_region == SalesRegionTyp_e::EU) {
    eu_construction_area = true;
  }
  if ((yellow_lane == false && no_yellow_lane_num >= debounce_period) ||
        veh_param_ptr->VarCodeInfo.sales_region == SalesRegionTyp_e::CN) {
    eu_construction_area = false;
  }
  vision_road->lane.eu_construction_area_flag = eu_construction_area;

  // LPP infor fill in
  vision_road->lpp.source             = (LPPSource_e)road_det->lpp().lpp_source();
  vision_road->lpp.available          = road_det->lpp().lpp_available();
  vision_road->lpp.confidence         = road_det->lpp().lpp_confidence();
  vision_road->lpp.first_line.c0      = road_det->lpp().lpp_first().line_c0();
  vision_road->lpp.first_line.c1      = road_det->lpp().lpp_first().line_c1();
  vision_road->lpp.first_line.c2      = road_det->lpp().lpp_first().line_c2();
  vision_road->lpp.first_line.c3      = road_det->lpp().lpp_first().line_c3();
  vision_road->lpp.first_valid        = road_det->lpp().lpp_first_valid();
  vision_road->lpp.first_vr_end       = road_det->lpp().lpp_first_vr_end();
  vision_road->lpp.lpp_ctrl_point.lat = road_det->lpp().lpp_ctrl_point_lat();
  vision_road->lpp.lpp_ctrl_point.lon = road_det->lpp().lpp_ctrl_point_long();
  vision_road->lpp.second_line.c0     = road_det->lpp().lpp_second().line_c0();
  vision_road->lpp.second_line.c1     = road_det->lpp().lpp_second().line_c1();
  vision_road->lpp.second_line.c2     = road_det->lpp().lpp_second().line_c2();
  vision_road->lpp.second_line.c3     = road_det->lpp().lpp_second().line_c3();
  vision_road->lpp.second_valid       = road_det->lpp().lpp_second_valid();
  vision_road->lpp.second_vr_end      = road_det->lpp().lpp_second_vr_end();

  // //Road edge infor fill in
  int road_edge_index = 0;
  int road_edge_num = MAX(road_det->roadedge_size(), kNumVisionRoadEdge);
  // int i_road_edg_size = MIN(road_det->roadedge_size(), kNumVisionRoadEdge);
  for (int i_road_edg = 0; i_road_edg < road_edge_num; ++i_road_edg) {
    if (i_road_edg < road_det->roadedge_size()) {
      const uint32_T ld_re_filter = road_det->roadedge(i_road_edg).ld_re_filter();
      if (!(static_cast<bool>(ld_re_filter & 2))) {
        continue;
      }
      vision_road->road_edge[road_edge_index].id     = road_det->roadedge(i_road_edg).ld_re_id();
      vision_road->road_edge[road_edge_index].age    = road_det->roadedge(i_road_edg).ld_re_age();
      // [NT2ADR-6103] Default Uncrossable Due to https://nio.feishu.cn/wiki/VcV0woFEqixJKbk9RSZc0S4Onrf
      vision_road->road_edge[road_edge_index].type   = (LDREType_e)2;
      vision_road->road_edge[road_edge_index].height = road_det->roadedge(i_road_edg).ld_re_height();
      vision_road->road_edge[road_edge_index].host_index =
        (LDREFromHostIndex_e)road_det->roadedge(i_road_edg).ld_re_from_host_index();
      vision_road->road_edge[road_edge_index].side           = (LDRESide_e)road_det->roadedge(i_road_edg).ld_re_side();
      vision_road->road_edge[road_edge_index].view_rng_start = road_det->roadedge(i_road_edg).ld_re_vr_start();
      vision_road->road_edge[road_edge_index].view_rng_end   = road_det->roadedge(i_road_edg).ld_re_vr_end();
      vision_road->road_edge[road_edge_index].line.c0        = road_det->roadedge(i_road_edg).ld_re_line().line_c0();
      vision_road->road_edge[road_edge_index].line.c1        = road_det->roadedge(i_road_edg).ld_re_line().line_c1();
      vision_road->road_edge[road_edge_index].line.c2        = road_det->roadedge(i_road_edg).ld_re_line().line_c2();
      vision_road->road_edge[road_edge_index].line.c3        = road_det->roadedge(i_road_edg).ld_re_line().line_c3();
      vision_road->road_edge[road_edge_index].re_class       = (LDREClass_e)road_det->roadedge(i_road_edg).ldre_class();
    } else {
      vision_road->road_edge[road_edge_index].id             = 0;
      vision_road->road_edge[road_edge_index].age            = 0;
      vision_road->road_edge[road_edge_index].type           = (LDREType_e)0;
      vision_road->road_edge[road_edge_index].height         = 0;
      vision_road->road_edge[road_edge_index].host_index     = (LDREFromHostIndex_e)0;
      vision_road->road_edge[road_edge_index].side           = (LDRESide_e)0;
      vision_road->road_edge[road_edge_index].view_rng_start = 0;
      vision_road->road_edge[road_edge_index].view_rng_end   = 0;
      vision_road->road_edge[road_edge_index].line.c0        = 0;
      vision_road->road_edge[road_edge_index].line.c1        = 0;
      vision_road->road_edge[road_edge_index].line.c2        = 0;
      vision_road->road_edge[road_edge_index].line.c3        = 0;
      vision_road->road_edge[road_edge_index].re_class       = (LDREClass_e)0;
    }
    road_edge_index += 1;
    if (road_edge_index >= kNumVisionRoadEdge - 1) {
      break;
    }
  }

  // stop line info fill in
  int i_stop_line_size = MIN(road_det->stopline_size(), kNumVisionStopLine);
  for (int i_stop_line = 0; i_stop_line < kNumVisionStopLine; ++i_stop_line) {
    if (i_stop_line < i_stop_line_size) {
      vision_road->stop_line[i_stop_line].SL_Is_Detected = road_det->stopline(i_stop_line).sl_is_detected();
      vision_road->stop_line[i_stop_line].SL_ID          = road_det->stopline(i_stop_line).sl_id();
      vision_road->stop_line[i_stop_line].SL_Type        = (uint8_t)road_det->stopline(i_stop_line).sl_type();
      vision_road->stop_line[i_stop_line].SL_Measure_Status =
        (uint8_t)road_det->stopline(i_stop_line).sl_measure_status();
      vision_road->stop_line[i_stop_line].SL_Lane_Assessment =
        (uint8_t)road_det->stopline(i_stop_line).sl_lane_assessment();
      vision_road->stop_line[i_stop_line].SL_Probability = road_det->stopline(i_stop_line).sl_probability();
      vision_road->stop_line[i_stop_line].SL_Long_Dist_L = road_det->stopline(i_stop_line).sl_long_dist_l();
      vision_road->stop_line[i_stop_line].SL_Long_Dist_R = road_det->stopline(i_stop_line).sl_long_dist_r();
      vision_road->stop_line[i_stop_line].SL_Lat_Dist_L  = road_det->stopline(i_stop_line).sl_lat_dist_l();
      vision_road->stop_line[i_stop_line].SL_Lat_Dist_R  = road_det->stopline(i_stop_line).sl_lat_dist_r();
    } else {
      vision_road->stop_line[i_stop_line].SL_Is_Detected     = false;
      vision_road->stop_line[i_stop_line].SL_ID              = 0U;
      vision_road->stop_line[i_stop_line].SL_Type            = 0U;  // SLType::SLType_Unknown;
      vision_road->stop_line[i_stop_line].SL_Measure_Status  = 0U;  // SLMeasureStatus::SLMeasureStatus_Unknown;
      vision_road->stop_line[i_stop_line].SL_Lane_Assessment = 0U;  // SLLaneAssessment::SLLaneAssessment_Unknown;
      vision_road->stop_line[i_stop_line].SL_Probability     = 0;
      vision_road->stop_line[i_stop_line].SL_Long_Dist_L     = 0;
      vision_road->stop_line[i_stop_line].SL_Long_Dist_R     = 0;
      vision_road->stop_line[i_stop_line].SL_Lat_Dist_L      = 0;
      vision_road->stop_line[i_stop_line].SL_Lat_Dist_R      = 0;
    }
  }

  // vision_road->timestamp = road_det->timestamp();

  return true;
}

bool FCTInputAdapter::fill_ehy_evd_input(const std::shared_ptr<nio::ad::messages::EHYEvdOutputs> ehy_evd_out,
                                         EHYEVD*                                                 ehy_evd_ptr) {
  ehy_evd_ptr->decision = (EvdDecisionName_e)(static_cast<int>(ehy_evd_out->decision()));

  ehy_evd_ptr->parameters.lane_change.change_dir =
    (EvdDcsDir_e)(static_cast<int>(ehy_evd_out->parameters().lane_change().change_dir()));

  ehy_evd_ptr->parameters.lane_change.lane_change_reason =
    (EvdLaneChangeReason_e)(static_cast<int>(ehy_evd_out->parameters().lane_change().lane_change_reason()));

  ehy_evd_ptr->parameters.path_select.path_dir =
    (EvdDcsDir_e)(static_cast<int>(ehy_evd_out->parameters().path_select().path_dir()));

  ehy_evd_ptr->parameters.leading.leading_dir =
    (EvdDcsDir_e)(static_cast<int>(ehy_evd_out->parameters().leading().leading_dir()));

  ehy_evd_ptr->parameters.takeover.takeover_src =
    static_cast<uint32_t>(ehy_evd_out->parameters().takeover().takeover_src());

  ehy_evd_ptr->parameters.hw2ramp.ramp_dir =
    (EvdDcsDir_e)(static_cast<int>(ehy_evd_out->parameters().hw2ramp().ramp_dir()));

  ehy_evd_ptr->parameters.hw2ramp.dst2leading = static_cast<float>(ehy_evd_out->parameters().hw2ramp().dst2leading());

  ehy_evd_ptr->limitations.spd_valid = static_cast<bool>(ehy_evd_out->limitations().spd_valid());

  ehy_evd_ptr->limitations.spd = static_cast<float>(ehy_evd_out->limitations().spd());

  ehy_evd_ptr->limitations.distance_valid = static_cast<bool>(ehy_evd_out->limitations().distance_valid());

  ehy_evd_ptr->limitations.distance = static_cast<float>(ehy_evd_out->limitations().distance());

  ehy_evd_ptr->limitations.deadline_valid = static_cast<uint32_t>(ehy_evd_out->limitations().deadline_valid());

  ehy_evd_ptr->limitations.deadline = static_cast<float>(ehy_evd_out->limitations().deadline());

  ehy_evd_ptr->limitations.curr_limit.spd = static_cast<uint32_t>(ehy_evd_out->limitations().curr_limit().spd());

  ehy_evd_ptr->limitations.curr_limit.dist = static_cast<float>(ehy_evd_out->limitations().curr_limit().dist());

  ehy_evd_ptr->limitations.curr_limit.valid = static_cast<uint32_t>(ehy_evd_out->limitations().curr_limit().valid());

  ehy_evd_ptr->limitations.curr_limit.source =
    (CurrSpdLmtSrc_e)(static_cast<int>(ehy_evd_out->limitations().curr_limit().source()));

  ehy_evd_ptr->limitations.curr_limit.regulation =
    static_cast<uint32_t>(ehy_evd_out->limitations().curr_limit().regulation());

  ehy_evd_ptr->gfp_info.valid = static_cast<uint32_t>(ehy_evd_out->gfp_info().valid());

  ehy_evd_ptr->gfp_info.classification = (GFPDirClass_e)(static_cast<int>(ehy_evd_out->gfp_info().classification()));

  ehy_evd_ptr->gfp_info.distance = static_cast<float>(ehy_evd_out->gfp_info().distance());

  ehy_evd_ptr->gfp_info.type = static_cast<uint32_t>(ehy_evd_out->gfp_info().type());

  return true;
}

bool FCTInputAdapter::fill_ehy_ha_input(const std::shared_ptr<nio::ad::messages::EHYHaOutputs> ehy_ha_out,
                                        EHYHA*                                                 ehy_ha_ptr) {
  ehy_ha_ptr->icon_info = static_cast<uint32_t>(ehy_ha_out->icon_info());

  ehy_ha_ptr->text_info = (HaTextInfo_e)(static_cast<int>(ehy_ha_out->icon_info()));

  ehy_ha_ptr->sound_info = static_cast<uint32_t>(ehy_ha_out->sound_info());

  ehy_ha_ptr->left_lane_flash = static_cast<bool>(ehy_ha_out->left_lane_flash());

  ehy_ha_ptr->right_lane_flash = static_cast<bool>(ehy_ha_out->right_lane_flash());

  return true;
}

bool FCTInputAdapter::fill_ehy_rme_input(const std::shared_ptr<nio::ad::messages::EHYRmeOutputs> ehy_rme_out,
                                         EHYRME*                                                 ehy_rme_ptr) {
  ehy_rme_ptr->road_edge_left.pt_conf = static_cast<float>(ehy_rme_out->road_edge_left().pt_conf());

  ehy_rme_ptr->road_edge_left.c0 = static_cast<float>(ehy_rme_out->road_edge_left().c0());

  ehy_rme_ptr->road_edge_left.c1 = static_cast<float>(ehy_rme_out->road_edge_left().c1());

  ehy_rme_ptr->road_edge_left.c2 = static_cast<float>(ehy_rme_out->road_edge_left().c2());

  ehy_rme_ptr->road_edge_left.c3 = static_cast<float>(ehy_rme_out->road_edge_left().c3());

  ehy_rme_ptr->road_edge_left.lrange_start = static_cast<float>(ehy_rme_out->road_edge_left().lrange_start());

  ehy_rme_ptr->road_edge_left.lrange_end = static_cast<float>(ehy_rme_out->road_edge_left().lrange_end());

  ehy_rme_ptr->road_edge_left.lm_width = static_cast<float>(ehy_rme_out->road_edge_left().lm_width());

  ehy_rme_ptr->road_edge_left.line_color = (LMColor_e)(static_cast<int>(ehy_rme_out->road_edge_left().line_color()));

  ehy_rme_ptr->road_edge_left.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->road_edge_left().line_type()));

  ehy_rme_ptr->road_edge_left.line_src = (LMSource_e)(static_cast<int>(ehy_rme_out->road_edge_left().line_src()));

  ehy_rme_ptr->road_edge_right.pt_conf = static_cast<float>(ehy_rme_out->road_edge_right().pt_conf());

  ehy_rme_ptr->road_edge_right.c0 = static_cast<float>(ehy_rme_out->road_edge_right().c0());

  ehy_rme_ptr->road_edge_right.c1 = static_cast<float>(ehy_rme_out->road_edge_right().c1());

  ehy_rme_ptr->road_edge_right.c2 = static_cast<float>(ehy_rme_out->road_edge_right().c2());

  ehy_rme_ptr->road_edge_right.c3 = static_cast<float>(ehy_rme_out->road_edge_right().c3());

  ehy_rme_ptr->road_edge_right.lrange_start = static_cast<float>(ehy_rme_out->road_edge_right().lrange_start());

  ehy_rme_ptr->road_edge_right.lrange_end = static_cast<float>(ehy_rme_out->road_edge_right().lrange_end());

  ehy_rme_ptr->road_edge_right.lm_width = static_cast<float>(ehy_rme_out->road_edge_right().lm_width());

  ehy_rme_ptr->road_edge_right.line_color = (LMColor_e)(static_cast<int>(ehy_rme_out->road_edge_right().line_color()));

  ehy_rme_ptr->road_edge_right.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->road_edge_right().line_type()));

  ehy_rme_ptr->road_edge_right.line_src = (LMSource_e)(static_cast<int>(ehy_rme_out->road_edge_right().line_src()));

  ehy_rme_ptr->host_lane.left_line.pt_conf = static_cast<float>(ehy_rme_out->host_lane().left_line().pt_conf());

  ehy_rme_ptr->host_lane.left_line.c0 = static_cast<float>(ehy_rme_out->host_lane().left_line().c0());

  ehy_rme_ptr->host_lane.left_line.c1 = static_cast<float>(ehy_rme_out->host_lane().left_line().c1());

  ehy_rme_ptr->host_lane.left_line.c2 = static_cast<float>(ehy_rme_out->host_lane().left_line().c2());

  ehy_rme_ptr->host_lane.left_line.c3 = static_cast<float>(ehy_rme_out->host_lane().left_line().c3());

  ehy_rme_ptr->host_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_out->host_lane().left_line().lrange_start());

  ehy_rme_ptr->host_lane.left_line.lrange_end = static_cast<float>(ehy_rme_out->host_lane().left_line().lrange_end());

  ehy_rme_ptr->host_lane.left_line.lm_width = static_cast<float>(ehy_rme_out->host_lane().left_line().lm_width());

  ehy_rme_ptr->host_lane.left_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->host_lane().left_line().line_color()));

  ehy_rme_ptr->host_lane.left_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->host_lane().left_line().line_type()));

  ehy_rme_ptr->host_lane.left_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->host_lane().left_line().line_src()));

  ehy_rme_ptr->host_lane.right_line.pt_conf = static_cast<float>(ehy_rme_out->host_lane().right_line().pt_conf());

  ehy_rme_ptr->host_lane.right_line.c0 = static_cast<float>(ehy_rme_out->host_lane().right_line().c0());

  ehy_rme_ptr->host_lane.right_line.c1 = static_cast<float>(ehy_rme_out->host_lane().right_line().c1());

  ehy_rme_ptr->host_lane.right_line.c2 = static_cast<float>(ehy_rme_out->host_lane().right_line().c2());

  ehy_rme_ptr->host_lane.right_line.c3 = static_cast<float>(ehy_rme_out->host_lane().right_line().c3());

  ehy_rme_ptr->host_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_out->host_lane().right_line().lrange_start());

  ehy_rme_ptr->host_lane.right_line.lrange_end = static_cast<float>(ehy_rme_out->host_lane().right_line().lrange_end());

  ehy_rme_ptr->host_lane.right_line.lm_width = static_cast<float>(ehy_rme_out->host_lane().right_line().lm_width());

  ehy_rme_ptr->host_lane.right_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->host_lane().right_line().line_color()));

  ehy_rme_ptr->host_lane.right_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->host_lane().right_line().line_type()));

  ehy_rme_ptr->host_lane.right_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->host_lane().right_line().line_src()));

  int min_hslantype_size = ehy_rme_out->host_lane().lane_type().size();

  for (int hostlanei = 0; hostlanei < 2; hostlanei++) {
    if (hostlanei < min_hslantype_size) {
      ehy_rme_ptr->host_lane.lane_type[hostlanei] =
        (LMLaneType_e)(static_cast<int>(ehy_rme_out->host_lane().lane_type(hostlanei)));
    } else {
      ehy_rme_ptr->host_lane.lane_type[hostlanei] = (LMLaneType_e)0;
    }
  }

  ehy_rme_ptr->host_lane.lane_start = static_cast<float>(ehy_rme_out->host_lane().lane_start());

  ehy_rme_ptr->host_lane.lane_end = static_cast<float>(ehy_rme_out->host_lane().lane_end());

  ehy_rme_ptr->host_lane.map_spd_limit = static_cast<float>(ehy_rme_out->host_lane().map_spd_limit());

  ehy_rme_ptr->host_lane.lane_width = static_cast<float>(ehy_rme_out->host_lane().lane_width());

  ehy_rme_ptr->host_lane.ca_lon_dst = static_cast<float>(ehy_rme_out->host_lane().ca_lon_dst());

  int host_cp_size = MIN(ehy_rme_out->host_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < 10; cpi++) {
    if (cpi < host_cp_size) {
      ehy_rme_ptr->host_lane.cur_point[cpi] = static_cast<float>(ehy_rme_out->host_lane().cur_point(cpi));
    } else {
      ehy_rme_ptr->host_lane.cur_point[cpi] = 0;
    }
  }

  int host_cv_size = MIN(ehy_rme_out->host_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < 10; cvi++) {
    if (cvi < host_cv_size) {
      ehy_rme_ptr->host_lane.cur_value[cvi] = static_cast<float>(ehy_rme_out->host_lane().cur_value(cvi));
    } else {
      ehy_rme_ptr->host_lane.cur_value[cvi] = 0;
    }
  }

  ehy_rme_ptr->host_lane.lane_dir = (LMLaneDir_e)(static_cast<int>(ehy_rme_out->host_lane().lane_dir()));

  ehy_rme_ptr->host_lane.ca_valid = static_cast<bool>(ehy_rme_out->host_lane().ca_valid());

  ehy_rme_ptr->host_lane.lane_id = static_cast<uint32_t>(ehy_rme_out->host_lane().lane_id());

  ehy_rme_ptr->left_lane.left_line.pt_conf = static_cast<float>(ehy_rme_out->left_lane().left_line().pt_conf());

  ehy_rme_ptr->left_lane.left_line.c0 = static_cast<float>(ehy_rme_out->left_lane().left_line().c0());

  ehy_rme_ptr->left_lane.left_line.c1 = static_cast<float>(ehy_rme_out->left_lane().left_line().c1());

  ehy_rme_ptr->left_lane.left_line.c2 = static_cast<float>(ehy_rme_out->left_lane().left_line().c2());

  ehy_rme_ptr->left_lane.left_line.c3 = static_cast<float>(ehy_rme_out->left_lane().left_line().c3());

  ehy_rme_ptr->left_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_out->left_lane().left_line().lrange_start());

  ehy_rme_ptr->left_lane.left_line.lrange_end = static_cast<float>(ehy_rme_out->left_lane().left_line().lrange_end());

  ehy_rme_ptr->left_lane.left_line.lm_width = static_cast<float>(ehy_rme_out->left_lane().left_line().lm_width());

  ehy_rme_ptr->left_lane.left_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->left_lane().left_line().line_color()));

  ehy_rme_ptr->left_lane.left_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->left_lane().left_line().line_type()));

  ehy_rme_ptr->left_lane.left_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->left_lane().left_line().line_src()));

  ehy_rme_ptr->left_lane.right_line.pt_conf = static_cast<float>(ehy_rme_out->left_lane().right_line().pt_conf());

  ehy_rme_ptr->left_lane.right_line.c0 = static_cast<float>(ehy_rme_out->left_lane().right_line().c0());

  ehy_rme_ptr->left_lane.right_line.c1 = static_cast<float>(ehy_rme_out->left_lane().right_line().c1());

  ehy_rme_ptr->left_lane.right_line.c2 = static_cast<float>(ehy_rme_out->left_lane().right_line().c2());

  ehy_rme_ptr->left_lane.right_line.c3 = static_cast<float>(ehy_rme_out->left_lane().right_line().c3());

  ehy_rme_ptr->left_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_out->left_lane().right_line().lrange_start());

  ehy_rme_ptr->left_lane.right_line.lrange_end = static_cast<float>(ehy_rme_out->left_lane().right_line().lrange_end());

  ehy_rme_ptr->left_lane.right_line.lm_width = static_cast<float>(ehy_rme_out->left_lane().right_line().lm_width());

  ehy_rme_ptr->left_lane.right_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->left_lane().right_line().line_color()));

  ehy_rme_ptr->left_lane.right_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->left_lane().right_line().line_type()));

  ehy_rme_ptr->left_lane.right_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->left_lane().right_line().line_src()));

  int min_lflantype_size = ehy_rme_out->left_lane().lane_type().size();

  for (int lflanei = 0; lflanei < 2; lflanei++) {
    if (lflanei < min_lflantype_size) {
      ehy_rme_ptr->left_lane.lane_type[lflanei] =
        (LMLaneType_e)(static_cast<int>(ehy_rme_out->left_lane().lane_type(lflanei)));
    } else {
      ehy_rme_ptr->left_lane.lane_type[lflanei] = (LMLaneType_e)0;
    }
  }

  ehy_rme_ptr->left_lane.lane_start = static_cast<float>(ehy_rme_out->left_lane().lane_start());

  ehy_rme_ptr->left_lane.lane_end = static_cast<float>(ehy_rme_out->left_lane().lane_end());

  ehy_rme_ptr->left_lane.map_spd_limit = static_cast<float>(ehy_rme_out->left_lane().map_spd_limit());

  ehy_rme_ptr->left_lane.lane_width = static_cast<float>(ehy_rme_out->left_lane().lane_width());

  ehy_rme_ptr->left_lane.ca_lon_dst = static_cast<float>(ehy_rme_out->left_lane().ca_lon_dst());

  int left_cp_size = MIN(ehy_rme_out->left_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < 10; cpi++) {
    if (cpi < left_cp_size) {
      ehy_rme_ptr->left_lane.cur_point[cpi] = static_cast<float>(ehy_rme_out->left_lane().cur_point(cpi));
    } else {
      ehy_rme_ptr->left_lane.cur_point[cpi] = 0;
    }
  }

  int left_cv_size = MIN(ehy_rme_out->left_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < 10; cvi++) {
    if (cvi < left_cv_size) {
      ehy_rme_ptr->left_lane.cur_value[cvi] = static_cast<float>(ehy_rme_out->left_lane().cur_value(cvi));
    } else {
      ehy_rme_ptr->left_lane.cur_value[cvi] = 0;
    }
  }

  ehy_rme_ptr->left_lane.lane_dir = (LMLaneDir_e)(static_cast<int>(ehy_rme_out->left_lane().lane_dir()));

  ehy_rme_ptr->left_lane.ca_valid = static_cast<bool>(ehy_rme_out->left_lane().ca_valid());

  ehy_rme_ptr->left_lane.lane_id = static_cast<uint32_t>(ehy_rme_out->left_lane().lane_id());

  ehy_rme_ptr->right_lane.left_line.pt_conf = static_cast<float>(ehy_rme_out->right_lane().left_line().pt_conf());

  ehy_rme_ptr->right_lane.left_line.c0 = static_cast<float>(ehy_rme_out->right_lane().left_line().c0());

  ehy_rme_ptr->right_lane.left_line.c1 = static_cast<float>(ehy_rme_out->right_lane().left_line().c1());

  ehy_rme_ptr->right_lane.left_line.c2 = static_cast<float>(ehy_rme_out->right_lane().left_line().c2());

  ehy_rme_ptr->right_lane.left_line.c3 = static_cast<float>(ehy_rme_out->right_lane().left_line().c3());

  ehy_rme_ptr->right_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_out->right_lane().left_line().lrange_start());

  ehy_rme_ptr->right_lane.left_line.lrange_end = static_cast<float>(ehy_rme_out->right_lane().left_line().lrange_end());

  ehy_rme_ptr->right_lane.left_line.lm_width = static_cast<float>(ehy_rme_out->right_lane().left_line().lm_width());

  ehy_rme_ptr->right_lane.left_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->right_lane().left_line().line_color()));

  ehy_rme_ptr->right_lane.left_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->right_lane().left_line().line_type()));

  ehy_rme_ptr->right_lane.left_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->right_lane().left_line().line_src()));

  ehy_rme_ptr->right_lane.right_line.pt_conf = static_cast<float>(ehy_rme_out->right_lane().right_line().pt_conf());

  ehy_rme_ptr->right_lane.right_line.c0 = static_cast<float>(ehy_rme_out->right_lane().right_line().c0());

  ehy_rme_ptr->right_lane.right_line.c1 = static_cast<float>(ehy_rme_out->right_lane().right_line().c1());

  ehy_rme_ptr->right_lane.right_line.c2 = static_cast<float>(ehy_rme_out->right_lane().right_line().c2());

  ehy_rme_ptr->right_lane.right_line.c3 = static_cast<float>(ehy_rme_out->right_lane().right_line().c3());

  ehy_rme_ptr->right_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_out->right_lane().right_line().lrange_start());

  ehy_rme_ptr->right_lane.right_line.lrange_end =
    static_cast<float>(ehy_rme_out->right_lane().right_line().lrange_end());

  ehy_rme_ptr->right_lane.right_line.lm_width = static_cast<float>(ehy_rme_out->right_lane().right_line().lm_width());

  ehy_rme_ptr->right_lane.right_line.line_color =
    (LMColor_e)(static_cast<int>(ehy_rme_out->right_lane().right_line().line_color()));

  ehy_rme_ptr->right_lane.right_line.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->right_lane().right_line().line_type()));

  ehy_rme_ptr->right_lane.right_line.line_src =
    (LMSource_e)(static_cast<int>(ehy_rme_out->right_lane().right_line().line_src()));

  int min_rglantype_size = ehy_rme_out->right_lane().lane_type().size();

  for (int rglanei = 0; rglanei < 2; rglanei++) {
    if (rglanei < min_rglantype_size) {
      ehy_rme_ptr->right_lane.lane_type[rglanei] =
        (LMLaneType_e)(static_cast<int>(ehy_rme_out->right_lane().lane_type(rglanei)));
    } else {
      ehy_rme_ptr->right_lane.lane_type[rglanei] = (LMLaneType_e)0;
    }
  }

  ehy_rme_ptr->right_lane.lane_start = static_cast<float>(ehy_rme_out->right_lane().lane_start());

  ehy_rme_ptr->right_lane.lane_end = static_cast<float>(ehy_rme_out->right_lane().lane_end());

  ehy_rme_ptr->right_lane.map_spd_limit = static_cast<float>(ehy_rme_out->right_lane().map_spd_limit());

  ehy_rme_ptr->right_lane.lane_width = static_cast<float>(ehy_rme_out->right_lane().lane_width());

  ehy_rme_ptr->right_lane.ca_lon_dst = static_cast<float>(ehy_rme_out->right_lane().ca_lon_dst());

  int right_cp_size = MIN(ehy_rme_out->right_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < 10; cpi++) {
    if (cpi < right_cp_size) {
      ehy_rme_ptr->right_lane.cur_point[cpi] = static_cast<float>(ehy_rme_out->right_lane().cur_point(cpi));
    } else {
      ehy_rme_ptr->right_lane.cur_point[cpi] = 0;
    }
  }

  int right_cv_size = MIN(ehy_rme_out->right_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < 10; cvi++) {
    if (cvi < right_cv_size) {
      ehy_rme_ptr->right_lane.cur_value[cvi] = static_cast<float>(ehy_rme_out->right_lane().cur_value(cvi));
    } else {
      ehy_rme_ptr->right_lane.cur_value[cvi] = 0;
    }
  }

  ehy_rme_ptr->right_lane.lane_dir = (LMLaneDir_e)(static_cast<int>(ehy_rme_out->right_lane().lane_dir()));

  ehy_rme_ptr->right_lane.ca_valid = static_cast<bool>(ehy_rme_out->right_lane().ca_valid());

  ehy_rme_ptr->right_lane.lane_id = static_cast<uint32_t>(ehy_rme_out->right_lane().lane_id());

  int ngpl_size = MIN(ehy_rme_out->hdmap_info().ngp_list().size(), 20);

  for (int ngpi = 0; ngpi < 20; ngpi++) {
    if (ngpi < ngpl_size) {
      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].gp_distance =
        static_cast<float>(ehy_rme_out->hdmap_info().ngp_list(ngpi).gp_distance());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].gp_type =
        static_cast<uint32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).gp_type());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed =
        static_cast<float>(ehy_rme_out->hdmap_info().ngp_list(ngpi).recom_speed());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].link_length =
        static_cast<float>(ehy_rme_out->hdmap_info().ngp_list(ngpi).link_length());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_lane_idx =
        static_cast<uint32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).recom_lane_idx());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed_id =
        static_cast<uint32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).recom_speed_id());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed_src =
        static_cast<uint32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).recom_speed_src());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed_conf =
        static_cast<uint32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).recom_speed_conf());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].spd_unit =
        static_cast<bool>(ehy_rme_out->hdmap_info().ngp_list(ngpi).spd_unit());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].sup_sign_typ =
        static_cast<int32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).sup_sign_typ());

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].sup_sign_attr =
        static_cast<int32_t>(ehy_rme_out->hdmap_info().ngp_list(ngpi).sup_sign_attr());
    } else {
      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].gp_distance = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].gp_type = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].link_length = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_lane_idx = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed_src = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].recom_speed_conf = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].spd_unit = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].sup_sign_typ = 0;

      ehy_rme_ptr->hdmap_info.ngp_list[ngpi].sup_sign_attr = 0;
    }
  }

  int intp_size = MIN(ehy_rme_out->interest_point().size(), 20);

  for (int intpi = 0; intpi < 20; intpi++) {
    if (intpi < intp_size) {
      ehy_rme_ptr->interest_point[intpi].point.conf =
        static_cast<float>(ehy_rme_out->interest_point(intpi).point().conf());

      ehy_rme_ptr->interest_point[intpi].point.x = static_cast<float>(ehy_rme_out->interest_point(intpi).point().x());

      ehy_rme_ptr->interest_point[intpi].point.y = static_cast<float>(ehy_rme_out->interest_point(intpi).point().y());

      ehy_rme_ptr->interest_point[intpi].point.z = static_cast<float>(ehy_rme_out->interest_point(intpi).point().z());

      ehy_rme_ptr->interest_point[intpi].point.w = static_cast<float>(ehy_rme_out->interest_point(intpi).point().w());

      ehy_rme_ptr->interest_point[intpi].point.d = static_cast<float>(ehy_rme_out->interest_point(intpi).point().d());

      ehy_rme_ptr->interest_point[intpi].point.s = static_cast<float>(ehy_rme_out->interest_point(intpi).point().s());

      ehy_rme_ptr->interest_point[intpi].id = static_cast<int32_t>(ehy_rme_out->interest_point(intpi).id());

      ehy_rme_ptr->interest_point[intpi].intp_class =
        (LMIntPClass_e)(static_cast<int>(ehy_rme_out->interest_point(intpi).intp_class()));

      ehy_rme_ptr->interest_point[intpi].source =
        (LMSource_e)(static_cast<int>(ehy_rme_out->interest_point(intpi).source()));

      ehy_rme_ptr->interest_point[intpi].role = (LMRole_e)(static_cast<int>(ehy_rme_out->interest_point(intpi).role()));

      ehy_rme_ptr->interest_point[intpi].far_markclass =
        (LMLaneMarkClass_e)(static_cast<int>(ehy_rme_out->interest_point(intpi).far_markclass()));

      ehy_rme_ptr->interest_point[intpi].far_color =
        (LMColor_e)(static_cast<int>(ehy_rme_out->interest_point(intpi).far_color()));

      ehy_rme_ptr->interest_point[intpi].far_spd =
        static_cast<uint32_t>(ehy_rme_out->interest_point(intpi).intp_class());
    } else {
      ehy_rme_ptr->interest_point[intpi].point.conf = 0;

      ehy_rme_ptr->interest_point[intpi].point.x = 0;

      ehy_rme_ptr->interest_point[intpi].point.y = 0;

      ehy_rme_ptr->interest_point[intpi].point.z = 0;

      ehy_rme_ptr->interest_point[intpi].point.w = 0;

      ehy_rme_ptr->interest_point[intpi].point.d = 0;

      ehy_rme_ptr->interest_point[intpi].point.s = 0;

      ehy_rme_ptr->interest_point[intpi].id = 0;

      ehy_rme_ptr->interest_point[intpi].intp_class = (LMIntPClass_e)0;

      ehy_rme_ptr->interest_point[intpi].source = (LMSource_e)0;

      ehy_rme_ptr->interest_point[intpi].role = (LMRole_e)0;

      ehy_rme_ptr->interest_point[intpi].far_markclass = (LMLaneMarkClass_e)0;

      ehy_rme_ptr->interest_point[intpi].far_color = (LMColor_e)0;

      ehy_rme_ptr->interest_point[intpi].far_spd = 0;
    }
  }

  ehy_rme_ptr->road_start = static_cast<float>(ehy_rme_out->road_start());

  ehy_rme_ptr->road_end = static_cast<float>(ehy_rme_out->road_end());

  ehy_rme_ptr->total_lane_num = static_cast<uint32_t>(ehy_rme_out->total_lane_num());

  ehy_rme_ptr->num_lane_id = static_cast<uint32_t>(ehy_rme_out->num_lane_id());

  ehy_rme_ptr->road_type = static_cast<uint32_t>(ehy_rme_out->road_type());

  ehy_rme_ptr->status = static_cast<uint32_t>(ehy_rme_out->status());

  return true;
}

bool FCTInputAdapter::fill_ehy_tpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_out,
                                         EHYTPP*                                                 ehy_tpp_ptr) {
  ehy_tpp_ptr->tpp_trajectory.pt_conf = static_cast<float>(ehy_tpp_out->tpp_trajectory().pt_conf());

  ehy_tpp_ptr->tpp_trajectory.c0 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c0());

  ehy_tpp_ptr->tpp_trajectory.c1 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c1());

  ehy_tpp_ptr->tpp_trajectory.c2 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c2());

  ehy_tpp_ptr->tpp_trajectory.c3 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c3());

  ehy_tpp_ptr->tpp_trajectory.lrange_start = static_cast<float>(ehy_tpp_out->tpp_trajectory().lrange_start());

  ehy_tpp_ptr->tpp_trajectory.lrange_end = static_cast<float>(ehy_tpp_out->tpp_trajectory().lrange_end());

  ehy_tpp_ptr->tpp_trajectory.lm_width = static_cast<float>(ehy_tpp_out->tpp_trajectory().lm_width());

  ehy_tpp_ptr->tpp_trajectory.line_color = (LMColor_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_color()));

  ehy_tpp_ptr->tpp_trajectory.line_type =
    (LMLaneMarkClass_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_type()));

  ehy_tpp_ptr->tpp_trajectory.line_src = (LMSource_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_src()));

  ehy_tpp_ptr->latctrl_pt = static_cast<float>(ehy_tpp_out->latctrl_pt());

  ehy_tpp_ptr->longctrl_pt = static_cast<float>(ehy_tpp_out->longctrl_pt());

  ehy_tpp_ptr->shift_offset = static_cast<float>(ehy_tpp_out->shift_offset());

  ehy_tpp_ptr->act_shift_status = static_cast<uint32_t>(ehy_tpp_out->act_shift_status());

  if (ehy_tpp_out->shift_object_id_size() > 0) {
    ehy_tpp_ptr->shift_object_id = static_cast<uint32_t>(ehy_tpp_out->shift_object_id().at(0));
  } else {
    ehy_tpp_ptr->shift_object_id = static_cast<uint32_t>(0);
  }

  return true;
}

bool FCTInputAdapter::fill_ehy_lpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_out,
                                         EHYLPP*                                                 ehy_lpp_ptr) {
  ehy_lpp_ptr->trajectory.pt_conf = static_cast<float>(ehy_tpp_out->tpp_trajectory().pt_conf());

  ehy_lpp_ptr->trajectory.c0 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c0());

  ehy_lpp_ptr->trajectory.c1 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c1());

  ehy_lpp_ptr->trajectory.c2 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c2());

  ehy_lpp_ptr->trajectory.c3 = static_cast<float>(ehy_tpp_out->tpp_trajectory().c3());

  ehy_lpp_ptr->trajectory.lrange_start = static_cast<float>(ehy_tpp_out->tpp_trajectory().lrange_start());

  ehy_lpp_ptr->trajectory.lrange_end = static_cast<float>(ehy_tpp_out->tpp_trajectory().lrange_end());

  ehy_lpp_ptr->trajectory.lm_width = static_cast<float>(ehy_tpp_out->tpp_trajectory().lm_width());

  ehy_lpp_ptr->trajectory.line_color = (LMColor_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_color()));

  ehy_lpp_ptr->trajectory.line_type = (LMLaneMarkClass_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_type()));

  ehy_lpp_ptr->trajectory.line_src = (LMSource_e)(static_cast<int>(ehy_tpp_out->tpp_trajectory().line_src()));

  ehy_lpp_ptr->latctrl_pt = static_cast<float>(ehy_tpp_out->latctrl_pt());

  ehy_lpp_ptr->lonctrl_pt = static_cast<float>(ehy_tpp_out->longctrl_pt());

  ehy_lpp_ptr->shitf_offset = static_cast<float>(ehy_tpp_out->shift_offset());

  ehy_lpp_ptr->act_shift_status = static_cast<uint32_t>(ehy_tpp_out->act_shift_status());

  return true;
}

bool FCTInputAdapter::fill_ehy_tsi_input(const std::shared_ptr<nio::ad::messages::EHYTsiOutputs> ehy_tsi_out,
                                         EHYTSI*                                                 ehy_tsi_ptr) {
  int bsd_hmi_size = MIN(ehy_tsi_out->bsd_hmi_id().size(), 2);
  for (int bsdi = 0; bsdi < 2; bsdi++) {
    if (bsdi < bsd_hmi_size) {
      ehy_tsi_ptr->bsd_hmi_id[bsdi] = static_cast<uint32_t>(ehy_tsi_out->bsd_hmi_id(bsdi));
    } else {
      ehy_tsi_ptr->bsd_hmi_id[bsdi] = static_cast<uint32_t>(0);
    }
  }

  int lca_hmi_size = MIN(ehy_tsi_out->lca_hmi_id().size(), 2);
  for (int lcai = 0; lcai < 2; lcai++) {
    if (lcai < lca_hmi_size) {
      ehy_tsi_ptr->lca_hmi_id[lcai] = static_cast<uint32_t>(ehy_tsi_out->lca_hmi_id(lcai));
    } else {
      ehy_tsi_ptr->lca_hmi_id[lcai] = static_cast<uint32_t>(0);
    }
  }

  int tsi_size = MIN(ehy_tsi_out->tsi_obj().size(), 35);

  for (int tsii = 0; tsii < 35; tsii++) {
    if (tsii < tsi_size) {
      ehy_tsi_ptr->tsi_obj[tsii].id = static_cast<uint32_t>(ehy_tsi_out->tsi_obj(tsii).id());

      ehy_tsi_ptr->tsi_obj[tsii].obj_index = static_cast<uint32_t>(ehy_tsi_out->tsi_obj(tsii).obj_index());

      ehy_tsi_ptr->tsi_obj[tsii].confidence = static_cast<uint32_t>(ehy_tsi_out->tsi_obj(tsii).confidence());

      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_ccs = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_pos_ccs());

      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_vcs = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_pos_vcs());

      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_vcs_std = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_pos_vcs_std());

      ehy_tsi_ptr->tsi_obj[tsii].lon_vel = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_vel());

      ehy_tsi_ptr->tsi_obj[tsii].lon_vel_std = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_vel());

      ehy_tsi_ptr->tsi_obj[tsii].lon_acc = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lon_acc());

      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_ccs = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_pos_ccs());

      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_vcs = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_pos_vcs());

      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_vcs_std = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_pos_vcs_std());

      ehy_tsi_ptr->tsi_obj[tsii].lat_vel = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_vel());

      ehy_tsi_ptr->tsi_obj[tsii].lat_vel_std = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_vel_std());

      ehy_tsi_ptr->tsi_obj[tsii].lat_vel_ccs = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_vel_ccs());

      ehy_tsi_ptr->tsi_obj[tsii].lat_acc = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).lat_acc());

      // ehy_tsi_ptr->tsi_obj[tsii].status =
      // (TgtObjMotionStatus_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).status()));
      ehy_tsi_ptr->tsi_obj[tsii].status = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).status()));

      // ehy_tsi_ptr->tsi_obj[tsii].type = (TgtObjType_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).type()));
      ehy_tsi_ptr->tsi_obj[tsii].type = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).type()));

      // ehy_tsi_ptr->tsi_obj[tsii].valid = (TgtObjValidStatus_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).valid()));
      ehy_tsi_ptr->tsi_obj[tsii].valid = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).valid()));

      ehy_tsi_ptr->tsi_obj[tsii].age = static_cast<uint32_t>(ehy_tsi_out->tsi_obj(tsii).age());

      ehy_tsi_ptr->tsi_obj[tsii].width = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).width());

      ehy_tsi_ptr->tsi_obj[tsii].length = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).length());

      ehy_tsi_ptr->tsi_obj[tsii].height = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).height());

      ehy_tsi_ptr->tsi_obj[tsii].phi_angle = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).phi_angle());

      ehy_tsi_ptr->tsi_obj[tsii].dphi_angle_rate = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).dphi_angle_rate());

      // ehy_tsi_ptr->tsi_obj[tsii].fusion_source =
      // (TgtFusionSrc_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).fusion_source()));
      ehy_tsi_ptr->tsi_obj[tsii].fusion_source = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).fusion_source()));

      ehy_tsi_ptr->tsi_obj[tsii].ttc = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).ttc());

      // ehy_tsi_ptr->tsi_obj[tsii].blinker_info =
      // (BlinkerType_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).blinker_info()));
      ehy_tsi_ptr->tsi_obj[tsii].blinker_info = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).blinker_info()));

      ehy_tsi_ptr->tsi_obj[tsii].brake_lights = static_cast<uint32_t>(ehy_tsi_out->tsi_obj(tsii).brake_lights());

      ehy_tsi_ptr->tsi_obj[tsii].prob_lane_change = static_cast<float>(ehy_tsi_out->tsi_obj(tsii).prob_lane_change());

      // ehy_tsi_ptr->tsi_obj[tsii].dirLaneChange =
      // (TgtLaneChangeDir_e)(static_cast<int>(ehy_tsi_out->tsi_obj(tsii).dirlanechange()));
      ehy_tsi_ptr->tsi_obj[tsii].dirLaneChange = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).dirlanechange()));
      ehy_tsi_ptr->tsi_obj[tsii].ageTarInPath  = (static_cast<int>(ehy_tsi_out->tsi_obj(tsii).age_in_path()));
      ehy_tsi_ptr->tsi_obj[tsii].lane_assign_from_perception  = (static_cast<uint8_t>(ehy_tsi_out->tsi_obj(tsii).lane_assign_from_perception()));
    } else {
      ehy_tsi_ptr->tsi_obj[tsii].id               = 0;
      ehy_tsi_ptr->tsi_obj[tsii].obj_index        = 0;
      ehy_tsi_ptr->tsi_obj[tsii].confidence       = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_ccs      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_vcs      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_pos_vcs_std  = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_vel          = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_vel_std      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lon_acc          = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_ccs      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_vcs      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_pos_vcs_std  = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_vel          = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_vel_std      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_vel_ccs      = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lat_acc          = 0;
      ehy_tsi_ptr->tsi_obj[tsii].status           = 0;
      ehy_tsi_ptr->tsi_obj[tsii].type             = 0;
      ehy_tsi_ptr->tsi_obj[tsii].valid            = 0;
      ehy_tsi_ptr->tsi_obj[tsii].age              = 0;
      ehy_tsi_ptr->tsi_obj[tsii].width            = 0;
      ehy_tsi_ptr->tsi_obj[tsii].length           = 0;
      ehy_tsi_ptr->tsi_obj[tsii].height           = 0;
      ehy_tsi_ptr->tsi_obj[tsii].phi_angle        = 0;
      ehy_tsi_ptr->tsi_obj[tsii].dphi_angle_rate  = 0;
      ehy_tsi_ptr->tsi_obj[tsii].fusion_source    = 0;
      ehy_tsi_ptr->tsi_obj[tsii].ttc              = 0;
      ehy_tsi_ptr->tsi_obj[tsii].blinker_info     = 0;
      ehy_tsi_ptr->tsi_obj[tsii].brake_lights     = 0;
      ehy_tsi_ptr->tsi_obj[tsii].prob_lane_change = 0;
      ehy_tsi_ptr->tsi_obj[tsii].dirLaneChange    = 0;
      ehy_tsi_ptr->tsi_obj[tsii].ageTarInPath     = 0;
      ehy_tsi_ptr->tsi_obj[tsii].lane_assign_from_perception  = 0;
    }
  }

  int rmtsi_size = MIN(ehy_tsi_out->rm_tsi_out().size(), 32);

  for (int rm_tsii = 0; rm_tsii < 32; rm_tsii++) {
    if (rm_tsii < rmtsi_size) {
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].id = static_cast<uint32_t>(ehy_tsi_out->rm_tsi_out(rm_tsii).id());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].obj_index = static_cast<uint32_t>(ehy_tsi_out->rm_tsi_out(rm_tsii).obj_index());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].confidence =
        static_cast<uint32_t>(ehy_tsi_out->rm_tsi_out(rm_tsii).confidence());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_ccs = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_pos_ccs());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_vcs = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_pos_vcs());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_vcs_std =
        static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_pos_vcs_std());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_vel = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_vel());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_vel_std = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_vel());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_acc = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lon_acc());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_ccs = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_pos_ccs());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_vcs = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_pos_vcs());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_vcs_std =
        static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_pos_vcs_std());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_vel());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel_std = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_vel_std());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel_ccs = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_vel_ccs());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_acc = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).lat_acc());

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].status =
      // (TgtObjMotionStatus_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).status()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].status = (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).status()));

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].type =
      // (TgtObjType_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).type()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].type = (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).type()));

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].valid =
      // (TgtObjValidStatus_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).valid()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].valid = (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).valid()));

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].age = static_cast<uint32_t>(ehy_tsi_out->rm_tsi_out(rm_tsii).age());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].width = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).width());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].length = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).length());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].height = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).height());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].phi_angle = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).phi_angle());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].dphi_angle_rate =
        static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).dphi_angle_rate());

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].fusion_source =
      // (TgtFusionSrc_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).fusion_source()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].fusion_source =
        (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).fusion_source()));

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].ttc = static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).ttc());

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].blinker_info =
      // (BlinkerType_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).blinker_info()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].blinker_info =
        (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).blinker_info()));

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].brake_lights =
        static_cast<uint32_t>(ehy_tsi_out->rm_tsi_out(rm_tsii).brake_lights());

      ehy_tsi_ptr->rm_tsi_out[rm_tsii].prob_lane_change =
        static_cast<float>(ehy_tsi_out->rm_tsi_out(rm_tsii).prob_lane_change());

      // ehy_tsi_ptr->rm_tsi_out[rm_tsii].dirLaneChange =
      // (TgtLaneChangeDir_e)(static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).dirlanechange()));
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].dirLaneChange =
        (static_cast<int>(ehy_tsi_out->rm_tsi_out(rm_tsii).dirlanechange()));
    } else {
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].id               = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].obj_index        = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].confidence       = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_ccs      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_vcs      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_pos_vcs_std  = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_vel          = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_vel_std      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lon_acc          = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_ccs      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_vcs      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_pos_vcs_std  = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel          = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel_std      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_vel_ccs      = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].lat_acc          = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].status           = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].type             = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].valid            = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].age              = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].width            = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].length           = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].height           = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].phi_angle        = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].dphi_angle_rate  = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].fusion_source    = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].ttc              = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].blinker_info     = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].brake_lights     = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].prob_lane_change = 0;
      ehy_tsi_ptr->rm_tsi_out[rm_tsii].dirLaneChange    = 0;
    }
  }

  int tca_size = MIN(ehy_tsi_out->tca_out().tca_obj().size(), 15);

  for (int tcai = 0; tcai < 15; tcai++) {
    if (tcai < tca_size) {
      ehy_tsi_ptr->tca_out.tca_obj[tcai].id = static_cast<uint32_t>(ehy_tsi_out->tca_out().tca_obj(tcai).id());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].obj_index =
        static_cast<uint32_t>(ehy_tsi_out->tca_out().tca_obj(tcai).obj_index());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].confidence =
        static_cast<uint32_t>(ehy_tsi_out->tca_out().tca_obj(tcai).confidence());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_ccs =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_pos_ccs());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_vcs =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_pos_vcs());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_vcs_std =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_pos_vcs_std());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_vel = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_vel());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_vel_std =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_vel());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_acc = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lon_acc());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_ccs =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_pos_ccs());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_vcs =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_pos_vcs());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_vcs_std =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_pos_vcs_std());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_vel());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel_std =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_vel_std());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel_ccs =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_vel_ccs());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_acc = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).lat_acc());

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].status =
      // (TgtObjMotionStatus_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).status()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].status = (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).status()));

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].type =
      // (TgtObjType_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).type()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].type = (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).type()));

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].valid =
      // (TgtObjValidStatus_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).valid()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].valid = (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).valid()));

      ehy_tsi_ptr->tca_out.tca_obj[tcai].age = static_cast<uint32_t>(ehy_tsi_out->tca_out().tca_obj(tcai).age());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].width = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).width());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].length = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).length());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].height = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).height());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].phi_angle =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).phi_angle());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].dphi_angle_rate =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).dphi_angle_rate());

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].fusion_source =
      // (TgtFusionSrc_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).fusion_source()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].fusion_source =
        (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).fusion_source()));

      ehy_tsi_ptr->tca_out.tca_obj[tcai].ttc = static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).ttc());

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].blinker_info =
      // (BlinkerType_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).blinker_info()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].blinker_info =
        (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).blinker_info()));

      ehy_tsi_ptr->tca_out.tca_obj[tcai].brake_lights =
        static_cast<uint32_t>(ehy_tsi_out->tca_out().tca_obj(tcai).brake_lights());

      ehy_tsi_ptr->tca_out.tca_obj[tcai].prob_lane_change =
        static_cast<float>(ehy_tsi_out->tca_out().tca_obj(tcai).prob_lane_change());

      // ehy_tsi_ptr->tca_out.tca_obj[tcai].dirLaneChange =
      // (TgtLaneChangeDir_e)(static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).dirlanechange()));
      ehy_tsi_ptr->tca_out.tca_obj[tcai].dirLaneChange =
        (static_cast<int>(ehy_tsi_out->tca_out().tca_obj(tcai).dirlanechange()));
    } else {
      ehy_tsi_ptr->tca_out.tca_obj[tcai].id               = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].obj_index        = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].confidence       = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_ccs      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_vcs      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_pos_vcs_std  = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_vel          = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_vel_std      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lon_acc          = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_ccs      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_vcs      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_pos_vcs_std  = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel          = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel_std      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_vel_ccs      = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].lat_acc          = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].status           = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].type             = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].valid            = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].age              = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].width            = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].length           = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].height           = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].phi_angle        = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].dphi_angle_rate  = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].fusion_source    = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].ttc              = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].blinker_info     = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].brake_lights     = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].prob_lane_change = 0;
      ehy_tsi_ptr->tca_out.tca_obj[tcai].dirLaneChange    = 0;
    }
  }

  ehy_tsi_ptr->tca_out.valid_tgt_num = static_cast<uint32_t>(ehy_tsi_out->tca_out().valid_tgt_num());

  ehy_tsi_ptr->tsi_status = static_cast<uint32_t>(ehy_tsi_out->tsi_status());

  ehy_tsi_ptr->tsi_flg_cipvlost = static_cast<bool>(ehy_tsi_out->tsi_flg_cipvlost());

  ehy_tsi_ptr->tsi_ego_lane_changed = static_cast<bool>(ehy_tsi_out->tsi_ego_lane_changed());

  ehy_tsi_ptr->svc_frnt_obstacle_status = static_cast<uint32_t>(ehy_tsi_out->svc_frnt_obstacle_status());

  return true;
}

bool FCTInputAdapter::fill_ehy_tse_input(const std::shared_ptr<nio::ad::messages::EHYTseOutputs> ehy_tse_out,
                                         EHYTSE*                                                 ehy_tse_ptr) {
  int tse_size = MIN(ehy_tse_out->tse_obj().size(), 4);

  for (int tsei = 0; tsei < 4; tsei++) {
    if (tsei < tse_size) {
      ehy_tse_ptr->tse_obj[tsei].id = static_cast<uint32_t>(ehy_tse_out->tse_obj(tsei).id());

      ehy_tse_ptr->tse_obj[tsei].obj_index = static_cast<uint32_t>(ehy_tse_out->tse_obj(tsei).obj_index());

      ehy_tse_ptr->tse_obj[tsei].confidence = static_cast<uint32_t>(ehy_tse_out->tse_obj(tsei).confidence());

      ehy_tse_ptr->tse_obj[tsei].lon_pos_ccs = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_pos_ccs());

      ehy_tse_ptr->tse_obj[tsei].lon_pos_vcs = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_pos_vcs());

      ehy_tse_ptr->tse_obj[tsei].lon_pos_vcs_std = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_pos_vcs_std());

      ehy_tse_ptr->tse_obj[tsei].lon_vel = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_vel());

      ehy_tse_ptr->tse_obj[tsei].lon_vel_std = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_vel());

      ehy_tse_ptr->tse_obj[tsei].lon_acc = static_cast<float>(ehy_tse_out->tse_obj(tsei).lon_acc());

      ehy_tse_ptr->tse_obj[tsei].lat_pos_ccs = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_pos_ccs());

      ehy_tse_ptr->tse_obj[tsei].lat_pos_vcs = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_pos_vcs());

      ehy_tse_ptr->tse_obj[tsei].lat_pos_vcs_std = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_pos_vcs_std());

      ehy_tse_ptr->tse_obj[tsei].lat_vel = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_vel());

      ehy_tse_ptr->tse_obj[tsei].lat_vel_std = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_vel_std());

      ehy_tse_ptr->tse_obj[tsei].lat_vel_ccs = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_vel_ccs());

      ehy_tse_ptr->tse_obj[tsei].lat_acc = static_cast<float>(ehy_tse_out->tse_obj(tsei).lat_acc());

      // ehy_tse_ptr->tse_obj[tsei].status =
      // (TgtObjMotionStatus_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).status()));
      ehy_tse_ptr->tse_obj[tsei].status = (static_cast<int>(ehy_tse_out->tse_obj(tsei).status()));

      // ehy_tse_ptr->tse_obj[tsei].type = (TgtObjType_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).type()));
      ehy_tse_ptr->tse_obj[tsei].type = (static_cast<int>(ehy_tse_out->tse_obj(tsei).type()));

      // ehy_tse_ptr->tse_obj[tsei].valid = (TgtObjValidStatus_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).valid()));
      ehy_tse_ptr->tse_obj[tsei].valid = (static_cast<int>(ehy_tse_out->tse_obj(tsei).valid()));

      ehy_tse_ptr->tse_obj[tsei].age = static_cast<uint32_t>(ehy_tse_out->tse_obj(tsei).age());

      ehy_tse_ptr->tse_obj[tsei].width = static_cast<float>(ehy_tse_out->tse_obj(tsei).width());

      ehy_tse_ptr->tse_obj[tsei].length = static_cast<float>(ehy_tse_out->tse_obj(tsei).length());

      ehy_tse_ptr->tse_obj[tsei].height = static_cast<float>(ehy_tse_out->tse_obj(tsei).height());

      ehy_tse_ptr->tse_obj[tsei].phi_angle = static_cast<float>(ehy_tse_out->tse_obj(tsei).phi_angle());

      ehy_tse_ptr->tse_obj[tsei].dphi_angle_rate = static_cast<float>(ehy_tse_out->tse_obj(tsei).dphi_angle_rate());

      // ehy_tse_ptr->tse_obj[tsei].fusion_source =
      // (TgtFusionSrc_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).fusion_source()));
      ehy_tse_ptr->tse_obj[tsei].fusion_source = (static_cast<int>(ehy_tse_out->tse_obj(tsei).fusion_source()));

      ehy_tse_ptr->tse_obj[tsei].ttc = static_cast<float>(ehy_tse_out->tse_obj(tsei).ttc());

      // ehy_tse_ptr->tse_obj[tsei].blinker_info =
      // (BlinkerType_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).blinker_info()));
      ehy_tse_ptr->tse_obj[tsei].blinker_info = (static_cast<int>(ehy_tse_out->tse_obj(tsei).blinker_info()));

      ehy_tse_ptr->tse_obj[tsei].brake_lights = static_cast<uint32_t>(ehy_tse_out->tse_obj(tsei).brake_lights());

      ehy_tse_ptr->tse_obj[tsei].prob_lane_change = static_cast<float>(ehy_tse_out->tse_obj(tsei).prob_lane_change());

      // ehy_tse_ptr->tse_obj[tsei].dirLaneChange =
      // (TgtLaneChangeDir_e)(static_cast<int>(ehy_tse_out->tse_obj(tsei).dirlanechange()));
      ehy_tse_ptr->tse_obj[tsei].dirLaneChange = (static_cast<int>(ehy_tse_out->tse_obj(tsei).dirlanechange()));
      ehy_tse_ptr->tse_obj[tsei].ageTarInPath  = (static_cast<int>(ehy_tse_out->tse_obj(tsei).age_in_path()));
    } else {
      ehy_tse_ptr->tse_obj[tsei].id               = 0;
      ehy_tse_ptr->tse_obj[tsei].obj_index        = 0;
      ehy_tse_ptr->tse_obj[tsei].confidence       = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_pos_ccs      = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_pos_vcs      = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_pos_vcs_std  = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_vel          = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_vel_std      = 0;
      ehy_tse_ptr->tse_obj[tsei].lon_acc          = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_pos_ccs      = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_pos_vcs      = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_pos_vcs_std  = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_vel          = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_vel_std      = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_vel_ccs      = 0;
      ehy_tse_ptr->tse_obj[tsei].lat_acc          = 0;
      ehy_tse_ptr->tse_obj[tsei].status           = 0;
      ehy_tse_ptr->tse_obj[tsei].type             = 0;
      ehy_tse_ptr->tse_obj[tsei].valid            = 0;
      ehy_tse_ptr->tse_obj[tsei].age              = 0;
      ehy_tse_ptr->tse_obj[tsei].width            = 0;
      ehy_tse_ptr->tse_obj[tsei].length           = 0;
      ehy_tse_ptr->tse_obj[tsei].height           = 0;
      ehy_tse_ptr->tse_obj[tsei].phi_angle        = 0;
      ehy_tse_ptr->tse_obj[tsei].dphi_angle_rate  = 0;
      ehy_tse_ptr->tse_obj[tsei].fusion_source    = 0;
      ehy_tse_ptr->tse_obj[tsei].ttc              = 0;
      ehy_tse_ptr->tse_obj[tsei].blinker_info     = 0;
      ehy_tse_ptr->tse_obj[tsei].brake_lights     = 0;
      ehy_tse_ptr->tse_obj[tsei].prob_lane_change = 0;
      ehy_tse_ptr->tse_obj[tsei].dirLaneChange    = 0;
      ehy_tse_ptr->tse_obj[tsei].ageTarInPath     = 0;
    }
  }

  ehy_tse_ptr->tsi_flg_cipv_lost = static_cast<bool>(ehy_tse_out->tsi_flg_cipv_lost());

  return true;
}

bool FCTInputAdapter::fill_obf_input(const std::shared_ptr<proto::PerceptionObjects> obf_info,
                                     std::vector<feature::ehy::Object>* fusion_object_ptr, EHYOBF* ehy_obf_ptr) {

  ehy_obf_ptr->ehyobfout.obf_rear_object_detected = static_cast<bool>(obf_info->rear_objects_detected());
  fusion_object_ptr->clear();
  int min_size = MIN(kNumFusionObject, obf_info->objects_size());
  cone_num cone_num_;

  for (int obf_i = 0; obf_i < min_size; obf_i++) {
    if (obf_i <= obf_info->objects_size()) {
      feature::ehy::Object tmp_obf;
      tmp_obf.ID = obf_info->objects(obf_i).id();
      fusion_object_ptr->push_back(tmp_obf);
      if (nio::planner::ObstacleType::CONE ==
              static_cast<nio::planner::ObstacleType>(
                  obf_info->objects(obf_i).type()) &&
          obf_info->objects(obf_i).position().x() < kMaxConeDistance &&
          obf_info->objects(obf_i).position().x() > kMinConeDistance) {
        const nio::planner::OBJLaneAssignment ObjLaneAssignment =
            static_cast<nio::planner::OBJLaneAssignment>(
                obf_info->objects(obf_i).lane_assignment_from_perception());
        if (nio::planner::OBJLaneAssignment::OBJLaneAssignment_Left ==
                ObjLaneAssignment ||
            nio::planner::OBJLaneAssignment::OBJLaneAssignment_Host_Left_Line ==
                ObjLaneAssignment) {
          cone_num_.left_lane++;
        } else if (nio::planner::OBJLaneAssignment::OBJLaneAssignment_Right ==
                       ObjLaneAssignment ||
                   nio::planner::OBJLaneAssignment::
                           OBJLaneAssignment_Host_Right_Line ==
                       ObjLaneAssignment) {
          cone_num_.right_lane++;
        }
      }
    }
  }
  if (cone_num_.left_lane >= kMaxConenum) {
    ehy_obf_ptr->ehyobfout.construction_valid.left_lane = true;
  } else if (cone_num_.left_lane == 0) {
    ehy_obf_ptr->ehyobfout.construction_valid.left_lane = false;
  }
  if (cone_num_.right_lane >= kMaxConenum) {
    ehy_obf_ptr->ehyobfout.construction_valid.right_lane = true;
  } else if (cone_num_.right_lane == 0) {
    ehy_obf_ptr->ehyobfout.construction_valid.right_lane = false;
  }

  if (ehy_obf_ptr->ehyobfout.construction_valid.left_lane || ehy_obf_ptr->ehyobfout.construction_valid.right_lane
      || (construction_wti_cnt > 0 && construction_wti_cnt < kNextConstructionConditionTime)) {
    construction_wti_cnt++;
    if (construction_wti_cnt >= kOneConstructionConditionTime) {
      construction_wti_cnt = 0;
    }
  } else {
    construction_wti_cnt = 0;
  }

  if (construction_wti_cnt > 0) {
    ehy_obf_ptr->ehyobfout.construction_wti = true;
  } else {
    ehy_obf_ptr->ehyobfout.construction_wti = false;
  }

  return true;
}

bool FCTInputAdapter::fill_veh10ms_input(const std::shared_ptr<proto::CarInfo> fct_vehicle_input, VEHDYN* vehdyn_ptr,
                                         VEHWHL* vehwhl_ptr, VEHPT* vehpt_ptr, VEHCTRL* vehctrl_ptr, STRSYS* strsys_ptr,
                                         BRKSYS* brksys_ptr, std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // vehicledynamic
  // float
  /*
  union {
    unsigned long ul;
    unsigned int  dw[2];
  } ul2dw;
  ul2dw.ul              = vehicle_info_10ms->publish_ts();
  FCT_TimestampsLow_mp  = ul2dw.dw[0];
  FCT_TimestampsHigh_mp = ul2dw.dw[1];
  */

  // vehupa_ptr->UsRegnDst[0].RegnDst[1] = vehicle_info_50ms->np_upa_info().usregndst()[0].regndst()[1];
  // vehupa_ptr->UsRegnDst[0].RegnDst[2] = vehicle_info_50ms->np_upa_info().usregndst()[0].regndst()[2];
  // vehupa_ptr->UsRegnDst[0].RegnDst[3] = vehicle_info_50ms->np_upa_info().usregndst()[0].regndst()[3];
  vehdyn_ptr->dYawRateDpss = fct_vehicle_input->np_vehicle_dyn_info().yawratests();
  vehdyn_ptr->LatAg        = fct_vehicle_input->np_vehicle_dyn_info().latsaeag();
  vehdyn_ptr->LatAmpss     = fct_vehicle_input->np_vehicle_dyn_info().latsaeampss();
  vehdyn_ptr->LgtAg        = fct_vehicle_input->np_vehicle_dyn_info().lgtsaeag();
  vehdyn_ptr->LgtAmpss     = fct_vehicle_input->np_vehicle_dyn_info().lgtsaeampss();
  vehdyn_ptr->VehOdom      = fct_vehicle_input->np_vehicle_dyn_info().vehodom();
  vehdyn_ptr->YawRateDps   = fct_vehicle_input->np_vehicle_dyn_info().yawratesaedps();
  vehdyn_ptr->YawRateRps   = fct_vehicle_input->np_vehicle_dyn_info().yawratesaerps();
  // struct
  vehdyn_ptr->AxAyYrsCalSts = static_cast<ImuCalSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().axayyrscalsts()));
  vehdyn_ptr->LatASts       = static_cast<ImuSigalSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().latasts()));
  vehdyn_ptr->LgtASts       = static_cast<ImuSigalSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().lgtasts()));

  vehdyn_ptr->VehSpd.VehSpdASILD = fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdasild();
  vehdyn_ptr->VehSpd.VehDispSpd  = fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehdispspd();
  vehdyn_ptr->VehSpd.VehSpdmps   = fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdmps();
  vehdyn_ptr->VehSpd.VehDispdSpdUnit = false;
  //vehdyn_ptr->VehSpd.VehDispdSpdUnit  = static_cast<bool>(fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehdispdspdunit());
  // save vehicle speed
  ioadapter->getInputManager().vehdispspd = vehdyn_ptr->VehSpd.VehDispSpd;
  ioadapter->getInputManager().vehSpdKph = fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdkph();
  vehdyn_ptr->VehSpd.VehSpdkph   = fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdkph();
  vehdyn_ptr->VehSpd.VehSpdSts =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdsts()));
  vehdyn_ptr->VehSpd.VehSpdASILDSts =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehspdasildsts()));
  vehdyn_ptr->VehSpd.VehMovgDir =
    static_cast<VehMovDir_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().vehspd().vehmovgdir()));

  vehdyn_ptr->YawRateSts = static_cast<ImuSigalSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_dyn_info().yawratests()));
  /*
    // vehicledrive
    vehdrvr_ptr->AdFunCfg.AEBOnOffReq =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().aebonoffreq()));
    vehdrvr_ptr->AdFunCfg.CDCFailSts =
      static_cast<CdcFailSt_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().cdcfailsts()));
    vehdrvr_ptr->AdFunCfg.DASTactileOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().dastactileonoff()));
    vehdrvr_ptr->AdFunCfg.DrvAlertSysOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().drvalertsysonoff()));
    vehdrvr_ptr->AdFunCfg.FCTAOnOffCmd =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().fctaonoffcmd()));
    vehdrvr_ptr->AdFunCfg.FCWSetReq =
      static_cast<FcwSet_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().fcwsetreq()));
    vehdrvr_ptr->AdFunCfg.GoNotifierOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().gonotifieronoff()));
    vehdrvr_ptr->AdFunCfg.LCAOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lcaonoff()));
    vehdrvr_ptr->AdFunCfg.LCATctlWarnOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lcatctlwarnonoff()));
    vehdrvr_ptr->AdFunCfg.LKAStrSprtLvlSet = static_cast<LkaStrSprtLvl_e>(static_cast<int>(0));
    vehdrvr_ptr->AdFunCfg.LnAssistTctlOnOff =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lnassisttctlonoff()));

    vehdrvr_ptr->AdFunCfg.RCTABReq =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().rctabreq()));
    vehdrvr_ptr->AdFunCfg.RCTAReq =
      static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().rctareq()));
    vehdrvr_ptr->AdFunCfg.SAPAPrkgModReq =
      static_cast<SapaPrkMod_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().sapaprkgmodreq()));
    vehdrvr_ptr->AdFunCfg.SetHMA =
      static_cast<HmaOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().sethma()));
    vehdrvr_ptr->AdFunCfg.SetLaneAssiSnvty =
      static_cast<LnAssistSnvty_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().setlaneassisnvty()));
    vehdrvr_ptr->AdFunCfg.SetLnAssiAidTyp =
      static_cast<LnAssistAid_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().setlnassiaidtyp()));
    vehdrvr_ptr->AdFunCfg.ACCTauGapStored =
      static_cast<TauGap_e>(static_cast<int>(vehicle_info_50ms->drvin().da_taugap_stored()));

    vehdrvr_ptr->FogLiPushSwtSts =
      static_cast<FogLiSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().foglipushswtsts()));
    vehdrvr_ptr->FogLiSCMCmd = static_cast<FogLiCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().fogliscmcmd()));
    vehdrvr_ptr->FrntWiprInterSpd =
      static_cast<WiprSpdSet_e>(static_cast<int>(vehicle_info_50ms->drvin().frntwiprinterspd()));
    vehdrvr_ptr->FrntWiprSwtSts =
    static_cast<WiprSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().frntwiprswtsts())); vehdrvr_ptr->HiBeamSCMCmd
    = static_cast<HiBmCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().hibeamscmcmd())); vehdrvr_ptr->HiBeamSwtSts   =
    static_cast<HiBeamSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().hibeamswtsts())); vehdrvr_ptr->NavCtryCod =
    vehicle_info_50ms->drvin().navctrycod(); vehdrvr_ptr->NaviCurrentRoadTyp =
      static_cast<NaviCrrntRd_e>(static_cast<int>(vehicle_info_50ms->drvin().navicurrentroadtyp()));
    vehdrvr_ptr->NaviSpdLim = vehicle_info_50ms->drvin().navispdlim();
    vehdrvr_ptr->NaviSpdLimSts =
      static_cast<NaviSpdLimSt_e>(static_cast<int>(vehicle_info_50ms->drvin().navispdlimsts()));
    vehdrvr_ptr->NaviSpdUnit  = static_cast<NaviSpdUnit_e>(static_cast<int>(vehicle_info_50ms->drvin().navispdunit()));
    vehdrvr_ptr->ReWiprSCMCmd = static_cast<ReWiprCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().rewiprscmcmd()));
    vehdrvr_ptr->SCMFailSts   = static_cast<ScmFailSt_e>(static_cast<int>(vehicle_info_50ms->drvin().scmfailsts()));

    for (int i = 0; i < vehicle_info_50ms->drvin().strwhl_switch_req().adupswtsts().size(); i++) {
      vehdrvr_ptr->StrWhlSwtch.AdUpSwtSts[i] =
        static_cast<SwcSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().strwhl_switch_req().adupswtsts()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->drvin().strwhl_switch_req().enupswtsts().size(); i++) {
      vehdrvr_ptr->StrWhlSwtch.EnUpSwtSts[i] =
        static_cast<SwcSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().strwhl_switch_req().enupswtsts()[i]));
    }

    vehdrvr_ptr->SVCAvl = static_cast<SvcAvl_e>(static_cast<int>(vehicle_info_50ms->drvin().svcavl()));
    vehdrvr_ptr->TurnIndcrSwtSts =
      static_cast<TrnIndcrSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().turnindcrswtsts()));
    vehdrvr_ptr->WiprAutoSwtSts =
      static_cast<WiprAutoSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wiprautoswtsts()));
    vehdrvr_ptr->WshrReWiprSwtSts =
      static_cast<WshrReWiprSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wshrrewiprswtsts()));
    vehdrvr_ptr->WTIDispSt = static_cast<WtiDispSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wtidispst()));
    vehdrvr_ptr->AdFunCfg.SetDA_SpeedAssist =
      static_cast<AdFunOnOff_e>(vehicle_info_50ms->drvin().adfuncfg().setda_speedassist());
    vehdrvr_ptr->AdFunCfg.SetDA_SteerAssist =
      static_cast<SetDA_StrAssType_e>(vehicle_info_50ms->drvin().adfuncfg().setda_steerassist());
    vehdrvr_ptr->TowModActv      = static_cast<TowModActv_e>(vehicle_info_50ms->drvin().adfuncfg().towmodactv());
    vehdrvr_ptr->ELKSwtSts       = vehicle_info_50ms->drvin().adfuncfg().elkswtsts();
    vehdrvr_ptr->AdFunCfg.SetALC = static_cast<AlcCnfrm_e>(vehicle_info_50ms->drvin().adfuncfg().setda_alcs());
    vehdrvr_ptr->AdFunCfg.SetSpeedCtrlSts =
      static_cast<SetSpeedCtrlSts_e>(vehicle_info_50ms->drvin().adfuncfg().setspeedctrlsts());
    vehdrvr_ptr->AdFunCfg.CurveSpeedAssist =
      static_cast<CurveSpeedAssistSts_e>(vehicle_info_50ms->drvin().adfuncfg().curvespeedassist());
    vehdrvr_ptr->AdFunCfg.SetSWF = static_cast<SetSWFType_e>(vehicle_info_50ms->drvin().adfuncfg().setswf());
    vehdrvr_ptr->SwtichDA_NOP    = static_cast<bool>(vehicle_info_50ms->drvin().adfuncfg().swtichda_nop());
    vehdrvr_ptr->SetDA_SetSpdOffs         =
    static_cast<SetDA_SetSpdOffs_e>(vehicle_info_50ms->drvin().adfuncfg().setda_setspdoffs());
    vehdrvr_ptr->SetDA_SetSpdOffsValue    =
    static_cast<int32_t>(vehicle_info_50ms->drvin().adfuncfg().setda_setspdoffsvalue());
  */
  // vehiclewheel
  for (int i = 0; i < fct_vehicle_input->np_wheel_info().whldyn().size(); i++) {
    vehwhl_ptr->WhlDyn[i].WhlPlsCntr = fct_vehicle_input->np_wheel_info().whldyn()[i].whlplscntr();
    vehwhl_ptr->WhlDyn[i].WhlSpd     = fct_vehicle_input->np_wheel_info().whldyn()[i].whlspd();
    vehwhl_ptr->WhlDyn[i].WhlPlsCntrVld =
      static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_wheel_info().whldyn()[i].whlplscntrvld()));
    vehwhl_ptr->WhlDyn[i].WhlSpdMovgDir =
      static_cast<WhlSpdDir_e>(static_cast<int>(fct_vehicle_input->np_wheel_info().whldyn()[i].whlspdmovgdir()));
    vehwhl_ptr->WhlDyn[i].WhlSpdSts =
      static_cast<WhlSpdSts_e>(static_cast<int>(fct_vehicle_input->np_wheel_info().whldyn()[i].whlspdsts()));
  }

  for (int i = 0; i < fct_vehicle_input->np_wheel_info().whltpms().size(); i++) {
    vehwhl_ptr->WHlTpms[i].BatSts        = fct_vehicle_input->np_wheel_info().whltpms()[i].batsts();
    vehwhl_ptr->WHlTpms[i].DeltaPressSts = fct_vehicle_input->np_wheel_info().whltpms()[i].deltapresssts();
    vehwhl_ptr->WHlTpms[i].Press         = fct_vehicle_input->np_wheel_info().whltpms()[i].press();
    vehwhl_ptr->WHlTpms[i].PressSts =
      static_cast<WhlTp_e>(static_cast<int>(fct_vehicle_input->np_wheel_info().whltpms()[i].presssts()));
    vehwhl_ptr->WHlTpms[i].SnsrFailSts = fct_vehicle_input->np_wheel_info().whltpms()[i].snsrfailsts();
    vehwhl_ptr->WHlTpms[i].Temp        = fct_vehicle_input->np_wheel_info().whltpms()[i].temp();
    vehwhl_ptr->WHlTpms[i].TempSts     = fct_vehicle_input->np_wheel_info().whltpms()[i].tempsts();
  }

  // vehicleupa

  // vehiclesuspension

  // vehiclept
  vehpt_ptr->AccrPedal.EfcPosnVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().accrpedal().efcposnvld()));
  vehpt_ptr->AccrPedal.EfcPosn = fct_vehicle_input->np_powertrain_info().accrpedal().efcposn();
  vehpt_ptr->AccrPedal.ActPosnVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().accrpedal().actposnvld()));
  vehpt_ptr->AccrPedal.ActPosn  = fct_vehicle_input->np_powertrain_info().accrpedal().actposn();
  vehpt_ptr->AccrPedal.PedlOvrd = fct_vehicle_input->np_powertrain_info().accrpedal().pedlovrd();

  vehpt_ptr->CruiseStatus      = static_cast<VcuCruiseSt_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().cruisestatus()));
  vehpt_ptr->CruiseStoredSpeed = fct_vehicle_input->np_powertrain_info().cruisestoredspeed();
  // vehpt_ptr->CTABrkAvl         = fct_vehicle_input->np_powertrain_info().ctabrkavl();

  vehpt_ptr->Gear.ActGear    = fct_vehicle_input->np_powertrain_info().gear().actgear();
  vehpt_ptr->Gear.SlctrPosn  = fct_vehicle_input->np_powertrain_info().gear().slctrposn();
  vehpt_ptr->Gear.TrgtGear   = fct_vehicle_input->np_powertrain_info().gear().trgtgear();
  vehpt_ptr->Gear.ActGearVld = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().gear().actgearvld()));
  vehpt_ptr->Gear.SlctrPosnVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().gear().slctrposnvld()));
  vehpt_ptr->Gear.TrgtGearVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().gear().trgtgearvld()));

  for (int i = 0; i < fct_vehicle_input->np_powertrain_info().motor().size(); i++) {
    vehpt_ptr->Motor[i].ActMotTq = fct_vehicle_input->np_powertrain_info().motor()[i].actmottq();
    vehpt_ptr->Motor[i].ActMotTqVld =
      static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().motor()[i].actmottqvld()));
    vehpt_ptr->Motor[i].IntdMotTq = fct_vehicle_input->np_powertrain_info().motor()[i].intdmottq();
    vehpt_ptr->Motor[i].IntdMotTqVld =
      static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().motor()[i].intdmottqvld()));
    vehpt_ptr->Motor[i].MotSpd = fct_vehicle_input->np_powertrain_info().motor()[i].motspd();
    vehpt_ptr->Motor[i].MotSpdVld =
      static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().motor()[i].motspdvld()));
  }

  vehpt_ptr->VCUBrkLampReq = fct_vehicle_input->np_powertrain_info().vcubrklampreq();
  vehpt_ptr->VCUEPBReq     = static_cast<VcuEpbReq_e>(static_cast<int>(fct_vehicle_input->np_powertrain_info().vcuepbreq()));
  // vehpt_ptr->VCUHealthMngt1 = fct_vehicle_input->np_powertrain_info().vcuhealthmngt1();
  vehpt_ptr->VCUPtWakeupReq = fct_vehicle_input->np_powertrain_info().vcuptwakeupreq();
  vehpt_ptr->VCURvsLampReq  = fct_vehicle_input->np_powertrain_info().vcurvslampreq();
  // vehpt_ptr->VCUTqAvl       = fct_vehicle_input->np_powertrain_info().vcutqavl();

  // vehiclecontrol
  vehctrl_ptr->LatCtrlIf.DAIAvl = fct_vehicle_input->np_vehicle_ctrl_info().latctrlif().daiavl();
  vehctrl_ptr->LatCtrlIf.HIAvl  = fct_vehicle_input->np_vehicle_ctrl_info().latctrlif().hiavl();
  vehctrl_ptr->LatCtrlIf.PAIAvl = fct_vehicle_input->np_vehicle_ctrl_info().latctrlif().paiavl();
  vehctrl_ptr->LatCtrlIf.TOIAvl = fct_vehicle_input->np_vehicle_ctrl_info().latctrlif().toiavl();
  vehctrl_ptr->LatCtrlIf.ActvExtIf =
    static_cast<StrActvIf_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().latctrlif().actvextif()));

  vehctrl_ptr->LngCtrlIf.VLCActv      = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vlcactv();
  vehctrl_ptr->LngCtrlIf.VLCAvl       = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vlcavl();
  vehctrl_ptr->LngCtrlIf.VLCTarDecel  = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vlctardecel();
  vehctrl_ptr->LngCtrlIf.AutoBrkgActv = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().autobrkgactv();
  vehctrl_ptr->LngCtrlIf.AutoBrkgAvl  = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().autobrkgavl();
  vehctrl_ptr->LngCtrlIf.LLCFctSt =
    static_cast<LlcFctSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().llcfctst()));
  vehctrl_ptr->LngCtrlIf.LLCIntrrptErrTyp =
    static_cast<LlcIntrptErr_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().llcintrrpterrtyp()));
  vehctrl_ptr->LngCtrlIf.ADTSts =
    static_cast<AdtSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().adtsts()));
  vehctrl_ptr->LngCtrlIf.HldLampReq =
    static_cast<HldLampReq_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().hldlampreq()));
  vehctrl_ptr->LngCtrlIf.VMCLgtDecCp = static_cast<float>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vmclgtdeccp());
  vehctrl_ptr->LngCtrlIf.FCC1_ForceFctEna = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_forcefctena();
  vehctrl_ptr->LngCtrlIf.FCC1_BrkReqEna   = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_brkreqena();
  vehctrl_ptr->LngCtrlIf.FCC1_TarBrkFReq  = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_tarbrkfreq();
  vehctrl_ptr->LngCtrlIf.FCC1_VehHldReq   = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_vehhldreq();
  vehctrl_ptr->LngCtrlIf.FCC1_VLCActv     = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_vlcactv();
  vehctrl_ptr->LngCtrlIf.RVMCLgtDecCp     = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().rvmclgtdeccp();
  vehctrl_ptr->LngCtrlIf.RVMCLgtSts       = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().rvmclgtsts();
  vehctrl_ptr->LngCtrlIf.VMCLgtAccCp      = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vmclgtacccp();
  vehctrl_ptr->LngCtrlIf.VMCLgtSts        = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vmclgtsts();
  vehctrl_ptr->LngCtrlIf.VCUCruiseCtrlMod =
    static_cast<CruiseCtrlMod_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vcucruisectrlmod()));
  vehctrl_ptr->LngCtrlIf.VMCBrkOvrd =
    static_cast<VMCBrkOvrd_e>(static_cast<int>(fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vmcbrkovrd()));
  vehctrl_ptr->LngCtrlIf.FCC1_VMCLLCSts = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().fcc1_vmcllcsts();
  vehctrl_ptr->LngCtrlIf.VCU_VMCLLCSts  = fct_vehicle_input->np_vehicle_ctrl_info().lngctrlif().vcu_vmcllcsts();

  /*
    // vehiclebody
    vehbody_ptr->AmbTemp      = vehicle_info_50ms->vehbody().ambtemp();
    vehbody_ptr->AmbTempValid = vehicle_info_50ms->vehbody().ambtempvalid();
    vehbody_ptr->CenLockSts   = static_cast<CenLockSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().cenlocksts()));
    vehbody_ptr->CrashDetd    = vehicle_info_50ms->vehbody().crashdetd();

    for (int i = 0; i < vehicle_info_50ms->vehbody().door().doorajarsts().size(); i++) {
      vehbody_ptr->Door.DoorAjarSts[i] =
        static_cast<DoorAjarSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().door().doorajarsts()[i]));
    }
    vehbody_ptr->Door.HoodAjarSts = vehicle_info_50ms->vehbody().door().hoodajarsts();
    vehbody_ptr->Door.TrAjarSts   = vehicle_info_50ms->vehbody().door().trajarsts();

    vehbody_ptr->DrvState    = static_cast<DrvSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().drvstate()));
    vehbody_ptr->IntrTemp    = vehicle_info_50ms->vehbody().intrtemp();
    vehbody_ptr->IntrTempVld = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info_50ms->vehbody().intrtempvld()));

    vehbody_ptr->LightSts.HzrdWarnSts =
      static_cast<HzrdLiSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().hzrdwarnsts()));
    vehbody_ptr->LightSts.LiSnsrData    = vehicle_info_50ms->vehbody().lightsts().lisnsrdata();
    vehbody_ptr->LightSts.LiSnsrFailSts = vehicle_info_50ms->vehbody().lightsts().lisnsrfailsts();
    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().foglists().size(); i++) {
      vehbody_ptr->LightSts.FogLiSts[i] =
        static_cast<FogLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().foglists()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().beamsts().size(); i++) {
      vehbody_ptr->LightSts.BeamSts[i] =
        static_cast<BeamSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().beamsts()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().turnindcrlists().size(); i++) {
      vehbody_ptr->LightSts.TurnIndcrLiSts[i] =
        static_cast<TurnLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().turnindcrlists()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().mirrligtsts().size(); i++) {
      vehbody_ptr->LightSts.MirrLigtSts[i] =
        static_cast<MirrLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().mirrligtsts()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().foglifctactvsts().size(); i++) {
      vehbody_ptr->LightSts.FogLiFctActvSts[i] =
        static_cast<FogLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().foglifctactvsts()[i]));
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().dowwarnamblests().size(); i++) {
      vehbody_ptr->LightSts.DowWarnAmbLeSts[i] = vehicle_info_50ms->vehbody().lightsts().dowwarnamblests()[i];
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().lgterrbrkli().size(); i++) {
      vehbody_ptr->LightSts.LgtErrBrkLi[i] = vehicle_info_50ms->vehbody().lightsts().lgterrbrkli()[i];
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().lgterrturnindcn().size(); i++) {
      vehbody_ptr->LightSts.LgtErrTurnIndcn[i] = vehicle_info_50ms->vehbody().lightsts().lgterrturnindcn()[i];
    }

    vehbody_ptr->MaiLiSet   = static_cast<MnLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().mailiset()));
    vehbody_ptr->NBSDrvrSts = static_cast<NbsDrvSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsdrvrsts()));
    // vehbody_ptr->NBSMovReq  = static_cast<NbsMov_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsmovreq()));
    // vehbody_ptr->NBSReq     = static_cast<NbsReq_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsreq()));
    vehbody_ptr->PrkgTyp = static_cast<PrkSys_e>(static_cast<int>(vehicle_info_50ms->vehbody().prkgtyp()));
    vehbody_ptr->SDWReq  = static_cast<ReqZeroAsOn_e>(static_cast<int>(vehicle_info_50ms->vehbody().sdwreq()));
    for (int i = 0; i < vehicle_info_50ms->vehbody().seatbltsts().size(); i++) {
      vehbody_ptr->SeatBltSts[i] = vehicle_info_50ms->vehbody().seatbltsts()[i];
    }

    for (int i = 0; i < vehicle_info_50ms->vehbody().seatoccpsts().size(); i++) {
      vehbody_ptr->SeatOccpSts[i] =
        static_cast<SeatOcupSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().seatoccpsts()[i]));
    }

    vehbody_ptr->SWCAdjModReq = static_cast<SwcAdjMod_e>(static_cast<int>(vehicle_info_50ms->vehbody().swcadjmodreq()));
    vehbody_ptr->Time.Day     = vehicle_info_50ms->vehbody().time().day();
    vehbody_ptr->Time.Hr      = vehicle_info_50ms->vehbody().time().hr();
    vehbody_ptr->Time.Min     = vehicle_info_50ms->vehbody().time().min();
    vehbody_ptr->Time.Mth     = vehicle_info_50ms->vehbody().time().mth();
    vehbody_ptr->Time.Sec     = vehicle_info_50ms->vehbody().time().sec();
    vehbody_ptr->Time.Yr      = vehicle_info_50ms->vehbody().time().yr();

    vehbody_ptr->TpmsSts       = static_cast<TpmsSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().tpmssts()));
    vehbody_ptr->TrailerModReq = static_cast<TrlrMod_e>(static_cast<int>(vehicle_info_50ms->vehbody().trailermodreq()));
    vehbody_ptr->UPAReq        = static_cast<ReqZeroAsOn_e>(static_cast<int>(vehicle_info_50ms->vehbody().upareq()));

    vehbody_ptr->VehStatus.VehMode =
      static_cast<VehMode_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehmode()));
    vehbody_ptr->VehStatus.VehState =
      static_cast<VehSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehstate()));
    vehbody_ptr->VehStatus.VehStateASIL =
      static_cast<VehSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehstateasil()));

    vehbody_ptr->WipperSts.FrntWiperParkSts =
      static_cast<WiprPrkSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().wippersts().frntwiperparksts()));
    vehbody_ptr->WipperSts.FrntWiprSts =
      static_cast<WiprSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().wippersts().frntwiprsts()));
    vehbody_ptr->ECOPlusModSts        = vehicle_info_50ms->vehbody().ecoplusmodsts();
    vehbody_ptr->CrashDetd            = vehicle_info_50ms->vehbody().crashdetd();
    vehbody_ptr->CDCEqpmtSts.AUDIOsts = vehicle_info_50ms->drvin().cdceqpmt().audiosts();
    vehbody_ptr->CDCEqpmtSts.ICsts    = vehicle_info_50ms->drvin().cdceqpmt().icsts();
    vehbody_ptr->CDCEqpmtSts.ICSsts   = vehicle_info_50ms->drvin().cdceqpmt().icssts();
    vehbody_ptr->CDCEqpmtSts.HUDsts   = vehicle_info_50ms->drvin().cdceqpmt().hudsts();
    vehbody_ptr->HeadLampsOn          = vehicle_info_50ms->vehbody().headlampson();
  */
  // steersys
  strsys_ptr->ACIMtrTq      = fct_vehicle_input->np_steering_info().acimtrtqsae();  // lrpq
  strsys_ptr->ACIMtrTqVld   = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_steering_info().acimtrtqvld()));
  strsys_ptr->DrvngMod      = static_cast<EpsDrvMod_e>(static_cast<int>(fct_vehicle_input->np_steering_info().drvngmod()));
  strsys_ptr->EPSSts        = static_cast<EPSSts_e>(static_cast<int>(fct_vehicle_input->np_steering_info().epssts()));
  strsys_ptr->SWCFailSts    = static_cast<SWCFailSts_e>(static_cast<int>(fct_vehicle_input->np_steering_info().swcfailsts()));
  strsys_ptr->EstRackFrc    = fct_vehicle_input->np_steering_info().estrackfrcsae();  // lrpq
  strsys_ptr->EstRackFrcVld = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_steering_info().estrackfrcvld()));
  strsys_ptr->MtrTq         = fct_vehicle_input->np_steering_info().mtrtqsae();
  strsys_ptr->MtrTqVld      = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_steering_info().mtrtqvld()));
  strsys_ptr->OverRideDetn  = fct_vehicle_input->np_steering_info().overridedetn();
  strsys_ptr->PnnAg         = fct_vehicle_input->np_steering_info().pnnagsae();
  ioadapter->getInputManager().vehPnnAg = (-1.0) * fct_vehicle_input->np_steering_info().pnnagsae(); //ISO, deg
  strsys_ptr->PnnAgOffset   = fct_vehicle_input->np_steering_info().pnnagoffsetsae();
  strsys_ptr->PnnAgVld      = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_steering_info().pnnagvld()));
  strsys_ptr->RampSts       = fct_vehicle_input->np_steering_info().rampsts();
  strsys_ptr->StrAgCalSts   = static_cast<StrAgCalSts_e>(static_cast<int>(fct_vehicle_input->np_steering_info().stragcalsts()));
  strsys_ptr->StrAgFailSts  = static_cast<StrAgFailSts_e>(static_cast<int>(fct_vehicle_input->np_steering_info().stragfailsts()));
  strsys_ptr->StrWhlAg      = fct_vehicle_input->np_steering_info().strwhlagsae();
  strsys_ptr->StrWhlAgSpd   = fct_vehicle_input->np_steering_info().strwhlagspdsae();
  strsys_ptr->SupInfo       = fct_vehicle_input->np_steering_info().supinfo();
  strsys_ptr->Temperature   = fct_vehicle_input->np_steering_info().temperature();
  strsys_ptr->TorsBarTq     = fct_vehicle_input->np_steering_info().torsbartqsae();
  strsys_ptr->TorsBarTqVld  = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_steering_info().torsbartqvld()));
  strsys_ptr->HODSts        = static_cast<HODSts_e>(fct_vehicle_input->np_steering_info().hosts());
  strsys_ptr->HODErrSts     = fct_vehicle_input->np_steering_info().hoderrsts();
  strsys_ptr->DSREPSReq     = fct_vehicle_input->np_steering_info().epsreqtyp();

  // brakesys
  brksys_ptr->BCUBrkLiReq = static_cast<BcuBrkLiReq_e>(static_cast<int>(fct_vehicle_input->np_brake_info().bcubrklireq()));
  brksys_ptr->BrkFldLvl   = static_cast<BrkFldLvl_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkfldlvl()));

  brksys_ptr->BrkFunSt.ABAActv        = fct_vehicle_input->np_brake_info().brkfunst().abaactv();  // todo
  brksys_ptr->BrkFunSt.ABAAvl         = fct_vehicle_input->np_brake_info().brkfunst().abaavl();
  brksys_ptr->BrkFunSt.ABPActv        = fct_vehicle_input->np_brake_info().brkfunst().abpactv();
  brksys_ptr->BrkFunSt.ABPAvl         = fct_vehicle_input->np_brake_info().brkfunst().abpavl();
  brksys_ptr->BrkFunSt.AWBActv        = fct_vehicle_input->np_brake_info().brkfunst().awbactv();
  brksys_ptr->BrkFunSt.AWBAvl         = fct_vehicle_input->np_brake_info().brkfunst().awbavl();
  brksys_ptr->BrkFunSt.ABSActv        = fct_vehicle_input->np_brake_info().brkfunst().absactv();
  brksys_ptr->BrkFunSt.ABSFailLampReq = fct_vehicle_input->np_brake_info().brkfunst().absfaillampreq();
  brksys_ptr->BrkFunSt.AVHSts =
    static_cast<AvhSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkfunst().avhsts()));
  brksys_ptr->BrkFunSt.BDWActv        = fct_vehicle_input->np_brake_info().brkfunst().bdwactv();
  brksys_ptr->BrkFunSt.DTCActv        = fct_vehicle_input->np_brake_info().brkfunst().dtcactv();
  brksys_ptr->BrkFunSt.DWTActv        = fct_vehicle_input->np_brake_info().brkfunst().dwtactv();
  brksys_ptr->BrkFunSt.EBAActv        = fct_vehicle_input->np_brake_info().brkfunst().ebaactv();
  brksys_ptr->BrkFunSt.EBAAvl         = fct_vehicle_input->np_brake_info().brkfunst().ebaavl();
  brksys_ptr->BrkFunSt.EBDActv        = fct_vehicle_input->np_brake_info().brkfunst().ebdactv();
  brksys_ptr->BrkFunSt.EBDFailLampReq = fct_vehicle_input->np_brake_info().brkfunst().ebdfaillampreq();
  brksys_ptr->BrkFunSt.HBAActv        = fct_vehicle_input->np_brake_info().brkfunst().hbaactv();
  brksys_ptr->BrkFunSt.HDCSts =
    static_cast<HdcSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkfunst().hdcsts()));
  brksys_ptr->BrkFunSt.HHCActv            = fct_vehicle_input->np_brake_info().brkfunst().hhcactv();
  brksys_ptr->BrkFunSt.HHCAvl             = fct_vehicle_input->np_brake_info().brkfunst().hhcavl();
  brksys_ptr->BrkFunSt.TCSActv            = fct_vehicle_input->np_brake_info().brkfunst().tcsactv();
  brksys_ptr->BrkFunSt.TCSDeactv          = fct_vehicle_input->np_brake_info().brkfunst().tcsdeactv();
  brksys_ptr->BrkFunSt.VDCActv            = fct_vehicle_input->np_brake_info().brkfunst().vdcactv();
  brksys_ptr->BrkFunSt.VDCDeactv          = fct_vehicle_input->np_brake_info().brkfunst().vdcdeactv();
  brksys_ptr->BrkFunSt.VDCTCSFailLampReq  = fct_vehicle_input->np_brake_info().brkfunst().vdctcsfaillampreq();
  brksys_ptr->BrkFunSt.VDCTCSLampInfo     = fct_vehicle_input->np_brake_info().brkfunst().vdctcslampinfo();
  brksys_ptr->BrkFunSt.VDCTCSOnOfflampReq = fct_vehicle_input->np_brake_info().brkfunst().vdctcsonofflampreq();

  brksys_ptr->BrkHAZReq     = static_cast<BrkHazReq_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkhazreq()));
  brksys_ptr->BrkOverHeat   = static_cast<BrkOvrHt_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkoverheat()));
  brksys_ptr->BrkPadWearSts = static_cast<BrkPdWrSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkpadwearsts()));

  brksys_ptr->BrkPdl.BrkPedlSts =
    static_cast<BrkPdlSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkpdl().brkpedlsts()));
  brksys_ptr->BrkPdl.BrkpedlOvrd = static_cast<bool>(fct_vehicle_input->np_brake_info().brkpdl().brkpedlovrd());
  brksys_ptr->BrkPdl.Trvl = fct_vehicle_input->np_brake_info().brkpdl().trvl();
  brksys_ptr->BrkPdl.TrvlCalSts =
    static_cast<BrkPdlCalSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkpdl().trvlcalsts()));

  brksys_ptr->BrkPrs.BrkPrs       = fct_vehicle_input->np_brake_info().brkprsinfo().brkprs();
  brksys_ptr->BrkPrs.BrkPrsOffset = fct_vehicle_input->np_brake_info().brkprsinfo().brkprsoffset();
  brksys_ptr->BrkPrs.BrkPrsOffsetVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkprsinfo().brkprsoffsetvld()));
  brksys_ptr->BrkPrs.BrkPrsVld =
    static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_brake_info().brkprsinfo().brkprsvld()));

  brksys_ptr->NoBrkF = static_cast<BcuBrkF_e>(static_cast<int>(fct_vehicle_input->np_brake_info().nobrkf()));

  brksys_ptr->PrkBrk.EPBMod = static_cast<EpbMod_e>(static_cast<int>(fct_vehicle_input->np_brake_info().prkbrk().epbmod()));
  brksys_ptr->PrkBrk.EPBSts = static_cast<EpbSts_e>(static_cast<int>(fct_vehicle_input->np_brake_info().prkbrk().epbsts()));
  brksys_ptr->PrkBrk.EPBSwtSts =
    static_cast<EpbSwtSt_e>(static_cast<int>(fct_vehicle_input->np_brake_info().prkbrk().epbswtsts()));
  brksys_ptr->PrkBrk.CDPReq = static_cast<CDPReq_e>(fct_vehicle_input->np_brake_info().prkbrk().cdpreq());

  brksys_ptr->SupInfo            = static_cast<BcuSupInfo_e>(static_cast<int>(fct_vehicle_input->np_brake_info().supinfo()));
  brksys_ptr->StstSts            = static_cast<StstSts_e>(fct_vehicle_input->np_brake_info().stststs());
  brksys_ptr->BrkFunSt.AWBActv   = fct_vehicle_input->np_brake_info().brkfunst().awbactv();
  brksys_ptr->BrkFunSt.AWBAvl    = fct_vehicle_input->np_brake_info().brkfunst().awbavl();
  brksys_ptr->BrkFunSt.ARPCfgSts = static_cast<ZeroEn_e>(fct_vehicle_input->np_brake_info().brkfunst().arpcfgsts());
  brksys_ptr->BrkFunSt.ARPActv   = fct_vehicle_input->np_brake_info().brkfunst().arpactv();
  brksys_ptr->BrkFunSt.DTCAvl    = fct_vehicle_input->np_brake_info().brkfunst().dtcavl();
  brksys_ptr->BrkFunSt.CDPActv   = fct_vehicle_input->np_brake_info().brkfunst().cdpactv();
  brksys_ptr->BrkFunSt.CDPAvl    = fct_vehicle_input->np_brake_info().brkfunst().cdpavail();
  brksys_ptr->BrkFldWarnReq      = static_cast<BrkFldWarnReq_e>(fct_vehicle_input->np_brake_info().brkfldwarnreq());
  brksys_ptr->BrkPadWearWarnReq  = static_cast<BrkPadWearWarnReq_e>(fct_vehicle_input->np_brake_info().brkpadwearwarnreq());
  return true;
}

bool FCTInputAdapter::fill_veh50ms_input(const std::shared_ptr<proto::CarInfo> fct_vehicle_input,
                                         VEHDRVR* vehdrvr_ptr, VEHBODY* vehbody_ptr, VEHUPA* vehupa_ptr,
                                         DANOPSM* danop_ptr) {
  if (!fct_vehicle_input->has_np_upa_info() || fct_vehicle_input->np_upa_info().usregndst_size() == 0
      || fct_vehicle_input->np_upa_info().usregndst()[0].regndst_size() < 3) {
    WARN_LOG << "car_info not ready";
  } else {
    vehupa_ptr->UsRegnDst[0].RegnDst[1] = fct_vehicle_input->np_upa_info().usregndst()[0].regndst()[1];
    vehupa_ptr->UsRegnDst[0].RegnDst[2] = fct_vehicle_input->np_upa_info().usregndst()[0].regndst()[2];
    vehupa_ptr->UsRegnDst[0].RegnDst[3] = fct_vehicle_input->np_upa_info().usregndst()[0].regndst()[3];
  }

  // vehicledrive
  vehdrvr_ptr->AdFunCfg.AEBOnOffReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().aebonoffreq()));
  vehdrvr_ptr->AdFunCfg.CDCFailSts =
    static_cast<CdcFailSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().cdcfailsts()));
  vehdrvr_ptr->AdFunCfg.DASTactileOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().dastactileonoff()));
  vehdrvr_ptr->AdFunCfg.DrvAlertSysOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().drvalertsysonoff()));
  vehdrvr_ptr->AdFunCfg.FCTAOnOffCmd =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().fctaonoffcmd()));
  vehdrvr_ptr->AdFunCfg.FCWSetReq =
    static_cast<FcwSet_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().fcwsetreq()));
  vehdrvr_ptr->AdFunCfg.GoNotifierOnOff =
    static_cast<GoNotifierSwitch_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().gonotifieronoff()));
  vehdrvr_ptr->AdFunCfg.LCAOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().lcaonoff()));
  vehdrvr_ptr->AdFunCfg.LCATctlWarnOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().lcatctlwarnonoff()));
  vehdrvr_ptr->AdFunCfg.LKAStrSprtLvlSet = static_cast<LkaStrSprtLvl_e>(static_cast<int>(0));
  vehdrvr_ptr->AdFunCfg.LnAssistTctlOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().lnassisttctlonoff()));
  vehdrvr_ptr->AdFunCfg.RCTABReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().rctabreq()));
  vehdrvr_ptr->AdFunCfg.RCTAReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().rctareq()));
  vehdrvr_ptr->AdFunCfg.SAPAPrkgModReq =
    static_cast<SapaPrkMod_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().sapaprkgmodreq()));
  vehdrvr_ptr->AdFunCfg.SetHMA =
    static_cast<HmaOnOff_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().sethma()));
  vehdrvr_ptr->AdFunCfg.SetLaneAssiSnvty =
    static_cast<LnAssistSnvty_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().setlaneassisnvty()));
  configure_received_ = static_cast<uint32_t>(fct_vehicle_input->np_drv_info().adfuncfg().setlaneassisnvty());
  vehdrvr_ptr->AdFunCfg.SetLnAssiAidTyp =
    static_cast<LnAssistAid_e>(static_cast<int>(fct_vehicle_input->np_drv_info().adfuncfg().setlnassiaidtyp()));
  vehdrvr_ptr->AdFunCfg.ACCTauGapStored =
    static_cast<TauGap_e>(static_cast<int>(fct_vehicle_input->np_drv_info().da_taugap_stored()));
  vehdrvr_ptr->FogLiPushSwtSts =
    static_cast<FogLiSwtSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().foglipushswtsts()));
  vehdrvr_ptr->FogLiSCMCmd = static_cast<FogLiCmd_e>(static_cast<int>(fct_vehicle_input->np_drv_info().fogliscmcmd()));//
  vehdrvr_ptr->FrntWiprInterSpd =
    static_cast<WiprSpdSet_e>(static_cast<int>(fct_vehicle_input->np_drv_info().frntwiprinterspd()));
  vehdrvr_ptr->FrntWiprSwtSts = static_cast<WiprSwtSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().frntwiprswtsts()));
  vehdrvr_ptr->HiBeamSCMCmd   = static_cast<HiBmCmd_e>(static_cast<int>(fct_vehicle_input->np_drv_info().hibeamscmcmd()));
  vehdrvr_ptr->HiBeamSwtSts   = static_cast<HiBeamSwtSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().hibeamswtsts()));
  vehdrvr_ptr->NavCtryCod     = fct_vehicle_input->np_drv_info().navctrycod();//
  vehdrvr_ptr->NaviCurrentRoadTyp =
    static_cast<NaviCrrntRd_e>(static_cast<int>(fct_vehicle_input->np_drv_info().navicurrentroadtyp()));
  vehdrvr_ptr->NaviSpdLim = fct_vehicle_input->np_drv_info().navispdlim();//
  vehdrvr_ptr->NaviSpdLimSts =
    static_cast<NaviSpdLimSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().navispdlimsts()));//
  vehdrvr_ptr->NaviSpdUnit  = static_cast<NaviSpdUnit_e>(static_cast<int>(fct_vehicle_input->np_drv_info().navispdunit()));
  vehdrvr_ptr->ReWiprSCMCmd = static_cast<ReWiprCmd_e>(static_cast<int>(fct_vehicle_input->np_drv_info().rewiprscmcmd()));
  vehdrvr_ptr->SCMFailSts   = static_cast<ScmFailSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().scmfailsts()));
  for (int i = 0; i < fct_vehicle_input->np_drv_info().strwhlswtch().adupswtsts().size(); i++) {
    vehdrvr_ptr->StrWhlSwtch.AdUpSwtSts[i] =
      static_cast<SwcSwSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().strwhlswtch().adupswtsts()[i]));
    //WARN_LOG << "AdUpSwtSts[" << i << "] =" <<static_cast<int>(vehicle_info_50ms->drvin().strwhlswtch().adupswtsts()[i]);
  }
  for (int i = 0; i < fct_vehicle_input->np_drv_info().strwhlswtch().enupswtsts().size(); i++) {
    vehdrvr_ptr->StrWhlSwtch.EnUpSwtSts[i] =
      static_cast<SwcSwSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().strwhlswtch().enupswtsts()[i]));//
  }
  vehdrvr_ptr->VehEPModReq = static_cast<VehEPModReq_e>(static_cast<int>(fct_vehicle_input->np_drv_info().vehepmodreq()));

  vehdrvr_ptr->SVCAvl = static_cast<SvcAvl_e>(static_cast<int>(fct_vehicle_input->np_drv_info().svcavl()));
  vehdrvr_ptr->TurnIndcrSwtSts =
    static_cast<TrnIndcrSwSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().turnindcrswtsts()));
  vehdrvr_ptr->TurnIndcrSwtPos = fct_vehicle_input->np_drv_info().turnindcrswtposition();
  vehdrvr_ptr->StalkType = fct_vehicle_input->np_drv_info().stalktype();
  vehdrvr_ptr->WiprAutoSwtSts =
    static_cast<WiprAutoSwSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().wiprautoswtsts()));
  vehdrvr_ptr->WshrReWiprSwtSts =
    static_cast<WshrReWiprSwtSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().wshrrewiprswtsts()));
  vehdrvr_ptr->WTIDispSt = static_cast<WtiDispSt_e>(static_cast<int>(fct_vehicle_input->np_drv_info().wtidispst()));
  vehdrvr_ptr->AdFunCfg.SetDA_SpeedAssist =
    static_cast<AdFunOnOff_e>(fct_vehicle_input->np_drv_info().adfuncfg().setda_speedassist());
  vehdrvr_ptr->AdFunCfg.SetDA_SteerAssist =
    static_cast<SetDA_StrAssType_e>(fct_vehicle_input->np_drv_info().adfuncfg().setda_steerassist());
  vehdrvr_ptr->TowModActv      = static_cast<TowModActv_e>(fct_vehicle_input->np_drv_info().adfuncfg().towmodactv());
  vehdrvr_ptr->ELKSwtSts       = fct_vehicle_input->np_drv_info().adfuncfg().elkswtsts();
  vehdrvr_ptr->AdFunCfg.SetALC = static_cast<AlcCnfrm_e>(fct_vehicle_input->np_drv_info().adfuncfg().setda_alcs());
  vehdrvr_ptr->AdFunCfg.SetSpeedCtrlSts =
    static_cast<SetSpeedCtrlSts_e>(fct_vehicle_input->np_drv_info().adfuncfg().setspeedctrlsts());
  vehdrvr_ptr->AdFunCfg.CurveSpeedAssist =
    static_cast<CurveSpeedAssistSts_e>(fct_vehicle_input->np_drv_info().adfuncfg().curvespeedassist());
  vehdrvr_ptr->AdFunCfg.SetSWF = static_cast<SetSWFType_e>(fct_vehicle_input->np_drv_info().adfuncfg().setswf());
  if (FLAGS_enforce_swtich_da_nop) {
    vehdrvr_ptr->SwtichDA_NOP = true;
  } else {
    vehdrvr_ptr->SwtichDA_NOP = static_cast<bool>(fct_vehicle_input->np_drv_info().adfuncfg().swtichda_nop());
  }
  vehdrvr_ptr->SetDA_SetSpdOffs =
    static_cast<SetDA_SetSpdOffs_e>(fct_vehicle_input->np_drv_info().adfuncfg().setda_setspdoffs());
  vehdrvr_ptr->SetDA_SetSpdOffsValue =
    static_cast<int32_t>(fct_vehicle_input->np_drv_info().adfuncfg().setda_setspdoffsvalue());
  // vehdrvr_ptr->Set360AP =  static_cast<Set360APType_e>(fct_vehicle_input->np_drv_info().adfuncfg().noptraining());
  vehdrvr_ptr->NOP_Training =  static_cast<NOPtrainingType_e>(fct_vehicle_input->np_drv_info().adfuncfg().noptraining());
  vehdrvr_ptr->AdFunCfg.SetDA_PSP =  static_cast<bool>(fct_vehicle_input->np_drv_info().adfuncfg().setda_psp());
  vehdrvr_ptr->VehSpdLimSts =  static_cast<uint32_t>(fct_vehicle_input->np_drv_info().adfuncfg().vehspdlimsts());
  vehdrvr_ptr->Aquila_OnOff = static_cast<bool>(fct_vehicle_input->np_drv_info().aquila_onoff());
  // vehiclebody
  vehbody_ptr->AmbTemp      = fct_vehicle_input->np_vehicle_body_info().ambtemp();
  vehbody_ptr->AmbTempValid = fct_vehicle_input->np_vehicle_body_info().ambtempvalid();
  vehbody_ptr->CenLockSts   = static_cast<CenLockSts_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().cenlocksts()));
  vehbody_ptr->CrashDetd    = fct_vehicle_input->np_vehicle_body_info().crashdetd();

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().door().doorajarsts().size(); i++) {
    vehbody_ptr->Door.DoorAjarSts[i] =
      static_cast<DoorAjarSts_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().door().doorajarsts()[i]));
  }
  vehbody_ptr->Door.HoodAjarSts = fct_vehicle_input->np_vehicle_body_info().door().hoodajarsts();
  vehbody_ptr->Door.TrAjarSts   = fct_vehicle_input->np_vehicle_body_info().door().trajarsts();

  vehbody_ptr->DrvState    = static_cast<DrvSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().drvstate()));
  vehbody_ptr->IntrTemp    = fct_vehicle_input->np_vehicle_body_info().intrtemp();
  vehbody_ptr->IntrTempVld = static_cast<QfZeroVld_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().intrtempvld()));

  vehbody_ptr->LightSts.HzrdWarnSts =
    static_cast<HzrdLiSts_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().hzrdwarnsts()));
  vehbody_ptr->LightSts.LiSnsrData    = fct_vehicle_input->np_vehicle_body_info().lightsts().lisnsrdata();
  vehbody_ptr->LightSts.LiSnsrFailSts = fct_vehicle_input->np_vehicle_body_info().lightsts().lisnsrfailsts();
  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().foglists().size(); i++) {
    vehbody_ptr->LightSts.FogLiSts[i] =
      static_cast<FogLiSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().foglists()[i]));
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().beamsts().size(); i++) {
    vehbody_ptr->LightSts.BeamSts[i] =
      static_cast<BeamSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().beamsts()[i]));
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().turnindcrlists().size(); i++) {
    vehbody_ptr->LightSts.TurnIndcrLiSts[i] =
      static_cast<TurnLiSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().turnindcrlists()[i]));
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().mirrligtsts().size(); i++) {
    vehbody_ptr->LightSts.MirrLigtSts[i] =
      static_cast<MirrLiSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().mirrligtsts()[i]));
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().foglifctactvsts().size(); i++) {
    vehbody_ptr->LightSts.FogLiFctActvSts[i] =
      static_cast<FogLiSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().lightsts().foglifctactvsts()[i]));
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().dowwarnamblests().size(); i++) {
    vehbody_ptr->LightSts.DowWarnAmbLeSts[i] = fct_vehicle_input->np_vehicle_body_info().lightsts().dowwarnamblests()[i];
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().lgterrbrkli().size(); i++) {
    vehbody_ptr->LightSts.LgtErrBrkLi[i] = fct_vehicle_input->np_vehicle_body_info().lightsts().lgterrbrkli()[i];
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().lightsts().lgterrturnindcn().size(); i++) {
    vehbody_ptr->LightSts.LgtErrTurnIndcn[i] = fct_vehicle_input->np_vehicle_body_info().lightsts().lgterrturnindcn()[i];
  }

  vehbody_ptr->MaiLiSet   = static_cast<MnLiSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().mailiset()));
  vehbody_ptr->NBSDrvrSts = static_cast<NbsDrvSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().nbsdrvrsts()));
  // vehbody_ptr->NBSMovReq  = static_cast<NbsMov_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().nbsmovreq()));
  // vehbody_ptr->NBSReq     = static_cast<NbsReq_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().nbsreq()));
  vehbody_ptr->PrkgTyp = static_cast<PrkSys_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().prkgtyp()));
  vehbody_ptr->SDWReq  = static_cast<ReqZeroAsOn_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().sdwreq()));
  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().seatbltsts().size(); i++) {
    vehbody_ptr->SeatBltSts[i] = fct_vehicle_input->np_vehicle_body_info().seatbltsts()[i];
  }

  for (int i = 0; i < fct_vehicle_input->np_vehicle_body_info().seatoccpsts().size(); i++) {
    vehbody_ptr->SeatOccpSts[i] =
      static_cast<SeatOcupSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().seatoccpsts()[i]));
  }

  vehbody_ptr->SWCAdjModReq = static_cast<SwcAdjMod_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().swcadjmodreq()));
  vehbody_ptr->Time.Day     = fct_vehicle_input->np_vehicle_body_info().time().day();
  vehbody_ptr->Time.Hr      = fct_vehicle_input->np_vehicle_body_info().time().hr();
  vehbody_ptr->Time.Min     = fct_vehicle_input->np_vehicle_body_info().time().min();
  vehbody_ptr->Time.Mth     = fct_vehicle_input->np_vehicle_body_info().time().mth();
  vehbody_ptr->Time.Sec     = fct_vehicle_input->np_vehicle_body_info().time().sec();
  vehbody_ptr->Time.Yr      = fct_vehicle_input->np_vehicle_body_info().time().yr();

  vehbody_ptr->TpmsSts       = static_cast<TpmsSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().tpmssts()));
  vehbody_ptr->TrailerModReq = static_cast<TrlrMod_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().trailermodreq()));
  vehbody_ptr->UPAReq        = static_cast<ReqZeroAsOn_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().upareq()));

  vehbody_ptr->VehStatus.VehMode =
    static_cast<VehMode_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().vehstatus().vehmode()));
  vehbody_ptr->VehStatus.VehState =
    static_cast<VehSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().vehstatus().vehstate()));
  vehbody_ptr->VehStatus.VehStateASIL =
    static_cast<VehSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().vehstatus().vehstateasil()));

  vehbody_ptr->WipperSts.FrntWiperParkSts =
    static_cast<WiprPrkSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().wippersts().frntwiperparksts()));
  vehbody_ptr->WipperSts.FrntWiprSts =
    static_cast<WiprSt_e>(static_cast<int>(fct_vehicle_input->np_vehicle_body_info().wippersts().frntwiprsts()));
  vehbody_ptr->ECOPlusModSts        = fct_vehicle_input->np_vehicle_body_info().ecoplusmodsts();
  vehbody_ptr->CrashDetd            = fct_vehicle_input->np_vehicle_body_info().crashdetd();
  vehbody_ptr->CDCEqpmtSts.AUDIOsts = fct_vehicle_input->np_drv_info().cdceqpmt().audiosts();
  vehbody_ptr->CDCEqpmtSts.ICsts    = fct_vehicle_input->np_drv_info().cdceqpmt().icsts();
  vehbody_ptr->CDCEqpmtSts.ICSsts   = fct_vehicle_input->np_drv_info().cdceqpmt().icssts();
  vehbody_ptr->CDCEqpmtSts.HUDsts   = fct_vehicle_input->np_drv_info().cdceqpmt().hudsts();
  vehbody_ptr->HeadLampsOn          = fct_vehicle_input->np_vehicle_body_info().headlampson();
  vehbody_ptr->VehSpdMaxLimOnOff    = fct_vehicle_input->np_vehicle_body_info().vehspdmaxlimonoff();

  danop_ptr->pwr_swap_proc = static_cast<PwrSwapProc_e>(fct_vehicle_input->np_psap_can_info().pwrswapproc());
  danop_ptr->psap_park_view_status = static_cast<PSAPParkViewStatus_e>(fct_vehicle_input->np_drv_info().psapparkviewstatus());
  return true;
}

bool FCTInputAdapter::fill_me_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> road_det,
                                             EHYVisionRoad*                                          vision_road) {
  // Lane info fill in
  vision_road->lane.crossing_flag   = road_det->laneline().ld_crossing_flag();
  vision_road->lane.host_lane_width = road_det->laneline().ld_lane_width();
  ME_LaneWidth_mp                   = road_det->laneline().ld_lane_width();
  for (int i_line = 0; i_line < road_det->laneline().line_size(); ++i_line) {
    // ehy input struct predefined with max 8 lines
    if (i_line < kNumVisionLaneMarker) {
      if (road_det->laneline().line(i_line).ld_role() == 1) {
        ME_LeftLine_Role_mp  = road_det->laneline().line(i_line).ld_role();
        ME_LeftLine_C0_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c0();
        ME_LeftLine_C1_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c1();
        ME_LeftLine_C2_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c2();
        ME_LeftLine_C3_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c3();
        ME_LeftLine_start_mp = road_det->laneline().line(i_line).ld_first_line().ld_start();
        ME_LeftLine_end_mp   = road_det->laneline().line(i_line).ld_first_line().ld_end();
        ME_LeftLine_conf_mp  = road_det->laneline().line(i_line).ld_confidence();
      }
      if (road_det->laneline().line(i_line).ld_role() == 2) {
        ME_RightLine_Role_mp  = road_det->laneline().line(i_line).ld_role();
        ME_RightLine_C0_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c0();
        ME_RightLine_C1_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c1();
        ME_RightLine_C2_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c2();
        ME_RightLine_C3_mp    = road_det->laneline().line(i_line).ld_first_line().ld_line().line_c3();
        ME_RightLine_start_mp = road_det->laneline().line(i_line).ld_first_line().ld_start();
        ME_RightLine_end_mp   = road_det->laneline().line(i_line).ld_first_line().ld_end();
        ME_RightLine_conf_mp  = road_det->laneline().line(i_line).ld_confidence();
      }

      vision_road->lane.lines[i_line].confidence          = road_det->laneline().line(i_line).ld_confidence();
      vision_road->lane.lines[i_line].crossing            = road_det->laneline().line(i_line).ld_crossing();
      vision_road->lane.lines[i_line].crossing_ID         = road_det->laneline().line(i_line).ld_crossing_id();
      vision_road->lane.lines[i_line].dash_average_gap    = road_det->laneline().line(i_line).ld_dash_average_gap();
      vision_road->lane.lines[i_line].dash_average_length = road_det->laneline().line(i_line).ld_dash_average_length();
      vision_road->lane.lines[i_line].first_line.color =
        (LDColor_e)road_det->laneline().line(i_line).ld_first_line().ld_color();
      vision_road->lane.lines[i_line].first_line.type =
        (LDType_e)road_det->laneline().line(i_line).ld_first_line().ld_type();
      vision_road->lane.lines[i_line].first_line.start = road_det->laneline().line(i_line).ld_first_line().ld_start();
      vision_road->lane.lines[i_line].first_line.end   = road_det->laneline().line(i_line).ld_first_line().ld_end();
      vision_road->lane.lines[i_line].first_line.end_reason =
        (LDEndReason_e)road_det->laneline().line(i_line).ld_first_line().ld_end_reason();
      vision_road->lane.lines[i_line].first_line.line.c0 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c0();
      vision_road->lane.lines[i_line].first_line.line.c1 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c1();
      vision_road->lane.lines[i_line].first_line.line.c2 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c2();
      vision_road->lane.lines[i_line].first_line.line.c3 =
        road_det->laneline().line(i_line).ld_first_line().ld_line().line_c3();
      vision_road->lane.lines[i_line].second_line.color =
        (LDColor_e)road_det->laneline().line(i_line).ld_second_line().ld_color();
      vision_road->lane.lines[i_line].second_line.type =
        (LDType_e)road_det->laneline().line(i_line).ld_second_line().ld_type();
      vision_road->lane.lines[i_line].second_line.start = road_det->laneline().line(i_line).ld_second_line().ld_start();
      vision_road->lane.lines[i_line].second_line.end   = road_det->laneline().line(i_line).ld_second_line().ld_end();
      vision_road->lane.lines[i_line].second_line.end_reason =
        (LDEndReason_e)road_det->laneline().line(i_line).ld_second_line().ld_end_reason();
      vision_road->lane.lines[i_line].second_line.line.c0 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c0();
      vision_road->lane.lines[i_line].second_line.line.c1 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c1();
      vision_road->lane.lines[i_line].second_line.line.c2 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c2();
      vision_road->lane.lines[i_line].second_line.line.c3 =
        road_det->laneline().line(i_line).ld_second_line().ld_line().line_c3();
      vision_road->lane.lines[i_line].is_multi_clothoid = road_det->laneline().line(i_line).ld_is_multi_clothoid();
      vision_road->lane.lines[i_line].marker_width      = road_det->laneline().line(i_line).ld_marker_width();
      vision_road->lane.lines[i_line].measure_status =
        (LDMeasureStatus_e)road_det->laneline().line(i_line).ld_measuring_status();
      vision_road->lane.lines[i_line].is_multi_clothoid = road_det->laneline().line(i_line).ld_is_multi_clothoid();
      // for (int i_pix_pt = 0; i_pix_pt < road_det->laneline().line(i_line).ld_pixel_point_size(); ++i_pix_pt)
      // {
      //     // ehy input struct predefined pixel point size is 300
      //     if (i_pix_pt < kNumVisionLaneMarkerPoint)
      //     {
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lat =
      //         road_det->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_lat();
      //         vision_road->lane.lines[i_line].pixel_point[i_pix_pt].lon =
      //         road_det->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_long();
      //     }
      // }
      for (int i_line_pt = 0; i_line_pt < road_det->laneline().line(i_line).ld_point_size(); ++i_line_pt) {
        // ehy input struct predefined point size is 300
        if (i_line_pt < kNumVisionLaneMarkerPoint) {
          vision_road->lane.lines[i_line].point[i_line_pt].lat =
            road_det->laneline().line(i_line).ld_point(i_line_pt).ld_point_lat();
          vision_road->lane.lines[i_line].point[i_line_pt].lon =
            road_det->laneline().line(i_line).ld_point(i_line_pt).ld_point_long();
        }
      }
      vision_road->lane.lines[i_line].predict_reason =
        (LDPredictReason_e)road_det->laneline().line(i_line).ld_prediction_reason();
      vision_road->lane.lines[i_line].quality = (LDQuality_e)road_det->laneline().line(i_line).ld_quality();
      vision_road->lane.lines[i_line].role    = (LDRole_e)road_det->laneline().line(i_line).ld_role();

      // vision_road->lane.lines[i_line].source =
      // (LDCameraSource_e)road_det->laneline().line(i_line).ld_camera_source();
      vision_road->lane.lines[i_line].special_point.lat =
        road_det->laneline().line(i_line).ld_special_point().ld_point_lat();
      vision_road->lane.lines[i_line].special_point.lon =
        road_det->laneline().line(i_line).ld_special_point().ld_point_long();
      vision_road->lane.lines[i_line].special_point_is_detected =
        road_det->laneline().line(i_line).ld_special_point_is_detected();
      vision_road->lane.lines[i_line].special_point_type =
        (LDSpecialPointType_e)road_det->laneline().line(i_line).ld_special_point_type();
      vision_road->lane.lines[i_line].track_age = road_det->laneline().line(i_line).ld_track_age();
      vision_road->lane.lines[i_line].track_ID  = road_det->laneline().line(i_line).ld_track_id();
    }
  }

  // LPP infor fill in
  vision_road->lpp.source             = (LPPSource_e)road_det->lpp().lpp_source();
  vision_road->lpp.available          = road_det->lpp().lpp_available();
  vision_road->lpp.confidence         = road_det->lpp().lpp_confidence();
  vision_road->lpp.first_line.c0      = road_det->lpp().lpp_first().line_c0();
  vision_road->lpp.first_line.c1      = road_det->lpp().lpp_first().line_c1();
  vision_road->lpp.first_line.c2      = road_det->lpp().lpp_first().line_c2();
  vision_road->lpp.first_line.c3      = road_det->lpp().lpp_first().line_c3();
  vision_road->lpp.first_valid        = road_det->lpp().lpp_first_valid();
  vision_road->lpp.first_vr_end       = road_det->lpp().lpp_first_vr_end();
  vision_road->lpp.lpp_ctrl_point.lat = road_det->lpp().lpp_ctrl_point_lat();
  vision_road->lpp.lpp_ctrl_point.lon = road_det->lpp().lpp_ctrl_point_long();
  vision_road->lpp.second_line.c0     = road_det->lpp().lpp_second().line_c0();
  vision_road->lpp.second_line.c1     = road_det->lpp().lpp_second().line_c1();
  vision_road->lpp.second_line.c2     = road_det->lpp().lpp_second().line_c2();
  vision_road->lpp.second_line.c3     = road_det->lpp().lpp_second().line_c3();
  vision_road->lpp.second_valid       = road_det->lpp().lpp_second_valid();
  vision_road->lpp.second_vr_end      = road_det->lpp().lpp_second_vr_end();

  // //Road edge infor fill in
  for (int i_road_edg = 0; i_road_edg < road_det->roadedge_size(); ++i_road_edg) {
    if (i_road_edg < kNumVisionRoadEdge) {
      vision_road->road_edge[i_road_edg].id     = road_det->roadedge(i_road_edg).ld_re_id();
      vision_road->road_edge[i_road_edg].age    = road_det->roadedge(i_road_edg).ld_re_age();
      vision_road->road_edge[i_road_edg].type   = (LDREType_e)road_det->roadedge(i_road_edg).ld_re_type();
      vision_road->road_edge[i_road_edg].height = road_det->roadedge(i_road_edg).ld_re_height();
      vision_road->road_edge[i_road_edg].host_index =
        (LDREFromHostIndex_e)road_det->roadedge(i_road_edg).ld_re_from_host_index();
      vision_road->road_edge[i_road_edg].side           = (LDRESide_e)road_det->roadedge(i_road_edg).ld_re_side();
      vision_road->road_edge[i_road_edg].view_rng_start = road_det->roadedge(i_road_edg).ld_re_vr_start();
      vision_road->road_edge[i_road_edg].view_rng_end   = road_det->roadedge(i_road_edg).ld_re_vr_end();
      vision_road->road_edge[i_road_edg].line.c0        = road_det->roadedge(i_road_edg).ld_re_line().line_c0();
      vision_road->road_edge[i_road_edg].line.c1        = road_det->roadedge(i_road_edg).ld_re_line().line_c1();
      vision_road->road_edge[i_road_edg].line.c2        = road_det->roadedge(i_road_edg).ld_re_line().line_c2();
      vision_road->road_edge[i_road_edg].line.c3        = road_det->roadedge(i_road_edg).ld_re_line().line_c3();
    }
  }

  // vision_road->timestamp = road_det->timestamp();

  return true;
}
bool FCTInputAdapter::fill_dms_input(const std::shared_ptr<nio::ad::messages::DMS_DA>     dms_da_out,
                                     const std::shared_ptr<nio::ad::messages::DMS_Result> dms_result_out,
                                     const std::shared_ptr<nio::ad::messages::ADMS> adms_out, DMS* dms_ptr,
                                     std::shared_ptr<planner::IOAdapter>& ioadapter) {
  dms_ptr->dms_drws_lvl          = static_cast<DMSDrowsinessLevel_e>(dms_result_out->drowsiness_result().level());
  dms_ptr->dms_dstr_lvl          = static_cast<DMSDistractionLevel_e>(dms_result_out->distraction_result().level());
  dms_ptr->dms_status            = static_cast<DMSStatus_e>(dms_result_out->system_status());
  dms_ptr->dms_dstr_result_valid = dms_result_out->distraction_result().is_valid();
  dms_ptr->dms_dstr_result_conf  = dms_result_out->distraction_result().confidence();
  dms_ptr->dms_drws_lvl_da       = static_cast<uint8_t>(dms_da_out->drowsiness_level());
  dms_ptr->dms_dstr_lvl_da       = static_cast<uint8_t>(dms_da_out->distraction_level());
  dms_ptr->dms_dstr_lvl_short    = static_cast<uint8_t>(dms_da_out->distraction_level_short());
  if (static_cast<uint8_t>(dms_da_out->driver_in_loop_status()) < 2) {
    dms_ptr->dms_driver_in_loop  = static_cast<uint8_t>(dms_da_out->driver_in_loop_status());
  } else {
    dms_ptr->dms_driver_in_loop  = static_cast<uint8_t>(1);
  }
  if (ioadapter != nullptr) {
    ioadapter->getMidOutputManager().setDMSDriverInLoop(dms_ptr->dms_driver_in_loop);
  }
  dms_ptr->dms_gaze_aoi          = static_cast<DMSGazeAoi_e>(dms_result_out->gaze_aoi_result().gaze_aoi());
  dms_ptr->dms_left_eye          = static_cast<DMSEyeStatus_e>(dms_result_out->eye_status_result().left_eye());
  dms_ptr->dms_right_eye         = static_cast<DMSEyeStatus_e>(dms_result_out->eye_status_result().right_eye());
  dms_ptr->dms_steer_trq_req     = static_cast<uint8_t>(adms_out->steering_torque_req());
  dms_ptr->dms_drws_sts          = static_cast<uint32_t>(dms_da_out->drowsiness_sts());
  dms_ptr->dms_dstr_sts          = static_cast<uint32_t>(dms_da_out->distraction_sts());

  dms_ptr->dms_static_obj_warning    = static_cast<DMSRiskSceneWarning_e>(adms_out->static_obj_warning());
  dms_ptr->dms_sharp_turn_warning    = static_cast<DMSRiskSceneWarning_e>(adms_out->sharp_turn_warning());
  dms_ptr->dms_cutin_warning         = static_cast<DMSRiskSceneWarning_e>(adms_out->cutin_warning());
  dms_ptr->dms_overlay_warning       = static_cast<DMSOverlayWarning_e>(adms_out->overlay_warning());
  dms_ptr->dms_contruction_redwarnsign_warning    = static_cast<DMSRiskSceneWarning_e>(adms_out->contruction_redwarnsign_warning());
  return true;
}

bool FCTInputAdapter::fill_vis_failsafe_input(const std::shared_ptr<nio::ad::messages::FailSafeDetection> failsafe_det,
                                              VisionFailSafe* vision_failsafe) {
  vision_failsafe->frontcam_failsafe.failsafe_FN.FS_Fog = static_cast<uint32_t>(failsafe_det->failsafe_fn().fs_fog());
  vision_failsafe->frontcam_failsafe.failsafe_FN.FS_Windshield_Frozen =
    static_cast<uint32_t>(failsafe_det->failsafe_fn().fs_windshield_frozen());
  vision_failsafe->frontcam_failsafe.failsafe_FW.FS_Fog = static_cast<uint32_t>(failsafe_det->failsafe_fw().fs_fog());
  vision_failsafe->frontcam_failsafe.failsafe_FW.FS_Windshield_Frozen =
    static_cast<uint32_t>(failsafe_det->failsafe_fw().fs_windshield_frozen());

  vision_failsafe->frontcam_failsafe.failsafe_FW.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fw().fs_partial_blockage());
  if (failsafe_det->failsafe_fw().has_fs_full_blockage()) {
    vision_failsafe->frontcam_failsafe.failsafe_FW.FS_Full_Blockage =
      static_cast<uint32_t>(failsafe_det->failsafe_fw().fs_full_blockage());
  }
  vision_failsafe->frontcam_failsafe.failsafe_FW.FS_Out_Of_Calibration =
    static_cast<uint32_t>(failsafe_det->failsafe_fw().fs_out_of_calibration());

  vision_failsafe->frontcam_failsafe.failsafe_FN.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fn().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_FN.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fn().fs_full_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_FN.FS_Out_Of_Calibration =
    static_cast<uint32_t>(failsafe_det->failsafe_fn().fs_out_of_calibration());

  vision_failsafe->frontcam_failsafe.failsafe_FL.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fl().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_FL.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fl().fs_full_blockage());

  vision_failsafe->frontcam_failsafe.failsafe_FR.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fr().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_FR.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_fr().fs_full_blockage());

  vision_failsafe->frontcam_failsafe.failsafe_RL.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_rl().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_RL.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_rl().fs_full_blockage());

  vision_failsafe->frontcam_failsafe.failsafe_RR.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_rr().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_RR.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_rr().fs_full_blockage());

  vision_failsafe->frontcam_failsafe.failsafe_R.FS_Partial_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_r().fs_partial_blockage());
  vision_failsafe->frontcam_failsafe.failsafe_R.FS_Full_Blockage =
    static_cast<uint32_t>(failsafe_det->failsafe_r().fs_full_blockage());

  return true;
}

bool FCTInputAdapter::fill_funcstatus_input(const std::shared_ptr<nio::ad::messages::ParkingOut> func_parkingout, FUNCARB* func_arb_ptr) {
  
  bool updated_state_ = false;
  func_arb_ptr->FunctionStatus[0].id = FuncId_e::PsapMain;

  for (uint16_t i = 0; i < 10; i++) {
    if (0 != (int32_t)func_arb_ptr->FunctionStatus[i].id) {
      for (const auto func : func_parkingout->function()) {
        if (func.functionid() == (int32_t)func_arb_ptr->FunctionStatus[i].id) {
          func_arb_ptr->FunctionStatus[i].sts = static_cast<FunctionRequest_e>(func.funcsts());
          updated_state_ = true;
          break;
        }
      }
    }
  }

  return updated_state_;

}

bool FCTInputAdapter::fill_arb_input(const std::shared_ptr<nio::ad::messages::FunctionRequestBook> func_arb_out,
                                     FUNCARB*                                                      func_arb_ptr) {
  bool update_st_ = false;
  for (const auto func : func_arb_out->function()) {
    if ((int32_t)FuncId_e::DaMain == func.functionid()) {
      func_arb_ptr->FunctionReq[0].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[0].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::ELK == func.functionid()) {
      func_arb_ptr->FunctionReq[1].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[1].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::AHB == func.functionid()) {
      func_arb_ptr->FunctionReq[2].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[2].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::EAS == func.functionid()) {
      func_arb_ptr->FunctionReq[3].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[3].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::DaSdc == func.functionid()) {
      func_arb_ptr->FunctionReq[4].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[4].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::DaLcc == func.functionid()) {
      func_arb_ptr->FunctionReq[5].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[5].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::DaNbc == func.functionid()) {
      func_arb_ptr->FunctionReq[6].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[6].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::SapaMain == func.functionid()) {
      func_arb_ptr->FunctionReq[7].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[7].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::PsapMain == func.functionid()) {
      func_arb_ptr->FunctionReq[8].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[8].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::DaResume == func.functionid()) {
      func_arb_ptr->FunctionReq[9].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[9].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                              = true;
    }

    if ((int32_t)FuncId_e::DaAlcs == func.functionid()) {
      func_arb_ptr->FunctionReq[10].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[10].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                               = true;
    }

    if ((int32_t)FuncId_e::DaNbc == func.functionid()) {
      func_arb_ptr->FunctionReq[11].FunctionID = func.functionid();
      func_arb_ptr->FunctionReq[11].FuncReq    = static_cast<FunctionRequest_e>(func.funcreq());
      update_st_                               = true;
    }
  }
  return update_st_;
}

bool FCTInputAdapter::fill_cam_fim_input(const std::shared_ptr<nio::ad::messages::CameraFimInfo> cam_fim_out,
                                         CAMFIMINFO*                                             cam_fim_ptr) {
  cam_fim_ptr->dms_fim_info.DMSPhysicalLinkage_Error   = cam_fim_out->dms_adc_fim_info().fim_dmsphysicallinkage_error();
  cam_fim_ptr->dms_fim_info.DMS_License_NotAvailable   = cam_fim_out->dms_adc_fim_info().fim_dms_license_notavailable();
  cam_fim_ptr->dms_fim_info.DMS_Function_NotAvailable  = cam_fim_out->dms_adc_fim_info().fim_dms_function_notavailable();
  cam_fim_ptr->dms_fim_info.DMS_Camera_Occluded  = cam_fim_out->dms_adc_fim_info().fim_dms_camera_occluded();
  cam_fim_ptr->dms_fim_info.DMS_No_Image_Recv  = cam_fim_out->dms_adc_fim_info().fim_dms_no_image_recv();

  cam_fim_ptr->fw_adc_fim_info.FIM_FW_Camera_Cal_Error = cam_fim_out->fw_adc_fim_info().fim_fw_camera_cal_error();
  cam_fim_ptr->fw_adc_fim_info.FIM_FWPhysicalLinkage_Error =
    cam_fim_out->fw_adc_fim_info().fim_fwphysicallinkage_error();
  cam_fim_ptr->fw_adc_fim_info.FIM_FW_Camera_Failsafe_3 =
    cam_fim_out->fw_adc_fim_info().fim_fw_camera_failsafe_3();
  cam_fim_ptr->fw_adc_fim_info.FIM_Windshield_Cal_Error =
    cam_fim_out->fw_adc_fim_info().fim_windshield_cal_error();
  cam_fim_ptr->fn_adc_fim_info.FIM_FN_Camera_Cal_Error = cam_fim_out->fn_adc_fim_info().fim_fn_camera_cal_error();
  cam_fim_ptr->fn_adc_fim_info.FIM_FNPhysicalLinkage_Error =
    cam_fim_out->fn_adc_fim_info().fim_fnphysicallinkage_error();
  cam_fim_ptr->fn_adc_fim_info.FIM_FN_Camera_Failsafe_3 =
    cam_fim_out->fn_adc_fim_info().fim_fn_camera_failsafe_3();
  cam_fim_ptr->sidefl_adc_fim_info.FIM_FL_Camera_Cal_Error =
    cam_fim_out->sidefl_adc_fim_info().fim_fl_camera_cal_error();
  cam_fim_ptr->sidefl_adc_fim_info.FIM_SideFLPhysicalLinkage_Error =
    cam_fim_out->sidefl_adc_fim_info().fim_sideflphysicallinkage_error();
  cam_fim_ptr->sidefr_adc_fim_info.FIM_FR_Camera_Cal_Error =
    cam_fim_out->sidefr_adc_fim_info().fim_fr_camera_cal_error();
  cam_fim_ptr->sidefr_adc_fim_info.FIM_SideFRPhysicalLinkage_Error =
    cam_fim_out->sidefr_adc_fim_info().fim_sidefrphysicallinkage_error();
  cam_fim_ptr->siderl_adc_fim_info.FIM_RL_Camera_Cal_Error =
    cam_fim_out->siderl_adc_fim_info().fim_rl_camera_cal_error();
  cam_fim_ptr->siderl_adc_fim_info.FIM_SideRLPhysicalLinkage_Error =
    cam_fim_out->siderl_adc_fim_info().fim_siderlphysicallinkage_error();
  cam_fim_ptr->siderr_adc_fim_info.FIM_RR_Camera_Cal_Error =
    cam_fim_out->siderr_adc_fim_info().fim_rr_camera_cal_error();
  cam_fim_ptr->siderr_adc_fim_info.FIM_SideRRPhysicalLinkage_Error =
    cam_fim_out->siderr_adc_fim_info().fim_siderrphysicallinkage_error();
  cam_fim_ptr->rn_adc_fim_info.FIM_RN_Camera_Cal_Error =
    cam_fim_out->rn_adc_fim_info().fim_rn_camera_cal_error();
  cam_fim_ptr->rn_adc_fim_info.FIM_RNPhysicalLinkage_Error =
    cam_fim_out->rn_adc_fim_info().fim_rnphysicallinkage_error();

  cam_fim_ptr->svcfront_adc_fim_info.FIM_SVCFront_Camera_Cal_Error =
    cam_fim_out->svcfront_adc_fim_info().fim_svcfront_camera_cal_error();
  cam_fim_ptr->svcfront_adc_fim_info.FIM_SVCFrontPhysicalLinkage_Error =
    cam_fim_out->svcfront_adc_fim_info().fim_svcfrontphysicallinkage_error();
  cam_fim_ptr->svcleft_adc_fim_info.FIM_SVCLeft_Camera_Cal_Error =
    cam_fim_out->svcleft_adc_fim_info().fim_svcleft_camera_cal_error();
  cam_fim_ptr->svcleft_adc_fim_info.FIM_SVCLeftPhysicalLinkage_Error =
    cam_fim_out->svcleft_adc_fim_info().fim_svcleftphysicallinkage_error();
  cam_fim_ptr->svcright_adc_fim_info.FIM_SVCRight_Camera_Cal_Error =
    cam_fim_out->svcright_adc_fim_info().fim_svcright_camera_cal_error();
  cam_fim_ptr->svcright_adc_fim_info.FIM_SVCRightPhysicalLinkage_Error =
    cam_fim_out->svcright_adc_fim_info().fim_svcrightphysicallinkage_error();
  cam_fim_ptr->svcrear_adc_fim_info.FIM_SVCRear_Camera_Cal_Error =
    cam_fim_out->svcrear_adc_fim_info().fim_svcrear_camera_cal_error();
  cam_fim_ptr->svcrear_adc_fim_info.FIM_SVCRearPhysicalLinkage_Error =
    cam_fim_out->svcrear_adc_fim_info().fim_svcrearphysicallinkage_error();

  return true;
}

bool FCTInputAdapter::fill_perception_fim_input(const std::shared_ptr<nio::ad::messages::PerceptionFimInfo> perception_fim_out,
                                                PERCEPTIONFIMINFO*                                          perception_fim_ptr) {
  perception_fim_ptr->fim_imu_hw_temporary_error = perception_fim_out->fim_imu_hw_temporary_error();
  perception_fim_ptr->fim_imu_hw_perpetual_error = perception_fim_out->fim_imu_hw_perpetual_error();
  return true;
}

bool FCTInputAdapter::fill_lidar_fim_input(const std::shared_ptr<nio::ad::messages::LidarFimInfo> lidar_fim_out,
                                           LIDARFIMINFO*                                          lidar_fim_ptr) {
  lidar_fim_ptr->FIM_Lidar_Cal_Error = lidar_fim_out->fim_lidar_cal_error();
  return true;
}

void FCTInputAdapter::fill_veh_param_input(const std::shared_ptr<nio::ad::messages::VehVariantCode> veh_var_code_out,
                                           const std::shared_ptr<nio::ad::messages::VehicleAdfFod> veh_adf_fod_out,
                                           VEHPARAM*                                                veh_param_ptr) {
  veh_param_ptr->VarCodeInfo.sales_region =
    static_cast<SalesRegionTyp_e>(veh_var_code_out->variant_code_info().sales_region());

  veh_param_ptr->VarCodeInfo.vehicle_type =
    static_cast<FCTVehProjectTyp_e>(veh_var_code_out->variant_code_info().vehicle_project());

  // INFO_LOG<<"VEHICLE TYPE IS"<<(int)veh_param_ptr->VarCodeInfo.vehicle_type;
  veh_param_ptr->VarCodeInfo.nop_plus_subscribe_avail = static_cast<bool>(false);
  veh_param_ptr->VarCodeInfo.NAD_subscribe_avail = static_cast<bool>(false);
  if (veh_adf_fod_out->adf_list_size() > 0) {
    for (const auto& adf : veh_adf_fod_out->adf_list()) {
      if (adf.key() == "nop_plus_highway") {
        veh_param_ptr->VarCodeInfo.nop_plus_subscribe_avail = adf.value();
      }
      else if (adf.key() == "NADBeta") {
        veh_param_ptr->VarCodeInfo.NAD_subscribe_avail = adf.value();
      }
    }
  }
}

void FCTInputAdapter::fill_adasmap_input(const std::shared_ptr<nio::ad::messages::AdasMap> AdasMap_out,
                                          SDMAP* adasmap_ptr) {
  // adasmap_ptr->= static_cast<>(AdasMap_out->);
  adasmap_ptr->SdMapInfo.is_adasmap_valid     = static_cast<bool>(AdasMap_out->adas_info().is_adasmap_valid());
  adasmap_ptr->SdMapInfo.m_adasmap_is_highway = static_cast<uint8_t>(AdasMap_out->adas_info().m_adasmap_is_highway());
  adasmap_ptr->SdMapInfo.reliable_state =
    static_cast<ReliableState_e>(AdasMap_out->navigation_info().heart_beat_info().reliable_state());
  adasmap_ptr->SdMapInfo.navigation_state =
    static_cast<NavigationState_e>(AdasMap_out->navigation_info().heart_beat_info().navigation_state());

  adasmap_ptr->SdMapInfo.country_code = static_cast<uint32_t>(AdasMap_out->adas_info().adas_meta().country_code());
  if (AdasMap_out->adas_info().adas_meta().speed_unit() == 2) {
    adasmap_ptr->SdMapInfo.speed_unit = speed_unit_last_;
  } else {
    adasmap_ptr->SdMapInfo.speed_unit = static_cast<uint32_t>(AdasMap_out->adas_info().adas_meta().speed_unit());
  }
  if (AdasMap_out->adas_info().segment().size() > 0 && adasmap_ptr->SdMapInfo.is_adasmap_valid) {
    adasmap_ptr->SdMapInfo.road_class  = static_cast<uint32_t>(AdasMap_out->adas_info().segment(0).road_class());
    adasmap_ptr->SdMapInfo.form_of_way = static_cast<uint32_t>(AdasMap_out->adas_info().segment(0).form_of_way());
    adasmap_ptr->SdMapInfo.offset = static_cast<uint32_t>(AdasMap_out->adas_info().segment(0).offset() & 0xFFFFFFFF);
  }
  if (AdasMap_out->adas_info().traffic_event().size() > 0) {
    adasmap_ptr->SdMapInfo.trafficevent_offset =
      static_cast<uint32_t>(AdasMap_out->adas_info().traffic_event().at(0).offset() & 0xFFFFFFFF);
    adasmap_ptr->SdMapInfo.trafficevent_type =
      static_cast<uint32_t>(AdasMap_out->adas_info().traffic_event().at(0).event_type() & 0xFFFFFFFF);
  } else {
    adasmap_ptr->SdMapInfo.trafficevent_offset = static_cast<uint32_t>(0);
    adasmap_ptr->SdMapInfo.trafficevent_type   = static_cast<uint32_t>(0);
  }
  speed_unit_last_ =  adasmap_ptr->SdMapInfo.speed_unit;
}
/*
void FCTInputAdapter::fill_nop_vehicleout_input(const std::shared_ptr<nio::ad::messages::NopVehicleOut> NopVehicle_out,
                                                NopVehicleOut* nopvehicle_ptr) {

  nopvehicle_ptr->nop_colllision_risk = static_cast<uint32_t>(NopVehicle_out->nop_colllision_risk());
  nopvehicle_ptr->nop_freeSpace_intrusion_go_notifier =
    static_cast<bool>(NopVehicle_out->nop_freespace_intrusion_go_notifier());
  nopvehicle_ptr->nop_lat_ctrl_tarLe = static_cast<uint32_t>(NopVehicle_out->nop_lat_ctrl_tarle());
  nopvehicle_ptr->nop_lat_ctrl_tarRi = static_cast<uint32_t>(NopVehicle_out->nop_lat_ctrl_tarri());
  nopvehicle_ptr->nop_long_ctrl_tar  = static_cast<uint32_t>(NopVehicle_out->nop_long_ctrl_tar());
  nopvehicle_ptr->nop_freespaceintrusionatstandstill =
    static_cast<bool>(NopVehicle_out->nop_freespace_intrusion_at_standstill());
  nopvehicle_ptr->nop_turn_indicator_req = static_cast<uint32_t>(NopVehicle_out->nop_turn_indicator_req());
  nopvehicle_ptr->nop_alc_sts            = static_cast<uint32_t>(NopVehicle_out->nop_alc_sts());
}*/
void FCTInputAdapter::fill_nop_vehicleout_input(NopVehicleOut*                             nopvehicle_ptr,
                                                const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& nop_vehicleout_info = ioadapter->getMidOutputManager().getNopVehicleOutInfo();

  nopvehicle_ptr->nop_colllision_risk = static_cast<uint32_t>(nop_vehicleout_info.nop_collision_risk);
  nopvehicle_ptr->nop_freeSpace_intrusion_go_notifier =
    static_cast<bool>(nop_vehicleout_info.nop_freeSpace_intrusion_go_notifier);
  nopvehicle_ptr->nop_lat_ctrl_tarLe = static_cast<uint32_t>(nop_vehicleout_info.nop_lat_ctrl_tarLe);
  nopvehicle_ptr->nop_lat_ctrl_tarRi = static_cast<uint32_t>(nop_vehicleout_info.nop_lat_ctrl_tarRi);
  nopvehicle_ptr->nop_long_ctrl_tar  = static_cast<uint32_t>(nop_vehicleout_info.nop_long_ctrl_tar);
  nopvehicle_ptr->nop_freespaceintrusionatstandstill =
    static_cast<bool>(nop_vehicleout_info.nop_freeSpace_intrusion_at_standstill);
  nopvehicle_ptr->nop_turn_indicator_req = static_cast<uint32_t>(nop_vehicleout_info.nop_turn_indicator_req);
  nopvehicle_ptr->nop_alc_sts            = static_cast<uint32_t>(nop_vehicleout_info.nop_alc_sts);
  nopvehicle_ptr->nop_rain_mode          = static_cast<uint32_t>(0);
  nopvehicle_ptr->nop_lat_error = ioadapter->getMidOutputManager().getNopChassisControlInfo().getNopControlLatError();
  nopvehicle_ptr->nop_dist_to_fork = nop_vehicleout_info.nop_distance_to_next_split_;
  nopvehicle_ptr->nop_cutin_wti = ioadapter->getMidOutputManager().getNopCutinWti();
  nopvehicle_ptr->nop_ego_is_lane_keep = ioadapter->getMidOutputManager().getEgoIsLaneKeep();
}
/*
void FCTInputAdapter::fill_nop_chassis_ctrl_input(
  const std::shared_ptr<nio::ad::messages::NopChassisControl> Nop_ChassisCtrl, NopChassisControl* nopchassis_ptr) {

  nopchassis_ptr->nop_pinion_angle_request = static_cast<float>(Nop_ChassisCtrl->nop_pinion_angle_request());
  nopchassis_ptr->nop_vlc_drive_off_req    = static_cast<bool>(Nop_ChassisCtrl->nop_vlc_drive_off_req());
}*/
void FCTInputAdapter::fill_nop_chassis_ctrl_input(NopChassisControl*                         nopchassis_ptr,
                                                  const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  nopchassis_ptr->nop_pinion_angle_request =
    static_cast<float>(ioadapter->getMidOutputManager().getNopChassisControlInfo().getNopControlSteerAngleCmd());
  nopchassis_ptr->nop_vlc_drive_off_req =
    ioadapter->getMidOutputManager().getNopChassisControlInfo().getNopControlDriveOffReq();
  nopchassis_ptr->TarGear =
    static_cast<uint32_t>(ioadapter->getMidOutputManager().getPSPChassisControlInfo().getPSPControlTarGear());
  nopchassis_ptr->LON_parking_target_speed_ms =
    static_cast<float>(ioadapter->getMidOutputManager().getPSPChassisControlInfo().getPSPControlTarSpd());
  nopchassis_ptr->LON_parking_stop_distance_cm =
    static_cast<float>(ioadapter->getMidOutputManager().getPSPChassisControlInfo().getPSPControlStopDistance());
  nopchassis_ptr->LON_ctrl_mode =
    static_cast<uint32_t>(ioadapter->getMidOutputManager().getPSPChassisControlInfo().getPSPControlLonCtrlMode());
  nopchassis_ptr->psp_control_mode_request =
    static_cast<uint32_t>(ioadapter->getMidOutputManager().getPSPChassisControlInfo().getPSPControlModeReq());
}
/*
void FCTInputAdapter::fill_nop_functionstatus_input(
  const std::shared_ptr<nio::ad::messages::NopFunctionStatus> NopFunction_Status, NopFunctionstatus* nopfucntion_ptr) {
  nopfucntion_ptr->nop_function_status_nop_sts =
    static_cast<FunctionStatus_e>(NopFunction_Status->function_status_nop_sts().funcsts());
}*/
void FCTInputAdapter::fill_nop_functionstatus_input(NopFunctionstatus*                         nopfucntion_ptr,
                                                    const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // nopfucntion_ptr->nop_function_status_nop_sts = static_cast<FunctionStatus_e>(0U);
  nopfucntion_ptr->nop_ReqFunctionID = static_cast<int32_t>(ioadapter->getMidOutputManager().getNopReqFunctionId());
  nopfucntion_ptr->nop_oe_end_instant_off =
    static_cast<bool>(ioadapter->getMidOutputManager().getOddOeCheckingStatus().is_oe_range_checking_);
}
// void FCTInputAdapter::fill_speed_controller_input(SpeedController_Info*                      speed_controller_ptr,
//                                                   const std::shared_ptr<planner::IOAdapter>& ioadapter) {
//   speed_controller_ptr->sas_speed_limit_out_value =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_out_value);
//   speed_controller_ptr->sas_speed_limit_out_valid =
//     static_cast<bool>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_out_valid);
//   speed_controller_ptr->sas_speed_limit_out_id =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_out_id);
//   speed_controller_ptr->sas_speed_limit_c_id =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_c_id);
//   speed_controller_ptr->sas_speed_limit_c_value =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_c_value);
//   speed_controller_ptr->sas_sldf_state =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_sldf_state);
//   speed_controller_ptr->sas_sup_sign_type =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().sas_sup_sign_type);
//   speed_controller_ptr->disp_set_speed_enable =
//     static_cast<bool>(ioadapter->getMidOutputManager().getSpeedControllerOut().disp_set_speed_enable);
//   speed_controller_ptr->iacc_speed_limit_out_valid =
//     static_cast<bool>(ioadapter->getMidOutputManager().getSpeedControllerOut().iacc_speed_limit_out_valid);
//   speed_controller_ptr->iacc_speed_limit_out_value =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().iacc_speed_limit_out_value);
//   speed_controller_ptr->iacc_take_over_pop =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().iacc_take_over_pop);
//   speed_controller_ptr->user_set_speed =
//     static_cast<uint32_t>(ioadapter->getMidOutputManager().getSpeedControllerOut().user_set_speed);
//   speed_controller_ptr->rain_mode =
//     static_cast<bool>(ioadapter->getMidOutputManager().getSpeedControllerOut().rain_mode);
// };
/*
void FCTInputAdapter::fill_nop_speed_input(const std::shared_ptr<nio::ad::messages::NopSpeed> NopSpeed_out,
                                           NopSpeed*                                          nopspeed_ptr) {

  nopspeed_ptr->nop_now_electronic_eye_speed_limit =
    static_cast<uint32_t>(NopSpeed_out->nop_now_electronic_eye_speed_limit());
  nopspeed_ptr->nop_now_advisory_speed_limit = static_cast<uint32_t>(NopSpeed_out->nop_now_advisory_speed_limit());
  nopspeed_ptr->nop_now_legal_speed          = static_cast<uint32_t>(NopSpeed_out->nop_now_legal_speed());
  nopspeed_ptr->nop_next_electronic_eye_speed_limit =
    static_cast<uint32_t>(NopSpeed_out->nop_next_electronic_eye_speed_limit());
  nopspeed_ptr->nop_next_advisory_speed_limit = static_cast<uint32_t>(NopSpeed_out->nop_next_advisory_speed_limit());
  nopspeed_ptr->nop_next_legal_speed          = static_cast<uint32_t>(NopSpeed_out->nop_next_legal_speed());
  nopspeed_ptr->nop_distance_to_next          = static_cast<uint32_t>(NopSpeed_out->nop_distance_to_next());
  nopspeed_ptr->nop_now_road_type             = static_cast<uint32_t>(NopSpeed_out->nop_now_road_type());
  nopspeed_ptr->nop_next_road_type            = static_cast<uint32_t>(NopSpeed_out->nop_next_road_type());
  nopspeed_ptr->nop_reserved                  = static_cast<uint32_t>(NopSpeed_out->nop_reserved());
}*/
void FCTInputAdapter::fill_nop_speed_input(NopSpeed*                                  nopspeed_ptr,
                                           const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& nop_speed_info = ioadapter->getMidOutputManager().getNopSpeedInfo();
  nopspeed_ptr->nop_now_electronic_eye_speed_limit =
    static_cast<uint32_t>(nop_speed_info.nop_now_electronic_eye_speed_limit);
  nopspeed_ptr->nop_now_advisory_speed_limit = static_cast<uint32_t>(nop_speed_info.nop_now_advisory_speed_limit);
  nopspeed_ptr->nop_now_legal_speed          = static_cast<uint32_t>(nop_speed_info.nop_now_legal_speed);
  nopspeed_ptr->nop_next_electronic_eye_speed_limit =
    static_cast<uint32_t>(nop_speed_info.nop_next_electronic_eye_speed_limit);
  nopspeed_ptr->nop_next_advisory_speed_limit = static_cast<uint32_t>(nop_speed_info.nop_next_advisory_speed_limit);
  nopspeed_ptr->nop_next_legal_speed          = static_cast<uint32_t>(nop_speed_info.nop_next_legal_speed);
  nopspeed_ptr->nop_distance_to_next          = static_cast<uint32_t>(nop_speed_info.nop_distance_to_next);
  nopspeed_ptr->nop_now_road_type             = static_cast<uint32_t>(nop_speed_info.nop_now_road_type);
  nopspeed_ptr->nop_next_road_type            = static_cast<uint32_t>(nop_speed_info.nop_next_road_type);
  nopspeed_ptr->nop_reserved                  = static_cast<uint32_t>(nop_speed_info.nop_reserved);
}

void FCTInputAdapter::fill_nop_speedlimitvalue_input(
  const std::shared_ptr<nio::ad::messages::NopSpeedLimitValue> NopSpeedLimitValue_out,
  NopSpeedLimitValue*                                          nopspeedlimitvalue_ptr) {

  nopspeedlimitvalue_ptr->nop_speed_limit_value =
    static_cast<uint32_t>(NopSpeedLimitValue_out->nop_speed_limit_value());
  nopspeedlimitvalue_ptr->nop_speed_limit_unit = static_cast<bool>(NopSpeedLimitValue_out->nop_speed_limit_unit());
  nopspeedlimitvalue_ptr->nop_supsign_type     = static_cast<uint32_t>(0);
}

void FCTInputAdapter::fill_nop_powerpilotstate_input(
  const std::shared_ptr<nio::ad::messages::PowerSwapPilotState> NopPowerPilotState_out,
  NopPowerPilotState*                                           noppowerpilotstate_ptr) {
  if (NopPowerPilotState_out->has_task_state()) {
    noppowerpilotstate_ptr->nop_task_state = static_cast<TaskState_e>(NopPowerPilotState_out->task_state());
  }
}

void FCTInputAdapter::fill_ads_out_input(const std::shared_ptr<nio::ad::messages::ADS> ads_out, ADSOUT* ads_out_info) {
  ads_out_info->vlc_mode                 = static_cast<uint8_t>(ads_out->actuator().lngctrlcmfrt().vlcmode());
  ads_out_info->ParkSt.SApaStatus        = static_cast<uint8_t>(ads_out->lowspdfun().parkst().sapastatus());
  ads_out_info->ParkSt.PSAPHMIStatus     = static_cast<uint8_t>(ads_out->lowspdfun().parkst().psaphmistatus());
  ads_out_info->eps_req_typ              = static_cast<uint8_t>(ads_out->actuator().latctrl().strifreq());
  ads_out_info->vlc_targetacc            = static_cast<double>(ads_out->actuator().lngctrlcmfrt().vlctara());
  ads_out_info->AEBSts                   = static_cast<uint8_t>(ads_out->drvrif().lngwarnsafe().aebsts());
}

void FCTInputAdapter::fill_aebout_input(const std::shared_ptr<nio::ad::messages::FctsOut> FctsOut_out,
                                        AEBOUT*                                           aebout_ptr) {

  aebout_ptr->AebOutInfo.aba_req                 = FctsOut_out->aeb().aba_req();
  aebout_ptr->AebOutInfo.abalvl_req              = FctsOut_out->aeb().abalvl_req();
  aebout_ptr->AebOutInfo.abp_req                 = FctsOut_out->aeb().abp_req();
  aebout_ptr->AebOutInfo.aeb_req                 = FctsOut_out->aeb().abp_req();
  aebout_ptr->AebOutInfo.aeb_tar_decel           = FctsOut_out->aeb().aeb_tar_decel();
  aebout_ptr->AebOutInfo.awb_req                 = FctsOut_out->aeb().awb_req();
  aebout_ptr->AebOutInfo.awblvl_req              = FctsOut_out->aeb().awblvl_req();
  aebout_ptr->AebOutInfo.eba_req                 = FctsOut_out->aeb().eba_req();
  aebout_ptr->AebOutInfo.aebsts                  = FctsOut_out->aeb().aebsts();
  aebout_ptr->AebOutInfo.fcwsetst                = FctsOut_out->aeb().fcwsetst();
  aebout_ptr->AebOutInfo.prewarnreq              = FctsOut_out->aeb().prewarnreq();
  aebout_ptr->AebOutInfo.txtinfo                 = FctsOut_out->aeb().txtinfo();
  aebout_ptr->AebOutInfo.AEBDecelReq_DummyForDVR = FctsOut_out->aeb().aebdecelreq_dummyfordvr();
  aebout_ptr->FctsElkLkaOut.ELKSts = static_cast<Fcts_ELKSts>(static_cast<int>(FctsOut_out->elk().elksts()));
  aebout_ptr->FctsElkLkaOut.ESFWarnSts =
    static_cast<Fcts_ESFWarnSts>(static_cast<int>(FctsOut_out->elk().esfwarnsts()));
  aebout_ptr->FctsElkLkaOut.LkaSnsvty     = FctsOut_out->latctrl().lkasnsvty();
  aebout_ptr->FctsElkLkaOut.LkaLnAsstSts  = FctsOut_out->latctrl().lkalnasststs();
  aebout_ptr->FctsElkLkaOut.LkaHODWarnSeq = FctsOut_out->latctrl().lkahodwarnseq();
  aebout_ptr->FctsElkLkaOut.AdasLeLine    = FctsOut_out->ldw().adasleline();
  aebout_ptr->FctsElkLkaOut.AdasRiLine    = FctsOut_out->ldw().adasriline();
  aebout_ptr->FctsElkLkaOut.is_elk_actv   = (bool)FctsOut_out->elk().elkactive();
  aebout_ptr->FctsElkLkaOut.elk_intv_case = (int)FctsOut_out->elk().elktype();
  aebout_ptr->FctsElkLkaOut.is_lka_actv   = (bool)FctsOut_out->latctrl().lkaactive();
  aebout_ptr->FctsElkLkaOut.lka_type      = (int)FctsOut_out->latctrl().lkatype();
  aebout_ptr->FctsElkLkaOut.is_ldw_actv   = (bool)FctsOut_out->ldw().ldwactive();
  aebout_ptr->FctsElkLkaOut.ldw_type      = (int)FctsOut_out->ldw().ldwtype();
  aebout_ptr->FctsElkLkaOut.esf_id        = (!FctsOut_out->fctsreserved().empty())?(static_cast<int>(FctsOut_out->fctsreserved()[0])):0;
}

bool FCTInputAdapter::fill_side_feature(const std::shared_ptr<nio::ad::messages::ForceSideFeatures> side_feature_info,
                                        BSDSTS*                                                     bsd_sts_ptr) {

  bsd_sts_ptr->BsdSts.bsdlca_left_sts =
    static_cast<BsdLcaWarnStType_e>(side_feature_info->rad_rr_01().bsdlca_left_sts());
  bsd_sts_ptr->BsdSts.bsdlca_right_sts =
    static_cast<BsdLcaWarnStType_e>(side_feature_info->rad_rr_01().bsdlca_right_sts());
  bsd_sts_ptr->BsdSts.bsdlca_left_warn_req =
    static_cast<BsdLcaReWarnType_e>(side_feature_info->rad_rr_01().bsdlca_right_warn_req());
  bsd_sts_ptr->BsdSts.bsdlca_right_warn_req =
    static_cast<BsdLcaReWarnType_e>(side_feature_info->rad_rr_01().bsdlca_right_warn_req());

  return true;
}

bool FCTInputAdapter::fill_lidar_internalfault_input(
  const std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo> lidar_internalfault_info,
  LIDARFAULTINFO*                                                  lidar_internalfault_ptr) {

  lidar_internalfault_ptr->INNO_LIDAR_IN_FAULT_WINDOW_BLOCKAGE1 =
    lidar_internalfault_info->inno_lidar_in_fault_window_blockage1();
  lidar_internalfault_ptr->INNO_LIDAR_TEMPHIGH_INHIBIT = lidar_internalfault_info->inno_lidar_temphigh_inhibit();

  return true;
}

bool FCTInputAdapter::fill_fault_software_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  //ioadapter->getInputManager().m_sub_fault_software_->Observe();
  const auto& fault_software_msg =
      ioadapter->getInputManager().m_sub_fault_software_.GetLatest();
  if(fault_software_msg != nullptr) {
    faut_software = fault_software_msg;
  }else {
    faut_software = std::make_shared<nio::ad::messages::SWFaultInfo>();
  }
  return true;
}

bool FCTInputAdapter::fill_fault_function_input(
  const std::shared_ptr<nio::ad::messages::FunctionInfo>& fault_function_info) {
  const apollo::cyber::Time current_time = ncyber::Time::Now();
  if (fault_function_info != nullptr && last_fault_function_ptp_ts != fault_function_info->publish_ptp_ts()) {
    is_eas_inhibit                 = (fault_function_info->eas_fim_info().fault2functional_sts() == 0) ? false : true;
    last_fault_function_topic_time = current_time;
    last_fault_function_ptp_ts = fault_function_info->publish_ptp_ts();
  } else {
    auto        warning_duration = current_time - last_fault_function_topic_time;
    const auto& duration_second  = warning_duration.ToSecond();
    if (duration_second > 1.0) {
      is_eas_inhibit = true;
    }
  }
  return true;
}

void FCTInputAdapter::fill_cfgtaskswitch_input(
  const std::shared_ptr<nio::ad::messages::CfgTaskSwitch> cfgtaskswitch_out, CfgTskSwt* cfgtaskmgr_ptr) {
  cfgtaskmgr_ptr->CfgTaskSwitchInfo.cfg_status =
    static_cast<CfgTaskSwitch_Status_e>(static_cast<int>(cfgtaskswitch_out->status()));
  if (cfgtaskswitch_status_last_ != static_cast<int>(cfgtaskswitch_out->status())) {
    WARN_LOG << "cfgtaskswitch_out status : from " << cfgtaskswitch_status_last_ << " to "
             << static_cast<int>(cfgtaskswitch_out->status());
  }
  cfgtaskswitch_status_last_ = static_cast<int>(cfgtaskswitch_out->status());
}

void FCTInputAdapter::fill_esdnpfeature_input(EsdNpFeature*                              esdnpfeature_ptr,
                                              const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& nop_path_info = ioadapter->getMidOutputManager().getEsdNopPathPoint();
  int path_size = std::min(kNumEsdNopPathNum, nop_path_info.esd_nop_path_points_size());
  int last_vaild_index = 0;
  for (int i_path = 0; i_path < kNumEsdNopPathNum; ++i_path) {
    if (path_size == 0) {
      esdnpfeature_ptr->esd_nop_path.x[i_path] = 0;
      esdnpfeature_ptr->esd_nop_path.y[i_path] = 0;
    } else if (i_path < path_size) {
      const auto& curr_point = nop_path_info.esd_nop_path_points(i_path);
      esdnpfeature_ptr->esd_nop_path.x[i_path] = curr_point.x();
      esdnpfeature_ptr->esd_nop_path.y[i_path] = curr_point.y();
      last_vaild_index = i_path;
    } else {
      esdnpfeature_ptr->esd_nop_path.x[i_path] = esdnpfeature_ptr->esd_nop_path.x[last_vaild_index];
      esdnpfeature_ptr->esd_nop_path.y[i_path] = esdnpfeature_ptr->esd_nop_path.y[last_vaild_index];
    }
  }

  //fill esd_in_powerstation
  esdnpfeature_ptr->esd_in_PowerStation = ioadapter->getMidOutputManager().getEsdInPowerStation();
};

bool FCTInputAdapter::fill_npnopsm_input(DANOPSM* danop_ptr, DAStateMachineAdapter* statemachine_adapter, VEHDRVR* veh_drvr_ptr,
                                         const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  danop_ptr->is_lccplus_available_flg = static_cast<bool>(FLAGS_enable_lcc_plus_in_feature_autogen);
  danop_ptr->nop_activation_trigger   = statemachine_adapter->fct_getNopActvTrigger();
  danop_ptr->nop_deactivation_trigger = statemachine_adapter->fct_getNopDeactvTrigger();
  danop_ptr->nop_status = static_cast<NOP_Status_e>(static_cast<uint8_t>(statemachine_adapter->fct_getNopStatus()));
  danop_ptr->nop_plus_subscribe_avail = static_cast<bool>(statemachine_adapter->getnopsubscribeavail());
  danop_ptr->psp_status               = static_cast<uint8_t>(statemachine_adapter->getPSPStatus());
  danop_ptr->urban_status =
    static_cast<Urban_Status_e>(static_cast<uint8_t>(statemachine_adapter->fct_getUrbanStatus()));
  danop_ptr->is_in_map_area           = static_cast<int32_t>(statemachine_adapter->getIsInMapArea());
  danop_ptr->np_activation_prevention = static_cast<bool>(statemachine_adapter->getnpactvationprevnt() &&
                                                          SetDA_StrAssType_e::kStronStrAss != veh_drvr_ptr->AdFunCfg.SetDA_SteerAssist);
  danop_ptr->psp_status_dawti         = static_cast<uint8_t>(statemachine_adapter->getPSPStatusDaWti());
  danop_ptr->is_nop_control_status = ioadapter->getMidOutputManager().getNopChassisControlInfo().getFlagIsNopControl();
  danop_ptr->is_nop_trans_to_psp_failed =
    statemachine_adapter->getFlagNopTransToPSPFailed(ioadapter, global_locali_info);
  danop_ptr->psp_task_status     = static_cast<uint8_t>(statemachine_adapter->getPSPTaskStatus());
  danop_ptr->psp_task_result     = static_cast<uint8_t>(statemachine_adapter->getPSPTaskResult());
  danop_ptr->priority_road_class = static_cast<uint8_t>(statemachine_adapter->getPriorityRoadClacc());
  danop_ptr->da_nop_avl = static_cast<uint8_t>(statemachine_adapter->getDANOPAvl());
  danop_ptr->da_nad_avl = static_cast<uint8_t>(statemachine_adapter->getDANADAvl());
  if (nullptr != ioadapter->getFramePtr()) {
    danop_ptr->distance_to_next_ramp = static_cast<uint8_t>(ioadapter->getFramePtr()->getDistanceToRamp());
    danop_ptr->is_psp_area = static_cast<bool>(ioadapter->getFramePtr()->getIsPSPArea());
  } else {
    danop_ptr->distance_to_next_ramp = static_cast<uint8_t>(std::numeric_limits<int>::max());
    danop_ptr->is_psp_area = static_cast<bool>(false);
  }
  danop_ptr->is_steer_override = false;
  if (fct_vehicle_input.size() > 0) {
    auto car_info_msg = fct_vehicle_input.back();
    // fill takeover_req
    static bool                is_first_override_start_         = false;
    static bool                is_last_override_status_         = false;
    static apollo::cyber::Time first_override_status_timestamp_ = apollo::cyber::Time(0.0);
    if (car_info_msg->steer_report().has_steer_override()) {
      danop_ptr->is_steer_override = car_info_msg->steer_report().steer_override();
      if (!is_last_override_status_ && car_info_msg->steer_report().steer_override() && !is_first_override_start_) {
        first_override_status_timestamp_ = ncyber::Time::Now();
        is_first_override_start_         = true;
      }
      is_last_override_status_             = car_info_msg->steer_report().steer_override();
      auto         curr_time               = ncyber::Time::Now();
      const double override_timestamp_diff = (curr_time - first_override_status_timestamp_).ToSecond();
      if (ioadapter->getMidOutputManager().getSMNOPAvailable() == false) {
        is_first_override_start_    = false;
        danop_ptr->nop_takeover_req = car_info_msg->steer_report().steer_override();
        first_override_status_timestamp_ = ncyber::Time::Now();
      } else if (is_first_override_start_ && std::fabs(override_timestamp_diff) < override_cooling_time_buffer) {
        danop_ptr->nop_takeover_req = true;
        INFO_LOG << "override cooling time set";
      } else {
        is_first_override_start_    = false;
        danop_ptr->nop_takeover_req = car_info_msg->steer_report().steer_override();
        INFO_LOG << "override not set";
      }
    }
    INFO_LOG << "steer_override: " << car_info_msg->steer_report().steer_override()
             << ", takeover_req: " << danop_ptr->nop_takeover_req;
  }
  ioadapter->getMidOutputManager().getNopChassisControlInfo().setFlagIsNopTakeover(danop_ptr->nop_takeover_req);

  bool is_psap_active_flg = false;
  if (fct_parkingout_info.size() > 0) {
    std::shared_ptr<nio::ad::messages::ParkingOut> func_parkingout = fct_parkingout_info.back();
    if (func_parkingout != nullptr) {
      for (const auto func : func_parkingout->function()) {
        if (static_cast<FuncId_e>(func.functionid()) == FuncId_e::PsapMain
            && static_cast<FunctionRequest_e>(func.funcsts()) == FunctionRequest_e::ReqRunning) {
          is_psap_active_flg = true;
          break;
        }
      }
    }
  }
  danop_ptr->is_psap_active_flg = is_psap_active_flg;
  ioadapter->getMidOutputManager().setPsapActiveFlg(danop_ptr->is_psap_active_flg);

  danop_ptr->nop_path_quality_check_result = ioadapter->getMidOutputManager().getPathQualityCheckResult();
  danop_ptr->is_in_risk_scenario_flg = ioadapter->getMidOutputManager().getRiskScenarioResult();
  danop_ptr->is_nop_planner_status = ioadapter->getMidOutputManager().getIsPlanner();
  danop_ptr->is_in_toll_station_flg =
    ioadapter->getMidOutputManager().getIsOnTollLane() || ioadapter->getMidOutputManager().getIsOnCheckingLane();
  danop_ptr->is_path_collision_risk_flg =
    ioadapter->getMrmDataPtr() == nullptr ? false : ioadapter->getMrmDataPtr()->main_path_collision_risk_flg;
  danop_ptr->abnormal_path_trigger_inhibit_flg = ioadapter->getMidOutputManager().getTriggerInhibitDec();
  // danop_ptr->nop_path_quality_check_result = true;
  INFO_LOG << "[FctInputAdapter] NOP path quality chek result : " << danop_ptr->nop_path_quality_check_result;

  auto nad_sm_debug = ioadapter->getMidOutputManager().getStateMachineDebug();
  danop_ptr->hard_inhibit_flg.is_crossing_hard_inhibit_flg =
    (nad_sm_debug.has_dasm_ioadaptor()) ? nad_sm_debug.dasm_ioadaptor().is_crossing_hard_inhibit_flg() : false;
  danop_ptr->odd_scenario = static_cast<uint8_t>(ioadapter->getMidOutputManager().getOddScenario());
  danop_ptr->one_orin_signals.is_open_one_orin_func = ioadapter->getMidOutputManager().getPlatformNt3Flag();
  danop_ptr->one_orin_signals.is_apps_status_actptr_flg = ioadapter->getMidOutputManager().getAppStatusActPreFlg();
  danop_ptr->is_lane_risk_scenario_flg = false;
  if (ioadapter->getFramePtr() != nullptr) {
    const proto::CarState car_state = ioadapter->getFramePtr()->getCarState();
    if (car_state.wm_lane_risk_scenario()
        && (nad_sm_debug.danadsts_enum() == 9 || nad_sm_debug.danadsts_enum() == 11
            || nad_sm_debug.danadsts_enum() == 7)) {
      danop_ptr->is_lane_risk_scenario_flg = true;
    }
    ioadapter->getFramePtr()->setIsLaneRiskScenario(danop_ptr->is_lane_risk_scenario_flg);
  }
  danop_ptr->is_in_uturn_scenario_flg =
    ioadapter->getFramePtr() != nullptr ? ioadapter->getFramePtr()->isFs() : false;
  danop_ptr->m_uBitNPActPreTrigger = ioadapter->getMidOutputManager().getNpActPreInput();
  danop_ptr->da_inhibit_input.m_uBitNPAdInhibitTrigger = ioadapter->getMidOutputManager().getNpAdInhibitInput();
  danop_ptr->da_inhibit_input.m_uBitNPTdInhibitTrigger = ioadapter->getMidOutputManager().getNpTdInhibitInput();
  danop_ptr->da_inhibit_input.m_uBitNPEasInhibitTrigger = ioadapter->getMidOutputManager().getNpEasInhibitInput();
  danop_ptr->da_inhibit_input.m_uBitNPHardInhibitTrigger = ioadapter->getMidOutputManager().getNpHardInhibitInput();
  danop_ptr->is_in_emergency_flg = ioadapter->getMidOutputManager().getIsInEmergenceFlag();
  danop_ptr->is_freeze_hod_timer_req_flg = ioadapter->getMidOutputManager().getFreezeHodTimerReq();
  danop_ptr->m_uBitNPActPreTrigger = ioadapter->getMidOutputManager().getNpActPreInput();
  return true;
}

void FCTInputAdapter::fill_globallocalization_input(
  const std::shared_ptr<nio::ad::messages::GlobalLocalization> Global_Localization,
  GLOBALLOCALIZATION* global_locali_info_ptr, GlobalLocation* glb_loc_mil_info_ptr) {
  if (Global_Localization->has_lane_loc()) {
    if (Global_Localization->lane_loc().has_curr_link_id()) {
      global_locali_info_ptr->lane_loc.curr_link_id = static_cast<uint64_t>(Global_Localization->lane_loc().curr_link_id());
    }
    if (Global_Localization->lane_loc().has_curr_lane_id()) {
      global_locali_info_ptr->lane_loc.curr_lane_id = static_cast<uint64_t>(Global_Localization->lane_loc().curr_lane_id());
    }
  }
  if (Global_Localization->has_auxiliary_parking_info()) {
    if (Global_Localization->auxiliary_parking_info().has_is_in_map_area()) {
      global_locali_info_ptr->auxiliary_parking_info.is_in_map_area =
        static_cast<int32_t>(Global_Localization->auxiliary_parking_info().is_in_map_area());
    }
  }

  if (Global_Localization->has_confidence()) {
    glb_loc_mil_info_ptr->confidence = Global_Localization->confidence();
  }
}

void FCTInputAdapter::fill_hd_link_input(const std::shared_ptr<nio::ad::messages::HdLinkInfoList> hd_link,
                                         std::vector<HDLINK>*                                     hd_link_info) {
  hd_link_info->clear();

  int min_size = MIN(kNumHdLink, hd_link->link_info_list_size());
  for (int linkinfo_i = 0; linkinfo_i < min_size; linkinfo_i++) {
    if (linkinfo_i < hd_link->link_info_list_size()) {
      HDLINK hdlink_temp;
      if (hd_link->link_info_list().at(linkinfo_i).has_priority_road_class()) {
        hdlink_temp.priority_road_class =
          static_cast<PriorityRoadClass_e>(hd_link->link_info_list().at(linkinfo_i).priority_road_class());
      }

      int formway_min_size = MIN(kNumFormWay, hd_link->link_info_list().at(linkinfo_i).form_way_size());
      for (int formway_i = 0; formway_i < formway_min_size; formway_i++) {
        if (formway_i < hd_link->link_info_list().at(linkinfo_i).form_way_size()) {
          FormWay_e formway_temp;
          formway_temp = static_cast<FormWay_e>(hd_link->link_info_list().at(linkinfo_i).form_way().at(formway_i));
          hdlink_temp.form_way.push_back(formway_temp);
        }
      }
      hd_link_info->push_back(hdlink_temp);
    }
  }
}

void FCTInputAdapter::fill_dynamic_map_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  //ioadapter->getInputManager().world_model_dynamic_map_reader->Observe();
  const auto& dynamic_map_msg =
      ioadapter->getInputManager().world_model_dynamic_map_.GetLatest();
  if(dynamic_map_msg != nullptr) {
    dynamic_map = dynamic_map_msg;
  }else {
    dynamic_map = std::make_shared<proto::DynamicMap>();
  }
}

void FCTInputAdapter::fill_active_prevention_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  if (ioadapter == nullptr || ioadapter->getFramePtr() == nullptr) {
    return;
  }

  // bit0: DA actpre for hear req
  bool is_wsheatTransSts_actpre_flg = (nio::ad::fctapp::adcheater.WSHeatTransSts == true);

  // bit1: risk scenario in local map from wm
  auto setDA_SteerAssist_enum = static_cast<int32_t>(nio::ad::fctapp::veh_drvr.AdFunCfg.SetDA_SteerAssist);
  bool is_da_steer_assist_flg = setDA_SteerAssist_enum != 0 ? true : false;
  bool is_wm_actprev_req_flg  = false;
  if (ioadapter->getFramePtr() != nullptr && is_da_steer_assist_flg) {
    const auto car_state_msg = ioadapter->getFramePtr()->getCarState();
    is_wm_actprev_req_flg = FLAGS_planner_use_wm_ramp_conditions_for_DAmain
                              ? (car_state_msg.wm_nop_actprev_req_flg() || car_state_msg.wm_nop_suppr_req_flg())
                              : false;
  }

  // bit2: single high risk junction
  bool is_single_high_risk_junction_flg = false;
  const auto dynamic_map = ioadapter->getFramePtr()->getDynamicMap();
  if (dynamic_map.has_navi_map() && dynamic_map.navi_map().has_long_range_info()
      && dynamic_map.navi_map().long_range_info().navi_stub_size() != 0) {
    const auto stubs = dynamic_map.navi_map().long_range_info().navi_stub();
    for (const auto stub : stubs) {
      if (stub.event_type_size() == 0) continue;
      for (const auto event_type : stub.event_type()) {
        if (event_type == 2108) {
          is_single_high_risk_junction_flg = true;
          break;
        }
      }
    }
  }

  uint32_t m_uBitNPActPreTrigger = 0;
  if (is_wsheatTransSts_actpre_flg)
    m_uBitNPActPreTrigger |= (0x01);
  if (is_wm_actprev_req_flg)
    m_uBitNPActPreTrigger |= (0x01 << 1);
  if (is_single_high_risk_junction_flg)
    m_uBitNPActPreTrigger |= (0x01 << 2);

  ioadapter->getMidOutputManager().setNpActPreInput(m_uBitNPActPreTrigger);
}

void FCTInputAdapter::fill_ad_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // bit0: for example
  bool is_example_ad_inhibit_flg = false;

  uint32_t m_uBitNPAdInhibitTrigger = 0;
  if (is_example_ad_inhibit_flg)
    m_uBitNPAdInhibitTrigger |= (0x01);

  ioadapter->getMidOutputManager().setNpAdInhibitInput(m_uBitNPAdInhibitTrigger);
}

void FCTInputAdapter::fill_td_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  if (!ioadapter) return;
  // ioadapter->getInputManager().m_sub_fim_sw_->Observe();
  auto fim_sw_msg = ioadapter->getInputManager().m_sub_fim_sw_.GetLatest();
  if(fim_sw_msg) {
    fim_rel_loc_abnoraml_flag_ = fim_sw_msg->s1_process_fim_info().fim_rel_loc_app_exited_abnoraml();
    fim_aa_app_abnoraml_flag_ = fim_sw_msg->s1_process_fim_info().fim_aa_app_exited_abnormal() || 
                                fim_sw_msg->s3_process_fim_info().fim_aa_app_exited_abnormal();
    fim_map_loc_app_abnoraml_flag_ = fim_sw_msg->s2_process_fim_info().fim_map_loc_app_exited_abnormal();
  }

  // ioadapter->getInputManager().m_sub_fim_perception_->Observe();
  auto fim_pept_msg = ioadapter->getInputManager().m_sub_fim_perception_.GetLatest();
  if(fim_pept_msg) {
    fim_trafficlight_error_flag_ = fim_pept_msg->fim_trafficlight_error();
  }

  // ioadapter->getInputManager().world_model_dynamic_map_->Observe();
  auto wmdm_msg = ioadapter->getInputManager().world_model_dynamic_map_.GetLatest();
  if(wmdm_msg) {
    wm_dynamic_publish_ptp_ts_ = wmdm_msg->publish_ptp_ts();
  }

  const auto wm_map_time = apollo::cyber::Time(wm_dynamic_publish_ptp_ts_);
  const auto current_time = ncyber::Time::Now();
  double time_delta_sec = (current_time - wm_map_time).ToSecond();
  constexpr double kWMTopicLostTimeThresSec = 2.0;
  bool is_wmdm_comm_lost = time_delta_sec > kWMTopicLostTimeThresSec;

  uint8_t da_nad_sts = ioadapter->getMidOutputManager().getDAMainState().nadsts;
  // bit0: TD on critical app failure/topic loss during NP+/NOP/NOP.urban
  bool is_relLoc_abnormal_td_inhibit_flg = (7 == da_nad_sts || 9 == da_nad_sts || 11 == da_nad_sts) && 
                                            fim_rel_loc_abnoraml_flag_;
  // bit1: TD on critical app failure/topic loss during NP+/NOP.urban  
  bool is_exited_abnormal_td_inhibit_flg = (7 == da_nad_sts || 11 == da_nad_sts) && (fim_aa_app_abnoraml_flag_ || 
                                            fim_map_loc_app_abnoraml_flag_ || fim_trafficlight_error_flag_);
  // bit2: TD on communication lost during NP+/NOP.urban
  bool is_comm_lost_td_inhibit_flg = (7 == da_nad_sts || 11 == da_nad_sts) && is_wmdm_comm_lost;   

  uint32_t m_uBitNPTdInhibitTrigger = 0;
  if (is_relLoc_abnormal_td_inhibit_flg)
    m_uBitNPTdInhibitTrigger |= (0x01);
  if (is_exited_abnormal_td_inhibit_flg)
    m_uBitNPTdInhibitTrigger |= (0x01<<1);
  if (is_comm_lost_td_inhibit_flg)
    m_uBitNPTdInhibitTrigger |= (0x01<<2);

  ioadapter->getMidOutputManager().setNpTdInhibitInput(m_uBitNPTdInhibitTrigger);
}

void FCTInputAdapter::fill_eas_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // bit0: for example
  bool is_example_eas_inhibit_flg = false;

  uint32_t m_uBitNPEasInhibitTrigger = 0;
  if (is_example_eas_inhibit_flg)
    m_uBitNPEasInhibitTrigger |= (0x01);

  ioadapter->getMidOutputManager().setNpEasInhibitInput(m_uBitNPEasInhibitTrigger);
}

void FCTInputAdapter::fill_hard_inhibit_input(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  uint32_t m_uBitNPHardInhibitTrigger = 0;
  if (ioadapter->getFramePtr() != nullptr &&
      ioadapter->getFramePtr()->isNpPlusInstantOffFlagNearestJunction()) {
    m_uBitNPHardInhibitTrigger |= (0x01);
  }

  ioadapter->getMidOutputManager().setNpHardInhibitInput(m_uBitNPHardInhibitTrigger);
}

bool FCTInputAdapter::MainFcn(
  EHYVisionRoad* vision_road_ptr, VEHDYN* veh_dyn_ptr, VEHDRVR* veh_drvr_ptr, VEHWHL* veh_whl_ptr, VEHPT* veh_pt_ptr,
  VEHCTRL* veh_ctrl_ptr, VEHBODY* veh_body_ptr, STRSYS* str_sys_ptr, BRKSYS* brk_sys_ptr, EHYEVD* ehy_evd_ptr,
  EHYHA* ehy_ha_ptr, EHYRME* ehy_rme_ptr, EHYTPP* ehy_tpp_ptr, EHYLPP* ehy_lpp_ptr, EHYTSI* ehy_tsi_ptr,
  EHYTSE* ehy_tse_ptr, EHYVisionRoad* me_vision_road_ptr, DMS* dms_ptr, VisionFailSafe* vision_failsafe,
  FUNCARB* func_arb_ptr, CAMFIMINFO* cam_fim_ptr, VEHUPA* veh_upa_ptr, VEHPARAM* veh_param_ptr, BSDSTS* bsd_sts_ptr,
  SDMAP* adasmap_ptr, NopVehicleOut* nopvehicle_ptr, NopFunctionstatus* nopfucntion_ptr,
  NopChassisControl* nopchassis_ptr, NopSpeed* nopspeed_ptr, NopSpeedLimitValue* nopspeedlimitvalue_ptr,
  std::vector<feature::ehy::Object>* fused_obj_ptr, EHYOBF* ehy_obf_ptr, LIDARFAULTINFO* lidar_internalfault_ptr,
  AEBOUT* aebout_ptr, CfgTskSwt* cfgtaskmgr_ptr, NopPowerPilotState* noppowerpilotstate_ptr,
  GLOBALLOCALIZATION* global_locali_ptr, GlobalLocation* global_loc_mil_ptr, std::vector<HDLINK>* hdlink_ptr,
  EsdNpFeature* esdnpfeature_ptr, std::shared_ptr<planner::IOAdapter>& ioadapter, ADSOUT* ads_ptr,
  PERCEPTIONFIMINFO* perception_fim_ptr, LIDARFIMINFO* lidar_fim_ptr, DANOPSM* danop_sm, VisionRoadSign *road_sign_ptr) {

  receive_update();

  // if(fct_radar_data_.size()>0)
  // {
  //   fill_rdr_input(fct_radar_data_.back(), ehy_rdr_sensor);
  // }
  // if(fct_vision_objects_.size()>0)
  // {
  //   fill_vis_obj_input(fct_vision_objects_.back(), ehy_vis_obj);
  //   fill_fct_vis_obj_input(fct_vision_objects_.back(), vis_obj);
  // }
  if (fct_var_code_info.size() > 0 && fct_veh_adf_fod_info.size() > 0) {
    fill_veh_param_input(fct_var_code_info.back(), fct_veh_adf_fod_info.back(), veh_param_ptr);
  }

  if (fct_road_detection.size() > 0) {
    fill_vis_road_input(fct_road_detection.back(), vision_road_ptr, veh_param_ptr);
  }

  if (fct_ehy_evd.size() > 0) {
    fill_ehy_evd_input(fct_ehy_evd.back(), ehy_evd_ptr);
  }

  if (fct_ehy_ha.size() > 0) {
    fill_ehy_ha_input(fct_ehy_ha.back(), ehy_ha_ptr);
  }

  if (fct_ehy_tpp.size() > 0) {
    fill_ehy_lpp_input(fct_ehy_tpp.back(), ehy_lpp_ptr);
  }

  if (fct_ehy_rme.size() > 0) {
    fill_ehy_rme_input(fct_ehy_rme.back(), ehy_rme_ptr);
  }

  if (fct_ehy_tpp.size() > 0) {
    fill_ehy_tpp_input(fct_ehy_tpp.back(), ehy_tpp_ptr);
  }

  if (fct_ehy_tsi.size() > 0) {
    fill_ehy_tsi_input(fct_ehy_tsi.back(), ehy_tsi_ptr);
  }

  if (fct_ehy_tse.size() > 0) {
    fill_ehy_tse_input(fct_ehy_tse.back(), ehy_tse_ptr);
  }

  if (fct_fusion_object.size() > 0) {
    fill_obf_input(fct_fusion_object.back(), fused_obj_ptr, ehy_obf_ptr);
  }
  else {
    WARN_LOG << "debug fct_fusion_object.size(): " << fct_fusion_object.size();
  }

  if (fct_vehicle_input.size() > 0) {
    if (fct_vehicle_input.back()->veh10ms_time_pub() != veh10ms_publish_ptp_ts) {
      fill_veh10ms_input(fct_vehicle_input.back(), veh_dyn_ptr, veh_whl_ptr, veh_pt_ptr, veh_ctrl_ptr, str_sys_ptr,
                         brk_sys_ptr, ioadapter);
      veh10ms_publish_ptp_ts = fct_vehicle_input.back()->veh10ms_time_pub();
    }
    if (fct_vehicle_input.back()->veh50ms_time_pub() != veh50ms_publish_ptp_ts) {
      fill_veh50ms_input(fct_vehicle_input.back(), veh_drvr_ptr, veh_body_ptr, veh_upa_ptr, danop_sm);
      veh50ms_publish_ptp_ts = fct_vehicle_input.back()->veh50ms_time_pub();
    }
  }
  // if (fct_me_road_detection.size() > 0) {
  //   fill_me_vis_road_input(fct_me_road_detection.back(), me_vision_road_ptr);
  // }

  if (fct_dms_da_info.size() > 0 && fct_dms_result_info.size() > 0 && fct_adms_info.size() > 0) {
    fill_dms_input(fct_dms_da_info.back(), fct_dms_result_info.back(), fct_adms_info.back(), dms_ptr, ioadapter);
  }

  if (fct_failsafe_detection.size() > 0) {
    fill_vis_failsafe_input(fct_failsafe_detection.back(), vision_failsafe);
  }

  if (fct_func_arb_info.size() > 0) {
    fill_arb_input(fct_func_arb_info.back(), func_arb_ptr);
  }

  if (fct_parkingout_info.size() > 0) {
    fill_funcstatus_input(fct_parkingout_info.back(), func_arb_ptr);
  }

  if (fct_fim_camera_info.size() > 0) {
    fill_cam_fim_input(fct_fim_camera_info.back(), cam_fim_ptr);
  }

  if (AdasMap_info.size() > 0) {
    fill_adasmap_input(AdasMap_info.back(), adasmap_ptr);
  }

  if (fct_side_feature_.size() > 0) {
    fill_side_feature(fct_side_feature_.back(), bsd_sts_ptr);
  }
  /*
  if (NOP_vehicleout.size() > 0) {
    fill_nop_vehicleout_input(NOP_vehicleout.back(), nopvehicle_ptr);
  }*/
  /*
  if (Nop_chassisctrl.size() > 0) {
    fill_nop_chassis_ctrl_input(Nop_chassisctrl.back(), nopchassis_ptr);
  }
  if (NopFunction_Status.size() > 0) {
    fill_nop_functionstatus_input(NopFunction_Status.back(), nopfucntion_ptr);
  }
  if (NOP_speed.size() > 0) {
    fill_nop_speed_input(NOP_speed.back(), nopspeed_ptr);
  }*/
  if (nullptr != ioadapter) {
    fill_vis_road_sign_input(ioadapter, road_sign_ptr);
    fill_nop_vehicleout_input(nopvehicle_ptr, ioadapter);
    fill_nop_speed_input(nopspeed_ptr, ioadapter);
    fill_nop_chassis_ctrl_input(nopchassis_ptr, ioadapter);
    fill_nop_functionstatus_input(nopfucntion_ptr, ioadapter);
    fill_esdnpfeature_input(esdnpfeature_ptr, ioadapter);
    fill_dynamic_map_input(ioadapter);
    fill_fault_software_input(ioadapter);
    // ioadapter->getInputManager().m_sub_fault_function_->Observe();
    std::shared_ptr<nio::ad::messages::FunctionInfo> fault_function =
      ioadapter->getInputManager().m_sub_fault_function_.GetLatest();
    fill_fault_function_input(fault_function);
    fill_ad_inhibit_input(ioadapter);
    fill_td_inhibit_input(ioadapter);
    fill_eas_inhibit_input(ioadapter);
    fill_hard_inhibit_input(ioadapter);
    fill_active_prevention_input(ioadapter);
  }

  if (NOP_speedlimitvalue.size() > 0) {
    fill_nop_speedlimitvalue_input(NOP_speedlimitvalue.back(), nopspeedlimitvalue_ptr);
  }
  if (fct_Nop_powerpilotstate.size() > 0) {
    fill_nop_powerpilotstate_input(fct_Nop_powerpilotstate.back(), noppowerpilotstate_ptr);
  }
  if (fct_lidar_internalfault_info.size() > 0) {
    fill_lidar_internalfault_input(fct_lidar_internalfault_info.back(), lidar_internalfault_ptr);
  }

  if (FctsOut_info.size() > 0) {
    fill_aebout_input(FctsOut_info.back(), aebout_ptr);
  }
  if (fct_cfgtaskswitch_info.size() > 0) {
    fill_cfgtaskswitch_input(fct_cfgtaskswitch_info.back(), cfgtaskmgr_ptr);
  }
  if (cfgtaskswitch_size_last_ != static_cast<int>(fct_cfgtaskswitch_info.size())) {
    WARN_LOG << "cfgtaskswitch_out size from: " << cfgtaskswitch_size_last_ << " to "
             << static_cast<int>(fct_cfgtaskswitch_info.size());
  }
  cfgtaskswitch_size_last_ = static_cast<int>(fct_cfgtaskswitch_info.size());

  if (fct_global_locali_info.size() > 0) {
    fill_globallocalization_input(fct_global_locali_info.back(), global_locali_ptr, global_loc_mil_ptr);
  }

  if (fct_ads_info.size() > 0) {
    fill_ads_out_input(fct_ads_info.back(), ads_ptr);
  }

  if (fct_fim_perception_info.size() > 0) {
    fill_perception_fim_input(fct_fim_perception_info.back(), perception_fim_ptr);
  }

  if (fct_fim_lidar_info.size() > 0) {
    fill_lidar_fim_input(fct_fim_lidar_info.back(), lidar_fim_ptr);
  }

  // if (fct_hd_link_info.size() > 0) {
  //   fill_hd_link_input(fct_hd_link_info.back(), hdlink_ptr);
  // }

  // if (fct_esd_np_feature_info.size() > 0) {
  //   fill_esdnpfeature_input(fct_esd_np_feature_info.back(), esdnpfeature_ptr);
  // }

  // fill_npnopsm_input(danop_ptr);

  return true;
}
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
