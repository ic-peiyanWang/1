#include "fct_dastatemachine_adapter.h"
#include "fct_input_adapter.h"
#include "planner/io_manager/io_adapter.h"
#include "comm_exec.h"

namespace nio {
namespace ad {
namespace fctapp {

namespace {
constexpr float  kFCTStepTime_s               = 0.05;
constexpr float  kDaActvTrigDelayTime_s       = 1.0;
constexpr int    kPlannerStatusActvCircles    = 10;
constexpr int    kPlannerStatusDeactvCircles  = 3;
constexpr float  kWithinPSPGeoGenceTime_s     = 1.0;
constexpr float  kDAMainReqFunningLastTime_s  = 1.0;
}  // namespace

DAStateMachineAdapter da_statemachine_adapter;
uint16_t              uBitNopStatusTriggerSup;
uint16_t              uBitUrbanStatusTrigggerSup;
bool                  flagNopStatusActvTigger;
bool                  flagNopStatusDectvTigger;
uint16_t              priority_road_class_mp;
uint64_t              curr_link_id_mp;
int32_t               is_in_map_area_mp;
uint16_t              nop_task_state_mp;
uint8_t               nop_task_result_mp;
uint8_t               psp_status_mp;
uint8_t               np_activation_prevention_mp;
uint8_t               nop_status_mp;
bool                  is_planner_sts_mp;
bool                  is_nop_control_mp;
uint16_t              m_uBitNOPDebug_mp;
uint8_t               psp_status_dawti_mp;


void fct_fillNopStatus_debug_out(DAStateMachineAdapter* dastatemachine_adapter, uint16_t* uBit, bool* avtvflg,
                                 bool* deactvflg) {
  *uBit      = dastatemachine_adapter->fct_getNopTriggerFim();
  *avtvflg   = dastatemachine_adapter->fct_getNopActvTrigger();
  *deactvflg = dastatemachine_adapter->fct_getNopDeactvTrigger();
}

void fct_fillUrbanStatus_debug_out(DAStateMachineAdapter* dastatemachine_adapter, uint16_t* uBit) {
  *uBit = dastatemachine_adapter->fct_getUrbanDebugFim();
}

DAStateMachineAdapter::DAStateMachineAdapter() {}
DAStateMachineAdapter::~DAStateMachineAdapter() {}

void DAStateMachineAdapter::fct_procNopTrigger(const MainState_outputs_T&          mainstate,
                                               const DASM_Info& da_state_out, const VEHDRVR& vehdrvrptr,
                                               const std::shared_ptr<planner::IOAdapter>&   ioadapter,
                                               const GLOBALLOCALIZATION&                    global_locali,
                                               const NopPowerPilotState&                    power_pilot_state) {
  setDAMain_Attributes(mainstate,da_state_out);
  setVehInfoConfig(vehdrvrptr);
  setNopRelatedConditions(ioadapter);
  setNopPlannerSts(ioadapter);
  setGlobaLocalizationInfo(global_locali);
  setPSPTaskStatus(ioadapter);
  // nop unavaliable flag: nop state quit condition
  bool flag_nop_unavaliable = (FeatureFuncSts_e::OFF == m_da_funcSts) || (2 != m_strAssType) || (!is_subscribtion_nop && !is_subscribtion_nad)
                              || (0 == m_switchDA_NOP) || (!is_nop_scenemgmt_ok)
                              || (proc_nop_status_unavaliable(ioadapter));
  // nop avaliable flag: enter nop state pre condition
  bool flag_nop_avaliable = (is_subscribtion_nop || is_subscribtion_nad) && (is_nop_scenemgmt_ok) && (2 == m_strAssType)
                            && (1 == m_switchDA_NOP) && proc_nop_status_avaliable(ioadapter);
  const bool close_nop_urban = false;
  if (flag_nop_unavaliable) {
    m_nop_status = NOPStatus_e::NOPStatus_NotAvaliable;
  } else if ((DaNadSts_e::DaNOPActv == m_danadsts) && proc_nop_requestToPSP(ioadapter)) {
    m_nop_status = NOPStatus_e::NOPStatus_RequestPSP;
  } else if ((DaNadSts_e::DaNOPActv == m_danadsts) && proc_nop_requestToUrban(ioadapter) && close_nop_urban) {
    m_nop_status = NOPStatus_e::NOPStatus_RequestUrban;
  } else if (DaNadSts_e::DaNOPActv != m_danadsts) {
    if (flag_nop_avaliable) {
      m_nop_status = NOPStatus_e::NOPStatus_Avaliable;
    } else {
      m_nop_status = NOPStatus_e::NOPStatus_NotAvaliable;
    }
  }

  nop_status_mp = static_cast<uint8_t>(m_nop_status);

  DebugInfoForNOPStatus(ioadapter);
  LOG_IF_CHANGED(WARN, int(m_nop_status));
}

void DAStateMachineAdapter::fct_procUrbanStatus(const MainState_outputs_T&          mainstate,
                                                const DASM_Info& da_state_out, const VEHDRVR& vehdrvrptr,
                                                const std::shared_ptr<planner::IOAdapter>&   ioadapter,
                                                const GLOBALLOCALIZATION&                    global_locali,
                                                const NopPowerPilotState&                    power_pilot_state) {
  setVehInfoConfig(vehdrvrptr);
  setNopRelatedConditions(ioadapter);
  // setNopPlannerSts(ioadapter);  // called already in function fct_procNopTrigger(...)
  setGlobaLocalizationInfo(global_locali);
  setPSPTaskStatus(ioadapter);

  const bool close_urban_nop = false;

  if (FeatureFuncSts_e::OFF == m_da_funcSts
      || ((FeatureFuncSts_e::LOADED == m_da_funcSts || FeatureFuncSts_e::CHECKING == m_da_funcSts) || 2 != m_strAssType
          || (!is_subscribtion_nop && !is_subscribtion_nad))
      || proc_urban_status_unavaliable(ioadapter)) {
    m_urban_status = UrbanStatus_e::UrbanStatus_NotAvaliable;
  } else if ((FeatureFuncSts_e::RUNNING == m_da_funcSts || FeatureFuncSts_e::STANDBY == m_da_funcSts)
             && (is_subscribtion_nop || is_subscribtion_nad) && (is_nop_scenemgmt_ok) && (2 == m_strAssType || 2 == m_daCurvSpdAss)
             && proc_urban_status_avaliable(ioadapter)) {
    m_urban_status = UrbanStatus_e::UrbanStatus_Avaliable;
  } else if (proc_urban_requestToPSP(ioadapter)) {
    m_urban_status = UrbanStatus_e::UrbanStatus_RequestPSP;
  } else if (proc_urban_requestToNOP(ioadapter) && close_urban_nop) {
    m_urban_status = UrbanStatus_e::UrbanStatus_RequestNOP;
  } else {
    /*do nothing*/
  }

  DebugInfoForUrbanStatus(ioadapter);
  LOG_IF_CHANGED(WARN, int(m_urban_status));
}

void DAStateMachineAdapter::fct_outputNopFuncStatus(std::shared_ptr<planner::IOAdapter>& ioadapter) {
  ioadapter->getMidOutputManager().setFuncStatus(static_cast<proto::FunctionRequest>(nop_function_sts_));
}

void DAStateMachineAdapter::fct_outputPSPFuncStatus(std::shared_ptr<planner::IOAdapter>& ioadapter) {
  ioadapter->getMidOutputManager().setPSPFuncReq(static_cast<proto::FunctionRequest>(psp_function_sts_));
}

void DAStateMachineAdapter::proc_nop_funcStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out,
                                                std::shared_ptr<planner::IOAdapter>& ioadapter) {
  setDAMain_Attributes(mainstate, da_state_out);
  if (FeatureFuncSts_e::OFF == m_da_funcSts || mainstate.EDAInfo.EDAActv) {
    nop_function_sts_ = NOPFunctionSts_e::REQ_OFF;  // Off
  } else if (flag_nop_status_standby) {
    nop_function_sts_ = NOPFunctionSts_e::REQ_STANDBY;
  } else if (DaNadSts_e::DaNOPActv == m_danadsts || DaNadSts_e::DaNADEngaged == m_danadsts
             || DaNadSts_e::DaNADTrsnDmd == m_danadsts) {
    nop_function_sts_ = NOPFunctionSts_e::REQ_RUNNING;  // Running
  } else {
    nop_function_sts_ = NOPFunctionSts_e::REQ_CHECKING;  // Checking
  }
  if (ioadapter == nullptr) { return; }
  auto nad_sm_debug = ioadapter->getMidOutputManager().getStateMachineDebug();
  if (nad_sm_debug.has_dasm_ioadaptor() &&
      nad_sm_debug.dasm_ioadaptor().has_is_nad_selected_by_dc_flg() &&
      nad_sm_debug.dasm_ioadaptor().is_nad_selected_by_dc_flg()) {
    // new state machine
    nop_function_sts_ = static_cast<NOPFunctionSts_e>(
        ioadapter->getMidOutputManager().getNadFuncStatus());
  }
  LOG_IF_CHANGED(WARN, int(nop_function_sts_));
}

void DAStateMachineAdapter::proc_psp_funcStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out) {
  setDAMain_Attributes(mainstate,da_state_out);
  if (FeatureFuncSts_e::OFF == m_da_funcSts) {
    psp_function_sts_ = PSPFunctionSts_e::REQ_PSP_OFF;  // Off
  } else if (DaNadSts_e::DaNADEngaged == m_danadsts) {
    psp_function_sts_ = PSPFunctionSts_e::REQ_PSP_RUNNING;  // psp Running
  } else if (DaNadSts_e::MdRdy == m_danadsts) {
    psp_function_sts_ = PSPFunctionSts_e::REQ_PSP_STANDBY;  // psp Standby
  } else {
    psp_function_sts_ = PSPFunctionSts_e::REQ_PSP_CHECKING;  // psp Checking
  }
  LOG_IF_CHANGED(WARN, int(psp_function_sts_));
}

void DAStateMachineAdapter::setDAMain_Attributes(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out) {
  m_da_funcSts = static_cast<FeatureFuncSts_e>(da_state_out.hwa_sm_op.DAFuncSts);
  m_danadsts   = static_cast<DaNadSts_e>(da_state_out.hwa_sm_op.NadSts);
  m_daInhibit  = static_cast<unsigned int>(mainstate.NpCdn.DAInhibitForNop);
  flag_nop_status_standby = static_cast<bool>(mainstate.NOPStsStandby);
}

void DAStateMachineAdapter::setVehInfoConfig(const VEHDRVR& vehdrvrptr) {
  m_strAssType = static_cast<int32_t>(vehdrvrptr.AdFunCfg.SetDA_SteerAssist);
  m_switchDA_NOP = static_cast<int32_t>(vehdrvrptr.SwtichDA_NOP);
  m_daCurvSpdAss = static_cast<int32_t>(vehdrvrptr.AdFunCfg.CurveSpeedAssist);

  if (fct_var_code_info.size() > 0 && fct_veh_adf_fod_info.size() > 0) {
    auto var_code_info_ptr = fct_var_code_info.back();
    auto veh_adf_fod_ptr = fct_veh_adf_fod_info.back();
    is_subscribtion_nop = false;
    is_subscribtion_nad = false;
    if (veh_adf_fod_ptr->adf_list_size() > 0) {
      for (const auto& adf : veh_adf_fod_ptr->adf_list()) {
        if (adf.key() == "nop_plus_highway") {
          is_subscribtion_nop = adf.value();
        }
        else if (adf.key() == "NADBeta") {
          is_subscribtion_nad = adf.value();
        }
      }
    }
    sales_region           = static_cast<uint8_t>(var_code_info_ptr->variant_code_info().sales_region());
  }
}

void DAStateMachineAdapter::setNopRelatedConditions(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  is_nop_ctrlCmd_lossCom = ioadapter->getMidOutputManager().getNopChassisControlInfo().getFlagIsNopControlCommand();
  is_nop_control         = ioadapter->getMidOutputManager().getNopChassisControlInfo().getFlagIsNopControl();
  nop_takeover_req       = ioadapter->getMidOutputManager().getNopChassisControlInfo().getFlagIsNopTakeover();
  m_priorityRoadClass    = static_cast<PriorityRoadClass_e>(ioadapter->getMidOutputManager().getRoadClass());
  is_nop_scenemgmt_ok    = ioadapter->getMidOutputManager().getSceneMgmtOk();
  is_local_route_end     = ioadapter->getMidOutputManager().getFlagLocalRouteEnd();

  // if (!ioadapter->getInputManager().car_state_reader)
  //   return;
  auto car_state_msg = ioadapter->getInputManager().car_state_.GetLatest();
  if (car_state_msg && car_state_msg->has_canbus_status()) {
    is_canbus_sts = car_state_msg->canbus_status();
  }

}

// Only allowed to be called once!!!
void DAStateMachineAdapter::setNopPlannerSts(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const bool curr_planner_sts = ioadapter->getMidOutputManager().getIsPlanner();
  if (!last_planner_sts && curr_planner_sts)
    planner_sts_activate_timer = 0;
  if (curr_planner_sts) {
    if (planner_sts_activate_timer > kPlannerStatusActvCircles) {
      is_planner_sts      = true;
      is_planner_sts_last = true;
    }
    planner_sts_activate_timer++;
    planner_sts_activate_timer = fmin(planner_sts_activate_timer, 50);
  } else {
    if (is_planner_sts_last)
      planner_sts_deactivate_timer = kPlannerStatusDeactvCircles;
    if (planner_sts_deactivate_timer > 0) {
      is_planner_sts = true;
    } else {
      is_planner_sts = false;
    }
    planner_sts_deactivate_timer--;
    planner_sts_deactivate_timer = fmax(planner_sts_deactivate_timer, 0);
    is_planner_sts_last = false;
  }

  last_planner_sts = curr_planner_sts;
}

bool DAStateMachineAdapter::getFlagNopTransToPSPFailed(const std::shared_ptr<planner::IOAdapter>& ioadapter,
                                                       const GLOBALLOCALIZATION&                  global_locali) {
  static bool  is_trans_failed_last  = false;
  static float is_trans_failed_timer = 0.0;
  bool         is_trans_failed_debounced  = false;
  setGlobaLocalizationInfo(global_locali);

  const auto& OddScenario = ioadapter->getMidOutputManager().getOddScenario();
  bool is_trans_failed = (OddScenario == nio::planner::OddScenario::InPspArea);

  if (!is_trans_failed || (!is_trans_failed_last && is_trans_failed))
    is_trans_failed_timer = 0.0;
  if (is_trans_failed) {
    if (is_trans_failed_timer >= kWithinPSPGeoGenceTime_s)
      is_trans_failed_debounced = true;
    is_trans_failed_timer += kFCTStepTime_s;
    is_trans_failed_timer = fmin(is_trans_failed_timer, kWithinPSPGeoGenceTime_s);
  }

  is_trans_failed_last = is_trans_failed;

  return is_trans_failed_debounced;
}

void DAStateMachineAdapter::setGlobaLocalizationInfo(const GLOBALLOCALIZATION& global_locali) {
  m_currLinkId = global_locali.lane_loc.curr_link_id;
  m_isInMapArea = static_cast<bool>(global_locali.auxiliary_parking_info.is_in_map_area);
}

void DAStateMachineAdapter::setPSPTaskStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  m_pspTaskStatus = static_cast<TaskState_e>(ioadapter->getMidOutputManager().getPSPStatus()->task_state());
  m_pspTaskResult = static_cast<int>(ioadapter->getMidOutputManager().getPSPStatus()->task_result());
}

bool DAStateMachineAdapter::proc_nop_status_avaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& odd_state_status = ioadapter->getMidOutputManager().getOddOeCheckingStatus();
  return (odd_state_status.is_odd_range_standby_         // 2. check odd
          && !odd_state_status.is_route_range_checking_  // 3. check route boundary
          && !is_nop_ctrlCmd_lossCom                     // 4. check msg receive status
          && (is_planner_sts)                            // 5. check planner status
          // && is_nop_control                                // 6. check controller status
          // && !nop_takeover_req                             // 7. check take over request
          && (odd_state_status.is_oe_range_standby_)       // 8. check oe
          && (!odd_state_status.is_offramp_checking_)      // 9. check offramp
          && (!odd_state_status.is_dim_confidence_)
          && (!is_local_route_end)
          && (PriorityRoadClass_e::MOTORWAY == m_priorityRoadClass || PriorityRoadClass_e::CITY_MOTORWAY == m_priorityRoadClass)
          && is_canbus_sts)
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_nop_status_unavaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& odd_state_status = ioadapter->getMidOutputManager().getOddOeCheckingStatus();
  return (odd_state_status.is_odd_range_checking_       // 2. check odd
          || (odd_state_status.is_route_range_checking_)  // 3. check route boundary
          || is_nop_ctrlCmd_lossCom                       // 4. check msg receive status
          || (!is_planner_sts)                            // 5. check planner status
          // || !is_nop_control                              // 6. check controller status
          // || nop_takeover_req                             // 7. check take over request-remove to trans to longOnly
          || (odd_state_status.is_oe_lc_checking_)        // 8.check user lane change coming to operation bound
          // || (odd_state_status.is_oe_range_checking_)     // 9.check operation bound -> move to hardinhibit--instant off
          || (odd_state_status.is_offramp_checking_)      // 10. check offramp
          || is_local_route_end                          // local route is end
          || (!is_canbus_sts))
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_nop_requestToPSP(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  return (1 >= m_daInhibit && 0 != m_currLinkId && PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == m_priorityRoadClass
          && m_isInMapArea
          && (TaskState_e::NAV_TO_QUEUE_AREA == m_pspTaskStatus || TaskState_e::NAV_TO_PSAP_LOC_BOX == m_pspTaskStatus)
          && (!is_nop_ctrlCmd_lossCom) && is_planner_sts && is_nop_control && !nop_takeover_req)
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_nop_requestToUrban(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  int is_in_dynamic_area = ioadapter->getMidOutputManager().getisinDynamicArea();
  return (0 != m_currLinkId && PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD != m_priorityRoadClass
          && is_in_dynamic_area && m_urban_status == UrbanStatus_e::UrbanStatus_Avaliable
          && (!is_nop_ctrlCmd_lossCom) && is_planner_sts && is_nop_control && !nop_takeover_req)
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_urban_status_avaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // TODO : is_nop_control and update NOPStsStandby
  int odd_nad_status = ioadapter->getMidOutputManager().getUrbanStatus();
  AINFO << "proc_urban_status_avaliable odd_nad_status : " << odd_nad_status;
  return (odd_nad_status == 1
          && (!is_nop_ctrlCmd_lossCom)
          && is_planner_sts
          // && is_nop_control
          && (!is_local_route_end)
          && (!nop_takeover_req)
          && is_canbus_sts)
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_urban_status_unavaliable(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  // TODO : is_nop_control and update NOPStsStandby
  int odd_nad_status = ioadapter->getMidOutputManager().getUrbanStatus();
  AINFO << "proc_urban_status_unavaliable odd_nad_status : " << odd_nad_status;
  const auto& odd_state_status = ioadapter->getMidOutputManager().getOddOeCheckingStatus();
  const bool found_warning_element = (ioadapter->getMidOutputManager().getCheckpointFound()
                                     || ioadapter->getMidOutputManager().getTollFound());
  return (odd_nad_status == 0
          || is_nop_ctrlCmd_lossCom
          || !is_planner_sts
          || nop_takeover_req
          || is_local_route_end
          || !is_canbus_sts
          || (odd_state_status.is_route_range_checking_)
          || (odd_state_status.is_oe_lc_checking_)
          || (odd_state_status.is_odd_range_checking_ && (!found_warning_element))
          || (odd_state_status.is_offramp_checking_))
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_urban_requestToPSP(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  return (0 != m_currLinkId && PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == m_priorityRoadClass
          && m_isInMapArea && DaNadSts_e::DaNADEngaged == m_danadsts && psp_status == PSPSts_e::PSPSts_Available
          && (TaskState_e::NAV_TO_QUEUE_AREA == m_pspTaskStatus || TaskState_e::NAV_TO_PSAP_LOC_BOX == m_pspTaskStatus)
          && (!is_nop_ctrlCmd_lossCom) && is_planner_sts && is_nop_control && !nop_takeover_req && is_canbus_sts)
           ? true
           : false;
}

bool DAStateMachineAdapter::proc_urban_requestToNOP(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  int odd_nad_status = ioadapter->getMidOutputManager().getUrbanStatus();
  return (odd_nad_status == 2
          && 0 != m_currLinkId
          && (!is_nop_ctrlCmd_lossCom) && is_planner_sts && is_nop_control && !nop_takeover_req && is_canbus_sts)
           ? true
           : false;
}

void DAStateMachineAdapter::DebugInfoForNOPStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  const auto& odd_state_status = ioadapter->getMidOutputManager().getOddOeCheckingStatus();
  m_uBitNOPDebug = 0;
  if (!is_nop_control)
    m_uBitNOPDebug |= (0x01);
  if (3 == m_daInhibit || 4 == m_daInhibit)
    m_uBitNOPDebug |= (0x01 << 1);
  if (odd_state_status.is_odd_range_checking_)
    m_uBitNOPDebug |= (0x01 << 2);
  if (odd_state_status.is_route_range_checking_)
    m_uBitNOPDebug |= (0x01 << 3);
  if (is_nop_ctrlCmd_lossCom)
    m_uBitNOPDebug |= (0x01 << 4);
  if (!is_planner_sts)
    m_uBitNOPDebug |= (0x01 << 5);
  if (nop_takeover_req)
    m_uBitNOPDebug |= (0x01 << 6);
  if (odd_state_status.is_oe_lc_checking_)
    m_uBitNOPDebug |= (0x01 << 7);
  if (odd_state_status.is_oe_range_checking_)
    m_uBitNOPDebug |= (0x01 << 8);
  if (odd_state_status.is_offramp_checking_)
    m_uBitNOPDebug |= (0x01 << 9);
  if (!odd_state_status.is_odd_range_standby_)
    m_uBitNOPDebug |= (0x01 << 10);
  if (!odd_state_status.is_oe_range_standby_)
    m_uBitNOPDebug |= (0x01 << 11);
  if (odd_state_status.is_dim_confidence_)
    m_uBitNOPDebug |= (0x01 << 12);
  if (is_local_route_end)
    m_uBitNOPDebug |= (0x01 << 13);
  if (!is_canbus_sts)
    m_uBitNOPDebug |= (0x01 << 14);

  // if (m_uBitNOPDebug) {
  //   WARN_LOG << "fct nop debug bit: " << static_cast<uint32_t>(m_uBitNOPDebug);
  // }
  LOG_IF_CHANGED(WARN, int(m_uBitNOPDebug));
}

void DAStateMachineAdapter::DebugInfoForUrbanStatus(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  int is_in_dynamic_area = ioadapter->getMidOutputManager().getisinDynamicArea();
  int odd_nad_status = ioadapter->getMidOutputManager().getUrbanStatus();
  AINFO << "debug_sm odd_nad_status : " << odd_nad_status;
  m_uBitUrbanDebug = 0;
  if (is_in_dynamic_area)
    m_uBitUrbanDebug |= (0x01);
  if (odd_nad_status == 0)
    m_uBitUrbanDebug |= (0x01 << 1);
  if (odd_nad_status == 1)
    m_uBitUrbanDebug |= (0x01 << 2);
  if (odd_nad_status == 2)
    m_uBitUrbanDebug |= (0x01 << 3);
  if (m_urban_status == UrbanStatus_e::UrbanStatus_Avaliable)
    m_uBitUrbanDebug |= (0x01 << 4);
  if (is_nop_ctrlCmd_lossCom)
    m_uBitUrbanDebug |= (0x01 << 5);
  if (!is_planner_sts)
    m_uBitUrbanDebug |= (0x01 << 6);
  if (nop_takeover_req)
    m_uBitUrbanDebug |= (0x01 << 7);
  if (!is_nop_control)
    m_uBitUrbanDebug |= (0x01 << 8);
  if (m_urban_status == UrbanStatus_e::UrbanStatus_RequestNOP)
    m_uBitUrbanDebug |= (0x01 << 9);
  if (0 == m_currLinkId)
    m_uBitUrbanDebug |= (0x01 << 10);
  if (PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == m_priorityRoadClass)
    m_uBitUrbanDebug |= (0x01 << 11);
  if (!m_isInMapArea)
    m_uBitUrbanDebug |= (0x01 << 12);
  if (TaskState_e::NAV_TO_QUEUE_AREA != m_pspTaskStatus || TaskState_e::NAV_TO_PSAP_LOC_BOX != m_pspTaskStatus)
    m_uBitUrbanDebug |= (0x01 << 13);

  LOG_IF_CHANGED(WARN, int(m_uBitUrbanDebug));
}

void DAStateMachineAdapter::setPSPStatus(const std::vector<HDLINK>& HdLink, const GLOBALLOCALIZATION& global_locali,
                                         const NopPowerPilotState&                  power_pilot_state,
                                         const std::shared_ptr<planner::IOAdapter>& ioadapter) {

  setPSPTaskStatus(ioadapter);
  setNopRelatedConditions(ioadapter);
  // setNopPlannerSts(ioadapter); // called already in function fct_procNopTrigger(...)
  const auto& odd_state_status = ioadapter->getMidOutputManager().getOddOeCheckingStatus();

  // psp req to urban
  float dist_to_odd3 = 0;

  //m_is_in_map_area = global_locali.auxiliary_parking_info.is_in_map_area;
  m_is_in_map_area = (ioadapter->getMidOutputManager().getOddScenario() == nio::planner::OddScenario::InPspArea)
                     || (ioadapter->getFramePtr() && ioadapter->getFramePtr()->isFs());

  const auto& priority_road_class = static_cast<PriorityRoadClass_e>(ioadapter->getMidOutputManager().getRoadClass());
  static PriorityRoadClass_e priority_road_class_last = PriorityRoadClass_e::MOTORWAY;
  static bool                first_cycle              = true;
  if (priority_road_class != priority_road_class_last || first_cycle) {
    WARN_LOG << "priority_road_class: " << static_cast<uint64_t>(priority_road_class);
    first_cycle = false;
  }

  static uint64_t curr_link_id_last = 0;
  if (global_locali.lane_loc.curr_link_id != curr_link_id_last) {
    WARN_LOG << "curr_link_id: " << static_cast<uint64_t>(global_locali.lane_loc.curr_link_id);
  }

  static int32_t is_in_map_area_last = 0;
  if (global_locali.auxiliary_parking_info.is_in_map_area != is_in_map_area_last) {
    WARN_LOG << "is_in_map_area: " << static_cast<uint64_t>(global_locali.auxiliary_parking_info.is_in_map_area);
  }

  static TaskState_e nop_task_state_last = TaskState_e::FINISH;
  static bool        first_cycle_noptask = true;
  if (m_pspTaskStatus != nop_task_state_last || first_cycle_noptask) {
    WARN_LOG << "nop_task_state: " << static_cast<uint64_t>(m_pspTaskStatus);
    first_cycle_noptask = false;
  }

  static PSPSts_e psp_status_last = PSPSts_e::PSPSts_NotAvailable;

  if (DaNadSts_e::DaNADEngaged == m_danadsts && is_planner_sts && is_canbus_sts && is_nop_control
      && 0 != global_locali.lane_loc.curr_link_id
      && (PriorityRoadClass_e::MOTORWAY == priority_road_class
          || PriorityRoadClass_e::CITY_MOTORWAY == priority_road_class)
      && odd_state_status.is_odd_range_standby_ && !(odd_state_status.is_route_range_checking_)
      && odd_state_status.is_oe_range_standby_ && (m_daCurvSpdAss == 0)) {
    this->psp_status = PSPSts_e::PSPSts_ReqEngageNOP;
  } else if (DaNadSts_e::DaNADEngaged == m_danadsts && is_planner_sts && is_canbus_sts && is_nop_control
             && 0 != global_locali.lane_loc.curr_link_id
             && (PriorityRoadClass_e::NATIONAL_HIGHWAY == priority_road_class
                 || PriorityRoadClass_e::PROVINCIAL_HIGHWAY == priority_road_class
                 || PriorityRoadClass_e::COUNTY_ROAD == priority_road_class
                 || PriorityRoadClass_e::TOWNSHIP_ROAD == priority_road_class
                 || PriorityRoadClass_e::OTHER_ROAD == priority_road_class)
             && dist_to_odd3 > 500  && (m_daCurvSpdAss == 1)) {
    this->psp_status = PSPSts_e::PSPSts_ReqEngageUrban;
  } else if (is_planner_sts && PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == priority_road_class
             && 1 == global_locali.auxiliary_parking_info.is_in_map_area && is_canbus_sts
             && (TaskState_e::NAV_TO_QUEUE_AREA == m_pspTaskStatus
                 || TaskState_e::NAV_TO_PSAP_LOC_BOX == m_pspTaskStatus
                 || TaskState_e::IN_QUEUE_AREA == m_pspTaskStatus
                 || TaskState_e::IN_PSAP_LOC_BOX == m_pspTaskStatus
                 || TaskState_e::NAV_TO_HIGHWAY == m_pspTaskStatus)) {
  // } else if (true) {
    this->psp_status = PSPSts_e::PSPSts_Available;
  } else {
    this->psp_status = PSPSts_e::PSPSts_NotAvailable;
  }

  if (this->psp_status == PSPSts_e::PSPSts_Available) {
    ioadapter->getMidOutputManager().setDaMainPSPAvailable(true);
  } else {
    ioadapter->getMidOutputManager().setDaMainPSPAvailable(false);
  }

  if (DaNadSts_e::DaNADEngaged == m_danadsts && is_planner_sts && is_nop_control && is_canbus_sts
      && 0 != global_locali.lane_loc.curr_link_id
      && (PriorityRoadClass_e::MOTORWAY == priority_road_class
          || PriorityRoadClass_e::CITY_MOTORWAY == priority_road_class)
      && odd_state_status.is_odd_range_standby_ && !(odd_state_status.is_route_range_checking_)
      && odd_state_status.is_oe_range_standby_) {
    this->psp_status_dawti = PSPSts_e::PSPSts_ReqEngageNOP;
  } else if (DaNadSts_e::DaNADEngaged == m_danadsts && is_planner_sts && is_nop_control && is_canbus_sts
             && 0 != global_locali.lane_loc.curr_link_id
             && (PriorityRoadClass_e::NATIONAL_HIGHWAY == priority_road_class
                 || PriorityRoadClass_e::PROVINCIAL_HIGHWAY == priority_road_class
                 || PriorityRoadClass_e::COUNTY_ROAD == priority_road_class
                 || PriorityRoadClass_e::TOWNSHIP_ROAD == priority_road_class
                 || PriorityRoadClass_e::OTHER_ROAD == priority_road_class)
             && dist_to_odd3 > 500) {
    this->psp_status_dawti = PSPSts_e::PSPSts_ReqEngageUrban;
  } else if (PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == priority_road_class
             && 1 == global_locali.auxiliary_parking_info.is_in_map_area
             && (TaskState_e::NAV_TO_QUEUE_AREA == m_pspTaskStatus
                 || TaskState_e::NAV_TO_PSAP_LOC_BOX == m_pspTaskStatus
                 || TaskState_e::IN_QUEUE_AREA == m_pspTaskStatus
                 || TaskState_e::IN_PSAP_LOC_BOX == m_pspTaskStatus
                 || TaskState_e::NAV_TO_HIGHWAY == m_pspTaskStatus)) {
  // } else if (true) {
    this->psp_status_dawti = PSPSts_e::PSPSts_Available;
  } else {
    this->psp_status_dawti = PSPSts_e::PSPSts_NotAvailable;
  }

  if (this->psp_status != psp_status_last) {
    WARN_LOG << "psp_status: " << static_cast<uint64_t>(this->psp_status);
  }

  if ((0 == global_locali.lane_loc.curr_link_id && 1 == global_locali.auxiliary_parking_info.is_in_map_area)
      || (0 != global_locali.lane_loc.curr_link_id && 1 == global_locali.auxiliary_parking_info.is_in_map_area
          && PriorityRoadClass_e::SERVICE_AREA_INNER_ROAD == priority_road_class)) {
    this->np_activation_prevention = true;
    ioadapter->getMidOutputManager().setPSPGeofence(true);
  } else {
    this->np_activation_prevention = false;
    ioadapter->getMidOutputManager().setPSPGeofence(false);
  }

  static bool np_activation_prevention_last = false;
  if (np_activation_prevention_last != this->np_activation_prevention) {
    WARN_LOG << "np_activation_prevention: " << static_cast<uint64_t>(this->np_activation_prevention);
  }

  priority_road_class_last      = priority_road_class;
  curr_link_id_last             = global_locali.lane_loc.curr_link_id;
  is_in_map_area_last           = global_locali.auxiliary_parking_info.is_in_map_area;
  nop_task_state_last           = m_pspTaskStatus;
  psp_status_last               = this->psp_status;
  np_activation_prevention_last = this->np_activation_prevention;

  priority_road_class_mp      = static_cast<uint16_t>(priority_road_class);
  curr_link_id_mp             = static_cast<uint64_t>(global_locali.lane_loc.curr_link_id);
  is_in_map_area_mp           = static_cast<int32_t>(global_locali.auxiliary_parking_info.is_in_map_area);
  nop_task_state_mp           = static_cast<uint16_t>(m_pspTaskStatus);
  nop_task_result_mp          = static_cast<uint8_t>(m_pspTaskResult);
  psp_status_mp               = static_cast<uint8_t>(this->psp_status);
  np_activation_prevention_mp = static_cast<uint8_t>(this->np_activation_prevention);
  is_planner_sts_mp           = static_cast<bool>(is_planner_sts);
  is_nop_control_mp           = static_cast<bool>(is_nop_control);
  psp_status_dawti_mp         = static_cast<uint8_t>(this->psp_status_dawti);
}

void DAStateMachineAdapter::setioadapter(const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  io_adapter_ = ioadapter;
}

void DAStateMachineAdapter::processDANBCAvlStatus(const MainState_outputs_T& mainstate, const DASM_Info& da_state_out,
                                                  const VEHDRVR& vehdrvrptr, const FUNCARB& funcarb) {
  setDAMain_Attributes(mainstate, da_state_out);
  setVehInfoConfig(vehdrvrptr);

  // 201-DAmain FuncReq = "ReqRunning" within last 5s
  static float function_req_running_timmer = 0;
  // const bool damain_function_req_running =
  //   (201 == funcarb.FunctionReq[0].FunctionID) && (FunctionRequest_e::ReqRunning == funcarb.FunctionReq[0].FuncReq);
  bool damain_function_req_running = false;
  if (io_adapter_ != nullptr && io_adapter_->getMidOutputManager().getPlatformNt3Flag()) {
    damain_function_req_running = ACCSC_flgSwPilotOriginal_mp || ACCSC_flgSwResumeOriginal_mp;
  } else {
    damain_function_req_running = mainstate.NpCdn.SwPilot || mainstate.NpCdn.SwResume;
  }
  bool damain_function_req_running_keep = false;
  if (damain_function_req_running) {
    function_req_running_timmer      = kDAMainReqFunningLastTime_s;
    damain_function_req_running_keep = true;
  } else {
    damain_function_req_running_keep = function_req_running_timmer > 0;
    function_req_running_timmer -= kFCTStepTime_s;
    function_req_running_timmer = fmax(function_req_running_timmer, 0);
  }

  // reset timer
  if (static_cast<uint8_t>(m_danadsts) != 2) {
    function_req_running_timmer = -1.0;
    damain_function_req_running_keep = false;
  }

  proto::NOPSenarioType senario;
  bool is_nop_available_flg = false;
  bool is_psp_available_flg = false;
  bool is_nad_available_flg = false;
  bool is_lcc_plus_avail_flg = false;

  if (io_adapter_ != nullptr &&
      io_adapter_->getMidOutputManager().getStateMachineDebug().has_dasm_ioadaptor() &&
      io_adapter_->getMidOutputManager().getStateMachineDebug().has_danadsts_enum()) {
    auto sm_debug = io_adapter_->getMidOutputManager().getStateMachineDebug();
    senario = sm_debug.dasm_ioadaptor().nop_senario();
    if (sm_debug.danadsts_enum() == 3 &&
        sm_debug.dasm_ioadaptor().psp_available_flg()) {
      is_psp_available_flg = true;
    } else if (sm_debug.danadsts_enum() == 5 &&
               sm_debug.dasm_ioadaptor().nop_available_flg()) {
      if (!sm_debug.dasm_ioadaptor().is_in_navigation_flg() ||  
          !sm_debug.dasm_ioadaptor().is_in_odd_flg() ||
           sm_debug.dasm_ioadaptor().nop_act_prev_flg() ||
           sm_debug.dasm_ioadaptor().nop_suppression_flg()) {
        is_lcc_plus_avail_flg = true;
      } else if (senario == proto::NOPSenarioType::NOPSenario_Highway) {
        is_nop_available_flg = true;
      } else if (senario == proto::NOPSenarioType::NOPSenario_Urban) {
        is_nad_available_flg = true;
      }
    } else if (sm_debug.danadsts_enum() == 7) {
      is_lcc_plus_avail_flg = true;
    } else if (sm_debug.danadsts_enum() == 9) {
      is_nop_available_flg = true;
    } else if (sm_debug.danadsts_enum() == 10) {
      is_psp_available_flg = true;
    } else if (sm_debug.danadsts_enum() == 11) {
      is_nad_available_flg = true;
    }
  }

  // NOP_ExpectedToActivate
  // bool is_nop_expected_to_activete =
  //   (2 == m_strAssType) && (!is_subscribtion_nad)
  //   && (!mainstate.NOPCdn_out.NOPActivationPrevention && !mainstate.NOPCdn_out.NOPSuppression
  //       && NOPStatus_e::NOPStatus_Avaliable == m_nop_status);

  // NAD_ExpectedToActivate
  // bool is_nad_expected_to_activete =
  //   (2 == m_strAssType) && (1 == sales_region) && (1 == m_daCurvSpdAss)
  //   && (!mainstate.NOPCdn_out.UrbanActivationPrevention && !mainstate.NOPCdn_out.UrbanSuppression
  //       && UrbanStatus_e::UrbanStatus_Avaliable == m_urban_status);

  da_iacc_avl = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  da_pilot_avl = DAPilotAvl_e::DA_PILOT_NOTAVAIABLE;
  da_nad_avl = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  da_psp_avl = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;
  da_nop_avl = DAiAccNOPPSPNADAvl_e::DA_NOTAVAIABLE;

  if (mainstate.EDAInfo.EDAActv) {
    // eas active
    INFO_LOG << "EAS Active, DA Not Available";
  } else if (static_cast<uint8_t>(m_danadsts) < 6 && damain_function_req_running_keep && 0 == m_strAssType) {
    // DA_iAcc_Act_Failed
    da_iacc_avl = DAiAccNOPPSPNADAvl_e::DA_ACTIVATEFAILED;
  } else if (DaNadSts_e::MdAccStby == m_danadsts && 0 == m_daInhibit && !mainstate.NpCdn.ActPrev) {
    // DA_iAcc_Avl
    da_iacc_avl = DAiAccNOPPSPNADAvl_e::DA_AVAIABLE;
  } else if (static_cast<uint8_t>(m_danadsts) < 6 && damain_function_req_running_keep
             && (1 == m_strAssType
                 || (2 == m_strAssType && !is_nop_available_flg && !is_psp_available_flg
                     && !is_nad_available_flg))) {
    // DA_Pilot_Act_Failed
    da_pilot_avl = mainstate.NpCdn.LatInh || !is_lcc_plus_avail_flg ? DAPilotAvl_e::DA_PILOT_ACTIVATEFAILED_LONGONLY
                                                                    : DAPilotAvl_e::DA_PILOT_ACTIVATEFAILED_LONGLAT;
  } else if (DaNadSts_e::MdPilotStby == m_danadsts && 0 == m_daInhibit && !mainstate.NpCdn.ActPrev
             && !is_nop_available_flg && !is_psp_available_flg && !is_nad_available_flg) {
    // DA_Pilot_Avl
    da_pilot_avl = mainstate.NpCdn.LatInh || !is_lcc_plus_avail_flg ? DAPilotAvl_e::DA_PILOT_AVAIABLE_LONGONLY
                                                                    : DAPilotAvl_e::DA_PILOT_AVAIABLE_LONGLAT;
  } else if (static_cast<uint8_t>(m_danadsts) < 6 && damain_function_req_running_keep && is_nop_available_flg) {
    // DA_NOP_Act_Failed
    da_nop_avl = DAiAccNOPPSPNADAvl_e::DA_ACTIVATEFAILED;
  } else if (DaNadSts_e::MdPilotStby == m_danadsts && is_nop_available_flg) {
    // DA_NOP_Avl
    da_nop_avl = DAiAccNOPPSPNADAvl_e::DA_AVAIABLE;
  } else if (static_cast<uint8_t>(m_danadsts) < 6 && damain_function_req_running_keep && is_psp_available_flg) {
    // DA_PSP_Act_Failed
    da_psp_avl = DAiAccNOPPSPNADAvl_e::DA_ACTIVATEFAILED;
  } else if (DaNadSts_e::MdRdy == m_danadsts && is_psp_available_flg) {
    // DA_PSP_Avl
    da_psp_avl = DAiAccNOPPSPNADAvl_e::DA_AVAIABLE;
  } else if (static_cast<uint8_t>(m_danadsts) < 6 && damain_function_req_running_keep && is_nad_available_flg) {
    // DA_NAD_Act_Failed
    da_nad_avl = DAiAccNOPPSPNADAvl_e::DA_ACTIVATEFAILED;
  } else if (DaNadSts_e::MdPilotStby == m_danadsts && is_nad_available_flg) {
    // DA_NAD_Avl
    da_nad_avl = DAiAccNOPPSPNADAvl_e::DA_AVAIABLE;
  } else if (DaNadSts_e::DaAccActv == m_danadsts) {
    da_iacc_avl = DAiAccNOPPSPNADAvl_e::DA_ENGAGED;
  } else if (DaNadSts_e::DaActvLongLat == m_danadsts) {
    da_pilot_avl = DAPilotAvl_e::DA_PILOT_ENGAGED_LONGLAT;
  } else if (DaNadSts_e::DaActvLong == m_danadsts) {
    da_pilot_avl = DAPilotAvl_e::DA_PILOT_ENGAGED_LONGONLY;
  } else if (DaNadSts_e::DaNOPActv == m_danadsts) {
    da_nop_avl = DAiAccNOPPSPNADAvl_e::DA_ENGAGED;
  } else if (DaNadSts_e::DaNADEngaged == m_danadsts) {
    da_psp_avl = DAiAccNOPPSPNADAvl_e::DA_ENGAGED;
  } else if (DaNadSts_e::DaNADTrsnDmd == m_danadsts) {
    da_nad_avl = DAiAccNOPPSPNADAvl_e::DA_ENGAGED;
  }

  INFO_LOG << "DA iAcc Avl: " << static_cast<int>(da_iacc_avl);
  INFO_LOG << "DA Pilot Avl: " << static_cast<int>(da_pilot_avl);
  INFO_LOG << "DA NOP Avl: " << static_cast<int>(da_nop_avl);
  INFO_LOG << "DA PSP Avl: " << static_cast<int>(da_psp_avl);
  INFO_LOG << "DA NAD Avl: " << static_cast<int>(da_nad_avl);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
