#include "fct_in_proc.h"
#include "common/perception/vision_feature_flag.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "fct_input_adapter.h"
#include "io_manager/io_adapter.h"
#include "niodds/application/application.h"
#include "parameters_configurator.h"

using nio::ad::messages::Features;
using nio::ad::messages::VEH10ms;
using nio::ad::messages::VEH50ms;

namespace nio {
namespace ad {
namespace fctapp {
nio::planner::SpeedControllerInput speed_controller_input;
nio::planner::TauGapProcessInput   tau_gap_process_input;
nio::planner::AdasMapTrafficSign   adasmap_traffic_sign;
nio::planner::DAMainState          damain_state;
vision_flg_s                       VISION_FLG;
uint32_t ldw_sensitivity_cnt = 150;
uint32_t ldw_sensitivity_input = 0;
uint32_t ldw_sensitivity_input_lf = 0;
LnAssistSnvty_e ldw_sensitivity_output = LnAssistSnvty_e::Normal;
bool driver_no_dms_warn = 0;
bool driver_change_set = 0;

void vision_flag_proc(const Features& visionflg) {
  VISION_FLG.HLB_decision = visionflg.ahc().hlb_decision();
}

bool update_elk_shadow(VEHPARAM* veh_param) {
  bool ret = 0;
  // if (veh_param->VarCodeInfo.vehicle_type == FCTVehProjectTyp_e::PEGASUS) {
  //   ret = true;
  // }
  // else {
  //   ret = false;
  // }
  return ret;
}

bool update_elk_solidline_enable(VEHPARAM* veh_param) {
  bool ret = 0;
  if (veh_param->VarCodeInfo.sales_region == SalesRegionTyp_e::EU) {
    ret = true;
  } else {
    ret = false;
  }
  return ret;
}

void update_lka_sensitivity(VEHDRVR* veh_drvr_ptr) {
  if (veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty == LnAssistSnvty_e::High) {
    veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty = LnAssistSnvty_e::Normal;
  } else if (veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty == LnAssistSnvty_e::Normal
             || veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty == LnAssistSnvty_e::Low) {
    veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty = LnAssistSnvty_e::Low;
  }
}

void dms_process_ldw(VEHDRVR* veh_drvr_ptr, DMS* dms_ptr) {
  ldw_sensitivity_input = configure_received_;

  if ((dms_ptr->dms_drws_lvl_da == 0 || dms_ptr->dms_drws_sts == 1) && (dms_ptr->dms_dstr_lvl_da == 0 || dms_ptr->dms_dstr_sts == 1)) {
    ldw_sensitivity_cnt ++;
    ldw_sensitivity_cnt = MIN(ldw_sensitivity_cnt, 300);
  }

  driver_no_dms_warn = (ldw_sensitivity_cnt >= 100) ?1:0;

  driver_change_set = (ldw_sensitivity_input_lf != ldw_sensitivity_input) ?1:0;

  if ((dms_ptr->dms_drws_sts == 0 && (dms_ptr->dms_drws_lvl_da == 1 ||  dms_ptr->dms_drws_lvl_da == 2 || dms_ptr->dms_drws_lvl_da == 3 ||dms_ptr->dms_drws_lvl_da == 4)) || (dms_ptr->dms_dstr_sts == 0 && (dms_ptr->dms_dstr_lvl_da == 1 ||  dms_ptr->dms_dstr_lvl_da == 2 || dms_ptr->dms_dstr_lvl_da == 3 ||dms_ptr->dms_dstr_lvl_da == 4))) {
    ldw_sensitivity_output = LnAssistSnvty_e::High;
    ldw_sensitivity_cnt = 0;
  }
  else if (driver_no_dms_warn == 1 || driver_change_set == 1) {
    //ldw_sensitivity_output = veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty;
    if (configure_received_ == 2 || configure_received_ == 1) {
      ldw_sensitivity_output = LnAssistSnvty_e::Normal;
    }
    else if (configure_received_ == 0) {
      ldw_sensitivity_output = LnAssistSnvty_e::Low;
    }
    else {
      ldw_sensitivity_output = LnAssistSnvty_e::Low;
    }
  }
  ldw_sensitivity_input_lf = configure_received_;


  veh_drvr_ptr->AdFunCfg.SetLaneAssiSnvty = ldw_sensitivity_output;
}

void update_oncoming_validity (EHYVisionRoad* vision_road_ptr, EHYTSI* ehy_tsi_ptr, VEHDYN* veh_dyn_ptr) {
  float left_line_c2 = 0;
  float right_line_c2 = 0;
  float roadedge_c0 = 100;
  float egospd = veh_dyn_ptr->VehSpd.VehSpdmps;

  for (size_t line_i = 0; line_i < 8; line_i++) {
    if (vision_road_ptr->lane.lines[line_i].role == LDRole_e::LDRole_Host_Left) {
      left_line_c2 = vision_road_ptr->lane.lines[line_i].first_line.line.c2;
    }
    else if (vision_road_ptr->lane.lines[line_i].role == LDRole_e::LDRole_Host_Right) {
      right_line_c2 = vision_road_ptr->lane.lines[line_i].first_line.line.c2;
    }
  }

  for (size_t re_i = 0; re_i < 4; re_i ++) {
    if (vision_road_ptr->road_edge[re_i].side == LDRESide_e::LDRESide_Left) {
      roadedge_c0 = vision_road_ptr->road_edge[re_i].line.c0;
    }
  }

  if (ehy_tsi_ptr->rm_tsi_out[18].valid != 0){
    float rangerate = egospd - ehy_tsi_ptr->rm_tsi_out[18].lon_vel;
    float ttc = 25.5;
    if (rangerate != 0) {
      ttc = ehy_tsi_ptr->rm_tsi_out[18].lon_pos_vcs/rangerate;
    }
    if ((ttc > 0.7 && (fabsf(left_line_c2) > 0.0005 || fabs(right_line_c2) > 0.0005)) || ehy_tsi_ptr->rm_tsi_out[18].fusion_source == 1 || (roadedge_c0 < 1.5 && roadedge_c0 > 0.8)){
      ehy_tsi_ptr->rm_tsi_out[18].valid = 0;
    }
  }
}


void fct_input_processing(FCTInputAdapter* fctinput, std::shared_ptr<planner::IOAdapter>& ioadapter) {

  fctinput->MainFcn(&vision_road, &veh_dyn, &veh_drvr, &veh_whl, &veh_pt, &veh_ctrl, &veh_body, &str_sys, &brk_sys,
                    &ehy_evd, &ehy_ha, &ehy_rme, &ehy_tpp, &ehy_lpp, &ehy_tsi, &ehy_tse, &me_vision_road, &dms_sys,
                    &vision_failsafe, &func_arb, &cam_fim, &veh_upa, &veh_param, &bsd_sts, &sdmap_info, &nop_vehicleout,
                    &nop_functionstatus, &nop_chassisctrl, &nop_speed, &nop_speedlimitvalue, &fused_obj, &ehy_obf,
                    &lidar_internalfault, &aebout_info, &cfgtaskmgr_info, &nop_powerpilotstate, &global_locali_info,
                    &glb_loc_mil_info, &hd_link_info, &esd_np_feature_info, ioadapter, &ads_out_info, &perception_fim,
                    &lidar_fim, &danop_sm, &vision_road_sign);

  LatCtrl_flgElkShadowMode_C          = update_elk_shadow(&veh_param);
  LatCtrl_Elk_bfSldLineIntvZnSrcMsk_C = update_elk_solidline_enable(&veh_param);
  // update_lka_sensitivity(&veh_drvr);
  dms_process_ldw(&veh_drvr, &dms_sys);
  update_oncoming_validity(&vision_road, &ehy_tsi, &veh_dyn);

  // INFO_LOG<< "====== AHC IN Start ====== ";
  // INFO_LOG<< "stMainLghtSet: "<< (int)stMainLghtSet << std::endl;
  // INFO_LOG<< "stSetHMA: "<< (int)stSetHMA << std::endl;
  // INFO_LOG<< "====== AHC IN END ====== ";
}
void fct_input_nop_trigger(FCTInputAdapter* fctinput, const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  fctinput->fill_npnopsm_input(&danop_sm, &da_statemachine_adapter, &veh_drvr, ioadapter);
}
void fct_nop_trigger_processing(DAStateMachineAdapter*                     dastatemachine_adapter,
                                const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  dastatemachine_adapter->fct_procNopTrigger(MainState_info,da_sm_info, veh_drvr, ioadapter, global_locali_info,
                                             nop_powerpilotstate);
  dastatemachine_adapter->setPSPStatus(hd_link_info, global_locali_info, nop_powerpilotstate, ioadapter);
  dastatemachine_adapter->fct_procUrbanStatus(MainState_info, da_sm_info,veh_drvr, ioadapter, global_locali_info,
                                              nop_powerpilotstate);
}

void fill_info_to_comm_proc(std::shared_ptr<planner::IOAdapter>& ioadapter, const bool& is_vehconf_uploaded) {
  static bool load_comm_conf_data = false;
  if (is_vehconf_uploaded && !load_comm_conf_data) {
    if (fct_conf_data.get_feature_conf().has_sas_rfwf_trigger_speed_time()) {
      speed_controller_input.sas_rfwf_trigger_speed_time =
        fct_conf_data.get_feature_conf().sas_rfwf_trigger_speed_time();
      WARN_LOG_FIRST_N(2) << "load sas_rfwf_tri_speed_time "
                          << speed_controller_input.sas_rfwf_trigger_speed_time;
    };
    if (fct_conf_data.get_feature_conf().has_sas_rfwf_trigger_min_distance()) {
      speed_controller_input.sas_rfwf_trigger_min_distance =
        fct_conf_data.get_feature_conf().sas_rfwf_trigger_min_distance();
      WARN_LOG_FIRST_N(2) << "load has_sas_rfwf_trigger_min_distance "
                          << speed_controller_input.sas_rfwf_trigger_min_distance;
    }
    load_comm_conf_data = true;
  };
  speed_controller_input.veh_disp_spd       = veh_dyn.VehSpd.VehDispSpd;
  speed_controller_input.swc_adj_mod_req    = static_cast<uint8_t>(veh_body.SWCAdjModReq);
  speed_controller_input.up_button          = static_cast<uint>(veh_drvr.StrWhlSwtch.AdUpSwtSts[0]);
  speed_controller_input.down_button        = static_cast<uint>(veh_drvr.StrWhlSwtch.AdUpSwtSts[1]);
  speed_controller_input.set_spd_offs       = static_cast<uint>(veh_drvr.SetDA_SetSpdOffs);
  speed_controller_input.set_spd_offs_value = static_cast<int>(veh_drvr.SetDA_SetSpdOffsValue);
  speed_controller_input.acc_pred_over_ride = static_cast<bool>(veh_pt.AccrPedal.PedlOvrd);
  for (uint i = 0u; i < 2; i++) {
    speed_controller_input.np_speed.unified_speed[i].legal_limit = ehy_rme.hdmap_info.ngp_list[i].recom_speed;
    speed_controller_input.np_speed.unified_speed[i].id          = ehy_rme.hdmap_info.ngp_list[i].recom_speed_id;
    speed_controller_input.np_speed.unified_speed[i].road_type   = ehy_rme.hdmap_info.ngp_list[i].gp_type;
    speed_controller_input.np_speed.unified_speed[i].source =
      (ehy_rme.hdmap_info.ngp_list[i].recom_speed_src & 0x000000FF);
    if (speed_controller_input.np_speed.unified_speed[i].legal_limit < 5.0f) {
      speed_controller_input.np_speed.unified_speed[i].distance = 10000.0f;
    } else {
      if (4 != speed_controller_input.np_speed.unified_speed[i].source) {
        speed_controller_input.np_speed.unified_speed[i].distance = ehy_rme.hdmap_info.ngp_list[i].gp_distance;
      } else {
        speed_controller_input.np_speed.unified_speed[i].distance = MAX(0, ehy_rme.hdmap_info.ngp_list[i].gp_distance);
      }
    }
    speed_controller_input.np_speed.unified_speed[i].sldf_state = (ehy_rme.hdmap_info.ngp_list[i].recom_speed_src >> 8);
    speed_controller_input.np_speed.unified_speed[i].confidence = ehy_rme.hdmap_info.ngp_list[i].recom_speed_conf;
    speed_controller_input.np_speed.unified_speed[i].unit =
      static_cast<nio::planner::SpdUnit>(sdmap_info.SdMapInfo.speed_unit);
    if (speed_controller_input.np_speed.unified_speed[i].unit == nio::planner::SpdUnit::SPEED_UNIT_MPH
        && speed_controller_input.np_speed.unified_speed[i].legal_limit != 255) {
      speed_controller_input.np_speed.unified_speed[i].legal_limit =
        speed_controller_input.np_speed.unified_speed[i].legal_limit / 0.6214 + 1;
    }
    speed_controller_input.np_speed.unified_speed[i].sup_sign_typ  = ehy_rme.hdmap_info.ngp_list[i].sup_sign_typ;
    speed_controller_input.np_speed.unified_speed[i].sup_sign_attr = ehy_rme.hdmap_info.ngp_list[i].sup_sign_attr;
    speed_controller_input.setda_speedassist     = static_cast<uint>(veh_drvr.AdFunCfg.SetDA_SpeedAssist);
    speed_controller_input.fw_fs_rain            = 0;
    speed_controller_input.iacc_topic_falut      = fct_diag_interface.is_iACC_TopicFault;
    speed_controller_input.sales_region          = static_cast<uint>(veh_param.VarCodeInfo.sales_region);
    speed_controller_input.is_highway            = static_cast<uint>(sdmap_info.SdMapInfo.m_adasmap_is_highway);
    speed_controller_input.nop_speed_limit_value = static_cast<uint>(nop_speedlimitvalue.nop_speed_limit_value);
    speed_controller_input.set_speed_ctrl_sts    = static_cast<uint>(veh_drvr.AdFunCfg.SetSpeedCtrlSts);
    speed_controller_input.ic_sts                = veh_body.CDCEqpmtSts.ICsts;
    speed_controller_input.set_swf               = static_cast<uint8_t>(veh_drvr.AdFunCfg.SetSWF);
    if (201 == func_arb.FunctionReq[0].FunctionID && FunctionRequest_e::ReqSandby == func_arb.FunctionReq[0].FuncReq) {
      speed_controller_input.arb_req_da_standby = true;
    } else {
      speed_controller_input.arb_req_da_standby = false;
    };
    speed_controller_input.acc_ped_efc_posn =
      QfZeroVld_e::QfVld == veh_pt.AccrPedal.EfcPosnVld ? veh_pt.AccrPedal.EfcPosn : 0.0f;
    speed_controller_input.brk_ped_pressed = BrkPdlSts_e::Prssd == brk_sys.BrkPdl.BrkPedlSts;
    speed_controller_input.lgt_a_mpss      = veh_dyn.LgtAg * 9.81f;
    speed_controller_input.veh_spd_mps     = veh_dyn.VehSpd.VehSpdmps;
    speed_controller_input.spd_unit        = 0;
    if (speed_controller_input.sales_region == 2) {
      speed_controller_input.spd_unit = veh_dyn.VehSpd.VehDispdSpdUnit;
    }
    if (AdasMap_info.size() > 0 && AdasMap_info.back()->adas_info().traffic_sign().size() > 0) {
      speed_controller_input.traffic_sign.clear();
      for (const auto traffic_sign : AdasMap_info.back()->adas_info().traffic_sign()) {
        adasmap_traffic_sign.index     = traffic_sign.index();
        adasmap_traffic_sign.offset    = traffic_sign.offset();
        adasmap_traffic_sign.sign_type = traffic_sign.sign_type();
        adasmap_traffic_sign.value     = traffic_sign.value();
        speed_controller_input.traffic_sign.push_back(adasmap_traffic_sign);
      }
    } else {
      speed_controller_input.traffic_sign.clear();
    }
    speed_controller_input.veh_spd_max_lmt_on_off = veh_body.VehSpdMaxLimOnOff;
    speed_controller_input.veh_spd_lmt_sts        = veh_drvr.VehSpdLimSts;
    speed_controller_input.trailer_mode_req       = static_cast<uint8_t>(veh_body.TrailerModReq);
    ioadapter->getMidOutputManager().setSpeedControllerInput(speed_controller_input);
    // DAMainState da_main_state_update       = ioadapter->getMidOutputManager().getDAMainState();
    damain_state.nadsts            = static_cast<int>(da_sm_info.hwa_sm_op.NadSts);
    damain_state.acc_sys_sts       = static_cast<int>(MainState_info.AccSysSt);
    damain_state.acc_stauts        = static_cast<int>(MainState_info.AccStatus);
    damain_state.acc_activated     = static_cast<bool>(MainState_info.AccActivated);
    damain_state.eda_sts           = static_cast<int>(MainState_info.EDAInfo.EDASts);
    damain_state.sw_acc_setspeed   = static_cast<uint8_t>(da_sm_info.hwa_sm_op.Ev_SwCruise_SetSpd);
    damain_state.sw_pilot_setspeed = static_cast<uint8_t>(da_sm_info.hwa_sm_op.Ev_SwPilot_SetSpd);
    ioadapter->getMidOutputManager().setDAMainState(damain_state);
    tau_gap_process_input.left_button       = static_cast<bool>(veh_drvr.StrWhlSwtch.AdUpSwtSts[2]);
    tau_gap_process_input.right_button      = static_cast<bool>(veh_drvr.StrWhlSwtch.AdUpSwtSts[3]);
    tau_gap_process_input.stored_tau_gap    = static_cast<uint8_t>(veh_drvr.AdFunCfg.ACCTauGapStored);
    tau_gap_process_input.cfgTaskMgr_status = static_cast<uint8_t>(cfgtaskmgr_info.CfgTaskSwitchInfo.cfg_status);
    tau_gap_process_input.swc_adj_mod_req   = static_cast<uint8_t>(veh_body.SWCAdjModReq);
    tau_gap_process_input.dms_drws_lvl      = static_cast<uint8_t>(dms_sys.dms_drws_lvl_da);
    tau_gap_process_input.sales_region      = static_cast<uint>(veh_param.VarCodeInfo.sales_region);
    ioadapter->getMidOutputManager().setTauGapProcessInput(tau_gap_process_input);
  }
}
void fill_comm_proc_info(CommonProc_Info* common_proc_ptr, const std::shared_ptr<planner::IOAdapter>& ioadapter) {
  auto speed_controller_out                   = ioadapter->getMidOutputManager().getSpeedControllerOut();
  auto tau_gap_proc_out                       = ioadapter->getMidOutputManager().getTauGapProcessOut();
  common_proc_ptr->sas_speed_limit_out_value  = static_cast<uint32_t>(speed_controller_out.sas_speed_limit_out_value);
  common_proc_ptr->sas_speed_limit_out_valid  = static_cast<bool>(speed_controller_out.sas_speed_limit_out_valid);
  common_proc_ptr->sas_speed_limit_out_id     = static_cast<uint32_t>(speed_controller_out.sas_speed_limit_out_id);
  common_proc_ptr->sas_speed_limit_c_id       = static_cast<uint32_t>(speed_controller_out.sas_speed_limit_c_id);
  common_proc_ptr->sas_speed_limit_c_value    = static_cast<uint32_t>(speed_controller_out.sas_speed_limit_c_value);
  common_proc_ptr->sas_sldf_state             = static_cast<uint32_t>(speed_controller_out.sas_sldf_state);
  common_proc_ptr->sas_sup_sign_type          = static_cast<uint32_t>(speed_controller_out.sas_sup_sign_type);
  common_proc_ptr->disp_set_speed_enable      = static_cast<bool>(speed_controller_out.disp_set_speed_enable);
  common_proc_ptr->iacc_speed_limit_out_valid = static_cast<bool>(speed_controller_out.iacc_speed_limit_out_valid);
  common_proc_ptr->iacc_speed_limit_out_value = static_cast<uint32_t>(speed_controller_out.iacc_speed_limit_out_value);
  common_proc_ptr->iacc_take_over_pop         = static_cast<uint32_t>(speed_controller_out.iacc_take_over_pop);
  common_proc_ptr->user_set_speed             = static_cast<uint32_t>(speed_controller_out.user_set_speed);
  common_proc_ptr->rain_mode                  = static_cast<bool>(speed_controller_out.rain_mode);
  common_proc_ptr->user_set_speed_out         = speed_controller_out.user_set_speed_out;
  common_proc_ptr->speed_unit                 = speed_controller_out.speed_unit;
  common_proc_ptr->setspeed_decel_mode        = speed_controller_out.setspeed_decel_mode;
  common_proc_ptr->set_spd_animation          = static_cast<uint32_t>(speed_controller_out.set_spd_animation);
  common_proc_ptr->tau_gap_setting            = tau_gap_proc_out.tau_gap_setting;
  common_proc_ptr->tau_gap_change_disp        = tau_gap_proc_out.tau_gap_display;
  sas_func_out                                = ioadapter->getMidOutputManager().getSasFunctionOut();
  common_proc_ptr->max_set_speed              = speed_controller_out.max_set_speed;
  common_proc_ptr->sas_speed_limit_out_value_trans =
    ioadapter->getMidOutputManager().getSpeedControllerOut().sas_speed_limit_out_value_trans;
}
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
