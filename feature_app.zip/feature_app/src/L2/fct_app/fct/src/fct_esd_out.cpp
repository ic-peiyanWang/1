#include <iostream>

#include "fct_esd_out.h"
#include "fct_input_adapter.h"
#include "fct_loc_cfg.h"
#include "fct_out_proc.h"
#include "fct_timestamps_param.h"
#include "func_arb_type.h"
#include "ids_mil.h"
#include "niodds/application/application.h"
#include "go_notifier.h"

namespace nio {
namespace ad {
namespace fctapp {
BSD_LCA_Obj bsd_obj[ObjSize];
BSD_LCA_Obj lca_obj[ObjSize];
uint32_t    TarIndex[TarSize];
uint8_t     TarLevel[TarSize];

void fct_esd_output_default(FctOut& fct_out) {

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Clear();

  auto esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_elk_fct(0);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_elk_fct(0);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_elk_fct(0);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_elk_fct(0);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_elk_fct(0);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(0);
  esd_info->set_esd_np_obj_level_fct(0);
  esd_info->set_esd_np_obj_da_fct(0);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_crossed_left_lane_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_crossed_right_lane_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_lanechngintent_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_np_alc_crossing_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_np_alc_sts_fct(0);

  // fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Clear();
  // auto esd_line = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Add();
  // esd_line->set_esd_np_line_ld_level_fct(0);
  // esd_line->set_esd_np_line_ldw_level_fct(0);
  // esd_line->set_esd_np_line_role_fct(0);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_enable_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c0_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c1_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c2_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c3_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c4_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c5_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_end_fct(0);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_valid(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_type(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_color(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_status(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_timer(0);
}

void fct_esd_output_processing(FctOut& fct_out) {
  fct_esd_match();
  fct_esd_arb();

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Clear();

  auto esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
#ifdef ENABLE_BSD_LCA_ESD
  // NT2ADD-9194 ESD: Turn off BSD/LCA ESD objects highlight on BL110
  esd_info->set_esd_np_obj_id_fct(bsd_obj[0].obj_id);
  esd_info->set_esd_np_obj_elk_fct(bsd_obj[0].obj_type);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(bsd_obj[1].obj_id);
  esd_info->set_esd_np_obj_elk_fct(bsd_obj[1].obj_type);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(lca_obj[0].obj_id);
  esd_info->set_esd_np_obj_elk_fct(lca_obj[0].obj_type);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(lca_obj[1].obj_id);
  esd_info->set_esd_np_obj_elk_fct(lca_obj[1].obj_type);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
#endif
  esd_info->set_esd_np_obj_id_fct(TarIndex[0]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[0]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[1]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[1]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[2]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[2]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[3]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[3]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[4]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[4]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[5]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[5]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[6]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[6]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[7]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[7]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[8]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[8]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[9]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[9]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[10]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[10]);
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  esd_info->set_esd_np_obj_id_fct(TarIndex[11]);
  esd_info->set_esd_np_obj_da_fct(TarLevel[11]);

  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  if (Fcts_ESFWarnSts::ESFOncomingLeftWarn == aebout_info.FctsElkLkaOut.ESFWarnSts || Fcts_ESFWarnSts::ESFOncomingRightWarn == aebout_info.FctsElkLkaOut.ESFWarnSts) {
    esd_info->set_esd_np_obj_id_fct(aebout_info.FctsElkLkaOut.esf_id);
    esd_info->set_esd_np_obj_elk_fct(1);
  } else if (Fcts_ESFWarnSts::ESFOvertakingLeftWarn == aebout_info.FctsElkLkaOut.ESFWarnSts || Fcts_ESFWarnSts::ESFOvertakingRightWarn == aebout_info.FctsElkLkaOut.ESFWarnSts) {
    esd_info->set_esd_np_obj_id_fct(aebout_info.FctsElkLkaOut.esf_id);
    esd_info->set_esd_np_obj_elk_fct(2);
  } else {
    esd_info->set_esd_np_obj_id_fct(0);
    esd_info->set_esd_np_obj_elk_fct(0);
  }

#ifdef ENABLE_ACTSHIFT_ESD
  esd_info = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_object_fct()->Add();
  if (1 == ehy_tpp.act_shift_status
      && (0 == LKS_LCA_out.ALCSStatus || 1 == LKS_LCA_out.ALCSStatus || 2 == LKS_LCA_out.ALCSStatus
          || 3 == LKS_LCA_out.ALCSStatus)) {
    esd_info->set_esd_np_obj_id_fct(ehy_tpp.shift_object_id);
    esd_info->set_esd_np_obj_level_fct(2);
    esd_info->set_esd_np_obj_da_fct(2);
  } else {
    esd_info->set_esd_np_obj_id_fct(0);
    esd_info->set_esd_np_obj_level_fct(0);
    esd_info->set_esd_np_obj_da_fct(0);
  }
#endif

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_crossed_left_lane_fct(LKS_LCA_out.LeLaneCrsg);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_crossed_right_lane_fct(
    LKS_LCA_out.RiLaneCrsg);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_lanechngintent_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_np_alc_crossing_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_alc_fct()->set_esd_np_alc_sts_fct(LKS_LCA_out.ALCSStatus);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Clear();
  if (LKS_LCA_out.ALCSLaneEsd.LeLaneInfo.LaneIndex) {
    auto esd_line = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Add();

    esd_line->set_esd_np_line_ld_level_fct(LKS_LCA_out.ALCSLaneEsd.LeLaneInfo.LaneLevel);
    esd_line->set_esd_np_line_ldw_level_fct(0);
    esd_line->set_esd_np_line_role_fct(LKS_LCA_out.ALCSLaneEsd.LeLaneInfo.LaneIndex);
  }
  if (LKS_LCA_out.ALCSLaneEsd.RiLaneInfo.LaneIndex) {
    auto esd_line = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Add();

    esd_line->set_esd_np_line_ld_level_fct(LKS_LCA_out.ALCSLaneEsd.RiLaneInfo.LaneLevel);
    esd_line->set_esd_np_line_ldw_level_fct(0);
    esd_line->set_esd_np_line_role_fct(LKS_LCA_out.ALCSLaneEsd.RiLaneInfo.LaneIndex);
  }

  // esd_line = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Add();
  // esd_line->set_esd_np_line_ld_level_fct(LKS_LCA_out.ALCSLaneEsd.NxLeLaneInfo.LaneLevel);
  // esd_line->set_esd_np_line_ldw_level_fct(0);
  // esd_line->set_esd_np_line_role_fct(LKS_LCA_out.ALCSLaneEsd.NxLeLaneInfo.LaneIndex);
  // esd_line = fct_out.mutable_esd_np_feature_out()->mutable_esd_np_line_fct()->Add();
  // esd_line->set_esd_np_line_ld_level_fct(LKS_LCA_out.ALCSLaneEsd.NxRiLaneInfo.LaneLevel);
  // esd_line->set_esd_np_line_ldw_level_fct(0);
  // esd_line->set_esd_np_line_role_fct(LKS_LCA_out.ALCSLaneEsd.NxRiLaneInfo.LaneIndex);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_enable_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c0_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c1_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c2_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c3_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c4_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_c5_fct(0);
  fct_out.mutable_esd_np_feature_out()->mutable_esd_np_path_fct()->set_esd_np_path_end_fct(0);

  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_valid(static_cast<uint32_t>(tl_gonotifier.EsdTrafficLight().tld_valid));
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_type(static_cast<uint32_t>(tl_gonotifier.EsdTrafficLight().tld_type));
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_color(static_cast<uint32_t>(tl_gonotifier.EsdTrafficLight().tld_color));
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_status(static_cast<uint32_t>(tl_gonotifier.EsdTrafficLight().tld_status));
  fct_out.mutable_esd_np_feature_out()->mutable_esd_tld_fct()->set_tld_timer(tl_gonotifier.EsdTrafficLight().tld_timer);
}

void fct_esd_arb() {
  for (int i = 0; i < TarSize - 1; i++) {
    for (int j = i + 1; j <= TarSize - 1; j++) {
      if (TarIndex[i] == TarIndex[j]) {
        TarLevel[i] = (TarLevel[i] >= TarLevel[j] ? TarLevel[i] : TarLevel[j]);
        TarIndex[j] = 0;
        TarLevel[j] = 0;
      }
    }
  }
}

void fct_esd_match() {
#ifdef ENABLE_BSD_LCA_ESD
  // NT2ADD-9194 ESD: Turn off BSD/LCA ESD objects highlight on BL110

  static bool           bsd_hilight_enable_left  = false;
  static bool           bsd_hilight_enable_right = false;
  static TrnIndcrSwSt_e last_turnlight_swsts     = TrnIndcrSwSt_e::Default;

  if (TrnIndcrSwSt_e::Left != last_turnlight_swsts && TrnIndcrSwSt_e::Left == veh_drvr.TurnIndcrSwtSts) {
    bsd_hilight_enable_left = true;
  }

  if (TrnIndcrSwSt_e::Right != last_turnlight_swsts && TrnIndcrSwSt_e::Right == veh_drvr.TurnIndcrSwtSts) {
    bsd_hilight_enable_right = true;
  }

  if (TrnIndcrSwSt_e::Left == last_turnlight_swsts && TrnIndcrSwSt_e::Left != veh_drvr.TurnIndcrSwtSts) {
    bsd_hilight_enable_left = false;
  }

  if (TrnIndcrSwSt_e::Right == last_turnlight_swsts && TrnIndcrSwSt_e::Right != veh_drvr.TurnIndcrSwtSts) {
    bsd_hilight_enable_right = false;
  }

  last_turnlight_swsts = veh_drvr.TurnIndcrSwtSts;

  if (0 != ehy_tsi.bsd_hmi_id[0]
      && (HWA_out.HWASM.NadSts != 7 && HWA_out.HWASM.NadSts != 8 && HWA_out.HWASM.NadSts != 9)
      && bsd_hilight_enable_left) {
    bsd_obj[0].obj_id   = static_cast<uint32_t>(ehy_tsi.bsd_hmi_id[0]);
    bsd_obj[0].obj_type = 4;  // 4: BSD Target
  } else {
    bsd_obj[0].obj_id   = 0;
    bsd_obj[0].obj_type = 0;
  }

  if (0 != ehy_tsi.bsd_hmi_id[1]
      && (HWA_out.HWASM.NadSts != 7 && HWA_out.HWASM.NadSts != 8 && HWA_out.HWASM.NadSts != 9)
      && bsd_hilight_enable_right) {
    bsd_obj[1].obj_id   = static_cast<uint32_t>(ehy_tsi.bsd_hmi_id[1]);
    bsd_obj[1].obj_type = 4;  // 4: BSD Target
  } else {
    bsd_obj[1].obj_id   = 0;
    bsd_obj[1].obj_type = 0;
  }

  if (0 != ehy_tsi.lca_hmi_id[0]
      && (HWA_out.HWASM.NadSts != 7 && HWA_out.HWASM.NadSts != 8 && HWA_out.HWASM.NadSts != 9)
      && bsd_hilight_enable_left) {
    lca_obj[0].obj_id   = static_cast<uint32_t>(ehy_tsi.lca_hmi_id[0]);
    lca_obj[0].obj_type = 5;  // 5: LCA Target
  } else {
    lca_obj[0].obj_id   = 0;
    lca_obj[0].obj_type = 0;
  }

  if (0 != ehy_tsi.lca_hmi_id[1]
      && (HWA_out.HWASM.NadSts != 7 && HWA_out.HWASM.NadSts != 8 && HWA_out.HWASM.NadSts != 9)
      && bsd_hilight_enable_right) {
    lca_obj[1].obj_id   = static_cast<uint32_t>(ehy_tsi.lca_hmi_id[1]);
    lca_obj[1].obj_type = 5;  // 5: LCA Target
  } else {
    lca_obj[1].obj_id   = 0;
    lca_obj[1].obj_type = 0;
  }

#endif

  // obf_info->obf_objects(obf_i).fuseobj().vision_match_cnt();
  TarIndex[0]  = HWA_out.LNGCTRL.EsdTarInfo.Tar0.TarIndex;
  TarLevel[0]  = HWA_out.LNGCTRL.EsdTarInfo.Tar0.TarLevel;
  TarIndex[1]  = HWA_out.LNGCTRL.EsdTarInfo.Tar1.TarIndex;
  TarLevel[1]  = HWA_out.LNGCTRL.EsdTarInfo.Tar1.TarLevel;
  TarIndex[2]  = HWA_out.LNGCTRL.EsdTarInfo.Tar2.TarIndex;
  TarLevel[2]  = HWA_out.LNGCTRL.EsdTarInfo.Tar2.TarLevel;
  TarIndex[3]  = HWA_out.LNGCTRL.EsdTarInfo.Tar3.TarIndex;
  TarLevel[3]  = HWA_out.LNGCTRL.EsdTarInfo.Tar3.TarLevel;
  TarIndex[4]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar0.TarIndex;
  TarLevel[4]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar0.TarLevel;
  TarIndex[5]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar1.TarIndex;
  TarLevel[5]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar1.TarLevel;
  TarIndex[6]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar2.TarIndex;
  TarLevel[6]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar2.TarLevel;
  TarIndex[7]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar3.TarIndex;
  TarLevel[7]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar3.TarLevel;
  TarIndex[8]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar4.TarIndex;
  TarLevel[8]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar4.TarLevel;
  TarIndex[9]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar5.TarIndex;
  TarLevel[9]  = 0;  // LKS_LCA_out.ALCEsdInfo.Tar5.TarLevel;
  TarIndex[10] = LKS_LCA_out.ALCEsdInfo.Tar6.TarIndex;
  TarLevel[10] = LKS_LCA_out.ALCEsdInfo.Tar6.TarLevel;
  TarIndex[11] = LKS_LCA_out.ALCEsdInfo.Tar7.TarIndex;
  TarLevel[11] = LKS_LCA_out.ALCEsdInfo.Tar7.TarLevel;

  for (int m = 0; m < TarSize; m++) {
    if (int(fused_obj.size()) > 0 && TarIndex[m] > 0) {

      for (int n = 0; n < fused_obj.size(); n++) {
        if (fused_obj.at(n).GetID() == TarIndex[m])
          break;
      }

    } else {
      TarIndex[m] = 0;
    }
  }
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
