#include "planner/behavior_planner/decision/model_feature_name.h"
#include "fct_input_adapter.h"
#include "feature_app/src/L2/fct_app/fct/include/np_labelling_match.h"
#include <utility>

namespace nio {
namespace ad {
namespace fctapp {

using std::endl;

DEFINE_string(labelling_input_json_file, "./inputs/clip_meta.json",
              "input labelling json file");

using json = nlohmann::json;
LabellingMatch::LabellingMatch(const std::string& json_file){
    AINFO << "json file = " << json_file;
    loadLabellingJsonFile(json_file);
}

bool LabellingMatch::loadLabellingJsonFile(const std::string& json_filepath) {
  std::ifstream in(json_filepath);
  if (!in.is_open()) {
    AERROR << " Failed to open file " << json_filepath;
    return false;
  }

  nlohmann::json meta_json;
  in >> meta_json;
  if (meta_json.is_null()) {
    AERROR << " meta_json is null";
    return false;
  }
  AINFO << meta_json.dump(4);

  labelling_format_.clip_id = meta_json["clip_id"];
  labelling_format_.evaluation_id = meta_json["evaluation_id"];

  const std::string label_string = meta_json["object_decision_labels"];
  labelling_result_json_ = json::parse(label_string);
  for (json::iterator i = labelling_result_json_.begin(); i != labelling_result_json_.end(); ++i) {
    if (i.key() == "decision_labels") {
      for (auto label_iter = i->begin(); label_iter != i->end(); ++label_iter) {
        DecisionLabel decision_label;
        decision_label.obstacle_id = (*label_iter)["obstacle_id"];
        decision_label.mode = label_iter->count("mode") == 1 ? (*label_iter)["mode"] : "LaneKeep";
        decision_label.decision = (*label_iter)["decision"].get<std::vector<std::string>>();
        decision_label.duration_second =
            (*label_iter)["duration_second"].get<std::vector<double>>();
        if (decision_label.duration_second.empty() ||
            decision_label.duration_second.front() >= decision_label.duration_second.back()) {
          continue;
        }
        ADEBUG << "obs id = " << decision_label.obstacle_id
               << ", decision size = " << decision_label.decision.size()
               << ", duration size = " << decision_label.duration_second.size();
        labelling_format_.decision_labels.emplace_back(std::move(decision_label));
      }

    } else if (i.key() == "ego_trigger_change_labels") {
      for (auto label_iter = i->begin(); label_iter != i->end(); ++label_iter) {
        EgoTriggerLaneChangeLabel ego_trigger_lane_change_label;
        ego_trigger_lane_change_label.lane_change_type = (*label_iter)["change_type"];
        ego_trigger_lane_change_label.duration_second =
            (*label_iter)["duration_second"].get<std::vector<double>>();
        if (ego_trigger_lane_change_label.duration_second.empty() ||
            ego_trigger_lane_change_label.duration_second.front() >=
                ego_trigger_lane_change_label.duration_second.back()) {
          continue;
        }
        ADEBUG << "obs id = " << ego_trigger_lane_change_label.lane_change_type
               << ", duration size = " << ego_trigger_lane_change_label.duration_second.size();
        lane_change_safety_.emplace(
            toLabelLaneChangeType(ego_trigger_lane_change_label.lane_change_type),
            std::make_pair(ego_trigger_lane_change_label.duration_second.front(),
                           ego_trigger_lane_change_label.duration_second.back()));
        labelling_format_.ego_lane_change_labels.emplace_back(
            std::move(ego_trigger_lane_change_label));
      }
    }
  }

  for (const auto& decision_label : labelling_format_.decision_labels) {
    AINFO << "labelling decision obstacle id = " << decision_label.obstacle_id ;
    if (decision_label.decision.size() != 2) {
      continue;
    }

    const ModeType mode = convertModeTypeEnum(decision_label.mode);
    if (mode == ModeType::MAX_INDEX) {
      continue;
    }

    const std::string& decision = decision_label.decision[1];
    const DecisionType decision_type = convertDecisionTypeEnum(decision);
    if (decision_type == DecisionType::MAX_INDEX) {
      continue;
    }

    LabelDecisionObject obj;
    obj.obstacle_id = decision_label.obstacle_id;
    obj.mode = mode;
    obj.decision_type = decision_type;
    obj.start_time = decision_label.duration_second.front();
    obj.end_time = decision_label.duration_second.back();

    label_object_dict_.emplace(std::make_pair(obj.obstacle_id, obj));
  }

  AINFO << "labelling obj size = " << label_object_dict_.size();

  return true;
}

bool LabellingMatch::match(const apollo::cyber::Time forward_init_time,
    LabellingMatchResult* labelling_match_result) {
  if (labelling_match_result == nullptr) {
    AERROR << " labelling_match_result is nullptr !";
    return false;
  }

  relative_time_to_start_time_ = (forward_init_time - init_time_).ToSecond();

  WARN_LOG << "relative_time_to_start_time_:" <<relative_time_to_start_time_ << endl;

  for (const auto& pair : label_object_dict_) {
    const auto& label_obj = pair.second;

    WARN_LOG << "label_obj.start_time" << label_obj.start_time << endl;
    WARN_LOG << "label_obj.end_time" << label_obj.end_time << endl;

    if (relative_time_to_start_time_ < label_obj.start_time ||
        relative_time_to_start_time_ > label_obj.end_time) {
      continue;
    }

    const ModeType mode = label_obj.mode;
    WARN_LOG << "label_obj.mode:" << (int)label_obj.mode << endl;
    WARN_LOG << "label_obj.decision_type:" << (int)label_obj.decision_type << endl;

    if (ModeType::LANE_KEEP == mode) {
      labelling_match_result->keep_label_object_dict.emplace(pair);
      int cutin_decision_type=label_obj.decision_type==DecisionType::YIELD ? 1 : 0;
      labelling_match_result->single_lane_match_label.emplace(label_obj.obstacle_id,cutin_decision_type);
    }
  }

  return !labelling_match_result->single_lane_match_label.empty();
}

void LabellingMatch::CalculateCutinID (const int& cutin_index,
                                      std::unordered_map<int, DecisionType>* cutin_predict_decision_dict){
  int obf_index = 0;
  if (int(fused_obj.size()) > 0 && cutin_index > 0) {
    for (int n = 0; n < fused_obj.size(); n++) {
      if (fused_obj.at(n).GetIndex() == cutin_index - 1) {
        obf_index = fused_obj.at(n).GetID();
        cutin_predict_decision_dict->emplace(std::make_pair(obf_index,DecisionType::YIELD));
        break;
      } else {
          cutin_predict_decision_dict->emplace(std::make_pair(obf_index,DecisionType::NOT_YIELD));
      }
    }
  }
}

bool LabellingMatch::run(const apollo::cyber::Time forward_init_time,
                         std::unordered_map<int,DecisionType>& decision_strategy_output) {
  labelling_match_result_ = LabellingMatchResult();

  bool match_success = match(forward_init_time,
      &labelling_match_result_);
  if (!match_success) {
    AERROR << " label match failed, not find label object !!!";
    return false;
  }
  calculateBadcase(decision_strategy_output, &labelling_match_result_);
  return true;
}

void LabellingMatch::calculateBadcase(std::unordered_map<int,DecisionType>& cutin_output,
                                      LabellingMatchResult* labelling_match_result) {
  calculateKeepBadcase(labelling_match_result->single_lane_match_label,
                       cutin_output,
                       &(labelling_match_result->keep_obstacle_predict_label_dict));
}

const LabellingMatchResult& LabellingMatch::getLabellingMatchResult() const {
  return labelling_match_result_;
}

const std::unordered_multimap<int, LabelDecisionObject>& LabellingMatch::getLabelObjectDict() const {
  return label_object_dict_;
}

void LabellingMatch::calculateKeepBadcase(
  const std::unordered_map<int, int>& keep_label_decision_dict,
  std::unordered_map<int, DecisionType>& cutin_predict_decision_dict,
  std::unordered_map<int, std::pair<int, int>>* keep_obstacle_predict_label_dict) {

  for (const auto& [label_obs_id, decision_label] : keep_label_decision_dict) {
    if (0 == cutin_predict_decision_dict.count(label_obs_id)) {
      AERROR << " keep obstacle proposal error !"
             << " label_obs_id = " << label_obs_id;
      continue;
      }

    const int predict_decision =
      cutin_predict_decision_dict.at(label_obs_id) == DecisionType::YIELD ? 1 : 0;

    keep_obstacle_predict_label_dict->emplace(
        std::make_pair(label_obs_id, std::make_pair(predict_decision, decision_label)));
    }
}

void LabellingMatch::labelmatch (const int& cutin_result, const apollo::cyber::Time eval_time_in){

  const apollo::cyber::Time car_state_stamp = eval_time_in;
  static apollo::cyber::Time temp_inittime;

  static bool flag_init=false;
  if(!flag_init){
    temp_inittime=car_state_stamp;
    flag_init=true;
  }
  init_time_=temp_inittime;

  std::unordered_map<int, DecisionType> cutin_predict_decision_dict;
  CalculateCutinID(cutin_result,&cutin_predict_decision_dict);

  run(car_state_stamp,cutin_predict_decision_dict);

}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio