#include "fct_edr_proc.h"
#include "ELKCore.h"
#include "LKACore.h"
#include "LKSCore.h"
#include "fct_input_adapter.h"
#include "ids_mil.h"

namespace nio {
namespace ad {
namespace fctapp {

extern void fct_edr_processing(const VEHPARAM* veh_param_ptr, const NopVehicleOut* nop_vehicleout_ptr, FctOut& fct_out) {
  if ((veh_param_ptr != nullptr && veh_param_ptr->VarCodeInfo.sales_region == SalesRegionTyp_e::CN && HWA_out.HWASM.NadSts == 11)||
     (HWA_out.HWASM.NadSts == 7||HWA_out.HWASM.NadSts == 9||HWA_out.HWASM.NadSts == 10))
  {
    fct_out.mutable_acmedr()->set_acsf_b1_sts_edr(2);
  } else if (HWA_out.HWASM.NadSts == 8 || HWA_out.HWASM.NadSts == 5 || HWA_out.HWASM.NadSts == 3 ) {
    fct_out.mutable_acmedr()->set_acsf_b1_sts_edr(1);
  } else if (HWA_out.HWASM.NadSts == 2 && HWA_out.HWASM.DASysFailSym) {
    fct_out.mutable_acmedr()->set_acsf_b1_sts_edr(3);
  } else {
    fct_out.mutable_acmedr()->set_acsf_b1_sts_edr(0);
  }

  fct_out.mutable_acmedr()->set_acsf_b2_sts_edr(0);

  if ((HWA_out.HWASM.NadSts == 7 && LKS_LCA_out.ALCSStatus >= 4) ||
      (HWA_out.HWASM.NadSts == 9 && nop_vehicleout_ptr != nullptr &&
       (nop_vehicleout_ptr->nop_alc_sts == 2 ||
        nop_vehicleout_ptr->nop_alc_sts == 3 ||
        nop_vehicleout_ptr->nop_alc_sts == 4 ||
        nop_vehicleout_ptr->nop_alc_sts == 5))) {
    fct_out.mutable_acmedr()->set_acsf_c_sts_edr(2);
  } else if (HWA_out.HWASM.NadSts == 2 && HWA_out.HWASM.DASysFailSym) {
    fct_out.mutable_acmedr()->set_acsf_c_sts_edr(3);
  } else if ((HWA_out.HWASM.NadSts == 7 && (LKS_LCA_out.ALCSStatus == 2 || LKS_LCA_out.ALCSStatus == 3)) ||
             (HWA_out.HWASM.NadSts == 9 && nop_vehicleout_ptr != nullptr &&
              (nop_vehicleout_ptr->nop_alc_sts == 1 ||
               nop_vehicleout_ptr->nop_alc_sts == 6))) {
    fct_out.mutable_acmedr()->set_acsf_c_sts_edr(1);
  } else {
    fct_out.mutable_acmedr()->set_acsf_c_sts_edr(0);
  }

  fct_out.mutable_acmedr()->set_acsf_d_sts_edr(0);
  fct_out.mutable_acmedr()->set_acsf_e_sts_edr(0);
  fct_out.mutable_acmedr()->set_lane_assist_sts_edr(fct_out.mutable_latctrl()->lkalnasststs());
  fct_out.mutable_acmedr()->set_ldw_lka_lane_assi_typ_edr(fct_out.mutable_latctrl()->laneassityp());
  fct_out.mutable_acmedr()->set_adas_le_line_edr(fct_out.mutable_ldw()->adasleline());
  fct_out.mutable_acmedr()->set_adas_ri_line_edr(fct_out.mutable_ldw()->adasriline());
  fct_out.mutable_acmedr()->set_elk_sts_edr(fct_out.mutable_elk()->elksts());
  fct_out.mutable_acmedr()->set_esf_warning_sts_edr(fct_out.mutable_elk()->esfwarningsts());

  if (HWA_out.HWASM.NadSts == 6 || HWA_out.HWASM.NadSts == 7 || HWA_out.HWASM.NadSts == 8 || 
      HWA_out.HWASM.NadSts == 9 || HWA_out.HWASM.NadSts == 10 || HWA_out.HWASM.NadSts == 11) {
    fct_out.mutable_acmedr()->set_acc_sts_edr(1);
  } else if (HWA_out.HWASM.NadSts == 3 || HWA_out.HWASM.NadSts == 4 || HWA_out.HWASM.NadSts == 5) {
    fct_out.mutable_acmedr()->set_acc_sts_edr(0);
  } else if (HWA_out.HWASM.NadSts == 2 && HWA_out.HWASM.DASysFailSym) {
    fct_out.mutable_acmedr()->set_acc_sts_edr(3);
  } else {
    fct_out.mutable_acmedr()->set_acc_sts_edr(2);
  }
}
extern void fct_edr_default(FctOut& fct_out) {
  fct_out.mutable_acmedr()->set_acsf_b1_sts_edr(0u);
  fct_out.mutable_acmedr()->set_acsf_b2_sts_edr(0u);
  fct_out.mutable_acmedr()->set_acsf_c_sts_edr(0u);
  fct_out.mutable_acmedr()->set_acsf_d_sts_edr(0u);
  fct_out.mutable_acmedr()->set_acsf_e_sts_edr(0u);
  fct_out.mutable_acmedr()->set_lane_assist_sts_edr(0u);
  fct_out.mutable_acmedr()->set_ldw_lka_lane_assi_typ_edr(0u);
  fct_out.mutable_acmedr()->set_adas_le_line_edr(0u);
  fct_out.mutable_acmedr()->set_adas_ri_line_edr(0u);
  fct_out.mutable_acmedr()->set_elk_sts_edr(0u);
  fct_out.mutable_acmedr()->set_esf_warning_sts_edr(0u);
  fct_out.mutable_acmedr()->set_acc_sts_edr(2u);
}
}  // namespace fctapp
}  // namespace ad
}  // namespace nio