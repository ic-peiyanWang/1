#include "fct_evm_proc.h"

namespace nio {
namespace ad {
namespace fctapp {

void fct_evm_processing(const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                        FctOut&                                                      fct_out) {
  if (fim_can_fea_info != nullptr &&
      fim_can_fea_info->mutable_vcu_feature_fim_info()->fim_chs1_vcu_vcuvehdispspd_error()) {
    fct_out.mutable_hwa()->set_adc_vehdisp_warn(true);
  } else {
    fct_out.mutable_hwa()->set_adc_vehdisp_warn(false);
  }
}
void fct_evm_default(FctOut& fct_out) {
  fct_out.mutable_hwa()->set_adc_vehdisp_warn(false);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio