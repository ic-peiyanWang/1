#include <iostream>
#include <mutex>
#include "LongCtrl.h"
#include "ahc_main.h"
#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"
#include "common/esd/esd_np_feature.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "fct_debug_out_proc.h"
#include "fct_dlb_out_proc.h"
#include "fct_in_proc.h"
#include "fct_long_control.h"
#include "fct_main.h"
#include "fct_user_interface_proc.h"
#include "go_notifier.h"
#include "heater.h"
#include "ids_mil.h"
#include "niodds/application/application.h"
#include "planner/io_manager/io_adapter.h"

#if defined(__aarch64_defined__)
#include "fault_tsp_log.h"
#endif

namespace nio {
namespace ad {
namespace fctapp {

std::string fault_type;
std::string fault_name;
uint8_t     fault_byte;
uint8_t     fault_bit;
bool        fault_state;

#if defined(__aarch64_defined__)
DiagTsp_log np_tsp_log;
#endif

#if defined(__aarch64_defined__)
DiagTsp_log nop_tsp_log;
#endif


void fct_main(const nio::ad::messages::VEH10ms& veh10ms, const nio::ad::messages::VEH50ms& veh50ms,
              FCTInputAdapter* fctinput, FctOut& fctout, FCTDebugOut& fct_debug_out,
              DAStateMachineAdapter* dastatemachine_adapter, std::shared_ptr<planner::IOAdapter>& ioadapter) {
  ids_mil_step();
  // fct_nop_user_interface.fct_nop_user_interface_processing(veh_dyn, HWA_out);
  gonotifier.MainFunction();
  tl_gonotifier.MainFunction();
  adcheater.MainFunction();

  fct_long_control.fctLongControlMainFunction(fctout, veh50ms, ioadapter); // it is to write the long control policy on the outside of the Matlab Model.
  // fct_long_control.fctLatControlMainFunction(fctout, veh50ms, ioadapter); // it is to write the lateral control policy on the outside of the Matlab Model.

  // fct_output_processing(fctout);
  // fct_debug_output_processing(fct_debug_out);
}

void fct_output_fill(FctOut& fctout, FCTDebugOut& fct_debug_out, FCTDlbOut& fct_dlb_out, APP_state_e APP_state,
                     nio::ad::messages::esd_np_feature& esdout, DAStateMachineAdapter* dastatemachine_adapter,
                     std::shared_ptr<FctDaInhibit>& fctdainhibit, std::shared_ptr<planner::IOAdapter>& ioadapter) {
  fct_output_processing(fctout, APP_state, ioadapter);
  fct_fillNopStatus_debug_out(dastatemachine_adapter, &uBitNopStatusTriggerSup, &flagNopStatusActvTigger,
                              &flagNopStatusDectvTigger);
  fct_fillUrbanStatus_debug_out(dastatemachine_adapter, &uBitUrbanStatusTrigggerSup);
  fct_debug_output_processing(fctout, fct_debug_out, fctdainhibit, APP_state, ioadapter);
  fct_dlb_output_processing(fctout, fct_debug_out, fct_dlb_out, APP_state);
  fct_user_interface_fill(ioadapter, APP_state);
}

void fct_init(void) {

  ids_mil_initialize();
}

void nop_fault_log(FctOut& fctout, APP_state_e APP_state) {
  static uint32_t last_nadsts_ = 0;
  [[maybe_unused]] uint8_t tsp_disable  = 0;
  uint32_t        nadsts_      = static_cast<uint32_t>(fctout.hwa().nanadsts());

  static uint32_t last_nopfimsts_      = 0;
  uint32_t        nopfimsts_           = static_cast<uint32_t>(fct_fim.is_NOP_Fim);
  static uint32_t last_nopfailsafests_ = 0;
  uint32_t        nopfailsafests_      = static_cast<uint32_t>(fct_fim.is_NOP_Failsafe);
  static uint32_t last_noptopicsts_    = 0;
  uint32_t        noptopicsts_         = static_cast<uint32_t>(fct_diag_interface.is_NOP_TopicFault);

  if ((9 == last_nadsts_ && 9 != nadsts_) && (nopfimsts_ == 1 || nopfailsafests_ == 1 || noptopicsts_ == 1)) {

    INFO_LOG << "Fct_Fault_Log_Nop_FimState: " << static_cast<uint32_t>(gNOPFaultSts);
    INFO_LOG << "Fct_Fault_Log_Nop_FailsafeState: " << static_cast<uint32_t>(gNOPFailSafeSupSts);
    INFO_LOG << "Fct_Fault_Log_Nop_TopicState: " << static_cast<uint32_t>(fct_diag_interface.is_NOP_TopicFault);
    if (7 == nadsts_ || 8 == nadsts_){
      tsp_disable = 0;
      fault_state = true;
      fault_type  = "NOP_Internal_Fault";

      if (APP_state == APP_state_e::FullActive || APP_state == APP_state_e::PartialActive
        || APP_state == APP_state_e::Failure) {
        INFO_LOG << "Fct_Fault_Log_TopicLoss: " << static_cast<uint32_t>(gFctTopicLoss);
        INFO_LOG << "Fct_Fault_Log_TopicNoInit: " << static_cast<uint32_t>(gFctTopicNoInit);
        if (((gFctTopicLoss | gFctTopicNoInit) & 0x2000000) != 0) {
          fault_name = "NopChassisCtrl_Topic_Los";
          INFO_LOG << "Fct_Fault_Log ---"
                 << "common/nop/nop_chassis_control Loss";
        }
        if (((gFctTopicLoss | gFctTopicNoInit) & 0x4000000) != 0) {
          fault_name = "NopFuncSts_Topic_Los";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "common/nop/nop_functionstatus Loss";
        }
        if (((gFctTopicLoss | gFctTopicNoInit) & 0x8000000) != 0) {
          fault_name = "NopScenemgmt_Topic_Los";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "common/nop/nop_scenemgmt Loss";
        }
        if (((gFctTopicLoss | gFctTopicNoInit) & 0x10000000) != 0) {
          fault_name = "NopSpdLmtVal_Topic_Los";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "common/nop/nop_speedlimitvalue Loss";
        }
        if (((gFctTopicLoss | gFctTopicNoInit) & 0x20000000) != 0) {
          fault_name = "NopVehOut_Topic_Los";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "common/nop/nop_vehicleout Loss";
        }
      }

      if (gNOPFaultSts != FimFault_e::NoFault) {
        fault_name = "FIM_Cause_Fault";
        for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
          if (gNOPFimByte[index] != 0) {
            for (uint8_t bit = 0; bit < 8; bit++) {
             if ((gNOPFimByte[index] & (1 << bit)) != 0) {
               fault_byte = index;
               fault_bit  = bit;
               INFO_LOG << "Fct_Fault_Log ---"
                        << "gNOPFim  Byte Num: " << static_cast<uint32_t>(index)
                        << "  bit Num:  " << static_cast<uint32_t>(bit);
             }
           }
         } else {
           // nothing
         }
       }
      } else {
       fault_byte = 0;
       fault_bit  = 0;
      }

      if ((gNOPFailSafeSupSts != FimFault_e::NoFault) && (gNOPFaultSts == FimFault_e::NoFault)) {
        if (gFLFailsafe.high != 0) {
          fault_name = "FL_Failsafe";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "gFLFailsafe : " << static_cast<uint32_t>(gFLFailsafe.high);
        }
        if (gFRFailsafe.high != 0) {
          fault_name = "FR_Failsafe";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "gFRfailsafe : " << static_cast<uint32_t>(gFRFailsafe.high);
        }
        if (gRrFailsafe.high != 0) {
          fault_name = "Rr_Failsafe";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "gRrfailsafe : " << static_cast<uint32_t>(gRrFailsafe.high);
        }
        if (gRLFailsafe.high != 0) {
          fault_name = "RL_Failsafe";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "gRLfailsafe : " << static_cast<uint32_t>(gRLFailsafe.high);
        }
        if (gRRFailsafe.high != 0) {
          fault_name = "RR_Failsafe";
          INFO_LOG << "Fct_Fault_Log ---"
                   << "gRRfailsafe : " << static_cast<uint32_t>(gRRFailsafe.high);
        }
      }
    } else if(5 == nadsts_ || 4 == nadsts_ || 2 == nadsts_){
      tsp_disable = 0;
      fault_state = true;
      fault_type  = "NOP_Internal_Fault";
      fault_name  = "Internal_Exit";
    }else {
      tsp_disable = 1;
          // nothing, maybe later for PSP tsp log
    }

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      nop_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }
  if ((last_nopfimsts_ == 1 && nopfimsts_ == 0 && nopfailsafests_ == 0 && noptopicsts_ == 0)
      || (last_nopfailsafests_ == 1 && nopfailsafests_ == 0 && nopfimsts_ == 0 && noptopicsts_ == 0)
      || (last_noptopicsts_ == 1 && noptopicsts_ == 0 && nopfimsts_ == 0 && nopfailsafests_ == 0)) {
      tsp_disable = 0;
      fault_state = false;
      INFO_LOG << "Fct_Fault_Log_Nop_ Fault  : recover ";

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      nop_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }
  last_nadsts_         = nadsts_;
  last_nopfimsts_      = nopfimsts_;
  last_nopfailsafests_ = nopfailsafests_;
  last_noptopicsts_    = noptopicsts_;
}

void np_fault_log(FctOut& fctout, APP_state_e APP_state, FCTDlbOut& fct_dlb_out) {
  static uint32_t last_nadsts_ = 0;
  [[maybe_unused]] uint8_t tsp_disable  = 0;
  uint32_t        nadsts_      = static_cast<uint32_t>(fctout.hwa().nanadsts());

  static uint32_t last_npfimsts_      = 0;
  uint32_t        npfimsts_           = static_cast<uint32_t>(fct_fim.da_np_fim.is_np_fault);
  static uint32_t last_npfailsafests_ = 0;
  uint32_t        npfailsafests_      = ACCSC_uFailSafeTDSoftInh1_mp;
  static uint32_t last_nptopicsts_    = 0;
  uint32_t        nptopicsts_         = static_cast<uint32_t>(fct_diag_interface.is_DA_TopicFault);

  if ((6 == last_nadsts_ || 7 == last_nadsts_ || 8 == last_nadsts_) && (5 == nadsts_ || 4 == nadsts_ || 2 == nadsts_)
      && (npfimsts_ == 1 || npfailsafests_ == 1 || nptopicsts_ == 1)) {
    tsp_disable = 0;
    fault_state = true;
    fault_type  = "NP_Internal_Fault";

    INFO_LOG << "Fct_Fault_Log_Np_FimState: " << static_cast<uint32_t>(gPilotNPFaultSt);
    INFO_LOG << "Fct_Fault_Log_Np_FailsafeState: " << static_cast<uint32_t>(ACCSC_uFailSafeTDSoftInh1_mp);
    INFO_LOG << "Fct_Fault_Log_Np_TopicState: " << static_cast<uint32_t>(fct_diag_interface.is_DA_TopicFault);

    if (APP_state == APP_state_e::FullActive || APP_state == APP_state_e::PartialActive
        || APP_state == APP_state_e::Failure) {
      INFO_LOG << "Fct_Fault_Log_TopicLoss: " << static_cast<uint32_t>(gFctTopicLoss);
      INFO_LOG << "Fct_Fault_Log_TopicNoInit: " << static_cast<uint32_t>(gFctTopicNoInit);
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x01) != 0) {
        fault_name = "Fct_VehicleInput_10_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "common/vehicle_in/vehicle_10ms Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x02) != 0) {
        fault_name = "Fct_VehicleInput_50_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "common/vehicle_in/vehicle_50ms Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x04) != 0) {
        fault_name = "Fct_Ehy_Tse_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "np/apps/ehy_tse_outputs Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x08) != 0) {
        fault_name = "Fct_Ehy_Tsi_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "np/apps/ehy_tsi_outputs Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x10) != 0) {
        fault_name = "Fct_Ehy_Tpp_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "np/apps/ehy_tpp_outputs Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x20) != 0) {
        fault_name = "Fct_Ehy_Lpp_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "np/apps/ehy_lpp_outputs Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x40) != 0) {
        fault_name = "Fct_Ehy_Rme_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "np/apps/ehy_rme_road_outputs Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x400) != 0) {
        fault_name = "Fct_RoadDetection_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "common/perception/vision_road_detection Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x800) != 0) {
        fault_name = "Fct_VisionObjects_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "common/perception/perception_objects Loss";
      }
      if (((gFctTopicLoss | gFctTopicNoInit) & 0x1000) != 0) {
        fault_name = "Fct_RadarData_Los";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "common/perception/radar_object Loss";
      }
    }

    if (gPilotNPFaultSt != FimFault_e::NoFault) {
      fault_name = "FIM_Cause_Fault";
      for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
        if (gPilotNPByte[index] != 0) {
          for (uint8_t bit = 0; bit < 8; bit++) {
            if ((gPilotNPByte[index] & (1 << bit)) != 0) {
              fault_byte = index;
              fault_bit  = bit;
              INFO_LOG << "Fct_Fault_Log ---"
                       << "gPilotFim  Byte Num: " << static_cast<uint32_t>(index)
                       << "  bit Num:  " << static_cast<uint32_t>(bit);
            }
          }
        } else {
          // nothing
        }
      }
    } else {
      fault_byte = 0;
      fault_bit  = 0;
    }

    if ((ACCSC_uFailSafeTDSoftInh1_mp != 0) && (gPilotNPFaultSt == FimFault_e::NoFault)) {
      if (fct_fim.da_FailSafe.is_CamFW_FailSafe != 0) {
        fault_name = "CamFW_FailSafe";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "is_CamFW_FailSafe : " << static_cast<uint32_t>(fct_fim.da_FailSafe.is_CamFW_FailSafe);
      }
      if (fct_fim.da_FailSafe.is_CamFN_FailSafe != 0) {
        fault_name = "CamFN_FailSafe";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "is_CamFN_FailSafe : " << static_cast<uint32_t>(fct_fim.da_FailSafe.is_CamFN_FailSafe);
      }
      if (fct_fim.da_FailSafe.is_Lidar_FailSafe != 0) {
        fault_name = "Lidar_FailSafe";
        INFO_LOG << "Fct_Fault_Log ---"
                 << "is_Lidar_FailSafe : " << static_cast<uint32_t>(fct_fim.da_FailSafe.is_Lidar_FailSafe);
      }
    }

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      np_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }
  if ((last_npfimsts_ == 1 && npfimsts_ == 0 && npfailsafests_ == 0 && nptopicsts_ == 0)
      || (last_npfailsafests_ == 1 && npfailsafests_ == 0 && npfimsts_ == 0 && nptopicsts_ == 0)
      || (last_nptopicsts_ == 1 && nptopicsts_ == 0 && npfimsts_ == 0 && npfailsafests_ == 0)) {
    tsp_disable = 0;
    fault_state = false;
    INFO_LOG << "Fct_Fault_Log_Np_ Fault  : recover ";

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      np_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }
  last_nadsts_        = nadsts_;
  last_npfimsts_      = npfimsts_;
  last_npfailsafests_ = npfailsafests_;
  last_nptopicsts_    = nptopicsts_;
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
