#include <iostream>
#include "fct_out_proc.h"
#include "ELKCore.h"
#include "LKACore.h"
#include "LKSCore.h"
#include "ahc_main.h"
#include "ahc_type.h"
#include "fct_loc_cfg.h"
#include "fct_me_param.h"
#include "fct_out_proc.h"
#include "fct_timestamps_param.h"
#include "fct_user_interface_proc.h"
#include "func_arb_type.h"
#include "go_notifier.h"
#include "heater.h"
#include "ids_mil.h"
#include "io_manager/io_adapter.h"
#include "niodds/application/application.h"
#include "fct_input_adapter.h"

// using nio::ad::messages::FctOut;
// using nio::ad::messages::debug::FCTDebugOut;

namespace nio {
namespace ad {
namespace fctapp {

uint16_t    Fct_start_cnt           = 0;
uint16_t    Fct_failure_thr         = 1800;
const float kstepTime_s             = 0.05;
const float kplatform_debouceTime_s = 10;
apollo::cyber::Time last_np_stop_before_junction_wti_timestamp_ = apollo::cyber::Time(0.0);
int fault_code_count = 0;
bool last_WSHeatTransSts = false;

bool turnon_delay(bool flag, float& timer, float timer_limit) {
  bool flag_trunon = false;
  if (flag) {
    timer += kstepTime_s;
  } else {
    timer = 0;
  }

  if (timer >= timer_limit) {
    timer       = timer_limit;
    flag_trunon = true;
  }

  return flag_trunon;
}

void fct_output_processing(FctOut& fct_out, APP_state_e APP_state,
                           std::shared_ptr<planner::IOAdapter>& ioadapter) {

  Fct_start_cnt++;
  if ((APP_state == APP_state_e::Suspend) || (APP_state == APP_state_e::Failure)) {
    fct_out.mutable_ahc()->set_ahchibmreq(0);

    fct_out.mutable_latctrl()->set_absltpinionagreq(0);
    fct_out.mutable_latctrl()->set_epsreqtyp(0);
    fct_out.mutable_latctrl()->set_extreqcamfc(0);
    fct_out.mutable_latctrl()->set_lelinetyp(0);
    fct_out.mutable_latctrl()->set_rilinetyp(0);
    fct_out.mutable_latctrl()->set_letrackingsts(0);
    fct_out.mutable_latctrl()->set_ritrackingsts(0);
    fct_out.mutable_latctrl()->set_lkahodwarnseq(0);
    fct_out.mutable_latctrl()->set_lkasnsvty(0);
    fct_out.mutable_latctrl()->set_latctrlactv(0);

    fct_out.mutable_latctrl()->set_latctrltarle(
      nio::ad::messages::LatCtrlOut_LatCtrlTar_e::LatCtrlOut_LatCtrlTar_e_DALatCtrlInActv);
    fct_out.mutable_latctrl()->set_latctrltarri(
      nio::ad::messages::LatCtrlOut_LatCtrlTar_e::LatCtrlOut_LatCtrlTar_e_DALatCtrlInActv);
    fct_out.mutable_latctrl()->set_epsacitsusup(
      nio::ad::messages::LatCtrlOut_ACITsuSup_e::LatCtrlOut_ACITsuSup_e_ACITsuSupSet1);
    fct_out.mutable_latctrl()->set_vmc1acitsusup(
      nio::ad::messages::LatCtrlOut_ACITsuSup_e::LatCtrlOut_ACITsuSup_e_ACITsuSupSet1);

    fct_out.mutable_ldw()->set_adasleline(0);
    fct_out.mutable_ldw()->set_adasriline(0);
    fct_out.mutable_ldw()->set_epsreqtyp(0);
    fct_out.mutable_ldw()->set_hapticonoffsts(0);
    fct_out.mutable_ldw()->set_snvty(0);

    fct_out.mutable_hwa()->set_accnpsts(nio::ad::messages::HwaOut_AccNpSts_e::HwaOut_AccNpSts_e_Off);
    fct_out.mutable_hwa()->set_nanadsts(nio::ad::messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdOff);
    fct_out.mutable_hwa()->set_nanadwti(0);
    fct_out.mutable_hwa()->set_freespaceintrsn(false);
    fct_out.mutable_hwa()->set_hodwarnreq(0);
    fct_out.mutable_hwa()->set_hzrdlireq(0);
    fct_out.mutable_hwa()->set_da_nop_wtis(0);
    fct_out.mutable_hwa()->set_da_iacc_wtis(0);
    fct_out.mutable_hwa()->set_da_pilot_wtis(0);
    fct_out.mutable_hwa()->set_adms_wtis(0);
    fct_out.mutable_hwa()->set_da_psp_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_PSP_WTIs));

    fct_out.mutable_hwa()->set_da_turnindctrletip(0);
    fct_out.mutable_hwa()->set_da_turnindctrritip(0);
    fct_out.mutable_hwa()->set_da_turnindctrlelatch(0);
    fct_out.mutable_hwa()->set_da_turnindctrrilatch(0);
    fct_out.mutable_hwa()->set_da_turnindctrlepush(0);
    fct_out.mutable_hwa()->set_da_turnindctrripush(0);
    fct_out.mutable_hwa()->set_adctocdc_temp2bit_2(nio::ad::messages::HwaOut_ADCtoCDC_temp2bit_2_e::HwaOut_ADCtoCDC_temp2bit_2_e_ADCtoCDC_temp2bit_2_NotAvl);
    fct_out.mutable_hwa()->set_adctocdc_temp1bit_1(static_cast<nio::ad::messages::HwaOut_ADCtoCDC_temp1bit_1_e>(0));

    fct_out.mutable_lonctrl()->set_modeesp(0);
    fct_out.mutable_lonctrl()->set_deceltostopreq(0);
    fct_out.mutable_lonctrl()->set_drvoffreq(0);
    fct_out.mutable_lonctrl()->set_maxjerkaccl(0);
    fct_out.mutable_lonctrl()->set_minjerkaccl(0);
    fct_out.mutable_lonctrl()->set_targetaccel(0);
    fct_out.mutable_lonctrl()->set_shutdownmodreq(0);
    fct_out.mutable_lonctrl()->set_dsplvelocityset(0);
    fct_out.mutable_lonctrl()->set_taugapset(0);

    fct_out.mutable_lonctrl()->set_taugapchgdisp(
      nio::ad::messages::LonCtrlOut_TauGapChg_e::LonCtrlOut_TauGapChg_e_NoChange);
    fct_out.mutable_lonctrl()->set_displsetspdenbl(0);
    fct_out.mutable_lonctrl()->set_vlcreqfct(
      nio::ad::messages::LonCtrlOut_VlcReqFctType_e::LonCtrlOut_VlcReqFctType_e_Off);
    fct_out.mutable_lonctrl()->set_spdunit(0);
    fct_out.mutable_lonctrl()->set_objvalid(0);
    fct_out.mutable_lonctrl()->set_da_setspeedanimation(static_cast<nio::ad::messages::LonCtrlOut_DA_SetSpdAnmt_e>(0));
    fct_out.mutable_lonctrl()->set_da_inhibit(0);

    fct_out.mutable_sas()->set_speedlimitvalue(0);
    fct_out.mutable_sas()->set_speedunit(0);
    fct_out.mutable_sas()->set_speedlimitattribute(
      nio::ad::messages::SasOut_SpdLmtAttr_e::SasOut_SpdLmtAttr_e_NoDisplay);
    fct_out.mutable_sas()->set_speedlimittakeover(nio::ad::messages::SasOut_SpdLmtTkOv_e::SasOut_SpdLmtTkOv_e_None);
    fct_out.mutable_sas()->set_supsigntype(0);
    fct_out.mutable_sas()->set_supsignattribute(0);
    fct_out.mutable_sas()->set_roadfeaturewarningsign(0);
    fct_out.mutable_sas()->set_trafficlightsts(0);
    fct_out.mutable_sas()->set_localhazards(0);

    fct_out.mutable_sas()->set_slwfwarntrigger(
      nio::ad::messages::SasOut_SLIFWarnTrgSts_e::SasOut_SLIFWarnTrgSts_e_NoWarning);

    fct_out.mutable_elk()->set_esfwarningsts(
      nio::ad::messages::ElkOut_ESFWarningSts_e::ElkOut_ESFWarningSts_e_ESFNoRequest);

    fct_out.mutable_heater()->set_wsheatreq(false);
    fct_out.mutable_heater()->set_wsheatreqvalid(false);

    fct_out.mutable_lonctrl()->set_gonotfrreq(0);
    fct_out.mutable_lonctrl()->set_gonotifytyp2(0);
    fct_out.mutable_latctrl()->mutable_alcsinfo()->set_da_alcssts(0);

    fct_out.mutable_eas()->set_eassts(static_cast<uint32_t>(0));
    fct_out.mutable_eas()->set_easwarninglv(static_cast<uint32_t>(0));
    fct_out.mutable_eas()->set_rpslockunlckctrl(static_cast<uint32_t>(0));
    fct_out.mutable_eas()->set_eascall(0);
    // fct_out.mutable_reserved()->Clear();
    // fct_out.add_reserved(static_cast<double>(0));  // Index:0 HWA_out.HWASM.ShowSetDA_NOP
    // fct_out.add_reserved(static_cast<double>(0));  // Index:1 HWA_out.HWASM.ShowSwtichDA_NOP
    fct_out.add_reserved(static_cast<double>(0));  // Index:2 HWA_out.HWASM.ShowSetDA_NOPALC
    // fct_out.add_reserved(static_cast<double>(0));  // Index:3 HWA_out.HWASM.ShowSetDA_DANOPAvl
    fct_out.mutable_hwa()->set_da_nop_avl(
      static_cast<nio::ad::messages::HwaOut_DA_NOP_Avl_e>(0));  // Index:3 HWA_out.HWASM.ShowSetDA_DANOPAvl

    fct_out.mutable_sesrsts()->set_camera_frntwidests(static_cast<nio::ad::messages::SnsrStsOut_SnsrSts_e>(0));

    if (nullptr != ioadapter) {
      fct_out.set_ramp_distance(ioadapter->getMidOutputManager().getDistanceToSplit());
      fct_out.set_ramp_lane_change_nums(ioadapter->getMidOutputManager().getRampLaneChangeNum());
    } else {
      fct_out.set_ramp_distance(10000.0);
      fct_out.set_ramp_lane_change_nums(-1);
    }

    if (APP_state == APP_state_e::Suspend) {
      fct_out.mutable_ahc()->set_ahcsysst(0);
      fct_out.mutable_sas()->set_slifstate(nio::ad::messages::SasOut_SLIFSts_e::SasOut_SLIFSts_e_Init);
      fct_out.mutable_elk()->set_elksts(nio::ad::messages::ElkOut_ELKSts_e::ElkOut_ELKSts_e_ELKOff);
      fct_out.mutable_ldw()->set_laneasststs(0);
      fct_out.mutable_ldw()->set_laneassttyp(0);
      fct_out.mutable_latctrl()->set_lkalnasststs(0);
      fct_out.mutable_latctrl()->set_laneassityp(0);
    } else if (APP_state == APP_state_e::Failure) {
      if (Fct_start_cnt >= Fct_failure_thr) {
        fct_out.mutable_ahc()->set_ahcsysst(3);
        Fct_start_cnt = Fct_failure_thr;
      } else {
        fct_out.mutable_ahc()->set_ahcsysst(0);
      }
      fct_out.mutable_sas()->set_slifstate(nio::ad::messages::SasOut_SLIFSts_e::SasOut_SLIFSts_e_Fault);

      if (LKS_LCA_out.ELKSts != 0 && !fct_diag_interface.is_vision_no_ready) {
        fct_out.mutable_elk()->set_elksts(nio::ad::messages::ElkOut_ELKSts_e::ElkOut_ELKSts_e_ELKFailure);
      } else {
        fct_out.mutable_elk()->set_elksts(nio::ad::messages::ElkOut_ELKSts_e::ElkOut_ELKSts_e_ELKOff);
      }

      if (LDW_stLaneAsstStsOut_mp != 0 && !fct_diag_interface.is_vision_no_ready) {
        fct_out.mutable_ldw()->set_laneasststs(3);
      } else {
        fct_out.mutable_ldw()->set_laneasststs(0);
      }

      if (LKS_LCA_out.LkaLnAsstSts != 0 && !fct_diag_interface.is_vision_no_ready) {
        fct_out.mutable_latctrl()->set_lkalnasststs(3);
      } else {
        fct_out.mutable_latctrl()->set_lkalnasststs(0);
      }

      fct_out.mutable_latctrl()->set_laneassityp(0);

    } else {
      // do nothing
    }

    fct_out.mutable_function()->Clear();
    auto func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaMain));
    func_info->set_functionname("DaMain");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::EAS));
    func_info->set_functionname("EAS");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaSdc));
    func_info->set_functionname("DaSdc");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaLcc));
    func_info->set_functionname("DaLcc");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::ELK));
    func_info->set_functionname("ELK");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(nio::ad::messages::FunctionXstatus_FunctionStatus::FunctionXstatus_FunctionStatus_OFF);
    func_info->set_functionid(171);
    func_info->set_functionname("AHB");

    fct_esd_output_default(fct_out);

    fct_out.mutable_drive_assist_to_adhmi()->set_damain_to_adinfo(0);

    fct_out.mutable_reserved()->Clear();
    fct_out.add_reserved(static_cast<double>(0));                                // 0
    fct_out.add_reserved(static_cast<double>(0));                                // 1
    fct_out.add_reserved(static_cast<double>(0));                                // 2
    fct_out.add_reserved(static_cast<double>(0));                                // 3
    fct_out.add_reserved(static_cast<double>(0));                                // 4
    fct_out.add_reserved(static_cast<double>(0));                                // 5
    fct_out.add_reserved(static_cast<double>(0));                                // 6
    fct_out.add_reserved(static_cast<double>(0));                                // 7
    fct_out.add_reserved(static_cast<double>(0));                                // 8
    fct_out.add_reserved(static_cast<double>(0));                                // 9
    fct_out.add_reserved(static_cast<double>(0));                                // 10
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.VLCLLCSts));          // 11
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.LLCReqFctSt));        // 12
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.LLCShutdownModReq));  // 13
    fct_out.add_reserved(static_cast<double>(0));                                // 14
    fct_out.add_reserved(static_cast<double>(MainState_info.PSP_DAmain_MRMongoing));  // 15
    fct_out.add_reserved(static_cast<double>(MainState_info.PSP_PNC_MRMongoing));     // 16
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.DA_PSP_WTIs));             // 17
    fct_out.add_reserved(static_cast<double>(MainState_info.ShowSwtichDA_NOP));       // 18
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.EPSHviReq));               // 19
    fct_out.add_reserved(static_cast<double>(0));                                     // 20
    fct_out.add_reserved(static_cast<double>(0));                                     // 21
    fct_out.add_reserved(static_cast<double>(0));                                     // 22
    fct_out.add_reserved(static_cast<double>(0));                                     // 23
    fct_out.add_reserved(static_cast<double>(0));                                     // 24
    fct_out.add_reserved(static_cast<double>(0));                                     // 25
    fct_out.add_reserved(static_cast<double>(0));                                     // 26
    fct_out.add_reserved(static_cast<double>(0));                                     // 27
    fct_out.add_reserved(static_cast<double>(0));                                     // 28
    fct_out.add_reserved(static_cast<double>(0));                                     // 29
    fct_out.add_reserved(static_cast<double>(0));                                     // 30
    fct_out.add_reserved(static_cast<double>(0));                                     // 31
    fct_out.add_reserved(static_cast<double>(0));                                     // 32
  } else {
    fct_out.mutable_ahc()->set_ahcsysst(static_cast<int32_t>(AHCSm.Get_AutoHiBeamSysSts()));
    fct_out.mutable_ahc()->set_ahchibmreq(AHCSm.Get_AutoHiBeamReq());

    fct_out.mutable_latctrl()->set_absltpinionagreq(LKS_LCA_out.LatCtrl_phiAbsltPinionAgReq);
    fct_out.mutable_latctrl()->set_epsreqtyp(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stEPSReqTyp));
    fct_out.mutable_latctrl()->set_extreqcamfc(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stExtReqCAMFC));
    fct_out.mutable_latctrl()->set_laneassityp(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stLKSLaneAssiTyp));
    fct_out.mutable_latctrl()->set_lelinetyp(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stLeLineTyp));
    fct_out.mutable_latctrl()->set_rilinetyp(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stRiLineTyp));
    fct_out.mutable_latctrl()->set_letrackingsts(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stLKSLeTrackingSts));
    fct_out.mutable_latctrl()->set_ritrackingsts(static_cast<int32_t>(LKS_LCA_out.LatCtrl_stLKSRiTrackingSts));
    fct_out.mutable_latctrl()->set_lkahodwarnseq(static_cast<int32_t>(LKS_LCA_out.stLkaHODWarnSeqReq));
    fct_out.mutable_latctrl()->set_lkalnasststs(static_cast<int32_t>(LKS_LCA_out.LkaLnAsstSts));
    fct_out.mutable_latctrl()->set_lkasnsvty(static_cast<int32_t>(LatCtrl_Lka_stSnvtyOut_mp));
    fct_out.mutable_latctrl()->set_latctrlactv(static_cast<boolean_T>(LKS_LCA_out.flgLatCtrlActv));

    fct_out.mutable_latctrl()->set_latctrltarle(
      static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(LKS_LCA_out.LatCtrlTarLe));
    fct_out.mutable_latctrl()->set_latctrltarri(
      static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(LKS_LCA_out.LatCtrlTarRi));
    fct_out.mutable_latctrl()->set_epsacitsusup(
      static_cast<nio::ad::messages::LatCtrlOut_ACITsuSup_e>(LKS_LCA_out.ACITsuSup));
    fct_out.mutable_latctrl()->set_vmc1acitsusup(
      static_cast<nio::ad::messages::LatCtrlOut_ACITsuSup_e>(LKS_LCA_out.ACITsuSup));

    fct_out.mutable_ldw()->set_adasleline(static_cast<int32_t>(LDW_stAdasLeLineOut_mp));
    fct_out.mutable_ldw()->set_adasriline(static_cast<int32_t>(LDW_stAdasRiLineOut_mp));
    fct_out.mutable_ldw()->set_epsreqtyp(static_cast<int32_t>(LDW_stEPSReqTypOut_mp));
    fct_out.mutable_ldw()->set_hapticonoffsts(static_cast<boolean_T>(LDW_flgLaneAsstHapticOnOffStsOut_mp));
    fct_out.mutable_ldw()->set_laneasststs(static_cast<int32_T>(LDW_stLaneAsstStsOut_mp));
    fct_out.mutable_ldw()->set_laneassttyp(static_cast<int32_T>(LDW_stLaneAsstTypOut_mp));
    fct_out.mutable_ldw()->set_snvty(static_cast<int32_T>(LDW_stSnvtyOut_mp));

    fct_out.mutable_hwa()->set_accnpsts(static_cast<nio::ad::messages::HwaOut_AccNpSts_e>(HWA_out.HWASM.St_AccNpSts));
    fct_out.mutable_hwa()->set_nanadsts(static_cast<nio::ad::messages::HwaOut_NadSts_e>(HWA_out.HWASM.NadSts));
    fct_out.mutable_hwa()->set_nanadwti(static_cast<uint32_t>(0));
    fct_out.mutable_hwa()->set_freespaceintrsn(static_cast<bool>(HWA_out.LNGCTRL.FreeSpcIntr));
    fct_out.mutable_hwa()->set_hodwarnreq(static_cast<int32_t>(HWA_out.HWASM.St_HodWarnSeq));
    fct_out.mutable_hwa()->set_hzrdlireq(static_cast<int32_t>(HWA_out.HWASM.St_HzrdLiReq));
    fct_out.mutable_hwa()->set_da_nop_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_NOP_WTIs));
    // fct_out.mutable_hwa()->set_da_pilot_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_Pilot_WTIs));
    // fct_out.mutable_hwa()->set_da_iacc_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_iACC_WTIs));
    fct_out.mutable_hwa()->set_da_iacc_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_iACC_WTIs));
    fct_out.mutable_hwa()->set_da_pilot_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_Pilot_WTIs));
    fct_out.mutable_hwa()->set_adms_wtis(static_cast<uint32_t>(HWA_out.HWASM.ADMS_WTIs));
    fct_out.mutable_hwa()->set_da_psp_wtis(static_cast<uint32_t>(HWA_out.HWASM.DA_PSP_WTIs));

    fct_out.mutable_hwa()->set_da_turnindctrletip(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrLeTip));
    fct_out.mutable_hwa()->set_da_turnindctrritip(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrRiTip));
    fct_out.mutable_hwa()->set_da_turnindctrlelatch(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrLeLatch));
    fct_out.mutable_hwa()->set_da_turnindctrrilatch(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrRiLatch));
    fct_out.mutable_hwa()->set_da_turnindctrlepush(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrLePush));
    fct_out.mutable_hwa()->set_da_turnindctrripush(
      static_cast<bool>(MtnCtrl_SAL_out.DrvrOpOut.TurnIdctrSts.TurnIndctrRiPush));
    fct_out.mutable_hwa()->set_adctocdc_temp2bit_2(
      static_cast<nio::ad::messages::HwaOut_ADCtoCDC_temp2bit_2_e>(MainState_info.adctocdc_temp2bit_2));
    
    static apollo::cyber::Time stop_speed_warning_start_time = apollo::cyber::Time(0.0);
    static uint8_t last_swf = static_cast<uint8_t>(veh_drvr.AdFunCfg.SetSWF);
    if((last_swf == 1 || last_swf == 2) && static_cast<uint8_t>(veh_drvr.AdFunCfg.SetSWF) == 0){
      stop_speed_warning_start_time = ncyber::Time::Now();
    } else if (static_cast<uint8_t>(veh_drvr.AdFunCfg.SetSWF) != 0) {
      stop_speed_warning_start_time = apollo::cyber::Time(0.0);
    }
    last_swf = static_cast<uint8_t>(veh_drvr.AdFunCfg.SetSWF);
    auto warning_duration = ncyber::Time::Now() - stop_speed_warning_start_time;
    if(warning_duration.ToSecond() <= 10.5){
      fct_out.mutable_hwa()->set_adctocdc_temp1bit_1(static_cast<nio::ad::messages::HwaOut_ADCtoCDC_temp1bit_1_e>(1));
    }
    else {
      fct_out.mutable_hwa()->set_adctocdc_temp1bit_1(static_cast<nio::ad::messages::HwaOut_ADCtoCDC_temp1bit_1_e>(0));
    }

    fct_out.mutable_lonctrl()->set_modeesp(HWA_out.LNGCTRL.LongCtrl_ModeESP);
    fct_out.mutable_lonctrl()->set_deceltostopreq(HWA_out.LNGCTRL.LongCtrl_DecelToStopReq);
    fct_out.mutable_lonctrl()->set_drvoffreq(HWA_out.LNGCTRL.LongCtrl_DrvOffReq);
    fct_out.mutable_lonctrl()->set_maxjerkaccl(HWA_out.LNGCTRL.LongCtrl_MaxJerkA);
    fct_out.mutable_lonctrl()->set_minjerkaccl(HWA_out.LNGCTRL.LongCtrl_MinJerkA);
    fct_out.mutable_lonctrl()->set_targetaccel(HWA_out.LNGCTRL.LongCtrl_TargetAccel);
    fct_out.mutable_lonctrl()->set_shutdownmodreq(HWA_out.LNGCTRL.LongCtrl_ShutdownModReq);
    fct_out.mutable_lonctrl()->set_dsplvelocityset(common_proc_info.user_set_speed_out);
    fct_out.mutable_lonctrl()->set_taugapset(HWA_out.LNGCTRL.LongCtrl_TauGapSet);
    fct_out.mutable_lonctrl()->set_da_inhibit(HWA_out.HWASM.DAInhibitForNop);

    fct_out.mutable_lonctrl()->set_taugapchgdisp(
      static_cast<nio::ad::messages::LonCtrlOut_TauGapChg_e>(HWA_out.LNGCTRL.TauGapChgDisp));
    fct_out.mutable_lonctrl()->set_displsetspdenbl(HWA_out.LNGCTRL.DisplSetSpdEnbl);
    fct_out.mutable_lonctrl()->set_vlcreqfct(
      static_cast<nio::ad::messages::LonCtrlOut_VlcReqFctType_e>(HWA_out.LNGCTRL.VlcReqFct));
    fct_out.mutable_lonctrl()->set_spdunit(static_cast<uint32_t>(HWA_out.LNGCTRL.ACCCT_iAccSpdLmtUnit));
    fct_out.mutable_lonctrl()->set_objvalid(HWA_out.LNGCTRL.LongCtrl_ObjValid);

    if (LatCtrl_flgElkShadowMode_C == true) {
      fct_out.mutable_elk()->set_elksts(static_cast<nio::ad::messages::ElkOut_ELKSts_e>(1));
    } else {
      fct_out.mutable_elk()->set_elksts(static_cast<nio::ad::messages::ElkOut_ELKSts_e>(LKS_LCA_out.ELKSts));
    }

    fct_out.mutable_elk()->set_esfwarningsts(
      static_cast<nio::ad::messages::ElkOut_ESFWarningSts_e>(LKS_LCA_out.ESFWarningLevel));

    fct_out.mutable_heater()->set_wsheatreq(adcheater.WSHeatReq);
    fct_out.mutable_heater()->set_wsheatreqvalid(adcheater.WSHeatReqValid);
    auto fault_codes = std::make_shared<nio::ad::messages::FaultCodes>();
    if (adcheater.WSHeatTransSts) {
      auto fault_code = fault_codes->mutable_fault_codes()->Add();
      fault_code->set_fault_code(static_cast<uint64_t>(0x5001000011170000));
      fault_code->set_fault_info("ADC heater is enabled");
      fault_code->set_status(true);
    }
    else{
      if(last_WSHeatTransSts && !adcheater.WSHeatTransSts) {
        fault_code_count = 0;
      }
      if(fault_code_count < 3){
        auto fault_code = fault_codes->mutable_fault_codes()->Add();
        fault_code->set_fault_code(static_cast<uint64_t>(0x5001000011170000));
        fault_code->set_fault_info("ADC heater is enabled");
        fault_code->set_status(false);
        fault_code_count += 1;
      }
    }
    auto heart_beat_code = fault_codes->mutable_fault_codes()->Add();
    heart_beat_code->set_fault_code(static_cast<uint64_t>(0x5001000000000000));
    heart_beat_code->set_fault_info("planner heartbeat");
    heart_beat_code->set_status(false);
    ioadapter->getOutputManager().fault_codes_.ExportData(fault_codes);
    last_WSHeatTransSts = adcheater.WSHeatTransSts;

    fct_out.mutable_lonctrl()->set_gonotfrreq(static_cast<uint32_t>(gonotifier.output_.gn_request));
    fct_out.mutable_lonctrl()->set_gonotifytyp2(tl_gonotifier.TLRequest().type);
    fct_out.mutable_latctrl()->mutable_alcsinfo()->set_da_alcssts(LKS_LCA_out.ALCSStatus);

    fct_out.mutable_eas()->set_eassts(static_cast<uint32_t>(HWA_out.LNGCTRL.EDASts));
    fct_out.mutable_eas()->set_easwarninglv(static_cast<uint32_t>(HWA_out.LNGCTRL.EDADriverWarningReq));
    fct_out.mutable_eas()->set_rpslockunlckctrl(static_cast<uint32_t>(HWA_out.HWASM.St_DoorUnlckReq));
    fct_out.mutable_eas()->set_eascall(static_cast<bool>(HWA_out.LNGCTRL.EDAECallReq));
    fct_out.mutable_lonctrl()->set_da_setspeedanimation(
      static_cast<nio::ad::messages::LonCtrlOut_DA_SetSpdAnmt_e>(HWA_out.LNGCTRL.DASetSpeedAnimation));
    // fct_out.mutable_hmiicon()->set_showsetda_steerassist(static_cast<uint32_t>(HWA_out.LNGCTRL.DASetSpeedAnimation));
    // fct_out.mutable_reserved()->Clear();
    // fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.DASysFailSym));
    fct_out.mutable_hwa()->set_da_sysfailsymbol(HWA_out.HWASM.DASysFailSym);

    uint8_t      snsr_lidarsts                = 0;
    static float timer_snsr_lidarsts_temphigh = 0;
    bool         flag_snsr_lidarsts_temphigh  = lidar_internalfault.INNO_LIDAR_TEMPHIGH_INHIBIT;
    flag_snsr_lidarsts_temphigh =
      turnon_delay(flag_snsr_lidarsts_temphigh, timer_snsr_lidarsts_temphigh, kplatform_debouceTime_s);
    static float timer_snsr_lidarsts_block1 = 0;
    bool         flag_snsr_lidarsts_block1  = lidar_internalfault.INNO_LIDAR_IN_FAULT_WINDOW_BLOCKAGE1;
    flag_snsr_lidarsts_block1 =
      turnon_delay(flag_snsr_lidarsts_block1, timer_snsr_lidarsts_block1, kplatform_debouceTime_s);
    static float timer_snsr_lidarsts_calerror = 0;
    bool         flag_snsr_lidarsts_calerror  = lidar_fim.FIM_Lidar_Cal_Error;
    flag_snsr_lidarsts_calerror =
      turnon_delay(flag_snsr_lidarsts_calerror, timer_snsr_lidarsts_calerror, kplatform_debouceTime_s);
    static float timer_snsr_lidarsts_outcal = 0;
    bool         flag_snsr_lidarsts_outcal  = (0 != ((gLidarFailsafe.high >> 6) & 0x01));
    flag_snsr_lidarsts_outcal =
      turnon_delay(flag_snsr_lidarsts_outcal, timer_snsr_lidarsts_outcal, kplatform_debouceTime_s);
    if (flag_snsr_lidarsts_calerror) {
      snsr_lidarsts = 6;
    } else if (flag_snsr_lidarsts_temphigh) {
      snsr_lidarsts = 3;
    } else if (flag_snsr_lidarsts_outcal) {
      snsr_lidarsts = 5;
    } else if (flag_snsr_lidarsts_block1) {
      snsr_lidarsts = 2;
    } else {
      snsr_lidarsts = 0;
    }
    fct_out.mutable_sesrsts()->set_lidarsts(static_cast<nio::ad::messages::SnsrStsOut_SnsrSts_e>(snsr_lidarsts));

    if (nullptr != ioadapter) {
      fct_out.set_ramp_distance(ioadapter->getMidOutputManager().getDistanceToSplit());
      fct_out.set_ramp_lane_change_nums(ioadapter->getMidOutputManager().getRampLaneChangeNum());
      const auto& frame_ptr = ioadapter->getFramePtr();
      if(nullptr != frame_ptr && frame_ptr->getIsStopBeforeJunction()){
        last_np_stop_before_junction_wti_timestamp_ = ncyber::Time::Now();
      }
    } else {
      fct_out.set_ramp_distance(10000.0);
      fct_out.set_ramp_lane_change_nums(-1);
    }

    auto np_stop_before_junction_wti_duration = ncyber::Time::Now() - last_np_stop_before_junction_wti_timestamp_;
    if (np_stop_before_junction_wti_duration.ToSecond() <= 1.0) {
      fct_out.mutable_drive_assist_to_adhmi()->set_damain_to_adinfo(4);
    } else {
      fct_out.mutable_drive_assist_to_adhmi()->set_damain_to_adinfo(0);
    }

    fct_out.mutable_reserved()->Clear();

    uint8_t      camera_frntnarrowsts                = 0;
    static float timer_camera_frntnarrowsts_calerror = 0;
    bool         flag_camera_frntnarrowsts_calerrorr = cam_fim.fn_adc_fim_info.FIM_FN_Camera_Cal_Error;
    flag_camera_frntnarrowsts_calerrorr =
      turnon_delay(flag_camera_frntnarrowsts_calerrorr, timer_camera_frntnarrowsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_frntnarrowsts_linkerror = 0;
    bool         flag_camera_frntnarrowsts_linkerror  = cam_fim.fn_adc_fim_info.FIM_FNPhysicalLinkage_Error;
    flag_camera_frntnarrowsts_linkerror =
      turnon_delay(flag_camera_frntnarrowsts_linkerror, timer_camera_frntnarrowsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_frntnarrowsts_outcal = 0;
    bool         flag_camera_frntnarrowsts_outcal  = (0 != ((gFNFailsafe.high >> 9) & 0x01));
    flag_camera_frntnarrowsts_outcal =
      turnon_delay(flag_camera_frntnarrowsts_outcal, timer_camera_frntnarrowsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_frntnarrowsts_block = 0;
    bool         flag_camera_frntnarrowsts_block =
      ((0 != ((gFNFailsafe.high >> 3) & 0x01)) || (0 != ((gFNFailsafe.high >> 4) & 0x01)));
    flag_camera_frntnarrowsts_block =
      turnon_delay(flag_camera_frntnarrowsts_block, timer_camera_frntnarrowsts_block, kplatform_debouceTime_s);
    if (flag_camera_frntnarrowsts_calerrorr) {
      camera_frntnarrowsts = 6;
    } else if (flag_camera_frntnarrowsts_outcal) {
      camera_frntnarrowsts = 5;
    } else if (flag_camera_frntnarrowsts_linkerror) {
      camera_frntnarrowsts = 4;
    } else if (flag_camera_frntnarrowsts_block) {
      camera_frntnarrowsts = 2;
    } else {
      camera_frntnarrowsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_frntnarrowsts));  // 0

    uint8_t      camera_frntwidests                = 0;
    static float timer_camera_frntwidests_calerror = 0;
    bool         flag_camera_frntwidests_calerror  = cam_fim.fw_adc_fim_info.FIM_FW_Camera_Cal_Error;
    flag_camera_frntwidests_calerror =
      turnon_delay(flag_camera_frntwidests_calerror, timer_camera_frntwidests_calerror, kplatform_debouceTime_s);
    static float timer_camera_frntwidests_linkerror = 0;
    bool         flag_camera_frntwidests_linkerror  = cam_fim.fw_adc_fim_info.FIM_FWPhysicalLinkage_Error;
    flag_camera_frntwidests_linkerror =
      turnon_delay(flag_camera_frntwidests_linkerror, timer_camera_frntwidests_linkerror, kplatform_debouceTime_s);
    static float timer_camera_frntwidests_outcal = 0;
    bool         flag_camera_frntwidests_outcal  = (0 != ((gFWFailsafe.high >> 9) & 0x01));
    flag_camera_frntwidests_outcal =
      turnon_delay(flag_camera_frntwidests_outcal, timer_camera_frntwidests_outcal, kplatform_debouceTime_s);
    static float timer_camera_frntwidests_block = 0;
    bool         flag_camera_frntwidests_block =
      ((0 != ((gFWFailsafe.high >> 3) & 0x01)) || (0 != ((gFWFailsafe.high >> 4) & 0x01)));
    flag_camera_frntwidests_block =
      turnon_delay(flag_camera_frntwidests_block, timer_camera_frntwidests_block, kplatform_debouceTime_s);
    if (flag_camera_frntwidests_calerror) {
      camera_frntwidests = 6;
    } else if (flag_camera_frntwidests_outcal) {
      camera_frntwidests = 5;
    } else if (flag_camera_frntwidests_linkerror) {
      camera_frntwidests = 4;
    } else if (flag_camera_frntwidests_block) {
      camera_frntwidests = 2;
    } else {
      camera_frntwidests = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_frntwidests));  // 1

    uint8_t      camera_sidefrntlests             = 0;
    static float timer_camera_sidefrntlests_calerror = 0;
    bool         flag_camera_sidefrntlests_calerror  = cam_fim.sidefl_adc_fim_info.FIM_FL_Camera_Cal_Error;
    flag_camera_sidefrntlests_calerror =
      turnon_delay(flag_camera_sidefrntlests_calerror, timer_camera_sidefrntlests_calerror, kplatform_debouceTime_s);
    static float timer_camera_sidefrntlests_linkerror = 0;
    bool         flag_camera_sidefrntlests_linkerror  = cam_fim.sidefl_adc_fim_info.FIM_SideFLPhysicalLinkage_Error;
    flag_camera_sidefrntlests_linkerror =
      turnon_delay(flag_camera_sidefrntlests_linkerror, timer_camera_sidefrntlests_linkerror, kplatform_debouceTime_s);
    static float timer_camera_sidefrntlests_outcal = 0;
    bool         flag_camera_sidefrntlests_outcal  = (0 != ((gFLFailsafe.high >> 9) & 0x01));
    flag_camera_sidefrntlests_outcal =
      turnon_delay(flag_camera_sidefrntlests_outcal, timer_camera_sidefrntlests_outcal, kplatform_debouceTime_s);
    static float timer_camera_sidefrntlests_block = 0;
    bool         flag_camera_sidefrntlests_block =
      ((0 != ((gFLFailsafe.high >> 3) & 0x01)) || (0 != ((gFLFailsafe.high >> 4) & 0x01)));
    flag_camera_sidefrntlests_block =
      turnon_delay(flag_camera_sidefrntlests_block, timer_camera_sidefrntlests_block, kplatform_debouceTime_s);
    if (flag_camera_sidefrntlests_calerror) {
      camera_sidefrntlests = 6;
    } else if (flag_camera_sidefrntlests_outcal) {
      camera_sidefrntlests = 5;
    } else if (flag_camera_sidefrntlests_linkerror) {
      camera_sidefrntlests = 4;
    } else if (flag_camera_sidefrntlests_block) {
      camera_sidefrntlests = 2;
    } else {
      camera_sidefrntlests = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_sidefrntlests));  // 2

    uint8_t      camera_sidefrntrists             = 0;
    static float timer_camera_sidefrntrists_calerror = 0;
    bool         flag_camera_sidefrntrists_calerror  = cam_fim.sidefr_adc_fim_info.FIM_FR_Camera_Cal_Error;
    flag_camera_sidefrntrists_calerror =
      turnon_delay(flag_camera_sidefrntrists_calerror, timer_camera_sidefrntrists_calerror, kplatform_debouceTime_s);
    static float timer_camera_sidefrntrists_linkerror = 0;
    bool         flag_camera_sidefrntrists_linkerror  = cam_fim.sidefr_adc_fim_info.FIM_SideFRPhysicalLinkage_Error;
    flag_camera_sidefrntrists_linkerror =
      turnon_delay(flag_camera_sidefrntrists_linkerror, timer_camera_sidefrntrists_linkerror, kplatform_debouceTime_s);
    static float timer_camera_sidefrntrists_outcal = 0;
    bool         flag_camera_sidefrntrists_outcal  = (0 != ((gFRFailsafe.high >> 9) & 0x01));
    flag_camera_sidefrntrists_outcal =
      turnon_delay(flag_camera_sidefrntrists_outcal, timer_camera_sidefrntrists_outcal, kplatform_debouceTime_s);
    static float timer_camera_sidefrntrists_block = 0;
    bool         flag_camera_sidefrntrists_block =
      ((0 != ((gFRFailsafe.high >> 3) & 0x01)) || (0 != ((gFRFailsafe.high >> 4) & 0x01)));
    flag_camera_sidefrntrists_block =
      turnon_delay(flag_camera_sidefrntrists_block, timer_camera_sidefrntrists_block, kplatform_debouceTime_s);
    if (flag_camera_sidefrntrists_calerror) {
      camera_sidefrntrists = 6;
    } else if (flag_camera_sidefrntrists_outcal) {
      camera_sidefrntrists = 5;
    } else if (flag_camera_sidefrntrists_linkerror) {
      camera_sidefrntrists = 4;
    } else if (flag_camera_sidefrntrists_block) {
      camera_sidefrntrists = 2;
    } else {
      camera_sidefrntrists = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_sidefrntrists));  // 3

    uint8_t      camera_siderelests             = 0;
    static float timer_camera_siderelests_calerror = 0;
    bool         flag_camera_siderelests_calerror  = cam_fim.siderl_adc_fim_info.FIM_RL_Camera_Cal_Error;
    flag_camera_siderelests_calerror =
      turnon_delay(flag_camera_siderelests_calerror, timer_camera_siderelests_calerror, kplatform_debouceTime_s);
    static float timer_camera_siderelests_linkerror = 0;
    bool         flag_camera_siderelests_linkerror  = cam_fim.siderl_adc_fim_info.FIM_SideRLPhysicalLinkage_Error;
    flag_camera_siderelests_linkerror =
      turnon_delay(flag_camera_siderelests_linkerror, timer_camera_siderelests_linkerror, kplatform_debouceTime_s);
    static float timer_camera_siderelests_outcal = 0;
    bool         flag_camera_siderelests_outcal  = (0 != ((gRLFailsafe.high >> 9) & 0x01));
    flag_camera_siderelests_outcal =
      turnon_delay(flag_camera_siderelests_outcal, timer_camera_siderelests_outcal, kplatform_debouceTime_s);
    static float timer_camera_siderelests_block = 0;
    bool         flag_camera_siderelests_block =
      ((0 != ((gRLFailsafe.high >> 3) & 0x01)) || (0 != ((gRLFailsafe.high >> 4) & 0x01)));
    flag_camera_siderelests_block =
      turnon_delay(flag_camera_siderelests_block, timer_camera_siderelests_block, kplatform_debouceTime_s);
    if (flag_camera_siderelests_calerror) {
      camera_siderelests = 6;
    } else if (flag_camera_siderelests_outcal) {
      camera_siderelests = 5;
    } else if (flag_camera_siderelests_linkerror) {
      camera_siderelests = 4;
    } else if (flag_camera_siderelests_block) {
      camera_siderelests = 2;
    } else {
      camera_siderelests = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_siderelests));  // 4

    uint8_t      camera_sidererists             = 0;
    static float timer_camera_sidererists_calerror = 0;
    bool         flag_camera_sidererists_calerror  = cam_fim.siderr_adc_fim_info.FIM_RR_Camera_Cal_Error;
    flag_camera_sidererists_calerror =
      turnon_delay(flag_camera_sidererists_calerror, timer_camera_sidererists_calerror, kplatform_debouceTime_s);
    static float timer_camera_sidererists_linkerror = 0;
    bool         flag_camera_sidererists_linkerror  = cam_fim.siderr_adc_fim_info.FIM_SideRRPhysicalLinkage_Error;
    flag_camera_sidererists_linkerror =
      turnon_delay(flag_camera_sidererists_linkerror, timer_camera_sidererists_linkerror, kplatform_debouceTime_s);
    static float timer_camera_sidererists_outcal = 0;
    bool         flag_camera_sidererists_outcal  = (0 != ((gRRFailsafe.high >> 9) & 0x01));
    flag_camera_sidererists_outcal =
      turnon_delay(flag_camera_sidererists_outcal, timer_camera_sidererists_outcal, kplatform_debouceTime_s);
    static float timer_camera_sidererists_block = 0;
    bool         flag_camera_sidererists_block =
      ((0 != ((gRRFailsafe.high >> 3) & 0x01)) || (0 != ((gRRFailsafe.high >> 4) & 0x01)));
    flag_camera_sidererists_block =
      turnon_delay(flag_camera_sidererists_block, timer_camera_sidererists_block, kplatform_debouceTime_s);
    if (flag_camera_sidererists_calerror) {
      camera_sidererists = 6;
    } else if (flag_camera_sidererists_outcal) {
      camera_sidererists = 5;
    } else if (flag_camera_sidererists_linkerror) {
      camera_sidererists = 4;
    } else if (flag_camera_sidererists_block) {
      camera_sidererists = 2;
    } else {
      camera_sidererists = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_sidererists));  // 5

    uint8_t      camera_rearnarrowsts             = 0;
    static float timer_camera_rearnarrowsts_calerror = 0;
    bool         flag_camera_rearnarrowsts_calerror  = cam_fim.rn_adc_fim_info.FIM_RN_Camera_Cal_Error;
    flag_camera_rearnarrowsts_calerror =
      turnon_delay(flag_camera_rearnarrowsts_calerror, timer_camera_rearnarrowsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_rearnarrowsts_linkerror = 0;
    bool         flag_camera_rearnarrowsts_linkerror  = cam_fim.rn_adc_fim_info.FIM_RNPhysicalLinkage_Error;
    flag_camera_rearnarrowsts_linkerror =
      turnon_delay(flag_camera_rearnarrowsts_linkerror, timer_camera_rearnarrowsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_rearnarrowsts_outcal = 0;
    bool         flag_camera_rearnarrowsts_outcal  = (0 != ((gRrFailsafe.high >> 9) & 0x01));
    flag_camera_rearnarrowsts_outcal =
      turnon_delay(flag_camera_rearnarrowsts_outcal, timer_camera_rearnarrowsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_rearnarrowsts_block = 0;
    bool         flag_camera_rearnarrowsts_block =
      ((0 != ((gRrFailsafe.high >> 3) & 0x01)) || (0 != ((gRrFailsafe.high >> 4) & 0x01)));
    flag_camera_rearnarrowsts_block =
      turnon_delay(flag_camera_rearnarrowsts_block, timer_camera_rearnarrowsts_block, kplatform_debouceTime_s);
    if (flag_camera_rearnarrowsts_calerror) {
      camera_rearnarrowsts = 6;
    } else if (flag_camera_rearnarrowsts_outcal) {
      camera_rearnarrowsts = 5;
    } else if (flag_camera_rearnarrowsts_linkerror) {
      camera_rearnarrowsts = 4;
    } else if (flag_camera_rearnarrowsts_block) {
      camera_rearnarrowsts = 2;
    } else {
      camera_rearnarrowsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_rearnarrowsts));                         // 6
    fct_out.add_reserved(static_cast<double>(HWA_out.LNGCTRL.flgSetspeedChgSrcForNop));  // 7

    fct_out.mutable_function()->Clear();
    auto func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(HWA_out.LNGCTRL.DAFuncSts));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaMain));
    func_info->set_functionname("DaMain");
    if (HWA_out.LNGCTRL.EASFuncSts == Func_Running) {
      func_info->set_reqfunctionid(static_cast<int32_t>(FuncId_e::EAS));
    }
    func_info->set_reqfunctionid(static_cast<int32_t>(HWA_out.HWASM.DAMainReqFuncID));
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(HWA_out.LNGCTRL.EASFuncSts));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::EAS));
    func_info->set_functionname("EAS");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(
      static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(HWA_out.LNGCTRL.DASdcFuncSts));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaSdc));
    func_info->set_functionname("DaSdc");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(
      static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(HWA_out.LNGCTRL.DALccFuncSts));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::DaLcc));
    func_info->set_functionname("DaLcc");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(ELKSS_stElkFAMSts_mp));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::ELK));
    func_info->set_functionname("ELK");
    func_info = fct_out.mutable_function()->Add();
    func_info->set_funcsts(static_cast<nio::ad::messages::FunctionXstatus_FunctionStatus>(AHC_FAMSts));
    func_info->set_functionid(static_cast<int32_t>(FuncId_e::AHB));
    func_info->set_functionname("AHB");
#ifdef OFF_ALL_SAS_OUTPUT
    fct_out.mutable_sas()->set_speedlimitvalue(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_speedunit(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_speedlimitattribute(static_cast<nio::ad::messages::SasOut_SpdLmtAttr_e>(0));
    fct_out.mutable_sas()->set_speedlimittakeover(static_cast<nio::ad::messages::SasOut_SpdLmtTkOv_e>(0));
    fct_out.mutable_sas()->set_supsigntype(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_supsignattribute(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_roadfeaturewarningsign(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_slifstate(static_cast<nio::ad::messages::SasOut_SLIFSts_e>(0));
    fct_out.mutable_sas()->set_slwfwarntrigger(static_cast<nio::ad::messages::SasOut_SLIFWarnTrgSts_e>(0));
    fct_out.mutable_sas()->set_trafficlightsts(static_cast<uint32_t>(0));
    fct_out.mutable_sas()->set_localhazards(static_cast<uint32_t>(0));

#else
    fct_out.mutable_sas()->set_speedlimitvalue(static_cast<uint32_t>(common_proc_info.sas_speed_limit_out_value_trans));
    fct_out.mutable_sas()->set_speedunit(static_cast<uint32_t>(HWA_out.LNGCTRL.ACCCT_iAccSpdLmtUnit));
    fct_out.mutable_sas()->set_speedlimitattribute(
      static_cast<nio::ad::messages::SasOut_SpdLmtAttr_e>(sas_func_out.sas_spd_lmt_attr));
    fct_out.mutable_sas()->set_speedlimittakeover(
      static_cast<nio::ad::messages::SasOut_SpdLmtTkOv_e>(common_proc_info.iacc_take_over_pop));
    fct_out.mutable_sas()->set_supsigntype(static_cast<uint32_t>(sas_func_out.sas_spd_lmt_sup_sign_type));
    fct_out.mutable_sas()->set_supsignattribute(static_cast<uint32_t>(sas_func_out.sas_spd_lmt_sup_sign_attr));
    fct_out.mutable_sas()->set_slifstate(
      static_cast<nio::ad::messages::SasOut_SLIFSts_e>(sas_func_out.sas_slif_state));
    fct_out.mutable_sas()->set_slwfwarntrigger(
      static_cast<nio::ad::messages::SasOut_SLIFWarnTrgSts_e>(sas_func_out.sas_slwf_warn_level));
    fct_out.mutable_sas()->set_roadfeaturewarningsign(static_cast<uint32_t>(sas_func_out.sas_road_feature_warn_sign));
    fct_out.mutable_sas()->set_trafficlightsts(static_cast<uint32_t>(sas_func_out.sas_traffic_light_sts));
    // Temp implement. Redo it after sas architecture finished by @fangtao.
    fct_out.mutable_sas()->set_localhazards(static_cast<uint32_t>(LKS_LCA_out.SasLocalHzrdsEUCA));

#endif
    fct_esd_output_processing(fct_out);
    if (HWA_out.HWASM.NadSts != 9) {
      fct_out.mutable_latctrl()->set_latctrltarle(
        static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(LKS_LCA_out.LatCtrlTarLe));
      fct_out.mutable_latctrl()->set_latctrltarri(
        static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(LKS_LCA_out.LatCtrlTarRi));
      fct_out.mutable_lonctrl()->set_objvalid(HWA_out.LNGCTRL.LongCtrl_ObjValid);
      fct_out.mutable_hwa()->set_da_nop_avl(static_cast<nio::ad::messages::HwaOut_DA_NOP_Avl_e>(
        HWA_out.HWASM.DANOPAvl));  // Index:3 HWA_out.HWASM.ShowSetDA_DANOPAvl
      // fct_out.mutable_reserved()->Clear();
      // fct_out.add_reserved(static_cast<double>(0));  // Index:0 HWA_out.HWASM.ShowSetDA_NOP
      // fct_out.add_reserved(static_cast<double>(0));  // Index:1 HWA_out.HWASM.ShowSwtichDA_NOP
      fct_out.add_reserved(
        // static_cast<uint32_t>(LKS_LCA_out.ShowSetDA_NOPALC));  // 8  Index:2 LKS_LCA_out.ShowSetDA_NOPALC
        static_cast<uint32_t>(LKS_LCA_out.ShowSetDA_ALCS_EU)); //8  Index:2 LKS_LCA_out.ShowSetDA_ALCS_EU
      // fct_out.add_reserved(static_cast<double>(0));  // Index:3 HWA_out.HWASM.ShowSetDA_DANOPAvl
    } else {
      fct_out.mutable_latctrl()->set_latctrltarle(
        static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(HWA_out.HWASM.NOPLatCtrlTarLe));
      fct_out.mutable_latctrl()->set_latctrltarri(
        static_cast<nio::ad::messages::LatCtrlOut_LatCtrlTar_e>(HWA_out.HWASM.NOPLatCtrlTarRi));
      fct_out.mutable_lonctrl()->set_objvalid(HWA_out.HWASM.NOPLongCtrlTar);
      // fct_out.mutable_reserved()->Clear();
      // fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.ShowSetDA_NOP));
      // fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.ShowSwtichDA_NOP));
      // fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.ShowSetDA_NOPALC));
      fct_out.add_reserved(static_cast<double>(0));   //8
      // fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.DANOPAvl));
      fct_out.mutable_hwa()->set_da_nop_avl(static_cast<nio::ad::messages::HwaOut_DA_NOP_Avl_e>(
        HWA_out.HWASM.DANOPAvl));  // Index:3 HWA_out.HWASM.ShowSetDA_DANOPAvl
    }
    fct_out.add_reserved(static_cast<double>(common_proc_info.setspeed_decel_mode));  // 9
    fct_out.add_reserved(static_cast<double>(HWA_out.LNGCTRL.flgRainModeSetting));    // 10
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.VLCLLCSts));               // 11
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.LLCReqFctSt));             // 12
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.LLCShutdownModReq));       // 13

    fct_out.add_reserved(static_cast<double>(da_statemachine_adapter.getDAPSPAvl())); // 14
    fct_out.add_reserved(static_cast<double>(MainState_info.PSP_DAmain_MRMongoing));  // 15
    fct_out.add_reserved(static_cast<double>(MainState_info.PSP_PNC_MRMongoing));     // 16
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.DA_PSP_WTIs));             // 17
    fct_out.add_reserved(static_cast<double>(MainState_info.ShowSwtichDA_NOP));       // 18

    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.EPSHviReq));               // 19

    uint8_t      camera_svcfrntsts             = 0;
    static float timer_camera_svcfrntsts_calerror = 0;
    bool         flag_camera_svcfrntsts_calerror  = cam_fim.svcfront_adc_fim_info.FIM_SVCFront_Camera_Cal_Error;
    flag_camera_svcfrntsts_calerror =
      turnon_delay(flag_camera_svcfrntsts_calerror, timer_camera_svcfrntsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_svcfrntsts_linkerror = 0;
    bool         flag_camera_svcfrntsts_linkerror  = cam_fim.svcfront_adc_fim_info.FIM_SVCFrontPhysicalLinkage_Error;
    flag_camera_svcfrntsts_linkerror =
      turnon_delay(flag_camera_svcfrntsts_linkerror, timer_camera_svcfrntsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_svcfrntsts_outcal = 0;
    bool         flag_camera_svcfrntsts_outcal  = (0 != ((gSVCFtFailsafe.high >> 9) & 0x01));
    flag_camera_svcfrntsts_outcal =
      turnon_delay(flag_camera_svcfrntsts_outcal, timer_camera_svcfrntsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_svcfrntsts_block = 0;
    bool         flag_camera_svcfrntsts_block =
      ((0 != ((gSVCFtFailsafe.high >> 3) & 0x01)) || (0 != ((gSVCFtFailsafe.high >> 4) & 0x01)));
    flag_camera_svcfrntsts_block =
      turnon_delay(flag_camera_svcfrntsts_block, timer_camera_svcfrntsts_block, kplatform_debouceTime_s);
    if (flag_camera_svcfrntsts_calerror) {
      camera_svcfrntsts = 6;
    } else if (flag_camera_svcfrntsts_outcal) {
      camera_svcfrntsts = 5;
    } else if (flag_camera_svcfrntsts_linkerror) {
      camera_svcfrntsts = 4;
    } else if (flag_camera_svcfrntsts_block) {
      camera_svcfrntsts = 2;
    } else {
      camera_svcfrntsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_svcfrntsts));                         // 20

    uint8_t      camera_svcrearsts             = 0;
    static float timer_camera_svcrearsts_calerror = 0;
    bool         flag_camera_svcrearsts_calerror  = cam_fim.svcrear_adc_fim_info.FIM_SVCRear_Camera_Cal_Error;
    flag_camera_svcrearsts_calerror =
      turnon_delay(flag_camera_svcrearsts_calerror, timer_camera_svcrearsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_svcrearsts_linkerror = 0;
    bool         flag_camera_svcrearsts_linkerror  = cam_fim.svcrear_adc_fim_info.FIM_SVCRearPhysicalLinkage_Error;
    flag_camera_svcrearsts_linkerror =
      turnon_delay(flag_camera_svcrearsts_linkerror, timer_camera_svcrearsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_svcrearsts_outcal = 0;
    bool         flag_camera_svcrearsts_outcal  = (0 != ((gSVCRrFailsafe.high >> 9) & 0x01));
    flag_camera_svcrearsts_outcal =
      turnon_delay(flag_camera_svcrearsts_outcal, timer_camera_svcrearsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_svcrearsts_block = 0;
    bool         flag_camera_svcrearsts_block =
      ((0 != ((gSVCRrFailsafe.high >> 3) & 0x01)) || (0 != ((gSVCRrFailsafe.high >> 4) & 0x01)));
    flag_camera_svcrearsts_block =
      turnon_delay(flag_camera_svcrearsts_block, timer_camera_svcrearsts_block, kplatform_debouceTime_s);
    if (flag_camera_svcrearsts_calerror) {
      camera_svcrearsts = 6;
    } else if (flag_camera_svcrearsts_outcal) {
      camera_svcrearsts = 5;
    } else if (flag_camera_svcrearsts_linkerror) {
      camera_svcrearsts = 4;
    } else if (flag_camera_svcrearsts_block) {
      camera_svcrearsts = 2;
    } else {
      camera_svcrearsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_svcrearsts));                         // 21

    uint8_t      camera_svcleftsts             = 0;
    static float timer_camera_svcleftsts_calerror = 0;
    bool         flag_camera_svcleftsts_calerror  = cam_fim.svcleft_adc_fim_info.FIM_SVCLeft_Camera_Cal_Error;
    flag_camera_svcleftsts_calerror =
      turnon_delay(flag_camera_svcleftsts_calerror, timer_camera_svcleftsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_svcleftsts_linkerror = 0;
    bool         flag_camera_svcleftsts_linkerror  = cam_fim.svcleft_adc_fim_info.FIM_SVCLeftPhysicalLinkage_Error;
    flag_camera_svcleftsts_linkerror =
      turnon_delay(flag_camera_svcleftsts_linkerror, timer_camera_svcleftsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_svcleftsts_outcal = 0;
    bool         flag_camera_svcleftsts_outcal  = (0 != ((gSVCLftFailsafe.high >> 9) & 0x01));
    flag_camera_svcleftsts_outcal =
      turnon_delay(flag_camera_svcleftsts_outcal, timer_camera_svcleftsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_svcleftsts_block = 0;
    bool         flag_camera_svcleftsts_block =
      ((0 != ((gSVCLftFailsafe.high >> 3) & 0x01)) || (0 != ((gSVCLftFailsafe.high >> 4) & 0x01)));
    flag_camera_svcleftsts_block =
      turnon_delay(flag_camera_svcleftsts_block, timer_camera_svcleftsts_block, kplatform_debouceTime_s);
    if (flag_camera_svcleftsts_calerror) {
      camera_svcleftsts = 6;
    } else if (flag_camera_svcleftsts_outcal) {
      camera_svcleftsts = 5;
    } else if (flag_camera_svcleftsts_linkerror) {
      camera_svcleftsts = 4;
    } else if (flag_camera_svcleftsts_block) {
      camera_svcleftsts = 2;
    } else {
      camera_svcleftsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_svcleftsts));                         // 22

    uint8_t      camera_svcrightsts             = 0;
    static float timer_camera_svcrightsts_calerror = 0;
    bool         flag_camera_svcrightsts_calerror  = cam_fim.svcright_adc_fim_info.FIM_SVCRight_Camera_Cal_Error;
    flag_camera_svcrightsts_calerror =
      turnon_delay(flag_camera_svcrightsts_calerror, timer_camera_svcrightsts_calerror, kplatform_debouceTime_s);
    static float timer_camera_svcrightsts_linkerror = 0;
    bool         flag_camera_svcrightsts_linkerror  = cam_fim.svcright_adc_fim_info.FIM_SVCRightPhysicalLinkage_Error;
    flag_camera_svcrightsts_linkerror =
      turnon_delay(flag_camera_svcrightsts_linkerror, timer_camera_svcrightsts_linkerror, kplatform_debouceTime_s);
    static float timer_camera_svcrightsts_outcal = 0;
    bool         flag_camera_svcrightsts_outcal  = (0 != ((gSVCRgtFailsafe.high >> 9) & 0x01));
    flag_camera_svcrightsts_outcal =
      turnon_delay(flag_camera_svcrightsts_outcal, timer_camera_svcrightsts_outcal, kplatform_debouceTime_s);
    static float timer_camera_svcrightsts_block = 0;
    bool         flag_camera_svcrightsts_block =
      ((0 != ((gSVCRgtFailsafe.high >> 3) & 0x01)) || (0 != ((gSVCRgtFailsafe.high >> 4) & 0x01)));
    flag_camera_svcrightsts_block =
      turnon_delay(flag_camera_svcrightsts_block, timer_camera_svcrightsts_block, kplatform_debouceTime_s);
    if (flag_camera_svcrightsts_calerror) {
      camera_svcrightsts = 6;
    } else if (flag_camera_svcrightsts_outcal) {
      camera_svcrightsts = 5;
    } else if (flag_camera_svcrightsts_linkerror) {
      camera_svcrightsts = 4;
    } else if (flag_camera_svcrightsts_block) {
      camera_svcrightsts = 2;
    } else {
      camera_svcrightsts = 0;
    }
    fct_out.add_reserved(static_cast<double>(camera_svcrightsts));                         // 23

    uint8_t      imusts             = 0;
    static float timer_imusts_temporaryerror = 0;
    bool         flag_imusts_temporaryerror = perception_fim.fim_imu_hw_temporary_error;
    flag_imusts_temporaryerror =
      turnon_delay(flag_imusts_temporaryerror, timer_imusts_temporaryerror, kplatform_debouceTime_s);
    static float timer_imusts_perpetualerror = 0;
    bool         flag_imusts_perpetualerror  = perception_fim.fim_imu_hw_perpetual_error;
    flag_imusts_perpetualerror =
      turnon_delay(flag_imusts_perpetualerror, timer_imusts_perpetualerror, kplatform_debouceTime_s);
    if (flag_imusts_perpetualerror) {
      imusts = 2;
    } else if (flag_imusts_temporaryerror) {
      imusts = 1;
    } else {
      imusts = 0;
    }
    fct_out.add_reserved(static_cast<double>(imusts));                         // 24
    fct_out.add_reserved(static_cast<double>(LKS_LCA_out.StrIFReq));           // 25
    bool is_nad_urban = false;
    if ((0 != danop_sm.priority_road_class && 1 != danop_sm.priority_road_class) &&
        (11 == HWA_out.HWASM.NadSts)) {
      is_nad_urban = true;
    }
    fct_out.add_reserved(static_cast<double>(is_nad_urban));                   // 26
    fct_out.add_reserved(static_cast<double>(da_statemachine_adapter.getDAiACCAvl()));    // 27
    fct_out.add_reserved(static_cast<double>(da_statemachine_adapter.getDAPilotAvl()));   // 28
    fct_out.add_reserved(static_cast<double>(da_statemachine_adapter.getDANADAvl()));     // 29
    fct_out.add_reserved(static_cast<double>(da_statemachine_adapter.getDANOPAvl()));     // 30
    fct_out.add_reserved(static_cast<double>(MainState_info.psp_softbutton_aval));           // 31
    fct_out.add_reserved(static_cast<double>(HWA_out.HWASM.DA_PSP_WTI3));                 // 32
    fct_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getPSPGeofence()));    //33
  }
}

void fct_nopFuncStatus_output_processing(DAStateMachineAdapter* dastatemachine_adapter, APP_state_e APP_state,
                                         std::shared_ptr<planner::IOAdapter>& ioadapter) {
  dastatemachine_adapter->setioadapter(ioadapter);
  if ((APP_state == APP_state_e::Suspend) || (APP_state == APP_state_e::Failure)) {
    ioadapter->getMidOutputManager().setFuncStatus(proto::FunctionRequest::REQ_OFF);
    ioadapter->getMidOutputManager().setPSPFuncReq(proto::FunctionRequest::REQ_OFF);
  } else {
    dastatemachine_adapter->proc_nop_funcStatus(MainState_info,da_sm_info,ioadapter);
    dastatemachine_adapter->proc_psp_funcStatus(MainState_info,da_sm_info);
    dastatemachine_adapter->fct_outputNopFuncStatus(ioadapter);
    dastatemachine_adapter->fct_outputPSPFuncStatus(ioadapter);
    dastatemachine_adapter->processDANBCAvlStatus(MainState_info, da_sm_info, veh_drvr, func_arb);
  }
}

void fct_user_interface_fill(std::shared_ptr<planner::IOAdapter>& ioadapter, APP_state_e APP_state) {
  if ((APP_state == APP_state_e::Suspend) || (APP_state == APP_state_e::Failure)) {
    // 异常情况处理
    ioadapter->getMidOutputManager().setNopRainMode(false);
    ioadapter->getFinalOutputManager().final_output_msg.set_reference_tau_gap_req(1.0f);
  }
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
