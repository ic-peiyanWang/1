#include "fct_debug_out_proc.h"
#include "ELKCore.h"
#include "HWA.h"
#include "LCACore.h"
#include "LDW.h"
#include "LKACore.h"
#include "LKSCore.h"
#include "LKS_LCA.h"
#include "LongCtrl.h"
#include "MainState.h"
#include "basics/log_utils.h"
#include "fct_dastatemachine_adapter.h"
#include "fct_diag.h"
#include "fct_diag_interface.h"
#include "fct_diag_param.h"
#include "fct_dummy_meas.h"
#include "fct_me_param.h"
#include "fct_user_interface_proc.h"
#include "go_notifier.h"
#include "ids_mil.h"
#include "planner/io_manager/io_adapter.h"
#include "fct_in_proc.h"
#include "fct_input_adapter.h"

namespace nio {
namespace ad {
namespace fctapp {

const float                    kHeroButtonTrigDelayTime_s = 1.0f;
const float                    kFctStepTime               = 0.05f;
nio::planner::SpeedDebugInfo   speed_debug_info;
nio::planner::TauGapProcessOut tau_gap_out;
nio::planner::StateMachineEvent sm_debug_info;

void accsa_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_avmclgtacccp_mp(static_cast<double>(ACCSA_aVMCLgtAccCp_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_avmclgtdeccp_mp(static_cast<double>(ACCSA_aVMCLgtDecCp_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_flgabsactv_mp(static_cast<bool>(ACCSA_flgAbsActv_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_idxlnspdlimidc_mp(static_cast<uint32_t>(ACCSA_idxLnSpdLimIdC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_idxlnspdlimidnn_mp(
    static_cast<uint32_t>(ACCSA_idxLnSpdLimIdNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_idxlnspdlimidn_mp(static_cast<uint32_t>(ACCSA_idxLnSpdLimIdN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_kphlnspdlimc_mp(static_cast<double>(ACCSA_kphLnSpdLimC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_kphlnspdlimnn_mp(static_cast<double>(ACCSA_kphLnSpdLimNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_kphlnspdlimn_mp(static_cast<double>(ACCSA_kphLnSpdLimN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlngptypec_mp(static_cast<uint32_t>(ACCSA_mLnGpTypeC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlngptypenn_mp(static_cast<uint32_t>(ACCSA_mLnGpTypeNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlngptypen_mp(static_cast<uint32_t>(ACCSA_mLnGpTypeN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlnspdlimdistc_mp(static_cast<double>(ACCSA_mLnSpdLimDistC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlnspdlimdistnn_mp(static_cast<double>(ACCSA_mLnSpdLimDistNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mlnspdlimdistn_mp(static_cast<double>(ACCSA_mLnSpdLimDistN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_mpsslgtacc_mp(static_cast<double>(ACCSA_mpssLgtAcc_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nabigation_state_mp(
    static_cast<uint32_t>(ACCSA_nabigation_state_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_colllision_risk_mp(
    static_cast<double>(ACCSA_nop_colllision_risk_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_freespace_intrusion_go_notifier_mp(
    static_cast<double>(ACCSA_nop_freeSpace_intrusion_go_notifier_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_freespaceintrusionatstandstill_mp(
    static_cast<double>(ACCSA_nop_freespaceintrusionatstandstill_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_lat_ctrl_tarle_mp(
    static_cast<uint32_t>(ACCSA_nop_lat_ctrl_tarLe_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_lat_ctrl_tarri_mp(
    static_cast<uint32_t>(ACCSA_nop_lat_ctrl_tarRi_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_long_ctrl_tar_mp(
    static_cast<uint32_t>(ACCSA_nop_long_ctrl_tar_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_sldf_state_mp(static_cast<uint32_t>(ACCSA_nop_sldf_state_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_spdlimt_supsigntype_mp(
    static_cast<uint32_t>(ACCSA_nop_spdlimt_supsignType_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_spdlmt_unit_mp(
    static_cast<uint32_t>(ACCSA_nop_spdlmt_unit_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_spdlmt_value_mp(
    static_cast<uint32_t>(ACCSA_nop_spdlmt_value_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_turn_indicator_req_mp(
    static_cast<uint32_t>(ACCSA_nop_turn_indicator_req_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_nop_vlc_frive_off_req_mp(
    static_cast<bool>(ACCSA_nop_vlc_frive_off_req_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_numfam_id10_mp(static_cast<uint32_t>(ACCSA_numFAM_ID10_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_numfam_id1_mp(static_cast<uint32_t>(ACCSA_numFAM_ID1_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_numfam_id7_mp(static_cast<uint32_t>(ACCSA_numFAM_ID7_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_reliable_state_mp(static_cast<uint32_t>(ACCSA_reliable_state_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_seg0formofway_state_mp(
    static_cast<uint32_t>(ACCSA_seg0formofway_state_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_seg0offset_state_mp(
    static_cast<uint32_t>(ACCSA_seg0offset_state_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stfam_req10_mp(static_cast<uint32_t>(ACCSA_stFAM_Req10_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stfam_req1_mp(static_cast<uint32_t>(ACCSA_stFAM_Req1_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stfam_req7_mp(static_cast<uint32_t>(ACCSA_stFAM_Req7_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimconfc_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimConfC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimconfnn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimConfNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimconfn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimConfN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsrcc_mp(static_cast<uint32_t>(ACCSA_stLnSpdLimSrcC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsrcnn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSrcNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsrcn_mp(static_cast<uint32_t>(ACCSA_stLnSpdLimSrcN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsignattrc_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignAttrC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsignattrnn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignAttrNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsignattrn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignAttrN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsigntypec_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignTypeC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsigntypenn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignTypeNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimsupsigntypen_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimSupSignTypeN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimunitc_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimUnitC_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimunitnn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimUnitNN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stlnspdlimunitn_mp(
    static_cast<uint32_t>(ACCSA_stLnSpdLimUnitN_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stspddecbtn_mp(static_cast<double>(ACCSA_stSpdDecBtn_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_stspdincbtn_mp(static_cast<double>(ACCSA_stSpdIncBtn_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_ufcc1lgtsts_mp(static_cast<uint32_t>(ACCSA_uFCC1LgtSts_mp));
  fct_debug_out.mutable_accsa_debug_out()->set_accsa_uvmclgtsts_mp(static_cast<uint32_t>(ACCSA_uVMCLgtSts_mp));
}

void accct_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_accct_debug_out()->set_accct_accaccrsts_mp(static_cast<uint32_t>(ACCCT_ACCAccrSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_accct_tiactive_mp(static_cast<double>(ACCCT_ACCCT_tiActive_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_accdecelvis_mp(static_cast<uint32_t>(ACCCT_ACCDecelVis_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_accnpdrivermsg_mp(static_cast<uint32_t>(ACCCT_ACCNPDriverMsg_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_brkpreferredreq_mp(
    static_cast<uint32_t>(ACCCT_BrkPreferredReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_clsobjdst_mp(static_cast<float>(ACCCT_ClsObjDst_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_clsobjtyp_mp(static_cast<uint32_t>(ACCCT_ClsObjTyp_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_cmftlowra_mp(static_cast<float>(ACCCT_CmftLowrA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_cmftuppra_mp(static_cast<float>(ACCCT_CmftUpprA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_deceltostopreq_mp(static_cast<uint32_t>(ACCCT_DecelToStopReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_displayvelocityset_mp(
    static_cast<float>(ACCCT_DisplayVelocitySet_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_drvoffreq_mp(static_cast<uint32_t>(ACCCT_DrvOffReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_gonotifieronoffsts_mp(
    static_cast<uint32_t>(ACCCT_GoNotifierOnOffSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_gonotifierreq_mp(static_cast<uint32_t>(ACCCT_GoNotifierReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_headwayaccelraw2_mp(
    static_cast<double>(ACCCT_HeadwayAccelRaw2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_headwayaccelraw_mp(static_cast<double>(ACCCT_HeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_isamodests_mp(static_cast<uint32_t>(ACCCT_ISAModeSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_isaspdalert_mp(static_cast<uint32_t>(ACCCT_ISASpdAlert_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_isaspdcfmreq_mp(static_cast<uint32_t>(ACCCT_ISASpdCfmReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_maxjerka_mp(static_cast<float>(ACCCT_MaxJerkA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_minbrkgreq_mp(static_cast<uint32_t>(ACCCT_MinBrkgReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_minjerka_mp(static_cast<float>(ACCCT_MinJerkA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_modeesp_mp(static_cast<uint32_t>(ACCCT_ModeESP_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_nopcipvsftyreqactv_mp(
    static_cast<bool>(ACCCT_NopCIPVSftyReqActv_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgavlaccel_mp(static_cast<float>(ACCCT_NopLnChgAvlAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgavldecel_mp(static_cast<float>(ACCCT_NopLnChgAvlDecel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgjerklimacc_mp(
    static_cast<float>(ACCCT_NopLnChgJerkLimAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgjerklimdec_mp(
    static_cast<float>(ACCCT_NopLnChgJerkLimDec_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgleavlaccel_mp(
    static_cast<float>(ACCCT_NopLnChgLeAvlAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgleavldecel_mp(
    static_cast<float>(ACCCT_NopLnChgLeAvlDecel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgriavlaccel_mp(
    static_cast<float>(ACCCT_NopLnChgRiAvlAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_noplnchgriavldecel_mp(
    static_cast<float>(ACCCT_NopLnChgRiAvlDecel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_objvalid_mp(static_cast<uint32_t>(ACCCT_ObjValid_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ovtklfttaraddaccfac_mp(
    static_cast<double>(ACCCT_OvtkLftTarAddAccFac_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ovtkmntaraddaccfac_mp(
    static_cast<double>(ACCCT_OvtkMnTarAddAccFac_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ovtkmntartotalaccfac_mp(
    static_cast<double>(ACCCT_OvtkMnTarTotalAccFac_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ovtksideobjindex_mp(
    static_cast<uint32_t>(ACCCT_OvtkSideObjIndex_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ovtksideobjvalid_mp(static_cast<bool>(ACCCT_OvtkSideObjValid_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_shutdownmodreq_mp(static_cast<uint32_t>(ACCCT_ShutdownModReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tsroperatingsts_mp(
    static_cast<uint32_t>(ACCCT_TSROperatingSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tsrspdlimdataonoffsts_mp(
    static_cast<uint32_t>(ACCCT_TSRSpdLimDataOnOffSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tsrspdlimunit_mp(static_cast<uint32_t>(ACCCT_TSRSpdLimUnit_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tsrspdlim_mp(static_cast<uint32_t>(ACCCT_TSRSpdLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_takeoverreq_mp(static_cast<uint32_t>(ACCCT_TakeOverReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_targetaccel_mp(static_cast<float>(ACCCT_TargetAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_taugapset_mp(static_cast<uint32_t>(ACCCT_TauGapSet_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_textinfo_mp(static_cast<uint32_t>(ACCCT_TextInfo_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_timegap_mp(static_cast<float>(ACCCT_TimeGap_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_undtktar1headwayaccelraw_mp(
    static_cast<double>(ACCCT_UndtkTar1HeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_undtktarcipvheadwayaccelraw_mp(
    static_cast<double>(ACCCT_UndtkTarCipvHeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_undtktarn1headwayaccelraw_mp(
    static_cast<double>(ACCCT_UndtkTarN1HeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_undtktarn2headwayaccelraw_mp(
    static_cast<double>(ACCCT_UndtkTarN2HeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_undtktarn3headwayaccelraw_mp(
    static_cast<double>(ACCCT_UndtkTarN3HeadwayAccelRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_aegotaraccel_mp(static_cast<double>(ACCCT_aEgoTaraccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_alfttaracc_mp(static_cast<double>(ACCCT_aLftTarAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_alfttarneededdlc_mp(
    static_cast<double>(ACCCT_aLftTarNeededDlc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_alfttarovrtaccraw_mp(
    static_cast<double>(ACCCT_aLftTarOvrtAccRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_alfttarrawaccflt_mp(
    static_cast<double>(ACCCT_aLftTarRawAccFlt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_alfttarrglaccflt_mp(
    static_cast<double>(ACCCT_aLftTarRglAccFlt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_amntarnrmaccraw_mp(static_cast<double>(ACCCT_aMnTarNrmAccRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_amntarnrmacc_mp(static_cast<double>(ACCCT_aMnTarNrmAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_amntarovrtaccraw_mp(
    static_cast<double>(ACCCT_aMnTarOvrtAccRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_amntarovrtkacc_mp(static_cast<double>(ACCCT_aMnTarOvrtkAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_aovrtklftaphaccbias_mp(
    static_cast<double>(ACCCT_aOvrtkLftAphAccBias_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_aovrtkmnaphaccbias_mp(
    static_cast<double>(ACCCT_aOvrtkMnAphAccBias_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_aovrtkrawacc_mp(static_cast<double>(ACCCT_aOvrtkRawAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_aovrtkrhtaphaccbias_mp(
    static_cast<double>(ACCCT_aOvrtkRhtAphAccBias_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_arhttaracc_mp(static_cast<double>(ACCCT_aRhtTarAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_arhttarneededdlc_mp(
    static_cast<double>(ACCCT_aRhtTarNeededDlc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_arhttarovrtaccraw_mp(
    static_cast<double>(ACCCT_aRhtTarOvrtAccRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_bflongctrlaccsrc_mp(
    static_cast<uint32_t>(ACCCT_bfLongCtrlACCSrc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_degrltstrwhlagwithdir_mp(
    static_cast<double>(ACCCT_degRltStrWhlAgwithDir_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facaccmaxsettingsgain_mp(
    static_cast<double>(ACCCT_facAccMaxSettingsGain_mp));
  fct_debug_out.mutable_accct_debug_out()->add_accct_faccipvreqwght_mp(static_cast<float>(ACCCT_facCIPVReqWght_mp[0]));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccctransgain_mp(static_cast<double>(ACCCT_facCcTransGain_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccur4expangle_mp(static_cast<double>(ACCCT_facCur4ExpAngle_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccurveaccellimit_mp(
    static_cast<double>(ACCCT_facCurveAccelLimit_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstatea0_mp(
    static_cast<double>(ACCCT_facCutInPlanStateA0_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstatea1_mp(
    static_cast<double>(ACCCT_facCutInPlanStateA1_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstates0_mp(
    static_cast<double>(ACCCT_facCutInPlanStateS0_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstates1_mp(
    static_cast<double>(ACCCT_facCutInPlanStateS1_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstatev0_mp(
    static_cast<double>(ACCCT_facCutInPlanStateV0_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplanstatev1_mp(
    static_cast<double>(ACCCT_facCutInPlanStateV1_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja0_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA0_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja1_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA1_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja2_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja3_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA3_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja4_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA4_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_faccutinplantraja5_mp(
    static_cast<double>(ACCCT_facCutInPlanTrajA5_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facdeccomflim_mp(static_cast<double>(ACCCT_facDecComfLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facfuzzyaccfactor2_mp(
    static_cast<double>(ACCCT_facFuzzyAccFactor2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facfuzzyaccfactor_mp(
    static_cast<double>(ACCCT_facFuzzyAccFactor_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facfuzzydecfactor2_mp(
    static_cast<double>(ACCCT_facFuzzyDecFactor2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facfuzzydecfactor_mp(
    static_cast<double>(ACCCT_facFuzzyDecFactor_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facinccomflim_mp(static_cast<double>(ACCCT_facIncComfLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facovrtkaccarbtrgtratio_mp(
    static_cast<double>(ACCCT_facOvrtkACCArbTrgtRatio_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facovrtklfttarctrlwghtforapph_mp(
    static_cast<double>(ACCCT_facOvrtkLftTarCtrlWghtForApph_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facovrtklfttarctrlwghtforhld_mp(
    static_cast<double>(ACCCT_facOvrtkLftTarCtrlWghtForHld_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_facovrtklfttarctrlwghtforstr_mp(
    static_cast<double>(ACCCT_facOvrtkLftTarCtrlWghtForStr_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgaccstupcmfadapt_mp(
    static_cast<bool>(ACCCT_flgAccStUpCmfAdapt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgactivationdenied_mp(
    static_cast<bool>(ACCCT_flgActivationDenied_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgactive2passive_mp(
    static_cast<bool>(ACCCT_flgActive2Passive_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgactive2standy_mp(static_cast<bool>(ACCCT_flgActive2Standy_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgangover4rev_mp(static_cast<bool>(ACCCT_flgAngOver4Rev_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgangoverexp4rev_mp(
    static_cast<bool>(ACCCT_flgAngOverExp4Rev_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgangoverexp_mp(static_cast<bool>(ACCCT_flgAngOverExp_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgcipvwghtrstofdspl_mp(
    static_cast<bool>(ACCCT_flgCIPVWghtRstOfDspl_mp));
  fct_debug_out.mutable_accct_debug_out()->add_accct_flgcipvwghtrstoftgtidx_mp(
    static_cast<bool>(ACCCT_flgCIPVWghtRstOfTgtIdx_mp[0]));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgcctransstatus_mp(static_cast<bool>(ACCCT_flgCcTransStatus_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgclearlatdistance_mp(
    static_cast<bool>(ACCCT_flgClearLatDistance_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgcrpaccstopacclim_mp(
    static_cast<bool>(ACCCT_flgCrpAccStopAccLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdec2stoplvst_mp(static_cast<bool>(ACCCT_flgDec2StopLvSt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdec2stopnormal_mp(
    static_cast<bool>(ACCCT_flgDec2StopNormal_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdec2stoptja_mp(static_cast<bool>(ACCCT_flgDec2StopTJA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdeceltostopreset_mp(
    static_cast<bool>(ACCCT_flgDeceltoStopReset_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdeceltostopset_mp(
    static_cast<bool>(ACCCT_flgDeceltoStopSet_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdisplsetspdenbl_mp(
    static_cast<bool>(ACCCT_flgDisplSetSpdEnbl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdrvoffreset_mp(static_cast<bool>(ACCCT_flgDrvOffReset_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdrvoffset_mp(static_cast<bool>(ACCCT_flgDrvOffSet_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdtsacccdn_mp(static_cast<bool>(ACCCT_flgDtSAccCdn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdtsdrvoffcdn_mp(static_cast<bool>(ACCCT_flgDtSDrvOffCdn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdtsststcdn_mp(static_cast<bool>(ACCCT_flgDtSStStCdn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdtsvehspdcdn_mp(static_cast<bool>(ACCCT_flgDtSVehSpdCdn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy01_mp(static_cast<bool>(ACCCT_flgDummy01_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy02_mp(static_cast<bool>(ACCCT_flgDummy02_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy03_mp(static_cast<bool>(ACCCT_flgDummy03_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy04_mp(static_cast<bool>(ACCCT_flgDummy04_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy05_mp(static_cast<bool>(ACCCT_flgDummy05_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy06_mp(static_cast<bool>(ACCCT_flgDummy06_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy07_mp(static_cast<bool>(ACCCT_flgDummy07_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdummy08_mp(static_cast<bool>(ACCCT_flgDummy08_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgdvoacccdn_mp(static_cast<bool>(ACCCT_flgDvOAccCdn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttaraccinitcnd_mp(
    static_cast<bool>(ACCCT_flgLftTarAccInitCnd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttaraccreq_mp(static_cast<bool>(ACCCT_flgLftTarAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttardclreqsprlfttaraccreq_mp(
    static_cast<bool>(ACCCT_flgLftTarDclReqSprLftTarAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttardclreq_mp(static_cast<bool>(ACCCT_flgLftTarDclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttardlctoolrgflg_mp(
    static_cast<bool>(ACCCT_flgLftTarDlcTooLrgFlg_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttaring_mp(static_cast<bool>(ACCCT_flgLftTarIng_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttarnotuseforctrl_mp(
    static_cast<bool>(ACCCT_flgLftTarNotUseForCtrl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttartimerdyfordcl_mp(
    static_cast<bool>(ACCCT_flgLftTarTimeRdyForDcl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttaruseforctrl_mp(
    static_cast<bool>(ACCCT_flgLftTarUseForCtrl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglfttarusefullacc_mp(
    static_cast<bool>(ACCCT_flgLftTarUseFullAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flglostcipvtor_mp(static_cast<bool>(ACCCT_flgLostCipvTor_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgnpnotmovareq_mp(
    static_cast<uint32_t>(ACCCT_flgNPnotMovAReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgnrbyovrd_mp(static_cast<bool>(ACCCT_flgNrbyOvrd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgobjvxfiltdeb_mp(static_cast<bool>(ACCCT_flgObjVxFiltDeb_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgovrtkprdctcollmntar_mp(
    static_cast<bool>(ACCCT_flgOvrtkPrdctCollMnTar_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgovrtkstraftchkcollreset_mp(
    static_cast<bool>(ACCCT_flgOvrtkStrAftChkCollReset_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgovrtkstraftchkcollision_mp(
    static_cast<bool>(ACCCT_flgOvrtkStrAftChkCollision_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgovrtkstrdrvnoaction_mp(
    static_cast<bool>(ACCCT_flgOvrtkStrDrvNoAction_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgovtkuserglacc_mp(static_cast<bool>(ACCCT_flgOvtkUseRglAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgpassive2standby_mp(
    static_cast<bool>(ACCCT_flgPassive2Standby_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgpilotactvdenied_mp(
    static_cast<bool>(ACCCT_flgPilotActvDenied_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgratioswitchflag_mp(
    static_cast<bool>(ACCCT_flgRatioSwitchFlag_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgreverdirstrngwhl_mp(
    static_cast<bool>(ACCCT_flgReverDirStrngWhl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttaraccinitcnd_mp(
    static_cast<bool>(ACCCT_flgRhtTarAccInitCnd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttaraccreq_mp(static_cast<bool>(ACCCT_flgRhtTarAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttardclreq_mp(static_cast<bool>(ACCCT_flgRhtTarDclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttardlctoolrgflg_mp(
    static_cast<bool>(ACCCT_flgRhtTarDlcTooLrgFlg_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttarnotuseforctrl_mp(
    static_cast<bool>(ACCCT_flgRhtTarNotUseForCtrl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttartimerdyfordcl_mp(
    static_cast<bool>(ACCCT_flgRhtTarTimeRdyForDcl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttaruseforctrl_mp(
    static_cast<bool>(ACCCT_flgRhtTarUseForCtrl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgrhttarusefullacc_mp(
    static_cast<bool>(ACCCT_flgRhtTarUseFullAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgsrcswitchflag_mp(static_cast<bool>(ACCCT_flgSrcSwitchflag_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgstandby2leftactive_mp(
    static_cast<bool>(ACCCT_flgStandby2LeftActive_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgstandby2rightactive_mp(
    static_cast<bool>(ACCCT_flgStandby2RightActive_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgstaticobjoutofrange_mp(
    static_cast<bool>(ACCCT_flgStaticObjOutofRange_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgsteermatturnlight_mp(
    static_cast<bool>(ACCCT_flgSteerMatTurnLight_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgsteerrevturnlight_mp(
    static_cast<bool>(ACCCT_flgSteerRevTurnLight_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgstrngwhlstart_mp(static_cast<bool>(ACCCT_flgStrngWhlStart_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgtar1shrpdecbyrange_mp(
    static_cast<bool>(ACCCT_flgTar1ShrpDecbyRange_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgtar1shrpdecbyttc_mp(
    static_cast<bool>(ACCCT_flgTar1ShrpDecbyTTC_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgturnthenactturnlight_mp(
    static_cast<bool>(ACCCT_flgTurnThenActTurnLight_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_flgudrtkaccenb_mp(static_cast<bool>(ACCCT_flgUdrtkAccEnb_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccspdlmtatrbt_mp(
    static_cast<uint32_t>(ACCCT_iAccSpdLmtAtrbt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccspdlmttakeover_mp(
    static_cast<uint32_t>(ACCCT_iAccSpdLmtTakeover_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccspdlmtunit(static_cast<bool>(ACCCT_iAccSpdLmtUnit));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccspdlmtvalue(static_cast<uint32_t>(ACCCT_iAccSpdLmtValue));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccsupsignattr_mp(
    static_cast<uint32_t>(ACCCT_iAccSupSignAttr_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_iaccsupsigntype_mp(
    static_cast<uint32_t>(ACCCT_iAccSupSignType_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_idxcutinoptmltraj_mp(
    static_cast<double>(ACCCT_idxCutInOptmlTraj_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_idxcutintrajminaccl_mp(
    static_cast<double>(ACCCT_idxCutInTrajMinAccl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_kphccspddif_mp(static_cast<double>(ACCCT_kphCcSpdDif_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_kphcrpobjvxflit_mp(static_cast<double>(ACCCT_kphCrpObjVxFlit_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_llfttardclminrngprdc_mp(
    static_cast<double>(ACCCT_lLftTarDclMinRngPrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_llfttarenbldclrng_mp(
    static_cast<double>(ACCCT_lLftTarEnblDclRng_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_lovrtkprdcttotallatdisplcmnt_mp(
    static_cast<double>(ACCCT_lOvrtkPrdctTotalLatDisplcmnt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_lovrtkstrprdctlatdisplcmnt_mp(
    static_cast<double>(ACCCT_lOvrtkStrPrdctLatDisplcmnt_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_lovrtkstrturnradius_mp(
    static_cast<double>(ACCCT_lOvrtkStrTurnRadius_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_lrhttardclminrngprdc_mp(
    static_cast<double>(ACCCT_lRhtTarDclMinRngPrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mcutinerra_mp(static_cast<double>(ACCCT_mCutInErrA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mcutinerrs_mp(static_cast<double>(ACCCT_mCutInErrS_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mcutinerrv_mp(static_cast<double>(ACCCT_mCutInErrV_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mcutintgtlonposccs_mp(
    static_cast<double>(ACCCT_mCutinTgtLonPosCCS_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mexphostdst_mp(static_cast<double>(ACCCT_mExpHostDst_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mlonposccspred_mp(static_cast<double>(ACCCT_mLonPosCCSPred_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mrangepred_mp(static_cast<double>(ACCCT_mRangePred_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mreallatdistance_mp(
    static_cast<double>(ACCCT_mRealLatDistance_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mturnradius_mp(static_cast<double>(ACCCT_mTurnRadius_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_modecluster_mp(static_cast<uint32_t>(ACCCT_modeCluster_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsccspddifcor_mp(static_cast<double>(ACCCT_mpsCcSpdDifCor_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsccspddif_mp(static_cast<double>(ACCCT_mpsCcSpdDif_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpscutintgtvx_mp(static_cast<double>(ACCCT_mpsCutinTgtVx_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsdeltalvspddec2_mp(
    static_cast<double>(ACCCT_mpsDeltaLVSpdDec2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsdeltalvspddec_mp(
    static_cast<double>(ACCCT_mpsDeltaLVSpdDec_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsdeltalvspdinc2_mp(
    static_cast<double>(ACCCT_mpsDeltaLVSpdInc2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsdeltalvspdinc_mp(
    static_cast<double>(ACCCT_mpsDeltaLVSpdInc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsexphostvel_mp(static_cast<double>(ACCCT_mpsExpHostVel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsobjvxpred_mp(static_cast<double>(ACCCT_mpsObjVxPred_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsspdimpact2_mp(static_cast<double>(ACCCT_mpsSpdImpact2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsspdimpact_mp(static_cast<double>(ACCCT_mpsSpdImpact_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsundtktar1spd_mp(static_cast<double>(ACCCT_mpsUndtkTar1Spd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsundtktarcipvspd_mp(
    static_cast<double>(ACCCT_mpsUndtkTarCipvSpd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsundtktarn1spd_mp(
    static_cast<double>(ACCCT_mpsUndtkTarN1Spd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsundtktarn2spd_mp(
    static_cast<double>(ACCCT_mpsUndtkTarN2Spd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsundtktarn3spd_mp(
    static_cast<double>(ACCCT_mpsUndtkTarN3Spd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssacccomflimed_mp(
    static_cast<double>(ACCCT_mpssAccComfLimed_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssacccomflowlimed_mp(
    static_cast<double>(ACCCT_mpssAccComfLowLimed_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssacccomfuplimed_mp(
    static_cast<double>(ACCCT_mpssAccComfUpLimed_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssacclimforuphillstop_mp(
    static_cast<double>(ACCCT_mpssAccLimForUphillStop_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaccelreqjerklim_ll_mp(
    static_cast<double>(ACCCT_mpssAccelReqJerkLim_ll_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaccelreqraw_mp(static_cast<double>(ACCCT_mpssAccelReqRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaggtjapoaccpart2_mp(
    static_cast<double>(ACCCT_mpssAggTjaPoAccPart2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaggtjapoaccpart_mp(
    static_cast<double>(ACCCT_mpssAggTjaPoAccPart_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaggtjarrpart2_mp(
    static_cast<double>(ACCCT_mpssAggTjaRRPart2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssaggtjarrpart_mp(
    static_cast<double>(ACCCT_mpssAggTjaRRPart_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssalphaacc_mp(static_cast<double>(ACCCT_mpssAlphaAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssbaaccelreq2_mp(static_cast<double>(ACCCT_mpssBaAccelReq2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssbaaccelreq_mp(static_cast<double>(ACCCT_mpssBaAccelReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssccaccelreqraw_mp(
    static_cast<double>(ACCCT_mpssCcAccelReqRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssccaccelreq_mp(static_cast<double>(ACCCT_mpssCcAccelReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscctransaccraw_mp(
    static_cast<double>(ACCCT_mpssCcTransAccRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscctransaccreq_mp(
    static_cast<double>(ACCCT_mpssCcTransAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssconetaracclreq_mp(
    static_cast<double>(ACCCT_mpssConeTarAcclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscorrectaccel_mp(
    static_cast<double>(ACCCT_mpssCorrectAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscreepacccorr_mp(
    static_cast<double>(ACCCT_mpssCreepAccCorr_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscreepaccelnoobj_mp(
    static_cast<double>(ACCCT_mpssCreepAccelNoObj_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscreepaccelobj_mp(
    static_cast<double>(ACCCT_mpssCreepAccelObj_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscreepaccel_mp(static_cast<double>(ACCCT_mpssCreepAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscuraccelreq_mp(static_cast<double>(ACCCT_mpssCurAccelReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscurspdaccelreqraw_mp(
    static_cast<double>(ACCCT_mpssCurSpdAccelReqRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscurspdlimaccelreq_mp(
    static_cast<double>(ACCCT_mpssCurSpdLimAccelReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscutinacclreq_mp(
    static_cast<double>(ACCCT_mpssCutInAcclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscutindacclreq_mp(
    static_cast<double>(ACCCT_mpssCutInDAcclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscutinffacclreq_mp(
    static_cast<double>(ACCCT_mpssCutInFFAcclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscutinpacclreq_mp(
    static_cast<double>(ACCCT_mpssCutInPAcclReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsscutintgtlonacc_mp(
    static_cast<double>(ACCCT_mpssCutinTgtLonAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssedadecreq_mp(static_cast<double>(ACCCT_mpssEDADecReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssedaupperdec_mp(static_cast<double>(ACCCT_mpssEDAUpperDec_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssevdspdcc_mp(static_cast<double>(ACCCT_mpssEvdSpdCC_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssfuzzyaccelreq2_mp(
    static_cast<double>(ACCCT_mpssFuzzyAccelReq2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssfuzzyaccelreq_mp(
    static_cast<double>(ACCCT_mpssFuzzyAccelReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssfzzaccelreqarb_mp(
    static_cast<double>(ACCCT_mpssFzzAccelReqArb_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsshwacccompraw2_mp(
    static_cast<double>(ACCCT_mpssHWAccCompRaw2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsshwacccompraw_mp(
    static_cast<double>(ACCCT_mpssHWAccCompRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssisataraccreq_mp(
    static_cast<double>(ACCCT_mpssIsaTarAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssjerklimacc_mp(static_cast<double>(ACCCT_mpssJerkLimAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssjerklimdec_mp(static_cast<double>(ACCCT_mpssJerkLimDec_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimcc_mp(static_cast<double>(ACCCT_mpssLnSpdLimCC_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimevdtarn1_mp(
    static_cast<double>(ACCCT_mpssLnSpdLimEvdTarN1_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimevdtarn2_mp(
    static_cast<double>(ACCCT_mpssLnSpdLimEvdTarN2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimevdtarn3_mp(
    static_cast<double>(ACCCT_mpssLnSpdLimEvdTarN3_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimncc_mp(static_cast<double>(ACCCT_mpssLnSpdLimNCc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimnncc_mp(
    static_cast<double>(ACCCT_mpssLnSpdLimNnCc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsslnspdlimtara_mp(
    static_cast<double>(ACCCT_mpssLnSpdLimTarA_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssmaxaccellim_mp(static_cast<double>(ACCCT_mpssMaxAccelLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssminaccellim_mp(static_cast<double>(ACCCT_mpssMinAccelLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssneedhostacc2_mp(
    static_cast<double>(ACCCT_mpssNeedHostAcc2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssneedhostacc_mp(static_cast<double>(ACCCT_mpssNeedHostAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssnobrkrnglimedraw_mp(
    static_cast<double>(ACCCT_mpssNoBrkRngLimedRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssnobrkrnglimed_mp(
    static_cast<double>(ACCCT_mpssNoBrkRngLimed_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssnrbyovrdreq_mp(static_cast<double>(ACCCT_mpssNrByOvrdReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssobjacclpred_mp(static_cast<double>(ACCCT_mpssObjAcclPred_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssovertakeaccel_mp(
    static_cast<double>(ACCCT_mpssOverTakeAccel_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssovtkaccreqraw_mp(
    static_cast<double>(ACCCT_mpssOvtkAccReqRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsspoaccfiltered2_mp(
    static_cast<double>(ACCCT_mpssPoAccFiltered2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsspoaccfiltered_mp(
    static_cast<double>(ACCCT_mpssPoAccFiltered_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssrmptofrwspdlim_mp(
    static_cast<double>(ACCCT_mpssRmpToFrwSpdLim_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsstjaaccreq_mp(static_cast<double>(ACCCT_mpssTJAAccReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpsstargetlosslimed_mp(
    static_cast<double>(ACCCT_mpssTargetLossLimed_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssudrtkmintaracc_mp(
    static_cast<double>(ACCCT_mpssUdrtkMinTarAcc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_mpssudrtkmintarid_mp(
    static_cast<uint32_t>(ACCCT_mpssUdrtkMinTarID_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_numovrtkctltarnum_mp(
    static_cast<uint32_t>(ACCCT_numOvrtkCtlTarNum_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phiexpangle_mp(static_cast<double>(ACCCT_phiExpAngle_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phiffangle4curve_mp(
    static_cast<double>(ACCCT_phiFFAngle4Curve_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phiovrtkstrprdctyawangle_mp(
    static_cast<double>(ACCCT_phiOvrtkStrPrdctYawAngle_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phipeaksteerwheelang_mp(
    static_cast<double>(ACCCT_phiPeakSteerWheelAng_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phirecdangatstr_mp(static_cast<double>(ACCCT_phiRecdAngatStr_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phirecdffangatpeakang_mp(
    static_cast<double>(ACCCT_phiRecdFFAngatPeakAng_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phirecordangle4ff_mp(
    static_cast<double>(ACCCT_phiRecordAngle4FF_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_phirecordangle_mp(static_cast<double>(ACCCT_phiRecordAngle_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_radheadinganglenow_mp(
    static_cast<double>(ACCCT_radHeadingAngleNow_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_radheadingangle_mp(static_cast<double>(ACCCT_radHeadingAngle_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stadcplatformfailsts_mp(
    static_cast<uint32_t>(ACCCT_stADCPlatformFailSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_statntdmdsoftihn_mp(static_cast<bool>(ACCCT_stAtntDmdSoftIhn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stdafuncsts_mp(static_cast<uint32_t>(ACCCT_stDAFuncSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stdalccfuncsts_mp(static_cast<uint32_t>(ACCCT_stDALccFuncSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stdasdcfuncsts_mp(static_cast<uint32_t>(ACCCT_stDASdcFuncSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stdasetspeedanimation_mp(
    static_cast<uint32_t>(ACCCT_stDASetSpeedAnimation_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stdbadrvtype_mp(static_cast<uint32_t>(ACCCT_stDBADrvType_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stddwalertlvl_mp(static_cast<uint32_t>(ACCCT_stDdwAlertLvl_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_steasfuncsts_mp(static_cast<uint32_t>(ACCCT_stEASFuncSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stedaadcdrvprtctmode_mp(
    static_cast<uint32_t>(ACCCT_stEDAADCDrvPrtctMode_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stedadriverwarningreq_mp(
    static_cast<uint32_t>(ACCCT_stEDADriverWarningReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stedaecallreq_mp(static_cast<uint32_t>(ACCCT_stEDAECallReq_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stedasts_mp(static_cast<uint32_t>(ACCCT_stEDASts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stfreespaceintrusion_mp(
    static_cast<uint32_t>(ACCCT_stFreeSpaceIntrusion_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stpilotdbasts_mp(static_cast<uint32_t>(ACCCT_stPilotDBASts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stslifstate_mp(static_cast<uint32_t>(ACCCT_stSLIFState_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stslwfwarntrg_mp(static_cast<uint32_t>(ACCCT_stSLWFWarnTrg_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_sttaugapchgdisp_mp(
    static_cast<uint32_t>(ACCCT_stTauGapChgDisp_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_sttkovdmdsoftihn_mp(static_cast<bool>(ACCCT_stTkovDmdSoftIhn_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_studrtkmintarindex_mp(
    static_cast<uint32_t>(ACCCT_stUdrtkMinTarIndex_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stundertakeprevsts_mp(
    static_cast<uint32_t>(ACCCT_stUndertakePrevSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stundertakeprevtarindex_mp(
    static_cast<uint32_t>(ACCCT_stUndertakePrevTarIndex_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_stvlcreqfct_mp(static_cast<uint32_t>(ACCCT_stVlcReqFct_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tidrvofftimer_mp(static_cast<double>(ACCCT_tiDrvOffTimer_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tilfttaracctimeprdcraw_mp(
    static_cast<double>(ACCCT_tiLftTarAccTimePrdcRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tilfttaracctimeprdc_mp(
    static_cast<double>(ACCCT_tiLftTarAccTimePrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tilfttardcltimeprdc_mp(
    static_cast<double>(ACCCT_tiLftTarDclTimePrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tineedhostaccarb_mp(
    static_cast<double>(ACCCT_tiNeedHostAccArb_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tinrbyovrd_mp(static_cast<double>(ACCCT_tiNrbyOvrd_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tiovrtkstrttc_mp(static_cast<double>(ACCCT_tiOvrtkStrTTC_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tirhttaracctimeprdcraw_mp(
    static_cast<double>(ACCCT_tiRhtTarAccTimePrdcRaw_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tirhttaracctimeprdc_mp(
    static_cast<double>(ACCCT_tiRhtTarAccTimePrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tirhttardcltimeprdc_mp(
    static_cast<double>(ACCCT_tiRhtTarDclTimePrdc_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tittc4rngdivrngrate_mp(
    static_cast<double>(ACCCT_tiTTC4RngDivRngRate_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_titimetocollision2_mp(
    static_cast<double>(ACCCT_tiTimeToCollision2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_titimetocollisionarb_mp(
    static_cast<double>(ACCCT_tiTimeToCollisionArb_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_titimetocollision_mp(
    static_cast<double>(ACCCT_tiTimeToCollision_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tittctar2_mp(static_cast<double>(ACCCT_tiTtcTar2_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_tittctar_mp(static_cast<double>(ACCCT_tiTtcTar_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_udummy_26_mp(static_cast<uint32_t>(ACCCT_uDummy_26_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_udummy_27_mp(static_cast<uint32_t>(ACCCT_uDummy_27_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_udummy_28_mp(static_cast<uint32_t>(ACCCT_uDummy_28_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_udummy_29_mp(static_cast<uint32_t>(ACCCT_uDummy_29_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_udummy_30_mp(static_cast<uint32_t>(ACCCT_uDummy_30_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_uovtpsv2stby_mp(static_cast<uint32_t>(ACCCT_uOvTPsv2Stby_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_uovrtkctlsts_mp(static_cast<uint32_t>(ACCCT_uOvrtkCtlSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_uovrtksts_mp(static_cast<uint32_t>(ACCCT_uOvrtkSts_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_uovtact2psv_mp(static_cast<uint32_t>(ACCCT_uOvtAct2Psv_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_uovtact2stby_mp(static_cast<uint32_t>(ACCCT_uOvtAct2Stby_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ustby2act_mp(static_cast<uint32_t>(ACCCT_uStby2Act_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_ustby2lfovtact_mp(static_cast<uint32_t>(ACCCT_uStby2LfOvtAct_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_utar1shrpdeccutin_mp(
    static_cast<uint32_t>(ACCCT_uTar1ShrpDecCutin_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_09_mp(static_cast<double>(ACCCT_xDummy_09_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_10_mp(static_cast<double>(ACCCT_xDummy_10_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_11_mp(static_cast<double>(ACCCT_xDummy_11_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_12_mp(static_cast<double>(ACCCT_xDummy_12_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_13_mp(static_cast<double>(ACCCT_xDummy_13_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_14_mp(static_cast<double>(ACCCT_xDummy_14_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_15_mp(static_cast<double>(ACCCT_xDummy_15_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_16_mp(static_cast<double>(ACCCT_xDummy_16_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_17_mp(static_cast<double>(ACCCT_xDummy_17_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_18_mp(static_cast<double>(ACCCT_xDummy_18_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_19_mp(static_cast<double>(ACCCT_xDummy_19_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_20_mp(static_cast<double>(ACCCT_xDummy_20_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_21_mp(static_cast<double>(ACCCT_xDummy_21_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_22_mp(static_cast<double>(ACCCT_xDummy_22_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_23_mp(static_cast<double>(ACCCT_xDummy_23_mp));
  // fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_24_mp(static_cast<double>(ACCCT_xDummy_24_mp));
  fct_debug_out.mutable_accct_debug_out()->set_accct_xdummy_25_mp(static_cast<double>(ACCCT_xDummy_25_mp));
}

void accsc_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_accstatus_mp(static_cast<uint32_t>(ACCSC_AccStatus_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_accsysst_mp(static_cast<uint32_t>(ACCSC_AccSysSt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_acousticwarnblocked_mp(
    static_cast<bool>(ACCSC_AcousticWarnBlocked_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_aimcurbfrfltr_mp(static_cast<double>(ACCSC_AimCurBfrFltr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_curadjspdlimtcur_mp(
    static_cast<double>(ACCSC_CurAdjSpdLimtCur_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_curccaccratelimt_mp(
    static_cast<double>(ACCSC_CurCcAccRateLimt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_gpdistancesource_mp(
    static_cast<double>(ACCSC_GPDistanceSource_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ic0_mp(static_cast<double>(ACCSC_IC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ihppc0_mp(static_cast<double>(ACCSC_IHPPC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ilmc0_mp(static_cast<double>(ACCSC_ILMC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_lostcipv_mp(static_cast<bool>(ACCSC_LostCIPV_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_notarget1_mp(static_cast<bool>(ACCSC_NoTarget1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_notarget2_mp(static_cast<bool>(ACCSC_NoTarget2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_notarget_mp(static_cast<bool>(ACCSC_NoTarget_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objaccel1_mp(static_cast<double>(ACCSC_ObjAccel1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objaccel2_mp(static_cast<double>(ACCSC_ObjAccel2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objaccel_mp(static_cast<double>(ACCSC_ObjAccel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objindex10_mp(static_cast<uint32_t>(ACCSC_ObjIndex10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objindex32_mp(static_cast<uint32_t>(ACCSC_ObjIndex32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objindex3_mp(static_cast<uint32_t>(ACCSC_ObjIndex3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objindex5_mp(static_cast<uint32_t>(ACCSC_ObjIndex5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objindex9_mp(static_cast<uint32_t>(ACCSC_ObjIndex9_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid10_mp(static_cast<double>(ACCSC_ObjValid10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid1_mp(static_cast<bool>(ACCSC_ObjValid1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid2_mp(static_cast<bool>(ACCSC_ObjValid2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid32_mp(static_cast<bool>(ACCSC_ObjValid32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid3_mp(static_cast<double>(ACCSC_ObjValid3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid5_mp(static_cast<double>(ACCSC_ObjValid5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid9_mp(static_cast<double>(ACCSC_ObjValid9_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_objvalid_mp(static_cast<bool>(ACCSC_ObjValid_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtkctlsts_mp(static_cast<uint32_t>(ACCSC_OvrtkCtlSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtklargertartimegap_mp(
    static_cast<double>(ACCSC_OvrtkLargerTarTimeGap_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtkmintartimegap_mp(
    static_cast<double>(ACCSC_OvrtkMinTarTimeGap_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtksts_mp(static_cast<uint32_t>(ACCSC_OvrtkSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtktar1changed_mp(static_cast<bool>(ACCSC_OvrtkTar1Changed_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtktar3changed_mp(static_cast<bool>(ACCSC_OvrtkTar3Changed_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ovrtktar5changed_mp(static_cast<bool>(ACCSC_OvrtkTar5Changed_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range10_mp(static_cast<double>(ACCSC_Range10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range1_mp(static_cast<double>(ACCSC_Range1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range2_mp(static_cast<double>(ACCSC_Range2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range32_mp(static_cast<double>(ACCSC_Range32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range3_mp(static_cast<double>(ACCSC_Range3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range5_mp(static_cast<double>(ACCSC_Range5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range9_mp(static_cast<double>(ACCSC_Range9_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangedisp1_mp(static_cast<double>(ACCSC_RangeDisp1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangedisp2_mp(static_cast<double>(ACCSC_RangeDisp2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangedisp_mp(static_cast<double>(ACCSC_RangeDisp_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate10_mp(static_cast<double>(ACCSC_RangeRate10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate1_mp(static_cast<double>(ACCSC_RangeRate1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate2_mp(static_cast<double>(ACCSC_RangeRate2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate32_mp(static_cast<double>(ACCSC_RangeRate32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate3_mp(static_cast<double>(ACCSC_RangeRate3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate5_mp(static_cast<double>(ACCSC_RangeRate5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate9_mp(static_cast<double>(ACCSC_RangeRate9_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rangerate_mp(static_cast<double>(ACCSC_RangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_range_mp(static_cast<double>(ACCSC_Range_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_recomspeedsrcsource_mp(
    static_cast<uint32_t>(ACCSC_RecomSpeedSrcSource_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rellongspd3_mp(static_cast<double>(ACCSC_RelLongSpd3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_rellongspd5_mp(static_cast<double>(ACCSC_RelLongSpd5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimidc_mp(static_cast<uint32_t>(ACCSC_SpdLimIdC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimsrcc_mp(static_cast<uint32_t>(ACCSC_SpdLimSrcC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimsrcnn_mp(static_cast<uint32_t>(ACCSC_SpdLimSrcNN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimsrcn_mp(static_cast<uint32_t>(ACCSC_SpdLimSrcN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimtypec_mp(static_cast<uint32_t>(ACCSC_SpdLimTypeC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimtypenn_mp(static_cast<uint32_t>(ACCSC_SpdLimTypeNN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlimtypen_mp(static_cast<uint32_t>(ACCSC_SpdLimTypeN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlmtaftunittransc_mp(
    static_cast<uint32_t>(ACCSC_SpdLmtAftUnitTransC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlmtaftunittransn_mp(
    static_cast<uint32_t>(ACCSC_SpdLmtAftUnitTransN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_spdlmtoutaftunittrans_mp(
    static_cast<uint32_t>(ACCSC_SpdLmtOutAftUnitTrans_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_tsrsetspdcupdatecndn1_mp(
  //   static_cast<uint32_t>(ACCSC_TSRSetSpdCUpdateCndn1_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_tsrsetspdcupdatecndn2_mp(
  //   static_cast<uint32_t>(ACCSC_TSRSetSpdCUpdateCndn2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tsrsetspdnupdatecndn_mp(
    static_cast<uint32_t>(ACCSC_TSRSetSpdNUpdateCndn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targetchanged1_mp(static_cast<bool>(ACCSC_TargetChanged1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targetchanged2_mp(static_cast<bool>(ACCSC_TargetChanged2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targetchanged_mp(static_cast<bool>(ACCSC_TargetChanged_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targettype1_mp(static_cast<uint32_t>(ACCSC_TargetType1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targettype2_mp(static_cast<uint32_t>(ACCSC_TargetType2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_targettype_mp(static_cast<uint32_t>(ACCSC_TargetType_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlatacctar1_mp(static_cast<double>(ACCSC_aTgtLatAccTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlatacctar2_mp(static_cast<double>(ACCSC_aTgtLatAccTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlatacctar32_mp(static_cast<double>(ACCSC_aTgtLatAccTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlatacctar_mp(static_cast<double>(ACCSC_aTgtLatAccTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlonacctar1_mp(static_cast<double>(ACCSC_aTgtLonAccTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlonacctar2_mp(static_cast<double>(ACCSC_aTgtLonAccTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlonacctar32_mp(static_cast<double>(ACCSC_aTgtLonAccTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_atgtlonacctar_mp(static_cast<double>(ACCSC_aTgtLonAccTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfcutindtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfCutinDtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfcutinhadtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfCutinHADtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutindtctdtrgt3msk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinDtctdTrgt3Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutindtctdtrgt4msk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinDtctdTrgt4Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutinsprstrgt3msk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinSprsTrgt3Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutinsprstrgt4msk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinSprsTrgt4Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutintrgt3allwdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinTrgt3AllwdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutintrgt3dtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinTrgt3DtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutintrgt4allwdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinTrgt4AllwdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bflecutintrgt4dtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfLeCutinTrgt4DtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutindtctdtrgt5msk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinDtctdTrgt5Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutindtctdtrgt6msk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinDtctdTrgt6Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutinsprstrgt5msk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinSprsTrgt5Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutinsprstrgt6msk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinSprsTrgt6Msk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutintrgt5allwdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinTrgt5AllwdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutintrgt5dtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinTrgt5DtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutintrgt6allwdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinTrgt6AllwdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfricutintrgt6dtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfRiCutinTrgt6DtctdMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_bfudrtkprvntsprsmsk_mp(
    static_cast<uint32_t>(ACCSC_bfUdrtkPrvntSprsMsk_mp));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_bfudrtktrgtdtctdmsk_mp(
    static_cast<uint32_t>(ACCSC_bfUdrtkTrgtDtctdMsk_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_bfudrtktrgttrckmsk_mp(
    static_cast<uint32_t>(ACCSC_bfUdrtkTrgtTrckMsk_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_degdeltastranglefrompeak_mp(
    static_cast<double>(ACCSC_degDeltaStrAngleFromPeak_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_degdeltastrangle_mp(
    static_cast<double>(ACCSC_degDeltaStrAngle_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_degovrtkhldstragchkcollision_mp(
    static_cast<double>(ACCSC_degOvrtkHldStrAgChkCollision_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_degovtkstrwhlagflt_mp(
    static_cast<double>(ACCSC_degOvtkStrWhlAgFlt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_degrltang4latdiscalc_mp(
    static_cast<double>(ACCSC_degRltAng4LatDisCalc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_dphiangleratetar1_mp(
    static_cast<double>(ACCSC_dphiAngleRateTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_dphiangleratetar2_mp(
    static_cast<double>(ACCSC_dphiAngleRateTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_dphiangleratetar32_mp(
    static_cast<double>(ACCSC_dphiAngleRateTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_dphiangleratetar_mp(
    static_cast<double>(ACCSC_dphiAngleRateTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradirelelebslici_mp(
    static_cast<double>(ACCSC_facGradireleLeBsLiCi_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradirelelebslile_mp(
    static_cast<double>(ACCSC_facGradireleLeBsLiLe_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradirelelebsliti_mp(
    static_cast<double>(ACCSC_facGradireleLeBsLiTi_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradireleribslici_mp(
    static_cast<double>(ACCSC_facGradireleRiBsLiCi_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradireleribsliti_mp(
    static_cast<double>(ACCSC_facGradireleRiBsLiTi_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradirele_mp(static_cast<double>(ACCSC_facGradirele_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facgradireleribslile_mp(
    static_cast<double>(ACCSC_facGradirelerIBsLiLe_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facovtklatdsttrajp_mp(
    static_cast<double>(ACCSC_facOvtkLatDstTrajP_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_facovtklatdsttrajrev_mp(
    static_cast<double>(ACCSC_facOvtkLatDstTrajRev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaaappfaultinstoff_mp(
    static_cast<bool>(ACCSC_flgAAappFaultInstOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaaappfimad_mp(static_cast<bool>(ACCSC_flgAAappFimAD_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaaappfimtd_mp(static_cast<bool>(ACCSC_flgAAappFimTD_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaebprewarnreq_mp(static_cast<bool>(ACCSC_flgAEBPrewarnreq_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgabsactvp_mp(static_cast<bool>(ACCSC_flgAbsActvP_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaccactivated_mp(static_cast<bool>(ACCSC_flgAccActivated_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaccnotactivereset_mp(
    static_cast<bool>(ACCSC_flgAccNotActiveReset_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaccstsetspdchngen_mp(
    static_cast<bool>(ACCSC_flgAccStSetSpdChngEn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgact2stby_mp(static_cast<bool>(ACCSC_flgAct2Stby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgactprev_mp(static_cast<bool>(ACCSC_flgActPrev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgaebunavl_mp(static_cast<bool>(ACCSC_flgAebUnavl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgarblelinecros_mp(static_cast<bool>(ACCSC_flgArbLeLineCros_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgarbrilinecros_mp(static_cast<bool>(ACCSC_flgArbRiLineCros_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgautosetspddone_mp(
    static_cast<bool>(ACCSC_flgAutoSetSpdDone_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgautosetspdtri_mp(static_cast<bool>(ACCSC_flgAutoSetSpdTri_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgbothiineparallel_mp(
    static_cast<bool>(ACCSC_flgBothIineParallel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgc2jump_mp(static_cast<bool>(ACCSC_flgC2Jump_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcdchu04datainvld_mp(
  // static_cast<bool>(ACCSC_flgCDCHU04DataInvld_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcancelautosetspd_mp(
    static_cast<bool>(ACCSC_flgCancelAutoSetSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcldupdtslifspdn_mp(
    static_cast<bool>(ACCSC_flgCldUpdtSLIFSpdN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcldupdttsrsetspdn_mp(
    static_cast<bool>(ACCSC_flgCldUpdtTSRSetSpdN_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcldupdttsrsetspd_mp(
  //   static_cast<bool>(ACCSC_flgCldUpdtTSRSetSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgclearlatdist4ovtact_mp(
    static_cast<bool>(ACCSC_flgClearLatDist4OvtAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcloudoffnop_mp(static_cast<bool>(ACCSC_flgCloudOffNOP_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcurjerklmt_mp(static_cast<bool>(ACCSC_flgCurJerkLmt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcurlimspdacti_mp(static_cast<bool>(ACCSC_flgCurLimspdActi_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcutinctrlactv_mp(static_cast<bool>(ACCSC_flgCutinCtrlActv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcutinedrtrigger_mp(
    static_cast<bool>(ACCSC_flgCutinEDRTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgcutinhadtctd_mp(static_cast<bool>(ACCSC_flgCutinHADtctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdamainreqdanbc_mp(
    static_cast<bool>(ACCSC_flgDAMainReqDAnbc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdms3spr_mp(static_cast<bool>(ACCSC_flgDMS3Spr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdmsoccluded_mp(static_cast<bool>(ACCSC_flgDMSOccluded_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdanopstby_mp(static_cast<bool>(ACCSC_flgDaNopStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdanoptrigger_mp(static_cast<bool>(ACCSC_flgDaNopTrigger_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvprscncelc_mp(static_cast<bool>(ACCSC_flgDrvPrsCncelC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvprscnceln_mp(static_cast<bool>(ACCSC_flgDrvPrsCncelN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvprsdaresumebtn_mp(
    static_cast<bool>(ACCSC_flgDrvPrsDAResumeBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvprsdasetbtn_mp(
    static_cast<bool>(ACCSC_flgDrvPrsDASetBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvresmeactvda_mp(
    static_cast<bool>(ACCSC_flgDrvResmeActvDA_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvsprstsrsetspdnvld_mp(
  //   static_cast<bool>(ACCSC_flgDrvSprsTSRSetSpdNVld_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvsprstsrsetspdn_mp(
  //   static_cast<bool>(ACCSC_flgDrvSprsTSRSetSpdN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvupdttsrsetspd_mp(
    static_cast<bool>(ACCSC_flgDrvUpdtTSRSetSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvrcmplied_mp(static_cast<bool>(ACCSC_flgDrvrCmplied_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgdrvrdeactv_mp(static_cast<bool>(ACCSC_flgDrvrDeactv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgedaactv2standby_mp(
    static_cast<bool>(ACCSC_flgEDAActv2Standby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgedaedrtrigger_mp(static_cast<bool>(ACCSC_flgEDAEdrTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgedastandby2actv_mp(
    static_cast<bool>(ACCSC_flgEDAStandby2Actv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgelkrunning_mp(static_cast<bool>(ACCSC_flgELKRunning_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgeq4faultinhovtk_mp(
    static_cast<bool>(ACCSC_flgEQ4FaultInhOvtk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgedrsprsspdincbtn_mp(
    static_cast<bool>(ACCSC_flgEdRsPrsSpdIncBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgegospdtoohigh_mp(static_cast<bool>(ACCSC_flgEgoSpdTooHigh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgenoughroomfor1mov_mp(
    static_cast<bool>(ACCSC_flgEnoughRoomFor1Mov_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgevdspdvalid_mp(static_cast<bool>(ACCSC_flgEvdSpdValid_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgexitstopmodespdcdn_mp(
    static_cast<bool>(ACCSC_flgExitStopModeSpdCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgfam_dahardinh_mp(static_cast<bool>(ACCSC_flgFAM_DAHardInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgfameasstby_mp(static_cast<bool>(ACCSC_flgFamEasStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgfameastrigger_mp(static_cast<bool>(ACCSC_flgFamEasTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgfaultdeactv_mp(static_cast<bool>(ACCSC_flgFaultDeactv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flghardinhnp_mp(static_cast<bool>(ACCSC_flgHardInhNp_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flghardinh_mp(static_cast<bool>(ACCSC_flgHardInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flginstopzoneaccactive_mp(
    static_cast<bool>(ACCSC_flgInStopZoneAccActive_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglcsyspsv_mp(static_cast<bool>(ACCSC_flgLcSysPsv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgletrunindcqf_mp(static_cast<bool>(ACCSC_flgLeTrunIndcQf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgletrunindc_mp(static_cast<bool>(ACCSC_flgLeTrunIndc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgleftlanelim_mp(static_cast<bool>(ACCSC_flgLeftLaneLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglnspdlimvalidc_mp(
    static_cast<bool>(ACCSC_flgLnSpdLimValidC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglnspdlimvalidnn_mp(
    static_cast<bool>(ACCSC_flgLnSpdLimValidNN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglnspdlimvalidn_mp(
    static_cast<bool>(ACCSC_flgLnSpdLimValidN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmdrvstrngovrd_mp(
    static_cast<bool>(ACCSC_flgLohmDrvStrngOvrd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmegospdtoohigh_mp(
    static_cast<bool>(ACCSC_flgLohmEgoSpdTooHigh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmimpsbactionfinish_mp(
    static_cast<bool>(ACCSC_flgLohmImpsbActionFinish_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmimpsblactionstart_mp(
    static_cast<bool>(ACCSC_flgLohmImpsblActionStart_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmrangetoolarge_mp(
    static_cast<bool>(ACCSC_flgLohmRangeTooLarge_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmreqstst_mp(static_cast<bool>(ACCSC_flgLohmReqStst_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flglohmwithinstopzone_mp(
    static_cast<bool>(ACCSC_flgLohmWithinStopZone_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgmovobjstopnearby_mp(
    static_cast<bool>(ACCSC_flgMovObjStopNearby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgnotrajinter_mp(static_cast<bool>(ACCSC_flgNoTrajInter_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgnonswstby_mp(static_cast<bool>(ACCSC_flgNonSwStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgnop2npupdtspd_mp(static_cast<bool>(ACCSC_flgNop2NpUpdtSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgnopsysdrvoff_mp(static_cast<bool>(ACCSC_flgNopSysDrvOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgnpsyspsv_mp(static_cast<bool>(ACCSC_flgNpSysPsv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgobjrangeok4onemov_mp(
    static_cast<bool>(ACCSC_flgObjRangeOK4OneMov_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgobjrangeok4drvoff_mp(
    static_cast<bool>(ACCSC_flgObjRangeOK4drvOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgoutstopzonereset_mp(
    static_cast<bool>(ACCSC_flgOutStopZoneReset_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovrtkedrtrg_mp(static_cast<uint32_t>(ACCSC_flgOvrtkEDRTrg_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovrtknolineactv_mp(
    static_cast<bool>(ACCSC_flgOvrtkNoLineActv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovrtknolineexit_mp(
    static_cast<bool>(ACCSC_flgOvrtkNoLineExit_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovrtkwithalc_mp(static_cast<bool>(ACCSC_flgOvrtkWithAlc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtkoffbyindcreset_mp(
    static_cast<bool>(ACCSC_flgOvtkOffByIndcReset_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtkstrmntarcoll_mp(
    static_cast<bool>(ACCSC_flgOvtkStrMnTarColl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtkstrwhlagrvs_mp(
    static_cast<bool>(ACCSC_flgOvtkStrWhlAgRvs_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtkstrwhlend_mp(static_cast<bool>(ACCSC_flgOvtkStrWhlEnd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtkttcprdtmntarcoll_mp(
    static_cast<bool>(ACCSC_flgOvtkTTCPrdtMnTarColl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgovtktar1latdstchk_mp(
    static_cast<bool>(ACCSC_flgOvtkTar1LatDstChk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgprscnfrmbtn_mp(static_cast<bool>(ACCSC_flgPrsCnfrmBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgprsspdincbtnn_mp(static_cast<bool>(ACCSC_flgPrsSpdIncBtnN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgrrtoolarge_mp(static_cast<bool>(ACCSC_flgRRTooLarge_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgrangetoolarge_mp(static_cast<bool>(ACCSC_flgRangeTooLarge_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgrecordffangle_mp(static_cast<bool>(ACCSC_flgRecordFFAngle_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgrecordsteerangle_mp(
    static_cast<bool>(ACCSC_flgRecordSteerAngle_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgresmdrvrdeactv_mp(
    static_cast<bool>(ACCSC_flgResmDrvrDeactv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgresuprev_mp(static_cast<bool>(ACCSC_flgResuPrev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgritrunindcqf_mp(static_cast<bool>(ACCSC_flgRiTrunIndcQf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgritrunindc_mp(static_cast<bool>(ACCSC_flgRiTrunIndc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgrightlanelim_mp(static_cast<bool>(ACCSC_flgRightLaneLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgslifspdnupdate_mp(
    static_cast<bool>(ACCSC_flgSLIFSpdNUpdate_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgshortprscnfrmbtn_mp(
  //   static_cast<bool>(ACCSC_flgShortPrsCnfrmBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsoftinh_mp(static_cast<bool>(ACCSC_flgSoftInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgspddeccntrenabled_mp(
    static_cast<bool>(ACCSC_flgSpdDecCntrEnabled_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgspddectrigger_mp(static_cast<bool>(ACCSC_flgSpdDecTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgspdincbtnnotactvacc_mp(
    static_cast<bool>(ACCSC_flgSpdIncBtnNotActvAcc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgspdinccntrenabled_mp(
    static_cast<bool>(ACCSC_flgSpdIncCntrEnabled_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgspdinctrigger_mp(static_cast<bool>(ACCSC_flgSpdIncTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgstrovrd_mp(static_cast<bool>(ACCSC_flgStrOvrd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgstrngwhlend_mp(static_cast<bool>(ACCSC_flgStrngWhlEnd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgstrngwhlstart4end_mp(
    static_cast<bool>(ACCSC_flgStrngWhlStart4end_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgststprecdn_mp(static_cast<bool>(ACCSC_flgStstPreCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgswfromcrs2lc_mp(static_cast<bool>(ACCSC_flgSwFromCrs2Lc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgswpilot_mp(static_cast<bool>(ACCSC_flgSwPilot_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgswresume_mp(static_cast<bool>(ACCSC_flgSwResume_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysactivation_mp(static_cast<bool>(ACCSC_flgSysActivation_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysbrkonlyprecdn_mp(
    static_cast<bool>(ACCSC_flgSysBrkOnlyPreCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysbrkonly_mp(static_cast<bool>(ACCSC_flgSysBrkOnly_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysdrvoff_mp(static_cast<bool>(ACCSC_flgSysDrvOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysfailirrev_mp(static_cast<bool>(ACCSC_flgSysFailIrrev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysfailrev_mp(static_cast<bool>(ACCSC_flgSysFailRev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysnpdirstby_mp(static_cast<bool>(ACCSC_flgSysNpDirStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysoff_mp(static_cast<bool>(ACCSC_flgSysOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsyson_mp(static_cast<bool>(ACCSC_flgSysOn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysoverride_mp(static_cast<bool>(ACCSC_flgSysOverride_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsyspassive_mp(static_cast<bool>(ACCSC_flgSysPassive_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysstst_mp(static_cast<bool>(ACCSC_flgSysStSt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysstby2ovrd_mp(static_cast<bool>(ACCSC_flgSysStby2Ovrd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgsysstby_mp(static_cast<bool>(ACCSC_flgSysStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtjareqstst_mp(static_cast<bool>(ACCSC_flgTJAReqStst_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtsrspdlmtupdttrgn_mp(
    static_cast<bool>(ACCSC_flgTSRSpdLmtUpdtTrgN_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtsrspdlmtupdttrg_mp(
  //   static_cast<bool>(ACCSC_flgTSRSpdLmtUpdtTrg_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar1chgwithline_mp(
    static_cast<bool>(ACCSC_flgTar1ChgwithLine_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar1chgwoline_mp(static_cast<bool>(ACCSC_flgTar1ChgwoLine_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar1nosaft4ovtenbsaccel_mp(
    static_cast<bool>(ACCSC_flgTar1NoSaft4OvtEnbsAccel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar1nosaft4ovtenbsrng_mp(
    static_cast<bool>(ACCSC_flgTar1NoSaft4OvtEnbsRng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar1shrpdec_mp(static_cast<bool>(ACCSC_flgTar1ShrpDec_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar3cutinprdctdinbrdrraw_mp(
    static_cast<bool>(ACCSC_flgTar3CutInPrdctdInBrdrRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar3cutintypdly_mp(
    static_cast<bool>(ACCSC_flgTar3CutInTypDly_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar4cutinprdctdinbrdrraw_mp(
    static_cast<bool>(ACCSC_flgTar4CutInPrdctdInBrdrRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar4cutintypdly_mp(
    static_cast<bool>(ACCSC_flgTar4CutInTypDly_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar5cutinprdctdinbrdrraw_mp(
    static_cast<bool>(ACCSC_flgTar5CutInPrdctdInBrdrRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar5cutintypdly_mp(
    static_cast<bool>(ACCSC_flgTar5CutInTypDly_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar6cutinprdctdinbrdrraw_mp(
    static_cast<bool>(ACCSC_flgTar6CutInPrdctdInBrdrRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtar6cutintypdly_mp(
    static_cast<bool>(ACCSC_flgTar6CutInTypDly_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtarchgbyindex_mp(static_cast<bool>(ACCSC_flgTarChgByIndex_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtempstopreq_mp(static_cast<bool>(ACCSC_flgTempStopReq_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtimegapdec_mp(static_cast<bool>(ACCSC_flgTimeGapDec_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgtimegapinc_mp(static_cast<bool>(ACCSC_flgTimeGapInc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgturnlightreset_mp(
    static_cast<bool>(ACCSC_flgTurnlightreset_mp));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_flgudrtktrgtchg_mp(static_cast<bool>(ACCSC_flgUdrtkTrgtChg_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_flgudrtktrgtdtctd_mp(
    static_cast<bool>(ACCSC_flgUdrtkTrgtDtctd_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_flgudrtktrgtindxtrckd_mp(
    static_cast<bool>(ACCSC_flgUdrtkTrgtIndxTrckd_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_flgudrtktrgttrckactv_mp(
    static_cast<bool>(ACCSC_flgUdrtkTrgtTrckActv_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_flgudrtktrgttrckvld_mp(
    static_cast<bool>(ACCSC_flgUdrtkTrgtTrckVld_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flguselecurlim_mp(static_cast<bool>(ACCSC_flgUseLeCurLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgusericurlim_mp(static_cast<bool>(ACCSC_flgUseRiCurLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgusespdinccnfmspdlmtn_mp(
    static_cast<bool>(ACCSC_flgUseSpdIncCnfmSpdLmtN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgusetsrspdlim_mp(static_cast<bool>(ACCSC_flgUseTsrSpdLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgvmclgtsts_mp(static_cast<bool>(ACCSC_flgVMCLgtSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgvehststbkwd_mp(static_cast<bool>(ACCSC_flgVehStstBkwd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgvehststveh3_mp(static_cast<bool>(ACCSC_flgVehStstVeh3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgvehststveh_mp(static_cast<bool>(ACCSC_flgVehStstVeh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgvehstst_mp(static_cast<bool>(ACCSC_flgVehStst_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgwithinstopzone_mp(
    static_cast<bool>(ACCSC_flgWithinStopZone_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgiaccdrvtkovsetspd_mp(
    static_cast<bool>(ACCSC_flgiACCDrvTkOvSetSpd_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgiaccoutnextspdlmt_mp(
  //   static_cast<bool>(ACCSC_flgiACCOutNextSpdLmt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgiaccspdincprs_mp(static_cast<bool>(ACCSC_flgiACCSpdIncPrs_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_flgiacctsplogtrigger_mp(
    static_cast<uint32_t>(ACCSC_flgiACCTSPLogTrigger_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphdeltasetspdraw_mp(
    static_cast<double>(ACCSC_kphDeltaSetSpdRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphdrvdeltaspdraw_mp(
    static_cast<uint32_t>(ACCSC_kphDrvDeltaSpdRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphevdspdlim_mp(static_cast<uint32_t>(ACCSC_kphEvdSpdLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphlnspdlimc_mp(static_cast<uint32_t>(ACCSC_kphLnSpdLimC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphlnspdlimnaftlim_mp(
    static_cast<uint32_t>(ACCSC_kphLnSpdLimNAftLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphlnspdlimnn_mp(static_cast<uint32_t>(ACCSC_kphLnSpdLimNN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphlnspdlimn_mp(static_cast<uint32_t>(ACCSC_kphLnSpdLimN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphlohmimpsbexpctspd_mp(
    static_cast<double>(ACCSC_kphLohmImpsbExpctSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphobjvx1_mp(static_cast<double>(ACCSC_kphObjVx1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphobjvx2_mp(static_cast<double>(ACCSC_kphObjVx2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphobjvx_mp(static_cast<double>(ACCSC_kphObjVx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphsetspddispll_mp(static_cast<double>(ACCSC_kphSetSpdDispLL_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphsetspdtarget_mp(static_cast<double>(ACCSC_kphSetSpdTarget_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphsetspeedtar_mp(static_cast<double>(ACCSC_kphSetSpeedTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphsetspeedtargetcurraw_mp(
    static_cast<double>(ACCSC_kphSetSpeedTargetCurRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphsetspeedtargetcur_mp(
    static_cast<double>(ACCSC_kphSetSpeedTargetCur_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphspdlmtvaluearb_mp(
    static_cast<uint32_t>(ACCSC_kphSpdLmtValueArb_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphstartsetspeed_mp(
    static_cast<double>(ACCSC_kphStartSetSpeed_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphupdttsrspdlmt_mp(
    static_cast<uint32_t>(ACCSC_kphUpdtTSRSpdLmt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphvehdispspd_mp(static_cast<double>(ACCSC_kphVehDispSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphvirvehspd_mp(static_cast<double>(ACCSC_kphVirVehSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphiacctsplogsetspd_mp(
    static_cast<double>(ACCSC_kphiACCTSPLogSetSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphiacctsplogspdlmtdst_mp(
    static_cast<double>(ACCSC_kphiACCTSPLogSpdLmtDst_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphiacctsplogspdlmtsrc_mp(
    static_cast<uint32_t>(ACCSC_kphiACCTSPLogSpdLmtSrc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_kphiacctsplogspdlmtvalue_mp(
    static_cast<double>(ACCSC_kphiACCTSPLogSpdLmtValue_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_lovrtkstrcurvelenth_mp(
    static_cast<double>(ACCSC_lOvrtkStrCurveLenth_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposccstar1_mp(
    static_cast<double>(ACCSC_lTgtLatPosCCSTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposccstar2_mp(
    static_cast<double>(ACCSC_lTgtLatPosCCSTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposccstar32_mp(
    static_cast<double>(ACCSC_lTgtLatPosCCSTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposccstar_mp(
    static_cast<double>(ACCSC_lTgtLatPosCCSTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposvcstar1_mp(
    static_cast<double>(ACCSC_lTgtLatPosVCSTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposvcstar2_mp(
    static_cast<double>(ACCSC_lTgtLatPosVCSTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposvcstar32_mp(
    static_cast<double>(ACCSC_lTgtLatPosVCSTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlatposvcstar_mp(
    static_cast<double>(ACCSC_lTgtLatPosVCSTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposccstar1_mp(
    static_cast<double>(ACCSC_lTgtLonPosCCSTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposccstar2_mp(
    static_cast<double>(ACCSC_lTgtLonPosCCSTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposccstar32_mp(
    static_cast<double>(ACCSC_lTgtLonPosCCSTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposccstar_mp(
    static_cast<double>(ACCSC_lTgtLonPosCCSTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposvcstar1_mp(
    static_cast<double>(ACCSC_lTgtLonPosVCSTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposvcstar2_mp(
    static_cast<double>(ACCSC_lTgtLonPosVCSTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposvcstar32_mp(
    static_cast<double>(ACCSC_lTgtLonPosVCSTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ltgtlonposvcstar_mp(
    static_cast<double>(ACCSC_lTgtLonPosVCSTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marblelinec0source_mp(
    static_cast<uint32_t>(ACCSC_mArbLeLineC0Source_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marblelinec0_mp(static_cast<double>(ACCSC_mArbLeLineC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marblelinec2_mp(static_cast<double>(ACCSC_mArbLeLineC2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marblelinec3_mp(static_cast<double>(ACCSC_mArbLeLineC3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marbrilinec0source_mp(
    static_cast<uint32_t>(ACCSC_mArbRiLineC0Source_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marbrilinec0_mp(static_cast<double>(ACCSC_mArbRiLineC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marbrilinec2_mp(static_cast<double>(ACCSC_mArbRiLineC2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_marbrilinec3_mp(static_cast<double>(ACCSC_mArbRiLineC3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mcutinctrlbrdrc2shft_mp(
    static_cast<double>(ACCSC_mCutinCtrlBrdrC2Shft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mcutindtctbrdrc2shft_mp(
    static_cast<double>(ACCSC_mCutinDtctBrdrC2Shft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mevdspdlimdist_mp(static_cast<double>(ACCSC_mEvdSpdLimDist_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlatdis4prevtraj_mp(
    static_cast<double>(ACCSC_mLatDis4PrevTraj_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlatdisaftfilter_mp(
    static_cast<double>(ACCSC_mLatDisAftFilter_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlatdisbymefun_mp(static_cast<double>(ACCSC_mLatDisByMEFun_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlatdist4ovtkact_mp(
    static_cast<double>(ACCSC_mLatDist4OvtkAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlatdistancelim_mp(static_cast<double>(ACCSC_mLatDistanceLim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt3basebrdr_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt3BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt3brdrtimeshft_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt3BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt3brdr_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt3Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt4basebrdr_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt4BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt4brdrtimeshft_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt4BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutinctrltrgt4brdr_mp(
    static_cast<double>(ACCSC_mLeCutinCtrlTrgt4Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt3basebrdr_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt3BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt3brdrtimeshft_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt3BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt3brdr_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt3Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt4basebrdr_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt4BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt4brdrtimeshft_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt4BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutindtcttrgt4brdr_mp(
    static_cast<double>(ACCSC_mLeCutinDtctTrgt4Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt3latdstprdctd_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt3LatDstPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt3latposprdctd_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt3LatPosPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt3latpos_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt3LatPos_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt3prdctdrng_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt3PrdctdRng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt4latdstprdctd_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt4LatDstPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt4latposprdctd_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt4LatPosPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt4latpos_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt4LatPos_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlecutintrgt4prdctdrng_mp(
    static_cast<double>(ACCSC_mLeCutinTrgt4PrdctdRng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlnspdlimdistc_mp(static_cast<double>(ACCSC_mLnSpdLimDistC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlnspdlimdistnn_mp(static_cast<double>(ACCSC_mLnSpdLimDistNN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mlnspdlimdistn_mp(static_cast<double>(ACCSC_mLnSpdLimDistN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mmeanturnradius_mp(static_cast<double>(ACCSC_mMeanTurnRadius_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mobjrngfilted_mp(static_cast<double>(ACCSC_mObjRngFilted_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtkhldlatdstchkcollision_mp(
    static_cast<double>(ACCSC_mOvrtkHldLatDstChkCollision_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar1largernormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar1LargerNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar1minnormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar1MinNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar1normrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar1NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar3largernormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar3LargerNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar3minnormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar3MinNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar3normrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar3NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar5largernormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar5LargerNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar5minnormrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar5MinNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movrtktar5normrange_mp(
    static_cast<double>(ACCSC_mOvrtkTar5NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movtklatdsttrajmax_mp(
    static_cast<double>(ACCSC_mOvtkLatDstTrajMax_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movtklatdsttrajp_mp(
    static_cast<double>(ACCSC_mOvtkLatDstTrajP_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_movtklatdsttrajrev_mp(
    static_cast<double>(ACCSC_mOvtkLatDstTrajRev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mreallatdist4ovtkact_mp(
    static_cast<double>(ACCSC_mRealLatDist4OvtkAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mrecdhpplatdis_mp(static_cast<double>(ACCSC_mRecdHPPLatDis_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mrecdlilinec0_mp(static_cast<double>(ACCSC_mRecdLiLineC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mrecdrilinec0_mp(static_cast<double>(ACCSC_mRecdRiLineC0_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt5basebrdr_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt5BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt5brdrtimeshft_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt5BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt5brdr_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt5Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt6basebrdr_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt6BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt6brdrtimeshft_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt6BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutinctrltrgt6brdr_mp(
    static_cast<double>(ACCSC_mRiCutinCtrlTrgt6Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt5basebrdr_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt5BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt5brdrtimeshft_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt5BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt5brdr_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt5Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt6basebrdr_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt6BaseBrdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt6brdrtimeshft_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt6BrdrTimeShft_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutindtcttrgt6brdr_mp(
    static_cast<double>(ACCSC_mRiCutinDtctTrgt6Brdr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt5latdstprdctd_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt5LatDstPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt5latposprdctd_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt5LatPosPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt5latpos_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt5LatPos_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt5prdctdrng_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt5PrdctdRng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt6latdstprdctd_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt6LatDstPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt6latposprdctd_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt6LatPosPrdctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt6latpos_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt6LatPos_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mricutintrgt6prdctdrng_mp(
    static_cast<double>(ACCSC_mRiCutinTrgt6PrdctdRng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mstoredrangelaststop_mp(
    static_cast<double>(ACCSC_mStoredRangeLastStop_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mtradius4latdisovtact_mp(
    static_cast<double>(ACCSC_mTRadius4LatDisOvtAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_mudrtktrgtrngcmpnstn_mp(
    static_cast<double>(ACCSC_mUdrtkTrgtRngCmpnstn_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_mudrtktrgttrckdst_mp(
    static_cast<double>(ACCSC_mUdrtkTrgtTrckDst_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_mudrtktrgttrckrng_mp(
    static_cast<double>(ACCSC_mUdrtkTrgtTrckRng_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktar1normrange_mp(
    static_cast<double>(ACCSC_mUndtkTar1NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktar1rangecmpnstn_mp(
    static_cast<double>(ACCSC_mUndtkTar1RangeCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktar1rangerate_mp(
    static_cast<double>(ACCSC_mUndtkTar1RangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktar1range_mp(static_cast<double>(ACCSC_mUndtkTar1Range_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarcipvnormrange_mp(
    static_cast<double>(ACCSC_mUndtkTarCipvNormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarcipvrangecmpnstn_mp(
    static_cast<double>(ACCSC_mUndtkTarCipvRangeCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarcipvrangerate_mp(
    static_cast<double>(ACCSC_mUndtkTarCipvRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarcipvrange_mp(
    static_cast<double>(ACCSC_mUndtkTarCipvRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn1normrange_mp(
    static_cast<double>(ACCSC_mUndtkTarN1NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn1rangecmpnstn_mp(
    static_cast<double>(ACCSC_mUndtkTarN1RangeCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn1rangerate_mp(
    static_cast<double>(ACCSC_mUndtkTarN1RangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn1range_mp(
    static_cast<double>(ACCSC_mUndtkTarN1Range_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn2normrange_mp(
    static_cast<double>(ACCSC_mUndtkTarN2NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn2rangecmpnstn_mp(
    static_cast<double>(ACCSC_mUndtkTarN2RangeCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn2rangerate_mp(
    static_cast<double>(ACCSC_mUndtkTarN2RangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn2range_mp(
    static_cast<double>(ACCSC_mUndtkTarN2Range_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn3normrange_mp(
    static_cast<double>(ACCSC_mUndtkTarN3NormRange_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn3rangecmpnstn_mp(
    static_cast<double>(ACCSC_mUndtkTarN3RangeCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn3rangerate_mp(
    static_cast<double>(ACCSC_mUndtkTarN3RangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mundtktarn3range_mp(
    static_cast<double>(ACCSC_mUndtkTarN3Range_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsnormheadway2_mp(static_cast<double>(ACCSC_mpsNormHeadway2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsnormheadway_mp(static_cast<double>(ACCSC_mpsNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjspdfilted_mp(static_cast<double>(ACCSC_mpsObjSpdFilted_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx10_mp(static_cast<double>(ACCSC_mpsObjVx10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx1_mp(static_cast<double>(ACCSC_mpsObjVx1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx2_mp(static_cast<double>(ACCSC_mpsObjVx2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx32_mp(static_cast<double>(ACCSC_mpsObjVx32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx3_mp(static_cast<double>(ACCSC_mpsObjVx3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx5_mp(static_cast<double>(ACCSC_mpsObjVx5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx9_mp(static_cast<double>(ACCSC_mpsObjVx9_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsobjvx_mp(static_cast<double>(ACCSC_mpsObjVx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar1largernormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar1LargerNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar1minnormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar1MinNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar1normrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar1NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar3largernormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar3LargerNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar3minnormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar3MinNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar3normrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar3NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar5largernormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar5LargerNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar5minnormrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar5MinNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsovrtktar5normrangerate_mp(
    static_cast<double>(ACCSC_mpsOvrtkTar5NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsrellatspd1_mp(static_cast<double>(ACCSC_mpsRelLatSpd1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsrellatspd_mp(static_cast<double>(ACCSC_mpsRelLatSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstar1lngvel_mp(static_cast<double>(ACCSC_mpsTar1LngVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstar1ltrvel_mp(static_cast<double>(ACCSC_mpsTar1LtrVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstar3lngvel_mp(static_cast<double>(ACCSC_mpsTar3LngVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstar5lngvel_mp(static_cast<double>(ACCSC_mpsTar5LngVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstar5ltrvel_mp(static_cast<double>(ACCSC_mpsTar5LtrVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstgtlatvel1_mp(static_cast<double>(ACCSC_mpsTgtLatVel1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpstgtlatvel_mp(static_cast<double>(ACCSC_mpsTgtLatVel_mp));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_mpsudrtktrgttrckobjvx_mp(
    static_cast<double>(ACCSC_mpsUdrtkTrgtTrckObjVx_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_mpsudrtktrgttrckrngrate_mp(
    static_cast<double>(ACCSC_mpsUdrtkTrgtTrckRngRate_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsundtktar1normrangerate_mp(
    static_cast<double>(ACCSC_mpsUndtkTar1NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsundtktarcipvnormrangerate_mp(
    static_cast<double>(ACCSC_mpsUndtkTarCipvNormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsundtktarn1normrangerate_mp(
    static_cast<double>(ACCSC_mpsUndtkTarN1NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsundtktarn2normrangerate_mp(
    static_cast<double>(ACCSC_mpsUndtkTarN2NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsundtktarn3normrangerate_mp(
    static_cast<double>(ACCSC_mpsUndtkTarN3NormRangeRate_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsslecutintrgt3eqvlatacclcmpnstn_mp(
    static_cast<double>(ACCSC_mpssLeCutinTrgt3EqvLatAcclCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsslecutintrgt3eqvlataccl_mp(
    static_cast<double>(ACCSC_mpssLeCutinTrgt3EqvLatAccl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsslecutintrgt4eqvlatacclcmpnstn_mp(
    static_cast<double>(ACCSC_mpssLeCutinTrgt4EqvLatAcclCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpsslecutintrgt4eqvlataccl_mp(
    static_cast<double>(ACCSC_mpssLeCutinTrgt4EqvLatAccl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssricutintrgt5eqvlatacclcmpnstn_mp(
    static_cast<double>(ACCSC_mpssRiCutinTrgt5EqvLatAcclCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssricutintrgt5eqvlataccl_mp(
    static_cast<double>(ACCSC_mpssRiCutinTrgt5EqvLatAccl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssricutintrgt6eqvlatacclcmpnstn_mp(
    static_cast<double>(ACCSC_mpssRiCutinTrgt6EqvLatAcclCmpnstn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssricutintrgt6eqvlataccl_mp(
    static_cast<double>(ACCSC_mpssRiCutinTrgt6EqvLatAccl_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssvirlgtahighspd_mp(
    static_cast<double>(ACCSC_mpssVirLgtaHighSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssvirlgtalowspd_mp(
    static_cast<double>(ACCSC_mpssVirLgtaLowSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssvirlongaccf_mp(static_cast<double>(ACCSC_mpssVirLongAccF_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssvirlongaccini_mp(
    static_cast<double>(ACCSC_mpssVirLongAccIni_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_mpssvirlongacc_mp(static_cast<double>(ACCSC_mpssVirLongAcc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numdltidx_mp(static_cast<uint32_t>(ACCSC_numDltIdx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numhdwyidxll_mp(static_cast<uint32_t>(ACCSC_numHdwyIdxll_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_nummanchnghdwyidx_mp(
    static_cast<uint32_t>(ACCSC_numManChngHdwyIdx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_nummanhdwyidx_mp(static_cast<uint32_t>(ACCSC_numManHdwyIdx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numstoredtimegap_mp(
    static_cast<uint32_t>(ACCSC_numStoredTimeGap_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtagetar1_mp(static_cast<uint32_t>(ACCSC_numTgtAgeTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtagetar2_mp(static_cast<uint32_t>(ACCSC_numTgtAgeTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtagetar32_mp(static_cast<uint32_t>(ACCSC_numTgtAgeTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtagetar_mp(static_cast<uint32_t>(ACCSC_numTgtAgeTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtconfidencetar1_mp(
    static_cast<uint32_t>(ACCSC_numTgtConfidenceTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtconfidencetar2_mp(
    static_cast<uint32_t>(ACCSC_numTgtConfidenceTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtconfidencetar32_mp(
    static_cast<uint32_t>(ACCSC_numTgtConfidenceTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtconfidencetar_mp(
    static_cast<uint32_t>(ACCSC_numTgtConfidenceTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtidtar1_mp(static_cast<uint32_t>(ACCSC_numTgtIdTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtidtar2_mp(static_cast<uint32_t>(ACCSC_numTgtIdTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtidtar32_mp(static_cast<uint32_t>(ACCSC_numTgtIdTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtidtar_mp(static_cast<uint32_t>(ACCSC_numTgtIdTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtobjindextar1_mp(
    static_cast<uint32_t>(ACCSC_numTgtObjIndexTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtobjindextar2_mp(
    static_cast<uint32_t>(ACCSC_numTgtObjIndexTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtobjindextar32_mp(
    static_cast<uint32_t>(ACCSC_numTgtObjIndexTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numtgtobjindextar_mp(
    static_cast<uint32_t>(ACCSC_numTgtObjIndexTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_numvirlongaccqf_mp(
    static_cast<uint32_t>(ACCSC_numVirLongAccQf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pctcamlelaneconf_mp(
    static_cast<double>(ACCSC_pctCamLeLaneConf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pctcamrilaneconf_mp(
    static_cast<double>(ACCSC_pctCamRiLaneConf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pcthpplaneconf_mp(static_cast<double>(ACCSC_pctHPPLaneConf_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_persetspdcurjerklmt_mp(
    static_cast<double>(ACCSC_perSetSpdCurJerkLmt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phiexpang4strthenturnrev_mp(
    static_cast<double>(ACCSC_phiExpAng4StrThenTurnRev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phiexpangle4rev_mp(static_cast<double>(ACCSC_phiExpAngle4Rev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phihppc1_mp(static_cast<double>(ACCSC_phiHPPC1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_philmc1_mp(static_cast<double>(ACCSC_phiLMC1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phistrwhlagwithdir_mp(
    static_cast<double>(ACCSC_phiStrWhlAgwithDir_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitargetangle1_mp(static_cast<double>(ACCSC_phiTargetAngle1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitargetangle2_mp(static_cast<double>(ACCSC_phiTargetAngle2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitargetangle_mp(static_cast<double>(ACCSC_phiTargetAngle_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitgtangletar1_mp(static_cast<double>(ACCSC_phiTgtAngleTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitgtangletar2_mp(static_cast<double>(ACCSC_phiTgtAngleTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitgtangletar32_mp(
    static_cast<double>(ACCSC_phiTgtAngleTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_phitgtangletar_mp(static_cast<double>(ACCSC_phiTgtAngleTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmhpplinec2aimaftgain_mp(
    static_cast<double>(ACCSC_pmHPPLineC2AimAftGain_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmhpplinec2aim_mp(static_cast<double>(ACCSC_pmHPPLineC2Aim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimaftgain_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimAftGain_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimpoint1_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimPoint1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimpoint2_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimPoint2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimpoint3_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimPoint3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimpoint4_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimPoint4_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aimpoint_mp(
    static_cast<double>(ACCSC_pmLeLineC2AimPoint_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmlelinec2aim_mp(static_cast<double>(ACCSC_pmLeLineC2Aim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimaftgain_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimAftGain_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimpoint1_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimPoint1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimpoint2_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimPoint2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimpoint3_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimPoint3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimpoint4_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimPoint4_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aimpoint_mp(
    static_cast<double>(ACCSC_pmRiLineC2AimPoint_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pmrilinec2aim_mp(static_cast<double>(ACCSC_pmRiLineC2Aim_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_pntovtkyawratefct_mp(
    static_cast<double>(ACCSC_pntOvtkYawRateFct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_radheadang4ovtkact_mp(
    static_cast<double>(ACCSC_radHeadAng4OvtkAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_radheadangnow4ovtkact_mp(
    static_cast<double>(ACCSC_radHeadAngNow4OvtkAct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sststtimer_mp(static_cast<double>(ACCSC_sStstTimer_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_secedadectime_mp(static_cast<double>(ACCSC_secEDADecTime_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_secovtktar1ttc_mp(static_cast<double>(ACCSC_secOvtkTar1Ttc_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_secsnowspdlmtupdttm_mp(
    static_cast<double>(ACCSC_secSnowSpdLmtUpdtTm_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_sectsrspdlmtupdttm_mp(
  //   static_cast<double>(ACCSC_secTSRSpdLmtUpdtTm_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcamlelaneqlt_mp(static_cast<uint32_t>(ACCSC_stCamLeLaneQlt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcamrilaneqlt_mp(static_cast<uint32_t>(ACCSC_stCamRiLaneQlt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutindtctdarbt_mp(
    static_cast<uint32_t>(ACCSC_stCutinDtctdArbt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutindtctd_mp(static_cast<uint32_t>(ACCSC_stCutinDtctd_mp));
  // fct_debug_out.mutable_accsc_debug_out()->add_accsc_stcutinlinedtctd_mp(
  //   static_cast<uint32_t>(ACCSC_stCutinLineDtctd_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutintrgtdtctd_mp(
    static_cast<uint32_t>(ACCSC_stCutinTrgtDtctd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutintrgtid_mp(static_cast<uint32_t>(ACCSC_stCutinTrgtId_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutintrgtindx_mp(
    static_cast<uint32_t>(ACCSC_stCutinTrgtIndx_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stcutintrgtturnindctron_mp(
    static_cast<uint32_t>(ACCSC_stCutinTrgtTurnIndctrOn_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_stdrvsprstsrsetspdidn_mp(
  //   static_cast<uint32_t>(ACCSC_stDrvSprsTSRSetSpdIdN_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stedadecsts_mp(static_cast<uint32_t>(ACCSC_stEDADecSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stedasts_mp(static_cast<uint32_t>(ACCSC_stEDASts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stfam_dalccsts_mp(static_cast<uint32_t>(ACCSC_stFAM_DALccSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stfam_damainsts_mp(
    static_cast<uint32_t>(ACCSC_stFAM_DAMainSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stfam_dasdcsts_mp(static_cast<uint32_t>(ACCSC_stFAM_DASdcSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stfsrain_mp(static_cast<uint32_t>(ACCSC_stFsRain_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sthostsfrcapsensor_mp(
    static_cast<uint32_t>(ACCSC_stHOStsFrCapSensor_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stlohmimpsbst_mp(static_cast<uint32_t>(ACCSC_stLohmImpsbSt_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stprsspddecbtn_mp(static_cast<uint32_t>(ACCSC_stPrsSpdDecBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stprsspdincbtn_mp(static_cast<uint32_t>(ACCSC_stPrsSpdIncBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stspddecbtn_mp(static_cast<uint32_t>(ACCSC_stSpdDecBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stspdincbtn_mp(static_cast<uint32_t>(ACCSC_stSpdIncBtn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stspdlmttakeover_mp(
    static_cast<uint32_t>(ACCSC_stSpdLmtTakeover_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stspdsynafterdrvchng_mp(
    static_cast<uint32_t>(ACCSC_stSpdSynAfterDrvChng_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttsrspdlmtsignconfcchk_mp(
    static_cast<uint32_t>(ACCSC_stTSRSpdLmtSignConfCChk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttaugapchgdispout_mp(
    static_cast<uint32_t>(ACCSC_stTauGapChgDispOut_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttaugapchgdisp_mp(
    static_cast<uint32_t>(ACCSC_stTauGapChgDisp_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtblinkerinfotar1_mp(
    static_cast<uint32_t>(ACCSC_stTgtBlinkerInfoTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtblinkerinfotar2_mp(
    static_cast<uint32_t>(ACCSC_stTgtBlinkerInfoTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtblinkerinfotar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtBlinkerInfoTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtblinkerinfotar_mp(
    static_cast<uint32_t>(ACCSC_stTgtBlinkerInfoTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtbrakelightstar1_mp(
    static_cast<uint32_t>(ACCSC_stTgtBrakeLightsTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtbrakelightstar2_mp(
    static_cast<uint32_t>(ACCSC_stTgtBrakeLightsTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtbrakelightstar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtBrakeLightsTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtbrakelightstar_mp(
    static_cast<uint32_t>(ACCSC_stTgtBrakeLightsTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtfusiontar1_mp(
    static_cast<uint32_t>(ACCSC_stTgtFusionTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtfusiontar2_mp(
    static_cast<uint32_t>(ACCSC_stTgtFusionTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtfusiontar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtFusionTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtfusiontar_mp(static_cast<uint32_t>(ACCSC_stTgtFusionTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtmissexceptiontar1_mp(
    static_cast<uint32_t>(ACCSC_stTgtMissExceptionTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtmissexceptiontar2_mp(
    static_cast<uint32_t>(ACCSC_stTgtMissExceptionTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtmissexceptiontar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtMissExceptionTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtmissexceptiontar_mp(
    static_cast<uint32_t>(ACCSC_stTgtMissExceptionTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtstatustar1_mp(
    static_cast<uint32_t>(ACCSC_stTgtStatusTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtstatustar2_mp(
    static_cast<uint32_t>(ACCSC_stTgtStatusTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtstatustar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtStatusTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtstatustar_mp(static_cast<uint32_t>(ACCSC_stTgtStatusTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgttypetar1_mp(static_cast<uint32_t>(ACCSC_stTgtTypeTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgttypetar2_mp(static_cast<uint32_t>(ACCSC_stTgtTypeTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgttypetar32_mp(static_cast<uint32_t>(ACCSC_stTgtTypeTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgttypetar_mp(static_cast<uint32_t>(ACCSC_stTgtTypeTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtvalidtar1_mp(static_cast<uint32_t>(ACCSC_stTgtValidTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtvalidtar2_mp(static_cast<uint32_t>(ACCSC_stTgtValidTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtvalidtar32_mp(
    static_cast<uint32_t>(ACCSC_stTgtValidTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttgtvalidtar_mp(static_cast<uint32_t>(ACCSC_stTgtValidTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sttrailermodreq_mp(
    static_cast<uint32_t>(ACCSC_stTrailerModReq_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stturnleftsts_mp(static_cast<bool>(ACCSC_stTurnLeftSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stturnrhtsts_mp(static_cast<bool>(ACCSC_stTurnRhtSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stupdttsrsetspdmode_mp(
    static_cast<uint32_t>(ACCSC_stUpdtTSRSetSpdMode_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stupdttsrspdlmtattrout_mp(
    static_cast<uint32_t>(ACCSC_stUpdtTSRSpdLmtAttrOut_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stupdttsrspdlmtconfchk_mp(
    static_cast<uint32_t>(ACCSC_stUpdtTSRSpdLmtConfChk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stupdttsrsupsignattrchk_mp(
    static_cast<uint32_t>(ACCSC_stUpdtTSRSupSignAttrChk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_stvlcreqfct_mp(static_cast<uint32_t>(ACCSC_stVlcReqFct_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtlengthtar1_mp(static_cast<double>(ACCSC_szTgtLengthTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtlengthtar2_mp(static_cast<double>(ACCSC_szTgtLengthTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtlengthtar32_mp(
    static_cast<double>(ACCSC_szTgtLengthTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtlengthtar_mp(static_cast<double>(ACCSC_szTgtLengthTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtwidthtar1_mp(static_cast<double>(ACCSC_szTgtWidthTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtwidthtar2_mp(static_cast<double>(ACCSC_szTgtWidthTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtwidthtar32_mp(static_cast<double>(ACCSC_szTgtWidthTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_sztgtwidthtar_mp(static_cast<double>(ACCSC_szTgtWidthTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ticutintime_mp(static_cast<double>(ACCSC_tiCutinTime_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ticutintrgtttc_mp(static_cast<double>(ACCSC_tiCutinTrgtTTC_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tilecutintrgt3time_mp(
    static_cast<double>(ACCSC_tiLeCutinTrgt3Time_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tilecutintrgt4time_mp(
    static_cast<double>(ACCSC_tiLeCutinTrgt4Time_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tinormheadway2_mp(static_cast<double>(ACCSC_tiNormHeadway2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tinormheadway_mp(static_cast<double>(ACCSC_tiNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tioverridertimer_mp(
    static_cast<double>(ACCSC_tiOverriderTimer_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar1largernormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar1LargerNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar1minnormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar1MinNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar1normheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar1NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar3largernormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar3LargerNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar3minnormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar3MinNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar3normheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar3NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar5largernormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar5LargerNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar5minnormheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar5MinNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiovrtktar5normheadway_mp(
    static_cast<double>(ACCSC_tiOvrtkTar5NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiricutintrgt5time_mp(
    static_cast<double>(ACCSC_tiRiCutinTrgt5Time_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiricutintrgt6time_mp(
    static_cast<double>(ACCSC_tiRiCutinTrgt6Time_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tisysbrkonlytimer_mp(
    static_cast<double>(ACCSC_tiSysBrkOnlyTimer_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titgraincorr_mp(static_cast<double>(ACCSC_tiTgRainCorr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titgtttctar1_mp(static_cast<double>(ACCSC_tiTgtTTCTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titgtttctar2_mp(static_cast<double>(ACCSC_tiTgtTTCTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titgtttctar32_mp(static_cast<double>(ACCSC_tiTgtTTCTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titgtttctar_mp(static_cast<double>(ACCSC_tiTgtTTCTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titimegapraw_mp(static_cast<double>(ACCSC_tiTimeGapRaw_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_titimegap_mp(static_cast<double>(ACCSC_tiTimeGap_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiundtktar1normheadway_mp(
    static_cast<double>(ACCSC_tiUndtkTar1NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiundtktarcipvnormheadway_mp(
    static_cast<double>(ACCSC_tiUndtkTarCipvNormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiundtktarn1normheadway_mp(
    static_cast<double>(ACCSC_tiUndtkTarN1NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiundtktarn2normheadway_mp(
    static_cast<double>(ACCSC_tiUndtkTarN2NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tiundtktarn3normheadway_mp(
    static_cast<double>(ACCSC_tiUndtkTarN3NormHeadway_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_tilatdistchecktimeintg_mp(
    static_cast<double>(ACCSC_tilatDistCheckTimeIntg_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uactprev1_mp(static_cast<uint32_t>(ACCSC_uActPrev1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uactprev2_mp(static_cast<uint32_t>(ACCSC_uActPrev2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uactprev_mp(static_cast<uint32_t>(ACCSC_uActPrev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uaebfun_mp(static_cast<uint32_t>(ACCSC_uAebFun_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uamclkssprs_mp(static_cast<uint32_t>(ACCSC_uAmcLksSprs_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uatndmdsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uAtnDmdSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uatndmdsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uAtnDmdSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubcufalut_mp(static_cast<uint32_t>(ACCSC_uBcuFalut_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubitmasknopdrvoffcdn_mp(
    static_cast<uint32_t>(ACCSC_uBitMaskNopDrvOffCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubitmaskpilot2nopcdn_mp(
    static_cast<uint32_t>(ACCSC_uBitMaskPilot2NOPCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubrksysadsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uBrkSysADSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubrksysadsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uBrkSysADSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubrksystdsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uBrkSysTDSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ubrksystdsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uBrkSysTDSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucddrvrcmplied_mp(static_cast<uint32_t>(ACCSC_uCdDrvrCmplied_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucdndrvrdeactv_mp(static_cast<uint32_t>(ACCSC_uCdnDrvrDeactv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucdnimmediateoff_mp(
    static_cast<uint32_t>(ACCSC_uCdnImmediateOff_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucdnnpsyspsv_mp(static_cast<uint32_t>(ACCSC_uCdnNpSysPsv_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucdnpassive_mp(static_cast<uint32_t>(ACCSC_uCdnPassive_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucdnstby_mp(static_cast<uint32_t>(ACCSC_uCdnStby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ucompfault_mp(static_cast<uint32_t>(ACCSC_uCompFault_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_udrvabsentdrvg_mp(static_cast<uint32_t>(ACCSC_uDrvAbsentDrvg_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_udrvabsentstst_mp(static_cast<uint32_t>(ACCSC_uDrvAbsentStst_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_udrvattntavlbadsoftinh_mp(
    static_cast<uint32_t>(ACCSC_uDrvAttntAvlbADSoftInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_udrvattntavlbtdsoftinh_mp(
    static_cast<uint32_t>(ACCSC_uDrvAttntAvlbTDSoftInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ueastrghardinh1_mp(
    static_cast<uint32_t>(ACCSC_uEASTrgHardInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ueastrghardinh2_mp(
    static_cast<uint32_t>(ACCSC_uEASTrgHardInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ueastrginmannualmode_mp(
    static_cast<uint32_t>(ACCSC_uEASTrgInMannualMode_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uedaactv2standby_mp(
    static_cast<uint32_t>(ACCSC_uEDAActv2Standby_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uedacdn_mp(static_cast<uint32_t>(ACCSC_uEDACdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uedafault_mp(static_cast<uint32_t>(ACCSC_uEDAFault_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uepsfault_mp(static_cast<uint32_t>(ACCSC_uEPSFault_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ueq4faultinhovtk_mp(
    static_cast<uint32_t>(ACCSC_uEQ4FaultInhOvtk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uemrgbrkhardinh_mp(
    static_cast<uint32_t>(ACCSC_uEmrgBrkHardInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uescfun_mp(static_cast<uint32_t>(ACCSC_uEscFun_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufailsafetdsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uFailSafeTDSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufaultsiinhibyte18to1f_mp(
    static_cast<uint32_t>(ACCSC_uFaultSiInhiByte18To1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimadsoftinh1_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimadsoftinh2_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimadsoftinh3_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte08_mp(static_cast<uint32_t>(ACCSC_uFimHiByte08_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte09_mp(static_cast<uint32_t>(ACCSC_uFimHiByte09_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0a_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0A_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0b_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0B_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0c_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0C_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0d_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0D_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0e_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0E_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte0f_mp(static_cast<uint32_t>(ACCSC_uFimHiByte0F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte10_mp(static_cast<uint32_t>(ACCSC_uFimHiByte10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte11_mp(static_cast<uint32_t>(ACCSC_uFimHiByte11_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte12_mp(static_cast<uint32_t>(ACCSC_uFimHiByte12_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte13_mp(static_cast<uint32_t>(ACCSC_uFimHiByte13_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte14_mp(static_cast<uint32_t>(ACCSC_uFimHiByte14_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte15_mp(static_cast<uint32_t>(ACCSC_uFimHiByte15_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte16_mp(static_cast<uint32_t>(ACCSC_uFimHiByte16_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte17_mp(static_cast<uint32_t>(ACCSC_uFimHiByte17_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte18_mp(static_cast<uint32_t>(ACCSC_uFimHiByte18_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte19_mp(static_cast<uint32_t>(ACCSC_uFimHiByte19_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1a_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1A_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1b_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1B_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1c_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1C_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1d_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1D_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1e_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1E_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte1f_mp(static_cast<uint32_t>(ACCSC_uFimHiByte1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte20_mp(static_cast<uint32_t>(ACCSC_uFimHiByte20_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte21_mp(static_cast<uint32_t>(ACCSC_uFimHiByte21_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte22_mp(static_cast<uint32_t>(ACCSC_uFimHiByte22_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte23_mp(static_cast<uint32_t>(ACCSC_uFimHiByte23_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte24_mp(static_cast<uint32_t>(ACCSC_uFimHiByte24_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte25_mp(static_cast<uint32_t>(ACCSC_uFimHiByte25_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimhibyte26_mp(static_cast<uint32_t>(ACCSC_uFimHiByte26_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte08_mp(static_cast<uint32_t>(ACCSC_uFimSiByte08_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte09_mp(static_cast<uint32_t>(ACCSC_uFimSiByte09_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0a_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0A_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0b_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0B_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0c_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0C_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0d_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0D_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0e_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0E_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte0f_mp(static_cast<uint32_t>(ACCSC_uFimSiByte0F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte10_mp(static_cast<uint32_t>(ACCSC_uFimSiByte10_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte11_mp(static_cast<uint32_t>(ACCSC_uFimSiByte11_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte12_mp(static_cast<uint32_t>(ACCSC_uFimSiByte12_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte13_mp(static_cast<uint32_t>(ACCSC_uFimSiByte13_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte14_mp(static_cast<uint32_t>(ACCSC_uFimSiByte14_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte15_mp(static_cast<uint32_t>(ACCSC_uFimSiByte15_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte16_mp(static_cast<uint32_t>(ACCSC_uFimSiByte16_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte17_mp(static_cast<uint32_t>(ACCSC_uFimSiByte17_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte18_mp(static_cast<uint32_t>(ACCSC_uFimSiByte18_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte19_mp(static_cast<uint32_t>(ACCSC_uFimSiByte19_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1a_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1A_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1b_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1B_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1c_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1C_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1d_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1D_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1e_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1E_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte1f_mp(static_cast<uint32_t>(ACCSC_uFimSiByte1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte20_mp(static_cast<uint32_t>(ACCSC_uFimSiByte20_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte21_mp(static_cast<uint32_t>(ACCSC_uFimSiByte21_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte22_mp(static_cast<uint32_t>(ACCSC_uFimSiByte22_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte23_mp(static_cast<uint32_t>(ACCSC_uFimSiByte23_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte24_mp(static_cast<uint32_t>(ACCSC_uFimSiByte24_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte25_mp(static_cast<uint32_t>(ACCSC_uFimSiByte25_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimsibyte26_mp(static_cast<uint32_t>(ACCSC_uFimSiByte26_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimtdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimtdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimtdsoftinh3_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimtdsoftinh4_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh4_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ufimtdsoftinh5_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh5_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhostsad_mp(static_cast<bool>(ACCSC_uHOStsAD_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhoststd_mp(static_cast<bool>(ACCSC_uHOStsTD_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhardinh1_mp(static_cast<uint32_t>(ACCSC_uHardInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhardinh2_mp(static_cast<uint32_t>(ACCSC_uHardInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhardinh3_mp(static_cast<uint32_t>(ACCSC_uHardInh3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhardinh4_mp(static_cast<uint32_t>(ACCSC_uHardInh4_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhdtraopen_mp(static_cast<uint32_t>(ACCSC_uHdTrAOpen_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhibyte08to0f_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiByte08To0F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhibyte10to17_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiByte10To17_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhibyte18to1f_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiByte18To1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhibyte20to27_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiByte20To27_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhinop00_mp(static_cast<uint32_t>(ACCSC_uHiInhiNOP00_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhinop01_mp(static_cast<uint32_t>(ACCSC_uHiInhiNOP01_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte10to17forsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte10To17ForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte10to17_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte10To17_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte18to1fforsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte18To1FForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte18to1f_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte18To1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte20to27forsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte20To27ForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte20to27_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte20To27_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte30to37forsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte30To37ForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbyte30to37_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByte30To37_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhipilotbytefctfimforsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhiPilotByteFctFimForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhopilotbyte08to0fforsymbol_mp(
    static_cast<uint32_t>(ACCSC_uHiInhoPilotByte08To0FForSymbol_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uhiinhopilotbyte08to0f_mp(
    static_cast<uint32_t>(ACCSC_uHiInhoPilotByte08To0F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uinhiforadcplatformfailsts_mp(
    static_cast<uint32_t>(ACCSC_uInhiForADCPlatformFailSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ulongcdn_mp(static_cast<uint32_t>(ACCSC_uLongCdn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_ulosscom_mp(static_cast<uint32_t>(ACCSC_uLossCom_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_unopactivationprevention_mp(
    static_cast<uint32_t>(ACCSC_uNOPActivationPrevention_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_unopsuppression_mp(
    static_cast<uint32_t>(ACCSC_uNOPSuppression_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_unonfaultsiinhibyte18to1f_mp(
    static_cast<uint32_t>(ACCSC_uNonFaultSiInhiByte18To1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uovrtkinh_mp(static_cast<uint32_t>(ACCSC_uOvrtkInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uovrtkmodchk_mp(static_cast<uint32_t>(ACCSC_uOvrtkModChk_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uovtkendexit_mp(static_cast<uint32_t>(ACCSC_uOvtkEndExit_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uovtkstrngwhlend_mp(
    static_cast<uint32_t>(ACCSC_uOvtkStrngWhlEnd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_upssgrdr_mp(static_cast<uint32_t>(ACCSC_uPssgrDr_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uresuprev1_mp(static_cast<uint32_t>(ACCSC_uResuPrev1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uresuprev_mp(static_cast<uint32_t>(ACCSC_uResuPrev_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uslifspdnupdatecndn_mp(
    static_cast<uint32_t>(ACCSC_uSLIFSpdNUpdateCndn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_useatbltunbck_mp(static_cast<bool>(ACCSC_uSeatBltUnbck_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usiinhibyte08to0f_mp(
    static_cast<uint32_t>(ACCSC_uSiInhiByte08To0F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usiinhibyte10to17_mp(
    static_cast<uint32_t>(ACCSC_uSiInhiByte10To17_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usiinhibyte18to1f_mp(
    static_cast<uint32_t>(ACCSC_uSiInhiByte18To1F_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usiinhibyte20to27_mp(
    static_cast<uint32_t>(ACCSC_uSiInhiByte20To27_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usoftinh1_mp(static_cast<uint32_t>(ACCSC_uSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_usoftinh2_mp(static_cast<uint32_t>(ACCSC_uSoftInh2_mp));
  // fct_debug_out.mutable_accsc_debug_out()->set_accsc_uspdlmtvluaftchsupdtcndn_mp(
  //   static_cast<uint32_t>(ACCSC_uSpdLmtVluAftChsUpdtCndn_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_utkovdmdcdcsts_mp(static_cast<uint32_t>(ACCSC_uTkovDmdCDCSts_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_utkovdmdsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_utkovdmdsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_utkovdmdsoftinh3_mp(
    static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uupdttsrsetspd_mp(static_cast<uint32_t>(ACCSC_uUpdtTSRSetSpd_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uvehstateinh_mp(static_cast<uint32_t>(ACCSC_uVehStateInh_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uvehstbadsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uVehStbADSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uvehstbadsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uVehStbADSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uvehstbtdsoftinh1_mp(
    static_cast<uint32_t>(ACCSC_uVehStbTDSoftInh1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_uvehstbtdsoftinh2_mp(
    static_cast<uint32_t>(ACCSC_uVehStbTDSoftInh2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlatveltar1_mp(static_cast<double>(ACCSC_vTgtLatVelTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlatveltar2_mp(static_cast<double>(ACCSC_vTgtLatVelTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlatveltar32_mp(static_cast<double>(ACCSC_vTgtLatVelTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlatveltar_mp(static_cast<double>(ACCSC_vTgtLatVelTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlonveltar1_mp(static_cast<double>(ACCSC_vTgtLonVelTar1_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlonveltar2_mp(static_cast<double>(ACCSC_vTgtLonVelTar2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlonveltar32_mp(static_cast<double>(ACCSC_vTgtLonVelTar32_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_vtgtlonveltar_mp(static_cast<double>(ACCSC_vTgtLonVelTar_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xc2_mp(static_cast<double>(ACCSC_xC2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xc3_mp(static_cast<double>(ACCSC_xC3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xhppc2_mp(static_cast<double>(ACCSC_xHPPC2_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xhppc3_mp(static_cast<double>(ACCSC_xHPPC3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xlmc3_mp(static_cast<double>(ACCSC_xLMC3_mp));
  fct_debug_out.mutable_accsc_debug_out()->set_accsc_xlacurv_mp(static_cast<double>(ACCSC_xLaCurv_mp));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_xorgroadcurvevalid_mp(
    static_cast<bool>(ACCSC_xOrgRoadCurveValid_mp[0]));
  fct_debug_out.mutable_accsc_debug_out()->add_accsc_xorgroadcurvevalue_mp(
    static_cast<double>(ACCSC_xOrgRoadCurveValue_mp[0]));
}

void hwasm_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_accnpsts_mp(static_cast<uint32_t>(HWASM_AccNpSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnact2stbysttimer_mp(
    static_cast<bool>(HWASM_CdnAct2StByStTimer_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnactprev_mp(static_cast<bool>(HWASM_CdnActPrev_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdncruisesw_mp(static_cast<bool>(HWASM_CdnCruiseSw_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnlatinh_mp(static_cast<bool>(HWASM_CdnLatInh_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnloninh_mp(static_cast<bool>(HWASM_CdnLonInh_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnlonstby_mp(static_cast<bool>(HWASM_CdnLonStby_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnpilotsw_mp(static_cast<bool>(HWASM_CdnPilotSw_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnresubygaspdl_mp(static_cast<bool>(HWASM_CdnResuByGasPdl_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnresuprev_mp(static_cast<bool>(HWASM_CdnResuPrev_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnresumesw_mp(static_cast<bool>(HWASM_CdnResumeSw_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysactbyovrd_mp(static_cast<bool>(HWASM_CdnSysActByOvrd_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysdrvoff_mp(static_cast<bool>(HWASM_CdnSysDrvOff_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysinit_mp(static_cast<bool>(HWASM_CdnSysInit_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysnoinit_mp(static_cast<bool>(HWASM_CdnSysNoInit_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysnonswstby_mp(static_cast<bool>(HWASM_CdnSysNonSwStby_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsyspassive_mp(static_cast<bool>(HWASM_CdnSysPassive_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_gpsmode_mp(static_cast<uint32_t>(HWASM_GpsMode_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rtkfusionflag_mp(static_cast<uint32_t>(HWASM_RtkFusionFlag_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlatctrl_mp(static_cast<uint32_t>(HWASM_StLatCtrl_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlongctrl_mp(static_cast<uint32_t>(HWASM_StLongCtrl_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlongintvst_mp(static_cast<uint32_t>(HWASM_StLongIntvSt_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlongintvtype_mp(static_cast<uint32_t>(HWASM_StLongIntvType_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stniopilot_mp(static_cast<uint32_t>(HWASM_StNIOPilot_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stnpstsd_mp(static_cast<uint32_t>(HWASM_StNpStsD_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stdummy_mp(static_cast<uint32_t>(HWASM_Stdummy_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_swcruise_mp(static_cast<uint32_t>(HWASM_SwCruise_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_swpilot_mp(static_cast<uint32_t>(HWASM_SwPilot_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnfaultdeact_mp(static_cast<bool>(HWASM_cdnFaultDeact_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnlatspraccsts_mp(static_cast<bool>(HWASM_cdnLatSprAccSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnlcsyspsv_mp(static_cast<bool>(HWASM_cdnLcSysPsv_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnnpactprev_mp(static_cast<bool>(HWASM_cdnNpActPrev_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnnpresuprev_mp(static_cast<bool>(HWASM_cdnNpResuPrev_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnnpsyspsv_mp(static_cast<bool>(HWASM_cdnNpSysPsv_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnpilotfaultdeactv_mp(
    static_cast<bool>(HWASM_cdnPilotFaultDeactv_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnpilothodspr_mp(static_cast<bool>(HWASM_cdnPilotHodSpr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_cdnsysbrkonly_mp(static_cast<bool>(HWASM_cdnSysBrkOnly_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgacccfgd_mp(static_cast<bool>(HWASM_flgAccCfgd_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgacmlatctrl_mp(static_cast<bool>(HWASM_flgAcmLatCtrl_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgcdcnaviinforeliable_mp(
    static_cast<bool>(HWASM_flgCDCNaviInfoReliable_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flggpsisready_mp(static_cast<bool>(HWASM_flgGpsIsReady_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flghandoffsts_mp(static_cast<uint32_t>(HWASM_flgHandoffSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flghodtakeover_mp(static_cast<bool>(HWASM_flgHodTakeOver_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flghodwarnspr_mp(static_cast<bool>(HWASM_flgHodWarnSpr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgisinacc_mp(static_cast<bool>(HWASM_flgIsInAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgisinpilot_mp(static_cast<bool>(HWASM_flgIsInPilot_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flglatctrlon_mp(static_cast<bool>(HWASM_flgLatCtrlOn_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flglocisnotready_mp(static_cast<bool>(HWASM_flgLocIsNotReady_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flglocmapisready_mp(static_cast<bool>(HWASM_flgLocMapIsReady_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgmapdatauptodate_mp(
    static_cast<bool>(HWASM_flgMapDataUptoDate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgmapisready_mp(static_cast<bool>(HWASM_flgMapIsReady_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnplatfailsym_mp(static_cast<bool>(HWASM_flgNPLatFailSym_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnavion_mp(static_cast<bool>(HWASM_flgNaviOn_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnopcfgd_mp(static_cast<bool>(HWASM_flgNopCfgd_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnopon_mp(static_cast<bool>(HWASM_flgNopOn_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnopswitchon_mp(static_cast<bool>(HWASM_flgNopSwitchOn_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgpilotcfgd_mp(static_cast<bool>(HWASM_flgPilotCfgd_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgrtkisready_mp(static_cast<bool>(HWASM_flgRtkIsReady_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgrtkisstable_mp(static_cast<bool>(HWASM_flgRtkIsStable_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgsysact2stbystti_mp(
    static_cast<bool>(HWASM_flgSysAct2StByStTi_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgisnopactv_mp(static_cast<bool>(HWASM_flgisNopActv_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_staccnpactvsts_mp(static_cast<uint32_t>(HWASM_stAccNpActvSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_staccsym_mp(static_cast<uint32_t>(HWASM_stAccSym_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stacctrgr_mp(static_cast<uint32_t>(HWASM_stAccTrgr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stdoorunlckreq_mp(static_cast<uint32_t>(HWASM_stDoorUnlckReq_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stherobuttonmode_mp(
    static_cast<uint32_t>(HWASM_stHeroButtonMode_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stherobuttonmodell_mp(
    static_cast<uint32_t>(HWASM_stHeroButtonModell_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stherobuttonpress_mp(
    static_cast<uint32_t>(HWASM_stHeroButtonPress_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_sthodwarnseq_mp(static_cast<uint32_t>(HWASM_stHodWarnSeq_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_sthzrdlireq_mp(static_cast<uint32_t>(HWASM_stHzrdLiReq_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlatautoeng_mp(static_cast<uint32_t>(HWASM_stLatAutoEng_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlkssysst_mp(static_cast<uint32_t>(HWASM_stLksSysSt_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stnaddasts_mp(static_cast<uint32_t>(HWA_out.HWASM.NadSts));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stnopmainswitch_mp(
    static_cast<uint32_t>(HWASM_stNopMainSwitch_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stpilotsym_mp(static_cast<uint32_t>(HWASM_stPilotSym_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stpilottrgr_mp(static_cast<uint32_t>(HWASM_stPilotTrgr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ststandststs_mp(static_cast<uint32_t>(HWASM_stStandStSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_tihodseqtimer_mp(static_cast<double>(HWASM_tiHodSeqTimer_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_tipswoffsprthr_mp(static_cast<double>(HWASM_tiPswOffSprThr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_tipswoffspr_mp(static_cast<double>(HWASM_tiPswOffSpr_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_unopsts_mp(static_cast<uint32_t>(HWASM_uNopSts_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_lonctltaraccel_mp(static_cast<float>(HWASM_LonCtlTarAccel_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj11valid_mp(static_cast<bool>(HWASM_Obj11Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj12valid_mp(static_cast<bool>(HWASM_Obj12Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj1valid_mp(static_cast<bool>(HWASM_Obj1Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj7valid_mp(static_cast<bool>(HWASM_Obj7Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj8valid_mp(static_cast<bool>(HWASM_Obj8Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_obj9valid_mp(static_cast<bool>(HWASM_Obj9Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range11_mp(static_cast<float>(HWASM_Range11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range12_mp(static_cast<float>(HWASM_Range12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range1_mp(static_cast<float>(HWASM_Range1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range4_mp(static_cast<float>(HWASM_Range4_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range6_mp(static_cast<float>(HWASM_Range6_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range7_mp(static_cast<float>(HWASM_Range7_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range8_mp(static_cast<float>(HWASM_Range8_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_range9_mp(static_cast<float>(HWASM_Range9_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate11_mp(static_cast<float>(HWASM_RangeRate11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate12_mp(static_cast<float>(HWASM_RangeRate12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate1_mp(static_cast<float>(HWASM_RangeRate1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate4_mp(static_cast<float>(HWASM_RangeRate4_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate6_mp(static_cast<float>(HWASM_RangeRate6_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate7_mp(static_cast<float>(HWASM_RangeRate7_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate8_mp(static_cast<float>(HWASM_RangeRate8_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rangerate9_mp(static_cast<float>(HWASM_RangeRate9_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone11_mp(static_cast<float>(HWASM_Rawscore4Zone11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone12_mp(static_cast<float>(HWASM_Rawscore4Zone12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone13_mp(static_cast<float>(HWASM_Rawscore4Zone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone1_mp(static_cast<float>(HWASM_Rawscore4Zone1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone2_mp(static_cast<float>(HWASM_Rawscore4Zone2_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_rawscore4zone3_mp(static_cast<float>(HWASM_Rawscore4Zone3_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarindex_mp(
    static_cast<uint32_t>(HWASM_Zone11ReTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarlength_mp(
    static_cast<float>(HWASM_Zone11ReTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarrangerate_mp(
    static_cast<float>(HWASM_Zone11ReTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarrange_mp(static_cast<float>(HWASM_Zone11ReTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarvalid_mp(static_cast<bool>(HWASM_Zone11ReTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11retarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone11ReTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone11SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarlength_mp(
    static_cast<float>(HWASM_Zone11SiFrtTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone11SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarrange_mp(
    static_cast<float>(HWASM_Zone11SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone11SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone11SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone11tarid_mp(static_cast<uint32_t>(HWASM_Zone11TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone12SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone12SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12sifrttarrange_mp(
    static_cast<float>(HWASM_Zone12SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone12SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone12SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12siretarindex_mp(
    static_cast<uint32_t>(HWASM_Zone12SiReTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12siretarrangerate_mp(
    static_cast<float>(HWASM_Zone12SiReTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12siretarrange_mp(
    static_cast<float>(HWASM_Zone12SiReTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12siretarvalid_mp(
    static_cast<bool>(HWASM_Zone12SiReTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12siretarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone12SiReTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone12tarid_mp(static_cast<uint32_t>(HWASM_Zone12TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone13SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarlength_mp(
    static_cast<float>(HWASM_Zone13SiFrtTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone13SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarrange_mp(
    static_cast<float>(HWASM_Zone13SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone13SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone13SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarindex_mp(
    static_cast<uint32_t>(HWASM_Zone13SiRrTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarlength_mp(
    static_cast<float>(HWASM_Zone13SiRrTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarrangerate_mp(
    static_cast<float>(HWASM_Zone13SiRrTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarrange_mp(
    static_cast<float>(HWASM_Zone13SiRrTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarvalid_mp(
    static_cast<bool>(HWASM_Zone13SiRrTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13sirrtarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone13SiRrTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone13tarid_mp(static_cast<uint32_t>(HWASM_Zone13TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarindex_mp(
    static_cast<uint32_t>(HWASM_Zone1ReTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarlength_mp(static_cast<float>(HWASM_Zone1ReTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarrangerate_mp(
    static_cast<float>(HWASM_Zone1ReTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarrange_mp(static_cast<float>(HWASM_Zone1ReTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarvalid_mp(static_cast<bool>(HWASM_Zone1ReTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1retarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone1ReTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone1SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarlength_mp(
    static_cast<float>(HWASM_Zone1SiFrtTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone1SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarrange_mp(
    static_cast<float>(HWASM_Zone1SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone1SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone1SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone1tarid_mp(static_cast<uint32_t>(HWASM_Zone1TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone2SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone2SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2sifrttarrange_mp(
    static_cast<float>(HWASM_Zone2SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone2SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone2SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2siretarindex_mp(
    static_cast<uint32_t>(HWASM_Zone2SiReTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2siretarrangerate_mp(
    static_cast<float>(HWASM_Zone2SiReTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2siretarrange_mp(
    static_cast<float>(HWASM_Zone2SiReTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2siretarvalid_mp(
    static_cast<bool>(HWASM_Zone2SiReTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2siretarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone2SiReTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone2tarid_mp(static_cast<uint32_t>(HWASM_Zone2TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarindex_mp(
    static_cast<uint32_t>(HWASM_Zone3SiFrtTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarlength_mp(
    static_cast<float>(HWASM_Zone3SiFrtTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarrangerate_mp(
    static_cast<float>(HWASM_Zone3SiFrtTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarrange_mp(
    static_cast<float>(HWASM_Zone3SiFrtTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarvalid_mp(
    static_cast<bool>(HWASM_Zone3SiFrtTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sifrttarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone3SiFrtTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarindex_mp(
    static_cast<uint32_t>(HWASM_Zone3SiRrTarIndex_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarlength_mp(
    static_cast<float>(HWASM_Zone3SiRrTarLength_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarrangerate_mp(
    static_cast<float>(HWASM_Zone3SiRrTarRangeRate_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarrange_mp(
    static_cast<float>(HWASM_Zone3SiRrTarRange_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarvalid_mp(
    static_cast<bool>(HWASM_Zone3SiRrTarValid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3sirrtarnumid_mp(
    static_cast<uint32_t>(HWASM_Zone3SiRrTarnumID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_zone3tarid_mp(static_cast<uint32_t>(HWASM_Zone3TarID_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_aaccel2sidefrttar4zone12_mp(
    static_cast<float>(HWASM_aAccel2SideFrtTar4Zone12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_aaccel2sidefrttar4zone13_mp(
    static_cast<float>(HWASM_aAccel2SideFrtTar4Zone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_aaccel2sidefrttar4zone2_mp(
    static_cast<float>(HWASM_aAccel2SideFrtTar4Zone2_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_aaccel2sidefrttar4zone3_mp(
    static_cast<float>(HWASM_aAccel2SideFrtTar4Zone3_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar11lonacc_mp(static_cast<float>(HWASM_aTar11LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar12lonacc_mp(static_cast<float>(HWASM_aTar12LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar1lonacc_mp(static_cast<float>(HWASM_aTar1LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar7lonacc_mp(static_cast<float>(HWASM_aTar7LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar8lonacc_mp(static_cast<float>(HWASM_aTar8LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_atar9lonacc_mp(static_cast<float>(HWASM_aTar9LonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone11retarlonacc_mp(
    static_cast<float>(HWASM_aZone11ReTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone11sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone11SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone12sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone12SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone12siretarlonacc_mp(
    static_cast<float>(HWASM_aZone12SiReTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone13sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone13SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone13sirrtarlonacc_mp(
    static_cast<float>(HWASM_aZone13SiRrTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone1retarlonacc_mp(
    static_cast<float>(HWASM_aZone1ReTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone1sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone1SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone2sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone2SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone2siretarlonacc_mp(
    static_cast<float>(HWASM_aZone2SiReTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone3sifrttarlonacc_mp(
    static_cast<float>(HWASM_aZone3SiFrtTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_azone3sirrtarlonacc_mp(
    static_cast<float>(HWASM_aZone3SiRrTarLonAcc_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgdecisionlock_mp(static_cast<bool>(HWASM_flgDecisionLock_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgfrttarzone12ok_mp(
    static_cast<bool>(HWASM_flgFrtTarZone12OK_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flghostlogdistoknowzone12_mp(
    static_cast<bool>(HWASM_flgHostLogDistokNowZone12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgmodezone13_mp(static_cast<uint32_t>(HWASM_flgModeZone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgreartarzone12ok_mp(
    static_cast<bool>(HWASM_flgRearTarZone12OK_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgtar1zone12ok_mp(static_cast<bool>(HWASM_flgTar1Zone12OK_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone11valid_mp(static_cast<bool>(HWASM_flgZone11Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone12valid_mp(static_cast<bool>(HWASM_flgZone12Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone13valid_mp(static_cast<bool>(HWASM_flgZone13Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone1valid_mp(static_cast<bool>(HWASM_flgZone1Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone2valid_mp(static_cast<bool>(HWASM_flgZone2Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgzone3valid_mp(static_cast<bool>(HWASM_flgZone3Valid_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnear2sidefrttarzone13_mp(
    static_cast<bool>(HWASM_flgnear2SideFrtTarZone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_flgnear2tar1zone13_mp(
    static_cast<bool>(HWASM_flgnear2Tar1Zone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mlength9_mp(static_cast<float>(HWASM_mLength9_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone11decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone11Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone12decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone12Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone13decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone13Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone1decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone1Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone2decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone2Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mtardist4zone3decs_mp(
    static_cast<float>(HWASM_mTarDist4Zone3Decs_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj11vx_mp(static_cast<float>(HWASM_mpsObj11Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj12vx_mp(static_cast<float>(HWASM_mpsObj12Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj1vx_mp(static_cast<float>(HWASM_mpsObj1Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj7vx_mp(static_cast<float>(HWASM_mpsObj7Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj8vx_mp(static_cast<float>(HWASM_mpsObj8Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpsobj9vx_mp(static_cast<float>(HWASM_mpsObj9Vx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone11retarobjvx_mp(
    static_cast<float>(HWASM_mpsZone11ReTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone11sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone11SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone12sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone12SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone12siretarobjvx_mp(
    static_cast<float>(HWASM_mpsZone12SiReTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone13sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone13SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone13sirrtarobjvx_mp(
    static_cast<float>(HWASM_mpsZone13SiRrTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone1retarobjvx_mp(
    static_cast<float>(HWASM_mpsZone1ReTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone1sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone1SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone2sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone2SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone2siretarobjvx_mp(
    static_cast<float>(HWASM_mpsZone2SiReTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone3sifrttarobjvx_mp(
    static_cast<float>(HWASM_mpsZone3SiFrtTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_mpszone3sirrtarobjvx_mp(
    static_cast<float>(HWASM_mpsZone3SiRrTarObjVx_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar11_mp(static_cast<uint32_t>(HWASM_numIDTar11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar12_mp(static_cast<uint32_t>(HWASM_numIDTar12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar1_mp(static_cast<uint32_t>(HWASM_numIDTar1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar7_mp(static_cast<uint32_t>(HWASM_numIDTar7_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar8_mp(static_cast<uint32_t>(HWASM_numIDTar8_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numidtar9_mp(static_cast<uint32_t>(HWASM_numIDTar9_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar11index_mp(static_cast<uint32_t>(HWASM_numTar11Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar12index_mp(static_cast<uint32_t>(HWASM_numTar12Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar1index_mp(static_cast<uint32_t>(HWASM_numTar1Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar7index_mp(static_cast<uint32_t>(HWASM_numTar7Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar8index_mp(static_cast<uint32_t>(HWASM_numTar8Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_numtar9index_mp(static_cast<uint32_t>(HWASM_numTar9Index_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone11_mp(static_cast<float>(HWASM_score4Zone11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone12_mp(static_cast<float>(HWASM_score4Zone12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone13_mp(static_cast<float>(HWASM_score4Zone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone1_mp(static_cast<float>(HWASM_score4Zone1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone2_mp(static_cast<float>(HWASM_score4Zone2_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_score4zone3_mp(static_cast<float>(HWASM_score4Zone3_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_stlfzoneout_mp(static_cast<uint32_t>(HWASM_stLfZoneOut_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_strizoneout_mp(static_cast<uint32_t>(HWASM_stRiZoneOut_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone11_mp(static_cast<float>(HWASM_ti2TarDis4Zone11_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone12_mp(static_cast<float>(HWASM_ti2TarDis4Zone12_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone13_mp(static_cast<float>(HWASM_ti2TarDis4Zone13_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone1_mp(static_cast<float>(HWASM_ti2TarDis4Zone1_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone2_mp(static_cast<float>(HWASM_ti2TarDis4Zone2_mp));
  fct_debug_out.mutable_hwasm_debug_out()->set_hwasm_ti2tardis4zone3_mp(static_cast<float>(HWASM_ti2TarDis4Zone3_mp));
}

void hwa_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_flgdmsconcentration_mp(static_cast<bool>(HWA_flgDMSConcentration_mp));
  // fct_debug_out.mutable_hwa_debug_out()->set_hwa_flgdrvtkovdeactvnop_mp(static_cast<bool>(HWA_flgDrvTkovDeactvNop_mp));
  // fct_debug_out.mutable_hwa_debug_out()->set_hwa_flgdrvtkovsprnop_mp(static_cast<bool>(HWA_flgDrvTkovSprNop_mp));
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_flgnop2pilot_mp(static_cast<bool>(HWA_flgNop2Pilot_mp));
  // fct_debug_out.mutable_hwa_debug_out()->set_hwa_flgpilot2nop_mp(static_cast<bool>(HWA_flgPilot2NOP_mp));
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_stpilotedrtriggerreason_mp(
    static_cast<uint32_t>(HWA_stPilotEdrTriggerReason_mp));
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_stpilotedrtrigger_mp(static_cast<uint32_t>(HWA_stPilotEdrTrigger_mp));
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_amaxaccellim_mp(static_cast<float>(HWA_aMaxAccelLim_mp));
  fct_debug_out.mutable_hwa_debug_out()->set_hwa_aminaccellim_mp(static_cast<float>(HWA_aMinAccelLim_mp));
}

void latctrl_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfleoncmngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfLeOncmngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfleovrtkngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfLeOvrtkngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bflerdedgintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfLeRdEdgIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bflesldlineintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfLeSldLineIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfoncmngtrgtintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfOncmngTrgtIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfovrtkngtrgtintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfOvrtkngTrgtIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfovrtkngtrgtttcintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfOvrtkngTrgtTTCIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfrioncmngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfRiOncmngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfriovrtkngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfRiOvrtkngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfrirdedgintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfRiRdEdgIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfrisldlineintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfRiSldLineIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_bfsidetrgtfltdoutmsk_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_bfSideTrgtFltdOutMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_flgridashlinevld_mp(
    static_cast<bool>(LatCtrl_ElkRud_flgRiDashLineVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgcrrntlatpos_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgCrrntLatPos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgestegovehlatpos_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgEstEgoVehLatPos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgintvlatrngofst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgIntvLatRngOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgt2lncntrdst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgt2LnCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgtestdltrldst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgtEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgtttcegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgtTTCEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_moncmngtrgtttcegovehestdltrlrng_mp(
    static_cast<float>(LatCtrl_ElkRud_mOncmngTrgtTTCEgoVehEstdLtrlRng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgintvlatdstcalofst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgIntvLatDstCalOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgintvlatrngofst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgIntvLatRngOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgt2lncntrdst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgt2LnCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgtestdltrldst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgtEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgtttcegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgtTTCEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_movrtkngtrgtttcegovehestdltrlrng_mp(
    static_cast<float>(LatCtrl_ElkRud_mOvrtkngTrgtTTCEgoVehEstdLtrlRng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_msidetrgtfltdoutlnwdth_mp(
    static_cast<float>(LatCtrl_ElkRud_mSideTrgtFltdOutLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_msidetrgtfltdoutltrldstlmt_mp(
    static_cast<float>(LatCtrl_ElkRud_mSideTrgtFltdOutLtrlDstLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_pctintvcrsslineratiole_mp(
    static_cast<float>(LatCtrl_ElkRud_pctIntvCrssLineRatioLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_pctintvcrsslineratiori_mp(
    static_cast<float>(LatCtrl_ElkRud_pctIntvCrssLineRatioRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_soncmngtrgtttc_mp(
    static_cast<float>(LatCtrl_ElkRud_sOncmngTrgtTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_sovrtkngtrgtttc_mp(
    static_cast<float>(LatCtrl_ElkRud_sOvrtkngTrgtTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_stintvcasele_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_stIntvCaseLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_stintvcaseri_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_stIntvCaseRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_stoncmngtrgtlinedtctd_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_stOncmngTrgtLineDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_stovrtkngtrgtlinedtctd_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_stOvrtkngTrgtLineDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elkrud_strdedgdtctd_mp(
    static_cast<uint32_t>(LatCtrl_ElkRud_stRdEdgDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elksud_moncmngtrgintvlatdstcalofst_mp(
    static_cast<float>(LatCtrl_ElkSud_mOncmngTrgIntvLatDstCalOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskfunarbinfo_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskFunArbInfo_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfgensprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfGenSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfintvcase_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfIntvCase_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfleoncmngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeOncmngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfleovrtkngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeOvrtkngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflerdedgintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeRdEdgIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesldlineintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSldLineIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskfunarbinfo_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskFunArbInfo_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bflesprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfLeSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfoncmngtrgtintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfOncmngTrgtIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfovrtkngtrgtintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfOvrtkngTrgtIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfovrtkngtrgtttcintvenblmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfOvrtkngTrgtTTCIntvEnblMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrioncmngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiOncmngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfriovrtkngtrgtintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiOvrtkngTrgtIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrirdedgintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiRdEdgIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisldlineintvlineinfosprsmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSldLineIntvLineInfoSprsMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskfunarbinfo_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskFunArbInfo_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfrisprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfRiSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_bfsidetrgtfltdoutmsk_mp(
    static_cast<uint32_t>(LatCtrl_Elk_bfSideTrgtFltdOutMsk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_facexpctltrldstinactvblnd_mp(
    static_cast<float>(LatCtrl_Elk_facExpctLtrlDstInactvBlnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_facexpctltrldstleblnd_mp(
    static_cast<float>(LatCtrl_Elk_facExpctLtrlDstLeBlnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_facexpctltrldstriblnd_mp(
    static_cast<float>(LatCtrl_Elk_facExpctLtrlDstRiBlnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_flgelkleturnsprs_mp(
    static_cast<bool>(LatCtrl_Elk_flgElkLeTurnSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_flgledashlinevld_mp(
    static_cast<bool>(LatCtrl_Elk_flgLeDashLineVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_flglerdedgdtctd_mp(
    static_cast<bool>(LatCtrl_Elk_flgLeRdEdgDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_flgrirdedgdtctd_mp(
    static_cast<bool>(LatCtrl_Elk_flgRiRdEdgDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mdstveh2leoutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mDstVeh2LeOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mdstveh2rioutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mDstVeh2RiOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctinrznbrdtrgtshft_mp(
    static_cast<float>(LatCtrl_Elk_mExpctInrZnBrdTrgtShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctleinrznbrdaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLeInrZnBrdAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctleinrznbrd_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLeInrZnBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctlinelec0_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLineLeC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctlinelnc0_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLineLnC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctlinelnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLineLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctlineric0_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLineRiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctltrldsttoleline_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLtrlDstToLeLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctltrldsttoline_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLtrlDstToLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctltrldsttoriline_mp(
    static_cast<float>(LatCtrl_Elk_mExpctLtrlDstToRiLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctriinrznbrdaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mExpctRiInrZnBrdAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mexpctriinrznbrd_mp(
    static_cast<float>(LatCtrl_Elk_mExpctRiInrZnBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mlerdedgc0_mp(
    static_cast<float>(LatCtrl_Elk_mLeRdEdgC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgcrrntlatpos_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgCrrntLatPos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgestegovehlatpos_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgEstEgoVehLatPos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgintvlatdstcalofst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgIntvLatDstCalOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgintvlatrngofst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgIntvLatRngOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgt2lncntrdst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgt2LnCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtbrdshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtBrdShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtdstveh2leoutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtDstVeh2LeOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtdstveh2rioutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtDstVeh2RiOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtinrlezonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtInrLeZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtinrrizonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtInrRiZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtinrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtinrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtInrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtleinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtleinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtleoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtleoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtlezonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtlezonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLeZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtlnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtoutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtoutrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtOutrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtriinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtriinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtrioutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtrioutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtrizonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtrizonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtRiZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtttcegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtTTCEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtttcegovehestdltrlrng_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtTTCEgoVehEstdLtrlRng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtvirtdstle2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtVirtDstLe2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtvirtdstlncntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtVirtDstLnCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_moncmngtrgtvirtdstri2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOncmngTrgtVirtDstRi2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgintvlatdstcalofst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgIntvLatDstCalOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgintvlatrngofst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgIntvLatRngOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgt2lncntrdst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgt2LnCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtbrdshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtBrdShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtdstveh2leoutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtDstVeh2LeOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtdstveh2rioutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtDstVeh2RiOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtinrlezonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtInrLeZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtinrrizonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtInrRiZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtinrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtinrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtInrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtleinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtleinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtleoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtleoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtlezonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtlezonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLeZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtlnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtoutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtoutrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtOutrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtriinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtriinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtrioutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtrioutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtrizonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtrizonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtRiZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtttcegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtTTCEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtttcegovehestdltrlrng_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtTTCEgoVehEstdLtrlRng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtvirtdstle2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtVirtDstLe2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtvirtdstlncntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtVirtDstLnCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_movrtkngtrgtvirtdstri2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mOvrtkngTrgtVirtDstRi2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgdstveh2leoutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgDstVeh2LeOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgdstveh2rioutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgDstVeh2RiOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedginrlezonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgInrLeZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedginrrizonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgInrRiZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedginrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedginrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgInrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgleinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgleinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgleoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgleoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedglezonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedglezonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLeZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedglnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgoutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgoutrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgOutrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgriinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgriinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgrioutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgrioutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgrizonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgrizonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgRiZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgvirtdstle2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgVirtDstLe2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgvirtdstlncntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgVirtDstLnCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrdedgvirtdstri2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mRdEdgVirtDstRi2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mrirdedgc0_mp(
    static_cast<float>(LatCtrl_Elk_mRiRdEdgC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msidetrgtfltdoutlnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mSideTrgtFltdOutLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msidetrgtfltdoutltrldstlmt_mp(
    static_cast<float>(LatCtrl_Elk_mSideTrgtFltdOutLtrlDstLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinedstveh2leoutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineDstVeh2LeOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinedstveh2rioutrbrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineDstVeh2RiOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineegovehestdltrldst_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineEgoVehEstdLtrlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineinrlezonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineInrLeZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineinrrizonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineInrRiZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineinrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineinrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineInrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineleinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineleinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineleoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineleoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinelezonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinelezonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLeZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinelnwdth_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineLnWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineoutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineoutrzonebrdlnwdthshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineOutrZoneBrdLnWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineriinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlineriinrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinerioutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinerioutrzonebrd_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinerizonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinerizonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineRiZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinevirtdstle2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineVirtDstLe2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinevirtdstlncntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineVirtDstLnCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_msldlinevirtdstri2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mSldLineVirtDstRi2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mvirtdstlncntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Elk_mVirtDstLnCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mzonemgrprdvdst_mp(
    static_cast<float>(LatCtrl_Elk_mZoneMgrPrdvDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mpsegovehltrlspd_mp(
    static_cast<float>(LatCtrl_Elk_mpsEgoVehLtrlSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mpstrgtintvegovehlatvel_mp(
    static_cast<float>(LatCtrl_Elk_mpsTrgtIntvEgoVehLatVel_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_mpssegovehltrlaccl_mp(
    static_cast<float>(LatCtrl_Elk_mpssEgoVehLtrlAccl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctintvcrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctIntvCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctlerdedgconf_mp(
    static_cast<float>(LatCtrl_Elk_pctLeRdEdgConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctoncmngtrgtlecrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctOncmngTrgtLeCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctoncmngtrgtricrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctOncmngTrgtRiCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctovrtkngtrgtlecrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctOvrtkngTrgtLeCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctovrtkngtrgtricrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctOvrtkngTrgtRiCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctrdedglecrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctRdEdgLeCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctrdedgricrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctRdEdgRiCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctrirdedgconf_mp(
    static_cast<float>(LatCtrl_Elk_pctRiRdEdgConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctsldlinelecrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctSldLineLeCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_pctsldlinericrsslineratio_mp(
    static_cast<float>(LatCtrl_Elk_pctSldLineRiCrssLineRatio_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_phiexpctlinelnc1_mp(
    static_cast<float>(LatCtrl_Elk_phiExpctLineLnC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_philerdedgc1_mp(
    static_cast<float>(LatCtrl_Elk_phiLeRdEdgC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_phirirdedgc1_mp(
    static_cast<float>(LatCtrl_Elk_phiRiRdEdgC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_soncmngtrgtttc_mp(
    static_cast<float>(LatCtrl_Elk_sOncmngTrgtTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_sovrtkngtrgtttc_mp(
    static_cast<float>(LatCtrl_Elk_sOvrtkngTrgtTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stintvcase_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stIntvCase_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stlerdedgavlst_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stLeRdEdgAvlSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stoncmngtrgtintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOncmngTrgtIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stoncmngtrgtintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOncmngTrgtIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stoncmngtrgtlinedtctd_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOncmngTrgtLineDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stovrtkngtrgtintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOvrtkngTrgtIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stovrtkngtrgtintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOvrtkngTrgtIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stovrtkngtrgtlinedtctd_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stOvrtkngTrgtLineDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_strdedgdtctd_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stRdEdgDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_strdedgintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stRdEdgIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_strdedgintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stRdEdgIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_strdedgvld_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stRdEdgVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_strirdedgavlst_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stRiRdEdgAvlSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stsldlinedtctd_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stSldLineDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stsldlineintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stSldLineIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_stsldlineintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Elk_stSldLineIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xexpctlinelnc2_mp(
    static_cast<float>(LatCtrl_Elk_xExpctLineLnC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xexpctlinelnc3_mp(
    static_cast<float>(LatCtrl_Elk_xExpctLineLnC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xlerdedgc2_mp(
    static_cast<float>(LatCtrl_Elk_xLeRdEdgC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xlerdedgc3_mp(
    static_cast<float>(LatCtrl_Elk_xLeRdEdgC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xrirdedgc2_mp(
    static_cast<float>(LatCtrl_Elk_xRiRdEdgC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_xrirdedgc3_mp(
    static_cast<float>(LatCtrl_Elk_xRiRdEdgC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bffltmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfFltMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskdrvroper1hod_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskDrvrOper1hod_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskdrvroper2hod_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskDrvrOper2hod_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfgensprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfGenSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfladetqlraw_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLaDetQlRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfladetql_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLaDetQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bflesprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfLeSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_bfrisprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_Lka_bfRiSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flghodsprsduractv_mp(
    static_cast<bool>(LatCtrl_Lka_flgHodSprsDurActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flghodsprsdurinactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgHodSprsDurInactv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgleftfrntwhlinleftintvzone_mp(
    static_cast<bool>(LatCtrl_Lka_flgLeftFrntWhlInLeftIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgleftlanevld_mp(
    static_cast<bool>(LatCtrl_Lka_flgLeftLaneVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrightfrntwhlinrightintvzone_mp(
    static_cast<bool>(LatCtrl_Lka_flgRightFrntWhlInRightIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrightlanevld_mp(
    static_cast<bool>(LatCtrl_Lka_flgRightLaneVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgsprsexclactrhod_mp(
    static_cast<bool>(LatCtrl_Lka_flgSprsExclActrHod_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgsprsexclactr_mp(
    static_cast<bool>(LatCtrl_Lka_flgSprsExclActr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgvehoutoflane_mp(
    static_cast<bool>(LatCtrl_Lka_flgVehOutOfLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_ldstveh2leftoutrbrd_mp(
    static_cast<float>(LatCtrl_Lka_lDstVeh2LeftOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_ldstveh2rightoutrbrd_mp(
    static_cast<float>(LatCtrl_Lka_lDstVeh2RightOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_legolawdthraw_mp(
    static_cast<float>(LatCtrl_Lka_lEgoLaWdthRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_legolawdth_mp(
    static_cast<float>(LatCtrl_Lka_lEgoLaWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_linrleftzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Lka_lInrLeftZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_linrrightzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Lka_lInrRightZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_linrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_Lka_lInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_linrzonebrdlanewdthshft_mp(
    static_cast<float>(LatCtrl_Lka_lInrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Lka_lLeftInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftinrzonebrd_mp(
    static_cast<float>(LatCtrl_Lka_lLeftInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftlanec0_mp(
    static_cast<float>(LatCtrl_Lka_lLeftLaneC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Lka_lLeftOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Lka_lLeftOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdactltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdprdvltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdPrdvLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lleftzonebrdprdvltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lLeftZoneBrdPrdvLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstlacntr2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstLaCntr2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstlacntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstLaCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstleftla2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstLeftLa2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstleftla2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstLeftLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstrightla2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstRightLa2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lltrldstrightla2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lLtrlDstRightLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_loutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_Lka_lOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_loutrzonebrdlanewdthshft_mp(
    static_cast<float>(LatCtrl_Lka_lOutrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Lka_lRightInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightinrzonebrd_mp(
    static_cast<float>(LatCtrl_Lka_lRightInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightlanec0_mp(
    static_cast<float>(LatCtrl_Lka_lRightLaneC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_Lka_lRightOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightoutrzonebrd_mp(
    static_cast<float>(LatCtrl_Lka_lRightOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdactltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdprdvltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdPrdvLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrightzonebrdprdvltrlvelshft_mp(
    static_cast<float>(LatCtrl_Lka_lRightZoneBrdPrdvLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lvirtdstleline2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lVirtDstLeLine2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lvirtdstriline2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lVirtDstRiLine2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lzonemgrprdvdst_mp(
    static_cast<float>(LatCtrl_Lka_lZoneMgrPrdvDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_pctlelatypconf_mp(
    static_cast<float>(LatCtrl_Lka_pctLeLaTypConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_pctleftlaneconf_mp(
    static_cast<float>(LatCtrl_Lka_pctLeftLaneConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_pctrilatypconf_mp(
    static_cast<float>(LatCtrl_Lka_pctRiLaTypConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_pctrightlaneconf_mp(
    static_cast<float>(LatCtrl_Lka_pctRightLaneConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2lanecntrdeg_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2LaneCntrDeg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2lanecntrraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2LaneCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2lanecntr_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2LaneCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2leftlaneraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2LeftLaneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2leftlane_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2LeftLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2rightlaneraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2RightLaneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagveh2rightlane_mp(
    static_cast<float>(LatCtrl_Lka_phiAgVeh2RightLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phileftlanec1_mp(
    static_cast<float>(LatCtrl_Lka_phiLeftLaneC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phirightlanec1_mp(
    static_cast<float>(LatCtrl_Lka_phiRightLaneC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phizonemgrprdvagdegraw_mp(
    static_cast<float>(LatCtrl_Lka_phiZoneMgrPrdvAgDegRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phizonemgrprdvag_mp(
    static_cast<float>(LatCtrl_Lka_phiZoneMgrPrdvAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stflt_mp(static_cast<uint32_t>(LatCtrl_Lka_stFlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stintvzone_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlanecaseraw_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneCaseRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlanecase_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneCase_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stledlmtyp_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLeDLMTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlelanetyp_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLeLaneTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stleftprdsrc_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLeftPrdSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stridlmtyp_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stRiDLMTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_strilanetyp_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stRiLaneTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_strightprdsrc_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stRightPrdSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stsprs_mp(static_cast<uint32_t>(LatCtrl_Lka_stSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xlacurvraw_mp(
    static_cast<float>(LatCtrl_Lka_xLaCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xlacurv_mp(static_cast<float>(LatCtrl_Lka_xLaCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xladcurvraw_mp(
    static_cast<float>(LatCtrl_Lka_xLadCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xladcurv_mp(static_cast<float>(LatCtrl_Lka_xLadCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xleftlanec2_mp(
    static_cast<float>(LatCtrl_Lka_xLeftLaneC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xleftlanec3_mp(
    static_cast<float>(LatCtrl_Lka_xLeftLaneC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xrightlanec2_mp(
    static_cast<float>(LatCtrl_Lka_xRightLaneC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xrightlanec3_mp(
    static_cast<float>(LatCtrl_Lka_xRightLaneC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xzonebrdshftladcurvfltd_mp(
    static_cast<float>(LatCtrl_Lka_xZoneBrdShftLadCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xzonemgrprdvagcurvfltd_mp(
    static_cast<float>(LatCtrl_Lka_xZoneMgrPrdvAgCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xzonemgrprdvcurvdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_xZoneMgrPrdvCurvDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xzonemgrprdvcurvraw_mp(
    static_cast<float>(LatCtrl_Lka_xZoneMgrPrdvCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xzonemgrprdvcurv_mp(
    static_cast<float>(LatCtrl_Lka_xZoneMgrPrdvCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsactrsts1msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsActrSts1Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsdrvroper1msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsDrvrOper1Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsdrvroper2msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsDrvrOper2Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsfailsafe2msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsFailSafe2Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsfailsafe4msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsFailSafe4Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsintrst1msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsIntrSt1Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprslaneinfo1msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsLaneInfo1Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprslaneinfo4msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsLaneInfo4Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_bfsprsvehst1msk_mp(
    static_cast<uint32_t>(LatCtrl_Lks_bfSprsVehSt1Msk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_flglksinactv_mp(
    static_cast<bool>(LatCtrl_Lks_flgLksInactv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tinoplanechgprcstime_mp(
    static_cast<float>(LatCtrl_TiNOPLaneChgPrcsTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_vldlnchgrmdcnfrm_mp(
    static_cast<bool>(LatCtrl_VldLnChgRmdCnfrm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_acalclataccofsprs_mp(
    static_cast<float>(LatCtrl_aCalcLatAccOfSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_aegovehacc_mp(static_cast<float>(LatCtrl_aEgoVehAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_aeqvltlatacc_mp(static_cast<float>(LatCtrl_aEqvltLatAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_affeqvlntlatacclfnlforlataccellim_mp(
    static_cast<float>(LatCtrl_aFFEqvlntLatAcclFnlForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_affeqvlntlatacclforlataccellim_mp(
    static_cast<float>(LatCtrl_aFFEqvlntLatAcclForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_afffltlatacclforlataccellim_mp(
    static_cast<float>(LatCtrl_aFFFltLatAcclForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_afflataccl4bankrdforlataccellim_mp(
    static_cast<float>(LatCtrl_aFFLatAccl4BankRdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alataccwithbnkagcmpstofsprs_mp(
    static_cast<float>(LatCtrl_aLatAccWithBnkAgCmpstOfSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfelkactvsprs_mp(
    static_cast<uint32_t>(LatCtrl_bfElkActvSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfendlnchgattmpt_mp(
    static_cast<uint32_t>(LatCtrl_bfEndLnChgAttmpt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfgensprsmskintrst1forpilotlndeptwarn_mp(
    static_cast<uint32_t>(LatCtrl_bfGenSprsMskIntrSt1ForPilotLnDeptWarn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfhandsoffcnt_mp(
    static_cast<uint32_t>(LatCtrl_bfHandsoffCnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflcalelanesprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLCALeLaneSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflcalesprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLCALeSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflcarilanesprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLCARiLaneSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflcarisprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLCARiSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflanedethighql_mp(
    static_cast<uint32_t>(LatCtrl_bfLaneDetHighQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflanedetmidql_mp(
    static_cast<uint32_t>(LatCtrl_bfLaneDetMidQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflanedetql_mp(static_cast<uint32_t>(LatCtrl_bfLaneDetQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflksovrdsprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLksOvrdSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflkssprs_mp(static_cast<uint32_t>(LatCtrl_bfLksSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfnopsprs_mp(static_cast<uint32_t>(LatCtrl_bfNopSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfphylanedetmidql_mp(
    static_cast<uint32_t>(LatCtrl_bfPhyLaneDetMidQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfrmelanedetmidql_mp(
    static_cast<uint32_t>(LatCtrl_bfRMELaneDetMidQl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskactrsts1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskActrSts1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskbrksys1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskBrkSys1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskdrvroper1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskDrvrOper1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskdrvroper2_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskDrvrOper2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe2_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe3_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe4_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe5_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskfailsafe6_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskFailSafe6_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskintrst1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskIntrSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmsklaneinfo1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskLaneInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmsklaneinfo2_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskLaneInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmsklaneinfo3_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskLaneInfo3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmsklaneinfo4_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskLaneInfo4_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskobjinfo1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskObjInfo1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskobjinfo2_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskObjInfo2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfsprsmskvehst1_mp(
    static_cast<uint32_t>(LatCtrl_bfSprsMskVehSt1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bfusermelineinfo_mp(
    static_cast<uint32_t>(LatCtrl_bfUseRMELineInfo_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_dphiegolanelinediffc2_mp(
    static_cast<float>(LatCtrl_dphiEgoLaneLineDiffC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_dphiyawrate_mp(static_cast<float>(LatCtrl_dphiYawRate_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffaceqvlntlataweightforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacEqvlntLatAWeightForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffacfinalforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacFinalForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffaclargeforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacLargeForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffacnormalforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacNormalForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffacweightforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacWeightForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffacweightoflatadiffforlataccellim_mp(
    static_cast<float>(LatCtrl_facFFFacWeightOfLatADiffForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcdriverantitrigger_mp(
    static_cast<bool>(LatCtrl_flgALCDriverAntiTrigger_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcslemaneuversprs_mp(
    static_cast<bool>(LatCtrl_flgALCSLeManeuverSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcsrimaneuversprs_mp(
    static_cast<bool>(LatCtrl_flgALCSRiManeuverSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgabsltpinionagreqvalid_mp(
    static_cast<bool>(LatCtrl_flgAbsltPinionAgReqValid_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslinelidetle_mp(
    static_cast<bool>(LatCtrl_flgAdasLineLiDetLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslinelidetri_mp(
    static_cast<bool>(LatCtrl_flgAdasLineLiDetRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnehywrnonle_mp(
    static_cast<bool>(LatCtrl_flgAdasLnEhyWrnOnLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnehywrnonri_mp(
    static_cast<bool>(LatCtrl_flgAdasLnEhyWrnOnRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnledispctrl_mp(
    static_cast<bool>(LatCtrl_flgAdasLnLeDispCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnlewrnoff_mp(
    static_cast<bool>(LatCtrl_flgAdasLnLeWrnOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnridispctrl_mp(
    static_cast<bool>(LatCtrl_flgAdasLnRiDispCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgadaslnriwrnoff_mp(
    static_cast<bool>(LatCtrl_flgAdasLnRiWrnOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgagextlelnforlndeptwarn_mp(
    static_cast<bool>(LatCtrl_flgAgExtLeLnForLnDeptWarn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgagextrilnforlndeptwarn_mp(
    static_cast<bool>(LatCtrl_flgAgExtRiLnForLnDeptWarn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgbsdlcaonoffsts_mp(
    static_cast<bool>(LatCtrl_flgBSDLCAOnOffSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgc2diffatlcaendsprs_mp(
    static_cast<bool>(LatCtrl_flgC2DiffAtLcaEndSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgc2diffsprs_mp(static_cast<bool>(LatCtrl_flgC2DiffSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgctafrntlewarnvld_mp(
    static_cast<bool>(LatCtrl_flgCTAFrntLeWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgctafrntriwarnvld_mp(
    static_cast<bool>(LatCtrl_flgCTAFrntRiWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgctarelewarnvld_mp(
    static_cast<bool>(LatCtrl_flgCTAReLeWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgctareriwarnvld_mp(
    static_cast<bool>(LatCtrl_flgCTAReRiWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcamlelanecrsg_mp(
    static_cast<bool>(LatCtrl_flgCamLeLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcamrilanecrsg_mp(
    static_cast<bool>(LatCtrl_flgCamRiLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlaton_mp(static_cast<bool>(LatCtrl_flgCdnLatOn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlatpsv_mp(static_cast<bool>(LatCtrl_flgCdnLatPsv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlca2lka_mp(static_cast<bool>(LatCtrl_flgCdnLca2Lka_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlca2lks_mp(static_cast<bool>(LatCtrl_flgCdnLca2Lks_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlca2trnst_mp(
    static_cast<bool>(LatCtrl_flgCdnLca2Trnst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlka2lks_mp(static_cast<bool>(LatCtrl_flgCdnLka2Lks_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlka2trnst_mp(
    static_cast<bool>(LatCtrl_flgCdnLka2Trnst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlks2lca_mp(static_cast<bool>(LatCtrl_flgCdnLks2Lca_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlks2lka_mp(static_cast<bool>(LatCtrl_flgCdnLks2Lka_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnlks2trnst_mp(
    static_cast<bool>(LatCtrl_flgCdnLks2Trnst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnpsv2lks_mp(static_cast<bool>(LatCtrl_flgCdnPsv2Lks_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdnpsv2trnst_mp(
    static_cast<bool>(LatCtrl_flgCdnPsv2Trnst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdntrnst2lka_mp(
    static_cast<bool>(LatCtrl_flgCdnTrnst2Lka_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcdntrnst2lks_mp(
    static_cast<bool>(LatCtrl_flgCdnTrnst2Lks_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgconfswitch_mp(static_cast<bool>(LatCtrl_flgConfSwitch_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgcsfwarntrg_mp(static_cast<bool>(LatCtrl_flgCsfWarnTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdaiavl_mp(static_cast<bool>(LatCtrl_flgDAIAvl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgda_strongsteering_mp(
    static_cast<bool>(LatCtrl_flgDA_StrongSteering_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdriveevddiffdir_mp(
    static_cast<bool>(LatCtrl_flgDriveEVDDiffDir_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdriveevdsamedir_mp(
    static_cast<bool>(LatCtrl_flgDriveEVDSameDir_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdriverholdtrq_mp(
    static_cast<bool>(LatCtrl_flgDriverHoldTrq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdriverresetlnchgreq_mp(
    static_cast<bool>(LatCtrl_flgDriverResetLnChgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvantitrgwhenrmdcnfrm_mp(
    static_cast<bool>(LatCtrl_flgDrvAntiTrgWhenRmdCnfrm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvcncllatdlbrtl_mp(
    static_cast<bool>(LatCtrl_flgDrvCnclLatDlbrtl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvcnfrmlnchgreqbyindctr_mp(
    static_cast<bool>(LatCtrl_flgDrvCnfrmLnChgReqByIndctr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvdifftrginnopleading_mp(
    static_cast<bool>(LatCtrl_flgDrvDiffTrgInNOPLeading_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvevdleadingdiffdir_mp(
    static_cast<bool>(LatCtrl_flgDrvEVDLeadingDiffDir_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvevdleadingsamedir_mp(
    static_cast<bool>(LatCtrl_flgDrvEVDLeadingSameDir_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvovrdretrgpathplan_mp(
    static_cast<bool>(LatCtrl_flgDrvOvrdReTrgPathPlan_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvstrinp_mp(static_cast<bool>(LatCtrl_flgDrvStrInp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdrvtrglnchgprcsovertime_mp(
    static_cast<bool>(LatCtrl_flgDrvTrgLnChgPrcsOverTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdynhmialcdesten_mp(
    static_cast<bool>(LatCtrl_flgDynHmiAlcDestEn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgelkdrvstrinp_mp(
    static_cast<bool>(LatCtrl_flgElkDrvStrInp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgendlnchgattmpt_mp(
    static_cast<bool>(LatCtrl_flgEndLnChgAttmpt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgenoughroom4lelc_mp(
    static_cast<double>(LatCtrl_flgEnoughRoom4LeLc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgenoughroom4rilc_mp(
    static_cast<double>(LatCtrl_flgEnoughRoom4RiLc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgevdnavisprbyspdthr_mp(
    static_cast<bool>(LatCtrl_flgEvdNaviSprBySpdThr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgexctnopramp2mainlnchg_mp(
    static_cast<bool>(LatCtrl_flgExctNopRamp2MainLnChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgextlnovrd_mp(static_cast<bool>(LatCtrl_flgExtLnOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flghw2rampsprs_mp(
    static_cast<bool>(LatCtrl_flgHW2RampSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flghalelaneflash_mp(
    static_cast<bool>(LatCtrl_flgHaLeLaneFlash_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgharilaneflash_mp(
    static_cast<bool>(LatCtrl_flgHaRiLaneFlash_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flghostlaneexistconstrctarea_mp(
    static_cast<bool>(LatCtrl_flgHostLaneExistConstrctArea_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flginnewleftzone_mp(
    static_cast<bool>(LatCtrl_flgInNewLeftZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flginnewrightzone_mp(
    static_cast<bool>(LatCtrl_flgInNewRightZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgintolcaconfarea_mp(
    static_cast<bool>(LatCtrl_flgIntoLcaConfArea_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgintrstlelinetypecrossable_mp(
    static_cast<bool>(LatCtrl_flgIntrstLeLineTypeCrossable_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgintrstrilinetypecrossable_mp(
    static_cast<bool>(LatCtrl_flgIntrstRiLineTypeCrossable_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgishowsactv_mp(static_cast<bool>(LatCtrl_flgIsHoWSActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalelanesprs_mp(
    static_cast<bool>(LatCtrl_flgLCALeLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcarilanesprs_mp(
    static_cast<bool>(LatCtrl_flgLCARiLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcintolongadj_mp(
    static_cast<bool>(LatCtrl_flgLCIntoLongAdj_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcturnlghtidcreq_mp(
    static_cast<bool>(LatCtrl_flgLCTurnLghtIdcReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglkstakeoverreq_mp(
    static_cast<bool>(LatCtrl_flgLKSTakeoverReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglkstqreqvalid_mp(
    static_cast<bool>(LatCtrl_flgLKSTqReqValid_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglanechgfucenb_mp(
    static_cast<bool>(LatCtrl_flgLaneChgFucEnb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglanechgignrdrvrantitrg_mp(
    static_cast<bool>(LatCtrl_flgLaneChgIgnrDrvrAntiTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglanelists4c2diff_mp(
    static_cast<bool>(LatCtrl_flgLaneLiSts4C2Diff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglatctrlactv_mp(
    static_cast<bool>(LatCtrl_flgLatCtrlActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcacfgbyuds_mp(
    static_cast<bool>(LatCtrl_flgLcaCfgByUDS_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcaendincntr_mp(
    static_cast<bool>(LatCtrl_flgLcaEndInCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelastabstssprs_mp(
    static_cast<bool>(LatCtrl_flgLeLaStabStsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanecrsgorg_mp(
    static_cast<bool>(LatCtrl_flgLeLaneCrsgOrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanedash_mp(static_cast<bool>(LatCtrl_flgLeLaneDash_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelaneexistconstrctarea_mp(
    static_cast<bool>(LatCtrl_flgLeLaneExistConstrctArea_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanereobssprs_mp(
    static_cast<bool>(LatCtrl_flgLeLaneReObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanesprs4wait_mp(
    static_cast<bool>(LatCtrl_flgLeLaneSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanesprs_mp(static_cast<bool>(LatCtrl_flgLeLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanewdthchgsts_mp(
    static_cast<bool>(LatCtrl_flgLeLaneWdthChgSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinec0facstb_mp(
    static_cast<bool>(LatCtrl_flgLeLineC0FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinec1facstb_mp(
    static_cast<bool>(LatCtrl_flgLeLineC1FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinedashsprs4latactv_mp(
    static_cast<bool>(LatCtrl_flgLeLineDashSprs4LatActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinedashsprs4longadj_mp(
    static_cast<bool>(LatCtrl_flgLeLineDashSprs4LongAdj_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinedel0qlt_mp(
    static_cast<bool>(LatCtrl_flgLeLineDel0Qlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinedel1qlt_mp(
    static_cast<bool>(LatCtrl_flgLeLineDel1Qlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinelensprs4wait_mp(
    static_cast<bool>(LatCtrl_flgLeLineLenSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelinelensprs_mp(
    static_cast<bool>(LatCtrl_flgLeLineLenSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelnchgreflinecpysprs_mp(
    static_cast<bool>(LatCtrl_flgLeLnChgRefLineCpySprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglereflinevnshtiextnd_mp(
    static_cast<bool>(LatCtrl_flgLeRefLineVnshTiExtnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgleturnidctron_mp(
    static_cast<bool>(LatCtrl_flgLeTurnIdctrOn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgleftturndtctd_mp(
    static_cast<bool>(LatCtrl_flgLeftTurnDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksimdtovrd_mp(
    static_cast<bool>(LatCtrl_flgLksImdtOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksnrmlovrd_mp(
    static_cast<bool>(LatCtrl_flgLksNrmlOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksovrdleftfrntwhlinleftintvzone_mp(
    static_cast<bool>(LatCtrl_flgLksOvrdLeftFrntWhlInLeftIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksovrdrightfrntwhlinrightintvzone_mp(
    static_cast<bool>(LatCtrl_flgLksOvrdRightFrntWhlInRightIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksovrdvehoutoflane_mp(
    static_cast<bool>(LatCtrl_flgLksOvrdVehOutOfLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglkssprs_mp(static_cast<bool>(LatCtrl_flgLksSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksuselpp_mp(static_cast<bool>(LatCtrl_flgLksUseLPP_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglnchgcouldreturn_mp(
    static_cast<bool>(LatCtrl_flgLnChgCouldReturn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglocklnchgcnfrmmthd_mp(
    static_cast<bool>(LatCtrl_flgLockLnChgCnfrmMthd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmlanewdthchgc1sprs_mp(
    static_cast<bool>(LatCtrl_flgMLaneWdthChgC1Sprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmlanewdthchgc2sprs_mp(
    static_cast<bool>(LatCtrl_flgMLaneWdthChgC2Sprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmlanewdthchgsts_mp(
    static_cast<bool>(LatCtrl_flgMLaneWdthChgSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmaplinetypeenable_mp(
    static_cast<bool>(LatCtrl_flgMapLineTypeEnable_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmovebacksprs_mp(
    static_cast<bool>(LatCtrl_flgMoveBackSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopattmptlclmt_mp(
    static_cast<bool>(LatCtrl_flgNOPAttmptLCLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvantitrg_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvAntiTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvcancellnchngreq_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvCancelLnChngReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvlanechgfinish_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvLaneChgFinish_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvsametrg_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvSameTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvshrttrglcreset_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvShrtTrgLCReset_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvshrttrglcset_mp(
    static_cast<bool>(LatCtrl_flgNOPDrvShrtTrgLCSet_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplcprcsovertime_mp(
    static_cast<bool>(LatCtrl_flgNOPLCPrcsOverTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplanechgfinish_mp(
    static_cast<bool>(LatCtrl_flgNOPLaneChgFinish_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplanechgreqoff_mp(
    static_cast<bool>(LatCtrl_flgNOPLaneChgReqOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplelanechglinecrsg_mp(
    static_cast<bool>(LatCtrl_flgNOPLeLaneChgLineCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopleaddrvsametrgsprs_mp(
    static_cast<bool>(LatCtrl_flgNOPLeadDrvSameTrgSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopleadingthendrvsametrg_mp(
    static_cast<bool>(LatCtrl_flgNOPLeadingThenDrvSameTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoprilanechglinecrsg_mp(
    static_cast<bool>(LatCtrl_flgNOPRiLaneChgLineCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopstoplcreq_mp(
    static_cast<bool>(LatCtrl_flgNOPStopLCReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopturnidctrswthld_mp(
    static_cast<bool>(LatCtrl_flgNOPTurnIdctrSwtHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnewatmptlanechg_mp(
    static_cast<bool>(LatCtrl_flgNewAtmptLaneChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnewlanechgbegin_mp(
    static_cast<bool>(LatCtrl_flgNewLaneChgBegin_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdrvercnfrmlnchg_mp(
    static_cast<bool>(LatCtrl_flgNopDrverCnfrmLnChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopevdlenotnedcnfrmlnchg_mp(
    static_cast<bool>(LatCtrl_flgNopEVDLeNotNedCnfrmLnChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopevdrinotnedcnfrmlnchg_mp(
    static_cast<bool>(LatCtrl_flgNopEVDRiNotNedCnfrmLnChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopexstshltrtar3_mp(
    static_cast<bool>(LatCtrl_flgNopExstShltrTar3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopexstshltrtar5_mp(
    static_cast<bool>(LatCtrl_flgNopExstShltrTar5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplongtrgturnindcrswt_mp(
    static_cast<uint32_t>(LatCtrl_flgNopLongTrgTurnIndcrSwt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopnolelanesprs_mp(
    static_cast<bool>(LatCtrl_flgNopNoLeLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopnorilanesprs_mp(
    static_cast<bool>(LatCtrl_flgNopNoRiLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopramp2maindshlnbeflnchg_mp(
    static_cast<bool>(LatCtrl_flgNopRamp2MainDshLnBefLnChg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopramp2maindshln_mp(
    static_cast<bool>(LatCtrl_flgNopRamp2MainDshLn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnotinlnchgprcs_mp(
    static_cast<bool>(LatCtrl_flgNotInLnChgPrcs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnotmovesprs_mp(
    static_cast<bool>(LatCtrl_flgNotMoveSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnotoverlataccellim_mp(
    static_cast<bool>(LatCtrl_flgNotOverLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxlelinelensprs4wait_mp(
    static_cast<bool>(LatCtrl_flgNxLeLineLenSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxlelinelensprs_mp(
    static_cast<bool>(LatCtrl_flgNxLeLineLenSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxrilinelensprs4wait_mp(
    static_cast<bool>(LatCtrl_flgNxRiLineLenSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxrilinelensprs_mp(
    static_cast<bool>(LatCtrl_flgNxRiLineLenSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxtlelinec0facstb_mp(
    static_cast<bool>(LatCtrl_flgNxtLeLineC0FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnxtrilinec0facstb_mp(
    static_cast<bool>(LatCtrl_flgNxtRiLineC0FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgobfrearobjectdetected_mp(
    static_cast<bool>(LatCtrl_flgObfRearObjectDetected_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondc0set_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondC0Set_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondc1set_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondC1Set_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondstrwhlagsetforlataccellim_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondStrWhlAgSetForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondstrwhlagset_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondStrWhlAgSet_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondtqsetforlataccellim_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondTqSetForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdprecondtqset_mp(
    static_cast<bool>(LatCtrl_flgOvrdPreCondTqSet_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgovrdtocntr_mp(static_cast<bool>(LatCtrl_flgOvrdToCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradflfailure_mp(
    static_cast<bool>(LatCtrl_flgRADFLFailure_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradflloosediagfail_mp(
    static_cast<bool>(LatCtrl_flgRADFLLooseDiagFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfllosscommfault_mp(
    static_cast<bool>(LatCtrl_flgRADFLLossCommFault_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfltistampinvld_mp(
    static_cast<bool>(LatCtrl_flgRADFLTiStampInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfrfailure_mp(
    static_cast<bool>(LatCtrl_flgRADFRFailure_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfrloosediagfail_mp(
    static_cast<bool>(LatCtrl_flgRADFRLooseDiagFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfrlosscommfault_mp(
    static_cast<bool>(LatCtrl_flgRADFRLossCommFault_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradfrtistampinvld_mp(
    static_cast<bool>(LatCtrl_flgRADFRTiStampInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradloosediagfail_mp(
    static_cast<bool>(LatCtrl_flgRADLooseDiagFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrlfailure_mp(
    static_cast<bool>(LatCtrl_flgRADRLFailure_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrlloosediagfail_mp(
    static_cast<bool>(LatCtrl_flgRADRLLooseDiagFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrllosscommfault_mp(
    static_cast<bool>(LatCtrl_flgRADRLLossCommFault_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrltistampinvld_mp(
    static_cast<bool>(LatCtrl_flgRADRLTiStampInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrr01datainvld_mp(
    static_cast<bool>(LatCtrl_flgRADRR01DataInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrrfailure_mp(
    static_cast<bool>(LatCtrl_flgRADRRFailure_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrrloosediagfail_mp(
    static_cast<bool>(LatCtrl_flgRADRRLooseDiagFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrrlosscommfault_mp(
    static_cast<bool>(LatCtrl_flgRADRRLossCommFault_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgradrrtistampinvld_mp(
    static_cast<bool>(LatCtrl_flgRADRRTiStampInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgreachlanechgatmptlmt_mp(
    static_cast<bool>(LatCtrl_flgReachLaneChgAtmptLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgreflineswtsprs_mp(
    static_cast<bool>(LatCtrl_flgRefLineSwtSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilastabstssprs_mp(
    static_cast<bool>(LatCtrl_flgRiLaStabStsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanecrsgorg_mp(
    static_cast<bool>(LatCtrl_flgRiLaneCrsgOrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanedash_mp(static_cast<bool>(LatCtrl_flgRiLaneDash_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilaneexistconstrctarea_mp(
    static_cast<bool>(LatCtrl_flgRiLaneExistConstrctArea_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanereobssprs_mp(
    static_cast<bool>(LatCtrl_flgRiLaneReObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanesprs4wait_mp(
    static_cast<bool>(LatCtrl_flgRiLaneSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanesprs_mp(static_cast<bool>(LatCtrl_flgRiLaneSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanewdthchgsts_mp(
    static_cast<bool>(LatCtrl_flgRiLaneWdthChgSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinec0facstb_mp(
    static_cast<bool>(LatCtrl_flgRiLineC0FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinec1facstb_mp(
    static_cast<bool>(LatCtrl_flgRiLineC1FacStb_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinedashsprs4latactv_mp(
    static_cast<bool>(LatCtrl_flgRiLineDashSprs4LatActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinedashsprs4longadj_mp(
    static_cast<bool>(LatCtrl_flgRiLineDashSprs4LongAdj_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinedel0qlt_mp(
    static_cast<bool>(LatCtrl_flgRiLineDel0Qlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinedel1qlt_mp(
    static_cast<bool>(LatCtrl_flgRiLineDel1Qlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinelensprs4wait_mp(
    static_cast<bool>(LatCtrl_flgRiLineLenSprs4Wait_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilinelensprs_mp(
    static_cast<bool>(LatCtrl_flgRiLineLenSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilnchgreflinecpysprs_mp(
    static_cast<bool>(LatCtrl_flgRiLnChgRefLineCpySprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrireflinevnshtiextnd_mp(
    static_cast<bool>(LatCtrl_flgRiRefLineVnshTiExtnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgriturnidctron_mp(
    static_cast<bool>(LatCtrl_flgRiTurnIdctrOn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrightturndtctd_mp(
    static_cast<bool>(LatCtrl_flgRightTurnDtctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsetalcinvld_mp(
    static_cast<bool>(LatCtrl_flgSetALCInvld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsactrstswarninactv_mp(
    static_cast<bool>(LatCtrl_flgSprsActrStsWarnInactv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsactrsts_mp(
    static_cast<bool>(LatCtrl_flgSprsActrSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsagdiffinstndstllovrd_mp(
    static_cast<bool>(LatCtrl_flgSprsAgDiffInStndStllOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsalcpathconf_mp(
    static_cast<bool>(LatCtrl_flgSprsAlcPathConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsc1onstart_mp(
    static_cast<bool>(LatCtrl_flgSprsC1OnStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsdvatnofepsagatstart_mp(
    static_cast<bool>(LatCtrl_flgSprsDvatnOfEpsAgAtStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsfuncpause_mp(
    static_cast<bool>(LatCtrl_flgSprsFuncPause_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslacurvraw_mp(
    static_cast<bool>(LatCtrl_flgSprsLaCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslacurv_mp(static_cast<bool>(LatCtrl_flgSprsLaCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslataccel_mp(
    static_cast<bool>(LatCtrl_flgSprsLatAccel_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslcaabrt_mp(
    static_cast<bool>(LatCtrl_flgSprsLcaAbrt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslcaovrd_mp(
    static_cast<bool>(LatCtrl_flgSprsLcaOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslinecaseonstart_mp(
    static_cast<bool>(LatCtrl_flgSprsLineCaseOnStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslksovrd_mp(
    static_cast<bool>(LatCtrl_flgSprsLksOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslongacc_mp(
    static_cast<bool>(LatCtrl_flgSprsLongAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprspathconf_mp(
    static_cast<bool>(LatCtrl_flgSprsPathConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsrwrddrv_mp(
    static_cast<bool>(LatCtrl_flgSprsRwrdDrv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprsturnidctr_mp(
    static_cast<bool>(LatCtrl_flgSprsTurnIdctr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgstrwhlspdbsovrd_mp(
    static_cast<bool>(LatCtrl_flgStrWhlSpdBsOvrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgstraightawayside_mp(
    static_cast<bool>(LatCtrl_flgStraightaWaySide_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar10obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar10ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar11obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar11ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar12obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar12ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar13obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar13ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar15obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar15ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar16obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar16ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar17obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar17ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar19obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar19ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar1obsdstsprs_mp(
    static_cast<bool>(LatCtrl_flgTar1ObsDstSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar1obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar1ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar1obsttcsprs_mp(
    static_cast<bool>(LatCtrl_flgTar1ObsTTCSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar21obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar21ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar3obsdstsprs_mp(
    static_cast<bool>(LatCtrl_flgTar3ObsDstSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar3obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar3ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar3obsttcsprs_mp(
    static_cast<bool>(LatCtrl_flgTar3ObsTTCSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar5obsdstsprs_mp(
    static_cast<bool>(LatCtrl_flgTar5ObsDstSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar5obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar5ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar5obsttcsprs_mp(
    static_cast<bool>(LatCtrl_flgTar5ObsTTCSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar7noplanechgsprs_mp(
    static_cast<bool>(LatCtrl_flgTar7NOPLaneChgSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar7obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar7ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar8noplanechgsprs_mp(
    static_cast<bool>(LatCtrl_flgTar8NOPLaneChgSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar8obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar8ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtar9obssprs_mp(
    static_cast<bool>(LatCtrl_flgTar9ObsSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgflgradflblindness_mp(
    static_cast<bool>(LatCtrl_flgflgRADFLBlindness_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgflgradfrblindness_mp(
    static_cast<bool>(LatCtrl_flgflgRADFRBlindness_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgflgradrlblindness_mp(
    static_cast<bool>(LatCtrl_flgflgRADRLBlindness_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgflgradrrblindness_mp(
    static_cast<bool>(LatCtrl_flgflgRADRRBlindness_mp));
  // fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_isadasmapvalid_mp(
  //   static_cast<bool>(LatCtrl_isadasmapValid_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ldstveh2leftoutrbrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lDstVeh2LeftOutrBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ldstveh2rightoutrbrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lDstVeh2RightOutrBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_levddistance_mp(static_cast<float>(LatCtrl_lEVDdistance_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_legolawdth_mp(static_cast<float>(LatCtrl_lEgoLaWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_linrlezonebrdlanewdthshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lInrLeZoneBrdLaneWdthShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_linrleftzonebrdhysshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lInrLeftZoneBrdHysShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_linrrizonebrdlanewdthshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lInrRiZoneBrdLaneWdthShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_linrrightzonebrdhysshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lInrRightZoneBrdHysShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_linrzonebrdcurvdiffshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lInrZoneBrdCurvDiffShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llriznbrdltrlpreaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLRiZnBrdLtrlPreAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelaneposorg_mp(static_cast<float>(LatCtrl_lLeLanePosOrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelanepos_mp(static_cast<float>(LatCtrl_lLeLanePos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelanewdthdst_mp(
    static_cast<float>(LatCtrl_lLeLaneWdthDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelinedst_mp(static_cast<float>(LatCtrl_lLeLineDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleznbrdltrlaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeZnBrdLtrlAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleznbrdltrlprdvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeZnBrdLtrlPrdVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleznbrdltrlpreaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeZnBrdLtrlPreAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleznbrdltrlvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeZnBrdLtrlVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftinrzonebrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeftInrZoneBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftlaneend_mp(static_cast<float>(LatCtrl_lLeftLaneEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftlanestart_mp(
    static_cast<float>(LatCtrl_lLeftLaneStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftoutrzonebrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeftOutrZoneBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftzonebrdltrlaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeftZoneBrdLtrlAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lleftzonebrdltrlvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lLeftZoneBrdLtrlVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksfltc3fortrgtpnt_mp(
    static_cast<float>(LatCtrl_lLksFltC3ForTrgtPnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrddstveh2leftoutrbrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdDstVeh2LeftOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrddstveh2rightoutrbrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdDstVeh2RightOutrBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdinrleftzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdInrLeftZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdinrrightzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdInrRightZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdinrzonebrdcurvdiffshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdInrZoneBrdCurvDiffShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdinrzonebrdlanewdthshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdInrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftinrzonebrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftoutrzonebrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdactltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdprdvltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdPrdvLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdleftzonebrdprdvltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdLeftZoneBrdPrdvLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdoutrzonebrdhysshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdoutrzonebrdlanewdthshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdOutrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightinrzonebrdraw_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightInrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightinrzonebrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightInrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightoutrzonebrdraw_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightOutrZoneBrdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightoutrzonebrd_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightOutrZoneBrd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdactltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdprdvltrlaccshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdPrdvLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdrightzonebrdprdvltrlvelshft_mp(
    static_cast<float>(LatCtrl_lLksOvrdRightZoneBrdPrdvLtrlVelShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdvirtdstleline2vehcntr_mp(
    static_cast<float>(LatCtrl_lLksOvrdVirtDstLeLine2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdvirtdstriline2vehcntr_mp(
    static_cast<float>(LatCtrl_lLksOvrdVirtDstRiLine2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksovrdzonemgrprdvdst_mp(
    static_cast<float>(LatCtrl_lLksOvrdZoneMgrPrdvDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llmtrajpathc0_mp(static_cast<float>(LatCtrl_lLmTrajPathC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llmtrajpathc1_mp(static_cast<float>(LatCtrl_lLmTrajPathC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llmtrajpathc2_mp(static_cast<float>(LatCtrl_lLmTrajPathC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llmtrajpathc3_mp(static_cast<float>(LatCtrl_lLmTrajPathC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llmtrajpathwdth_mp(
    static_cast<float>(LatCtrl_lLmTrajPathWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lltrldstlacntr2vehcntr_mp(
    static_cast<float>(LatCtrl_lLtrlDstLaCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lltrldstleftla2vehcntr_mp(
    static_cast<float>(LatCtrl_lLtrlDstLeftLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lltrldstrightla2vehcntr_mp(
    static_cast<float>(LatCtrl_lLtrlDstRightLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehppc0_mp(static_cast<float>(LatCtrl_lMeHppC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehppconf_mp(static_cast<float>(LatCtrl_lMeHppConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehppispred_mp(static_cast<float>(LatCtrl_lMeHppIsPred_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplawidth_mp(static_cast<float>(LatCtrl_lMeHppLaWidth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplatctrlpnt_mp(
    static_cast<float>(LatCtrl_lMeHppLatCtrlPnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplonctrlpnt_mp(
    static_cast<float>(LatCtrl_lMeHppLonCtrlPnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtlelaneend_mp(static_cast<float>(LatCtrl_lNxtLeLaneEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtlelanepos_mp(static_cast<float>(LatCtrl_lNxtLeLanePos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtlelanestart_mp(
    static_cast<float>(LatCtrl_lNxtLeLaneStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtrilaneend_mp(static_cast<float>(LatCtrl_lNxtRiLaneEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtrilanepos_mp(static_cast<float>(LatCtrl_lNxtRiLanePos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnxtrilanestart_mp(
    static_cast<float>(LatCtrl_lNxtRiLaneStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_loutrzonebrdhysshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lOutrZoneBrdHysShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_loutrzonebrdlanewdthshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lOutrZoneBrdLaneWdthShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt1llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt1LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt1mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt1MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt1mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt1MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt1mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt1MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt1rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt1RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt2llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt2LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt2mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt2MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt2mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt2MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt2mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt2MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt2rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt2RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt3llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt3LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt3mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt3MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt3mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt3MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt3mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt3MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt3rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt3RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt4llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt4LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt4mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt4MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt4mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt4MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt4mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt4MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt4rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt4RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt5llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt5LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt5mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt5MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt5mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt5MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt5mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt5MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt5rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt5RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt6llanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt6LLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt6mlanewdthdiffc1thrld_mp(
    static_cast<float>(LatCtrl_lPnt6MLaneWdthDiffC1Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt6mlanewdthdiffc2thrld_mp(
    static_cast<float>(LatCtrl_lPnt6MLaneWdthDiffC2Thrld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt6mlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt6MLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lpnt6rlanewdthdiff_mp(
    static_cast<float>(LatCtrl_lPnt6RLaneWdthDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilaneend_mp(static_cast<float>(LatCtrl_lRiLaneEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilaneposorg_mp(static_cast<float>(LatCtrl_lRiLanePosOrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilanepos_mp(static_cast<float>(LatCtrl_lRiLanePos_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilanestart_mp(static_cast<float>(LatCtrl_lRiLaneStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilanewdthdst_mp(
    static_cast<float>(LatCtrl_lRiLaneWdthDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilinedst_mp(static_cast<float>(LatCtrl_lRiLineDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lriznbrdltrlaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lRiZnBrdLtrlAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lriznbrdltrlprdvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lRiZnBrdLtrlPrdVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lriznbrdltrlvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lRiZnBrdLtrlVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrightinrzonebrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lRightInrZoneBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrightoutrzonebrdforlataccellim_mp(
    static_cast<float>(LatCtrl_lRightOutrZoneBrdForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrightzonebrdltrlaccshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lRightZoneBrdLtrlAccShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrightzonebrdltrlvelshftforlataccellim_mp(
    static_cast<float>(LatCtrl_lRightZoneBrdLtrlVelShftForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ltar1obsdst_mp(static_cast<float>(LatCtrl_lTar1ObsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ltar3obsdst_mp(static_cast<float>(LatCtrl_lTar3ObsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ltar5obsdst_mp(static_cast<float>(LatCtrl_lTar5ObsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lvirtdstlacntr2vehcntrforlataccellim_mp(
    static_cast<float>(LatCtrl_lVirtDstLaCntr2VehCntrForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lvirtdstleline2vehcntrforlataccellim_mp(
    static_cast<float>(LatCtrl_lVirtDstLeLine2VehCntrForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lvirtdstriline2vehcntrforlataccellim_mp(
    static_cast<float>(LatCtrl_lVirtDstRiLine2VehCntrForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lznmgrc0_mp(static_cast<float>(LatCtrl_lZnMgrC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lznmgregolawdth_mp(
    static_cast<float>(LatCtrl_lZnMgrEgoLaWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrle1lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrLe1LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrle2lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrLe2LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrle2liofset_mp(
    static_cast<float>(LatCtrl_lZoneMgrLe2LiOfset_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrle3lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrLe3LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrledeadzonec0_mp(
    static_cast<float>(LatCtrl_lZoneMgrLeDeadZoneC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrri1lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrRi1LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrri2lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrRi2LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrri2liofset_mp(
    static_cast<float>(LatCtrl_lZoneMgrRi2LiOfset_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrri3lic0_mp(
    static_cast<float>(LatCtrl_lZoneMgrRi3LiC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lzonemgrrideadzonec0_mp(
    static_cast<float>(LatCtrl_lZoneMgrRiDeadZoneC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mevddst2leading_mp(
    static_cast<float>(LatCtrl_mEVDDst2Leading_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlcalescritical_mp(
    static_cast<float>(LatCtrl_mLcaLeScritical_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlcariscritical_mp(
    static_cast<float>(LatCtrl_mLcaRiScritical_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlelctar7latdstlmt_mp(
    static_cast<float>(LatCtrl_mLeLCTar7LatDstLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlelctar8latdstlmt_mp(
    static_cast<float>(LatCtrl_mLeLCTar8LatDstLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mleftlanewdth_mp(static_cast<float>(LatCtrl_mLeftLaneWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlnchgtar1sprsdst_mp(
    static_cast<float>(LatCtrl_mLnChgTar1SprsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlnchgtar3sprsdst_mp(
    static_cast<float>(LatCtrl_mLnChgTar3SprsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlnchgtar5sprsdst_mp(
    static_cast<float>(LatCtrl_mLnChgTar5SprsDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mradislimforlataccellim_mp(
    static_cast<float>(LatCtrl_mRadisLimForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mrightlanewdth_mp(
    static_cast<float>(LatCtrl_mRightLaneWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_nop_alc_sts_mp(static_cast<uint32_t>(LatCtrl_nop_alc_sts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_numfam_id11_mp(static_cast<uint32_t>(LatCtrl_numFAM_ID11_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_numfam_id1_mp(static_cast<uint32_t>(LatCtrl_numFAM_ID1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_numnoplcatmptnum_mp(
    static_cast<uint32_t>(LatCtrl_numNOPLCAtmptNum_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctcamleliconf_mp(
    static_cast<float>(LatCtrl_pctCamLeLiConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctcamnxtleliconf_mp(
    static_cast<float>(LatCtrl_pctCamNxtLeLiConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctcamnxtriliconf_mp(
    static_cast<float>(LatCtrl_pctCamNxtRiLiConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctcamriliconf_mp(
    static_cast<float>(LatCtrl_pctCamRiLiConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctlmconf_mp(static_cast<float>(LatCtrl_pctLMConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctlksleliconfdebnc_mp(
    static_cast<float>(LatCtrl_pctLksLeLiConfDebnc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctlksriliconfdebnc_mp(
    static_cast<float>(LatCtrl_pctLksRiLiConfDebnc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiabsltpinionagreq_mp(
    static_cast<float>(LatCtrl_phiAbsltPinionAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiagreq_mp(static_cast<float>(LatCtrl_phiAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiagveh2lanecntr_mp(
    static_cast<float>(LatCtrl_phiAgVeh2LaneCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiagveh2leftlane_mp(
    static_cast<float>(LatCtrl_phiAgVeh2LeftLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiagveh2rightlane_mp(
    static_cast<float>(LatCtrl_phiAgVeh2RightLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phianglimforlataccellim_mp(
    static_cast<float>(LatCtrl_phiAngLimForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiegolanelinediffc1_mp(
    static_cast<float>(LatCtrl_phiEgoLaneLineDiffC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcastrwhlagreq_mp(
    static_cast<float>(LatCtrl_phiLCAStrWhlAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksstrwhlagreq_mp(
    static_cast<float>(LatCtrl_phiLKSStrWhlAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philec1deadatstart_mp(
    static_cast<float>(LatCtrl_phiLeC1DeadAtStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philec1tresatstart_mp(
    static_cast<float>(LatCtrl_phiLeC1TresAtStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philelanehdgag_mp(
    static_cast<float>(LatCtrl_phiLeLaneHdgAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksovrdagveh2lanecntrdeg_mp(
    static_cast<float>(LatCtrl_phiLksOvrdAgVeh2LaneCntrDeg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksovrdzonemgrprdvagdegraw_mp(
    static_cast<float>(LatCtrl_phiLksOvrdZoneMgrPrdvAgDegRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksovrdzonemgrprdvag_mp(
    static_cast<float>(LatCtrl_phiLksOvrdZoneMgrPrdvAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phimehppc1_mp(static_cast<float>(LatCtrl_phiMeHppC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phinxtlelanehdgag_mp(
    static_cast<float>(LatCtrl_phiNxtLeLaneHdgAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phinxtrilanehdgag_mp(
    static_cast<float>(LatCtrl_phiNxtRiLaneHdgAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiric1deadatstart_mp(
    static_cast<float>(LatCtrl_phiRiC1DeadAtStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiric1tresatstart_mp(
    static_cast<float>(LatCtrl_phiRiC1TresAtStart_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phirilanehdgag_mp(
    static_cast<float>(LatCtrl_phiRiLaneHdgAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phistrwhlagreq_mp(
    static_cast<float>(LatCtrl_phiStrWhlAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiveh2lanecntrag_mp(
    static_cast<float>(LatCtrl_phiVeh2LaneCntrAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiznmgrc1_mp(static_cast<float>(LatCtrl_phiZnMgrC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phinoppinionreq_mp(
    static_cast<float>(LatCtrl_phinoppinionReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_secevdlnchglgtontime_mp(
    static_cast<float>(LatCtrl_secEVDLnChgLgtOnTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_secnotintolnchgtm_mp(
    static_cast<float>(LatCtrl_secNotIntoLnChgTm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stadcwtidsplysts_mp(
    static_cast<uint32_t>(LatCtrl_stADCWTIDsplySts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stagreqtyp_mp(static_cast<uint32_t>(LatCtrl_stAgReqTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stbsdrelewarnvld_mp(
    static_cast<uint32_t>(LatCtrl_stBSDReLeWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stbsdreriwarnvld_mp(
    static_cast<uint32_t>(LatCtrl_stBSDReRiWarnVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamleliqlt_mp(
    static_cast<uint32_t>(LatCtrl_stCamLeLiQlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamleftlinetype_mp(
    static_cast<uint32_t>(LatCtrl_stCamLeftLineType_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamnxtleliqlt_mp(
    static_cast<uint32_t>(LatCtrl_stCamNxtLeLiQlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamnxtriliqlt_mp(
    static_cast<uint32_t>(LatCtrl_stCamNxtRiLiQlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamriliqlt_mp(
    static_cast<uint32_t>(LatCtrl_stCamRiLiQlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stcamrightlinetype_mp(
    static_cast<uint32_t>(LatCtrl_stCamRightLineType_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stconstructionarea_mp(
    static_cast<uint32_t>(LatCtrl_stConstructionArea_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stctrllanechgreqsrc_mp(
    static_cast<uint32_t>(LatCtrl_stCtrlLaneChgReqSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stctrllanechgreq_mp(
    static_cast<uint32_t>(LatCtrl_stCtrlLaneChgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stepsacitsusup_mp(
    static_cast<uint32_t>(LatCtrl_stEPSACITsuSup_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stepsreqtyp_mp(static_cast<uint32_t>(LatCtrl_stEPSReqTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stevdlanechgreason_mp(
    static_cast<uint32_t>(LatCtrl_stEVDLaneChgReason_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stevdlanechngreqaftcnfrm_mp(
    static_cast<uint32_t>(LatCtrl_stEVDLaneChngReqAftCnfrm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stevdrampdir_mp(
    static_cast<uint32_t>(LatCtrl_stEVDRampDir_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stevddistancevalid_mp(
    static_cast<uint32_t>(LatCtrl_stEVDdistanceValid_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stelksprssts_mp(
    static_cast<uint32_t>(LatCtrl_stElkSprsSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stevdvldlanechgreq_mp(
    static_cast<uint32_t>(LatCtrl_stEvdVldLaneChgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stextreqcamfc_mp(
    static_cast<uint32_t>(LatCtrl_stExtReqCAMFC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthighwayexitleft_mp(
    static_cast<uint32_t>(LatCtrl_stHighwayExitLeft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthighwayexitright_mp(
    static_cast<uint32_t>(LatCtrl_stHighwayExitRight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthowsleline_mp(
    static_cast<uint32_t>(LatCtrl_stHoWSLeLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthowsriline_mp(
    static_cast<uint32_t>(LatCtrl_stHoWSRiLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthowsstgfurremaintime_mp(
    static_cast<double>(LatCtrl_stHoWSStgFurRemainTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sthowswarnstg_mp(
    static_cast<uint32_t>(LatCtrl_stHoWSWarnStg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlkslaneassityp_mp(
    static_cast<uint32_t>(LatCtrl_stLKSLaneAssiTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlksletrackingsts_mp(
    static_cast<uint32_t>(LatCtrl_stLKSLeTrackingSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlksritrackingsts_mp(
    static_cast<uint32_t>(LatCtrl_stLKSRiTrackingSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlkssnsvty_mp(static_cast<uint32_t>(LatCtrl_stLKSSnsvty_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlmlelinetype_mp(
    static_cast<uint32_t>(LatCtrl_stLMLeLineType_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlmrilinetype_mp(
    static_cast<uint32_t>(LatCtrl_stLMRiLineType_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlanechngintentraw_mp(
    static_cast<uint32_t>(LatCtrl_stLaneChngIntentRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlanectrloutrng_mp(
    static_cast<uint32_t>(LatCtrl_stLaneCtrlOutRng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlanedepatwarnintvzoneforlataccellim_mp(
    static_cast<uint32_t>(LatCtrl_stLaneDepatWarnIntvZoneForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcrdysts_mp(static_cast<uint32_t>(LatCtrl_stLcRdySts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlelinecolorsts_mp(
    static_cast<uint32_t>(LatCtrl_stLeLineColorSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlelinesrc_mp(static_cast<uint32_t>(LatCtrl_stLeLineSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlelinetyp_mp(static_cast<uint32_t>(LatCtrl_stLeLineTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stleturnidctrlghtsts_mp(
    static_cast<uint32_t>(LatCtrl_stLeTurnIdctrLghtSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlksovrdintvzoneraw_mp(
    static_cast<uint32_t>(LatCtrl_stLksOvrdIntvZoneRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlksovrdintvzone_mp(
    static_cast<uint32_t>(LatCtrl_stLksOvrdIntvZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlockedlnchgcnfrmmthd_mp(
    static_cast<uint32_t>(LatCtrl_stLockedLnChgCnfrmMthd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stmainlatctrlsts_mp(
    static_cast<uint32_t>(LatCtrl_stMainLatCtrlSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopcurntlcprcssrc_mp(
    static_cast<uint32_t>(LatCtrl_stNOPCurntLCPrcsSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopdrvlanechgreq_mp(
    static_cast<uint32_t>(LatCtrl_stNOPDrvLaneChgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopevdlanechgreq_mp(
    static_cast<uint32_t>(LatCtrl_stNOPEVDLaneChgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopintgrtlcreqsrc_mp(
    static_cast<uint32_t>(LatCtrl_stNOPIntgrtLCReqSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopintgrtlcreq_mp(
    static_cast<uint32_t>(LatCtrl_stNOPIntgrtLCReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnoplcatmptnumcalcsts_mp(
    static_cast<uint32_t>(LatCtrl_stNOPLCAtmptNumCalcSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnoplanechngreq2cdc_mp(
    static_cast<uint32_t>(LatCtrl_stNOPLaneChngReq2CDC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopturnidctrswt_mp(
    static_cast<uint32_t>(LatCtrl_stNOPTurnIdctrSwt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopsts_mp(static_cast<uint32_t>(LatCtrl_stNopSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopturnidctrswtchk_mp(
    static_cast<uint32_t>(LatCtrl_stNopTurnIdctrSwtChk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnxtlelinecolorsts_mp(
    static_cast<uint32_t>(LatCtrl_stNxtLeLineColorSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnxtrilinecolorsts_mp(
    static_cast<uint32_t>(LatCtrl_stNxtRiLineColorSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stpilotlndeptwarnsprsst_mp(
    static_cast<uint32_t>(LatCtrl_stPilotLnDeptWarnSprsSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_strerirsdsdisp_mp(
    static_cast<uint32_t>(LatCtrl_stReRiRSDSDisp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_strilinecolorsts_mp(
    static_cast<uint32_t>(LatCtrl_stRiLineColorSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_strilinesrc_mp(static_cast<uint32_t>(LatCtrl_stRiLineSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_strilinetyp_mp(static_cast<uint32_t>(LatCtrl_stRiLineTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_striturnidctrlghtsts_mp(
    static_cast<uint32_t>(LatCtrl_stRiTurnIdctrLghtSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stsetalc_mp(static_cast<uint32_t>(LatCtrl_stSetALC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ststrwhlagsts_mp(
    static_cast<uint32_t>(LatCtrl_stStrWhlAgSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sttrnstznorg_mp(
    static_cast<uint32_t>(LatCtrl_stTrnstZnOrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_sttrnstzn_mp(static_cast<uint32_t>(LatCtrl_stTrnstZn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stturnlghtreq_mp(
    static_cast<uint32_t>(LatCtrl_stTurnLghtReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stturnlightreq_mp(
    static_cast<uint32_t>(LatCtrl_stTurnLightReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stvmc1acitsusup_mp(
    static_cast<uint32_t>(LatCtrl_stVMC1ACITsuSup_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stznmgrreflinests_mp(
    static_cast<uint32_t>(LatCtrl_stZnMgrRefLineSts_mp));
  // fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stadasmaphighway_mp(
  //   static_cast<uint32_t>(LatCtrl_stadasmapHighway_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tiadaslnlewrntimer_mp(
    static_cast<double>(LatCtrl_tiAdasLnLeWrnTimer_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tiadaslnriwrntimer_mp(
    static_cast<double>(LatCtrl_tiAdasLnRiWrnTimer_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tinolaneline4lcasprsdelt_mp(
    static_cast<float>(LatCtrl_tiNoLaneLine4LCASprsDelT_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_titar1obsttc_mp(static_cast<float>(LatCtrl_tiTar1ObsTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_titar3obsttc_mp(static_cast<float>(LatCtrl_tiTar3ObsTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_titar5obsttc_mp(static_cast<float>(LatCtrl_tiTar5ObsTTC_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_trqeqvltlatacccmpsttq_mp(
    static_cast<float>(LatCtrl_trqEqvltLatAccCmpstTq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_trqextlnovrdbsthres_mp(
    static_cast<float>(LatCtrl_trqExtLnOvrdBsThres_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_trqextlnovrdthres_mp(
    static_cast<float>(LatCtrl_trqExtLnOvrdThres_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_trqlkstqreq_mp(static_cast<float>(LatCtrl_trqLKSTqReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_uadaslinecyccntrle_mp(
    static_cast<uint32_t>(LatCtrl_uAdasLineCycCntrLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_uadaslinecyccntrri_mp(
    static_cast<uint32_t>(LatCtrl_uAdasLineCycCntrRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_uadaslinedbgle_mp(
    static_cast<uint32_t>(LatCtrl_uAdasLineDbgLe_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_uadaslinedbgri_mp(
    static_cast<uint32_t>(LatCtrl_uAdasLineDbgRi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ubitnoplanechgreqoff_mp(
    static_cast<uint32_t>(LatCtrl_uBitNOPLaneChgReqOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ucsfhowscdn_mp(static_cast<uint32_t>(LatCtrl_uCsfHoWSCdn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_uedalatsprs_mp(static_cast<uint32_t>(LatCtrl_uEDALatSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_unoplanechgrmdtrg_mp(
    static_cast<uint32_t>(LatCtrl_uNOPLaneChgRmdTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_unoplanechgstoprmdtrg_mp(
    static_cast<uint32_t>(LatCtrl_uNOPLaneChgStopRmdTrg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlacurv_mp(static_cast<float>(LatCtrl_xLaCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xladcurv_mp(static_cast<float>(LatCtrl_xLadCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlelanecur_mp(static_cast<float>(LatCtrl_xLeLaneCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlelanedcur_mp(static_cast<float>(LatCtrl_xLeLanedCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlksovrdzonebrdshftladcurvfltd_mp(
    static_cast<float>(LatCtrl_xLksOvrdZoneBrdShftLadCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlksovrdzonemgrprdvagcurvfltd_mp(
    static_cast<float>(LatCtrl_xLksOvrdZoneMgrPrdvAgCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlksovrdzonemgrprdvcurvdifffltd_mp(
    static_cast<float>(LatCtrl_xLksOvrdZoneMgrPrdvCurvDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlksovrdzonemgrprdvcurvraw_mp(
    static_cast<float>(LatCtrl_xLksOvrdZoneMgrPrdvCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlksovrdzonemgrprdvcurv_mp(
    static_cast<float>(LatCtrl_xLksOvrdZoneMgrPrdvCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlnc1cmpst_mp(static_cast<float>(LatCtrl_xLnC1Cmpst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlnc2cmpst_mp(static_cast<float>(LatCtrl_xLnC2Cmpst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xmehppc2_mp(static_cast<float>(LatCtrl_xMeHppC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xmehppc3_mp(static_cast<float>(LatCtrl_xMeHppC3_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xnxtlelanecur_mp(static_cast<float>(LatCtrl_xNxtLeLaneCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xnxtlelanedcur_mp(
    static_cast<float>(LatCtrl_xNxtLeLanedCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xnxtrilanecur_mp(static_cast<float>(LatCtrl_xNxtRiLaneCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xnxtrilanedcur_mp(
    static_cast<float>(LatCtrl_xNxtRiLanedCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xprevc2forlataccellim_mp(
    static_cast<float>(LatCtrl_xPrevC2ForLatAccelLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xrilanecur_mp(static_cast<float>(LatCtrl_xRiLaneCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xrilanedcur_mp(static_cast<float>(LatCtrl_xRiLanedCur_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xznmgrc2_mp(static_cast<float>(LatCtrl_xZnMgrC2_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_elk_flgisedrtriggered_mp(
    static_cast<bool>(LatCtrl_Elk_flgIsEDRTriggered_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_faclcadeclatacccmptnfacofffctrl_mp(
    static_cast<float>(LatCtrl_Lks_facLcaDecLatAccCmptnFacOfFFCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tialcmnvrongoingtime_mp(
    static_cast<float>(LatCtrl_TiAlcMnvrOngoingTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tialcmnvrpendingtime_mp(
    static_cast<float>(LatCtrl_TiAlcMnvrPendingTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alcaffeqvlntlatacclfnl_mp(
    static_cast<float>(LatCtrl_aLcaFFEqvlntLatAcclFnl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alcaffeqvlntlataccl_mp(
    static_cast<float>(LatCtrl_aLcaFFEqvlntLatAccl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alcafffltlataccl_mp(
    static_cast<float>(LatCtrl_aLcaFFFltLatAccl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alcafflataccldiff_mp(
    static_cast<float>(LatCtrl_aLcaFFLatAcclDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_bflcatakeoversprsmask_mp(
    static_cast<uint32_t>(LatCtrl_bfLCATakeOverSprsMask_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_deglcactlrowag_mp(
    static_cast<float>(LatCtrl_degLCACtlRowAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_deglcalimitangle_mp(
    static_cast<float>(LatCtrl_degLCALimitAngle_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_deglcarefstrngangle_mp(
    static_cast<float>(LatCtrl_degLCARefStrngAngle_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_deglcatransctlangle_mp(
    static_cast<float>(LatCtrl_degLCATransCtlAngle_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_degtranslimitangle_mp(
    static_cast<float>(LatCtrl_degTransLimitAngle_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffaceqvlntlataweight_mp(
    static_cast<float>(LatCtrl_facLcaFFFacEqvlntLatAWeight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffacfinal_mp(
    static_cast<float>(LatCtrl_facLcaFFFacFinal_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffaclarge_mp(
    static_cast<float>(LatCtrl_facLcaFFFacLarge_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffacnormal_mp(
    static_cast<float>(LatCtrl_facLcaFFFacNormal_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffacweightoflatadiff_mp(
    static_cast<float>(LatCtrl_facLcaFFFacWeightOfLatADiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcafffacweight_mp(
    static_cast<float>(LatCtrl_facLcaFFFacWeight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcalatacccmptnfac_mp(
    static_cast<float>(LatCtrl_facLcaLatAccCmptnFac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclcalgtacccmptnfacofffctrl_mp(
    static_cast<float>(LatCtrl_facLcaLgtAccCmptnFacOfFFCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmmehppc0fac_mp(
    static_cast<float>(LatCtrl_facmMeHppC0Fac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmmehppc1fac_mp(
    static_cast<float>(LatCtrl_facmMeHppC1Fac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmmehppc2fac_mp(
    static_cast<float>(LatCtrl_facmMeHppC2Fac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmmehppc3fac_mp(
    static_cast<float>(LatCtrl_facmMeHppC3Fac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmtarlanec0fachld_mp(
    static_cast<float>(LatCtrl_facmTarLaneC0FacHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmtarlanec1fachld_mp(
    static_cast<float>(LatCtrl_facmTarLaneC1FacHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmtarlanec2fachld_mp(
    static_cast<float>(LatCtrl_facmTarLaneC2FacHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facmtarlanec3fachld_mp(
    static_cast<float>(LatCtrl_facmTarLaneC3FacHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgaccnpdrivermsg12le_mp(
    static_cast<bool>(LatCtrl_flgACCNPDriverMsg12Le_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgaccnpdrivermsg12ri_mp(
    static_cast<bool>(LatCtrl_flgACCNPDriverMsg12Ri_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgaccnpdrivermsg5_mp(
    static_cast<bool>(LatCtrl_flgACCNPDriverMsg5_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcnotactvcdn_mp(
    static_cast<bool>(LatCtrl_flgALCNotActvCdn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcmnvrlecrslatch_mp(
    static_cast<bool>(LatCtrl_flgAlcMnvrLeCrsLatch_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcmnvrrchlcfailtime_mp(
    static_cast<bool>(LatCtrl_flgAlcMnvrRchLCFailTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgalcmnvrricrslatch_mp(
    static_cast<bool>(LatCtrl_flgAlcMnvrRiCrsLatch_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flginownlane_mp(static_cast<bool>(LatCtrl_flgInOwnLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcaend_mp(static_cast<bool>(LatCtrl_flgLCAEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalelaneptd_mp(
    static_cast<bool>(LatCtrl_flgLCALeLanePtd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalelinesprs_mp(
    static_cast<bool>(LatCtrl_flgLCALeLineSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalerilinesprs_mp(
    static_cast<bool>(LatCtrl_flgLCALeRiLineSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcarilaneptd_mp(
    static_cast<bool>(LatCtrl_flgLCARiLanePtd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcarilinesprs_mp(
    static_cast<bool>(LatCtrl_flgLCARiLineSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcatakeoverreq_mp(
    static_cast<bool>(LatCtrl_flgLCATakeOverReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcawrkend_mp(static_cast<bool>(LatCtrl_flgLCAWrkEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcawrkfin_mp(static_cast<bool>(LatCtrl_flgLCAWrkFin_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcawrkstsdspl_mp(
    static_cast<bool>(LatCtrl_flgLCAWrkStsDspl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcafeedback_mp(
    static_cast<bool>(LatCtrl_flgLCAfeedback_mp));
  // fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglclenozoom_mp(static_cast<bool>(LatCtrl_flgLCLeNoZoom_mp));
  // fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcrinozoom_mp(static_cast<bool>(LatCtrl_flgLCRiNoZoom_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcaleovershoot_mp(
    static_cast<bool>(LatCtrl_flgLcaLeOverShoot_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalestragdirt_mp(
    static_cast<bool>(LatCtrl_flgLcaLeStrAgDirt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcaleundershoot_mp(
    static_cast<bool>(LatCtrl_flgLcaLeUnderShoot_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcalevylmt_mp(static_cast<bool>(LatCtrl_flgLcaLeVyLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcariovershoot_mp(
    static_cast<bool>(LatCtrl_flgLcaRiOverShoot_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcaristragdirt_mp(
    static_cast<bool>(LatCtrl_flgLcaRiStrAgDirt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcariundershoot_mp(
    static_cast<bool>(LatCtrl_flgLcaRiUnderShoot_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglcarivylmt_mp(static_cast<bool>(LatCtrl_flgLcaRiVyLmt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanecrsg_mp(static_cast<bool>(LatCtrl_flgLeLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglelanereqtrig_mp(
    static_cast<bool>(LatCtrl_flgLeLaneReqTrig_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglongitudedstend_mp(
    static_cast<bool>(LatCtrl_flgLongitudeDstEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgmehppispred_mp(
    static_cast<bool>(LatCtrl_flgMeHppIsPred_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnewintoinlnchgprcs_mp(
    static_cast<bool>(LatCtrl_flgNewIntoInLnChgPrcs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnopdecision_mp(
    static_cast<bool>(LatCtrl_flgNopDecision_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnoplonpossprs_mp(
    static_cast<bool>(LatCtrl_flgNopLonPosSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgnotinlnchgpndngovtm_mp(
    static_cast<bool>(LatCtrl_flgNotInLnChgPndngOvTm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanecrsg_mp(static_cast<bool>(LatCtrl_flgRiLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgrilanereqtrig_mp(
    static_cast<bool>(LatCtrl_flgRiLaneReqTrig_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_legolaneradst_mp(static_cast<float>(LatCtrl_lEgoLaneRaDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_legolanewdthdst_mp(
    static_cast<float>(LatCtrl_lEgoLaneWdthDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llcalanechgdst_mp(
    static_cast<float>(LatCtrl_lLCALaneChgDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llatactdst_mp(static_cast<float>(LatCtrl_lLatActDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llatdsterr_mp(static_cast<float>(LatCtrl_lLatDstErr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llatrefdst_mp(static_cast<float>(LatCtrl_lLatRefDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llateraltrckest_mp(
    static_cast<float>(LatCtrl_lLateralTrckEst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llcalatdsterr_mp(static_cast<float>(LatCtrl_lLcaLatDstErr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelanecntrc1_mp(static_cast<float>(LatCtrl_lLeLaneCntrC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llelanecntrdst_mp(
    static_cast<float>(LatCtrl_lLeLaneCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llongitudetrckest_mp(
    static_cast<float>(LatCtrl_lLongitudeTrckEst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplanewdth_mp(
    static_cast<float>(LatCtrl_lMeHppLaneWdth_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplatctlpnt_mp(
    static_cast<float>(LatCtrl_lMeHppLatCtlPnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lmehpplonctlpnt_mp(
    static_cast<float>(LatCtrl_lMeHppLonCtlPnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lnoplonctldst_mp(static_cast<float>(LatCtrl_lNopLonCtlDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilanecntrc1_mp(static_cast<float>(LatCtrl_lRiLaneCntrC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lrilanecntrdst_mp(
    static_cast<float>(LatCtrl_lRiLaneCntrDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_mlnchgegolnc0hld_mp(
    static_cast<float>(LatCtrl_mLnChgEgoLnC0Hld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_numlcafiterrnum_mp(
    static_cast<uint32_t>(LatCtrl_numLcaFitErrNum_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctegovehlnchgoverlinepct_mp(
    static_cast<float>(LatCtrl_pctEgoVehLnChgOverLinePct_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_pctmehppconf_mp(static_cast<float>(LatCtrl_pctMeHppConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiangletrckest_mp(
    static_cast<float>(LatCtrl_phiAngleTrckEst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcacurvctlag_mp(
    static_cast<float>(LatCtrl_phiLCACurvCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcacurvffctlag_mp(
    static_cast<float>(LatCtrl_phiLCACurvFfCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcalanechgctlag_mp(
    static_cast<float>(LatCtrl_phiLCALaneChgCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcalatagerrctlag_mp(
    static_cast<float>(LatCtrl_phiLCALatAgErrCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcalatclsctlag_mp(
    static_cast<float>(LatCtrl_phiLCALatClsCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philcalatdisctlag_mp(
    static_cast<float>(LatCtrl_phiLCALatDisCtlAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philatactag_mp(static_cast<float>(LatCtrl_phiLatActAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philatagerr_mp(static_cast<float>(LatCtrl_phiLatAgErr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philatrefag_mp(static_cast<float>(LatCtrl_phiLatRefAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_slcproceduretime_mp(
    static_cast<float>(LatCtrl_sLCProcedureTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_snoplonctltime_mp(
    static_cast<float>(LatCtrl_sNopLonCtlTime_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_secnotinlnchgprcstm_mp(
    static_cast<float>(LatCtrl_secNotInLnChgPrcsTm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stalcsstatus_mp(
    static_cast<uint32_t>(LatCtrl_stALCSStatus_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stalcsts_mp(static_cast<uint32_t>(LatCtrl_stALCSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stadasleline_mp(
    static_cast<uint32_t>(LatCtrl_stAdasLeLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stadasriline_mp(
    static_cast<uint32_t>(LatCtrl_stAdasRiLine_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcaendsts_mp(static_cast<uint32_t>(LatCtrl_stLCAEndSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcalanechagwarnsts_mp(
    static_cast<uint32_t>(LatCtrl_stLCALaneChagWarnSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcalatdststs_mp(
    static_cast<uint32_t>(LatCtrl_stLCALatDstSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcamnsts_mp(static_cast<uint32_t>(LatCtrl_stLCAMnSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcareflinecurvsts_mp(
    static_cast<uint32_t>(LatCtrl_stLCARefLineCurvSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcawrkmode_mp(
    static_cast<uint32_t>(LatCtrl_stLCAWrkMode_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlanechngintentdly_mp(
    static_cast<uint32_t>(LatCtrl_stLaneChngIntentDly_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlastvldlnchgintent_mp(
    static_cast<uint32_t>(LatCtrl_stLastVldLnChgIntent_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlatctlsts_mp(static_cast<uint32_t>(LatCtrl_stLatCtlSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlatposeststs_mp(
    static_cast<uint32_t>(LatCtrl_stLatPosEstSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlcamaneuver_mp(
    static_cast<uint32_t>(LatCtrl_stLcaManeuver_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlnchgintent_mp(
    static_cast<uint32_t>(LatCtrl_stLnChgIntent_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlonctltarget_mp(
    static_cast<uint32_t>(LatCtrl_stLonCtlTarget_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stmanusts_mp(static_cast<uint32_t>(LatCtrl_stManuSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopdecisionid_mp(
    static_cast<uint32_t>(LatCtrl_stNopDecisionID_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stnopzoneid_mp(static_cast<uint32_t>(LatCtrl_stNopZoneID_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tilcalanechgt_mp(static_cast<float>(LatCtrl_tiLCALaneChgT_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_tilanechgthld_mp(static_cast<float>(LatCtrl_tiLaneChgTHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_ualcmnvrcdn_mp(static_cast<uint32_t>(LatCtrl_uAlcMnvrCdn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_vlcavehspdhld_mp(static_cast<float>(LatCtrl_vLCAVehSpdHld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlcaroadcurvrt_mp(
    static_cast<float>(LatCtrl_xLCARoadCurvRT_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_algtlacc_mp(static_cast<float>(LatCtrl_Lka_aLgtlAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_altrlacc_mp(static_cast<float>(LatCtrl_Lka_aLtrlAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_dphiyawrate_mp(
    static_cast<float>(LatCtrl_Lka_dphiYawRate_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrlcurvgain_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlCurvGain_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrldrtreqtrsnbartrqarbtfac_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlDrtReqTrsnbarTrqArbtFac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrldrtreqtrsnbartrqfac_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlDrtReqTrsnbarTrqFac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrlinactvblndng_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlInactvBlndng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrlleftblndng_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlLeftBlndng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrlrightblndng_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlRightBlndng_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrltrgtpntdstgain_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlTrgtPntDstGain_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_facagctrlyawaggain_mp(
    static_cast<float>(LatCtrl_Lka_facAgCtrlYawAgGain_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgadcsysvldout_mp(
    static_cast<bool>(LatCtrl_Lka_flgADCSysVldOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgactv2inactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgActv2Inactv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgactv2stdby_mp(
    static_cast<bool>(LatCtrl_Lka_flgActv2Stdby_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgactv2warn_mp(
    static_cast<bool>(LatCtrl_Lka_flgActv2Warn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagactravl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgActrAvl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrtreqenbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrtReqEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrtreqoutrdstenbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrtReqOutrDstEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrtreqpinionagdiffenbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrtReqPinionAgDiffEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrtreqtrsnbartrqdiffenbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrtReqTrsnbarTrqDiffEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrtreqtrsnbartrqenbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrtReqTrsnbarTrqEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrldrvrovrdinr_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlDrvrOvrdInr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrlovrshtlmtdactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlOvrshtLmtdActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagctrltrsnbartrqagdrvrovrdinr_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgCtrlTrsnbarTrqAgDrvrOvrdInr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgagreqactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgAgReqActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgcfgbyuds_mp(
    static_cast<bool>(LatCtrl_Lka_flgCfgByUDS_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgcmrblk_mp(static_cast<bool>(LatCtrl_Lka_flgCmrBlk_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgdashandoff_mp(
    static_cast<bool>(LatCtrl_Lka_flgDASHandOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgepsmottrqvld_mp(
    static_cast<bool>(LatCtrl_Lka_flgEPSMotTrqVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgepspinionagvld_mp(
    static_cast<bool>(LatCtrl_Lka_flgEPSPinionAgVld_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgenbl_mp(static_cast<bool>(LatCtrl_Lka_flgEnbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgfail_mp(static_cast<bool>(LatCtrl_Lka_flgFail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgfrmwrdsbl_mp(
    static_cast<bool>(LatCtrl_Lka_flgFrmwrDsbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flggenactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgGenActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flghiactravl_mp(
    static_cast<bool>(LatCtrl_Lka_flgHIActrAvl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flghandoffdctd_mp(
    static_cast<bool>(LatCtrl_Lka_flgHandOffDctd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flghapticreqactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgHapticReqActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flginactv2leftintv_mp(
    static_cast<bool>(LatCtrl_Lka_flgInactv2LeftIntv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flginactv2rightintv_mp(
    static_cast<bool>(LatCtrl_Lka_flgInactv2RightIntv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgintvenblout_mp(
    static_cast<bool>(LatCtrl_Lka_flgIntvEnblOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flglaneassthapticonoffstsout_mp(
    static_cast<bool>(LatCtrl_Lka_flgLaneAsstHapticOnOffStsOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgleftlanecrsgcalc_mp(
    static_cast<bool>(LatCtrl_Lka_flgLeftLaneCrsgCalc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgleftlanecrsgraw_mp(
    static_cast<bool>(LatCtrl_Lka_flgLeftLaneCrsgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgleftlanecrsg_mp(
    static_cast<bool>(LatCtrl_Lka_flgLeftLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgoff2fail_mp(
    static_cast<bool>(LatCtrl_Lka_flgOff2Fail_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgoff_mp(static_cast<bool>(LatCtrl_Lka_flgOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgon_mp(static_cast<bool>(LatCtrl_Lka_flgOn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrightlanecrsgcalc_mp(
    static_cast<bool>(LatCtrl_Lka_flgRightLaneCrsgCalc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrightlanecrsgraw_mp(
    static_cast<bool>(LatCtrl_Lka_flgRightLaneCrsgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrightlanecrsg_mp(
    static_cast<bool>(LatCtrl_Lka_flgRightLaneCrsg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgrstwarnseq_mp(
    static_cast<bool>(LatCtrl_Lka_flgRstWarnSeq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgselsts_mp(static_cast<bool>(LatCtrl_Lka_flgSelSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgstdby2actv_mp(
    static_cast<bool>(LatCtrl_Lka_flgStdby2Actv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgstdby2leintv_mp(
    static_cast<bool>(LatCtrl_Lka_flgStdby2LeIntv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgstdby2riintv_mp(
    static_cast<bool>(LatCtrl_Lka_flgStdby2RiIntv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgstdbybygensprs_mp(
    static_cast<bool>(LatCtrl_Lka_flgStdbyByGenSprs_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgswtsts_mp(static_cast<bool>(LatCtrl_Lka_flgSwtSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgtakeoverreqout_mp(
    static_cast<bool>(LatCtrl_Lka_flgTakeOverReqOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgtrqactravl_mp(
    static_cast<bool>(LatCtrl_Lka_flgTrqActrAvl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgtrqreqactv_mp(
    static_cast<bool>(LatCtrl_Lka_flgTrqReqActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgwarn2stdby_mp(
    static_cast<bool>(LatCtrl_Lka_flgWarn2Stdby_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgwarnstg1actv_mp(
    static_cast<bool>(LatCtrl_Lka_flgWarnStg1Actv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_flgwarnstg2actv_mp(
    static_cast<bool>(LatCtrl_Lka_flgWarnStg2Actv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstlacntr2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstLaCntr2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstlacntr2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstLaCntr2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstleftla2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstLeftLa2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstleftla2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstLeftLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstrightla2vehcntrraw_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstRightLa2VehCntrRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlactvltrldstrightla2vehcntr_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlActvLtrlDstRightLa2VehCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrldrtreqoutrdstcls2brddstmax_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlDrtReqOutrDstCls2BrdDstMax_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrldstdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlDstDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrldstdiffraw_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlDstDiffRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlinrzonebrdlanewdthshft_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlInrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlleftzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlLeftZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlltrldstintg_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlLtrlDstIntg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrlrightzonebrdactltrlaccshft_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlRightZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrltgrtleftinrzone_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlTgrtLeftInrZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrltgrtrightinrzone_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlTgrtRightInrZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lagctrltrgtpntdst_mp(
    static_cast<float>(LatCtrl_Lka_lAgCtrlTrgtPntDst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_llelinedstout_mp(
    static_cast<float>(LatCtrl_Lka_lLeLineDstOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_lrilinedstout_mp(
    static_cast<float>(LatCtrl_Lka_lRiLineDstOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlactvltrldstagfromest_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlActvLtrlDstAgFromEst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlactvltrldstagfromtrgnfun_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlActvLtrlDstAgFromTrgnFun_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlactvltrldstagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlActvLtrlDstAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlactvltrldstag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlActvLtrlDstAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc0basedagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC0BasedAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc0basedag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC0BasedAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc1basedagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC1BasedAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc1basedag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC1BasedAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc2basedagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC2BasedAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc2basedag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC2BasedAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlc3basedag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlC3BasedAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlcurvadjstdag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlCurvAdjstdAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlcurvaglmtd_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlCurvAgLmtd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlcurvag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlCurvAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlcurvdiffagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlCurvDiffAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlcurvdiffag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlCurvDiffAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldebugrefstrngag40_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDebugRefStrngAg40_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldrtreqofst_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDrtReqOfst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldrtreqpinionagdiffarbt_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDrtReqPinionAgDiffArbt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldrtreqpinionagdiffraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDrtReqPinionAgDiffRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldrtreqpinionagdiff_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDrtReqPinionAgDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldrtreq_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDrtReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldstdiffagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDstDiffAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrldstdiffag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlDstDiffAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlintvofstag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlIntvOfstAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlltrldstintgag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlLtrlDstIntgAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrlayrefstrngag40_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrlayRefStrngAg40_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagdiffraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgDiffRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagdiffterm_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgDiffTerm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagintgterm_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgIntgTerm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagpropterm_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgPropTerm_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlovrshtlmtdag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlOvrshtLmtdAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlprdvagdegraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlPrdvAgDegRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlprdvag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlPrdvAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlprdvcurvadjstdag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlPrdvCurvAdjstdAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlprdvcurvag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlPrdvCurvAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlprdvyawag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlPrdvYawAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagbeforegrad_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgBeforeGrad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagdecgrad_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgDecGrad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngaggradlmtd_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgGradLmtd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagincgrad_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgIncGrad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagmax_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgMax_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagmin_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgMin_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagovrshtlmtd_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgOvrshtLmtd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlrefstrngag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlRefStrngAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlstrngagreq_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlStrngAgReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrltrsnbartrqag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlTrsnbarTrqAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlyawagdiffagraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlYawAgDiffAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlyawagdiffag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlYawAgDiffAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlyawagdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlYawAgDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlyawagdiffraw_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlYawAgDiffRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagctrlyawag_mp(
    static_cast<float>(LatCtrl_Lka_phiAgCtrlYawAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiagreqout_mp(
    static_cast<float>(LatCtrl_Lka_phiAgReqOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_phiepspinionag_mp(
    static_cast<float>(LatCtrl_Lka_phiEPSPinionAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_staccnpsts_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stAccNpSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stactvextifc_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stActvExtIfc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stadaslelineout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stAdasLeLineOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stadasrilineout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stAdasRiLineOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stagctrlcurvintvst_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stAgCtrlCurvIntvSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stasstst_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stAsstSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stcdcsetlaneassiaidtyp_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stCDCSetLaneAssiAidTyp_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stdrvoverridedetn_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stDrvOverRideDetn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stepsreqtypout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stEPSReqTypOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stepssts_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stEPSSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_sthodwarnseqreqout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stHODWarnSeqReqOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_sthandsoffdetconf_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stHandsOffDetConf_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_sthdfstlcaout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stHdfStLcaOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stintvst_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stIntvSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlaneasstsnvty_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneAsstSnvty_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlaneasststsout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneAsstStsOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlaneassttactileonoff_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneAsstTactileOnOff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlaneassttypout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLaneAsstTypOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stlelinetypout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stLeLineTypOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_strilinetypout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stRiLineTypOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stsnvtyout_mp(
    static_cast<uint32_t>(LatCtrl_Lka_stSnvtyOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_stvehst_mp(static_cast<uint32_t>(LatCtrl_Lka_stVehSt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqagctrldrtreqtrsnbartrqdiffarbt_mp(
    static_cast<float>(LatCtrl_Lka_trqAgCtrlDrtReqTrsnbarTrqDiffArbt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqagctrldrtreqtrsnbartrqdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_trqAgCtrlDrtReqTrsnbarTrqDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqagctrldrtreqtrsnbartrqdiffraw_mp(
    static_cast<float>(LatCtrl_Lka_trqAgCtrlDrtReqTrsnbarTrqDiffRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqagctrldrtreqtrsnbartrqfltd_mp(
    static_cast<float>(LatCtrl_Lka_trqAgCtrlDrtReqTrsnbarTrqFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqagctrltrqagtrsnbartrqfltd_mp(
    static_cast<float>(LatCtrl_Lka_trqAgCtrlTrqAgTrsnbarTrqFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqepsmotortq_mp(
    static_cast<float>(LatCtrl_Lka_trqEPSMotorTq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqtrqreqout_mp(
    static_cast<float>(LatCtrl_Lka_trqTrqReqOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_trqtrsnbartrq_mp(
    static_cast<float>(LatCtrl_Lka_trqTrsnbarTrq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_vvehdispspd_mp(
    static_cast<float>(LatCtrl_Lka_vVehDispSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_vvehspd_mp(static_cast<float>(LatCtrl_Lka_vVehSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlladcurvfltd_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlLadCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlprdvagcurvdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlPrdvAgCurvDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlprdvagcurvfltd_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlPrdvAgCurvFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlprdvcurvdifffltd_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlPrdvCurvDiffFltd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlprdvcurvraw_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlPrdvCurvRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lka_xagctrlprdvcurv_mp(
    static_cast<float>(LatCtrl_Lka_xAgCtrlPrdvCurv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlintgsep_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlIntgSep_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkc0_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKc0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkc1_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKc1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkiofeqvlntlatacc_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKiOfEqvlntLatAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkioflatspdraw_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKiOfLatSpdRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkioflatspd_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKiOfLatSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkiofspd_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKiOfSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_facctrlkioftorsbartq_mp(
    static_cast<float>(LatCtrl_Lks_facCtrlKiOfTorsBarTq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_faclksdeclatacccmptnfacofffctrl_mp(
    static_cast<float>(LatCtrl_Lks_facLksDecLatAccCmptnFacOfFFCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_flgexitcurveroad_mp(
    static_cast<bool>(LatCtrl_Lks_flgExitCurveRoad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_flglksitgragfadeoutactv_mp(
    static_cast<bool>(LatCtrl_Lks_flgLksItgrAgFadeOutActv_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_lintgldywithdeadzone_mp(
    static_cast<float>(LatCtrl_Lks_lIntgldYWithDeadZone_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_philksitgragfadeout_mp(
    static_cast<float>(LatCtrl_Lks_phiLksItgrAgFadeOut_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lks_xctrlintgpredcurv4lmtr_mp(
    static_cast<float>(LatCtrl_Lks_xCtrlIntgPredCurv4Lmtr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alksffeqvlntlatacclfnl_mp(
    static_cast<float>(LatCtrl_aLksFFEqvlntLatAcclFnl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alksffeqvlntlataccl_mp(
    static_cast<float>(LatCtrl_aLksFFEqvlntLatAccl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alksfffltlataccl_mp(
    static_cast<float>(LatCtrl_aLksFFFltLatAccl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_alksfflataccldiff_mp(
    static_cast<float>(LatCtrl_aLksFFLatAcclDiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facbiglatofscmpst_mp(
    static_cast<float>(LatCtrl_facBigLatOfsCmpst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffaceqvlntlataweight_mp(
    static_cast<float>(LatCtrl_facFFFacEqvlntLatAWeight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facfffacweightoflatadiff_mp(
    static_cast<float>(LatCtrl_facFFFacWeightOfLatADiff_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlki_mp(static_cast<float>(LatCtrl_facLksCtrlKi_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlpntbasic_mp(
    static_cast<float>(LatCtrl_facLksCtrlPntBasic_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlpntcmpstofc0_mp(
    static_cast<float>(LatCtrl_facLksCtrlPntCmpstOfC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlpntcmpstofc1_mp(
    static_cast<float>(LatCtrl_facLksCtrlPntCmpstOfC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlpntcmpstoflatacc_mp(
    static_cast<float>(LatCtrl_facLksCtrlPntCmpstOfLatAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksctrlpntcmpstoflgtacc_mp(
    static_cast<float>(LatCtrl_facLksCtrlPntCmpstOfLgtAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfffacfinal_mp(
    static_cast<float>(LatCtrl_facLksFFFacFinal_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfffaclarge_mp(
    static_cast<float>(LatCtrl_facLksFFFacLarge_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfffacnormal_mp(
    static_cast<float>(LatCtrl_facLksFFFacNormal_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfffacweight_mp(
    static_cast<float>(LatCtrl_facLksFFFacWeight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfbctrlweightc0_mp(
    static_cast<float>(LatCtrl_facLksFbCtrlWeightC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfbctrlweightc1_mp(
    static_cast<float>(LatCtrl_facLksFbCtrlWeightC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclksfbctrlweight_mp(
    static_cast<float>(LatCtrl_facLksFbCtrlWeight_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslatacccmptnfacoffbctrl_mp(
    static_cast<float>(LatCtrl_facLksLatAccCmptnFacOfFbCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslatacccmptnfac_mp(
    static_cast<float>(LatCtrl_facLksLatAccCmptnFac_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslgtacccmptnfacofffctrl_mp(
    static_cast<float>(LatCtrl_facLksLgtAccCmptnFacOfFFCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslgtacccmptnfacoffbctrl_mp(
    static_cast<float>(LatCtrl_facLksLgtAccCmptnFacOfFbCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslvctrlpntbasic_mp(
    static_cast<float>(LatCtrl_facLksLvCtrlPntBasic_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslvctrlpntcmpstofc0_mp(
    static_cast<float>(LatCtrl_facLksLvCtrlPntCmpstOfC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslvctrlpntcmpstofc1_mp(
    static_cast<float>(LatCtrl_facLksLvCtrlPntCmpstOfC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslvctrlpntcmpstoflatacc_mp(
    static_cast<float>(LatCtrl_facLksLvCtrlPntCmpstOfLatAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_faclkslvctrlpntcmpstoflgtacc_mp(
    static_cast<float>(LatCtrl_facLksLvCtrlPntCmpstOfLgtAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_facpctrlgradfact_mp(
    static_cast<float>(LatCtrl_facPCtrlGradFact_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgagintrstalimrst_mp(
    static_cast<bool>(LatCtrl_flgAgIntrStaLimRst_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgdummyc0rampindisbl_mp(
    static_cast<bool>(LatCtrl_flgDummyC0RampInDisbl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgfbgrdntlmtena_mp(
    static_cast<bool>(LatCtrl_flgFbGrdntLmtEna_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flggradlimmode_mp(
    static_cast<bool>(LatCtrl_flgGradLimMode_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksagstrtlimend4belowmin_mp(
    static_cast<bool>(LatCtrl_flgLksAgStrtLimEnd4BelowMin_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksagstrtlimend4cls2trgt_mp(
    static_cast<bool>(LatCtrl_flgLksAgStrtLimEnd4Cls2Trgt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksagstrtlimend4time_mp(
    static_cast<bool>(LatCtrl_flgLksAgStrtLimEnd4Time_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksagstrtlimend_mp(
    static_cast<bool>(LatCtrl_flgLksAgStrtLimEnd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flglksstartdummyc0ena_mp(
    static_cast<bool>(LatCtrl_flgLksStartDummyC0Ena_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgsprslowdispspd_mp(
    static_cast<bool>(LatCtrl_flgSprsLowDispSpd_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_flgtolanecntr_mp(static_cast<bool>(LatCtrl_flgToLaneCntr_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_idxscenarionum_mp(
    static_cast<uint32_t>(LatCtrl_idxScenarioNum_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_idxdyshiftnum_mp(
    static_cast<uint32_t>(LatCtrl_idxdYShiftNum_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksctrltargetpoint_mp(
    static_cast<float>(LatCtrl_lLksCtrlTargetPoint_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llkscurvcalcedlatacc_mp(
    static_cast<float>(LatCtrl_lLksCurvCalcedLatAcc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llkslvlmctrltargetpoint_mp(
    static_cast<float>(LatCtrl_lLksLvlmCtrlTargetPoint_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksstartdummyc0max_mp(
    static_cast<float>(LatCtrl_lLksStartDummyC0Max_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksstartdummyc0rampin_mp(
    static_cast<float>(LatCtrl_lLksStartDummyC0RampIn_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksstartdummyc0_mp(
    static_cast<float>(LatCtrl_lLksStartDummyC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llksstartdummydltc0_mp(
    static_cast<float>(LatCtrl_lLksStartDummyDltC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_llkstrgtpntc0_mp(static_cast<float>(LatCtrl_lLksTrgtPntC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_lltrldstlacntr2vehcntrdummy_mp(
    static_cast<float>(LatCtrl_lLtrlDstLaCntr2VehCntrDummy_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiagintrstalim_mp(
    static_cast<float>(LatCtrl_phiAgIntrStaLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phicurvffctrl_mp(static_cast<float>(LatCtrl_phiCurvFfCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phifbarbttgtreqdlt_mp(
    static_cast<float>(LatCtrl_phiFbArbtTgtReqDlt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phifbarbttgtreq_mp(
    static_cast<float>(LatCtrl_phiFbArbtTgtReq_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phifbgrdntlmtag_mp(
    static_cast<float>(LatCtrl_phiFbGrdntLmtAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phigenlim_mp(static_cast<float>(LatCtrl_phiGenLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phiictrl_mp(static_cast<float>(LatCtrl_phiICtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkscntrareactrlc0_mp(
    static_cast<float>(LatCtrl_phiLksCntrAreaCtrlC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkscntrareactrlc1_mp(
    static_cast<float>(LatCtrl_phiLksCntrAreaCtrlC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkscntrareactrlp_mp(
    static_cast<float>(LatCtrl_phiLksCntrAreaCtrlP_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksgenctrlc0_mp(
    static_cast<float>(LatCtrl_phiLksGenCtrlC0_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksgenctrlc1_mp(
    static_cast<float>(LatCtrl_phiLksGenCtrlC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksgenctrlp_mp(
    static_cast<float>(LatCtrl_phiLksGenCtrlP_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksitgraglim_mp(
    static_cast<float>(LatCtrl_phiLksItgrAgLim_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkslapctrl_mp(static_cast<float>(LatCtrl_phiLksLaPCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkslvlmagpctrl_mp(
    static_cast<float>(LatCtrl_phiLksLvlmAgPCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkslvlmpctrl_mp(
    static_cast<float>(LatCtrl_phiLksLvlmPCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkslvlmpdyctrl_mp(
    static_cast<float>(LatCtrl_phiLksLvlmPdYCtrl_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkspctrlfinal_mp(
    static_cast<float>(LatCtrl_phiLksPCtrlFinal_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkspctrlsaturation_mp(
    static_cast<float>(LatCtrl_phiLksPCtrlSaturation_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philksstrtupgrdntlimgrdnt_mp(
    static_cast<float>(LatCtrl_phiLksStrtupGrdntLimGrdnt_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_philkstrgtpntc1_mp(
    static_cast<float>(LatCtrl_phiLksTrgtPntC1_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phinormagtolane_mp(
    static_cast<float>(LatCtrl_phiNormAgToLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phipctrlbsgrad_mp(
    static_cast<float>(LatCtrl_phiPCtrlBsGrad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phipctrlgrad_mp(static_cast<float>(LatCtrl_phiPCtrlGrad_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phirefstrngagraw_mp(
    static_cast<float>(LatCtrl_phiRefStrngAgRaw_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_phirefstrngag_mp(static_cast<float>(LatCtrl_phiRefStrngAg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_radestagtolane_mp(
    static_cast<float>(LatCtrl_radEstAgToLane_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlkssts_mp(static_cast<uint32_t>(LatCtrl_stLksSts_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_stlmsrc_mp(static_cast<uint32_t>(LatCtrl_stLmSrc_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xbiglatofscmpstintg_mp(
    static_cast<float>(LatCtrl_xBigLatOfsCmpstIntg_mp));
  fct_debug_out.mutable_latctrl_debug_out()->set_latctrl_xlkstrgtpntc2_mp(static_cast<float>(LatCtrl_xLksTrgtPntC2_mp));
}

void elkct_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiagctrlc0basedag_mp(
    static_cast<float>(ELKCT_phiAgCtrlC0BasedAg_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiagctrlc1basedag_mp(
    static_cast<float>(ELKCT_phiAgCtrlC1BasedAg_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiagctrlcurvaglmtd_mp(
    static_cast<float>(ELKCT_phiAgCtrlCurvAgLmtd_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiagctrlrefstrngagraw_mp(
    static_cast<float>(ELKCT_phiAgCtrlRefStrngAgRaw_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiagctrltrsnbartrqbasedag_mp(
    static_cast<float>(ELKCT_phiAgCtrlTrsnbarTrqBasedAg_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiovershootlimitedangle_mp(
    static_cast<float>(ELKCT_phiOvershootLimitedAngle_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phiresetanglerequest_mp(
    static_cast<float>(ELKCT_phiResetAngleRequest_mp));
  fct_debug_out.mutable_elkct_debug_out()->set_elkct_phistrngagreq_mp(static_cast<float>(ELKCT_phiStrngAgReq_mp));
}

void elkh_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_elkh_debug_out()->set_elkh_stadasleline_mp(static_cast<uint32_t>(ELKH_stAdasLeLine_mp));
  fct_debug_out.mutable_elkh_debug_out()->set_elkh_stadasriline_mp(static_cast<uint32_t>(ELKH_stAdasRiLine_mp));
  fct_debug_out.mutable_elkh_debug_out()->set_elkh_stesfwarninglevel_mp(
    static_cast<uint32_t>(ELKH_stESFWarningLevel_mp));
}

void elkss_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_mprdvlnc0_mp(static_cast<float>(ELKSS_mPrdvLnC0_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_radprdvlnc1_mp(static_cast<float>(ELKSS_radPrdvLnC1_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_stelkfamsts_mp(static_cast<uint32_t>(ELKSS_stElkFAMSts_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_stelksts_mp(static_cast<uint32_t>(ELKSS_stElkSts_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_stlnasststs_mp(static_cast<uint32_t>(ELKSS_stLnAsstSts_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_usmcdn_mp(static_cast<uint32_t>(ELKSS_uSmCdn_mp));
  fct_debug_out.mutable_elkss_debug_out()->set_elkss_xprdvlncurv_mp(static_cast<float>(ELKSS_xPrdvLnCurv_mp));
}

void mtn_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_aestacctara_mp(static_cast<float>(Mtn_Plan_aEstAccTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_aestacctarb_mp(static_cast<float>(Mtn_Plan_aEstAccTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_facnormhwycompa_mp(
    static_cast<double>(Mtn_Plan_facNormHwyCompA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_facnormhwycompb_mp(
    static_cast<double>(Mtn_Plan_facNormHwyCompB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_factoacchldwght_mp(
    static_cast<double>(Mtn_Plan_facToACCHldWght_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_factoaccwght_mp(static_cast<double>(Mtn_Plan_facToACCWght_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgcipvsftyintvt_mp(
    static_cast<bool>(Mtn_Plan_flgCIPVSftyIntvt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgisoccupytarln_mp(
    static_cast<bool>(Mtn_Plan_flgIsOccupyTarLn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgsafeaccreq_mp(static_cast<bool>(Mtn_Plan_flgSafeAccReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtarvlda_mp(static_cast<bool>(Mtn_Plan_flgTarVldA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtarvldb_mp(static_cast<bool>(Mtn_Plan_flgTarVldB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_idxnopavlbacclabltyub_mp(
    static_cast<uint32_t>(Mtn_Plan_idxNopAvlbAcclAbltyUb_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mactrngtara_mp(static_cast<float>(Mtn_Plan_mActRngTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mactrngtarb_mp(static_cast<float>(Mtn_Plan_mActRngTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mbkwexprnghitara_mp(
    static_cast<double>(Mtn_Plan_mBkwExpRngHiTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mbkwexprnghitarb_mp(
    static_cast<double>(Mtn_Plan_mBkwExpRngHiTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mbkwexprnglotara_mp(
    static_cast<double>(Mtn_Plan_mBkwExpRngLoTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mbkwexprnglotarb_mp(
    static_cast<double>(Mtn_Plan_mBkwExpRngLoTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrnglmttara_mp(static_cast<float>(Mtn_Plan_mEstRngLmtTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrnglmttarb_mp(static_cast<float>(Mtn_Plan_mEstRngLmtTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngtara_mp(static_cast<float>(Mtn_Plan_mEstRngTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngtarb_mp(static_cast<float>(Mtn_Plan_mEstRngTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mexprngtara_mp(static_cast<double>(Mtn_Plan_mExpRngTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mexprngtarb_mp(static_cast<double>(Mtn_Plan_mExpRngTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfwexprnghitara_mp(
    static_cast<double>(Mtn_Plan_mFwExpRngHiTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfwexprnghitarb_mp(
    static_cast<double>(Mtn_Plan_mFwExpRngHiTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfwexprnglotara_mp(
    static_cast<double>(Mtn_Plan_mFwExpRngLoTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfwexprnglotarb_mp(
    static_cast<double>(Mtn_Plan_mFwExpRngLoTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mmntarcomphdy_mp(static_cast<double>(Mtn_Plan_mMnTarCompHdy_mp));
  fct_debug_out.mutable_mtn_debug_out()->add_mtn_plan_msidetarcomphdy_mp(
    static_cast<double>(Mtn_Plan_mSideTarCompHdy_mp[0]));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtseintvtrng_mp(static_cast<double>(Mtn_Plan_mTSEIntvtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtseminflwgap_mp(static_cast<double>(Mtn_Plan_mTSEMinFlwGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtsiintvtrng_mp(static_cast<double>(Mtn_Plan_mTSIIntvtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtsiminflwgap_mp(static_cast<double>(Mtn_Plan_mTSIMinFlwGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtrkaccdmyrnga_mp(static_cast<float>(Mtn_Plan_mTrkAccDmyRngA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtrkaccdmyrngb_mp(static_cast<float>(Mtn_Plan_mTrkAccDmyRngB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtrkrngerra_mp(static_cast<double>(Mtn_Plan_mTrkRngErrA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtrkrngerrb_mp(static_cast<double>(Mtn_Plan_mTrkRngErrB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpslerefrngratea_mp(
    static_cast<double>(Mtn_Plan_mpsLeRefRngRateA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpslerefrngrateb_mp(
    static_cast<double>(Mtn_Plan_mpsLeRefRngRateB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsrirefrngratea_mp(
    static_cast<double>(Mtn_Plan_mpsRiRefRngRateA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsrirefrngrateb_mp(
    static_cast<double>(Mtn_Plan_mpsRiRefRngRateB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsrngratetara_mp(static_cast<float>(Mtn_Plan_mpsRngRateTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsrngratetarb_mp(static_cast<float>(Mtn_Plan_mpsRngRateTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstseintvtrngrate_mp(
    static_cast<double>(Mtn_Plan_mpsTSEIntvtRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstseminflwrngrate_mp(
    static_cast<double>(Mtn_Plan_mpsTSEMinFlwRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstsiintvtrngrate_mp(
    static_cast<double>(Mtn_Plan_mpsTSIIntvtRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstsiminflwrngrate_mp(
    static_cast<double>(Mtn_Plan_mpsTSIMinFlwRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstrkaccdmyrngratea_mp(
    static_cast<float>(Mtn_Plan_mpsTrkAccDmyRngRateA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpstrkaccdmyrngrateb_mp(
    static_cast<float>(Mtn_Plan_mpsTrkAccDmyRngRateB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsveltara_mp(static_cast<float>(Mtn_Plan_mpsVelTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsveltarb_mp(static_cast<float>(Mtn_Plan_mpsVelTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssacctara_mp(static_cast<float>(Mtn_Plan_mpssAccTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssacctarb_mp(static_cast<float>(Mtn_Plan_mpssAccTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssaphacctara_mp(
    static_cast<double>(Mtn_Plan_mpssAphAccTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssaphacctarb_mp(
    static_cast<double>(Mtn_Plan_mpssAphAccTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssaphdcltara_mp(
    static_cast<double>(Mtn_Plan_mpssAphDclTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssaphdcltarb_mp(
    static_cast<double>(Mtn_Plan_mpssAphDclTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssbkwdcllima_mp(
    static_cast<double>(Mtn_Plan_mpssBkwDclLimA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssbkwdcllimb_mp(
    static_cast<double>(Mtn_Plan_mpssBkwDclLimB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsscnstacctara_mp(
    static_cast<double>(Mtn_Plan_mpssCnstAccTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsscnstacctarb_mp(
    static_cast<double>(Mtn_Plan_mpssCnstAccTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsscnstdcltara_mp(
    static_cast<double>(Mtn_Plan_mpssCnstDclTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsscnstdcltarb_mp(
    static_cast<double>(Mtn_Plan_mpssCnstDclTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslanechgaccraw_mp(
    static_cast<double>(Mtn_Plan_mpssLaneChgAccRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslanechgacc_mp(
    static_cast<double>(Mtn_Plan_mpssLaneChgAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslebkwdcllima_mp(
    static_cast<double>(Mtn_Plan_mpssLeBkwDclLimA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslebkwdcllimb_mp(
    static_cast<double>(Mtn_Plan_mpssLeBkwDclLimB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslnspdlimacc_mp(
    static_cast<double>(Mtn_Plan_mpssLnSpdLimAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntaraccout_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarAccOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntarbkwapphacc_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarBkwApphAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntarbkwapphtotrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarBkwApphToTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntarfwapphacc_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarFwApphAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntarfwapphtotrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarFwApphToTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssmntartrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssMnTarTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssphy1accraw_mp(
    static_cast<double>(Mtn_Plan_mpssPhy1AccRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssphy1acc_mp(static_cast<double>(Mtn_Plan_mpssPhy1Acc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssphy2accraw_mp(
    static_cast<double>(Mtn_Plan_mpssPhy2AccRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssphy2acc_mp(static_cast<double>(Mtn_Plan_mpssPhy2Acc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssribkwdcllima_mp(
    static_cast<double>(Mtn_Plan_mpssRiBkwDclLimA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssribkwdcllimb_mp(
    static_cast<double>(Mtn_Plan_mpssRiBkwDclLimB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetaraccout_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarAccOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetarbkwapphacc_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarBkwApphAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetarbkwapphtotrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarBkwApphToTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetarfwapphacc_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarFwApphAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetarfwapphtotrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarFwApphToTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsssidetartrkacc_mp(
    static_cast<double>(Mtn_Plan_mpssSideTarTrkAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstsecipvsftyreq_mp(
    static_cast<double>(Mtn_Plan_mpssTSECIPVSftyReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstsemingapsftyreq_mp(
    static_cast<double>(Mtn_Plan_mpssTSEMinGapSftyReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstsicipvsftyreq_mp(
    static_cast<double>(Mtn_Plan_mpssTSICIPVSftyReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstsimingapsftyreq_mp(
    static_cast<double>(Mtn_Plan_mpssTSIMinGapSftyReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstoaccprcsreq_mp(
    static_cast<double>(Mtn_Plan_mpssToACCPrcsReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_numidxoflnspdlimsrc_mp(
    static_cast<double>(Mtn_Plan_numIdxOfLnSpdLimSrc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_smntartranssttmr_mp(
    static_cast<double>(Mtn_Plan_sMnTarTransStTmr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_ssidetartranssttmr_mp(
    static_cast<double>(Mtn_Plan_sSideTarTransStTmr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stactvlanechgmntarst_mp(
    static_cast<uint32_t>(Mtn_Plan_stActvLaneChgMnTarSt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stactvlanechgsidetarst_mp(
    static_cast<uint32_t>(Mtn_Plan_stActvLaneChgSideTarSt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stlanechgsm_mp(static_cast<uint32_t>(Mtn_Plan_stLaneChgSm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm1tara_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm1TarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm1tarb_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm1TarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm2tara_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm2TarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm2tarb_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm2TarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm3tara_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm3TarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm3tarb_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm3TarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm4tara_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm4TarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm4tarb_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm4TarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm5tara_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm5TarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgtimeestm5tarb_mp(
    static_cast<double>(Mtn_Plan_tiLaneChgTimeEstm5TarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tiphs1dyntimegap_mp(
    static_cast<double>(Mtn_Plan_tiPhs1DynTimeGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tiphs2dyntimegap_mp(
    static_cast<double>(Mtn_Plan_tiPhs2DynTimeGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_titsemintimegap_mp(
    static_cast<double>(Mtn_Plan_tiTSEMinTimeGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_titsimintimegap_mp(
    static_cast<double>(Mtn_Plan_tiTSIMinTimeGap_mp));
  fct_debug_out.mutable_mtn_debug_out()->add_mtn_plan_ubitmaskusenewdeca_mp(
    static_cast<uint32_t>(Mtn_Plan_uBitMaskUseNewDecA_mp[0]));
  fct_debug_out.mutable_mtn_debug_out()->add_mtn_plan_ubitmaskusenewdecb_mp(
    static_cast<uint32_t>(Mtn_Plan_uBitMaskUseNewDecB_mp[0]));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_uphs1ctrlprocsmcdn_mp(
    static_cast<uint32_t>(Mtn_Plan_uPhs1CtrlProcSmCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_uphs2ctrlprocsmcdn_mp(
    static_cast<uint32_t>(Mtn_Plan_uPhs2CtrlProcSmCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_xtimesetctrlnrtara_mp(
    static_cast<double>(Mtn_Plan_xTimeSetCtrlNrTarA_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_xtimesetctrlnrtarb_mp(
    static_cast<double>(Mtn_Plan_xTimeSetCtrlNrTarB_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgdrvconfirm4lca_mp(
    static_cast<bool>(Mtn_Dcsn_flgDrvConfirm4Lca_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stdrvconfirmmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stDrvConfirmMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_strmddrvlrconfirm_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stRmdDrvLRConfirm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfconepssdmsk_mp(static_cast<uint32_t>(Mtn_Loh_bfConePssdMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfegolnpssblinhbtmsk_mp(
    static_cast<uint32_t>(Mtn_Loh_bfEgoLnPssblInhbtMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflelinetypdtctdmsk_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLeLineTypDtctdMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex10_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex11_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex12_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex13_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex14_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex15_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex16_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex17_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex18_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex19_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex1_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex20_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex2_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex3_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex4_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex5_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex6_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex7_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex8_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bflepathlmtdmskindex9_mp(
    static_cast<uint32_t>(Mtn_Loh_bfLePathLmtdMskIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfmsktrgt7fltdoutmsk_mp(
    static_cast<uint32_t>(Mtn_Loh_bfMskTrgt7FltdOutMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfmsktrgt8fltdoutmsk_mp(
    static_cast<uint32_t>(Mtn_Loh_bfMskTrgt8FltdOutMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfrilinetypdtctdmsk_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiLineTypDtctdMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex10_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex11_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex12_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex13_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex14_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex15_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex16_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex17_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex18_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex19_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex1_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex20_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex2_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex3_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex4_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex5_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex6_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex7_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex8_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfripathlmtdmskindex9_mp(
    static_cast<uint32_t>(Mtn_Loh_bfRiPathLmtdMskIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_bfsprsmsk_mp(static_cast<uint32_t>(Mtn_Loh_bfSprsMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_cntpathestsmpldtimebufrsize_mp(
    static_cast<uint32_t>(Mtn_Loh_cntPathEstSmpldTimeBufrSize_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgconepssd_mp(static_cast<bool>(Mtn_Loh_flgConePssd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgconesle2richgactv_mp(
    static_cast<bool>(Mtn_Loh_flgConesLe2RiChgActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgconesle2richgenbl_mp(
    static_cast<bool>(Mtn_Loh_flgConesLe2RiChgEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgconesri2lechgactv_mp(
    static_cast<bool>(Mtn_Loh_flgConesRi2LeChgActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgconesri2lechgenbl_mp(
    static_cast<bool>(Mtn_Loh_flgConesRi2LeChgEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdactv_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex10_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex11_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex12_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex13_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex14_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex15_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex16_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex17_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex18_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex19_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex1_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex20_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex2_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex3_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex4_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex5_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex6_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex7_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex8_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flglepathlmtdindex9_mp(
    static_cast<bool>(Mtn_Loh_flgLePathLmtdIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgrefoccpdmostconeactv_mp(
    static_cast<bool>(Mtn_Loh_flgRefOccpdMostConeActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdactv_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex10_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex11_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex12_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex13_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex14_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex15_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex16_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex17_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex18_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex19_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex1_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex20_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex2_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex3_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex4_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex5_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex6_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex7_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex8_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgripathlmtdindex9_mp(
    static_cast<bool>(Mtn_Loh_flgRiPathLmtdIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgrrtrgtlonaccllmtdenbl_mp(
    static_cast<bool>(Mtn_Loh_flgRrTrgtLonAcclLmtdEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgsprsenbl_mp(static_cast<bool>(Mtn_Loh_flgSprsEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgtrgt7fltdout_mp(static_cast<bool>(Mtn_Loh_flgTrgt7FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgtrgt8fltdout_mp(static_cast<bool>(Mtn_Loh_flgTrgt8FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_flgtrgtlmtdlatdst_mp(
    static_cast<bool>(Mtn_Loh_flgTrgtLmtdLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_kphexpctlonvel_mp(static_cast<float>(Mtn_Loh_kphExpctLonVel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_kphlatctrllmtdlonvel_mp(
    static_cast<float>(Mtn_Loh_kphLatCtrlLmtdLonVel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_kphletrgtlmtdlonvel_mp(
    static_cast<float>(Mtn_Loh_kphLeTrgtLmtdLonVel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_kphritrgtlmtdlonvel_mp(
    static_cast<float>(Mtn_Loh_kphRiTrgtLmtdLonVel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mconepssdlatdst_mp(static_cast<float>(Mtn_Loh_mConePssdLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex10_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex11_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex12_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex13_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex14_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex15_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex16_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex17_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex18_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex19_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex1_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex20_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex2_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex3_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex4_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex5_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex6_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex7_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex8_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_megovehpathlonposindex9_mp(
    static_cast<float>(Mtn_Loh_mEgoVehPathLonPosIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mexpctlatdst_mp(static_cast<float>(Mtn_Loh_mExpctLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mexpctlondst_mp(static_cast<float>(Mtn_Loh_mExpctLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestconelatposccs_mp(
    static_cast<float>(Mtn_Loh_mFarestConeLatPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestconelatposvcs_mp(
    static_cast<float>(Mtn_Loh_mFarestConeLatPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestconelonposccs_mp(
    static_cast<float>(Mtn_Loh_mFarestConeLonPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestconelonposvcs_mp(
    static_cast<float>(Mtn_Loh_mFarestConeLonPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestconerng_mp(static_cast<float>(Mtn_Loh_mFarestConeRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mfarestoccpddst_mp(static_cast<float>(Mtn_Loh_mFarestOccpdDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblconelatposccs_mp(
    static_cast<float>(Mtn_Loh_mImpssblConeLatPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblconelatposvcs_mp(
    static_cast<float>(Mtn_Loh_mImpssblConeLatPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblconelonposccs_mp(
    static_cast<float>(Mtn_Loh_mImpssblConeLonPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblconelonposvcs_mp(
    static_cast<float>(Mtn_Loh_mImpssblConeLonPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblconerng_mp(static_cast<float>(Mtn_Loh_mImpssblConeRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mimpssblexpctlatdst_mp(
    static_cast<float>(Mtn_Loh_mImpssblExpctLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleimpssblconebrdr_mp(
    static_cast<float>(Mtn_Loh_mLeImpssblConeBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlelinebrdr_mp(static_cast<float>(Mtn_Loh_mLeLineBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlelnbrdrraw_mp(static_cast<float>(Mtn_Loh_mLeLnBrdrRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlelnbrdr_mp(static_cast<float>(Mtn_Loh_mLeLnBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlelnoccpdbrdr_mp(static_cast<float>(Mtn_Loh_mLeLnOccpdBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlelnoccpddst_mp(static_cast<float>(Mtn_Loh_mLeLnOccpdDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconelatposccsraw_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeLatPosCCSRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconelatposccs_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeLatPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconelatposvcs_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeLatPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconelonposccs_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeLonPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconelonposvcs_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeLonPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mleoccpmostconerng_mp(
    static_cast<float>(Mtn_Loh_mLeOccpMostConeRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex10_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex11_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex12_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex13_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex14_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex15_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex16_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex17_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex18_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex19_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex1_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex20_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex2_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex3_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex4_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex5_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex6_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex7_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex8_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlepathlmtdlatposindex9_mp(
    static_cast<float>(Mtn_Loh_mLePathLmtdLatPosIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlerdedg2lineofst_mp(
    static_cast<float>(Mtn_Loh_mLeRdEdg2LineOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mlerdedgc0_mp(static_cast<float>(Mtn_Loh_mLeRdEdgC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mletrgtlmtdbrdr_mp(static_cast<float>(Mtn_Loh_mLeTrgtLmtdBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpssblexpctlatdst_mp(
    static_cast<float>(Mtn_Loh_mPssblExpctLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpssblwdth_mp(static_cast<float>(Mtn_Loh_mPssblWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrefconelatposccs_mp(
    static_cast<float>(Mtn_Loh_mRefConeLatPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrefconelonposccs_mp(
    static_cast<float>(Mtn_Loh_mRefConeLonPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mriimpssblconebrdr_mp(
    static_cast<float>(Mtn_Loh_mRiImpssblConeBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrilinebrdr_mp(static_cast<float>(Mtn_Loh_mRiLineBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrilnbrdrraw_mp(static_cast<float>(Mtn_Loh_mRiLnBrdrRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrilnbrdr_mp(static_cast<float>(Mtn_Loh_mRiLnBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrilnoccpdbrdr_mp(static_cast<float>(Mtn_Loh_mRiLnOccpdBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrilnoccpddst_mp(static_cast<float>(Mtn_Loh_mRiLnOccpdDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconelatposccsraw_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeLatPosCCSRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconelatposccs_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeLatPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconelatposvcs_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeLatPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconelonposccs_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeLonPosCCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconelonposvcs_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeLonPosVCS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrioccpmostconerng_mp(
    static_cast<float>(Mtn_Loh_mRiOccpMostConeRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex10_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex10_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex11_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex12_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex13_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex14_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex14_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex15_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex15_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex16_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex16_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex17_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex17_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex18_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex18_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex19_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex19_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex1_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex20_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex20_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex2_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex3_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex4_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex5_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex6_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex6_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex7_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex7_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex8_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex8_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mripathlmtdlatposindex9_mp(
    static_cast<float>(Mtn_Loh_mRiPathLmtdLatPosIndex9_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrirdedg2lineofst_mp(
    static_cast<float>(Mtn_Loh_mRiRdEdg2LineOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mrirdedgc0_mp(static_cast<float>(Mtn_Loh_mRiRdEdgC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mritrgtlmtdbrdr_mp(static_cast<float>(Mtn_Loh_mRiTrgtLmtdBrdr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mtrgt7fltdoutlatdstlmt_mp(
    static_cast<float>(Mtn_Loh_mTrgt7FltdOutLatDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mtrgt7fltdoutlnwdth_mp(
    static_cast<float>(Mtn_Loh_mTrgt7FltdOutLnWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mtrgt8fltdoutlatdstlmt_mp(
    static_cast<float>(Mtn_Loh_mTrgt8FltdOutLatDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mtrgt8fltdoutlnwdth_mp(
    static_cast<float>(Mtn_Loh_mTrgt8FltdOutLnWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsfarestconerngrate_mp(
    static_cast<float>(Mtn_Loh_mpsFarestConeRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsimpssblconerngrate_mp(
    static_cast<float>(Mtn_Loh_mpsImpssblConeRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpslatctrlavrgvel_mp(
    static_cast<float>(Mtn_Loh_mpsLatCtrlAvrgVel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsleoccpmostconerngrate_mp(
    static_cast<float>(Mtn_Loh_mpsLeOccpMostConeRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsrioccpmostconerngrate_mp(
    static_cast<float>(Mtn_Loh_mpsRiOccpMostConeRngRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpssavrglonaccl_mp(static_cast<float>(Mtn_Loh_mpssAvrgLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsslatctrllmtdavrglonaccl_mp(
    static_cast<float>(Mtn_Loh_mpssLatCtrlLmtdAvrgLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpsslondstlmtdavrglonaccl_mp(
    static_cast<float>(Mtn_Loh_mpssLonDstLmtdAvrgLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_mpssrrtrgtlmtdlonaccl_mp(
    static_cast<float>(Mtn_Loh_mpssRrTrgtLmtdLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numfarestconeid_mp(
    static_cast<uint32_t>(Mtn_Loh_numFarestConeID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numfarestconeindex_mp(
    static_cast<uint32_t>(Mtn_Loh_numFarestConeIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numimpssblconeid_mp(
    static_cast<uint32_t>(Mtn_Loh_numImpssblConeID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numimpssblconeindex_mp(
    static_cast<uint32_t>(Mtn_Loh_numImpssblConeIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numleoccpmostconeidraw_mp(
    static_cast<uint32_t>(Mtn_Loh_numLeOccpMostConeIDRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numleoccpmostconeid_mp(
    static_cast<uint32_t>(Mtn_Loh_numLeOccpMostConeID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numleoccpmostconeindexraw_mp(
    static_cast<uint32_t>(Mtn_Loh_numLeOccpMostConeIndexRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numleoccpmostconeindex_mp(
    static_cast<uint32_t>(Mtn_Loh_numLeOccpMostConeIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrefconeid_mp(static_cast<uint32_t>(Mtn_Loh_numRefConeID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrefconeindex_mp(
    static_cast<uint32_t>(Mtn_Loh_numRefConeIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrioccpmostconeidraw_mp(
    static_cast<uint32_t>(Mtn_Loh_numRiOccpMostConeIDRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrioccpmostconeid_mp(
    static_cast<uint32_t>(Mtn_Loh_numRiOccpMostConeID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrioccpmostconeindexraw_mp(
    static_cast<uint32_t>(Mtn_Loh_numRiOccpMostConeIndexRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_numrioccpmostconeindex_mp(
    static_cast<uint32_t>(Mtn_Loh_numRiOccpMostConeIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_pctfarestoccpdratio_mp(
    static_cast<float>(Mtn_Loh_pctFarestOccpdRatio_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_pctlelnoccpdratio_mp(
    static_cast<float>(Mtn_Loh_pctLeLnOccpdRatio_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_pctlnoccpdratio_mp(static_cast<float>(Mtn_Loh_pctLnOccpdRatio_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_pctrefconeratiodiff_mp(
    static_cast<float>(Mtn_Loh_pctRefConeRatioDiff_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_pctrilnoccpdratio_mp(
    static_cast<float>(Mtn_Loh_pctRiLnOccpdRatio_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_phiexpctag_mp(static_cast<float>(Mtn_Loh_phiExpctAg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_philerdedgc1_mp(static_cast<float>(Mtn_Loh_phiLeRdEdgC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_phirirdedgc1_mp(static_cast<float>(Mtn_Loh_phiRiRdEdgC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_slatctrltimeestd_mp(
    static_cast<float>(Mtn_Loh_sLatCtrlTimeEstd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_slonctrltime_mp(static_cast<float>(Mtn_Loh_sLonCtrlTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_spathestsmpltime_mp(
    static_cast<float>(Mtn_Loh_sPathEstSmplTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_srrtrgtlonttc_mp(static_cast<float>(Mtn_Loh_sRrTrgtLonTTC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stdashlinedtctd_mp(
    static_cast<uint32_t>(Mtn_Loh_stDashLineDtctd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stegolnpssbl_mp(static_cast<uint32_t>(Mtn_Loh_stEgoLnPssbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stfarestconevld_mp(
    static_cast<uint32_t>(Mtn_Loh_stFarestConeVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stimpssblconevld_mp(
    static_cast<uint32_t>(Mtn_Loh_stImpssblConeVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stleoccpmostconevld_mp(
    static_cast<uint32_t>(Mtn_Loh_stLeOccpMostConeVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_stlnoccpd_mp(static_cast<uint32_t>(Mtn_Loh_stLnOccpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_strdedgdtctd_mp(static_cast<uint32_t>(Mtn_Loh_stRdEdgDtctd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_strioccpmostconevld_mp(
    static_cast<uint32_t>(Mtn_Loh_stRiOccpMostConeVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_xlerdedgc2_mp(static_cast<float>(Mtn_Loh_xLeRdEdgC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_xlerdedgc3_mp(static_cast<float>(Mtn_Loh_xLeRdEdgC3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_xrirdedgc2_mp(static_cast<float>(Mtn_Loh_xRiRdEdgC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_loh_xrirdedgc3_mp(static_cast<float>(Mtn_Loh_xRiRdEdgC3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_flgdynhmisuprtinfoactv_mp(
    static_cast<bool>(Mtn_flgDynHmiSuprtInfoActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_flgenleadtrjtrfortrnst_mp(
    static_cast<bool>(Mtn_flgEnLeadTrjtrForTrnst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_flgisemergncylnchg_mp(static_cast<bool>(Mtn_flgIsEmergncyLnChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_flgrampleadovrd_mp(static_cast<bool>(Mtn_flgRampLeadOvrd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_stevddecision_mp(static_cast<uint32_t>(Mtn_stEVDDecision_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_stevdleadingdir_mp(static_cast<uint32_t>(Mtn_stEVDLeadingDir_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_stevdpathdir_mp(static_cast<uint32_t>(Mtn_stEVDPathDir_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_lnchgstg1evddistance_mp(
    static_cast<float>(Mtn_Dcsn_LnChgStg1EVDDistance_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn11crstartime_mp(
    static_cast<float>(Mtn_Dcsn_TiZn11CrsTarTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn13crstartime_mp(
    static_cast<float>(Mtn_Dcsn_TiZn13CrsTarTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn1crstartime_mp(
    static_cast<float>(Mtn_Dcsn_TiZn1CrsTarTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn3crstartime_mp(
    static_cast<float>(Mtn_Dcsn_TiZn3CrsTarTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2evddist4zone13_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2EVDDist4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2evddist4zone1_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2EVDDist4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2evddist4zone2_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2EVDDist4Zone2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2evddist4zone3_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2EVDDist4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2reartar4zone13_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2RearTar4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2reartar4zone3_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2RearTar4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2sdrrtar4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2SdRrTar4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2sdrrtar4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2SdRrTar4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2tar1frzone13_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2Tar1FrZone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aaccel2tar1frzone3_mp(
    static_cast<float>(Mtn_Dcsn_aAccel2Tar1FrZone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavetaraccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aAveTarAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aavertaraccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aAverTarAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aegovehsetspdlonaccl_mp(
    static_cast<float>(Mtn_Dcsn_aEgoVehSetSpdLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amaxaccellimaftresv_mp(
    static_cast<float>(Mtn_Dcsn_aMaxAccelLimAftResv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2evddist4zone11_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2EVDDist4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2evddist4zone12_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2EVDDist4Zone12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdfrttar4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdFrtTar4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdfrttar4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdFrtTar4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdfrttar4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdFrtTar4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdfrttar4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdFrtTar4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdrrtar4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdRrTar4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdrrtar4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdRrTar4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdrrtar4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdRrTar4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2sdrrtar4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2SdRrTar4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2tar1frzn11_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2Tar1FrZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2tar1frzn12_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2Tar1FrZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2tar1frzn1_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2Tar1FrZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_amendaccel2tar1frzn2_mp(
    static_cast<float>(Mtn_Dcsn_aMendAccel2Tar1FrZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_aminaccellimaftresv_mp(
    static_cast<float>(Mtn_Dcsn_aMinAccelLimAftResv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_armtar1eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aRMTar1EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4frnttrgt2zn12_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4FrntTrgt2Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4frnttrgt2zn2_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4FrntTrgt2Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4rmtrgt1zn12_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4RMTrgt1Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4rmtrgt1zn2_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4RMTrgt1Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4rrtrgt2zn12_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4RrTrgt2Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4rrtrgt2zn2_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4RrTrgt2Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4tsetrgt1zn12_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4TSETrgt1Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4tsetrgt1zn2_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4TSETrgt1Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4tsitrgt1zn12_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4TSITrgt1Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_astg2avrgaccl4tsitrgt1zn2_mp(
    static_cast<float>(Mtn_Dcsn_aStg2AvrgAccl4TSITrgt1Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsetar1eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTSETar1EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atsitar1eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTSITar1EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar11eqacc4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar11EqAcc4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar11eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aTar11EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar11eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTar11EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar12eqacc4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar12EqAcc4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar12eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aTar12EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar12eqaccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aTar12EqAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar23eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTar23EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar24eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTar24EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar3eqacc4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar3EqAcc4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar3eqaccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aTar3EqAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar3eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aTar3EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar4eqaccel4zn1_mp(
    static_cast<float>(Mtn_Dcsn_aTar4EqAccel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar5eqacc4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar5EqAcc4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar5eqaccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aTar5EqAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar5eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aTar5EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar6eqaccel4zn11_mp(
    static_cast<float>(Mtn_Dcsn_aTar6EqAccel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar7eqacc4zn2stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar7EqAcc4Zn2Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar7eqaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_aTar7EqAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar7eqaccel4zn3_mp(
    static_cast<float>(Mtn_Dcsn_aTar7EqAccel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar8eqacc4zn12stg2_mp(
    static_cast<float>(Mtn_Dcsn_aTar8EqAcc4Zn12Stg2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar8eqaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_aTar8EqAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_atar8eqaccel4zn13_mp(
    static_cast<float>(Mtn_Dcsn_aTar8EqAccel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bflnchgdcsnpreferzn13_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfLnChgDcsnPreferZn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bflnchgdcsnpreferzn3_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfLnChgDcsnPreferZn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn11_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn12_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn13_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn1_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn2_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfsprs4zn3_mp(static_cast<uint32_t>(Mtn_Dcsn_bfSprs4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfstg2mrginriskvldmsk_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfStg2MrgInRiskVldMsk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfstg2tsetrgt1accchk4zn12_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfStg2TSETrgt1AccChk4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfstg2tsetrgt1accchk4zn2_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfStg2TSETrgt1AccChk4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfstg2tsitrgt1accchk4zn12_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfStg2TSITrgt1AccChk4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_bfstg2tsitrgt1accchk4zn2_mp(
    static_cast<uint32_t>(Mtn_Dcsn_bfStg2TSITrgt1AccChk4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn1cstraw_mp(
    static_cast<float>(Mtn_Dcsn_facMrgInZn1CstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn1cst_mp(static_cast<float>(Mtn_Dcsn_facMrgInZn1Cst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn2cstraw_mp(
    static_cast<float>(Mtn_Dcsn_facMrgInZn2CstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn2cst_mp(static_cast<float>(Mtn_Dcsn_facMrgInZn2Cst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn3cstraw_mp(
    static_cast<float>(Mtn_Dcsn_facMrgInZn3CstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facmrginzn3cst_mp(static_cast<float>(Mtn_Dcsn_facMrgInZn3Cst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_facstg2lnchgactlatdstfctr_mp(
    static_cast<float>(Mtn_Dcsn_facStg2LnChgActLatDstFctr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgarrvlelnchgstg1rngpos_mp(
    static_cast<bool>(Mtn_Dcsn_flgArrvLeLnChgStg1RngPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgarrvrilnchgstg1rngpos_mp(
    static_cast<bool>(Mtn_Dcsn_flgArrvRiLnChgStg1RngPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcrostar_mp(static_cast<bool>(Mtn_Dcsn_flgCrosTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcrs2lnchng_mp(static_cast<bool>(Mtn_Dcsn_flgCrs2LnChng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsaccelim4sirrtarzn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsAcceLim4SiRrTarZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsaccelim4sirrtarzn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsAcceLim4SiRrTarZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsaccllim4rrtarzn12_mp(
    static_cast<float>(Mtn_Dcsn_flgCtrlbsAcclLim4RrTarZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsaccllim4rrtarzn2_mp(
    static_cast<float>(Mtn_Dcsn_flgCtrlbsAcclLim4RrTarZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4sifrttarzn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4SiFrtTarZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4sifrttarzn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4SiFrtTarZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4sifrttarzn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4SiFrtTarZn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4sifrttarzn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4SiFrtTarZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4sifrttarzn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4SiFrtTarZn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4tar1zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4Tar1Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclim4tar1_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLim4Tar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclimtar1zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLimTar1Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgctrlbsdeclimtar1zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgCtrlbsDecLimTar1Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcurdshmptypok4zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurDshMpTypOk4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgcursldmptypok4zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgCurSldMpTypOk4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgdcsnlecntnsnozn_mp(
    static_cast<bool>(Mtn_Dcsn_flgDcsnLeCntnsNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgdcsnoutenbwhennolezn_mp(
    static_cast<bool>(Mtn_Dcsn_flgDcsnOutEnbWhenNoLeZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgdcsnoutenbwhennorizn_mp(
    static_cast<bool>(Mtn_Dcsn_flgDcsnOutEnbWhenNoRiZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgdcsnricntnsnozn_mp(
    static_cast<bool>(Mtn_Dcsn_flgDcsnRiCntnsNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevddistneng4lf_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDDistNEng4Lf_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevddistneng4ri_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDDistNEng4Ri_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevddistzn12ok_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDDistZn12OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevddistzn2ok_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDDistZn2OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevddstvldst_mp(static_cast<bool>(Mtn_Dcsn_flgEVDDstVldSt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevdnoenog4zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDNoEnog4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgevdnoenog4zn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgEVDNoEnog4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgestcrstarappear_mp(
    static_cast<bool>(Mtn_Dcsn_flgEstCrsTarAppear_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgestdlnchngdstvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgEstdLnChngDstVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgestdlnwdthinvldst_mp(
    static_cast<bool>(Mtn_Dcsn_flgEstdLnWdthInvldSt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfollowtardst2accel4zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgFollowTarDst2Accel4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfrttarzn12ok_mp(
    static_cast<bool>(Mtn_Dcsn_flgFrtTarZn12OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfrttarzn2ok_mp(static_cast<bool>(Mtn_Dcsn_flgFrtTarZn2OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfutspdovstspdzn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgFutSpdOvStSpdZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfutspdovstspdzn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgFutSpdOvStSpdZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfutspdovstspdzn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgFutSpdOvStSpdZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgfutspdovstspdzn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgFutSpdOvStSpdZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flghostlogdistoknowzn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgHostLogDistokNowZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flghostlogdistoknowzn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgHostLogDistokNowZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flginstg2bfrlnchgstg_mp(
    static_cast<bool>(Mtn_Dcsn_flgInStg2BfrLnChgStg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgintolon2ctlstg_mp(
    static_cast<bool>(Mtn_Dcsn_flgIntoLon2CtlStg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglanechgdstenough_mp(
    static_cast<bool>(Mtn_Dcsn_flgLaneChgDstEnough_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgleadjlnexsttruck_mp(
    static_cast<bool>(Mtn_Dcsn_flgLeAdjLnExstTruck_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgleadramp_mp(static_cast<bool>(Mtn_Dcsn_flgLeadRamp_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchg2crssldln_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChg2CrsSldLn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgadv_mp(static_cast<bool>(Mtn_Dcsn_flgLnChgAdv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgaftcrosline_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgAftCrosLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn11expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn11ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn12expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn12ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn13expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn13ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn1expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn1ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn2expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn2ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchgzn3expctposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChgZn3ExpctPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchng2crszninvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChng2CrsZnInvld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchng2crs_mp(static_cast<bool>(Mtn_Dcsn_flgLnChng2Crs_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchng2rtrnegolnallwd_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChng2RtrnEgoLnAllwd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchng2rtrnegolnraw_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChng2RtrnEgoLnRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglnchng2rtrnegoln_mp(
    static_cast<bool>(Mtn_Dcsn_flgLnChng2RtrnEgoLn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglon2ctlvalid_mp(
    static_cast<bool>(Mtn_Dcsn_flgLon2CtlValid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglon2tarupdate_mp(
    static_cast<bool>(Mtn_Dcsn_flgLon2TarUpdate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglondstnotenough_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonDstNotEnough_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn11_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn12_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn1_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn2_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flglonspdwithinlmt4zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgLonSpdWithinLmt4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgmapinvaldlflndsh_mp(
    static_cast<bool>(Mtn_Dcsn_flgMapInvaldLfLnDsh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgmapinvaldrilndsh_mp(
    static_cast<bool>(Mtn_Dcsn_flgMapInvaldRiLnDsh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgnopon4zoneidlock_mp(
    static_cast<bool>(Mtn_Dcsn_flgNOPOn4ZoneIDLock_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgnosprs4lc_mp(static_cast<bool>(Mtn_Dcsn_flgNoSprs4LC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgnotar7tar8spr_mp(
    static_cast<bool>(Mtn_Dcsn_flgNoTar7Tar8Spr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgnopactv_mp(static_cast<bool>(Mtn_Dcsn_flgNopActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgprfrznintolnchg_mp(
    static_cast<bool>(Mtn_Dcsn_flgPrfrZnIntoLnChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgreartarzn12ok_mp(
    static_cast<bool>(Mtn_Dcsn_flgRearTarZn12OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgreartarzn2ok_mp(
    static_cast<bool>(Mtn_Dcsn_flgRearTarZn2OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgriadjlnexsttruck_mp(
    static_cast<bool>(Mtn_Dcsn_flgRiAdjLnExstTruck_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgrtrnegoln2crs_mp(
    static_cast<bool>(Mtn_Dcsn_flgRtrnEgoLn2Crs_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn13onlyonetar_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn13OnlyOneTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn13rrtardstengh_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn13RrTarDstEngh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn13tar24dstengh_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn13Tar24DstEngh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn3onlyonetar_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn3OnlyOneTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn3rrtardstengh_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn3RrTarDstEngh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg1zn3tar23dstengh_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg1Zn3Tar23DstEngh_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2ctrlenbl_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2CtrlEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2ignoretar1trakvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2IgnoreTar1TrakVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lechgctrldstinvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeChgCtrlDstInvld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lechgctrldstvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeChgCtrlDstVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lechgsiderrtrgtsafe_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeChgSideRrTrgtSafe_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lechgtrgt1accrisk_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeChgTrgt1AccRisk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lechgtrgt1riskvalid_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeChgTrgt1RiskValid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lerngvldraw_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeRngVldRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lerngvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LeRngVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lnchgcrssdtrgt1riskvalid_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LnChgCrssdTrgt1RiskValid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lncrssdctrlvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LnCrssdCtrlVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lncrssd_mp(static_cast<bool>(Mtn_Dcsn_flgStg2LnCrssd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lonctrldstgradlmtactv_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LonCtrlDstGradLmtActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2lonctrldstgradlmtrst_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2LonCtrlDstGradLmtRst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2rmtrgt1bypassd_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RMTrgt1ByPassd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2richgctrldstinvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiChgCtrlDstInvld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2richgctrldstvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiChgCtrlDstVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2richgsiderrtrgtsafe_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiChgSideRrTrgtSafe_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2richgtrgt1accrisk_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiChgTrgt1AccRisk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2richgtrgt1riskvalid_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiChgTrgt1RiskValid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2rirngvldraw_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiRngVldRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2rirngvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2RiRngVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2trgtznchckactv_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2TrgtZnChckActv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2trgtznchckrst_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2TrgtZnChckRst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn12acclvldraw_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2Zn12AcclVldRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn12acclvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2Zn12AcclVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn12vld_mp(static_cast<bool>(Mtn_Dcsn_flgStg2Zn12Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn2acclvldraw_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2Zn2AcclVldRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn2acclvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgStg2Zn2AcclVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgstg2zn2vld_mp(static_cast<bool>(Mtn_Dcsn_flgStg2Zn2Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1crashbyrng_mp(
    static_cast<bool>(Mtn_Dcsn_flgTar1CrashByRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1crashbyttc_mp(
    static_cast<bool>(Mtn_Dcsn_flgTar1CrashByTTC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1crash_mp(static_cast<bool>(Mtn_Dcsn_flgTar1Crash_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1indextrakvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgTar1IndexTrakVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1rngtrakvld_mp(
    static_cast<bool>(Mtn_Dcsn_flgTar1RngTrakVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1zn12ok_mp(static_cast<bool>(Mtn_Dcsn_flgTar1Zn12OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar1zn2ok_mp(static_cast<bool>(Mtn_Dcsn_flgTar1Zn2OK_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar23vld_mp(static_cast<bool>(Mtn_Dcsn_flgTar23Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar24vld_mp(static_cast<bool>(Mtn_Dcsn_flgTar24Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtar9rangevld4zone3and13_mp(
    static_cast<bool>(Mtn_Dcsn_flgTar9RangeVld4Zone3And13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt7and23aszn3tar_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt7And23AsZn3Tar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt7fltdout4zn3_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt7FltdOut4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt7fltdoutlatdstenbl_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt7FltdOutLatDstEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt8and24aszn13tar_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt8And24AsZn13Tar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt8fltdout4zn13_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt8FltdOut4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgt8fltdoutlatdstenbl_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgt8FltdOutLatDstEnbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgtflttrgt7fltdout_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgtFltTrgt7FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgtrgtflttrgt8fltdout_mp(
    static_cast<bool>(Mtn_Dcsn_flgTrgtFltTrgt8FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11crstartrkzn11rridx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11CrsTarTrkZn11RrIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11crstartrkzn11rrrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11CrsTarTrkZn11RrRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11crstartrkzn12rridx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11CrsTarTrkZn12RrIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11crstartrkzn12rrrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11CrsTarTrkZn12RrRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11hastrkcrstarindex_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11HasTrkCrsTarIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11trkcrsfaketar_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn11TrkCrsFakeTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn11valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn11Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn12bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn12BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn12futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn12FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn12valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn12Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13crossingtardet_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13CrossingTarDet_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13crstartrkzn12frtidx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13CrsTarTrkZn12FrtIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13crstartrkzn12frtrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13CrsTarTrkZn12FrtRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13crstartrkzn13frtidx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13CrsTarTrkZn13FrtIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13crstartrkzn13frtrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13CrsTarTrkZn13FrtRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13hastrkcrstarindex_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13HasTrkCrsTarIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13trkcrsfaketar_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn13TrkCrsFakeTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn13valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn13Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1crstartrkzn1rridx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1CrsTarTrkZn1RrIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1crstartrkzn1rrrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1CrsTarTrkZn1RrRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1crstartrkzn2rridx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1CrsTarTrkZn2RrIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1crstartrkzn2rrrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1CrsTarTrkZn2RrRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1hastrkcrstarindex_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1HasTrkCrsTarIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1trkcrsfaketar_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn1TrkCrsFakeTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn1valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn1Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn2bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn2BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn2futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn2FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn2valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn2Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3bgnlnchgposreset_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3BgnLnChgPosReset_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3crossingtardet_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3CrossingTarDet_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3crstartrkzn2frtidx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3CrsTarTrkZn2FrtIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3crstartrkzn2frtrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3CrsTarTrkZn2FrtRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3crstartrkzn3frtidx_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3CrsTarTrkZn3FrtIdx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3crstartrkzn3frtrange_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3CrsTarTrkZn3FrtRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3futnearesttar1vld_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3FutNearestTar1Vld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3hastrkcrstarindex_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3HasTrkCrsTarIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3trkcrsfaketar_mp(
    static_cast<bool>(Mtn_Dcsn_flgZn3TrkCrsFakeTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzn3valid_mp(static_cast<bool>(Mtn_Dcsn_flgZn3Valid_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone11stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone11Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone12stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone12Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone13stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone13Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone1stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone1Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone2stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone2Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzone3stg1usetar1dst_mp(
    static_cast<bool>(Mtn_Dcsn_flgZone3Stg1UseTar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzonerst_mp(static_cast<bool>(Mtn_Dcsn_flgZoneRst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_flgzonevalid4longctrl_mp(
    static_cast<bool>(Mtn_Dcsn_flgZoneValid4LongCtrl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_marvrilcstg1tar1dstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mArvRiLCStg1Tar1DstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_marvrilcstg1tar5dstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mArvRiLCStg1Tar5DstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_marvrilcstg1zn12rrtardstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mArvRiLCStg1Zn12RrTarDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_marvrilcstg1zn2rrtardstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mArvRiLCStg1Zn2RrTarDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mdectominlnchgspddst_mp(
    static_cast<float>(Mtn_Dcsn_mDecToMinLnChgSpdDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mdfltlondstmin4lanechg_mp(
    static_cast<float>(Mtn_Dcsn_mDfltLonDstMin4LaneChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mdistlim4lfemlnchg_mp(
    static_cast<float>(Mtn_Dcsn_mDistLim4LfEMLnChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mdistlim4riemlnchg_mp(
    static_cast<float>(Mtn_Dcsn_mDistLim4RiEMLnChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mevddst_mp(static_cast<float>(Mtn_Dcsn_mEVDDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mestdlnchngdst_mp(static_cast<float>(Mtn_Dcsn_mEstdLnChngDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mestdlnwdthinvlddstmin_mp(
    static_cast<float>(Mtn_Dcsn_mEstdLnWdthInvldDstMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mestdlnwdthmin_mp(static_cast<float>(Mtn_Dcsn_mEstdLnWdthMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn11_mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn12mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn12mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn13_mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn1_mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn2mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn2mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostaccllimdisplace4zn3_mp(
    static_cast<float>(Mtn_Dcsn_mHostAcclLimDisplace4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn11_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn12_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn13_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn1_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn2_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostdeclimdisplace4zn3_mp(
    static_cast<float>(Mtn_Dcsn_mHostDecLimDisplace4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn11_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn12_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn13_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn1_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn2_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostfutureposition4zn3_mp(
    static_cast<float>(Mtn_Dcsn_mHostFuturePosition4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn11_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn12_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn13_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn1_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn2_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mhostlonadjfinshpos4zn3_mp(
    static_cast<float>(Mtn_Dcsn_mHostLonAdjFinshPos4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgmaxdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgMaxDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgmindstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgMinDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgtimeestlelatdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgTimeEstLeLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgtimeestrilatdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgTimeEstRiLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn11expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn11ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn11flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn11FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn11frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn11FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn11rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn11RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn12expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn12ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn12flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn12FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn12frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn12FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn12rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn12RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn13expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn13ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn13flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn13FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn13frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn13FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn13rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn13RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn1expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn1ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn1flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn1FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn1frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn1FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn1rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn1RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn2expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn2ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn2flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn2FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn2frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn2FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn2rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn2RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn3expctposflt_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn3ExpctPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn3flwfrttardst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn3FlwFrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn3frttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn3FrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzn3rrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZn3RrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone11bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone11BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone11expctpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone11ExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone12bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone12BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone13bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone13BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone13expctpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone13ExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone1bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone1BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone1expctpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone1ExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone2bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone2BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone2expctpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone2ExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone3bgnlnchgpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone3BgnLnChgPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnchgzone3expctpos_mp(
    static_cast<float>(Mtn_Dcsn_mLnChgZone3ExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlnwdthestdst_mp(static_cast<float>(Mtn_Dcsn_mLnWdthEstDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlon2ctldst_mp(static_cast<float>(Mtn_Dcsn_mLon2CtlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlondstleft_mp(static_cast<float>(Mtn_Dcsn_mLonDstLeft_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mlondstmin4lanechg_mp(
    static_cast<float>(Mtn_Dcsn_mLonDstMin4LaneChg_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mnearesttar1range_mp(
    static_cast<float>(Mtn_Dcsn_mNearestTar1Range_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mrtrnchckrmtrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mRtrnChckRMTrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mrtrnchcktsetrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mRtrnChckTSETrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mrtrnchcktsitrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mRtrnChckTSITrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mrtrnenbleqvc0_mp(static_cast<float>(Mtn_Dcsn_mRtrnEnblEqvC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mrtrnenblestc0_mp(static_cast<float>(Mtn_Dcsn_mRtrnEnblEstC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_msdfrttardisplace4zn12_mp(
    static_cast<float>(Mtn_Dcsn_mSdFrtTarDisplace4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_msdfrttardisplace4zn2_mp(
    static_cast<float>(Mtn_Dcsn_mSdFrtTarDisplace4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_msidefrttarrng2frttarzone13_mp(
    static_cast<float>(Mtn_Dcsn_mSideFrtTarRng2FrtTarZone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_msidefrttarrng2frttarzone3_mp(
    static_cast<float>(Mtn_Dcsn_mSideFrtTarRng2FrtTarZone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn13frtsidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn13FrtSideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn13rrsidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn13RrSideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn13sftydstthrshld_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn13SftyDstThrshld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn13sidetarcurdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn13SideTarCurDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn13sidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn13SideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn3frtsidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn3FrtSideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn3rrsidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn3RrSideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn3sftydstthrshld_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn3SftyDstThrshld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn3sidetarcurdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn3SideTarCurDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg1zn3sidetarestmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg1Zn3SideTarEstmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2deltavcomptime_mp(
    static_cast<float>(Mtn_Dcsn_mStg2DeltaVCompTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2evddstleft_mp(
    static_cast<float>(Mtn_Dcsn_mStg2EVDDstLeft_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2egovehlncrsslatdstraw_mp(
    static_cast<float>(Mtn_Dcsn_mStg2EgoVehLnCrssLatDstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2egovehlncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2EgoVehLnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlinedshdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineDshDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlineledshdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineLeDshDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlineleslddstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineLeSldDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlineridshdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineRiDshDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlinerislddstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineRiSldDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2intrstlineslddstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2IntrstLineSldDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgctrldst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgmaxacclegovehlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgMaxAcclEgoVehLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgmaxdclegovehlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgMaxDclEgoVehLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgrmtrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRMTrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgrmtrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRMTrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgrmtrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRMTrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgrmtrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRMTrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgreftrgtcrssdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRefTrgtCrssDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgreftrgtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgRefTrgtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsetspdacclegovehlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSetSpdAcclEgoVehLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsetspddclegovehlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSetSpdDclEgoVehLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsidefrnttrgtcmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideFrntTrgtCmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsidefrnttrgtcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideFrntTrgtCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsidefrnttrgtestrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideFrntTrgtEstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsidefrnttrgtlmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideFrntTrgtLmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsidefrnttrgtlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideFrntTrgtLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsiderrtrgtcmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideRrTrgtCmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsiderrtrgtcrssdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideRrTrgtCrssDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsiderrtrgtcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideRrTrgtCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsiderrtrgtestrngmax_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideRrTrgtEstRngMax_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgsiderrtrgtlmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgSideRrTrgtLmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsetrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSETrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsetrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSETrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsetrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSETrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsetrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSETrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsetrgt1londst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSETrgt1LonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsitrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSITrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsitrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSITrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsitrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSITrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtsitrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTSITrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lechgtrgtlmtdexprng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeChgTrgtLmtdExpRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lefutnrsttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeFutNrstTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lefutnrsttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeFutNrstTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lesidefrnttrgtlncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LeSideFrntTrgtLnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lnchgtar1crsscompdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnChgTar1CrssCompDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lnchgtar1deltaspdcrsscompdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnChgTar1DeltaSpdCrssCompDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lnchgtar1spdcrsscompdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnChgTar1SpdCrssCompDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrssrmtrgt1dst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssRMTrgt1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrsstsetrgt1dst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssTSETrgt1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrsstsitrgt1dst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssTSITrgt1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrsstrgt1maxdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssTrgt1MaxDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrsstrgt1mindst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssTrgt1MinDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrsstrgtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssTrgtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lncrssdctrldst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LnCrssdCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedlnchgcrsstimeleft_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LockedLnChgCrssTimeLeft_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedsidefrttarindx_mp(
    static_cast<uint32_t>(Mtn_Dcsn_mStg2LockedSideFrtTarIndx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedtar1indx_mp(
    static_cast<uint32_t>(Mtn_Dcsn_mStg2LockedTar1Indx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedtar1lonspd_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LockedTar1LonSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedtar1rng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LockedTar1Rng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2lockedvehspdmps_mp(
    static_cast<float>(Mtn_Dcsn_mStg2LockedVehSpdMps_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2mrginriskrngratecmpnstdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2MrgInRiskRngRateCmpnstDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2rmtar1ttc_mp(static_cast<float>(Mtn_Dcsn_mStg2RMTar1TTC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2rmtrgt1lncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RMTrgt1LnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2rmtrgt1lncrsslatofst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RMTrgt1LnCrssLatOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgctrldst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgrmtrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRMTrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgrmtrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRMTrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgrmtrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRMTrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgrmtrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRMTrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgreftrgtcrssdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRefTrgtCrssDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgreftrgtdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgRefTrgtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsidefrnttrgtcmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideFrntTrgtCmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsidefrnttrgtcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideFrntTrgtCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsidefrnttrgtestrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideFrntTrgtEstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsidefrnttrgtlmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideFrntTrgtLmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsidefrnttrgtlondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideFrntTrgtLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsiderrtrgtcmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideRrTrgtCmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsiderrtrgtcrssdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideRrTrgtCrssDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsiderrtrgtcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideRrTrgtCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsiderrtrgtestrngmax_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideRrTrgtEstRngMax_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgsiderrtrgtlmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgSideRrTrgtLmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsetrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSETrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsetrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSETrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsetrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSETrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsetrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSETrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsetrgt1londst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSETrgt1LonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsitrgt1cmpnstdsftydst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSITrgt1CmpnstdSftyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsitrgt1crsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSITrgt1CrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsitrgt1estrngmin_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSITrgt1EstRngMin_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2richgtsitrgt1lmtdcrsslondst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiChgTSITrgt1LmtdCrssLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2rifutnrsttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiFutNrstTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2rifutnrsttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiFutNrstTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2risidefrnttrgtlncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2RiSideFrntTrgtLnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2sidefrnttrgtlncrsslatofst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2SideFrntTrgtLnCrssLatOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsetar1ttc_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSETar1TTC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsetrgt1lncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSETrgt1LnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsetrgt1lncrsslatofst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSETrgt1LnCrssLatOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsitar1ttc_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSITar1TTC_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsitrgt1lncrsslatdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSITrgt1LnCrssLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2tsitrgt1lncrsslatofst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TSITrgt1LnCrssLatOfst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2trackedtar1diffdst_mp(
    static_cast<float>(Mtn_Dcsn_mStg2TrackedTar1DiffDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn12rmtrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn12RMTrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn12sidefrntrrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn12SideFrntRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn12tsetrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn12TSETrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn12tsitrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn12TSITrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn2rmtrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn2RMTrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn2sidefrntrrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn2SideFrntRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn2tsetrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn2TSETrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mstg2zn2tsitrgt1siderrtrgtrng_mp(
    static_cast<float>(Mtn_Dcsn_mStg2Zn2TSITrgt1SideRrTrgtRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn11_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn12_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn13_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn1_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn2_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1displace4zn3_mp(
    static_cast<float>(Mtn_Dcsn_mTar1Displace4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar1timegapsafedst_mp(
    static_cast<float>(Mtn_Dcsn_mTar1TimeGapSafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar23range_mp(static_cast<float>(Mtn_Dcsn_mTar23Range_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtar24range_mp(static_cast<float>(Mtn_Dcsn_mTar24Range_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtrgt7fltdoutlatdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mTrgt7FltdOutLatDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtrgt7fltdoutlnwdth_mp(
    static_cast<float>(Mtn_Dcsn_mTrgt7FltdOutLnWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtrgt8fltdoutlatdstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mTrgt8FltdOutLatDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mtrgt8fltdoutlnwdth_mp(
    static_cast<float>(Mtn_Dcsn_mTrgt8FltdOutLnWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn11BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11frttardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FrtTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn11FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11hosttail2rrheaddst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11HostTail2RrHeadDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11lockeddeltas_mp(
    static_cast<float>(Mtn_Dcsn_mZn11LockedDeltaS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11oversiderrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11OverSideRrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11rrtardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn11RrTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn11RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn11RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn11RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11selecttar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SelectTar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11siderrtarreldst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11SideRrTarRelDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn11Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11tar1dstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn11Tar1DstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn11Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn11Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11tar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn11Tar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11targetdst4rrtar_mp(
    static_cast<float>(Mtn_Dcsn_mZn11TargetDst4RrTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn11trkcrstarrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn11TrkCrsTarRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn12BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12frttardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FrtTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn12FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12futsdrrtarsafedstraw_mp(
    static_cast<float>(Mtn_Dcsn_mZn12FutSdRrTarSafeDstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12lnchgfutroom_mp(
    static_cast<float>(Mtn_Dcsn_mZn12LnChgFutRoom_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12rrtardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn12RrTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn12RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn12RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn12RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sdfrntandreartarfutrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SdFrntAndRearTarFutRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sdfrttarpos4rngchk_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SdFrtTarPos4RngChk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sdrrtarpos4rngchk_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SdRrTarPos4RngChk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sdrrtarsafedstraw_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SdRrTarSafeDstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1dstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1DstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn12Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1futtimegapcomprange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1FutTimeGapCompRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1futtimegaprange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1FutTimeGapRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn12tar1siderrfutrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn12Tar1SideRrFutRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn13BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13flwsidefrttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FlwSideFrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn13FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13hosthead2rrtaildst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13HostHead2RrTailDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13lockeddeltas_mp(
    static_cast<float>(Mtn_Dcsn_mZn13LockedDeltaS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn13RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn13RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn13RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13rrtartimedstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mZn13RrTarTimeDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13rrtarttltimedstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mZn13RrTarTtlTimeDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13selecttar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SelectTar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13sidefrttarreldst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SideFrtTarRelDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn13Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn13Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn13Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13tar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn13Tar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13targetdst4rrtar_mp(
    static_cast<float>(Mtn_Dcsn_mZn13TargetDst4RrTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13targetdst4tsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn13TargetDst4TSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn13trkcrstarrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn13TrkCrsTarRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn1BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1frttardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FrtTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn1FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1hosttail2rrheaddst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1HostTail2RrHeadDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1lockeddeltas_mp(
    static_cast<float>(Mtn_Dcsn_mZn1LockedDeltaS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1lonctrldst_mp(static_cast<float>(Mtn_Dcsn_mZn1LonCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1lonctrlevdlmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1LonCtrlEVDLmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1oversiderrtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1OverSideRrTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1rrtardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn1RrTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn1RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn1RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn1RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1selecttar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SelectTar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1siderrtarreldst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1SideRrTarRelDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn1Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1tar1dstfut_mp(static_cast<float>(Mtn_Dcsn_mZn1Tar1DstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn1Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn1Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1tar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn1Tar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1targetdst4rrtar_mp(
    static_cast<float>(Mtn_Dcsn_mZn1TargetDst4RrTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn1trkcrstarrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn1TrkCrsTarRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2and12rmtar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2And12RMTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2and12tsetar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2And12TSETar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2and12tsitar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2And12TSITar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn2BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2frttardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FrtTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn2FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2futsdrrtarsafedstraw_mp(
    static_cast<float>(Mtn_Dcsn_mZn2FutSdRrTarSafeDstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2lnchgfutroom_mp(
    static_cast<float>(Mtn_Dcsn_mZn2LnChgFutRoom_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2lonctrldst_mp(static_cast<float>(Mtn_Dcsn_mZn2LonCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2lonctrlevdlmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2LonCtrlEVDLmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2rrtardstfut_mp(
    static_cast<float>(Mtn_Dcsn_mZn2RrTarDstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn2RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn2RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn2RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sdfrntandreartarfutrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SdFrntAndRearTarFutRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sdfrttarpos4rngchk_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SdFrtTarPos4RngChk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sdrrtarpos4rngchk_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SdRrTarPos4RngChk_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sdrrtarsafedstraw_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SdRrTarSafeDstRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1dstfut_mp(static_cast<float>(Mtn_Dcsn_mZn2Tar1DstFut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn2Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1futtimegapcomprange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Tar1FutTimeGapCompRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1futtimegaprange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Tar1FutTimeGapRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn2tar1siderrfutrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn2Tar1SideRrFutRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3and13rangethrldwhennozn_mp(
    static_cast<float>(Mtn_Dcsn_mZn3And13RangeThrldWhenNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3and13timethrldwhennozn_mp(
    static_cast<float>(Mtn_Dcsn_mZn3And13TimeThrldWhenNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3bgnlnchgflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3BgnLnChgFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3bgnlnchgposflt_mp(
    static_cast<float>(Mtn_Dcsn_mZn3BgnLnChgPosFlt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3expctflwtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3ExpctFlwTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3flwfrttarpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FlwFrtTarPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3flwsidefrttarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FlwSideFrtTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3flwtarbgnlnchgdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FlwTarBgnLnChgDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3flwtarexpctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FlwTarExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3frttardst_mp(static_cast<float>(Mtn_Dcsn_mZn3FrtTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3frttarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FrtTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3frttarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FrtTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3futnearesttar1dstbtwntsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FutNearestTar1DstBtwnTSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3futnearesttar1safedst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FutNearestTar1SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3futnearesttar1saferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3FutNearestTar1SafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3hosthead2rrtaildst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3HostHead2RrTailDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3lockeddeltas_mp(
    static_cast<float>(Mtn_Dcsn_mZn3LockedDeltaS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3lonctrldstnoevd_mp(
    static_cast<float>(Mtn_Dcsn_mZn3LonCtrlDstNoEVD_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3lonctrldst_mp(static_cast<float>(Mtn_Dcsn_mZn3LonCtrlDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3lonctrlevdlmtdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3LonCtrlEVDLmtDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3nearesttar1currange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3NearestTar1CurRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3rrtardst_mp(static_cast<float>(Mtn_Dcsn_mZn3RrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3rrtarexpctpos_mp(
    static_cast<float>(Mtn_Dcsn_mZn3RrTarExpctPos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3rrtarsafepos_mp(
    static_cast<float>(Mtn_Dcsn_mZn3RrTarSafePos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3rrtartimedstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mZn3RrTarTimeDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3rrtarttltimedstlmt_mp(
    static_cast<float>(Mtn_Dcsn_mZn3RrTarTtlTimeDstLmt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3selecttar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SelectTar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3sidefrttarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SideFrtTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3sidefrttarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SideFrtTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3sidefrttarreldst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SideFrtTarRelDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3siderrtarfutcompsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SideRrTarFutCompSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3siderrtarfutexptrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3SideRrTarFutExptRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3stg1futexpctrng_mp(
    static_cast<float>(Mtn_Dcsn_mZn3Stg1FutExpctRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3tar1dst_mp(static_cast<float>(Mtn_Dcsn_mZn3Tar1Dst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3tar1expctdst_mp(
    static_cast<float>(Mtn_Dcsn_mZn3Tar1ExpctDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3tar1futdist_mp(
    static_cast<float>(Mtn_Dcsn_mZn3Tar1FutDist_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3tar1futsaferange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3Tar1FutSafeRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3targetdst4rrtar_mp(
    static_cast<float>(Mtn_Dcsn_mZn3TargetDst4RrTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3targetdst4tsetar1_mp(
    static_cast<float>(Mtn_Dcsn_mZn3TargetDst4TSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzn3trkcrstarrange_mp(
    static_cast<float>(Mtn_Dcsn_mZn3TrkCrsTarRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone11RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone11SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone11SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11stg1ovrsiderrtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone11Stg1OvrSideRrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone11TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone11tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone11TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12egovehfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12EgoVehFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12stg1flwsidetardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone12Stg1FlwSideTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone12TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone12timegapdis_mp(
    static_cast<float>(Mtn_Dcsn_mZone12TimeGapDis_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone13RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone13SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone13SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13stg1flwsidetardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone13Stg1FlwSideTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone13TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone13tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone13TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone1RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone1SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone1SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1stg1ovrsiderrtardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone1Stg1OvrSideRrTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone1TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone1tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone1TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2egovehfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2EgoVehFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2stg1flwsidetardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone2Stg1FlwSideTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone2TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone2timegapdis_mp(
    static_cast<float>(Mtn_Dcsn_mZone2TimeGapDis_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3and13tar9mindst_mp(
    static_cast<float>(Mtn_Dcsn_mZone3And13Tar9MinDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3rmtar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone3RMTar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3sifrttarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone3SiFrtTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3sirrtarfuturerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone3SiRrTarFutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3stg1flwsidetardst_mp(
    static_cast<float>(Mtn_Dcsn_mZone3Stg1FlwSideTarDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3tsetar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone3TSETar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mzone3tsitar1futurerange_mp(
    static_cast<float>(Mtn_Dcsn_mZone3TSITar1FutureRange_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpslelnchglatspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsLeLnChgLatSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsrilnchglatspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsRiLnChgLatSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpstar23rangerate_mp(
    static_cast<float>(Mtn_Dcsn_mpsTar23RangeRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpstar23vx_mp(static_cast<float>(Mtn_Dcsn_mpsTar23Vx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpstar24rangerate_mp(
    static_cast<float>(Mtn_Dcsn_mpsTar24RangeRate_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpstar24vx_mp(static_cast<float>(Mtn_Dcsn_mpsTar24Vx_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn11futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn11FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn11trkcrstarspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn11TrkCrsTarSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn12futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn12FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn13futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn13FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn13trkcrstarspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn13TrkCrsTarSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn1futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn1FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn1trkcrstarspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn1TrkCrsTarSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn2futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn2FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn3futnearesttar1vehspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn3FutNearestTar1VehSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpszn3trkcrstarspd_mp(
    static_cast<float>(Mtn_Dcsn_mpsZn3TrkCrsTarSpd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpssstg2avrglonaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssStg2AvrgLonAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpssstg2lechgctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssStg2LeChgCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpssstg2lncrssdctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssStg2LnCrssdCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpssstg2richgctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssStg2RiChgCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsstar23lonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssTar23LonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsstar24lonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssTar24LonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn11trkcrstarlonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn11TrkCrsTarLonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn11trktarlonequacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn11TrkTarLonEquAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn13trkcrstarlonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn13TrkCrsTarLonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn13trktarlonequacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn13TrkTarLonEquAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn1lonctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn1LonCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn1trkcrstarlonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn1TrkCrsTarLonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn1trktarlonequacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn1TrkTarLonEquAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn2lonctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn2LonCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn3lonctrlavrgaccl_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn3LonCtrlAvrgAccl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn3trkcrstarlonacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn3TrkCrsTarLonAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_mpsszn3trktarlonequacc_mp(
    static_cast<float>(Mtn_Dcsn_mpssZn3TrkTarLonEquAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_numtar23objindex_mp(
    static_cast<uint32_t>(Mtn_Dcsn_numTar23ObjIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_numtar24objindex_mp(
    static_cast<uint32_t>(Mtn_Dcsn_numTar24ObjIndex_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_pntzn12sdrrtarsafedstfac_mp(
    static_cast<float>(Mtn_Dcsn_pntZn12SdRrTarSafeDstFac_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_pntzn12sdrrtarstblfac_mp(
    static_cast<float>(Mtn_Dcsn_pntZn12SdRrTarStblFac_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_pntzn2sdrrtarsafedstfac_mp(
    static_cast<float>(Mtn_Dcsn_pntZn2SdRrTarSafeDstFac_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_pntzn2sdrrtarstblfac_mp(
    static_cast<float>(Mtn_Dcsn_pntZn2SdRrTarStblFac_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_slelnchgtimeestd_mp(
    static_cast<float>(Mtn_Dcsn_sLeLnChgTimeEstd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_smrginlefttime_mp(static_cast<float>(Mtn_Dcsn_sMrgInLeftTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_srilnchgtimeestd_mp(
    static_cast<float>(Mtn_Dcsn_sRiLnChgTimeEstd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_srtrnchckrmtrgt1time_mp(
    static_cast<float>(Mtn_Dcsn_sRtrnChckRMTrgt1Time_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_srtrnchcktsetrgt1time_mp(
    static_cast<float>(Mtn_Dcsn_sRtrnChckTSETrgt1Time_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_srtrnchcktsitrgt1time_mp(
    static_cast<float>(Mtn_Dcsn_sRtrnChckTSITrgt1Time_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ssifrttarttczn11_mp(
    static_cast<float>(Mtn_Dcsn_sSiFrtTarTTCZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ssifrttarttczn1_mp(
    static_cast<float>(Mtn_Dcsn_sSiFrtTarTTCZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2lechgctrltime_mp(
    static_cast<float>(Mtn_Dcsn_sStg2LeChgCtrlTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2lechgctrltrgt_mp(
    static_cast<uint32_t>(Mtn_Dcsn_sStg2LeChgCtrlTrgt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2lnchgcrsstimeleft_mp(
    static_cast<float>(Mtn_Dcsn_sStg2LnChgCrssTimeLeft_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2lnchgtimeleft_mp(
    static_cast<float>(Mtn_Dcsn_sStg2LnChgTimeLeft_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2lncrssdctrltime_mp(
    static_cast<float>(Mtn_Dcsn_sStg2LnCrssdCtrlTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2richgctrltime_mp(
    static_cast<float>(Mtn_Dcsn_sStg2RiChgCtrlTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_sstg2richgctrltrgt_mp(
    static_cast<uint32_t>(Mtn_Dcsn_sStg2RiChgCtrlTrgt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seclnchgmaxtmbsonevddst_mp(
    static_cast<float>(Mtn_Dcsn_secLnChgMaxTmbsOnEVDDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn12sdrrtarstbltm_mp(
    static_cast<float>(Mtn_Dcsn_secZn12SdRrTarStblTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn12sdrrtarttc4safedst_mp(
    static_cast<float>(Mtn_Dcsn_secZn12SdRrTarTtc4SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn12sdrrtarttc_mp(
    static_cast<float>(Mtn_Dcsn_secZn12SdRrTarTtc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn12sdrrtarvldttc_mp(
    static_cast<float>(Mtn_Dcsn_secZn12SdRrTarVldTtc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn2sdrrtarstbltm_mp(
    static_cast<float>(Mtn_Dcsn_secZn2SdRrTarStblTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn2sdrrtarttc4safedst_mp(
    static_cast<float>(Mtn_Dcsn_secZn2SdRrTarTtc4SafeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn2sdrrtarttc_mp(
    static_cast<float>(Mtn_Dcsn_secZn2SdRrTarTtc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_seczn2sdrrtarvldttc_mp(
    static_cast<float>(Mtn_Dcsn_secZn2SdRrTarVldTtc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn11_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn12_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn13_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn1_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn2_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stctrltimemode4zn3_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stCtrlTimeMode4Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stfollowtarraw_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stFollowTarRaw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlelnchgpreferzn_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLeLnChgPreferZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone11expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone11ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone12expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone12ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone13expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone13ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone1expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone1ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone2expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone2ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlnchgzone3expctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLnChgZone3ExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlon2ctltarget_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLon2CtlTarget_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stlonctrldsttrgtsel_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stLonCtrlDstTrgtSel_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stmainrdznout_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stMainRdZnOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stmrginznout_mp(static_cast<uint32_t>(Mtn_Dcsn_stMrgInZnOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_strilnchgpreferzn_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stRiLnChgPreferZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stselecttar1mode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stSelectTar1Mode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stselecttar1out_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stSelectTar1Out_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ststg2lefutnrsttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stStg2LeFutNrstTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ststg2rifutnrsttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stStg2RiFutNrstTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn11trkcrstarnum_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn11TrkCrsTarNum_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn12expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn12ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn12futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn12FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn12lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn12LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn12lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn12LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn12stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn12Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn13trkcrstarnum_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn13TrkCrsTarNum_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn1trkcrstarnum_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn1TrkCrsTarNum_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn2expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn2ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn2futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn2FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn2lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn2LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn2lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn2LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn2stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn2Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3expctflwtarid_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3ExpctFlwTarID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3futnearesttar1selectmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3FutNearestTar1SelectMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3lrgtardstbgnlnchgposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3LrgTarDstBgnLnChgPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3lrgtardstexpctposmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3LrgTarDstExpctPosMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3stg1futexpctrngmode_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3Stg1FutExpctRngMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_stzn3trkcrstarnum_mp(
    static_cast<uint32_t>(Mtn_Dcsn_stZn3TrkCrsTarNum_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tlon2ctltime_mp(static_cast<float>(Mtn_Dcsn_tLon2CtlTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tlondstaccllmtdtime_mp(
    static_cast<float>(Mtn_Dcsn_tLonDstAcclLmtdTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tlondstdcllmtdtime_mp(
    static_cast<float>(Mtn_Dcsn_tLonDstDclLmtdTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tmaxdecelesttimesidefrttar4zn12_mp(
    static_cast<float>(Mtn_Dcsn_tMaxDecelEstTimeSideFrtTar4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tmaxdecelesttimesidefrttar4zn2_mp(
    static_cast<float>(Mtn_Dcsn_tMaxDecelEstTimeSideFrtTar4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ttotallimitdeceltimesidefrttar4zn12_mp(
    static_cast<float>(Mtn_Dcsn_tTotalLimitDecelTimeSideFrtTar4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ttotallimitdeceltimesidefrttar4zn2_mp(
    static_cast<float>(Mtn_Dcsn_tTotalLimitDecelTimeSideFrtTar4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ttotalmaxdecelesttimesidefrttar4zn12_mp(
    static_cast<float>(Mtn_Dcsn_tTotalMaxDecelEstTimeSideFrtTar4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ttotalmaxdecelesttimesidefrttar4zn2_mp(
    static_cast<float>(Mtn_Dcsn_tTotalMaxDecelEstTimeSideFrtTar4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsirrtar1frzone11_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiRrTar1FrZone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsirrtar1frzone1_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiRrTar1FrZone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsitar4zone11_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiTar4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsitar4zone13_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiTar4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsitar4zone1_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiTar4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2btnsitar4zone3_mp(
    static_cast<float>(Mtn_Dcsn_ti2BtnSiTar4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone11_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone12_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone13_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone1_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone2_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sifrttar4zone3_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiFrtTar4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtar4zone11_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTar4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtar4zone12_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTar4Zone12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtar4zone1_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTar4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtar4zone2_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTar4Zone2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtarbsaccel4zn12_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTarBsAccel4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2sirrtarbsaccel4zn2_mp(
    static_cast<float>(Mtn_Dcsn_ti2SiRrTarBsAccel4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone11_mp(
    static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone12_mp(
    static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone13_mp(
    static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone1_mp(static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone2_mp(static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti2tar1frzone3_mp(static_cast<float>(Mtn_Dcsn_ti2Tar1FrZone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4bsrngadratefrt1zn13_mp(
    static_cast<float>(Mtn_Dcsn_ti4BsRngAdRateFrt1Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4bsrngadratefrt1zn3_mp(
    static_cast<float>(Mtn_Dcsn_ti4BsRngAdRateFrt1Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4bsrngadratesifrtzn13_mp(
    static_cast<float>(Mtn_Dcsn_ti4BsRngAdRateSiFrtZn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4bsrngadratesifrtzn3_mp(
    static_cast<float>(Mtn_Dcsn_ti4BsRngAdRateSiFrtZn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4lonctrlfin4zn11_mp(
    static_cast<float>(Mtn_Dcsn_ti4LonCtrlFin4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4lonctrlfin4zn12_mp(
    static_cast<float>(Mtn_Dcsn_ti4LonCtrlFin4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4lonctrlfin4zn1_mp(
    static_cast<float>(Mtn_Dcsn_ti4LonCtrlFin4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ti4lonctrlfin4zn2_mp(
    static_cast<float>(Mtn_Dcsn_ti4LonCtrlFin4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiaftamendzn11_mp(static_cast<float>(Mtn_Dcsn_tiAftAmendZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiaftamendzn12_mp(static_cast<float>(Mtn_Dcsn_tiAftAmendZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiaftamendzn1_mp(static_cast<float>(Mtn_Dcsn_tiAftAmendZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiaftamendzn2_mp(static_cast<float>(Mtn_Dcsn_tiAftAmendZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tibsrngadratesirr4zn12_mp(
    static_cast<float>(Mtn_Dcsn_tiBsRngAdRateSiRr4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tibsrngadratesirr4zn2_mp(
    static_cast<float>(Mtn_Dcsn_tiBsRngAdRateSiRr4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tibstar1rngadrtzn12_mp(
    static_cast<float>(Mtn_Dcsn_tiBsTar1RngAdRtZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone11_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone12_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone13_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone1_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone2_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tictrltime4zone3_mp(
    static_cast<float>(Mtn_Dcsn_tiCtrlTime4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilatlcmeetlntime_mp(
    static_cast<float>(Mtn_Dcsn_tiLatLCMeetLnTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilatch4zn11cros_mp(
    static_cast<float>(Mtn_Dcsn_tiLatch4Zn11Cros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilatch4zn13cros_mp(
    static_cast<float>(Mtn_Dcsn_tiLatch4Zn13Cros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilatch4zn1cros_mp(
    static_cast<float>(Mtn_Dcsn_tiLatch4Zn1Cros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilatch4zn3cros_mp(
    static_cast<float>(Mtn_Dcsn_tiLatch4Zn3Cros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilelachgstage2_mp(
    static_cast<float>(Mtn_Dcsn_tiLeLaChgStage2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilock4crosstar_mp(
    static_cast<float>(Mtn_Dcsn_tiLock4CrossTar_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilonctrl2cross4zn11_mp(
    static_cast<float>(Mtn_Dcsn_tiLonCtrl2Cross4Zn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilonctrl2cross4zn12_mp(
    static_cast<float>(Mtn_Dcsn_tiLonCtrl2Cross4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilonctrl2cross4zn1_mp(
    static_cast<float>(Mtn_Dcsn_tiLonCtrl2Cross4Zn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tilonctrl2cross4zn2_mp(
    static_cast<float>(Mtn_Dcsn_tiLonCtrl2Cross4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirilachgstage2_mp(
    static_cast<float>(Mtn_Dcsn_tiRiLaChgStage2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiroot1zone11_mp(static_cast<float>(Mtn_Dcsn_tiRoot1Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiroot1zone1_mp(static_cast<float>(Mtn_Dcsn_tiRoot1Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiroot2zone11_mp(static_cast<float>(Mtn_Dcsn_tiRoot2Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tiroot2zone1_mp(static_cast<float>(Mtn_Dcsn_tiRoot2Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn11_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn12_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn13_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn2_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sifrtzn3_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiFrtZn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sirrzn12_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiRrZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sirrzn1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiRrZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4sirrzn2_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4SiRrZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4tar1zn13_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4Tar1Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccel4tar1zn3_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccel4Tar1Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsaccelrrzone11_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsAccelRrZone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsdeclim4rmtar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsDecLim4RMTar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsdeclim4tsetar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsDecLim4TSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt1bsdeclim4tsitar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt1bsDecLim4TSITar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn11_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn12_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn13_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn2_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sifrtzn3_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiFrtZn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sirrzn12_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiRrZn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sirrzn1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiRrZn1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4sirrzn2_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4SiRrZn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4tar1zn13_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4Tar1Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccel4tar1zn3_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccel4Tar1Zn3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsaccelrrzone11_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsAccelRrZone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsdeclim4rmtar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsDecLim4RMTar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsdeclim4tsetar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsDecLim4TSETar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tirt2bsdeclim4tsitar1_mp(
    static_cast<float>(Mtn_Dcsn_tiRt2bsDecLim4TSITar1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn13stg1tm2cross_mp(
    static_cast<float>(Mtn_Dcsn_tiZn13Stg1Tm2Cross_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_tizn3stg1tm2cross_mp(
    static_cast<float>(Mtn_Dcsn_tiZn3Stg1Tm2Cross_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_titibstar1rngadrt_mp(
    static_cast<float>(Mtn_Dcsn_titiBsTar1RngAdRt_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskarrivstg1pos_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskArrivStg1Pos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskevdlcaeff_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskEVDLcaEff_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmasklc2cruiseres_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskLC2CruiseRes_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmasklc2cruise_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskLC2Cruise_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmasklfrngarrivstg1posadv_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskLfRngArrivStg1PosAdv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmasklfrngrt4arrivstg1pos_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskLfRngRt4ArrivStg1Pos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskreturnreason_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskReturnReason_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskreturn_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskReturn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskrirngarrivstg1posadv_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskRiRngArrivStg1PosAdv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskrirngrt4arrivstg1pos_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskRiRngRt4ArrivStg1Pos_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskstg2chkinactv_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskStg2ChkInactv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskstg2lectrldstinvld_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskStg2LeCtrlDstInvld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskstg2rictrldstinvld_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskStg2RiCtrlDstInvld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskznstlfarrivstg1posadv_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskZnStLfArrivStg1PosAdv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskznstriarrivstg1posadv_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskZnStRiArrivStg1PosAdv_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskzonerst_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMaskZoneRst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmskstg2acclchkmsk4zn12_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskStg2AcclChkMsk4Zn12_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmskstg2acclchkmsk4zn2_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskStg2AcclChkMsk4Zn2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmskstg2lerngvld_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskStg2LeRngVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmskstg2rirngvld_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskStg2RiRngVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmsktrgt7fltdout_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskTrgt7FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmsktrgt8fltdout_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitMskTrgt8FltdOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitneartar4zn13_mp(
    static_cast<uint32_t>(Mtn_Dcsn_uBitnearTar4Zn13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskzn12reartarstbl_mp(
    static_cast<uint32_t>(Mtn_Dcsn_ubitMaskZn12RearTarStbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dcsn_ubitmaskzn2reartarstbl_mp(
    static_cast<uint32_t>(Mtn_Dcsn_ubitMaskZn2RearTarStbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dscn_mstg2lncrssdtimegaprng_mp(
    static_cast<float>(Mtn_Dscn_mStg2LnCrssdTimeGapRng_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_dscn_stlastdcsnznout_mp(
    static_cast<uint32_t>(Mtn_Dscn_stLastDcsnZnOut_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_islohmpathinlane_mp(
    static_cast<bool>(Mtn_Plan_IsLohmPathInLane_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgegolinec0raw_mp(
    static_cast<float>(Mtn_Plan_LaneChgEgoLineC0Raw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechglereflinec0raw_mp(
    static_cast<float>(Mtn_Plan_LaneChgLeRefLineC0Raw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgreflinec0_mp(
    static_cast<float>(Mtn_Plan_LaneChgRefLineC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgreflinec1_mp(
    static_cast<float>(Mtn_Plan_LaneChgRefLineC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgreflinec2_mp(
    static_cast<float>(Mtn_Plan_LaneChgRefLineC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgreflinec3_mp(
    static_cast<float>(Mtn_Plan_LaneChgRefLineC3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lanechgrireflinec0raw_mp(
    static_cast<float>(Mtn_Plan_LaneChgRiRefLineC0Raw_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntc0err_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntC0Err_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntc1err_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntC1Err_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntc2err_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntC2Err_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta0_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta1_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta2_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta3_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta4_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntfcta5_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntFctA5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntpos0c0_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPos0C0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntpos0c1_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPos0C1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntpos0c2_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPos0C2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntprdctc0_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPrdctC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntprdctc1_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPrdctC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathfrntprdctc2_mp(
    static_cast<float>(Mtn_Plan_LatPathFrntPrdctC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta0_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta1_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta2_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta3_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta4_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA4_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvcsfcta5_mp(
    static_cast<float>(Mtn_Plan_LatPathVCSFctA5_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvehbasefrntc0_mp(
    static_cast<float>(Mtn_Plan_LatPathVehBaseFrntC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvehbasefrntc1_mp(
    static_cast<float>(Mtn_Plan_LatPathVehBaseFrntC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latpathvehbasefrntc2_mp(
    static_cast<float>(Mtn_Plan_LatPathVehBaseFrntC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latplanpathc0_mp(static_cast<float>(Mtn_Plan_LatPlanPathC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latplanpathc1_mp(static_cast<float>(Mtn_Plan_LatPlanPathC1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latplanpathc2_mp(static_cast<float>(Mtn_Plan_LatPlanPathC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_latplanrdstage_mp(static_cast<bool>(Mtn_Plan_LatPlanRdStage_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tibeflnchgc0time_mp(
    static_cast<float>(Mtn_Plan_TiBefLnChgC0Time_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tibeflnchgc1time_mp(
    static_cast<float>(Mtn_Plan_TiBefLnChgC1Time_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tibeflnchgtime_mp(static_cast<float>(Mtn_Plan_TiBefLnChgTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcinittime_c0_mp(
    static_cast<float>(Mtn_Plan_TiLCInitTime_C0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcinittime_c1_mp(
    static_cast<float>(Mtn_Plan_TiLCInitTime_C1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcinittime_mp(static_cast<float>(Mtn_Plan_TiLCInitTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcmintime_c0_mp(static_cast<float>(Mtn_Plan_TiLCMinTime_C0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcmintime_c1_mp(static_cast<float>(Mtn_Plan_TiLCMinTime_C1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcmintime_mp(static_cast<float>(Mtn_Plan_TiLCMinTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilanechgresttime_mp(
    static_cast<float>(Mtn_Plan_TiLaneChgRestTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilelcvehcroslntm_mp(
    static_cast<float>(Mtn_Plan_TiLeLCVehCrosLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilelcvehmeetlntm_mp(
    static_cast<float>(Mtn_Plan_TiLeLCVehMeetLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilelcvehoverlntm_mp(
    static_cast<float>(Mtn_Plan_TiLeLCVehOverLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tirilcvehcroslntm_mp(
    static_cast<float>(Mtn_Plan_TiRiLCVehCrosLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tirilcvehmeetlntm_mp(
    static_cast<float>(Mtn_Plan_TiRiLCVehMeetLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tirilcvehoverlntm_mp(
    static_cast<float>(Mtn_Plan_TiRiLCVehOverLnTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_bfalclanedetmidqi_mp(
    static_cast<uint32_t>(Mtn_Plan_bfALCLaneDetMidQI_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_bflcasmcdnmask_mp(
    static_cast<uint32_t>(Mtn_Plan_bfLCASMCdnMask_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_bflcprpractvsprsmask_mp(
    static_cast<uint32_t>(Mtn_Plan_bfLCPrprActvSprsMask_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_bftransendmask_mp(
    static_cast<uint32_t>(Mtn_Plan_bfTransEndMask_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_deglatplanrefstrngangle_mp(
    static_cast<float>(Mtn_Plan_degLatPlanRefStrngAngle_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_degstrwhlagforfrntinitcalc_mp(
    static_cast<float>(Mtn_Plan_degStrWhlAgForFrntInitCalc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_facpathplandrvprtnfac_mp(
    static_cast<float>(Mtn_Plan_facPathPlanDrvPrtnFac_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalclelinec0jump_mp(
    static_cast<bool>(Mtn_Plan_flgALCLeLineC0Jump_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalclelinefirstcros_mp(
    static_cast<bool>(Mtn_Plan_flgALCLeLineFirstCros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalcleriallcrosline_mp(
    static_cast<bool>(Mtn_Plan_flgALCLeRiAllCrosLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalcnxlelinec0jump_mp(
    static_cast<bool>(Mtn_Plan_flgALCNxLeLineC0Jump_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalcnxrilinec0jump_mp(
    static_cast<bool>(Mtn_Plan_flgALCNxRiLineC0Jump_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalcrilinec0jump_mp(
    static_cast<bool>(Mtn_Plan_flgALCRiLineC0Jump_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgalcrilinefirstcros_mp(
    static_cast<bool>(Mtn_Plan_flgALCRiLineFirstCros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgbgnfrntpathplan_mp(
    static_cast<bool>(Mtn_Plan_flgBgnFrntPathPlan_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgfrntlcpathovrsht_mp(
    static_cast<bool>(Mtn_Plan_flgFrntLCPathOvrsht_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgfrntpathovershoot_mp(
    static_cast<bool>(Mtn_Plan_flgFrntPathOverShoot_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgfrntprdctparalargeerr_mp(
    static_cast<bool>(Mtn_Plan_flgFrntPrdctParaLargeErr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglcapreparesprsreq_mp(
    static_cast<bool>(Mtn_Plan_flgLCAPrepareSprsReq_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglcrstdstnotenough_mp(
    static_cast<bool>(Mtn_Plan_flgLCRstDstNotEnough_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglksagearlytocntrdlycyl_mp(
    static_cast<bool>(Mtn_Plan_flgLKSAgEarlyToCntrDlyCyl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglksagearlytocntr_mp(
    static_cast<bool>(Mtn_Plan_flgLKSAgEarlyToCntr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglanechglastatmptnozone_mp(
    static_cast<bool>(Mtn_Plan_flgLaneChgLastAtmptNoZone_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglanechgovrothersidelane_mp(
    static_cast<bool>(Mtn_Plan_flgLaneChgOvrOtherSideLane_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglanechgovrshoot_mp(
    static_cast<bool>(Mtn_Plan_flgLaneChgOvrShoot_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglcalongadjust2wait_mp(
    static_cast<bool>(Mtn_Plan_flgLcaLongAdjust2Wait_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglcatran2lksstabsts_mp(
    static_cast<bool>(Mtn_Plan_flgLcaTran2LksStabSts_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglefrntpathovstend_mp(
    static_cast<bool>(Mtn_Plan_flgLeFrntPathOvStEnd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelcmeetlntmvld_mp(
    static_cast<bool>(Mtn_Plan_flgLeLCMeetLnTmVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelanechgcdn_mp(
    static_cast<bool>(Mtn_Plan_flgLeLaneChgCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelinec0jumpaftcrsgline_mp(
    static_cast<bool>(Mtn_Plan_flgLeLineC0JumpAftCrsgLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelinec0jumpbefcrsline_mp(
    static_cast<bool>(Mtn_Plan_flgLeLineC0JumpBefCrsLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelinec0jumpresaftcros_mp(
    static_cast<bool>(Mtn_Plan_flgLeLineC0JumpResAftCros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelinec0jumpres_mp(
    static_cast<bool>(Mtn_Plan_flgLeLineC0JumpRes_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelinegood_mp(static_cast<bool>(Mtn_Plan_flgLeLineGood_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglelnchgcncldurngnozn_mp(
    static_cast<bool>(Mtn_Plan_flgLeLnChgCnclDurngNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgletranvehmvoutlane_mp(
    static_cast<bool>(Mtn_Plan_flgLeTranVehMvOutLane_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flglnchgvehcannotreturn_mp(
    static_cast<float>(Mtn_Plan_flgLnChgVehCanNotReturn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgnxlelinec0jumpbefcrsline_mp(
    static_cast<bool>(Mtn_Plan_flgNxLeLineC0JumpBefCrsLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgnxlelinec0jumpres_mp(
    static_cast<bool>(Mtn_Plan_flgNxLeLineC0JumpRes_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgnxrilinec0jumpbefcrsline_mp(
    static_cast<bool>(Mtn_Plan_flgNxRiLineC0JumpBefCrsLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgnxrilinec0jumpres_mp(
    static_cast<bool>(Mtn_Plan_flgNxRiLineC0JumpRes_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgoutlksagfortrans_mp(
    static_cast<bool>(Mtn_Plan_flgOutLKSAgForTrans_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrifrntpathovstend_mp(
    static_cast<bool>(Mtn_Plan_flgRiFrntPathOvStEnd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilcmeetlntmvld_mp(
    static_cast<bool>(Mtn_Plan_flgRiLCMeetLnTmVld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilanechgcdn_mp(
    static_cast<bool>(Mtn_Plan_flgRiLaneChgCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilinec0jumpaftcrsgline_mp(
    static_cast<bool>(Mtn_Plan_flgRiLineC0JumpAftCrsgLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilinec0jumpbefcrsline_mp(
    static_cast<bool>(Mtn_Plan_flgRiLineC0JumpBefCrsLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilinec0jumpresaftcros_mp(
    static_cast<bool>(Mtn_Plan_flgRiLineC0JumpResAftCros_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilinec0jumpres_mp(
    static_cast<bool>(Mtn_Plan_flgRiLineC0JumpRes_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilinegood_mp(static_cast<bool>(Mtn_Plan_flgRiLineGood_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgrilnchgcncldurngnozn_mp(
    static_cast<bool>(Mtn_Plan_flgRiLnChgCnclDurngNoZn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgritranvehmvoutlane_mp(
    static_cast<bool>(Mtn_Plan_flgRiTranVehMvOutLane_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgstoplanechgcdn_mp(
    static_cast<bool>(Mtn_Plan_flgStopLaneChgCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranvehinegolane_mp(
    static_cast<bool>(Mtn_Plan_flgTranVehInEgoLane_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranscrsgline_mp(
    static_cast<bool>(Mtn_Plan_flgTransCrsgLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranscrsglnovsht_mp(
    static_cast<bool>(Mtn_Plan_flgTransCrsgLnOvSht_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranscrsglntolksstbl_mp(
    static_cast<bool>(Mtn_Plan_flgTransCrsgLnToLksStbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranscrsglntqovrd_mp(
    static_cast<bool>(Mtn_Plan_flgTransCrsgLnTqOvrd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtranslksc0stbl_mp(
    static_cast<bool>(Mtn_Plan_flgTransLksC0Stbl_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtransretegodir_mp(
    static_cast<uint32_t>(Mtn_Plan_flgTransRetEgoDir_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgtrnstend_mp(static_cast<bool>(Mtn_Plan_flgTrnstEnd_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgvehbeflnchgsamedir_mp(
    static_cast<bool>(Mtn_Plan_flgVehBefLnChgSameDir_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_flgvehlnchgsamedir_mp(
    static_cast<bool>(Mtn_Plan_flgVehLnChgSameDir_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lfreelclatdsterr_mp(
    static_cast<float>(Mtn_Plan_lFreeLCLatDstErr_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_lfreelclatrefdst_mp(
    static_cast<float>(Mtn_Plan_lFreeLCLatRefDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_ltrans2egolanedst_mp(
    static_cast<float>(Mtn_Plan_lTrans2EgoLaneDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_ltrans2egolanevydst_mp(
    static_cast<float>(Mtn_Plan_lTrans2EgoLaneVyDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_malcegolanewdthbyline_mp(
    static_cast<float>(Mtn_Plan_mALCEgoLaneWdthByLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_malclelanewdthbyline_mp(
    static_cast<float>(Mtn_Plan_mALCLeLaneWdthByLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_malcrilanewdthbyline_mp(
    static_cast<float>(Mtn_Plan_mALCRiLaneWdthByLine_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mbeflnchgnormlatdst_mp(
    static_cast<float>(Mtn_Plan_mBefLnChgNormLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos0frnts_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos0FrntS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos0frntt_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos0FrntT_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos1frnts_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos1FrntS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos1frntt_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos1FrntT_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos2frnts_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos2FrntS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_megovehpos2frntt_mp(
    static_cast<float>(Mtn_Plan_mEgoVehPos2FrntT_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngbsrngratezone11_mp(
    static_cast<float>(Mtn_Plan_mEstRngBsRngRateZone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngbsrngratezone13_mp(
    static_cast<float>(Mtn_Plan_mEstRngBsRngRateZone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngbsrngratezone1_mp(
    static_cast<float>(Mtn_Plan_mEstRngBsRngRateZone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mestrngbsrngratezone3_mp(
    static_cast<float>(Mtn_Plan_mEstRngBsRngRateZone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrenethldc0_mp(static_cast<float>(Mtn_Plan_mFrenetHldC0_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntlcpathegolanemaxlatdst_mp(
    static_cast<float>(Mtn_Plan_mFrntLCPathEgoLaneMaxLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntlcpathegolanemaxlondst_mp(
    static_cast<float>(Mtn_Plan_mFrntLCPathEgoLaneMaxLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntlcpathovrshtlatdst_mp(
    static_cast<float>(Mtn_Plan_mFrntLCPathOvrshtLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntlcpathovrshtlondst_mp(
    static_cast<float>(Mtn_Plan_mFrntLCPathOvrshtLonDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntpathmaxovershoots_mp(
    static_cast<float>(Mtn_Plan_mFrntPathMaxOverShootS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mfrntpathmaxovershoott_mp(
    static_cast<float>(Mtn_Plan_mFrntPathMaxOverShootT_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlanechgegolanewdth_mp(
    static_cast<float>(Mtn_Plan_mLaneChgEgoLaneWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlanechgrestlength_mp(
    static_cast<float>(Mtn_Plan_mLaneChgRestLength_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlelcvehcroslnlatdst_mp(
    static_cast<float>(Mtn_Plan_mLeLCVehCrosLnLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlelcvehmetlnlatdst_mp(
    static_cast<float>(Mtn_Plan_mLeLCVehMetLnLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlelanechgegolanewdth_mp(
    static_cast<float>(Mtn_Plan_mLeLaneChgEgoLaneWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlelanewdth_mp(static_cast<float>(Mtn_Plan_mLeLaneWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlnchginitnormlatdst_mp(
    static_cast<float>(Mtn_Plan_mLnChgInitNormLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mlnchgminnormlatdst_mp(
    static_cast<float>(Mtn_Plan_mLnChgMinNormLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->add_mtn_plan_mpathfitlatdsterr_mp(
    static_cast<double>(Mtn_Plan_mPathFitLatDstErr_mp[0]));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpathtotallength_mp(
    static_cast<float>(Mtn_Plan_mPathTotalLength_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mreflnc0jump_mp(static_cast<float>(Mtn_Plan_mRefLnC0Jump_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mrilcvehcroslnlatdst_mp(
    static_cast<float>(Mtn_Plan_mRiLCVehCrosLnLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mrilcvehmetlnlatdst_mp(
    static_cast<float>(Mtn_Plan_mRiLCVehMetLnLatDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mrilanechgegolanewdth_mp(
    static_cast<float>(Mtn_Plan_mRiLaneChgEgoLaneWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mrilanewdth_mp(static_cast<float>(Mtn_Plan_mRiLaneWdth_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_msiderrrangeest4zone11_mp(
    static_cast<float>(Mtn_Plan_mSideRrRangeEst4Zone11_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_msiderrrangeest4zone13_mp(
    static_cast<float>(Mtn_Plan_mSideRrRangeEst4Zone13_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_msiderrrangeest4zone1_mp(
    static_cast<float>(Mtn_Plan_mSideRrRangeEst4Zone1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_msiderrrangeest4zone3_mp(
    static_cast<float>(Mtn_Plan_mSideRrRangeEst4Zone3_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mtranscrsglnrefc0hld_mp(
    static_cast<float>(Mtn_Plan_mTransCrsgLnRefC0Hld_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mvcsorigins_mp(static_cast<float>(Mtn_Plan_mVCSOriginS_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssbeflnchgavglatacce_mp(
    static_cast<float>(Mtn_Plan_mpssBefLnChgAvgLatAcce_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsslatplanavglatacce_mp(
    static_cast<float>(Mtn_Plan_mpssLatPlanAvgLatAcce_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpsstransmaxlatacc_mp(
    static_cast<float>(Mtn_Plan_mpssTransMaxLatAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssvehnotovegolnminacc_mp(
    static_cast<float>(Mtn_Plan_mpssVehNotOvEgoLnMinAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssvehnotovlelnminacc_mp(
    static_cast<float>(Mtn_Plan_mpssVehNotOvLeLnMinAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssvehnotovreflnleznminacc_mp(
    static_cast<float>(Mtn_Plan_mpssVehNotOvRefLnLeZnMinAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssvehnotovreflnriznminacc_mp(
    static_cast<float>(Mtn_Plan_mpssVehNotOvRefLnRiZnMinAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_mpssvehnotovrilnminacc_mp(
    static_cast<float>(Mtn_Plan_mpssVehNotOvRiLnMinAcc_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_numlcpolyfiterrnum_mp(
    static_cast<uint32_t>(Mtn_Plan_numLCPolyFitErrNum_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_pctlatplanpathexcutpct_mp(
    static_cast<float>(Mtn_Plan_pctLatPlanPathExcutPct_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_secfrenethldtime_mp(
    static_cast<float>(Mtn_Plan_secFrenetHldTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_secfrntlnchgcroslntime_mp(
    static_cast<float>(Mtn_Plan_secFrntLnChgCrosLnTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_secfrntlnchgtotaltime_mp(
    static_cast<float>(Mtn_Plan_secFrntLnChgTotalTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_seclatplanmaxlatvtm_mp(
    static_cast<float>(Mtn_Plan_secLatPlanMaxLatVTm_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stchglanests_mp(static_cast<uint32_t>(Mtn_Plan_stChgLaneSts_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stlanechgreflinemode_mp(
    static_cast<uint32_t>(Mtn_Plan_stLaneChgRefLineMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stlonglatctrlmode_mp(
    static_cast<uint32_t>(Mtn_Plan_stLongLatCtrlMode_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_stnopzoneid_mp(static_cast<uint32_t>(Mtn_Plan_stNOPZoneID_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_sttrnststs_mp(static_cast<uint32_t>(Mtn_Plan_stTrnstSts_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilatpathfitbeginpnttime_mp(
    static_cast<float>(Mtn_Plan_tiLatPathFitBeginPntTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilatpathgnrttimedst_mp(
    static_cast<float>(Mtn_Plan_tiLatPathGnrtTimeDst_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcaltime_mp(static_cast<float>(Mtn_Plan_tiLcaLTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcalelctime_mp(static_cast<float>(Mtn_Plan_tiLcaLeLCTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tilcarilctime_mp(static_cast<float>(Mtn_Plan_tiLcaRiLCTime_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tipnttimedstforctrlc0c1_mp(
    static_cast<float>(Mtn_Plan_tiPntTimeDstForCtrlC0C1_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_tipnttimedstforctrlc2_mp(
    static_cast<float>(Mtn_Plan_tiPntTimeDstForCtrlC2_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_titrans2egolaneplant_mp(
    static_cast<float>(Mtn_Plan_tiTrans2EgoLanePlanT_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_utrnstvehcdn_mp(static_cast<uint32_t>(Mtn_Plan_uTrnstVehCdn_mp));
  fct_debug_out.mutable_mtn_debug_out()->set_mtn_plan_xreflnc2jump_mp(static_cast<float>(Mtn_Plan_xRefLnC2Jump_mp));
}

void ldw_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_algtlacc_mp(static_cast<float>(LDW_aLgtlAcc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_altrlacc_mp(static_cast<float>(LDW_aLtrlAcc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfbcuactv_mp(static_cast<uint32_t>(LDW_bfBCUActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfladetqlraw_mp(static_cast<uint32_t>(LDW_bfLaDetQlRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfladetql_mp(static_cast<uint32_t>(LDW_bfLaDetQl_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bflosscommfaultinhib_mp(
    static_cast<uint32_t>(LDW_bfLossCommFaultInhib_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfsensactrfaultinhib_mp(
    static_cast<uint32_t>(LDW_bfSensActrFaultInhib_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfsigerrfaultinhib_mp(
    static_cast<uint32_t>(LDW_bfSigErrFaultInhib_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_bfspecsprs_mp(static_cast<uint32_t>(LDW_bfSpecSprs_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_dphistrngwhlagspd_mp(static_cast<float>(LDW_dphiStrngWhlAgSpd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_dphiyawrate_mp(static_cast<float>(LDW_dphiYawRate_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgabsactv_mp(static_cast<bool>(LDW_flgABSActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgacm02datainvld_mp(static_cast<bool>(LDW_flgACM02DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgacm03datainvld_mp(static_cast<bool>(LDW_flgACM03DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgacmcommlost_mp(static_cast<bool>(LDW_flgACMCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgadcsysvldout_mp(static_cast<bool>(LDW_flgADCSysVldOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgaccpdlactposninvld_mp(
    static_cast<bool>(LDW_flgAccPdlActPosnInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgactrstsprs_mp(static_cast<bool>(LDW_flgActrStSprs_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgasimovfault_mp(static_cast<bool>(LDW_flgAsimovFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgautobrkgactv_mp(static_cast<bool>(LDW_flgAutoBrkgActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgautofixoutofcal_mp(static_cast<bool>(LDW_flgAutofixOutOfCal_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbcmcommlost_mp(static_cast<bool>(LDW_flgBCMCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbcu04datainvld_mp(static_cast<bool>(LDW_flgBCU04DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbcucommlost_mp(static_cast<bool>(LDW_flgBCUCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbcuoff_mp(static_cast<bool>(LDW_flgBCUOff_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgblurredimage_mp(static_cast<bool>(LDW_flgBlurredImage_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbrkpdlinvld_mp(static_cast<bool>(LDW_flgBrkPdlInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgbrkprssinvld_mp(static_cast<bool>(LDW_flgBrkPrssInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcdccommlost_mp(static_cast<bool>(LDW_flgCDCCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcdchu03datainvld_mp(static_cast<bool>(LDW_flgCDCHU03DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcdclosscommadasfault_mp(
    static_cast<bool>(LDW_flgCDCLossCommADASFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcdclosscommchsfault_mp(
    static_cast<bool>(LDW_flgCDCLossCommCHSFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcgwcommlost_mp(static_cast<bool>(LDW_flgCGWCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgcmrblk_mp(static_cast<bool>(LDW_flgCmrBlk_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgdashandoff_mp(static_cast<bool>(LDW_flgDASHandOff_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeps01datainvld_mp(static_cast<bool>(LDW_flgEPS01DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeps02datainvld_mp(static_cast<bool>(LDW_flgEPS02DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepsactvextifinvld_mp(
    static_cast<bool>(LDW_flgEPSActvExtIfInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepscommlost_mp(static_cast<bool>(LDW_flgEPSCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepsdrvoverridedetnsna_mp(
    static_cast<bool>(LDW_flgEPSDrvOverRideDetnSna_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepserr_mp(static_cast<bool>(LDW_flgEPSErr_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepshiavl_mp(static_cast<bool>(LDW_flgEPSHIAvl_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepsinvld_mp(static_cast<bool>(LDW_flgEPSInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepspinionaginvld_mp(static_cast<bool>(LDW_flgEPSPinionAgInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgepstrsnbartrqinvld_mp(
    static_cast<bool>(LDW_flgEPSTrsnBarTrqInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeq4commlost_mp(static_cast<bool>(LDW_flgEQ4CommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeq4coredump_mp(static_cast<bool>(LDW_flgEQ4Coredump_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeq4nonrecoverablefault_mp(
    static_cast<bool>(LDW_flgEQ4NonRecoverableFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgeq4recoverablefault_mp(
    static_cast<bool>(LDW_flgEQ4RecoverableFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgfrmwrdsbl_mp(static_cast<bool>(LDW_flgFrmwrDsbl_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgfrznwindshld_mp(static_cast<bool>(LDW_flgFrznWindshld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flggearinvld_mp(static_cast<bool>(LDW_flgGearInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flghiactravl_mp(static_cast<bool>(LDW_flgHIActrAvl_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flghmiadasfail_mp(static_cast<bool>(LDW_flgHMIADASFail_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flghmifail_mp(static_cast<bool>(LDW_flgHMIFail_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flghapticreqactv_mp(static_cast<bool>(LDW_flgHapticReqActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flginnewleftzone_mp(static_cast<bool>(LDW_flgInNewLeftZone_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flginnewrightzone_mp(static_cast<bool>(LDW_flgInNewRightZone_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglaasstactileonoffinvld_mp(
    static_cast<bool>(LDW_flgLaAssTactileOnOffInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglaneassthapticonoffstsout_mp(
    static_cast<bool>(LDW_flgLaneAsstHapticOnOffStsOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglataccvalinvld_mp(static_cast<bool>(LDW_flgLatAccValInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgldwcfgbyuds_mp(static_cast<bool>(LDW_flgLdwCfgByUDS_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgldwselsts_mp(static_cast<bool>(LDW_flgLdwSelSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgldwswtsts_mp(static_cast<bool>(LDW_flgLdwSwtSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleturnindcrliinvld_mp(
    static_cast<bool>(LDW_flgLeTurnIndcrLiInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftfrntwhlinleftwarnzone_mp(
    static_cast<bool>(LDW_flgLeftFrntWhlInLeftWarnZone_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftlanecrsgcalc_mp(static_cast<bool>(LDW_flgLeftLaneCrsgCalc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftlanecrsgraw_mp(static_cast<bool>(LDW_flgLeftLaneCrsgRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftlanecrsg_mp(static_cast<bool>(LDW_flgLeftLaneCrsg_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftlanevld_mp(static_cast<bool>(LDW_flgLeftLaneVld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgleftturndtctd_mp(static_cast<bool>(LDW_flgLeftTurnDtctd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglkacfgbyuds_mp(static_cast<bool>(LDW_flgLkaCfgByUDS_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglksdndbysigcndt_mp(static_cast<bool>(LDW_flgLksDndBySigCndt_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglksenabyvehsts_mp(static_cast<bool>(LDW_flgLksEnaByVehSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglonaccvalinvld_mp(static_cast<bool>(LDW_flgLonAccValInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flglowsun_mp(static_cast<bool>(LDW_flgLowSun_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgmultlanemarkdctd_mp(static_cast<bool>(LDW_flgMultLaneMarkDctd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgoutfocus_mp(static_cast<bool>(LDW_flgOutFocus_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrain_mp(static_cast<bool>(LDW_flgRain_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgriturnindcrliinvld_mp(
    static_cast<bool>(LDW_flgRiTurnIndcrLiInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightfrntwhlinrightwarnzone_mp(
    static_cast<bool>(LDW_flgRightFrntWhlInRightWarnZone_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightlanecrsgcalc_mp(
    static_cast<bool>(LDW_flgRightLaneCrsgCalc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightlanecrsgraw_mp(static_cast<bool>(LDW_flgRightLaneCrsgRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightlanecrsg_mp(static_cast<bool>(LDW_flgRightLaneCrsg_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightlanevld_mp(static_cast<bool>(LDW_flgRightLaneVld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgrightturndtctd_mp(static_cast<bool>(LDW_flgRightTurnDtctd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgscm01datainvld_mp(static_cast<bool>(LDW_flgSCM01DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgscmcommlost_mp(static_cast<bool>(LDW_flgSCMCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgscmfail_mp(static_cast<bool>(LDW_flgSCMFail_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgseatoccpfrntlefailure_mp(
    static_cast<bool>(LDW_flgSeatOccpFrntLeFailure_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgseatoccpfrntleinvld_mp(
    static_cast<bool>(LDW_flgSeatOccpFrntLeInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgsetlaneassiaidtypinvld_mp(
    static_cast<bool>(LDW_flgSetLaneAssiAidTypInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgsetlaneassisnvtyinvld_mp(
    static_cast<bool>(LDW_flgSetLaneAssiSnvtyInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgsplsh_mp(static_cast<bool>(LDW_flgSplsh_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgstrngwhlagsnsrfail_mp(
    static_cast<bool>(LDW_flgStrngWhlAgSnsrFail_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgstrngwhlagsnsrnotcal_mp(
    static_cast<bool>(LDW_flgStrngWhlAgSnsrNotCal_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgstrngwhlagspdinvld_mp(
    static_cast<bool>(LDW_flgStrngWhlAgSpdInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgsunray_mp(static_cast<bool>(LDW_flgSunRay_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgtcsactv_mp(static_cast<bool>(LDW_flgTCSActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgtsroutofcalmode_mp(static_cast<bool>(LDW_flgTSROutOfCalMode_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgturnindctrswtinvld_mp(
    static_cast<bool>(LDW_flgTurnIndctrSwtInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flguselanemodel_mp(static_cast<bool>(LDW_flgUseLaneModel_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvcu02datainvld_mp(static_cast<bool>(LDW_flgVCU02DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvcu05datainvld_mp(static_cast<bool>(LDW_flgVCU05DataInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvcucommlost_mp(static_cast<bool>(LDW_flgVCUCommLost_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvdcactv_mp(static_cast<bool>(LDW_flgVDCActv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvdctcslmpinfo_mp(static_cast<bool>(LDW_flgVDCTCSLmpInfo_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvehoutoflane_mp(static_cast<bool>(LDW_flgVehOutOfLane_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvehspdinvld_mp(static_cast<bool>(LDW_flgVehSpdInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgvehstinvld_mp(static_cast<bool>(LDW_flgVehStInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_flgyawrateinvld_mp(static_cast<bool>(LDW_flgYawrateInvld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_legolawdthraw_mp(static_cast<float>(LDW_lEgoLaWdthRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_legolawdth_mp(static_cast<float>(LDW_lEgoLaWdth_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_linrleftzonebrdhysshft_mp(
    static_cast<float>(LDW_lInrLeftZoneBrdHysShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_linrrightzonebrdhysshft_mp(
    static_cast<float>(LDW_lInrRightZoneBrdHysShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_linrzonebrdlanewdthshft_mp(
    static_cast<float>(LDW_lInrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_llelinedstout_mp(static_cast<float>(LDW_lLeLineDstOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lleftinrzonebrd_mp(static_cast<float>(LDW_lLeftInrZoneBrd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lleftlanec0_mp(static_cast<float>(LDW_lLeftLaneC0_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lleftoutrzonebrd_mp(static_cast<float>(LDW_lLeftOutrZoneBrd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lleftzonebrdactltrlaccshft_mp(
    static_cast<float>(LDW_lLeftZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lleftzonebrdactltrlvelshft_mp(
    static_cast<float>(LDW_lLeftZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstlacntr2vehcntrraw_mp(
    static_cast<float>(LDW_lLtrlDstLaCntr2VehCntrRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstlacntr2vehcntr_mp(
    static_cast<float>(LDW_lLtrlDstLaCntr2VehCntr_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstleftla2vehcntrraw_mp(
    static_cast<float>(LDW_lLtrlDstLeftLa2VehCntrRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstleftla2vehcntr_mp(
    static_cast<float>(LDW_lLtrlDstLeftLa2VehCntr_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstrightla2vehcntrraw_mp(
    static_cast<float>(LDW_lLtrlDstRightLa2VehCntrRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lltrldstrightla2vehcntr_mp(
    static_cast<float>(LDW_lLtrlDstRightLa2VehCntr_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_loutrzonebrdhysshft_mp(static_cast<float>(LDW_lOutrZoneBrdHysShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_loutrzonebrdlanewdthshft_mp(
    static_cast<float>(LDW_lOutrZoneBrdLaneWdthShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrilinedstout_mp(static_cast<float>(LDW_lRiLineDstOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrightinrzonebrd_mp(static_cast<float>(LDW_lRightInrZoneBrd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrightlanec0_mp(static_cast<float>(LDW_lRightLaneC0_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrightoutrzonebrd_mp(static_cast<float>(LDW_lRightOutrZoneBrd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrightzonebrdactltrlaccshft_mp(
    static_cast<float>(LDW_lRightZoneBrdActLtrlAccShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lrightzonebrdactltrlvelshft_mp(
    static_cast<float>(LDW_lRightZoneBrdActLtrlVelShft_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lvirtdstleline2vehcenter_mp(
    static_cast<float>(LDW_lVirtDstLeLine2VehCenter_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_lvirtdstriline2vehcenter_mp(
    static_cast<float>(LDW_lVirtDstRiLine2VehCenter_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_pbrkpres_mp(static_cast<float>(LDW_pBrkPres_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_pctaccpedal_mp(static_cast<float>(LDW_pctAccPedal_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_pctleftlaneconf_mp(static_cast<float>(LDW_pctLeftLaneConf_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_pctrightlaneconf_mp(static_cast<float>(LDW_pctRightLaneConf_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2lanecntrraw_mp(
    static_cast<float>(LDW_phiAgVeh2LaneCntrRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2lanecntr_mp(static_cast<float>(LDW_phiAgVeh2LaneCntr_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2leftlaneraw_mp(
    static_cast<float>(LDW_phiAgVeh2LeftLaneRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2leftlane_mp(static_cast<float>(LDW_phiAgVeh2LeftLane_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2rightlaneraw_mp(
    static_cast<float>(LDW_phiAgVeh2RightLaneRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phiagveh2rightlane_mp(static_cast<float>(LDW_phiAgVeh2RightLane_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phicurrstrngwhlag_mp(static_cast<float>(LDW_phiCurrStrngWhlAg_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phileftlanec1_mp(static_cast<float>(LDW_phiLeftLaneC1_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_phirightlanec1_mp(static_cast<float>(LDW_phiRightLaneC1_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_staccnpsts_mp(static_cast<uint32_t>(LDW_stAccNpSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stactgear_mp(static_cast<uint32_t>(LDW_stActGear_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stactvextifc_mp(static_cast<uint32_t>(LDW_stActvExtIfc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stadaslelineout_mp(static_cast<uint32_t>(LDW_stAdasLeLineOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stadasrilineout_mp(static_cast<uint32_t>(LDW_stAdasRiLineOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_staxayyrscalsts_mp(static_cast<uint32_t>(LDW_stAxAyYrsCalSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stbcubrkswt_mp(static_cast<uint32_t>(LDW_stBCUBrkSwt_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stcdcsetlaneassiaidtyp_mp(
    static_cast<uint32_t>(LDW_stCDCSetLaneAssiAidTyp_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stepsdrvoverridedetn_mp(
    static_cast<uint32_t>(LDW_stEPSDrvOverRideDetn_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stepsdrvtrqvld_mp(static_cast<uint32_t>(LDW_stEPSDrvTrqVld_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stepsreqtypout_mp(static_cast<uint32_t>(LDW_stEPSReqTypOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stepssts_mp(static_cast<uint32_t>(LDW_stEPSSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stfault_mp(static_cast<uint32_t>(LDW_stFault_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlaneasstsnvty_mp(static_cast<uint32_t>(LDW_stLaneAsstSnvty_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlaneasstst_mp(static_cast<uint32_t>(LDW_stLaneAsstSt_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlaneasststsout_mp(static_cast<uint32_t>(LDW_stLaneAsstStsOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlaneassttactileonoff_mp(
    static_cast<uint32_t>(LDW_stLaneAsstTactileOnOff_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlaneassttypout_mp(static_cast<uint32_t>(LDW_stLaneAsstTypOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlanecaseraw_mp(static_cast<uint32_t>(LDW_stLaneCaseRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlanecase_mp(static_cast<uint32_t>(LDW_stLaneCase_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stldwintsts_mp(static_cast<uint32_t>(LDW_stLdwIntSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlelanetyp_mp(static_cast<uint32_t>(LDW_stLeLaneTyp_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stlelinetypout_mp(static_cast<uint32_t>(LDW_stLeLineTypOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stleftprdsrc_mp(static_cast<uint32_t>(LDW_stLeftPrdSrc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stleftturnidctrlghtsts_mp(
    static_cast<uint32_t>(LDW_stLeftTurnIdctrLghtSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_strilanetyp_mp(static_cast<uint32_t>(LDW_stRiLaneTyp_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_strilinetypout_mp(static_cast<uint32_t>(LDW_stRiLineTypOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_strightprdsrc_mp(static_cast<uint32_t>(LDW_stRightPrdSrc_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_strightturnidctrlghtsts_mp(
    static_cast<uint32_t>(LDW_stRightTurnIdctrLghtSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stseatoccupantflsts_mp(
    static_cast<uint32_t>(LDW_stSeatOccupantFLSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stsnvtyout_mp(static_cast<uint32_t>(LDW_stSnvtyOut_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stspecsprs_mp(static_cast<uint32_t>(LDW_stSpecSprs_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stturnidctrswt_mp(static_cast<uint32_t>(LDW_stTurnIdctrSwt_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stvehlataccsts_mp(static_cast<uint32_t>(LDW_stVehLatAccSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stvehlongaccsts_mp(static_cast<uint32_t>(LDW_stVehLongAccSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stvehst_mp(static_cast<uint32_t>(LDW_stVehSt_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_stwarnzone_mp(static_cast<uint32_t>(LDW_stWarnZone_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_styawratests_mp(static_cast<uint32_t>(LDW_stYawRateSts_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_trqepsmotortq_mp(static_cast<float>(LDW_trqEPSMotorTq_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_trqtrsnbartrq_mp(static_cast<float>(LDW_trqTrsnbarTrq_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_vvehdispspdceil_mp(static_cast<float>(LDW_vVehDispSpdCeil_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_vvehdispspd_mp(static_cast<float>(LDW_vVehDispSpd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_vvehspd_mp(static_cast<float>(LDW_vVehSpd_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xlacurvraw_mp(static_cast<float>(LDW_xLaCurvRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xlacurv_mp(static_cast<float>(LDW_xLaCurv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xladcurvraw_mp(static_cast<float>(LDW_xLadCurvRaw_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xladcurv_mp(static_cast<float>(LDW_xLadCurv_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xleftlanec2_mp(static_cast<float>(LDW_xLeftLaneC2_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xleftlanec3_mp(static_cast<float>(LDW_xLeftLaneC3_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xrightlanec2_mp(static_cast<float>(LDW_xRightLaneC2_mp));
  fct_debug_out.mutable_ldw_debug_out()->set_ldw_xrightlanec3_mp(static_cast<float>(LDW_xRightLaneC3_mp));
}

void lka_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {}

void me_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_role_mp(static_cast<double>(ME_LeftLine_Role_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_c0_mp(static_cast<double>(ME_LeftLine_C0_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_c1_mp(static_cast<double>(ME_LeftLine_C1_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_c2_mp(static_cast<double>(ME_LeftLine_C2_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_c3_mp(static_cast<double>(ME_LeftLine_C3_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_start_mp(static_cast<double>(ME_LeftLine_start_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_end_mp(static_cast<double>(ME_LeftLine_end_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_leftline_conf_mp(static_cast<double>(ME_LeftLine_conf_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_role_mp(static_cast<double>(ME_RightLine_Role_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_c0_mp(static_cast<double>(ME_RightLine_C0_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_c1_mp(static_cast<double>(ME_RightLine_C1_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_c2_mp(static_cast<double>(ME_RightLine_C2_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_c3_mp(static_cast<double>(ME_RightLine_C3_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_start_mp(static_cast<double>(ME_RightLine_start_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_end_mp(static_cast<double>(ME_RightLine_end_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_rightline_conf_mp(static_cast<double>(ME_RightLine_conf_mp));
  fct_debug_out.mutable_me_debug_out()->set_me_lanewidth_mp(static_cast<double>(ME_LaneWidth_mp));
}

void reserved_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out, APP_state_e APP_state,
                   std::shared_ptr<planner::IOAdapter>& ioadapter) {
  fct_debug_out.mutable_debug_reserved()->set_reserved_0(
    static_cast<double>(fct_diag_interface.is_vehicle_input_loss_comm));
  fct_debug_out.mutable_debug_reserved()->set_reserved_1(static_cast<double>(fct_diag_interface.is_ehy_traj_loss_comm));
  fct_debug_out.mutable_debug_reserved()->set_reserved_2(
    static_cast<double>(fct_diag_interface.is_ehy_target_loss_comm));
  fct_debug_out.mutable_debug_reserved()->set_reserved_3(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar0.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_4(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar0.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_5(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar1.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_6(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar1.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_7(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar2.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_8(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar2.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_9(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar3.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_10(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar3.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_11(static_cast<double>(gAHCFaultSt));
  fct_debug_out.mutable_debug_reserved()->set_reserved_12(static_cast<double>(gFctTopicNoInit));
  fct_debug_out.mutable_debug_reserved()->set_reserved_13(static_cast<double>(gFctTopicLoss));
  fct_debug_out.mutable_debug_reserved()->set_reserved_14(static_cast<double>(APP_state));
  fct_debug_out.mutable_debug_reserved()->set_reserved_15(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar4.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_16(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar4.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_17(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar5.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_18(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar5.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_19(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar6.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_20(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar6.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_21(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar7.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_22(static_cast<double>(LKS_LCA_out.ALCEsdInfo.Tar7.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_23(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar0.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_24(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar0.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_25(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar1.TarIndex));

  fct_debug_out.mutable_debug_reserved()->set_reserved_26(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar1.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_27(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar2.TarIndex));

  fct_debug_out.mutable_debug_reserved()->set_reserved_28(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar2.TarLevel));
  fct_debug_out.mutable_debug_reserved()->set_reserved_29(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar3.TarIndex));
  fct_debug_out.mutable_debug_reserved()->set_reserved_30(
    static_cast<double>(HWA_out.LNGCTRL.EsdTarInfo.Tar3.TarLevel));
  // fct_debug_out.mutable_debug_reserved()->set_reserved_31(static_cast<double>(LatCtrl_bfLCARiSprsMask_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_32(static_cast<double>(LatCtrl_mNOPLatError_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_33(static_cast<double>(ACCCT_bfLongCtrlACCSrc_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_34(static_cast<bool>(vision_road.lane.eu_construction_area_flag));

  fct_debug_out.mutable_debug_reserved()->set_reserved_40(static_cast<double>(gFWFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_41(static_cast<double>(gFNFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_42(static_cast<double>(gLidarFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_43(static_cast<double>(gFLFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_44(static_cast<double>(gFRFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_45(static_cast<double>(gRrFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_46(static_cast<double>(gRLFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_47(static_cast<double>(gRRFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_48(static_cast<double>(gSVCFtFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_49(static_cast<double>(gSVCRrFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_50(static_cast<double>(gSVCLftFailsafe.high));
  fct_debug_out.mutable_debug_reserved()->set_reserved_51(static_cast<double>(gSVCRgtFailsafe.high));

  fct_debug_out.mutable_debug_reserved()->set_reserved_52(static_cast<uint32_t>(LatCtrl_flgElkShadowMode_C));
  fct_debug_out.mutable_debug_reserved()->set_reserved_53(static_cast<double>(LatCtrl_steeringtrqreq_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_54(static_cast<uint16_t>(LatCtrl_flgleftlaneconstruction_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_55(static_cast<uint16_t>(LatCtrl_flgrightlaneconstruction_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_56(static_cast<uint16_t>(LatCtrl_flgstructionwti_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_57(static_cast<uint16_t>(LatCtrl_construction_wti_cnt_mp));

  fct_debug_out.mutable_debug_reserved()->set_reserved_62(static_cast<double>(LatCtrl_Elk_stActvShftDtctd_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_63(static_cast<double>(ACCSC_flgAutoSetSpdTri_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_64(static_cast<double>(ACCSC_flgCancelAutoSetSpd_mp));
  // fct_debug_out.mutable_debug_reserved()->set_reserved_65(static_cast<double>(ACCSC_TSRSetSpdCUpdateCndn1_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_66(static_cast<double>(ACCSC_kphStartSetSpeed_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_67(static_cast<double>(ACCSC_kphSetSpeedTar_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_68(static_cast<double>(ACCSC_stTauGapChgDispOut_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_69(static_cast<double>(ACCSA_numFAM_ID10_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_70(static_cast<double>(ACCSA_stFAM_Req10_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_71(static_cast<double>(ACCSC_flgDrvPrsDAResumeBtn_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_72(static_cast<double>(ACCSC_flgResmDrvrDeactv_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_73(static_cast<double>(fct_diag_interface.is_vision_no_ready));
  fct_debug_out.mutable_debug_reserved()->set_reserved_74(static_cast<double>(FctAppRunTime));
  fct_debug_out.mutable_debug_reserved()->set_reserved_75(fct_fim.da_np_fim.is_DaAdClassified_fault);
  fct_debug_out.mutable_debug_reserved()->set_reserved_76(fct_fim.da_np_fim.is_DaTdClassified_fault);
  fct_debug_out.mutable_debug_reserved()->set_reserved_77(fct_fim.da_np_fim.is_DaEasClassified_fault);
  // fct_debug_out.mutable_debug_reserved()->set_reserved_78(static_cast<bool>(LatCtrl_isadasmapValid_mp));
  // fct_debug_out.mutable_debug_reserved()->set_reserved_79(static_cast<uint8_t>(LatCtrl_stadasmapHighway_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_80(static_cast<uint8_t>(ACCSA_reliable_state_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_81(static_cast<uint8_t>(ACCSA_nabigation_state_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_82(static_cast<uint8_t>(ACCSA_nop_turn_indicator_req_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_83(static_cast<uint32_t>(ACCSA_nop_spdlmt_value_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_84(static_cast<uint8_t>(0));
  fct_debug_out.mutable_debug_reserved()->set_reserved_85(
    static_cast<double>(ACCSA_nop_freespaceintrusionatstandstill_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_86(static_cast<uint16_t>(LKS_LCA_out.ALCSwti));
  fct_debug_out.mutable_debug_reserved()->set_reserved_87(static_cast<uint8_t>(HWASM_stZoneOut_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_88(static_cast<float>(LatCtrl_Elk_RdEdgConf_0_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_89(static_cast<float>(LatCtrl_Elk_RdEdgConf_1_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_90(static_cast<uint8_t>(LKS_LCA_out.SasLocalHzrdsEUCA));
  fct_debug_out.mutable_debug_reserved()->set_reserved_91(static_cast<uint8_t>(LatCtrl_Elk_RdEdgSide_1_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_92(static_cast<float>(LatCtrl_Elk_RdEdgC0_0_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_93(static_cast<float>(LatCtrl_Elk_RdEdgC0_1_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_94(ACCSC_flgSwPilot_mp);
  fct_debug_out.mutable_debug_reserved()->set_reserved_95(LatCtrl_vLCAActvMinVehSpd_C);
  fct_debug_out.mutable_debug_reserved()->set_reserved_96(static_cast<double>(gLkaFaultSt));
  fct_debug_out.mutable_debug_reserved()->set_reserved_97(static_cast<double>(LNCH_stDAMainReqFuncID_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_98(static_cast<double>(LatCtrl_bfLCAODDSprsMask_mp));
  fct_debug_out.mutable_debug_reserved()->set_reserved_99(static_cast<double>(LatCtrl_flgALCSODDSprs_mp));
  if (nullptr != ioadapter) {
    speed_debug_info = ioadapter->getMidOutputManager().getSpeedDebugInfo();
    tau_gap_out      = ioadapter->getMidOutputManager().getTauGapProcessOut();
    sm_debug_info    = ioadapter->getMidOutputManager().getSmDebugInfo();
  }
  fct_debug_out.mutable_reserved()->Clear();
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_nop_freeSpace_intrusion_go_notifier_mp));  // 0
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_nop_long_ctrl_tar_mp));                  // 1
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_nop_lat_ctrl_tarRi_mp));                 // 2
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_nop_lat_ctrl_tarLe_mp));                 // 3
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_nop_colllision_risk_mp));                  // 4
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_stFAM_Req7_mp));                          // 5
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_numFAM_ID7_mp));                         // 6
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uNOPActivationPrevention_mp));           // 7
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uNOPSuppression_mp));                    // 8
  fct_debug_out.add_reserved(static_cast<bool>(LatCtrl_flgDA_StrongSteering_mp));                 // 9
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgVMCLgtSts_mp));                           // 10
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgDMSOccluded_mp));                         // 11
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgAEBPrewarnreq_mp));                       // 12
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uActPrev2_mp));                          // 13
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgAAappFimTD_mp));                          // 14
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgAAappFimAD_mp));                          // 15
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgCloudOffNOP_mp));                         // 16
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_flgAAappFaultInstOff_mp));                   // 17
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_uVMCLgtSts_mp));                          // 18
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_uFCC1LgtSts_mp));                         // 19
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_aVMCLgtDecCp_mp));                         // 20
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_aVMCLgtAccCp_mp));                         // 21
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_GPDistanceSource_mp));                     // 22
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_RecomSpeedSrcSource_mp));                  // 23
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_flgNop2NpUpdtSpd_mp));                     // 24
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_TSE1FusionSts_mp));                       // 25
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_TSE1Status_mp));                          // 26
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_TSE1Type_mp));                            // 27
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_TSE1ageTarInPath_mp));                   // 28
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_TSE1LongAcc_mp));                          // 29
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_TSE1Range_mp));                            // 30
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_bfMaskLwrJrkLimEnbCdn_mp));                // 31
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_facLowerJerkLimEnbFac_mp));                // 32
  fct_debug_out.add_reserved(static_cast<double>(ACCCT_mpssFuzzyAccelReqbfSdCutIn_mp));           // 33
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DAWTISPre_mp));                           // 34
  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_isDATopicFault_mp));                         // 35
  fct_debug_out.add_reserved(static_cast<bool>(LatCtrl_Lks_IntFadeActvRst_mp));                   // 36
  fct_debug_out.add_reserved(static_cast<bool>(LatCtrl_Lks_IntFadeActvRst1_mp));                  // 37
  fct_debug_out.add_reserved(static_cast<bool>(LatCtrl_Lks_IntFadeActvRst2_mp));                  // 38
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmLeLineC2AimPointDelay1_mp));             // 39
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmLeLineC2AimPointDelay2_mp));             // 40
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmLeLineC2AimPointDelay3_mp));             // 41
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmLeLineC2AimPointDelay4_mp));             // 42
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmLeLineC2AimPointDelay5_mp));             // 43
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmRiLineC2AimPointDelay0_mp));             // 44
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmRiLineC2AimPointDelay1_mp));             // 45
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmRiLineC2AimPointDelay2_mp));             // 46
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmRiLineC2AimPointDelay3_mp));             // 47
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_pmRiLineC2AimPointDelay4_mp));             // 48
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC1_mp));                          // 49
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC2_mp));                          // 50
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC3_mp));                          // 51
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC1_mp));                          // 52
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC2_mp));                          // 53
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_CamLeLaneC3_mp));                          // 54
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_eleeye_spdlmtC_mp));                 // 55
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_advisory_spdlmtC_mp));               // 56
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_legal_spdlmtC_mp));                  // 57
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_eleeye_spdlmtN_mp));                 // 58
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_advisory_spdlmtN_mp));               // 59
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_legal_spdlmtN_mp));                  // 60
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSA_nop_dist_to_next_mp));                   // 61
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_roadtypeC_mp));                      // 62
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_roadtypeN_mp));                      // 63
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_nop_reserved_mp));                       // 64
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_iACC_SpdLimC_mp));                       // 65
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_SAS_SpdLimC_mp));                        // 66
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_SAS_SpdLimN_mp));                        // 67
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSC_SAS_SpdLimDistN_mp));                    // 68
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSA_SetSpdOffs_mp));                         // 69
  fct_debug_out.add_reserved(static_cast<int32_t>(ACCSA_SetSpdOffsValue_mp));                     // 70
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_u8CfgTaskMgrSts_mp));                     // 71
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_flgSetspdOffsUpdt_mp));                 // 72
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCCT_stSetspeedChgSrcForNop_mp));            // 73
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_IsSimulationOpen_mp));                  // 74
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_isDANADStsEx_mp));                      // 75
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DANADStsEx_mp));                          // 76
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_SetSpdDisp_mp));                          // 77
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_TauGapSetEx_mp));                         // 78
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DisplaySetSpdEx_mp));                     // 79
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_LogsimFlagEx_mp));                        // 80
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_EpsPinionAg_mp));                        // 81
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_EpsGearRatio_mp));                       // 82
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_trigger_ramp_pre_dec));        // 83
  fct_debug_out.add_reserved(static_cast<uint64_t>(speed_debug_info.ramp_pre_dec_lane_id));       // 84
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_flgUseDfltTauGap_mp));                  // 85
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DANOPAvl_mp));                            // 86
  fct_debug_out.add_reserved(static_cast<double>(speed_debug_info.decl_distance));                // 87
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_kphRainModeSpdLmtVlu_mp));                 // 88
  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->getLocalMapLargeCurvature()));   // 89
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->getLocalMapMaxCurvature()));     // 90
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                     // 89
    fct_debug_out.add_reserved(static_cast<double>(0));                                                       // 90
  }
  fct_debug_out.add_reserved(static_cast<double>(ACCCT_stNOPRainModeOut_mp));                     // 91
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_nop_rain_mode_mp));                        // 92
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_FS_rain_mp));                              // 93
  fct_debug_out.add_reserved(static_cast<double>(ACCSA_kphVCUVehDispdSpd_mp));                    // 94
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.state_macine_debug_info));         // 95
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.standby_debug_info));              // 96
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.cruise_debug_info));               // 97
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.pilot_debug_info_pilotactv));      // 98
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.pilot_sub_actv_debug_info));       // 99
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.pilot_debug_info_lngctrl));        // 100
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_DAiACCTri_mp));                         // 101
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_DAPilotTripre_mp));                     // 102
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_DAPilotTri_mp));                        // 103
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_DANOPTripre_mp));                       // 104
  fct_debug_out.add_reserved(static_cast<boolean_T>(ACCSC_DANOPTri_mp));                          // 105
  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(
        static_cast<bool>(ioadapter->getFramePtr()->getOpenLocalMapStitchLogic()));               // 106
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                         // 106
  }
  fct_debug_out.add_reserved(static_cast<int32_t>(ACCSA_nop_req_function_mp));                    // 107
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uNOPFailSafeSup_mp));                    // 108
  fct_debug_out.add_reserved(static_cast<uint16_t>(uBitNopStatusTriggerSup));                     // 109
  fct_debug_out.add_reserved(static_cast<uint8_t>(flagNopStatusActvTigger));                      // 110
  fct_debug_out.add_reserved(static_cast<uint8_t>(flagNopStatusDectvTigger));                     // 111
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_ADCDMSDstrLvlDA_mp));                     // 112
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathSprLeCross_mp));               // 113
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathSprRiCross_mp));               // 114
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathSprState_mp));                 // 115
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathCollisionState_mp));           // 116
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_auto_setspeed_blocked));       // 117
  fct_debug_out.add_reserved(static_cast<double>(speed_debug_info.non_straight_navi_stub_id));    // 118
  fct_debug_out.add_reserved(static_cast<double>(speed_debug_info.auto_setspeed_block_debug));    // 119
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL3_mp));               // 120
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL4_mp));               // 121
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL5_mp));               // 122
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL6_mp));               // 123
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL7_mp));               // 124
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL8_mp));               // 125
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL9_mp));               // 126
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL10_mp));              // 127
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL11_mp));              // 128
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL12_mp));              // 129
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL13_mp));              // 130
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL14_mp));              // 131
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL15_mp));              // 132
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL16_mp));              // 133
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL17_mp));              // 134
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL18_mp));              // 135
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL19_mp));              // 136
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL20_mp));              // 137
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprLePointL21_mp));              // 138
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL0_mp));               // 139
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL1_mp));               // 140
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL2_mp));               // 141
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL3_mp));               // 142
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL4_mp));               // 143
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL5_mp));               // 144
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL6_mp));               // 145
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL7_mp));               // 146
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL8_mp));               // 147
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL9_mp));               // 148
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL10_mp));              // 149
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL11_mp));              // 150
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL12_mp));              // 151
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL13_mp));              // 152
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL14_mp));              // 153
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL15_mp));              // 154
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL16_mp));              // 155
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL17_mp));              // 156
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL18_mp));              // 157
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL19_mp));              // 158
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL20_mp));              // 159
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_mNOPPathSprRiPointL21_mp));              // 160
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprLeRdEdgCur_mp));             // 161
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprRiRdEdgCur_mp));             // 162
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathLeRdEdgStart_mp));             // 163
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathLeRdEdgEnd_mp));               // 164
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathRiRdEdgStart_mp));             // 165
  fct_debug_out.add_reserved(static_cast<int32_t>(LatCtrl_bfNOPPathRiRdEdgEnd_mp));               // 166
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPDistToFork_mp));                    // 167
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_blNOPPathCollsionRisk_mp));              // 168
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprAverLeRdEdgCur_mp));         // 169
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprAverRiRdEdgCur_mp));         // 170
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprLeRdEdgC3_mp));              // 171
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_bfNOPPathSprRiRdEdgC3_mp));              // 172
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_Elk_RdEdgC1_0_mp));                      // 173
  fct_debug_out.add_reserved(static_cast<double>(LatCtrl_Elk_RdEdgC1_1_mp));                      // 174

  // psp statemachine
  fct_debug_out.add_reserved(static_cast<uint32_t>(ACCSC_uBitMaskPSPActPrev_mp));                 // 175
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPCond_mp));                    // 176
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPADSoftInh_mp));                      // 177
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPTDSoftInh_mp));                      // 178
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPFimTDSoftInh1_mp));                  // 179
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPFimTDSoftInh2_mp));                  // 180
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPFimADSoftInh1_mp));                  // 181
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPFimADSoftInh2_mp));                  // 182
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uPSPHardInh_mp));                        // 183
  // statemachine psp condition
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPStandbyToSysPassive_mp));     // 184
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskSysPassiveToPSPStandby_mp));     // 185
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPStandbyToAccStandby_mp));     // 186
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPStandbyToPilotStandby_mp));   // 187
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskAccStandbyToPSPStandby_mp));     // 188
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPilotStandbyToPSPStandby_mp));   // 189
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPActiveToStandby_mp));         // 190
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPStandbyToActive_mp));         // 191
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskNOPActiveToPSPActive_mp));       // 192
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPSPActiveToNOPActive_mp));       // 193
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskAccStandbyToPilotStandby_mp));   // 194
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uBitMaskPilotStandbyToAccStandby_mp));   // 195
  fct_debug_out.add_reserved(static_cast<uint16_t>(DA_Inhibit_ForNop));                           // 196
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uActPrev_mp));                           // 197
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uActPrev1_mp));                          // 198
  fct_debug_out.add_reserved(static_cast<uint16_t>(ACCSC_uActPrev2_mp));                          // 199
  fct_debug_out.add_reserved(static_cast<uint16_t>(priority_road_class_mp));                      // 200
  fct_debug_out.add_reserved(static_cast<uint64_t>(curr_link_id_mp));                             // 201
  fct_debug_out.add_reserved(static_cast<int32_t>(is_in_map_area_mp));                            // 202
  fct_debug_out.add_reserved(static_cast<uint16_t>(nop_task_state_mp));                           // 203
  fct_debug_out.add_reserved(static_cast<uint8_t>(psp_status_mp));                                // 204
  fct_debug_out.add_reserved(static_cast<uint8_t>(np_activation_prevention_mp));                  // 205
  fct_debug_out.add_reserved(static_cast<uint8_t>(nop_status_mp));                                // 206
  fct_debug_out.add_reserved(static_cast<uint8_t>(is_planner_sts_mp));                            // 207
  fct_debug_out.add_reserved(static_cast<uint8_t>(is_nop_control_mp));                            // 208
  fct_debug_out.add_reserved(static_cast<uint16_t>(speed_debug_info.max_set_speed));                         // 209
  fct_debug_out.add_reserved(static_cast<uint16_t>(speed_debug_info.is_use_next_spd_lmt));                   // 210
  fct_debug_out.add_reserved(static_cast<uint16_t>(speed_debug_info.cdc_disp_veh_spd));                      // 211
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_up_button_press));                        // 212
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_down_button_press));                      // 213
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.up_button_trigger));                         // 214
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.down_button_trigger));                       // 215
  fct_debug_out.add_reserved(static_cast<uint8_t>(speed_debug_info.inner_speed_assist_type));                // 216
  fct_debug_out.add_reserved(static_cast<float>(speed_debug_info.user_adjust_set_speed_delta));              // 217
  fct_debug_out.add_reserved(static_cast<float>(speed_debug_info.user_set_speed));                           // 218
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.fw_fs_rain));                                // 219
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_rain_mode));                              // 220
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_iACC_topic_loss_comm));                   // 221
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_display_set_speed_enable));               // 222
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.st_iACC_take_over_demand));               // 223
  fct_debug_out.add_reserved(static_cast<int8_T>(speed_debug_info.speed_limit_diff));                        // 224
  fct_debug_out.add_reserved(static_cast<uint16_T>(speed_debug_info.mask_sas_speed_limit_update));           // 225
  fct_debug_out.add_reserved(static_cast<uint16_T>(speed_debug_info.mask_set_speed_update_request_start));   // 226
  fct_debug_out.add_reserved(static_cast<uint16_T>(speed_debug_info.mask_set_speed_update_request_reset));   // 227
  fct_debug_out.add_reserved(static_cast<uint16_T>(speed_debug_info.mask_set_speed_update_trigger));         // 228
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.flg_set_speed_update_tri));               // 229
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.sas_speed_limit_out.set_spd_animation));  // 230
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.nop_speed_source));                       // 231
  fct_debug_out.add_reserved(
    static_cast<uint8_T>(speed_debug_info.sas_speed_limit_out.sas_speed_limit_out_valid));                   // 232
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_set_speed_limit_update));                 // 233
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_up_cancel_take_over));                    // 234
  fct_debug_out.add_reserved(static_cast<bool>(speed_debug_info.is_func_actv_by_hero_trig));                 // 235
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.sw_acc_setspeed));                        // 236
  fct_debug_out.add_reserved(static_cast<uint8_T>(speed_debug_info.sw_pilot_setspeed));                      // 237
  fct_debug_out.add_reserved(static_cast<uint8_T>(tau_gap_out.tau_gap_setting));                             // 238
  fct_debug_out.add_reserved(static_cast<uint8_T>(tau_gap_out.tau_gap_display));                             // 239
  fct_debug_out.add_reserved(static_cast<bool>(tau_gap_out.tau_gap_display));                                // 240
  fct_debug_out.add_reserved(static_cast<bool>(tau_gap_out.tau_gap_inc));                                    // 241
  fct_debug_out.add_reserved(static_cast<bool>(tau_gap_out.tau_gap_dec));                                    // 242
  fct_debug_out.add_reserved(static_cast<bool>(tau_gap_out.right_button_trigger));                           // 243
  fct_debug_out.add_reserved(static_cast<bool>(tau_gap_out.left_button_trigger));                            // 244
  fct_debug_out.add_reserved(static_cast<bool>(HWA_flgNop2PilotLongOnly_mp));                                // 245
  fct_debug_out.add_reserved(static_cast<uint16_t>(psp_status_dawti_mp));                                    // 246
  //sas RFWF function
  fct_debug_out.add_reserved(static_cast<uint8_t>(sas_func_out.sas_road_feature_warn_sign));                 // 247
  fct_debug_out.add_reserved(static_cast<uint8_t>(sas_func_out.rfwf_number_warn_sign));                      // 248
  fct_debug_out.add_reserved(static_cast<uint64_t>(sas_func_out.rfwf_id_warn_sign));                         // 249
  fct_debug_out.add_reserved(static_cast<bool>(sas_func_out.rfwf_flg_has_next_warn_sign));                   // 250
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.rfwf_over_dist_warn_sign));                    // 251
  fct_debug_out.add_reserved(static_cast<boolean_T>(sas_func_out.rfwf_flg_pass_warn_sign));                  // 252
  fct_debug_out.add_reserved(static_cast<uint8_t>(sas_func_out.sas_traffic_light_sts));                      // 253
  fct_debug_out.add_reserved(static_cast<uint8_t>(sas_func_out.rfwf_number_traffic_light));                  // 254
  fct_debug_out.add_reserved(static_cast<uint64_t>(sas_func_out.rfwf_id_traffic_light));                     // 255
  fct_debug_out.add_reserved(static_cast<bool>(sas_func_out.rfwf_flg_has_next_traffic_light));               // 256
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.rfwf_over_dist_traffic_light));                // 257
  fct_debug_out.add_reserved(static_cast<boolean_T>(sas_func_out.rfwf_flg_pass_traffic_light));              // 258
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.slwf_time_eu_t1));                             // 259
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.slwf_time_eu_t4));                             // 260
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.slwf_time_eu_t3));                             // 261
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.slwf_time_eu_lv1_to_lv2_thd));                 // 262
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.slwf_is_over_cur_lmt));                        // 263
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.eu_slwf_state));                               // 264
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.is_eu_slwf_reset));                            // 265
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.is_over_lower_cur_lmt));                       // 266
  fct_debug_out.add_reserved(static_cast<double>(sas_func_out.is_acoustic_warn_blocked));                    // 267
  fct_debug_out.add_reserved(static_cast<uint8_t>(speed_debug_info.sas_speed_limit_c_value_trans));          // 268
  fct_debug_out.add_reserved(static_cast<uint8_t>(speed_debug_info.sas_speed_limit_out_value_trans));        // 269
  // //psp vlc/llc
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_uVLCLLCCdn_mp));                                     // 270
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_stVLCLLCSubSysSt_mp));                               // 271
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_NBC_TarGear_mp));                                    // 272
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_NBC_LC_ReqFct_mp));                                  // 273
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_stVLCLLCSts_mp));                                    // 274
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_stLLCShutdownModReq_mp));                            // 275
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_stLLCReqFctSt_mp));                                  // 276
  // fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSA_nop_power_task_sts_mp));
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uFailSafeADSoftInh1_mp));                           // 277
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_AccNpSts));                       // 278
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_Dummy));                          // 279
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_PilotSt));                        // 280
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_LongCtrl));                       // 281
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_LatCtrl));                        // 282
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.St_NpStsD));                         // 283
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.Ev_SwCruise));                       // 284
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.stAccTrgr));                         // 285
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.Ev_SwPilot));                        // 286
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.stPilotTrgr));                       // 287
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.isInAccMode));                       // 288
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.isInPilotMode));                     // 289
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.da_hwa_sm_op.NadSts));                         // 290
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.NadSts));                            // 291
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.ALCSsts));                           // 292
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.DAActv));                            // 293
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.DAFuncSts));                         // 294
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.DASdcSts));                          // 295
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.DALccSts));                          // 296
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.Ev_SwCruise_SetSpd));                // 297
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.hwa_sm_op.Ev_SwPilot_SetSpd));                 // 298
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.lat_ctrl_on));                                 // 299
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.da_req_func_id));                              // 300
  fct_debug_out.add_reserved(static_cast<uint16_T>(da_sm_info.dummy_da_func_sts));                           // 301
  fct_debug_out.add_reserved(static_cast<uint8_t>(nop_task_result_mp));                                      // 302
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_mCutinRisk3_mp));                                   // 303
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_mCutinRisk4_mp));                                   // 304
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_mCutinRisk5_mp));                                   // 305
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_mCutinRisk6_mp));                                   // 306
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_bfMaskTSEHardBrkEnbCdn_mp));                        // 307
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_facHardBrkLimEnbFac_mp));                           // 308
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_mflagCutinRisk_mp));                                // 309

  fct_debug_out.add_reserved(static_cast<uint8_t>(0));                                                       // 310
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskStbyOrNp2UrbanCdn_mp));                     // 311
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskUrban2StbyCdn_mp));                         // 312
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskUrban2PSPCdn_mp));                          // 313
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskUrban2NopCdn_mp));                          // 314
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskPspOrNop2UrbanCdn_mp));                     // 315
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskUrban2PilotCdn_mp));                        // 316
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uBitMaskUrban2PilotLongCdn_mp));                    // 317
  fct_debug_out.add_reserved(static_cast<double>(sm_debug_info.pilot_debug_info_standby));                   // 318
  fct_debug_out.add_reserved(static_cast<uint16_t>(uBitUrbanStatusTrigggerSup));                             // 319
  if (nullptr != ioadapter) {
    int nad_status        = ioadapter->getMidOutputManager().getUrbanStatus();
    double debug_odd1_urban  = ioadapter->getMidOutputManager().getUrbanOdd1Dis();
    double debug_odd3_urban  = ioadapter->getMidOutputManager().getUrbanOdd3Dis();
    double debug_odd6_urban  = ioadapter->getMidOutputManager().getUrbanOdd6Dis();
    bool is_in_nad_dynamic_area = ioadapter->getMidOutputManager().getisinDynamicArea();
    fct_debug_out.add_reserved(static_cast<uint16_T>(nad_status));                                           // 320
    fct_debug_out.add_reserved(static_cast<double>(debug_odd1_urban));                                       // 321
    fct_debug_out.add_reserved(static_cast<double>(debug_odd3_urban));                                       // 322
    fct_debug_out.add_reserved(static_cast<double>(debug_odd6_urban));                                       // 323
    fct_debug_out.add_reserved(static_cast<double>(is_in_nad_dynamic_area));                                 // 324
  } else {
    fct_debug_out.add_reserved(static_cast<uint16_T>(5));                                                   // 320
    fct_debug_out.add_reserved(static_cast<double>(-10));                                                    // 321
    fct_debug_out.add_reserved(static_cast<double>(-10));                                                    // 322
    fct_debug_out.add_reserved(static_cast<double>(-10));                                                    // 323
    fct_debug_out.add_reserved(static_cast<double>(0));                                                      // 324
  }
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uUrbanActivationPrevention_mp));                    // 325
  fct_debug_out.add_reserved(static_cast<uint16_T>(ACCSC_uUrbanSuppression_mp));                             // 326
  // HWASM_uCdnLatInh_mp
  fct_debug_out.add_reserved(static_cast<uint16_T>(HWASM_uCdnLatInh_mp));                                    // 327
  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->getIsFollowingVehicle()));     // 328
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(0));                                                     // 328
  }
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DAPSPWTI3_mp));                                      // 329
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_TaskState_mp));                                      // 330
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DistanceToOdd_mp));                                  // 331
  fct_debug_out.add_reserved(static_cast<double>(ACCSC_AccPedPos_mp));                                       // 332
  fct_debug_out.add_reserved(static_cast<uint8_t>(ACCSC_DANADAvl_mp));                                       // 333


  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getNavigationStateSuccess()));   // 334
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getNopPlusAvailable()));   // 335
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                     // 334
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                     // 335
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<int>(ioadapter->getFramePtr()->getFollowingVehicleID()));   // 336
  } else {
    fct_debug_out.add_reserved(static_cast<int>(0));                                                     // 336
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getDaMainPSPAvailable()));   // 337
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getHighwayStatus()));    // 338
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getUrbanStatus()));      // 339
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getPSPGeofence()));         // 340
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                // 337
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                // 338
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                // 339
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                // 340
  }

  fct_debug_out.add_reserved(static_cast<bool>(ACCSC_DisengChimeWoLatCtrlMLC_mp));                       // 341

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsInTollStation()));       // 342
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getCloseToTollStation()));    // 343
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getCurrLaneInTollStation())); // 344
    fct_debug_out.add_reserved(ioadapter->getFramePtr() ? ioadapter->getFramePtr()->getDistanceLeftToODDBoundary() : 100000.0);       // 345
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getNavigationYawingSts()));   // 346
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getRiskScenarioResult()));    // 347
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                       // 342
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                       // 343
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                       // 344
    fct_debug_out.add_reserved(-100000.0);                                                                      // 345
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                       // 346
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                       // 347
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getRefineSpeedFlg()));          // 348
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getSpeedError()));            // 349
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getIntegralSpeedError()));    // 350
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getUserSetSpeedOut()));       // 351
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getVcuDispSpeed()));          // 352
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getUserSetSpeed()));          // 353
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getUserSetSpeedforBp()));     // 354
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getSpeedControlStable()));      // 355
    // speed control stable flag debug
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getMPRefSpeed()));            // 356
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getPathMaxSpeed()));          // 357
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getPathMinSpeed()));          // 358
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getPathAverSpeed()));         // 359

  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 348
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 349
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 350
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 351
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 352
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 353
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 354
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 355

    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 356
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 357
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 358
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 359
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getWmReqNopSuppression()));     // 360
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getJunctionActPrev()));         // 361
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsNopSubscribtion()));       // 362
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsNadSubscribtion()));       // 363
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getCurveSpeedAssist()));    // 364
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getFlagLocalRouteEnd()));       // 365
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsOnTollLane()));            // 366
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsOnCheckingLane()));        // 367

  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 360
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 361
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 362
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 363
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 364
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 365
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 366
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 367
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getMrmEnableResult()));         // 368
    fct_debug_out.add_reserved(
      static_cast<bool>(ioadapter->getMidOutputManager().getLargeCurvatureScenarioResult()));                     // 369
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getJunctionScenarioResult()));  // 370
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getMrmEnableByHazard()));       // 371
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getMrmAvailableFlg()));         // 372
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 368
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 369
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 370
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 371
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 372
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getPsapActiveFlg()));           // 373
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsHighwayNpEvent()));        // 374
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getDistanceToHighwayNpEvent())); // 375
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 373
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 374
    fct_debug_out.add_reserved(-100000.0);                                                                        // 375
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<uint16_t>(ioadapter->getMidOutputManager().getNavigationDebugMask()));     // 376
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNopActPreDebugMask()));      // 377
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNopSupprDebugMask()));       // 378
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getLccPlusActPreDebugMask()));  // 379
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getLccPlusSupprDebugMask()));   // 380
    fct_debug_out.add_reserved(static_cast<double>(-9999));                                                           // 381
  } else {
    fct_debug_out.add_reserved(static_cast<uint16_t>(0));                                                         // 376
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 377
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 378
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 379
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 380
    fct_debug_out.add_reserved(static_cast<double>(-9999));                                                       // 381
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getWMMapModeReq()));          // 382
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getNpPlusAvailable()));         // 383
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getTriggerInhibitDec()));       // 384
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 382
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 383
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 384
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<uint8_t>(ioadapter->getFramePtr()->getHeavyBrakeFlg()));               // 385
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->getBrakeBackObsCollisionFlg()));       // 386
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->getLaneNarrowSpaceSuppressFlag()));    // 387
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->getLaneWideSpaceFlag()));              // 388
  } else {
    fct_debug_out.add_reserved(static_cast<uint8_t>(10));                                                         // 385
    fct_debug_out.add_reserved(static_cast<uint8_t>(10));                                                         // 386
    fct_debug_out.add_reserved(static_cast<uint8_t>(2));                                                          // 387
    fct_debug_out.add_reserved(static_cast<uint8_t>(3));                                                          // 388
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<int>(ioadapter->getMidOutputManager().getMrmScenarioResult()));        // 389
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getChangeToNpplusFlag()));      // 390
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getChangeNpplusAccumS()));    // 391
  } else {
    fct_debug_out.add_reserved(static_cast<int>(0));                                                              // 389
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 390
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                         // 391
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getAppStatusActPreFlg()));      // 392
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getAppStatusActPreDebug()));// 393
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getAppTopicLossDebug()));   // 394
    fct_debug_out.add_reserved(static_cast<uint8_t>(ioadapter->getMidOutputManager().getPlannerStsReq()));        // 395  
    fct_debug_out.add_reserved(static_cast<uint8_t>(ioadapter->getMidOutputManager().getAppTopicSendType()));     // 396    
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                         // 392
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 393
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 394
    fct_debug_out.add_reserved(static_cast<uint8_t>(0));                                                          // 395
    fct_debug_out.add_reserved(static_cast<uint8_t>(0));                                                          // 396
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->isLaneRiskScenario()));              // 397
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->isUTurn()));                         // 398
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->isUTurnRisk()));                     // 399
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->getUTurnRiskObjId()));               // 400
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 397
    fct_debug_out.add_reserved(static_cast<double>(255));                                                         // 398
    fct_debug_out.add_reserved(static_cast<double>(255));                                                         // 399
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 400
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getDistanceToHighRiskAOEvent())); // 401
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getHighRiskEventFlag()));           // 402
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getDistanceToMidRiskAOEvent()));  // 403
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getMidRiskEventFlag()));            // 404
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNpAdInhibitInput()));    // 405
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNpTdInhibitInput()));    // 406
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNpEasInhibitInput()));   // 407
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNpHardInhibitInput()));  // 408
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                             // 401
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                             // 402
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                             // 403
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                             // 404
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 405
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 406
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 407
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                         // 408
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<int>(ioadapter->getFramePtr()->getExplorationType()));                 // 409
    fct_debug_out.add_reserved(static_cast<int>(ioadapter->getFramePtr()->getIsSitichPointsReplan()));            // 410
  } else {
    fct_debug_out.add_reserved(static_cast<int>(-1));                                                             // 409
    fct_debug_out.add_reserved(static_cast<int>(0));                                                              // 410
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->isNpPlusInstantOffFlagNearestJunction()));  // 411
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                              // 411
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getMidOutputManager().getIsInEmergenceFlag()));           // 412
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                             // 412
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->getUTurnDistance()));               // 413
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->getUTurnNaviSpeedLimit()));         // 414
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->isUTurnStuck()));                   // 415
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getFreezeHodTimerReq()));    // 416
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 413
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 414
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 415
    fct_debug_out.add_reserved(static_cast<double>(0));                                                           // 416
  }
  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getFramePtr()->distanceToNearestSlopePoint()));       // 417
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                           // 417
  }
  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->SlopeSpeedAdjustActive()));              // 418
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                           // 418
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<uint32_t>(ioadapter->getMidOutputManager().getNpActPreInput()));           // 419
  } else {
    fct_debug_out.add_reserved(static_cast<uint32_t>(0));                                                             // 419
  }

  if (nullptr != ioadapter && nullptr != ioadapter->getFramePtr()) {
    fct_debug_out.add_reserved(static_cast<bool>(ioadapter->getFramePtr()->getKMergeScenario()));                   // 420
  } else {
    fct_debug_out.add_reserved(static_cast<bool>(false));                                                           // 420
  }

  if (nullptr != ioadapter) {
    fct_debug_out.add_reserved(static_cast<double>(ioadapter->getMidOutputManager().getNaviYawingAccumulateS()));   // 421
  } else {
    fct_debug_out.add_reserved(static_cast<double>(0.0));                                                           // 421
  }

  static uint16_t ACCSC_uBitMaskPSPActPrev_mp_last = 0;
  if (ACCSC_uBitMaskPSPActPrev_mp_last != ACCSC_uBitMaskPSPActPrev_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPActPrev_mp: " << ACCSC_uBitMaskPSPActPrev_mp;
  }
  ACCSC_uBitMaskPSPActPrev_mp_last = ACCSC_uBitMaskPSPActPrev_mp;

  static uint16_t ACCSC_uBitMaskPSPCond_mp_last = 0;
  if (ACCSC_uBitMaskPSPCond_mp_last != ACCSC_uBitMaskPSPCond_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPCond_mp: " << ACCSC_uBitMaskPSPCond_mp;
  }
  ACCSC_uBitMaskPSPCond_mp_last = ACCSC_uBitMaskPSPCond_mp;

  static uint16_t ACCSC_uPSPADSoftInh_mp_last = 0;
  if (ACCSC_uPSPADSoftInh_mp_last != ACCSC_uPSPADSoftInh_mp) {
    WARN_LOG << "ACCSC_uPSPADSoftInh_mp: " << ACCSC_uPSPADSoftInh_mp;
  }
  ACCSC_uPSPADSoftInh_mp_last = ACCSC_uPSPADSoftInh_mp;

  static uint16_t ACCSC_uPSPTDSoftInh_mp_last = 0;
  if (ACCSC_uPSPTDSoftInh_mp_last != ACCSC_uPSPTDSoftInh_mp) {
    WARN_LOG << "ACCSC_uPSPTDSoftInh_mp: " << ACCSC_uPSPTDSoftInh_mp;
  }
  ACCSC_uPSPTDSoftInh_mp_last = ACCSC_uPSPTDSoftInh_mp;

  static uint16_t ACCSC_uPSPFimTDSoftInh1_mp_last = 0;
  if (ACCSC_uPSPFimTDSoftInh1_mp_last != ACCSC_uPSPFimTDSoftInh1_mp) {
    WARN_LOG << "ACCSC_uPSPFimTDSoftInh1_mp: " << ACCSC_uPSPFimTDSoftInh1_mp;
  }
  ACCSC_uPSPFimTDSoftInh1_mp_last = ACCSC_uPSPFimTDSoftInh1_mp;

  static uint16_t ACCSC_uPSPFimTDSoftInh2_mp_last = 0;
  if (ACCSC_uPSPFimTDSoftInh2_mp_last != ACCSC_uPSPFimTDSoftInh2_mp) {
    WARN_LOG << "ACCSC_uPSPFimTDSoftInh2_mp: " << ACCSC_uPSPFimTDSoftInh2_mp;
  }
  ACCSC_uPSPFimTDSoftInh2_mp_last = ACCSC_uPSPFimTDSoftInh2_mp;

  static uint16_t ACCSC_uPSPFimADSoftInh1_mp_last = 0;
  if (ACCSC_uPSPFimADSoftInh1_mp_last != ACCSC_uPSPFimADSoftInh1_mp) {
    WARN_LOG << "ACCSC_uPSPFimADSoftInh1_mp: " << ACCSC_uPSPFimADSoftInh1_mp;
  }
  ACCSC_uPSPFimADSoftInh1_mp_last = ACCSC_uPSPFimADSoftInh1_mp;

  static uint16_t ACCSC_uPSPFimADSoftInh2_mp_last = 0;
  if (ACCSC_uPSPFimADSoftInh2_mp_last != ACCSC_uPSPFimADSoftInh2_mp) {
    WARN_LOG << "ACCSC_uPSPFimADSoftInh2_mp: " << ACCSC_uPSPFimADSoftInh2_mp;
  }
  ACCSC_uPSPFimADSoftInh2_mp_last = ACCSC_uPSPFimADSoftInh2_mp;

  static uint16_t ACCSC_uPSPHardInh_mp_last = 0;
  if (ACCSC_uPSPHardInh_mp_last != ACCSC_uPSPHardInh_mp) {
    WARN_LOG << "ACCSC_uPSPHardInh_mp: " << ACCSC_uPSPHardInh_mp;
  }
  ACCSC_uPSPHardInh_mp_last = ACCSC_uPSPHardInh_mp;

  // statemachine for psp cond
  static uint16_t ACCSC_uBitMaskPSPStandbyToSysPassive_mp_last = 0;
  if (ACCSC_uBitMaskPSPStandbyToSysPassive_mp_last != ACCSC_uBitMaskPSPStandbyToSysPassive_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPStandbyToSysPassive_mp: " << ACCSC_uBitMaskPSPStandbyToSysPassive_mp;
  }
  ACCSC_uBitMaskPSPStandbyToSysPassive_mp_last = ACCSC_uBitMaskPSPStandbyToSysPassive_mp;

  static uint16_t ACCSC_uBitMaskSysPassiveToPSPStandby_mp_last = 0;
  if (ACCSC_uBitMaskSysPassiveToPSPStandby_mp_last != ACCSC_uBitMaskSysPassiveToPSPStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskSysPassiveToPSPStandby_mp: " << ACCSC_uBitMaskSysPassiveToPSPStandby_mp;
  }
  ACCSC_uBitMaskSysPassiveToPSPStandby_mp_last = ACCSC_uBitMaskSysPassiveToPSPStandby_mp;

  static uint16_t ACCSC_uBitMaskPSPStandbyToAccStandby_mp_last = 0;
  if (ACCSC_uBitMaskPSPStandbyToAccStandby_mp_last != ACCSC_uBitMaskPSPStandbyToAccStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPStandbyToAccStandby_mp: " << ACCSC_uBitMaskPSPStandbyToAccStandby_mp;
  }
  ACCSC_uBitMaskPSPStandbyToAccStandby_mp_last = ACCSC_uBitMaskPSPStandbyToAccStandby_mp;

  static uint16_t ACCSC_uBitMaskPSPStandbyToPilotStandby_mp_last = 0;
  if (ACCSC_uBitMaskPSPStandbyToPilotStandby_mp_last != ACCSC_uBitMaskPSPStandbyToPilotStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPStandbyToPilotStandby_mp: " << ACCSC_uBitMaskPSPStandbyToPilotStandby_mp;
  }
  ACCSC_uBitMaskPSPStandbyToPilotStandby_mp_last = ACCSC_uBitMaskPSPStandbyToPilotStandby_mp;

  static uint16_t ACCSC_uBitMaskAccStandbyToPSPStandby_mp_last = 0;
  if (ACCSC_uBitMaskAccStandbyToPSPStandby_mp_last != ACCSC_uBitMaskAccStandbyToPSPStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskAccStandbyToPSPStandby_mp: " << ACCSC_uBitMaskAccStandbyToPSPStandby_mp;
  }
  ACCSC_uBitMaskAccStandbyToPSPStandby_mp_last = ACCSC_uBitMaskAccStandbyToPSPStandby_mp;

  static uint16_t ACCSC_uBitMaskPilotStandbyToPSPStandby_mp_last = 0;
  if (ACCSC_uBitMaskPilotStandbyToPSPStandby_mp_last != ACCSC_uBitMaskPilotStandbyToPSPStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskPilotStandbyToPSPStandby_mp: " << ACCSC_uBitMaskPilotStandbyToPSPStandby_mp;
  }
  ACCSC_uBitMaskPilotStandbyToPSPStandby_mp_last = ACCSC_uBitMaskPilotStandbyToPSPStandby_mp;

  static uint16_t ACCSC_uBitMaskPSPActiveToStandby_mp_last = 0;
  if (ACCSC_uBitMaskPSPActiveToStandby_mp_last != ACCSC_uBitMaskPSPActiveToStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPActiveToStandby_mp: " << ACCSC_uBitMaskPSPActiveToStandby_mp;
  }
  ACCSC_uBitMaskPSPActiveToStandby_mp_last = ACCSC_uBitMaskPSPActiveToStandby_mp;

  static uint16_t ACCSC_uBitMaskPSPStandbyToActive_mp_last = 0;
  if (ACCSC_uBitMaskPSPStandbyToActive_mp_last != ACCSC_uBitMaskPSPStandbyToActive_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPStandbyToActive_mp: " << ACCSC_uBitMaskPSPStandbyToActive_mp;
  }
  ACCSC_uBitMaskPSPStandbyToActive_mp_last = ACCSC_uBitMaskPSPStandbyToActive_mp;

  static uint16_t ACCSC_uBitMaskNOPActiveToPSPActive_mp_last = 0;
  if (ACCSC_uBitMaskNOPActiveToPSPActive_mp_last != ACCSC_uBitMaskNOPActiveToPSPActive_mp) {
    WARN_LOG << "ACCSC_uBitMaskNOPActiveToPSPActive_mp: " << ACCSC_uBitMaskNOPActiveToPSPActive_mp;
  }
  ACCSC_uBitMaskNOPActiveToPSPActive_mp_last = ACCSC_uBitMaskNOPActiveToPSPActive_mp;

  static uint16_t ACCSC_uBitMaskPSPActiveToNOPActive_mp_last = 0;
  if (ACCSC_uBitMaskPSPActiveToNOPActive_mp_last != ACCSC_uBitMaskPSPActiveToNOPActive_mp) {
    WARN_LOG << "ACCSC_uBitMaskPSPActiveToNOPActive_mp: " << ACCSC_uBitMaskPSPActiveToNOPActive_mp;
  }
  ACCSC_uBitMaskPSPActiveToNOPActive_mp_last = ACCSC_uBitMaskPSPActiveToNOPActive_mp;

  static uint16_t ACCSC_uBitMaskAccStandbyToPilotStandby_mp_last = 0;
  if (ACCSC_uBitMaskAccStandbyToPilotStandby_mp_last != ACCSC_uBitMaskAccStandbyToPilotStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskAccStandbyToPilotStandby_mp: " << ACCSC_uBitMaskAccStandbyToPilotStandby_mp;
  }
  ACCSC_uBitMaskAccStandbyToPilotStandby_mp_last = ACCSC_uBitMaskAccStandbyToPilotStandby_mp;

  static uint16_t ACCSC_uBitMaskPilotStandbyToAccStandby_mp_last = 0;
  if (ACCSC_uBitMaskPilotStandbyToAccStandby_mp_last != ACCSC_uBitMaskPilotStandbyToAccStandby_mp) {
    WARN_LOG << "ACCSC_uBitMaskPilotStandbyToAccStandby_mp: " << ACCSC_uBitMaskPilotStandbyToAccStandby_mp;
  }
  ACCSC_uBitMaskPilotStandbyToAccStandby_mp_last = ACCSC_uBitMaskPilotStandbyToAccStandby_mp;

  static uint16_t DA_Inhibit_ForNop_last = 0;
  if (DA_Inhibit_ForNop_last != DA_Inhibit_ForNop) {
    WARN_LOG << "DA_Inhibit_ForNop: " << DA_Inhibit_ForNop;
  }
  DA_Inhibit_ForNop_last = DA_Inhibit_ForNop;

  static uint16_t ACCSC_DAFuncArbReq_mp_last = 0;
  if (ACCSC_DAFuncArbReq_mp_last != ACCSC_DAFuncArbReq_mp) {
    WARN_LOG << "ACCSC_DAFuncArbReq_mp: " << ACCSC_DAFuncArbReq_mp;
  }
  ACCSC_DAFuncArbReq_mp_last = ACCSC_DAFuncArbReq_mp;

  static uint16_t ACCSC_uNOPSuppression_mp_last = 0;
  if (ACCSC_uNOPSuppression_mp_last != ACCSC_uNOPSuppression_mp) {
    WARN_LOG << "ACCSC_uNOPSuppression_mp: " << ACCSC_uNOPSuppression_mp;
  }
  ACCSC_uNOPSuppression_mp_last = ACCSC_uNOPSuppression_mp;

  static uint16_t ACCSC_uNOPActivationPrevention_mp_last = 0;
  if (ACCSC_uNOPActivationPrevention_mp_last != ACCSC_uNOPActivationPrevention_mp) {
    WARN_LOG << "ACCSC_uNOPActivationPrevention_mp: " << ACCSC_uNOPActivationPrevention_mp;
  }
  ACCSC_uNOPActivationPrevention_mp_last = ACCSC_uNOPActivationPrevention_mp;

  static uint8_t HWASM_Stdummy_mp_last = 0;
  if (HWASM_Stdummy_mp_last != HWASM_Stdummy_mp) {
    AWARN_ET(10) << "HWASM_Stdummy_mp: " << HWASM_Stdummy_mp;
  }
  HWASM_Stdummy_mp_last = HWASM_Stdummy_mp;

}

void gonotifier_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_gonotifier_debug_out()->set_cipv_index(gonotifier.input_.cipv_obj.obj_index);
  fct_debug_out.mutable_gonotifier_debug_out()->set_cipv_valid(gonotifier.input_.cipv_obj.valid);
  fct_debug_out.mutable_gonotifier_debug_out()->set_cipv_lon_pos(gonotifier.input_.cipv_obj.lon_pos_vcs);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_last_index(gonotifier.output_.lead_obj.obj_last.obj_index);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_last_valid(gonotifier.output_.lead_obj.obj_last.valid);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_last_lon_pos(
    gonotifier.output_.lead_obj.obj_last.lon_pos_vcs);
  fct_debug_out.mutable_gonotifier_debug_out()->set_np_sts(static_cast<uint32_t>(gonotifier.input_.np_sts));
  fct_debug_out.mutable_gonotifier_debug_out()->set_dms_phylink_fim(gonotifier.input_.dms_phylink_fim);
  fct_debug_out.mutable_gonotifier_debug_out()->set_dms_sts(static_cast<uint32_t>(gonotifier.input_.dms_sts));
  fct_debug_out.mutable_gonotifier_debug_out()->set_dms_result_valid(gonotifier.input_.dms_result_valid);
  fct_debug_out.mutable_gonotifier_debug_out()->set_dms_result_conf(
    static_cast<double>(gonotifier.input_.dms_result_conf));
  fct_debug_out.mutable_gonotifier_debug_out()->set_dms_dstr_lvl(static_cast<uint32_t>(gonotifier.input_.dms_dstr_lvl));
  fct_debug_out.mutable_gonotifier_debug_out()->set_obs_dist_fl(gonotifier.input_.obs_dist_fl);
  fct_debug_out.mutable_gonotifier_debug_out()->set_obs_dist_fm(gonotifier.input_.obs_dist_fm);
  fct_debug_out.mutable_gonotifier_debug_out()->set_obs_dist_fr(gonotifier.input_.obs_dist_fr);
  fct_debug_out.mutable_gonotifier_debug_out()->set_ego_standstill(gonotifier.output_.ego_standstill);
  fct_debug_out.mutable_gonotifier_debug_out()->set_ego_standstill_age(gonotifier.output_.ego_standstill_age);
  fct_debug_out.mutable_gonotifier_debug_out()->set_req_send_flag(gonotifier.output_.req_send_flag);
  fct_debug_out.mutable_gonotifier_debug_out()->set_no_lead_obj_age(gonotifier.output_.no_lead_obj_age);
  fct_debug_out.mutable_gonotifier_debug_out()->set_np_cond(gonotifier.output_.np_cond);
  fct_debug_out.mutable_gonotifier_debug_out()->set_ego_cond(gonotifier.output_.ego_cond);
  fct_debug_out.mutable_gonotifier_debug_out()->set_drv_distracted(gonotifier.output_.drv_distracted);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_exist(gonotifier.output_.lead_obj.obj_exist);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_leave_age(gonotifier.output_.lead_obj.leave_age);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_dis_age(gonotifier.output_.lead_obj.dis_age);
  fct_debug_out.mutable_gonotifier_debug_out()->set_lead_obj_cond(gonotifier.output_.lead_obj.obj_cond);
  fct_debug_out.mutable_gonotifier_debug_out()->set_uss_fault_st(static_cast<uint32_t>(gGoNotifyUSSFaultSt));
  fct_debug_out.mutable_gonotifier_debug_out()->set_sys_fault_st(static_cast<uint32_t>(gGoNotifySysFaultSt));
  fct_debug_out.mutable_gonotifier_debug_out()->set_failsafe_st(static_cast<uint32_t>(gGoNotifyFailSafeSt));
  fct_debug_out.mutable_gonotifier_debug_out()->set_uss_fail(gonotifier.output_.uss_fail);
  fct_debug_out.mutable_gonotifier_debug_out()->set_obs_cond(gonotifier.output_.obs_cond);
  fct_debug_out.mutable_gonotifier_debug_out()->set_sys_fail(gonotifier.output_.sys_fail);
  fct_debug_out.mutable_gonotifier_debug_out()->set_smstate(static_cast<uint32_t>(gonotifier.output_.smstate));
  fct_debug_out.mutable_gonotifier_debug_out()->set_gn_request(static_cast<uint32_t>(gonotifier.output_.gn_request));
  fct_debug_out.mutable_gonotifier_debug_out()->set_gn_request_age(gonotifier.output_.gn_request_age);
  fct_debug_out.mutable_gonotifier_debug_out()->set_gn_switch(static_cast<uint32_t>(gonotifier.input_.gn_switch));
  fct_debug_out.mutable_gonotifier_debug_out()->set_driver_act(gonotifier.output_.driver_act);
}

void tl_gonotifier_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  fct_debug_out.mutable_tl_gonotifier()->set_gn_switch(static_cast<uint32_t>(tl_gonotifier.GnSwitch()));
  fct_debug_out.mutable_tl_gonotifier()->set_sales_region(static_cast<uint32_t>(tl_gonotifier.SalesRegion()));
  fct_debug_out.mutable_tl_gonotifier()->set_nopplus_subscribe(tl_gonotifier.NopPlusSubscribe());
  fct_debug_out.mutable_tl_gonotifier()->set_nad_subscribe(tl_gonotifier.NadSubscribe());
  fct_debug_out.mutable_tl_gonotifier()->set_dms_driver_inloop(tl_gonotifier.DmsDriverInLoop());
  fct_debug_out.mutable_tl_gonotifier()->set_tl_color(tl_gonotifier.TrafficLight().color);
  fct_debug_out.mutable_tl_gonotifier()->set_tl_timer(tl_gonotifier.TrafficLight().timer);
  fct_debug_out.mutable_tl_gonotifier()->set_gn_failsafe_state(tl_gonotifier.GnFailSafeState());
  fct_debug_out.mutable_tl_gonotifier()->set_cn_config(tl_gonotifier.CNConfig());
  fct_debug_out.mutable_tl_gonotifier()->set_eu_config(tl_gonotifier.EUConfig());
  fct_debug_out.mutable_tl_gonotifier()->set_da_active(tl_gonotifier.DaActive());
  fct_debug_out.mutable_tl_gonotifier()->set_da_haswti(tl_gonotifier.DaHasWti());
  fct_debug_out.mutable_tl_gonotifier()->set_is_standstill(tl_gonotifier.IsStandstill());
  fct_debug_out.mutable_tl_gonotifier()->set_is_firstvehicle(tl_gonotifier.IsFirstVehicle());
  fct_debug_out.mutable_tl_gonotifier()->set_precondition(tl_gonotifier.PreCondition());
  fct_debug_out.mutable_tl_gonotifier()->set_faultbit(tl_gonotifier.FaultBit());
  fct_debug_out.mutable_tl_gonotifier()->set_dms_faultbit(tl_gonotifier.DmsFaultBit());
  fct_debug_out.mutable_tl_gonotifier()->set_driver_distracted(tl_gonotifier.DriverDistracted());
  fct_debug_out.mutable_tl_gonotifier()->set_color_turn(tl_gonotifier.ColorTurn());
  fct_debug_out.mutable_tl_gonotifier()->set_has_timer(tl_gonotifier.HasTimer());
  fct_debug_out.mutable_tl_gonotifier()->set_timer_turn(tl_gonotifier.TimerTurn());
  fct_debug_out.mutable_tl_gonotifier()->mutable_gn_req()->set_type_in(tl_gonotifier.TLRequest().type_in);
  fct_debug_out.mutable_tl_gonotifier()->mutable_gn_req()->set_type(tl_gonotifier.TLRequest().type);
  fct_debug_out.mutable_tl_gonotifier()->mutable_gn_req()->set_req(tl_gonotifier.TLRequest().req);
  fct_debug_out.mutable_tl_gonotifier()->mutable_gn_req()->set_age(tl_gonotifier.TLRequest().age);

  fct_debug_out.mutable_tl_gonotifier()->mutable_reserved()->Clear();
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.HasTLJunctionMatched()));           //00
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.DistanceToEntry()));                //01
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.HdJunctionID()));                   //02
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.IsNaviOn()));                       //03
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.RoadSign()));                       //04
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.RoadSignHasNaviDir()));             //05
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.IsSingleRoadSign()));               //06
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.DistToCipvTrs()));                  //07

  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.LaneEsdTrafficLight().tld_valid));  //08
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.LaneEsdTrafficLight().tld_type));   //09
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.LaneEsdTrafficLight().tld_color));  //10
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.LaneEsdTrafficLight().tld_status)); //11
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.LaneEsdTrafficLight().tld_timer));  //12
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.NaviEsdTrafficLight().tld_valid));  //13
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.NaviEsdTrafficLight().tld_type));   //14
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.NaviEsdTrafficLight().tld_color));  //15
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.NaviEsdTrafficLight().tld_status)); //16
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.NaviEsdTrafficLight().tld_timer));  //17

  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.EsdTrafficLight().tld_valid));      //18
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.EsdTrafficLight().tld_type));       //19
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.EsdTrafficLight().tld_color));      //20
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.EsdTrafficLight().tld_status));     //21
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.EsdTrafficLight().tld_timer));      //22
  fct_debug_out.mutable_tl_gonotifier()->add_reserved(static_cast<double>(tl_gonotifier.TLRequest().suppress));             //23
}

void fim_debug_proc(nio::ad::messages::FctOut& fctout, nio::ad::messages::debug::FCTDebugOut& fct_debug_out) {
  // fct_debug_out.mutable_fim_debug_out()->set_ahc_fault(fct_fim.is_ahc_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_eps_fault(fct_fim.da_np_fim.is_eps_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_acm_fault(fct_fim.da_np_fim.is_acm_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_bcm_fault(fct_fim.da_np_fim.is_bcm_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_bcu_fault(fct_fim.da_np_fim.is_bcu_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_scm_fault(fct_fim.da_np_fim.is_scm_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_can_bus_off(fct_fim.da_np_fim.is_can_bus_off);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_vcu_fault(fct_fim.da_np_fim.is_vcu_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_swc_fault(fct_fim.da_np_fim.is_swc_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_dms_fault(fct_fim.da_np_fim.is_dms_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_f30_fault(fct_fim.da_np_fim.is_f30_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_f120_fault(fct_fim.da_np_fim.is_f120_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_radfc_fault(fct_fim.da_np_fim.is_radfc_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_radfs_fault(fct_fim.da_np_fim.is_radfs_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_radrs_fault(fct_fim.da_np_fim.is_radrs_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_camfs_fault(fct_fim.da_np_fim.is_camfs_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_camrs_fault(fct_fim.da_np_fim.is_camrs_fault);

  fct_debug_out.mutable_fim_debug_out()->mutable_elk_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_ldw_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_lka_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_pilot_cdc_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_pilot_bgw_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_pilot_apa_fault()->Clear();
  fct_debug_out.mutable_fim_debug_out()->mutable_pilot_svc_fault()->Clear();
  for (size_t i = 0; i < DIAG_FIM_MAX_MASK_NUM; i++) {
    // TODO: correct debug signal name
    // orignal fim signal with byte
    fct_debug_out.mutable_fim_debug_out()->add_pilot_cdc_fault(fct_fim_diag.fim_encoder_byte[i]);
    fct_debug_out.mutable_fim_debug_out()->add_pilot_bgw_fault(gAlcCamFimByte[i]);
    fct_debug_out.mutable_fim_debug_out()->add_pilot_apa_fault(gEasFimByte[i]);
    fct_debug_out.mutable_fim_debug_out()->add_pilot_svc_fault(gPilotNPByte[i]);

    fct_debug_out.mutable_fim_debug_out()->add_elk_fault(gElkFimByte[i]);
    fct_debug_out.mutable_fim_debug_out()->add_ldw_fault(gLdwFimByte[i]);
    fct_debug_out.mutable_fim_debug_out()->add_lka_fault(gLkaFimByte[i]);
  }

  fct_debug_out.mutable_fim_debug_out()->add_pilot_cdc_fault(fct_fim.da_np_fim.is_cdc_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_bgw_fault(fct_fim.da_np_fim.is_bgw_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_apa_fault(fct_fim.da_np_fim.is_apa_fault);
  fct_debug_out.mutable_fim_debug_out()->add_pilot_svc_fault(fct_fim.da_np_fim.is_svc_fault);

  fct_debug_out.mutable_fim_debug_out()->add_elk_fault(fct_fim.is_elk_fault);
  fct_debug_out.mutable_fim_debug_out()->add_ldw_fault(fct_fim.is_ldw_fault);
  fct_debug_out.mutable_fim_debug_out()->add_lka_fault(fct_fim.is_lka_fault);

  //  np_fault_log
  static uint32_t np_fault_flag      = 0;
  static uint32_t last_np_fault_flag = 0;
  static float    np_log_delay_time  = 0;
  static int      last_nanadsts      = 0;
  int             current_nanadsts   = fctout.hwa().nanadsts();
  static int      last_hero_button   = 0;
  int             hero_button        = static_cast<int>(veh_drvr.StrWhlSwtch.AdUpSwtSts[4]);
  static int      last_wti           = 0;
  int             current_wti        = fctout.hwa().nanadwti();

  if (last_nanadsts != current_nanadsts) {
    WARN_LOG << "nadsts: " << current_nanadsts;
  }

  bool ACCSC_flgSoftInh_mp_    = fct_debug_out.accsc_debug_out().accsc_flgsoftinh_mp();
  bool ACCSC_flgHardInh_mp_    = fct_debug_out.accsc_debug_out().accsc_flghardinh_mp();
  bool ACCSC_flgSysPassive_mp_ = fct_debug_out.accsc_debug_out().accsc_flgsyspassive_mp();

  if ((((6 == last_nanadsts || 7 == last_nanadsts || 8 == last_nanadsts || 9 == last_nanadsts)
        && (6 != current_nanadsts || 7 != current_nanadsts || 8 != current_nanadsts || 9 != current_nanadsts))
       && (ACCSC_flgSoftInh_mp_ || ACCSC_flgHardInh_mp_ || ACCSC_flgSysPassive_mp_)
       && (0 == static_cast<int>(brk_sys.BrkPdl.BrkPedlSts)))
      || ((ACCSC_flgSoftInh_mp_ || ACCSC_flgHardInh_mp_ || ACCSC_flgSysPassive_mp_)
          && (1 == last_hero_button && 0 == hero_button))
      || ((current_wti != last_wti) && (ACCSC_flgSoftInh_mp_))) {
    np_fault_flag = 1;
  }
  if (1 == np_fault_flag) {
    np_log_delay_time += kFctStepTime;
    if (np_log_delay_time > kHeroButtonTrigDelayTime_s) {
      np_fault_flag     = 0;
      np_log_delay_time = 0;
    }
  } else {
    np_fault_flag     = 0;
    np_log_delay_time = 0;
  }

  if (0 == last_np_fault_flag && 1 == np_fault_flag) {

    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_flgActPrev_mp       : " << int(ACCSC_flgActPrev_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_flgSoftInh_mp       : " << int(ACCSC_flgSoftInh_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_flgHardInh_mp       : " << int(ACCSC_flgHardInh_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_flgSysPassive_mp    : " << int(ACCSC_flgSysPassive_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp         : " << int(ACCSC_uActPrev_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp        : " << int(ACCSC_uActPrev1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp        : " << int(ACCSC_uHardInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp        : " << int(ACCSC_uHardInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp        : " << int(ACCSC_uHardInh3_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh4_mp        : " << int(ACCSC_uHardInh4_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp  : " << int(ACCSC_uAtnDmdSoftInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh2_mp  : " << int(ACCSC_uAtnDmdSoftInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp : " << int(ACCSC_uTkovDmdSoftInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp : " << int(ACCSC_uTkovDmdSoftInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh3_mp : " << int(ACCSC_uTkovDmdSoftInh3_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uVehStbADSoftInh1_mp: " << int(ACCSC_uVehStbADSoftInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uVehStbADSoftInh2_mp: " << int(ACCSC_uVehStbADSoftInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uVehStbTDSoftInh1_mp: " << int(ACCSC_uVehStbTDSoftInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uVehStbTDSoftInh2_mp: " << int(ACCSC_uVehStbTDSoftInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp  : " << int(ACCSC_uEASTrgHardInh1_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh2_mp  : " << int(ACCSC_uEASTrgHardInh2_mp);
    // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uCdnPassive_mp      : " << int(ACCSC_uCdnPassive_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp     : " << int(LatCtrl_bfLksSprs_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_WTI                      : " << int(fctout.hwa().nanadwti());
    {
      // TODO: backup signals
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE536: " << (ACCSC_uActPrev_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE512: " << ((ACCSC_uActPrev_mp>>1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE128: " << ((ACCSC_uActPrev_mp>>2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE234: " << ((ACCSC_uActPrev_mp>>3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE240: " << ((ACCSC_uActPrev_mp>>4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE189: " << ((ACCSC_uActPrev_mp>>5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_RE234_Pilot: " << ((ACCSC_uActPrev_mp>>6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev_mp_TrailerModSprs: " << ((ACCSC_uActPrev_mp>>7) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_flgAEBRelated: " << (ACCSC_uActPrev1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_DmsDrvDistracted: " << ((ACCSC_uActPrev1_mp>>1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_HandsOffDetd: " << ((ACCSC_uActPrev1_mp>>2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_ECOPlusModSts: " << ((ACCSC_uActPrev1_mp>>3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_DrvOvrdStrWhl: " << ((ACCSC_uActPrev1_mp>>4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_TowModActv: " << ((ACCSC_uActPrev1_mp>>5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_ElkActv: " << ((ACCSC_uActPrev1_mp>>6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uActPrev1_mp_ReqDAStdby: " << ((ACCSC_uActPrev1_mp>>7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE196: " << (ACCSC_uHardInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE103: " << ((ACCSC_uHardInh1_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE499: " << ((ACCSC_uHardInh1_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE321: " << ((ACCSC_uHardInh1_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE313: " << ((ACCSC_uHardInh1_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE314: " << ((ACCSC_uHardInh1_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_RE222: " << ((ACCSC_uHardInh1_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_DrvAbsStst: " << ((ACCSC_uHardInh1_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE193: " << (ACCSC_uHardInh2_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE102: " << ((ACCSC_uHardInh2_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE152: " << ((ACCSC_uHardInh2_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE502: " << ((ACCSC_uHardInh2_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE194: " << ((ACCSC_uHardInh2_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE235: " << ((ACCSC_uHardInh2_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE73: " << ((ACCSC_uHardInh2_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh2_mp_RE513: " << ((ACCSC_uHardInh2_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh1_mp_DrvAbsStst: " << ((ACCSC_uHardInh1_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_FctDiagLongLossComm: " << (ACCSC_uHardInh3_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_TrailerModSprs: " << ((ACCSC_uHardInh3_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_EPBHld: " << ((ACCSC_uHardInh3_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_CDPReq: " << ((ACCSC_uHardInh3_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_CrashDetd: " << ((ACCSC_uHardInh3_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_EASFailed: " << ((ACCSC_uHardInh3_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_FullOvrdStrWhl: " << ((ACCSC_uHardInh3_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh3_mp_EasTrgHardInh: " << ((ACCSC_uHardInh3_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh4_mp_StndStlSoftInh: " << (ACCSC_uHardInh4_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uHardInh4_mp_FAM_DAHardInhReq: " << ((ACCSC_uHardInh4_mp >> 1) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgBrkSysAD: " << (ACCSC_uAtnDmdSoftInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_RE310: " << ((ACCSC_uAtnDmdSoftInh1_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgDrvAttntAvlAD: " << ((ACCSC_uAtnDmdSoftInh1_mp >> 2)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_OverMaxDispVehLmtAD: "
      //          << ((ACCSC_uAtnDmdSoftInh1_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgVehStbAD: " << ((ACCSC_uAtnDmdSoftInh1_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgFctFimAD: " << ((ACCSC_uAtnDmdSoftInh1_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgHODErrStsAD: " << ((ACCSC_uAtnDmdSoftInh1_mp >> 6) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uAtnDmdSoftInh1_mp_flgDmsHodInstFbAD: "
      //          << ((ACCSC_uAtnDmdSoftInh1_mp >> 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_flgDrvAttntAvlTD: " << (ACCSC_uTkovDmdSoftInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_PsngDrUnLock: " << ((ACCSC_uTkovDmdSoftInh1_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_FLSeatBltUnbck: " << ((ACCSC_uTkovDmdSoftInh1_mp >>
      // 2) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_flgVehStbTD: " << ((ACCSC_uTkovDmdSoftInh1_mp
      // >> 3) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_FLDoorOpen: " <<
      // ((ACCSC_uTkovDmdSoftInh1_mp >> 4) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_flgBrkSysTD: "
      // << ((ACCSC_uTkovDmdSoftInh1_mp >> 5) & 1); INFO_LOG <<
      // "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_flgHrTrkOpenTD: " << ((ACCSC_uTkovDmdSoftInh1_mp
      // >> 6) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh1_mp_flgDrvAttntAvlTD: "
      //          << ((ACCSC_uTkovDmdSoftInh1_mp >> 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_OverMaxDispVehLmtTD: " << (ACCSC_uTkovDmdSoftInh2_mp &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgFctFimTD: " << ((ACCSC_uTkovDmdSoftInh2_mp >> 1)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgHODErrS: " << ((ACCSC_uTkovDmdSoftInh2_mp >>
      // 2) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgDmsHodInstFbTD: "
      //          << ((ACCSC_uTkovDmdSoftInh2_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgDistrWithFtTD: "
      //          << ((ACCSC_uTkovDmdSoftInh2_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgCDCStsNokTD: " << ((ACCSC_uTkovDmdSoftInh2_mp >> 5)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgFctFailSafeTD: "
      //          << ((ACCSC_uTkovDmdSoftInh2_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uTkovDmdSoftInh2_mp_flgDAINotAvlTD: " << ((ACCSC_uTkovDmdSoftInh2_mp >> 7)
      // & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_eps_fault: " << (ACCSC_uFimTDSoftInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_bcu_fault: " << ((ACCSC_uFimTDSoftInh1_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_can_bus_off: " << ((ACCSC_uFimTDSoftInh1_mp >> 2) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_vcu_fault: " << ((ACCSC_uFimTDSoftInh1_mp >> 3) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_swc_fault: " << ((ACCSC_uFimTDSoftInh1_mp >> 4) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh1_mp_is_cdc_fault: " << ((ACCSC_uFimTDSoftInh1_mp >> 5) &
      // 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_mcu_fault: " << (ACCSC_uFimTDSoftInh2_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_percepapp_fault: " << ((ACCSC_uFimTDSoftInh2_mp >> 1)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_power_fault: " << ((ACCSC_uFimTDSoftInh2_mp >>
      // 2) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_soc1adp_fault: " << ((ACCSC_uFimTDSoftInh2_mp
      // >> 3) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_soc2dcb_fault: " <<
      // ((ACCSC_uFimTDSoftInh2_mp >> 4) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_soc3adb_fault: "
      // << ((ACCSC_uFimTDSoftInh2_mp
      // >> 5) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_soc4ads_fault: " <<
      // ((ACCSC_uFimTDSoftInh2_mp >> 6) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh2_mp_is_othercan_fault:
      // "
      // << ((ACCSC_uFimTDSoftInh2_mp >> 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_f30_fault: " << (ACCSC_uFimTDSoftInh3_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_f120_fault: " << ((ACCSC_uFimTDSoftInh3_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_lidar_fault: " << ((ACCSC_uFimTDSoftInh3_mp >> 2) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_radfc_fault: " << ((ACCSC_uFimTDSoftInh3_mp >> 3)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_svc_fault: " << ((ACCSC_uFimTDSoftInh3_mp >> 4)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_windcalibra_fault: "
      //          << ((ACCSC_uFimTDSoftInh3_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh3_mp_is_DaTdClassified_fault: "
      //          << ((ACCSC_uFimTDSoftInh3_mp >> 6) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_acm_fault: " << (ACCSC_uFimTDSoftInh4_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_bcm_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_scm_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_dms_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_f30_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_radfc_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 5) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_radfs_fault: " << ((ACCSC_uFimTDSoftInh4_mp >> 6)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh4_mp_is_radrs_fault: " << ((ACCSC_uFimTDSoftInh4_mp >>
      // 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_camfs_fault: " << (ACCSC_uFimTDSoftInh5_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_camrs_fault: " << ((ACCSC_uFimTDSoftInh5_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_svc_fault: " << ((ACCSC_uFimTDSoftInh5_mp >> 2) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_apa_fault: " << ((ACCSC_uFimTDSoftInh5_mp >> 3) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_bgw_fault: " << ((ACCSC_uFimTDSoftInh5_mp >> 4) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_gnss_fault: " << ((ACCSC_uFimTDSoftInh5_mp >> 5) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_hodsensor_fault: " << ((ACCSC_uFimTDSoftInh5_mp >>
      // 6) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimTDSoftInh5_mp_is_failsafelidar_fault: "
      //          << ((ACCSC_uFimTDSoftInh5_mp >> 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_acm_fault: " << (ACCSC_uFimADSoftInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_bcm_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_scm_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_dms_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_f30_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_radfc_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 5) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_radfs_fault: " << ((ACCSC_uFimADSoftInh1_mp >> 6)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh1_mp_is_radrs_fault: " << ((ACCSC_uFimADSoftInh1_mp >>
      // 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_camfs_fault: " << (ACCSC_uFimADSoftInh2_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_camrs_fault: " << ((ACCSC_uFimADSoftInh2_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_svc_fault: " << ((ACCSC_uFimADSoftInh2_mp >> 2) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_apa_fault: " << ((ACCSC_uFimADSoftInh2_mp >> 3) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_bgw_fault: " << ((ACCSC_uFimADSoftInh2_mp >> 4) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_gnss_fault: " << ((ACCSC_uFimADSoftInh2_mp >> 5) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_hodsensor_fault: " << ((ACCSC_uFimADSoftInh2_mp >>
      // 6) & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uFimADSoftInh2_mp_is_failsafelidar_fault: "
      //          << ((ACCSC_uFimADSoftInh2_mp >> 7) & 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_DrwsDetd: " << (ACCSC_uEASTrgHardInh1_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_DstrcDetd: " << ((ACCSC_uEASTrgHardInh1_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_DrvLeavingSeat: " << ((ACCSC_uEASTrgHardInh1_mp >> 2) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_EPBSwtPresd: " << ((ACCSC_uEASTrgHardInh1_mp >> 3) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_ACIOvrlayExit: " << ((ACCSC_uEASTrgHardInh1_mp >> 4)
      // & 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_VLCUnavl: " << ((ACCSC_uEASTrgHardInh1_mp >> 5) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh1_mp_TkovDmdEscl: " << ((ACCSC_uEASTrgHardInh1_mp >> 6) &
      // 1);

      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh2_mp_aaFail: " << (ACCSC_uEASTrgHardInh2_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh2_mp_VehDispSpdErr: " << ((ACCSC_uEASTrgHardInh2_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_np_ACCSC_uEASTrgHardInh2_mp_EasclassifiedFault: "
      //          << ((ACCSC_uEASTrgHardInh2_mp >> 2) & 1);
    }
  }

  fct_debug_out.mutable_fim_debug_out()->add_pilot_np_fault(0);
  fct_debug_out.mutable_fim_debug_out()->set_pilot_np_fault(0, np_fault_flag);
  last_nanadsts      = current_nanadsts;
  last_hero_button   = hero_button;
  last_np_fault_flag = np_fault_flag;
  last_wti           = current_wti;

  // alc
  static uint32_t alcs_fault_flag          = 0;
  static uint32_t last_alcs_fault_flag     = 0;
  static float    alc_log_delay_time       = 0;
  uint32_t        da_alcssts               = fctout.mutable_latctrl()->mutable_alcsinfo()->da_alcssts();
  static uint32_t last_stctrllanechgreq_mp = 0;
  uint32_t        stctrllanechgreq_mp      = fct_debug_out.mutable_latctrl_debug_out()->latctrl_stctrllanechgreq_mp();
  bool flgalcslemaneuversprs_mp = fct_debug_out.mutable_latctrl_debug_out()->latctrl_flgalcslemaneuversprs_mp();
  bool flgalcsrimaneuversprs_mp = fct_debug_out.mutable_latctrl_debug_out()->latctrl_flgalcsrimaneuversprs_mp();

  if ((8 == da_alcssts || 9 == da_alcssts)
      || (1 != last_stctrllanechgreq_mp && 1 == stctrllanechgreq_mp && flgalcslemaneuversprs_mp)
      || (2 != last_stctrllanechgreq_mp && 2 == stctrllanechgreq_mp && flgalcsrimaneuversprs_mp)) {
    alcs_fault_flag = 1;
  }
  if (1 == alcs_fault_flag) {
    alc_log_delay_time += kFctStepTime;
    if (alc_log_delay_time > kHeroButtonTrigDelayTime_s) {
      alcs_fault_flag    = 0;
      alc_log_delay_time = 0;
    }
  } else {
    alcs_fault_flag    = 0;
    alc_log_delay_time = 0;
  }

  if (0 == last_alcs_fault_flag && 1 == alcs_fault_flag) {
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgALCSLeManeuverSprs_mp : " << int(LatCtrl_flgALCSLeManeuverSprs_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp       : " << int(LatCtrl_bfLCALeSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgALCSRiManeuverSprs_mp : " << int(LatCtrl_flgALCSRiManeuverSprs_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp       : " << int(LatCtrl_bfLCARiSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgLCALeLaneSprs_mp      : " << int(LatCtrl_flgLCALeLaneSprs_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp   : " << int(LatCtrl_bfLCALeLaneSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgLCARiLaneSprs_mp      : " << int(LatCtrl_flgLCARiLaneSprs_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp   : " << int(LatCtrl_bfLCARiLaneSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp : " << int(Mtn_Plan_bfLCPrprActvSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp : " << int(LatCtrl_bfLCATakeOverSprsMask_mp);
    // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp             : " << int(LatCtrl_bfLksSprs_mp);
    {
      // TODO: signals backup
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_0: " << (LatCtrl_bfLCALeSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_1: " << ((LatCtrl_bfLCALeSprsMask_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_2: " << ((LatCtrl_bfLCALeSprsMask_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_3: " << ((LatCtrl_bfLCALeSprsMask_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_4: " << ((LatCtrl_bfLCALeSprsMask_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_5: " << ((LatCtrl_bfLCALeSprsMask_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_6: " << ((LatCtrl_bfLCALeSprsMask_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_7: " << ((LatCtrl_bfLCALeSprsMask_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_8: " << ((LatCtrl_bfLCALeSprsMask_mp >> 8) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_9: " << ((LatCtrl_bfLCALeSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_10: " << ((LatCtrl_bfLCALeSprsMask_mp >> 10) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeSprsMask_mp_11: " << ((LatCtrl_bfLCALeSprsMask_mp >> 11) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgALCSRiManeuverSprs_mp: " << LatCtrl_flgALCSRiManeuverSprs_mp;
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_0: " << (LatCtrl_bfLCARiSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_1: " << ((LatCtrl_bfLCARiSprsMask_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_2: " << ((LatCtrl_bfLCARiSprsMask_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_3: " << ((LatCtrl_bfLCARiSprsMask_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_4: " << ((LatCtrl_bfLCARiSprsMask_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_5: " << ((LatCtrl_bfLCARiSprsMask_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_6: " << ((LatCtrl_bfLCARiSprsMask_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_7: " << ((LatCtrl_bfLCARiSprsMask_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_8: " << ((LatCtrl_bfLCARiSprsMask_mp >> 8) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_9: " << ((LatCtrl_bfLCARiSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_10: " << ((LatCtrl_bfLCARiSprsMask_mp >> 10) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiSprsMask_mp_11: " << ((LatCtrl_bfLCARiSprsMask_mp >> 11) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgLCALeLaneSprs_mp: " << LatCtrl_flgLCALeLaneSprs_mp;
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_0: " << (LatCtrl_bfLCALeLaneSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_1: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_2: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >>
      // 2) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_3: " << ((LatCtrl_bfLCALeLaneSprsMask_mp
      // >> 3) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_4: " <<
      // ((LatCtrl_bfLCALeLaneSprsMask_mp
      // >> 4) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_5: " <<
      // ((LatCtrl_bfLCALeLaneSprsMask_mp >> 5) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_6: "
      // << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 6) & 1); INFO_LOG <<
      // "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_7: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 7) & 1); INFO_LOG
      // << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_8: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 8) & 1);
      // INFO_LOG
      // << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_9: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_10: " << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 10)
      // & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_11: " << ((LatCtrl_bfLCALeLaneSprsMask_mp
      // >> 11) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_12: " <<
      // ((LatCtrl_bfLCALeLaneSprsMask_mp
      // >> 12) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_13: " <<
      // ((LatCtrl_bfLCALeLaneSprsMask_mp >> 13) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCALeLaneSprsMask_mp_14:
      // "
      // << ((LatCtrl_bfLCALeLaneSprsMask_mp >> 14) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_flgLCARiLaneSprs_mp: " << LatCtrl_flgLCARiLaneSprs_mp;
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_0: " << (LatCtrl_bfLCARiLaneSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_1: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 1) &
      // 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_2: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >>
      // 2) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_3: " << ((LatCtrl_bfLCARiLaneSprsMask_mp
      // >> 3) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_4: " <<
      // ((LatCtrl_bfLCARiLaneSprsMask_mp
      // >> 4) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_5: " <<
      // ((LatCtrl_bfLCARiLaneSprsMask_mp >> 5) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_6: "
      // << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 6) & 1); INFO_LOG <<
      // "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_7: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 7) & 1); INFO_LOG
      // << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_8: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 8) & 1);
      // INFO_LOG
      // << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_9: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_10: " << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 10)
      // & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_11: " << ((LatCtrl_bfLCARiLaneSprsMask_mp
      // >> 11) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_12: " <<
      // ((LatCtrl_bfLCARiLaneSprsMask_mp
      // >> 12) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_13: " <<
      // ((LatCtrl_bfLCARiLaneSprsMask_mp >> 13) & 1); INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCARiLaneSprsMask_mp_14:
      // "
      // << ((LatCtrl_bfLCARiLaneSprsMask_mp >> 14) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_0: " << (Mtn_Plan_bfLCPrprActvSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_1: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_2: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_3: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_4: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_5: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_6: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_7: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_8: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 8) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_9: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_10: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 10) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_11: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 11) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_12: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 12) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_13: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 13) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_14: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 14) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_15: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 15) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_16: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 16) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_17: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 17) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_18: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 18) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_19: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 19) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_20: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 20) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_21: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 21) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_22: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 22) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_23: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 23) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_24: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 24) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_Mtn_Plan_bfLCPrprActvSprsMask_mp_25: "
      //          << ((Mtn_Plan_bfLCPrprActvSprsMask_mp >> 25) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_0: " << (LatCtrl_bfLCATakeOverSprsMask_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_1: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_2: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_3: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_4: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_5: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_6: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_7: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_8: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 8) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_9: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_10: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 10) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_11: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 11) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_12: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 12) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_13: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 13) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_14: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 14) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_15: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 15) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_16: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 16) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_17: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 17) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_18: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 18) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_19: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 19) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_20: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 20) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_21: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 21) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_22: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 22) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_23: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 23) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_24: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 24) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLCATakeOverSprsMask_mp_25: "
      //          << ((LatCtrl_bfLCATakeOverSprsMask_mp >> 25) & 1);

      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_0: " << (LatCtrl_bfLksSprs_mp & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_1: " << ((LatCtrl_bfLksSprs_mp >> 1) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_2: " << ((LatCtrl_bfLksSprs_mp >> 2) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_3: " << ((LatCtrl_bfLksSprs_mp >> 3) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_4: " << ((LatCtrl_bfLksSprs_mp >> 4) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_5: " << ((LatCtrl_bfLksSprs_mp >> 5) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_6: " << ((LatCtrl_bfLksSprs_mp >> 6) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_7: " << ((LatCtrl_bfLksSprs_mp >> 7) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_8: " << ((LatCtrl_bfLksSprs_mp >> 8) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_9: " << ((LatCtrl_bfLksSprs_mp >> 9) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_10: " << ((LatCtrl_bfLksSprs_mp >> 10) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_11: " << ((LatCtrl_bfLksSprs_mp >> 11) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_12: " << ((LatCtrl_bfLksSprs_mp >> 12) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_13: " << ((LatCtrl_bfLksSprs_mp >> 13) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_14: " << ((LatCtrl_bfLksSprs_mp >> 14) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_15: " << ((LatCtrl_bfLksSprs_mp >> 15) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_16: " << ((LatCtrl_bfLksSprs_mp >> 16) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_17: " << ((LatCtrl_bfLksSprs_mp >> 17) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_18: " << ((LatCtrl_bfLksSprs_mp >> 18) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_19: " << ((LatCtrl_bfLksSprs_mp >> 19) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_20: " << ((LatCtrl_bfLksSprs_mp >> 20) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_21: " << ((LatCtrl_bfLksSprs_mp >> 21) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_22: " << ((LatCtrl_bfLksSprs_mp >> 22) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_23: " << ((LatCtrl_bfLksSprs_mp >> 23) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_24: " << ((LatCtrl_bfLksSprs_mp >> 24) & 1);
      // INFO_LOG << "Fct_Fault_Log_alc_LatCtrl_bfLksSprs_mp_25: " << ((LatCtrl_bfLksSprs_mp >> 25) & 1);
    }
  }

  fct_debug_out.mutable_fim_debug_out()->add_alcs_fim(0);
  fct_debug_out.mutable_fim_debug_out()->set_alcs_fim(0, alcs_fault_flag);
  last_stctrllanechgreq_mp = stctrllanechgreq_mp;
  last_alcs_fault_flag     = alcs_fault_flag;

  // ELK/LKA/LDW
  static uint32_t elk_lka_ldw_fault_flag = 0;
  static float    elk_log_delay_time     = 0;

  static int last_elksts_      = 0;
  int        elksts_           = fctout.mutable_elk()->elksts();
  static int last_laneasststs_ = 0;
  int        laneasststs_      = fctout.mutable_ldw()->laneasststs();
  static int last_lkalnasststs = 0;
  int        lkalnasststs_     = fctout.mutable_latctrl()->lkalnasststs();

  if ((3 != last_elksts_ && 3 == elksts_) || (3 != last_laneasststs_ && 3 == laneasststs_)
      || (3 != last_lkalnasststs && 3 == lkalnasststs_)) {
    elk_lka_ldw_fault_flag = 1;
  }
  if (1 == elk_lka_ldw_fault_flag) {
    elk_log_delay_time += kFctStepTime;
    if (elk_log_delay_time > kHeroButtonTrigDelayTime_s) {
      elk_lka_ldw_fault_flag = 0;
      elk_log_delay_time     = 0;
    }
  } else {
    elk_lka_ldw_fault_flag = 0;
    elk_log_delay_time     = 0;
  }

  fct_debug_out.mutable_fim_debug_out()->set_lka_fault(0, elk_lka_ldw_fault_flag);
  last_elksts_      = elksts_;
  last_laneasststs_ = laneasststs_;
  last_lkalnasststs = lkalnasststs_;

  // eas
  static uint32_t eas_fault_flag     = 0;
  static float    eas_log_delay_time = 0;
  static int      last_eassts_       = 0;
  int             eassts_            = fctout.mutable_eas()->eassts();
  if (3 != last_eassts_ && 3 == eassts_) {
    eas_fault_flag = 1;
  }
  if (1 == eas_fault_flag) {
    eas_log_delay_time += kFctStepTime;
    if (eas_log_delay_time > kHeroButtonTrigDelayTime_s) {
      eas_fault_flag     = 0;
      eas_log_delay_time = 0;
    }
  } else {
    eas_fault_flag     = 0;
    eas_log_delay_time = 0;
  }

  fct_debug_out.mutable_fim_debug_out()->add_eas_fault(0);
  fct_debug_out.mutable_fim_debug_out()->set_eas_fault(0, eas_fault_flag);
  last_eassts_ = eassts_;

  // fct_fault_log_fim
  // for (size_t i = 0; i < DIAG_FIM_MAX_MASK_NUM; i++) {
  //   if (0 != gLkaFimByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gLkaFimByte"
  //              << "[" << i << "]: " << int(gLkaFimByte[i]);
  //   }

  //   if (0 != gLdwFimByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gLdwFimByte"
  //              << "[" << i << "]: " << int(gLdwFimByte[i]);
  //   }

  //   if (0 != gElkFimByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gElkFimByte"
  //              << "[" << i << "]: " << int(gElkFimByte[i]);
  //   }

  //   if (0 != gPilotNPByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gPilotNPByte"
  //              << "[" << i << "]: " << int(gPilotNPByte[i]);
  //   }

  //   if (0 != gEasFimByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gEasFimByte"
  //              << "[" << i << "]: " << int(gEasFimByte[i]);
  //   }

  //   if (0 != gAlcCamFimByte[i]) {
  //     INFO_LOG << "Fct_Fault_Log_Fim_gAlcCamFimByte"
  //              << "[" << i << "]: " << int(gAlcCamFimByte[i]);
  //   }
  // }
}

void appstate_debug_proc(nio::ad::messages::debug::FCTDebugOut& fct_debug_out, APP_state_e APP_state) {
  fct_debug_out.mutable_app_state_out()->set_app_state(
    static_cast<nio::ad::messages::debug::AppStateDebugOut_AppState>(APP_state));
}

void dainhibit_debug_proc(std::shared_ptr<nio::ad::messages::FctDaInhibit>& fctdainhibt, APP_state_e APP_state) {
  if ((APP_state == APP_state_e::Suspend) || (APP_state == APP_state_e::Failure)) {
    fctdainhibt->set_accsc_flgactprev_mp(0);
    fctdainhibt->set_accsc_uactprev_mp(0);
    fctdainhibt->set_accsc_uactprev1_mp(0);
    fctdainhibt->set_accsc_uactprev2_mp(0);
    fctdainhibt->set_accsc_uescfun_mp(0);
    fctdainhibt->set_accsc_flghardinh_mp(0);
    fctdainhibt->set_accsc_flgedastandby2actv_mp(0);
    fctdainhibt->set_accsc_uhardinh1_mp(0);
    fctdainhibt->set_accsc_uhardinh2_mp(0);
    fctdainhibt->set_accsc_uhardinh3_mp(0);
    fctdainhibt->set_accsc_uhardinh4_mp(0);
    fctdainhibt->set_accsc_ueastrghardinh1_mp(0);
    fctdainhibt->set_accsc_ueastrghardinh2_mp(0);
    fctdainhibt->set_accsc_ueastrginmannualmode_mp(0);
    fctdainhibt->set_da_topic_loss_comm(0);
    fctdainhibt->set_accsc_flgsoftinh_mp(0);
    fctdainhibt->set_accsc_uatndmdsoftinh1_mp(0);
    fctdainhibt->set_accsc_uatndmdsoftinh2_mp(0);
    fctdainhibt->set_accsc_utkovdmdsoftinh1_mp(0);
    fctdainhibt->set_accsc_utkovdmdsoftinh2_mp(0);
    fctdainhibt->set_accsc_utkovdmdsoftinh3_mp(0);
    fctdainhibt->set_accsc_ubrksysadsoftinh1_mp(0);
    fctdainhibt->set_accsc_ubrksysadsoftinh2_mp(0);
    fctdainhibt->set_accsc_udrvattntavlbadsoftinh_mp(0);
    fctdainhibt->set_accsc_ufimadsoftinh1_mp(0);
    fctdainhibt->set_accsc_ufimadsoftinh2_mp(0);
    fctdainhibt->set_accsc_ufimadsoftinh3_mp(0);
    fctdainhibt->set_accsc_uvehstbtdsoftinh1_mp(0);
    fctdainhibt->set_accsc_uvehstbtdsoftinh2_mp(0);
    fctdainhibt->set_accsc_ubrksystdsoftinh1_mp(0);
    fctdainhibt->set_accsc_ubrksystdsoftinh2_mp(0);
    fctdainhibt->set_accsc_udrvattntavlbtdsoftinh_mp(0);
    fctdainhibt->set_accsc_ufimtdsoftinh1_mp(0);
    fctdainhibt->set_accsc_ufimtdsoftinh2_mp(0);
    fctdainhibt->set_accsc_ufimtdsoftinh3_mp(0);
    fctdainhibt->set_accsc_ufimtdsoftinh4_mp(0);
    fctdainhibt->set_accsc_ufimtdsoftinh5_mp(0);
    fctdainhibt->set_accsc_utkovdmdcdcsts_mp(0);
    fctdainhibt->set_accsc_ufailsafetdsoftinh1_mp(0);
    fctdainhibt->set_accsc_uvehstbadsoftinh1_mp(0);
    fctdainhibt->set_accsc_uvehstbadsoftinh2_mp(0);
    fctdainhibt->set_accsc_flgsyspassive_mp(0);
    fctdainhibt->set_accsc_ucdnpassive_mp(0);
    fctdainhibt->set_accsc_unopsuppression_mp(0);
    fctdainhibt->set_accsc_unopactivationprevention_mp(0);
    fctdainhibt->set_latctrl_bflcatakeoversprsmask_mp(0);
    fctdainhibt->set_latctrl_bflkssprs_mp(0);
    fctdainhibt->set_hwasm_stdummy_mp(0);
    fctdainhibt->set_accsc_stfam_damainsts_mp(0);
    fctdainhibt->add_reserved(static_cast<double>(0));
  } else {
    fctdainhibt->set_accsc_flgactprev_mp(static_cast<uint32_t>(ACCSC_flgActPrev_mp));
    fctdainhibt->set_accsc_uactprev_mp(static_cast<uint32_t>(ACCSC_uActPrev_mp));
    fctdainhibt->set_accsc_uactprev1_mp(static_cast<uint32_t>(ACCSC_uActPrev1_mp));
    fctdainhibt->set_accsc_uactprev2_mp(static_cast<uint32_t>(ACCSC_uActPrev2_mp));
    fctdainhibt->set_accsc_uescfun_mp(static_cast<uint32_t>(ACCSC_uEscFun_mp));
    fctdainhibt->set_accsc_flghardinh_mp(static_cast<uint32_t>(ACCSC_flgHardInh_mp));
    fctdainhibt->set_accsc_flgedastandby2actv_mp(static_cast<uint32_t>(ACCSC_flgEDAStandby2Actv_mp));
    fctdainhibt->set_accsc_uhardinh1_mp(static_cast<uint32_t>(ACCSC_uHardInh1_mp));
    fctdainhibt->set_accsc_uhardinh2_mp(static_cast<uint32_t>(ACCSC_uHardInh2_mp));
    fctdainhibt->set_accsc_uhardinh3_mp(static_cast<uint32_t>(ACCSC_uHardInh3_mp));
    fctdainhibt->set_accsc_uhardinh4_mp(static_cast<uint32_t>(ACCSC_uHardInh4_mp));
    fctdainhibt->set_accsc_ueastrghardinh1_mp(static_cast<uint32_t>(ACCSC_uEASTrgHardInh1_mp));
    fctdainhibt->set_accsc_ueastrghardinh2_mp(static_cast<uint32_t>(ACCSC_uEASTrgHardInh2_mp));
    fctdainhibt->set_accsc_ueastrginmannualmode_mp(static_cast<uint32_t>(ACCSC_uEASTrgInMannualMode_mp));
    fctdainhibt->set_da_topic_loss_comm(static_cast<uint32_t>(gFctTopicLoss));
    fctdainhibt->set_accsc_flgsoftinh_mp(static_cast<uint32_t>(ACCSC_flgSoftInh_mp));
    fctdainhibt->set_accsc_uatndmdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uAtnDmdSoftInh1_mp));
    fctdainhibt->set_accsc_uatndmdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uAtnDmdSoftInh2_mp));
    fctdainhibt->set_accsc_utkovdmdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh1_mp));
    fctdainhibt->set_accsc_utkovdmdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh2_mp));
    fctdainhibt->set_accsc_utkovdmdsoftinh3_mp(static_cast<uint32_t>(ACCSC_uTkovDmdSoftInh3_mp));
    fctdainhibt->set_accsc_ubrksysadsoftinh1_mp(static_cast<uint32_t>(ACCSC_uBrkSysADSoftInh1_mp));
    fctdainhibt->set_accsc_ubrksysadsoftinh2_mp(static_cast<uint32_t>(ACCSC_uBrkSysADSoftInh2_mp));
    fctdainhibt->set_accsc_udrvattntavlbadsoftinh_mp(static_cast<uint32_t>(ACCSC_uDrvAttntAvlbADSoftInh_mp));
    fctdainhibt->set_accsc_ufimadsoftinh1_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh1_mp));
    fctdainhibt->set_accsc_ufimadsoftinh2_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh2_mp));
    fctdainhibt->set_accsc_ufimadsoftinh3_mp(static_cast<uint32_t>(ACCSC_uFimADSoftInh3_mp));
    fctdainhibt->set_accsc_uvehstbtdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uVehStbTDSoftInh1_mp));
    fctdainhibt->set_accsc_uvehstbtdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uVehStbTDSoftInh2_mp));
    fctdainhibt->set_accsc_ubrksystdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uBrkSysTDSoftInh1_mp));
    fctdainhibt->set_accsc_ubrksystdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uBrkSysTDSoftInh2_mp));
    fctdainhibt->set_accsc_udrvattntavlbtdsoftinh_mp(static_cast<uint32_t>(ACCSC_uDrvAttntAvlbTDSoftInh_mp));
    fctdainhibt->set_accsc_ufimtdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh1_mp));
    fctdainhibt->set_accsc_ufimtdsoftinh2_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh2_mp));
    fctdainhibt->set_accsc_ufimtdsoftinh3_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh3_mp));
    fctdainhibt->set_accsc_ufimtdsoftinh4_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh4_mp));
    fctdainhibt->set_accsc_ufimtdsoftinh5_mp(static_cast<uint32_t>(ACCSC_uFimTDSoftInh5_mp));
    fctdainhibt->set_accsc_utkovdmdcdcsts_mp(static_cast<uint32_t>(ACCSC_uTkovDmdCDCSts_mp));
    fctdainhibt->set_accsc_ufailsafetdsoftinh1_mp(static_cast<uint32_t>(ACCSC_uFailSafeTDSoftInh1_mp));
    fctdainhibt->set_accsc_uvehstbadsoftinh1_mp(static_cast<uint32_t>(ACCSC_uVehStbADSoftInh1_mp));
    fctdainhibt->set_accsc_uvehstbadsoftinh2_mp(static_cast<uint32_t>(ACCSC_uVehStbADSoftInh2_mp));
    fctdainhibt->set_accsc_flgsyspassive_mp(static_cast<uint32_t>(ACCSC_flgSysPassive_mp));
    fctdainhibt->set_accsc_ucdnpassive_mp(static_cast<uint32_t>(ACCSC_uCdnPassive_mp));
    fctdainhibt->set_accsc_unopsuppression_mp(static_cast<uint32_t>(ACCSC_uNOPSuppression_mp));
    fctdainhibt->set_accsc_unopactivationprevention_mp(static_cast<uint32_t>(ACCSC_uNOPActivationPrevention_mp));
    fctdainhibt->set_latctrl_bflcatakeoversprsmask_mp(static_cast<uint32_t>(LatCtrl_bfLCATakeOverSprsMask_mp));
    fctdainhibt->set_latctrl_bflkssprs_mp(static_cast<uint32_t>(LatCtrl_bfLksSprs_mp));
    fctdainhibt->set_hwasm_stdummy_mp(static_cast<uint32_t>(HWASM_Stdummy_mp));
    fctdainhibt->set_accsc_stfam_damainsts_mp(static_cast<uint32_t>(ACCSC_stFAM_DAMainSts_mp));
    fctdainhibt->add_reserved(static_cast<double>(0));
  }
}

void fct_debug_output_processing(nio::ad::messages::FctOut&                        fctout,
                                 nio::ad::messages::debug::FCTDebugOut&            fct_debug_out,
                                 std::shared_ptr<nio::ad::messages::FctDaInhibit>& fctdainhibt, APP_state_e APP_state,
                                 std::shared_ptr<planner::IOAdapter>& ioadapter) {
  accsa_debug_proc(fct_debug_out);
  accct_debug_proc(fct_debug_out);
  accsc_debug_proc(fct_debug_out);
  hwasm_debug_proc(fct_debug_out);
  hwa_debug_proc(fct_debug_out);
  latctrl_debug_proc(fct_debug_out);
  mtn_debug_proc(fct_debug_out);
  ldw_debug_proc(fct_debug_out);
  elkct_debug_proc(fct_debug_out);
  elkss_debug_proc(fct_debug_out);
  elkh_debug_proc(fct_debug_out);
  me_debug_proc(fct_debug_out);
  reserved_proc(fct_debug_out, APP_state, ioadapter);
  gonotifier_debug_proc(fct_debug_out);
  tl_gonotifier_debug_proc(fct_debug_out);
  fim_debug_proc(fctout, fct_debug_out);
  appstate_debug_proc(fct_debug_out, APP_state);
  dainhibit_debug_proc(fctdainhibt, APP_state);
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
