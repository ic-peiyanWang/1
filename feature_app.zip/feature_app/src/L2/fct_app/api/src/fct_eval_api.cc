#include <iostream>
#include "fct_eval_api.h"

using namespace std;
using namespace nio::ad::messages;
using nio::ad::messages::esd_np_feature;

namespace nio {
namespace ad {
namespace fctapp {

FctOut fct_eval_main(std::shared_ptr<nio::ad::messages::RadarSensor>             radar_data_in,                // input
                     std::shared_ptr<nio::ad::messages::ObjectsDetection>        vision_objects_in,            // input
                     std::shared_ptr<proto::CarInfo>                             fct_vehicle_input_in,         // input
                     std::shared_ptr<nio::ad::messages::RoadDetection>           road_detection_in,            // input
                     std::shared_ptr<proto::PerceptionObjects>                   fusion_object_in,             // input
                     std::shared_ptr<nio::ad::messages::EHYEvdOutputs>           ehy_evd_in,                   // input
                     std::shared_ptr<nio::ad::messages::EHYHaOutputs>            ehy_ha_in,                    // input
                     std::shared_ptr<nio::ad::messages::EHYLppOutputs>           ehy_lpp_in,                   // input
                     std::shared_ptr<nio::ad::messages::EHYRmeOutputs>           ehy_rme_in,                   // input
                     std::shared_ptr<nio::ad::messages::EHYTppOutputs>           ehy_tpp_in,                   // input
                     std::shared_ptr<nio::ad::messages::EHYTsiOutputs>           ehy_tsi_in,                   // input
                     std::shared_ptr<nio::ad::messages::EHYTseOutputs>           ehy_tse_in,                   // input
                     std::shared_ptr<nio::ad::messages::VehVariantCode>          var_code_info_in,             // input
                     std::shared_ptr<nio::ad::messages::AdasMap>                 AdasMap_info_in,              // input
                     std::shared_ptr<nio::ad::messages::CameraFimInfo>           fim_camera_info_in,           // input
                     std::shared_ptr<nio::ad::messages::FimCanInfo>              fim_can_info_in,              // input
                     std::shared_ptr<nio::ad::messages::FimSoftwareInfo>         fim_sw_info_in,               // input
                     std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>       fim_can_fea_info_in,          // input
                     std::shared_ptr<nio::ad::messages::PowerFimInfo>            fim_power_info_in,            // input
                     std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>       fim_mcu_soc_info_in,          // input
                     std::shared_ptr<nio::ad::messages::LidarFimInfo>            fim_lidar_info_in,            // input
                     std::shared_ptr<nio::ad::messages::DMS_DA>                  dms_da_info_in,               // input
                     std::shared_ptr<nio::ad::messages::DMS_Result>              dms_result_info_in,           // input
                     std::shared_ptr<nio::ad::messages::McuSystemFimInfo>        fim_mcu_sys_info_in,          // input
                     std::shared_ptr<nio::ad::messages::PerceptionFimInfo>       fim_perception_info_in,       // input
                     std::shared_ptr<nio::ad::messages::FunctionRequestBook>     func_arb_info_in,             // input
                     std::shared_ptr<nio::ad::messages::RoadDetection>           me_road_detection_in,         // input
                     std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> failsafe_lidar_info_in,       // input
                     std::shared_ptr<nio::ad::messages::FailSafeDetection>       failsafe_detection_in,        // input
                     std::shared_ptr<nio::ad::messages::ForceSideFeatures>       side_feature_in,              // input
                     std::shared_ptr<nio::ad::messages::IlluminanceFeatures>     vision_illuminance_info_in,   // input
                     std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo>  lidar_internalfault_info_in,  // input
                     std::shared_ptr<nio::ad::messages::NopSpeedLimitValue>      nop_speedlimitvalue_in,       // input
                     std::shared_ptr<planner::IOAdapter>                         ioadapter,
                     std::shared_ptr<nio::ad::messages::debug::FCTDebugOut>      fct_debugout_in,              // input
                     std::shared_ptr<nio::proto::PlannerEvaluation>              np_planner_eval_in,           // input
                     const apollo::cyber::Time                                   np_eval_timestamp_in,         // input
                     std::shared_ptr<nio::ad::messages::VehicleAdfFod>           veh_adf_fod_info_in           // input
) {

#if defined(__x86_Sim_debug_mode_defined__)
  ACCSC_IsSimulationOpen_C = 1;
#endif

  {
    fct_radar_data.push_back(radar_data_in);
    fct_vision_objects.push_back(vision_objects_in);
    fct_vehicle_input.push_back(fct_vehicle_input_in);
    fct_road_detection.push_back(road_detection_in);
    fct_fusion_object.push_back(fusion_object_in);
    fct_ehy_evd.push_back(ehy_evd_in);
    fct_ehy_ha.push_back(ehy_ha_in);
    fct_ehy_lpp.push_back(ehy_lpp_in);
    fct_ehy_rme.push_back(ehy_rme_in);
    fct_ehy_tpp.push_back(ehy_tpp_in);
    fct_ehy_tsi.push_back(ehy_tsi_in);
    fct_ehy_tse.push_back(ehy_tse_in);
    fct_var_code_info.push_back(var_code_info_in);
    AdasMap_info.push_back(AdasMap_info_in);
    fct_fim_camera_info.push_back(fim_camera_info_in);
    fct_fim_can_info.push_back(fim_can_info_in);
    fct_fim_sw_info.push_back(fim_sw_info_in);
    fct_fim_can_fea_info.push_back(fim_can_fea_info_in);
    fct_fim_power_info.push_back(fim_power_info_in);
    fct_fim_mcu_soc_info.push_back(fim_mcu_soc_info_in);
    fct_fim_lidar_info.push_back(fim_lidar_info_in);
    fct_dms_da_info.push_back(dms_da_info_in);
    fct_dms_result_info.push_back(dms_result_info_in);
    fct_fim_mcu_sys_info.push_back(fim_mcu_sys_info_in);
    fct_fim_perception_info.push_back(fim_perception_info_in);
    fct_func_arb_info.push_back(func_arb_info_in);
    fct_failsafe_lidar_info.push_back(failsafe_lidar_info_in);
    fct_failsafe_detection.push_back(failsafe_detection_in);
    fct_vision_illuminance_info.push_back(vision_illuminance_info_in);
    fct_lidar_internalfault_info.push_back(lidar_internalfault_info_in);
    NOP_speedlimitvalue.push_back(nop_speedlimitvalue_in);
    fct_veh_adf_fod_info.push_back(veh_adf_fod_info_in);
  }
  shared_ptr<VEH10ms>             m_latestVeh10ms                   = nullptr;
  shared_ptr<VEH50ms>             m_latestVeh50ms                   = nullptr;
  shared_ptr<IlluminanceFeatures> m_latest_vision_illuminance_info_ = vision_illuminance_info_in;
  shared_ptr<CanFeatureFimInfo>   m_latest_fim_can_fea_             = fim_can_fea_info_in;
  shared_ptr<proto::CarInfo>      m_veh_info                        = fct_vehicle_input_in;

  auto fctOut        = make_shared<FctOut>();
  auto esdout        = make_shared<esd_np_feature>();
  auto fct_debug_out = make_shared<FCTDebugOut>();
  auto fct_dlb_out   = make_shared<FCTDlbOut>();
  auto adapter       = make_shared<nio::planner::IOAdapter>();
  auto fctdainhibit  = make_shared<FctDaInhibit>();
  std::unique_ptr<nio::planner::sm_wrapper::StateMachineWrapper> state_machine_wrapper_ptr;
  state_machine_wrapper_ptr = std::make_unique<nio::planner::sm_wrapper::StateMachineWrapper>();

  auto planner_eval_out=make_shared<proto::PlannerEvaluation>();
  auto labellingmatch_ptr=std::make_shared<nio::ad::fctapp::LabellingMatch>(FLAGS_labelling_input_json_file);

  static APP_state_e fct_state = APP_state_e::FullActive;

  fct_diag_main(fim_camera_info_in, fim_can_info_in, fim_sw_info_in, fim_can_fea_info_in, fim_power_info_in,
                fim_mcu_sys_info_in, fim_mcu_soc_info_in, fim_lidar_info_in, fim_perception_info_in,
                failsafe_detection_in, failsafe_lidar_info_in, fct_vehicle_input_in);

  fct_input_processing(&fct_input_adapter_, adapter);

  // run state machine
  state_machine_wrapper_ptr->runStateMachine(adapter);
  fct_nopFuncStatus_output_processing(&da_statemachine_adapter, fct_state, adapter);
  state_machine_wrapper_ptr->output(adapter);

  fct_main(*m_latestVeh10ms, *m_latestVeh50ms, &fct_input_adapter_, *fctOut, *fct_debug_out, &da_statemachine_adapter, adapter);
  ahc_proc(*m_veh_info, *m_latest_vision_illuminance_info_);

  labellingmatch_ptr->labelmatch(ACCSC_stCutinTrgtIndx_mp, np_eval_timestamp_in);

  const auto& label_match_result = labellingmatch_ptr->getLabellingMatchResult();

  planner_eval_out->clear_behavior_keep_confusion_matrix();

  planner_eval_out->clear_time_meas();
  planner_eval_out->set_time_meas(static_cast<uint64>(np_eval_timestamp_in.ToNanosecond()));

  auto planner_eval_behaviorkeep=planner_eval_out->add_behavior_keep_confusion_matrix();

  planner_eval_behaviorkeep->set_tree_level(1);
  int true_positive = 0;
  int false_positive = 0;
  int true_negative = 0;
  int false_negative = 0;

  if(!label_match_result.keep_label_object_dict.empty()){
    for (const auto& [obstalce_id, predict_label] :
      label_match_result.keep_label_object_dict){
          if ((obstalce_id==ACCSC_stCutinTrgtIndx_mp||obstalce_id==ACCSC_numTgtObjIndexTar_mp||obstalce_id==ACCSC_numTgtObjIndexTar2_mp)&&predict_label.decision_type == DecisionType::YIELD){
            true_positive+=1;
          }
          if ((obstalce_id==ACCSC_stCutinTrgtIndx_mp||obstalce_id==ACCSC_numTgtObjIndexTar_mp||obstalce_id==ACCSC_numTgtObjIndexTar2_mp)&&predict_label.decision_type == DecisionType::NOT_YIELD){
            false_positive+=1;
          }
          if (obstalce_id!=ACCSC_stCutinTrgtIndx_mp&&obstalce_id!=ACCSC_numTgtObjIndexTar_mp&&obstalce_id!=ACCSC_numTgtObjIndexTar2_mp&&predict_label.decision_type == DecisionType::YIELD){
            false_negative+=1;
          }
          if (obstalce_id!=ACCSC_stCutinTrgtIndx_mp&&obstalce_id!=ACCSC_numTgtObjIndexTar_mp&&obstalce_id!=ACCSC_numTgtObjIndexTar2_mp&&predict_label.decision_type == DecisionType::NOT_YIELD){
            true_negative+=1;
          }
        }
  }

  planner_eval_behaviorkeep->set_true_positive(true_positive);
  planner_eval_behaviorkeep->set_false_positive(false_positive);
  planner_eval_behaviorkeep->set_true_negative(true_negative);
  planner_eval_behaviorkeep->set_false_negative(false_negative);

  WARN_LOG<<"true_positive:"<<planner_eval_behaviorkeep->true_positive()<<endl;
  WARN_LOG<<"false_positive:"<<planner_eval_behaviorkeep->false_positive()<<endl;
  WARN_LOG<<"true_negative:"<<planner_eval_behaviorkeep->true_negative()<<endl;
  WARN_LOG<<"false_negative:"<<planner_eval_behaviorkeep->false_negative()<<endl;

  WARN_LOG<<"label_match_result.keep_label_object_dict.size:"<<label_match_result.keep_label_object_dict.size()<<endl;

  ERROR_LOG<<"cutin_id:"<< static_cast<int>(ACCSC_stCutinTrgtIndx_mp) <<endl;

  fct_output_fill(*fctOut, *fct_debug_out, *fct_dlb_out, fct_state, *esdout, &da_statemachine_adapter, fctdainhibit, adapter);
  fct_evm_processing(m_latest_fim_can_fea_, *fctOut);
  fct_edr_processing(&veh_param, &nop_vehicleout, *fctOut);

  *fct_debugout_in = *fct_debug_out;
  *np_planner_eval_in = *planner_eval_out;
  return *fctOut;
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio