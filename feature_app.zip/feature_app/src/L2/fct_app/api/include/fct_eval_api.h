#pragma once
#include "fct_input_adapter.h"
#include "fct_out_proc.h"
#include "LongCtrl.h"
#include "np_labelling_match.h"
#include "common/proto/planner_evaluation.pb.h"
#include "state_machine/state_machine_wrapper.h"
#include "fct_in_proc.h"
#include "ahc_main.h"
#include "ahc_proc.h"
#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"
#include "common/esd/esd_np_feature.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "fct_diag.h"
#include "fct_edr_proc.h"
#include "fct_evm_proc.h"
#include "fct_main.h"
#include "ids_mil.h"
#include "planner/io_manager/io_adapter.h"


namespace nio {
namespace ad {
namespace fctapp {
extern FctOut
fct_eval_main(std::shared_ptr<nio::ad::messages::RadarSensor>             radar_data_in,                // input
              std::shared_ptr<nio::ad::messages::ObjectsDetection>        vision_objects_in,            // input
              std::shared_ptr<proto::CarInfo>                             fct_vehicle_input_in,         // input
              std::shared_ptr<nio::ad::messages::RoadDetection>           road_detection_in,            // input
              std::shared_ptr<proto::PerceptionObjects>                   fusion_object_in,             // input
              std::shared_ptr<nio::ad::messages::EHYEvdOutputs>           ehy_evd_in,                   // input
              std::shared_ptr<nio::ad::messages::EHYHaOutputs>            ehy_ha_in,                    // input
              std::shared_ptr<nio::ad::messages::EHYLppOutputs>           ehy_lpp_in,                   // input
              std::shared_ptr<nio::ad::messages::EHYRmeOutputs>           ehy_rme_in,                   // input
              std::shared_ptr<nio::ad::messages::EHYTppOutputs>           ehy_tpp_in,                   // input
              std::shared_ptr<nio::ad::messages::EHYTsiOutputs>           ehy_tsi_in,                   // input
              std::shared_ptr<nio::ad::messages::EHYTseOutputs>           ehy_tse_in,                   // input
              std::shared_ptr<nio::ad::messages::VehVariantCode>          var_code_info_in,             // input
              std::shared_ptr<nio::ad::messages::AdasMap>                 AdasMap_info_in,              // input
              std::shared_ptr<nio::ad::messages::CameraFimInfo>           fim_camera_info_in,           // input
              std::shared_ptr<nio::ad::messages::FimCanInfo>              fim_can_info_in,              // input
              std::shared_ptr<nio::ad::messages::FimSoftwareInfo>         fim_sw_info_in,               // input
              std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>       fim_can_fea_info_in,          // input
              std::shared_ptr<nio::ad::messages::PowerFimInfo>            fim_power_info_in,            // input
              std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>       fim_mcu_soc_info_in,          // input
              std::shared_ptr<nio::ad::messages::LidarFimInfo>            fim_lidar_info_in,            // input
              std::shared_ptr<nio::ad::messages::DMS_DA>                  dms_da_info_in,               // input
              std::shared_ptr<nio::ad::messages::DMS_Result>              dms_result_info_in,           // input
              std::shared_ptr<nio::ad::messages::McuSystemFimInfo>        fim_mcu_sys_info_in,          // input
              std::shared_ptr<nio::ad::messages::PerceptionFimInfo>       fim_perception_info_in,       // input
              std::shared_ptr<nio::ad::messages::FunctionRequestBook>     func_arb_info_in,             // input
              std::shared_ptr<nio::ad::messages::RoadDetection>           me_road_detection_in,         // input
              std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> failsafe_lidar_info_in,       // input
              std::shared_ptr<nio::ad::messages::FailSafeDetection>       failsafe_detection_in,        // input
              std::shared_ptr<nio::ad::messages::ForceSideFeatures>       side_feature_in,              // input
              std::shared_ptr<nio::ad::messages::IlluminanceFeatures>     vision_illuminance_info_in,   // input
              std::shared_ptr<nio::ad::messages::LidarInternalFaultInfo>  lidar_internalfault_info_in,  // input
              std::shared_ptr<nio::ad::messages::NopSpeedLimitValue>      nop_speedlimitvalue_in,       // input
              std::shared_ptr<planner::IOAdapter>                         ioadapter,
              std::shared_ptr<nio::ad::messages::debug::FCTDebugOut>      fct_debugout_in,              // input
              std::shared_ptr<nio::proto::PlannerEvaluation>              np_planner_eval_in,           // input
              const apollo::cyber::Time                                   np_eval_timestamp_in,         // input
              std::shared_ptr<nio::ad::messages::VehicleAdfFod>           veh_adf_fod_info_in           // input

);
}
}  // namespace ad
}  // namespace nio