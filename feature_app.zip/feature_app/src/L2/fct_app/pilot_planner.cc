#include <chrono>
#include "pilot_planner.h"
#include "io_manager/io_adapter.h"
#include "common/basics/macros.h"
#include "common/basics/trace_utils.h"
#include "dcs_param_interface.h"

using namespace std;
using namespace nio::ad::messages;
using nio::ad::messages::esd_np_feature;
bool flgEnaSimRunmode_x86_restore = false;

namespace nio {
namespace planner {
namespace {
std::map<uint8_t, std::pair<std::string, std::deque<nio::ncyber::TimeRecord>>> TimeRecordMap
{
  { 0, {"fct_vehicle_input_10_ID", {{0,0}}} },
  { 1, {"fct_vehicle_input_50_ID", {{0,0}}} },
  { 2,   {"fct_ehy_tse_ID", {{0,0}}} },
  { 3,   {"fct_ehy_tsi_ID", {{0,0}}} },
  { 4,   {"fct_ehy_tpp_ID", {{0,0}}} },
  { 5,   {"fct_ehy_lpp_ID", {{0,0}}} },
  { 6,   {"fct_ehy_rme_ID", {{0,0}}} },
  { 7,   {"fct_ehy_ha_ID", {{0,0}}} },
  { 8,   {"fct_ehy_evd_ID", {{0,0}}} },
  { 9,   {"fct_fusion_object_ID", {{0,0}}} },
  { 10,   {"fct_road_detection_ID", {{0,0}}} },
  { 11,   {"fct_vision_objects_ID", {{0,0}}} },
  { 12,   {"fct_radar_data_ID", {{0,0}}} },
  { 13,   {"fct_dms_result_ID", {{0,0}}} },
  { 14,   {"fct_veh_upa_ID", {{0,0}}} },
  { 15,   {"fct_fim_camera_ID", {{0,0}}} },
  { 16,   {"fct_fim_can_ID", {{0,0}}} },
  { 17,   {"fct_fim_sw_ID", {{0,0}}} },
  { 18,   {"fct_fim_can_fea_ID", {{0,0}}} },
  { 19,   {"fct_fim_power_ID", {{0,0}}} },
  { 20,   {"fct_fim_mcu_soc_ID", {{0,0}}} },
  { 21,   {"fct_fim_lidar_ID", {{0,0}}} },
  { 22,   {"fct_vision_failsafe_ID", {{0,0}}} },
  { 23,   {"fct_lidar_failsafe_ID", {{0,0}}} },
  { 24,   {"fct_fim_mcu_sys_ID", {{0,0}}} },
  { 25,   {"fct_NOP_CHASSIS_CTRL_TP_ID", {{0,0}}} },
  { 26,   {"fct_NOP_FUNCTIONSTATUS_TP_ID", {{0,0}}} },
  { 27,   {"fct_NOP_SCENEMGMT_TP_ID", {{0,0}}} },
  { 28,   {"fct_NOP_SPEEDLIMIT_TP_ID", {{0,0}}} },
  { 29,   {"fct_NOP_VEHICLE_TP_ID", {{0,0}}} },
  { 30,   {"fct_NOP_SPEED_TP_ID", {{0,0}}} },
};

}

using namespace nio::ad::fctapp;
using namespace nio::ad;


bool PilotPlanner::OnInit(std::shared_ptr<IOAdapter> adapter) {
  io_adapter_      = adapter;
  tau_gap_process  = std::make_unique<TauGapProcess>();
  speed_controller = std::make_unique<SpeedController>();
  sas_function     = std::make_unique<SasFunction>();
  if (!io_adapter_->init()) {
    AERROR << " io adapter init failed";
    return false;
  }
  state_machine_wrapper_ptr_ = std::make_unique<sm_wrapper::StateMachineWrapper>();
  // init state machine
  state_machine_wrapper_ptr_->init(adapter);

  // m_nop_powerswap_pilotstate_ =
  //   node->CreateReader<nio::ad::messages::PowerSwapPilotState>("common/nop/task_scheduler/power_swap_pilot_state");
  // m_pub           = node->CreateWriter<FctOut>("np/apps/fct_out");
  // m_pub           = node->CreateWriter<FctOut>("np/apps/fct_planner_out");
  // m_pub_fct_debug = node->CreateWriter<FCTDebugOut>("np/debug/dgb_fct");
  // m_pub_fct_dlb   = node->CreateWriter<FCTDlbOut>("np/apps/fct_dlb");
  // m_pub_esd       = node->CreateWriter<esd_np_feature>("common/esd/esd_np_feature");
  // m_pub_fct_da_inhibit = node->CreateWriter<nio::ad::messages::FctDaInhibit>("np/apps/fct_da_inhibit");

  m_latest_fim_camera_            = std::make_shared<nio::ad::messages::CameraFimInfo>(fim_camera_info_);
  m_latest_fim_can_               = std::make_shared<nio::ad::messages::FimCanInfo>(fim_can_info_);
  m_latest_fim_sw_                = std::make_shared<nio::ad::messages::FimSoftwareInfo>(fim_sw_info_);
  m_latest_fim_can_fea_           = std::make_shared<nio::ad::messages::CanFeatureFimInfo>(fim_can_fea_info_);
  m_latest_fim_power_             = std::make_shared<nio::ad::messages::PowerFimInfo>(fim_power_info_);
  m_latest_fim_mcu_soc_           = std::make_shared<nio::ad::messages::MCUWithSOCFimInfo>(fim_mcu_soc_info_);
  m_latest_fim_lidar_             = std::make_shared<nio::ad::messages::LidarFimInfo>(fim_lidar_info_);
  m_latest_fim_mcu_sys_           = std::make_shared<nio::ad::messages::McuSystemFimInfo>(fim_mcu_sys_info_);
  m_latest_fim_perception_        = std::make_shared<nio::ad::messages::PerceptionFimInfo>(fim_perception_info_);
  m_latestFailSafeDetection       = std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_vision_info_);
  m_latestLidar_FailSafeDetection = std::make_shared<nio::ad::messages::Lidar_FailSafeDetection>(failsafe_lidar_info_);
  // m_latest_failsafe_vision_calib_ = std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_vision_calib_);
  m_latest_vision_illuminance_info_ =
    std::make_shared<nio::ad::messages::IlluminanceFeatures>(vision_illuminance_info_);  // LOG FctApp Start time
  gFctAppStartTime = FCT_CURRENT_SEC;

  // Init features
  WARN_LOG << "Pre Init featuers";
  std::vector<std::string> intput_args = nio::ad::niodds::GetArguments();
  if (std::find(intput_args.begin(), intput_args.end(), "--elk-shadow-mode") != intput_args.end()) {
    LatCtrl_flgElkShadowMode_C = true;
    WARN_LOG << "ELK shadow mode active";
  } else {
    LatCtrl_flgElkShadowMode_C = false;
    WARN_LOG << "ELK in normal mode";
  }

  nio::ad::fctapp::fct_init();

#if defined(__aarch64_defined__)
  np_tsp_log.FaultTspLogInit("_fct_app");
#endif

  fct_state = APP_state_e::Init;

  WARN_LOG << "xcp init";
#ifdef FCT_XCP_ENABLED
  TcpServerStart(9999);
  xcp_if_init();
#endif


  char* restore_var = nullptr;
  restore_var = getenv("ENV_SIMULATION_MODE_RESTORE");
  if (nullptr != restore_var) {
    flgEnaSimRunmode_x86_restore = true;
  }


  WARN_LOG << "Post Init features";
  // m_interval = kDefaultInterval;  // set the app to run in 20hz by default
  // this value can be overriden by providing a manifest file to the launcher

  nop_initial_input_ = std::make_shared<NopOutput>();

  return true;
}

template <typename MsgType>
void GetLatest(const DataElement<MsgType>& input, 
               std::vector<std::shared_ptr<MsgType>>* latest_vec, std::shared_ptr<MsgType>* latest = nullptr,
               std::function<void(const MsgType&)> fn = std::function<void(const MsgType&)>()) {
  if (latest_vec->empty()) {
    latest_vec->push_back(nullptr);
  }
  auto observed = input.GetLatest();
  if ((*latest_vec)[0] != observed) {
    if (fn) {
      fn(*observed);
    }
    (*latest_vec)[0] = observed;
    if (latest != nullptr) {
      *latest = observed;
    }
  }
  if ((*latest_vec)[0] == nullptr) {
    latest_vec->clear();
  }
}

template <typename MsgType>
void GetLatest(const DataElement<MsgType>& input, std::deque<nio::ncyber::TimeRecord>& time_record,
               std::vector<std::shared_ptr<MsgType>>* latest_vec, std::shared_ptr<MsgType>* latest = nullptr,
               std::function<void(const MsgType&)> fn = std::function<void(const MsgType&)>()) {
  if (latest_vec->empty()) {
    latest_vec->push_back(nullptr);
  }
  auto observed = input.GetLatest(time_record);
  if ((*latest_vec)[0] != observed) {
    if (fn) {
      fn(*observed);
    }
    (*latest_vec)[0] = observed;
    if (latest != nullptr) {
      *latest = observed;
    }
  }
  if ((*latest_vec)[0] == nullptr) {
    latest_vec->clear();
  }
}

bool PilotPlanner::traceFctOutMsg(std::shared_ptr<FctOut>& fct_out) {
  // trace success frame only
  if (fct_ehy_tse.size() > 0 && (gFctTopicLoss & gTseTopicLossMask) == 0) {
    nio::common::TraceUtils::fillTraceFields(fct_ehy_tse.back(), fct_out, "fct_planner_out");
    return true;
  }
  return false;
}

bool PilotPlanner::restorePilotPlanner(std::shared_ptr<nio::proto::StateRestore> state_restore_data) {
  if (state_restore_data) {
    speed_controller->restoreSpeedControl(state_restore_data->mid_data());
    return true;
  } else {
    return false;
  }
}

void PilotPlanner::adaptReaderCallBack() {
  state_machine_wrapper_ptr_->adaptReaderCallBack(io_adapter_);
}

int32_t PilotPlanner::OnProc(const PncInputDataType& input, PncOutputDataType& output) {
  RECORD_IF_TIME_TOO_LONG(WARN, 50);
  auto now = std::chrono::steady_clock::now();
  auto period = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_call_ts_).count();
  last_call_ts_ = now;

  if (period < 30) {
    AWARN << "Timer Error, cur_time - last_time = " << period << " ms";
    return -1;
  }

#if not defined(IOADAPTER_USE_GLOBAL_BUFFER)
  constexpr std::array<const char*, 2> output_names{StateMachineOutputName, NpOutputName};
  StateMachineOutput* statemachine_output_buff=nullptr;
  NpOutput* np_output_buff=nullptr;

  get_all_data_ptrs_by_data_name(output, output_names.begin(), output_names.end(), statemachine_output_buff, np_output_buff);
  if (nullptr == statemachine_output_buff) {
    AERROR << "Buffer Error, get output buff failed for " << StateMachineOutputName;
    return -1;
  } 
  
  if (nullptr == np_output_buff) {
    AERROR << "Buffer Error, get output buff failed for " << NpOutputName;
    return -1;
  } 

  NopOutput* nop_output_buff=nullptr;
  if (!get_msg_ptr_by_name(&input, &nop_output_buff, NopOutputName)) {
    if(nop_initial_input_){
      AERROR << "use initial input buff for " << NopOutputName;
      nop_output_buff = nop_initial_input_.get();
    }else{
      AERROR << "Buffer Error, get input buff failed for " << NopOutputName;
      return -1;  
    }
  }

  adapter->SetMidOutputData(statemachine_output_buff, np_output_buff, nop_output_buff);
 #endif 

  // Read frames from subscribers
  // fct_conf_data.UpdateConf("fct_conf.pb.txt");
  const apollo::cyber::Time current_time = ncyber::Time::Now();
  DYBLOG_LINERAR_SCHED_RECORD(fct, current_time.ToNanosecond());

  std::function<void(const Features&)> fn(nio::ad::fctapp::vision_flag_proc);
  GetLatest(io_adapter_->getInputManager().m_subFeatureFlag, &m_featureFlag, &m_latestFeatureFlag, fn);
  GetLatest(io_adapter_->getInputManager().m_subFailSafe, TimeRecordMap[22].second, &fct_failsafe_detection, &m_latestFailSafeDetection);
  GetLatest(io_adapter_->getInputManager().m_subLidar_FailSafe, TimeRecordMap[23].second, &fct_failsafe_lidar_info, &m_latestLidar_FailSafeDetection);
  // GetLatest(io_adapter_->getInputManager().m_subVeh10ms, TimeRecordMap[0].second, &fct_vehicle_input_10, &m_latestVeh10ms);
  // GetLatest(io_adapter_->getInputManager().m_subVeh50ms, TimeRecordMap[1].second, &fct_vehicle_input_50, &m_latestVeh50ms);
  GetLatest(io_adapter_->getInputManager().car_info_, &fct_vehicle_input, &m_latestVeh);
  GetLatest(io_adapter_->getInputManager().m_sub_vision_object_, TimeRecordMap[11].second, &fct_vision_objects);
  GetLatest(io_adapter_->getInputManager().m_sub_radar_object_, TimeRecordMap[12].second, &fct_radar_data);
  GetLatest(io_adapter_->getInputManager().m_sub_road_detection_, TimeRecordMap[10].second, &fct_road_detection);
  // GetLatest(io_adapter_->getInputManager().m_sub_fusion_object_, TimeRecordMap[9].second, &fct_fusion_object);
  GetLatest(io_adapter_->getInputManager().objects_, &fct_fusion_object);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_evd_, TimeRecordMap[8].second, &fct_ehy_evd);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_ha_, TimeRecordMap[7].second, &fct_ehy_ha);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_lpp_, TimeRecordMap[5].second, &fct_ehy_lpp);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_rme_, TimeRecordMap[6].second, &fct_ehy_rme);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_tpp_, TimeRecordMap[4].second, &fct_ehy_tpp);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_tsi_, TimeRecordMap[3].second, &fct_ehy_tsi);
  GetLatest(io_adapter_->getInputManager().m_sub_ehy_tse_, TimeRecordMap[2].second, &fct_ehy_tse);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_camera_, TimeRecordMap[15].second, &fct_fim_camera_info, &m_latest_fim_camera_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_can_, TimeRecordMap[16].second, &fct_fim_can_info, &m_latest_fim_can_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_sw_, TimeRecordMap[17].second, &fct_fim_sw_info, &m_latest_fim_sw_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_can_fea_, TimeRecordMap[18].second, &fct_fim_can_fea_info, &m_latest_fim_can_fea_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_power_, TimeRecordMap[19].second, &fct_fim_power_info, &m_latest_fim_power_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_mcu_soc_, TimeRecordMap[20].second, &fct_fim_mcu_soc_info, &m_latest_fim_mcu_soc_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_lidar_, TimeRecordMap[21].second, &fct_fim_lidar_info, &m_latest_fim_lidar_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_mcu_sys_, TimeRecordMap[24].second, &fct_fim_mcu_sys_info, &m_latest_fim_mcu_sys_);
  GetLatest(io_adapter_->getInputManager().m_sub_fim_perception_, &fct_fim_perception_info, &m_latest_fim_perception_);
  GetLatest(io_adapter_->getInputManager().m_sub_dms_da_, &fct_dms_da_info);
  GetLatest(io_adapter_->getInputManager().m_sub_dms_result_, TimeRecordMap[13].second, &fct_dms_result_info);
  GetLatest(io_adapter_->getInputManager().m_sub_func_arb_, &fct_func_arb_info);
  GetLatest(io_adapter_->getInputManager().parking_out_, &fct_parkingout_info);
  GetLatest(io_adapter_->getInputManager().m_sub_veh_var_code_, &fct_var_code_info, &veh_var_code_out);
  //GetLatest(io_adapter_->getInputManager().m_SdMap_, &SdMap_info);
  GetLatest(io_adapter_->getInputManager().m_sub_adas_map_, &AdasMap_info);
  // GetLatest(io_adapter_->getInputManager().m_nop_vehicle_out_, &NOP_vehicleout);
  // GetLatest(io_adapter_->getInputManager().m_nop_chassis_ctrl_, &Nop_chassisctrl);
  // GetLatest(io_adapter_->getInputManager().m_nop_function_status_, &NopFunction_Status);
  GetLatest(io_adapter_->getInputManager().m_nop_speed_limit_value_, TimeRecordMap[28].second, &NOP_speedlimitvalue);
  // GetLatest(io_adapter_->getInputManager().m_nop_speed_, &NOP_speed);
  // GetLatest(io_adapter_->getInputManager().m_nop_scenemgmt_, &Nop_scenemgmt);
  GetLatest(io_adapter_->getInputManager().m_sub_vision_illuminance_, &fct_vision_illuminance_info,
            &m_latest_vision_illuminance_info_);
  GetLatest(io_adapter_->getInputManager().m_sub_lidar_internalfault_, &fct_lidar_internalfault_info);
  GetLatest(io_adapter_->getInputManager().m_sub_CfgTaskSwitch_, &fct_cfgtaskswitch_info);
  GetLatest(io_adapter_->getInputManager().m_FctsOut_, &FctsOut_info);
  GetLatest(io_adapter_->getInputManager().m_sub_adms_, &fct_adms_info);

  GetLatest(io_adapter_->getInputManager().global_localization_, &fct_global_locali_info);
  // GetLatest(io_adapter_->getInputManager().m_sub_hd_link_, &fct_hd_link_info);
  GetLatest(io_adapter_->getInputManager().m_sub_powerswap_pilotstate_, &fct_Nop_powerpilotstate);
  GetLatest(io_adapter_->getInputManager().ads_, &fct_ads_info);
  GetLatest(io_adapter_->getInputManager().m_sub_veh_adf_fod_, &fct_veh_adf_fod_info);

  auto& ins = dcs::DcsParamInterface::Instance();
  dcs::PlatformType platfrom_type = ins->GetPlatform();
  if (dcs::PlatformType::kNt3 == platfrom_type){
    io_adapter_->getMidOutputManager().setPlatformNt3Flag(true);
  }else{
    io_adapter_->getMidOutputManager().setPlatformNt3Flag(false);
  }
  
  
  if (flgEnaSimRunmode_x86_restore) {
    state_restore_data = io_adapter_->getInputManager().sim_mid_state_.GetLatest();
  }
  // Only pass the latest messages to fct_main, and it is also possible that multiple instances of same type of
  // messages have been received If need to check from inside fct_main about if there are additional messages
  // recevied in the current frame, do it like the following code snippets: auto& v50ms =
  // Application::GetInstance("FctApp").GetLastVeh50ms(); if(v50ms)
  //{
  //  //Process the two veh50ms messages together
  //}
  static bool    is_vehconf_uploaded      = false;
  static uint8_t vehconf_not_uploaded_cnt = 0;

  if (nullptr != veh_var_code_out && veh_var_code_out->has_variant_code_info()
      && veh_var_code_out->has_is_variant_code_valid() && is_vehconf_uploaded == false) {
    const auto& var_code_info         = veh_var_code_out->variant_code_info();
    const bool  is_variant_code_valid = veh_var_code_out->is_variant_code_valid();
    WARN_LOG << static_cast<uint32_t>(var_code_info.vehicle_project()) << "/n";
    int vehicle_project = 0;
    // felix: temp change for alps function test
    if (var_code_info.has_vehicle_project() && var_code_info.vehicle_project() <= 8) {
      vehicle_project = var_code_info.vehicle_project();
    } else {
      vehicle_project = 6;
      WARN_LOG << "use libra project's paramters as alps project's";
    }
    if (var_code_info.has_sales_region() && var_code_info.has_vehicle_project() && is_variant_code_valid
        && (vehicle_project == 1 || vehicle_project == 2
            || vehicle_project == 3 || vehicle_project == 4
            || vehicle_project == 5 || vehicle_project == 6
            || vehicle_project == 7 || vehicle_project == 8)) {
      WARN_LOG << "debug vehicle type   :  " << vehicle_project << "raw vehicle type" << var_code_info.vehicle_project();
      fct_conf_data.SetVehicleType(static_cast<VehProjectTyp_e>(vehicle_project));
      if (var_code_info.sales_region() == 2) {
        fct_conf_data.UpdateConf("fct_eu_conf.pb.txt");
        WARN_LOG << "Upload fct_eu_conf.pb.txt";
      } else if (var_code_info.sales_region() == 1) {
        fct_conf_data.UpdateConf("fct_cn_conf.pb.txt");
        WARN_LOG << "Upload fct_cn_conf.pb.txt";
      } else {
        AERROR << "sales_region error";
      }
      if (fct_conf_data.is_feature_conf_data_loaded() && fct_conf_data.is_mode_conf_loaded()
          && fct_conf_data.is_feature_conf_loaded()) {
        is_vehconf_uploaded = true;
      }
    }
    if (var_code_info.has_drive_hand()
        && var_code_info.drive_hand() == nio::ad::messages::VariantCodeInfo_DriveHandTyp_RIGHT_RUDDER) {
      IDS_flgIsLeftHandElk_C = 0;
      WARN_LOG_FIRST_N(3) << "ELK Right Rudder Active";
    } else {
      IDS_flgIsLeftHandElk_C = 1;
      WARN_LOG_FIRST_N(3) << "ELK Left Rudder Active";
    }
  }
  if (is_vehconf_uploaded == false) {
    vehconf_not_uploaded_cnt++;
  } else {
    vehconf_not_uploaded_cnt = 0;
  }

  // Alps/NT2 platform update
  if (nullptr != veh_var_code_out && veh_var_code_out->has_variant_code_info()
      && veh_var_code_out->variant_code_info().has_vehicle_brand()) {
    const auto& veh_brand = veh_var_code_out->variant_code_info().vehicle_brand();
    if (nio::ad::messages::VariantCodeInfo::ALPS == veh_brand) {
      io_adapter_->getMidOutputManager().setAlpsFlag(true);
    }
  }

  fct_state_lf = fct_state;
  fct_diag_main(m_latest_fim_camera_, m_latest_fim_can_, m_latest_fim_sw_, m_latest_fim_can_fea_, m_latest_fim_power_,
                m_latest_fim_mcu_sys_, m_latest_fim_mcu_soc_, m_latest_fim_lidar_, m_latest_fim_perception_,
                m_latestFailSafeDetection, m_latestLidar_FailSafeDetection, 
                m_latestVeh,io_adapter_->getMidOutputManager().getPlatformNt3Flag());
  fct_logout_losscom_time(TimeRecordMap, gFctTopicLoss,io_adapter_->getMidOutputManager().getPlatformNt3Flag());

  if (vehconf_not_uploaded_cnt > 200) {
    ERROR_LOG_FIRST_N(1) << "Parameter Upload Failure";
    fct_state                = APP_state_e::Failure;
    vehconf_not_uploaded_cnt = 201;
  } else {
    fct_state = APP_StateManage(gFctTopicNoInit, gFctInitMask, gFctTopicLoss, gFctLossMask);
  }

  if (fct_state_lf != fct_state) {
    WARN_LOG << "fct_app state transform : " << static_cast<uint32_t>(fct_state_lf) << " ->  "
             << static_cast<uint32_t>(fct_state);
  }


  auto&& fctOut = io_adapter_->getOutputManager().fctOut_.GetBuff();
  auto&& esdout = io_adapter_->getOutputManager().esdout_.GetBuff();
  auto&& fct_debug_out = io_adapter_->getOutputManager().fct_debug_out_.GetBuff();
  auto&& fct_dlb_out = io_adapter_->getOutputManager().fct_dlb_out_.GetBuff();
  auto&& fct_da_inhibit = io_adapter_->getOutputManager().fct_da_inhibit_.GetBuff();
  if (!fctOut) {
    ERROR_LOG << "get ouput buff failed for fctOut";
    return -1;
  }
  if (!esdout) {
    ERROR_LOG << "get ouput buff failed for esdout";
    return -1;
  }
  if (!fct_debug_out) {
    ERROR_LOG << "get ouput buff failed for fct_debug_out";
    return -1;
  }
  if (!fct_dlb_out) {
    ERROR_LOG << "get ouput buff failed for fct_dlb_out";
    return -1;
  }
  if (!fct_da_inhibit) {
    ERROR_LOG << "get ouput buff failed for fct_da_inhibit";
    return -1;
  }
  fctOut->Clear();
  esdout->Clear();
  fct_debug_out->Clear();
  fct_dlb_out->Clear();
  fct_da_inhibit->Clear();

  // FctOut default_fct_out;
  // FCTDebugOut default_fct_debug_out;

  if (fct_state == APP_state_e::Suspend) {
    WARN_LOG_N(3) << "Feature_app Suspend";
    state_machine_wrapper_ptr_->process(io_adapter_);
    // run state machine
    state_machine_wrapper_ptr_->runStateMachine(io_adapter_);
    state_machine_wrapper_ptr_->output(io_adapter_);
    // auto default_fct_out_ptr = make_shared<FctOut>(default_fct_out);
    // auto default_fct_debug_out_ptr = make_shared<FCTDebugOut>(default_fct_debug_out);
    fct_nopFuncStatus_output_processing(&da_statemachine_adapter, fct_state, io_adapter_);
    nio::ad::fctapp::fct_evm_default(*fctOut);
    nio::ad::fctapp::fct_output_fill(*fctOut, *fct_debug_out, *fct_dlb_out, fct_state, *esdout,
                                     &da_statemachine_adapter, fct_da_inhibit, io_adapter_);
    nio::ad::fctapp::fct_edr_default(*fctOut);
    nio::ad::fctapp::nop_fault_log(*fctOut, fct_state);
    nio::ad::fctapp::np_fault_log(*fctOut, fct_state, *fct_dlb_out);

    io_adapter_->getOutputManager().fctOut_.SetExportValid(true);
    // io_adapter_->getOutputManager().esdout_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_debug_out_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_dlb_out_.SetExportValid(true);
    // io_adapter_->getOutputManager().fct_da_inhibit_.SetExportValid(true);

  } else if ((fct_state == APP_state_e::PartialActive) || (fct_state == APP_state_e::FullActive)) {
    // auto ts = Time::Now();
    // DEBUG_LOG << "Calling Features";
    
    fct_conf_data.UpdateCalTable();
    fct_input_processing(&fct_input_adapter_, io_adapter_);
    state_machine_wrapper_ptr_->process(io_adapter_);
    fct_nop_trigger_processing(&da_statemachine_adapter, io_adapter_);
    fct_input_nop_trigger(&fct_input_adapter_, io_adapter_);
    // run state machine
    state_machine_wrapper_ptr_->runStateMachine(io_adapter_);
    fct_nopFuncStatus_output_processing(&da_statemachine_adapter, fct_state, io_adapter_);
    state_machine_wrapper_ptr_->output(io_adapter_);
    // run set speed
    fill_info_to_comm_proc(io_adapter_, is_vehconf_uploaded);

    if (!speed_controller->run(veh_drvr, io_adapter_)) {
      AERROR << "set speed run failed";
    }
    if (!sas_function->run(io_adapter_)) {
      AERROR << "sas func run failed";
    }
    if (!tau_gap_process->run(io_adapter_)) {
      AERROR << "tau gap run failed";
    }

    const auto& restore_function_request = io_adapter_->getMidOutputManager().getFuncStatus();

    if(flgEnaSimRunmode_x86_restore && restore_function_request == proto::FunctionRequest::REQ_RUNNING && io_adapter_->getRestoreSts()){
      flgEnaSimRunmode_x86_restore = !restorePilotPlanner(state_restore_data);
    }
    fill_comm_proc_info(&common_proc_info, io_adapter_);
    io_adapter_->midOutputAdapter();
    fct_main(*m_latestVeh10ms, *m_latestVeh50ms, &fct_input_adapter_, *fctOut, *fct_debug_out, &da_statemachine_adapter,
             io_adapter_);
    if (m_latest_vision_illuminance_info_ != nullptr) {
      ahc_proc(*m_latestVeh, *m_latest_vision_illuminance_info_);
    }
    fct_evm_processing(m_latest_fim_can_fea_, *fctOut);
    nio::ad::fctapp::fct_output_fill(*fctOut, *fct_debug_out, *fct_dlb_out, fct_state, *esdout,
                                     &da_statemachine_adapter, fct_da_inhibit, io_adapter_);
    fct_edr_processing(&veh_param, &nop_vehicleout, *fctOut);
    nio::ad::fctapp::nop_fault_log(*fctOut, fct_state);
    nio::ad::fctapp::np_fault_log(*fctOut, fct_state, *fct_dlb_out);
    if (io_adapter_->finalOutputAdapter(fctOut)) {
      AERROR << "final output adapter exec failed";
    }
    // trace success frame only
    traceFctOutMsg(fctOut);
    io_adapter_->getOutputManager().fctOut_.SetExportValid(true);
    // io_adapter_->getOutputManager().esdout_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_debug_out_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_dlb_out_.SetExportValid(true);
    // io_adapter_->getOutputManager().fct_da_inhibit_.SetExportValid(true);
    // DEBUG_LOG << "Cost: " << Time::Now() - ts << "ms";
#ifdef FCT_XCP_ENABLED
    xcp_if_service();
#endif
    // DEBUG_LOG << "Cost: " << Time::Now() - ts << "ms";
  } else if (fct_state == APP_state_e::Failure) {
    ERROR_LOG_N(3) << "Feature_app Failure";
    state_machine_wrapper_ptr_->process(io_adapter_);
    // run state machine
    state_machine_wrapper_ptr_->runStateMachine(io_adapter_);
    state_machine_wrapper_ptr_->output(io_adapter_);
    // auto default_fct_out_ptr = make_shared<FctOut>(default_fct_out);
    // auto default_fct_debug_out_ptr = make_shared<FCTDebugOut>(default_fct_debug_out);
    fct_nopFuncStatus_output_processing(&da_statemachine_adapter, fct_state, io_adapter_);
    nio::ad::fctapp::fct_evm_default(*fctOut);
    nio::ad::fctapp::fct_output_fill(*fctOut, *fct_debug_out, *fct_dlb_out, fct_state, *esdout,
                                     &da_statemachine_adapter, fct_da_inhibit, io_adapter_);
    nio::ad::fctapp::fct_edr_default(*fctOut);
    nio::ad::fctapp::nop_fault_log(*fctOut, fct_state);
    nio::ad::fctapp::np_fault_log(*fctOut, fct_state, *fct_dlb_out);
    io_adapter_->getOutputManager().fctOut_.SetExportValid(true);
    // io_adapter_->getOutputManager().esdout_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_debug_out_.SetExportValid(true);
    io_adapter_->getOutputManager().fct_dlb_out_.SetExportValid(true);
    // io_adapter_->getOutputManager().fct_da_inhibit_.SetExportValid(true);
  }

#if not defined(IOADAPTER_USE_GLOBAL_BUFFER)
  set_msg_valid_by_name(output, NpOutputName, np_output_buff, true);
  set_msg_valid_by_name(output, StateMachineOutputName, statemachine_output_buff, true);
#endif
  

  auto& start_time = now;
  auto end_time = std::chrono::steady_clock::now();

  auto cost_time = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
  if (cost_time > 100) {
    AWARN << "np time cost = " << cost_time << ", start - last_start = " << period;
  }
  return true;

}

void PilotPlanner::OnFinalize() {
  fct_state = APP_state_e::exit;
}

}  // namespace planner
}  // namespace nio
