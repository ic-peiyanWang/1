#ifndef RTW_HEADER_heater_h_
#define RTW_HEADER_heater_h_
#include <stddef.h>
#include <string.h>

#ifndef heater_COMMON_INCLUDES_
#define heater_COMMON_INCLUDES_
#include "fct_input_adapter.h"
#include "ids_mil.h"
#include "np/apps/fct_out.pb.h"
#endif // heater_COMMON_INCLUDES_

#include "fct_diag_interface.h"
// Child system includes

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm) ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val) ((rtm)->errorStatus = (val))
#endif

namespace nio {
namespace ad {
namespace fctapp {
class heaterModelClass {
public:

  heaterModelClass();

  ~heaterModelClass();

  void MainFunction();

  bool WSHeatReq = false;

  bool WSHeatReqValid = false;

  bool WSHeatTransSts = false;

private:
  void step();

  bool trigger();

  bool last_status = false;

  apollo::cyber::Time heater_start_time = apollo::cyber::Time(0.0);

  apollo::cyber::Time heater_stop_time = apollo::cyber::Time(0.0);

  apollo::cyber::Time heater_trans_start_time = apollo::cyber::Time(0.0);

  double heater_total_time = 0.0;
};

extern heaterModelClass adcheater;

} // namespace fctapp
} // namespace ad
} // namespace nio

#endif // RTW_HEADER_heater_h_