#include <iostream>
#include "heater.h"
#include "planner/flags/planner_gflags.h"

namespace nio {
namespace ad {
namespace fctapp {

namespace {
const double kMaxHeatTimeOnce  = FLAGS_max_heat_once_time * 60;
const double kMinIntervalTime  = FLAGS_min_heat_interval_time * 60;
const double kMaxHeatTimeTotal = FLAGS_max_heat_total_time * 60;
const double kWSHeatTransStsKeepTime = FLAGS_wsheattranssts_keep_time;
}  // namespace

heaterModelClass::heaterModelClass() {
  WSHeatReq               = false;
  WSHeatReqValid          = false;
  WSHeatTransSts          = false;
  last_status             = false;
  heater_start_time       = apollo::cyber::Time(0.0);
  heater_stop_time        = apollo::cyber::Time(0.0);
  heater_trans_start_time = apollo::cyber::Time(0.0);
  heater_total_time       = 0.0;
}
heaterModelClass::~heaterModelClass() {}

bool heaterModelClass::trigger() {
  if (fct_fim_can_fea_info.empty()) {
    return false;
  }
  if (fct_fim_can_fea_info.back()->bcm_feature_fim_info().fim_adas_wsheaterror_bcm()
      || fct_fim_can_fea_info.back()->ccu_feature_fim_info().fim_chs1_ccu_ambtempvalid_invalid()) {
    return false;
  }
  if (veh_body.AmbTemp > 20) {
    return false;
  }
  if (vision_failsafe.frontcam_failsafe.failsafe_FW.FS_Full_Blockage != 3
      && !(vision_failsafe.frontcam_failsafe.failsafe_FW.FS_Full_Blockage == 1
           && static_cast<int>(veh_pt.Gear.ActGear) == 3)) {
    return false;
  }
  const auto current_time = ncyber::Time::Now();
  if (heater_start_time != apollo::cyber::Time(0.0)
      && (current_time - heater_start_time).ToSecond() >= kMaxHeatTimeOnce) {
    return false;
  }
  if (heater_stop_time != apollo::cyber::Time(0.0) && (current_time - heater_stop_time).ToSecond() < kMinIntervalTime) {
    return false;
  }
  if (heater_total_time >= kMaxHeatTimeTotal) {
    return false;
  }
  if (heater_start_time != apollo::cyber::Time(0.0)
      && heater_total_time + (current_time - heater_start_time).ToSecond() >= kMaxHeatTimeTotal) {
    return false;
  }
  return true;
}

void heaterModelClass::step() {

  bool current_status = trigger();
  const auto current_time = ncyber::Time::Now();
  if (!last_status && current_status) {
    heater_start_time = current_time;
    heater_trans_start_time = current_time;
  }
  if (last_status && !current_status) {
    heater_stop_time  = current_time;
    heater_total_time += (current_time - heater_start_time).ToSecond();
    heater_start_time = apollo::cyber::Time(0.0);
  }
  WSHeatReq               = current_status;
  WSHeatReqValid          = current_status;
  WSHeatTransSts = (current_time - heater_stop_time).ToSecond() < kWSHeatTransStsKeepTime;
  last_status = current_status;
}

void heaterModelClass::MainFunction() {
  step();
}

heaterModelClass adcheater;
}  // namespace fctapp
}  // namespace ad
}  // namespace nio
