#include "fct_diag_interface.h"

FctDiagIf fct_diag_interface;
FctFim fct_fim;