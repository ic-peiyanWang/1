#include "fct_diag.h"
#include "basics/log_utils.h"
#include "ids_mil.h"
#include "planner/flags/planner_gflags.h"

namespace nio {
namespace ad {
namespace fctapp {
FimFault_e gLkaFaultSt;
FimFault_e gLdwFaultSt;
FimFault_e gElkFaultSt;
FimFault_e gAHCFaultSt;
FimFault_e gAHCPassiveSt;
FimFault_e gPilotNPFaultSt;
FimFault_e gPilotRadfcFaultSt;
FimFault_e gPilotRadfsFaultSt;
FimFault_e gPilotRadrsFaultSt;
FimFault_e gPilotCamfsFaultSt;
FimFault_e gPilotCamrsFaultSt;
FimFault_e gPilotCanBusOffFaultSt;
FimFault_e gHeaterFaultSt;
FimFault_e gGoNotifyUSSFaultSt;
FimFault_e gGoNotifySysFaultSt;
FimFault_e gGoNotifyFailSafeSt;
FimFault_e gTLGoNotifyFailSafeSt;
FimFault_e gDAFailSafeTDSts;
FimFault_e gALCCamFaultSts;
FimFault_e gALCRadFaultSts;
FimFault_e gALCFailSafeSupSts;
FimFault_e gEasFaultSts;
FimFault_e gEasLgtFaultSts;
FimFault_e gEasLatFaultSts;
FimFault_e gNOPFaultSts;
FimFault_e gNOPFailSafeSupSts;
// FimFault_e gAAappIntFaultSts;
FimFault_e gPSPFaultSt;

T_FS gFWFailsafe;
T_FS gFNFailsafe;
T_FS gLidarFailsafe;
T_FS gFLFailsafe;
T_FS gFRFailsafe;
T_FS gRrFailsafe;
T_FS gRLFailsafe;
T_FS gRRFailsafe;
T_FS gSVCFtFailsafe;
T_FS gSVCRrFailsafe;
T_FS gSVCLftFailsafe;
T_FS gSVCRgtFailsafe;

extern std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>      fct_radar_data;
extern std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>> fct_vision_objects;
extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>    fct_road_detection;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>    fct_ehy_evd;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>     fct_ehy_ha;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>    fct_ehy_lpp;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>    fct_ehy_rme;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>>    fct_ehy_tpp;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>>    fct_ehy_tsi;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>    fct_ehy_tse;
extern std::vector<std::shared_ptr<nio::ad::messages::DMS_Result>>       fct_dms_result_info;

nio::ad::DiagFim      fct_fim_diag;
nio::ad::DiagFailsafe fct_failsafe_diag;

TopicStatus topic_status[DIAG_MAX_TP_NUM];

// timestamps unit is ns, fct_app run time is 50ms, threshold set as 10ms
// const uint64_t P_TsLossCommThres = 10000;
uint32_t           gFctTopicNoInit            = 0;
uint32_t           gFctTopicLoss              = 0;
uint8_t            gFctDiagCycleCount         = 0;
uint32_t           gTseTopicLossMask          = 0x04;

const FltThreshold FltConfig[DIAG_MAX_TP_NUM] = {
  { 0, 5, 1, 2 },  /*0*    fct_vehicle_input_10_ID*/
  { 0, 5, 1, 2 },  /*1*    fct_vehicle_input_50_ID*/
  { 0, 5, 1, 2 },  /*2*    fct_ehy_tse_ID*/
  { 0, 5, 1, 2 },  /*3*    fct_ehy_tsi_ID*/
  { 0, 5, 1, 2 },  /*4*    fct_ehy_tpp_ID*/
  { 0, 5, 1, 2 },  /*5*    fct_ehy_lpp_ID*/
  { 0, 5, 1, 2 },  /*6*    fct_ehy_rme_ID*/
  { 0, 5, 1, 2 },  /*7*    fct_ehy_ha_ID*/
  { 0, 5, 1, 2 },  /*8*    fct_ehy_evd_ID*/
  { 0, 5, 1, 2 },  /*9*    fct_fusion_object_ID*/
  { 0, 5, 1, 2 },  /*10*   fct_road_detection_ID*/
  { 0, 5, 1, 2 },  /*11*   fct_vision_objects_ID*/
  { 0, 5, 1, 2 },  /*12*   fct_radar_data_ID*/
  { 0, 5, 1, 2 },  /*13*   fct_dms_result_ID*/
  { 0, 5, 1, 2 },  /*14*   fct_veh_upa_ID*/
  { 0, 10, 1, 3 }, /*15*   fct_fim_camera_ID*/
  { 0, 10, 1, 3 }, /*16*   fct_fim_can_ID*/
  { 0, 10, 1, 3 }, /*17*   fct_fim_sw_ID*/
  { 0, 10, 1, 3 }, /*18*   fct_fim_can_fea_ID*/
  { 0, 10, 1, 3 }, /*19*   fct_fim_power_ID*/
  { 0, 10, 1, 3 }, /*20*   fct_fim_mcu_soc_ID*/
  { 0, 10, 1, 3 }, /*21*   fct_fim_lidar_ID*/
  { 0, 10, 1, 3 }, /*22*   fct_vision_failsafe_ID*/
  { 0, 10, 1, 4 }, /*23*   fct_lidar_failsafe_ID*/
  { 0, 10, 1, 3 }, /*24*   fct_fim_mcu_sys_ID*/
  { 0, 5, 1, 2 },  /*25*   fct_NOP_CHASSIS_CTRL_TP_ID*/
  { 0, 5, 1, 2 },  /*26*   fct_NOP_FUNCTIONSTATUS_TP_ID*/
  { 0, 5, 1, 2 },  /*27*   fct_NOP_SCENEMGMT_TP_ID*/
  { 0, 8, 1, 2 },  /*28*   fct_NOP_SPEEDLIMIT_TP_ID*/
  { 0, 8, 1, 3 },  /*29*   fct_NOP_VEHICLE_TP_ID*/
  { 0, 16, 1, 3 }, /*30*   fct_NOP_SPEED_TP_ID*/
};

uint64_t gFctAppStartTime = 0;
uint64_t FctAppRunTime    = 0;

void fct_update_fim(nio::ad::DiagFim&                                            fim_table,
                    const std::shared_ptr<nio::ad::messages::CameraFimInfo>&     fim_camera_info,
                    const std::shared_ptr<nio::ad::messages::FimCanInfo>&        fim_can_info,
                    const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&   fim_sw_info,
                    const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                    const std::shared_ptr<nio::ad::messages::PowerFimInfo>&      fim_power_info,
                    const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&  fim_mcu_sys_info,
                    const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>& fim_mcu_soc_info,
                    const std::shared_ptr<nio::ad::messages::LidarFimInfo>&      fim_lidar_info,
                    const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>& fim_perception_info) {
  fim_table.FimEncoder(fim_camera_info, fim_can_info, fim_sw_info, fim_can_fea_info, fim_power_info, fim_mcu_sys_info,
                       fim_mcu_soc_info, fim_lidar_info, fim_perception_info);
}

FimFault_e update_function_fault_status(nio::ad::DiagFim& fim_table, uint8_t (&rev_fim)[DIAG_FIM_MAX_MASK_NUM],
                                        uint8_t (&rev_mask)[DIAG_FIM_MAX_MASK_NUM]) {
  bool is_rev_fault = false;
  for (uint8_t iter = 0; iter < DIAG_FIM_MAX_MASK_NUM; iter++) {
    rev_fim[iter] = fim_table.get_relative_fim_byte(rev_mask[iter], iter);
    is_rev_fault |= (rev_fim[iter] != 0U ? true : false);
  }
  if (true == is_rev_fault) {
    return FimFault_e::RevFault;
  } else {
    return FimFault_e::NoFault;
  }
}

bool update_platform_fault_status() {
  // fim_byte_t_ = fct_fim_diag.get_relative_fim_byte(0x11, fct_fim_diag.fim_encoder_byte[0]);
  return true;
}

void fct_diag_main(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&           fim_camera_info,
                   const std::shared_ptr<nio::ad::messages::FimCanInfo>&              fim_can_info,
                   const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&         fim_sw_info,
                   const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>&       fim_can_fea_info,
                   const std::shared_ptr<nio::ad::messages::PowerFimInfo>&            fim_power_info,
                   const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&        fim_mcu_sys_info,
                   const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>&       fim_mcu_soc_info,
                   const std::shared_ptr<nio::ad::messages::LidarFimInfo>&            fim_lidar_info,
                   const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>&       fim_perception_info,
                   const std::shared_ptr<nio::ad::messages::FailSafeDetection>&       failsafe_vision_info,
                   const std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>& failsafe_lidar_info,
                   const std::shared_ptr<proto::CarInfo>&                             veh_info,
                   const bool                                                         isPlatformNt3) {

  // TODO: Update structure: topic status
  {
    // update_topic_status(fct_vehicle_input_10, topic_status[DIAG_VEH10MS_TP_ID], FltConfig[DIAG_VEH10MS_TP_ID]);
    // update_topic_status(fct_vehicle_input_50, topic_status[DIAG_VEH50MS_TP_ID], FltConfig[DIAG_VEH50MS_TP_ID]);
    update_topic_status_nop_veh10(fct_vehicle_input, topic_status[DIAG_VEH10MS_TP_ID], FltConfig[DIAG_VEH10MS_TP_ID]);
    update_topic_status_nop_veh50(fct_vehicle_input, topic_status[DIAG_VEH50MS_TP_ID], FltConfig[DIAG_VEH50MS_TP_ID]);
    update_topic_status(fct_ehy_tse, topic_status[DIAG_EHY_TSE_TP_ID], FltConfig[DIAG_EHY_TSE_TP_ID]);
    update_topic_status(fct_ehy_tsi, topic_status[DIAG_EHY_TSI_TP_ID], FltConfig[DIAG_EHY_TSI_TP_ID]);
    update_topic_status(fct_ehy_tpp, topic_status[DIAG_EHY_TPP_TP_ID], FltConfig[DIAG_EHY_TPP_TP_ID]);
    // update_topic_status(fct_ehy_lpp, topic_status[DIAG_EHY_LPP_TP_ID], FltConfig[DIAG_EHY_LPP_TP_ID]);
    update_topic_status(fct_ehy_rme, topic_status[DIAG_EHY_RME_TP_ID], FltConfig[DIAG_EHY_RME_TP_ID]);
    update_topic_status(fct_ehy_ha, topic_status[DIAG_EHY_HA_TP_ID], FltConfig[DIAG_EHY_HA_TP_ID]);
    update_topic_status(fct_ehy_evd, topic_status[DIAG_EHY_EVD_TP_ID], FltConfig[DIAG_EHY_EVD_TP_ID]);
    // update_topic_status(fct_fusion_object, topic_status[DIAG_EHY_FUSION_TP_ID], FltConfig[DIAG_EHY_FUSION_TP_ID]);
    update_topic_status_nop_sub(fct_fusion_object, topic_status[DIAG_EHY_FUSION_TP_ID], FltConfig[DIAG_EHY_FUSION_TP_ID]);
    update_topic_status(fct_road_detection, topic_status[DIAG_ROAD_DETECT_ID], FltConfig[DIAG_ROAD_DETECT_ID]);
    update_topic_status(fct_vision_objects, topic_status[DIAG_VISION_TP_ID], FltConfig[DIAG_VISION_TP_ID]);
    update_topic_status(fct_radar_data, topic_status[DIAG_RADAR_TP_ID], FltConfig[DIAG_RADAR_TP_ID]);
    update_topic_status(fct_dms_result_info, topic_status[DIAG_DMS_RESULT_ID], FltConfig[DIAG_DMS_RESULT_ID]);
    update_topic_status(fct_fim_camera_info, topic_status[DIAG_FIM_CAMERA_ID], FltConfig[DIAG_FIM_CAMERA_ID]);
    update_topic_status(fct_fim_can_info, topic_status[DIAG_FIM_CAN_ID], FltConfig[DIAG_FIM_CAN_ID]);
    update_topic_status(fct_fim_sw_info, topic_status[DIAG_FIM_SW_ID], FltConfig[DIAG_FIM_SW_ID]);
    update_topic_status(fct_fim_can_fea_info, topic_status[DIAG_FIM_CAN_FEA_ID], FltConfig[DIAG_FIM_CAN_FEA_ID]);
    update_topic_status(fct_fim_power_info, topic_status[DIAG_FIM_POWER_ID], FltConfig[DIAG_FIM_POWER_ID]);
    update_topic_status(fct_fim_mcu_soc_info, topic_status[DIAG_FIM_MCU_SOC_ID], FltConfig[DIAG_FIM_MCU_SOC_ID]);
    update_topic_status(fct_fim_lidar_info, topic_status[DIAG_FIM_LIDAR_ID], FltConfig[DIAG_FIM_LIDAR_ID]);
    update_topic_status(fct_failsafe_detection, topic_status[DIAG_VISION_FAILSAFE_ID],
                        FltConfig[DIAG_VISION_FAILSAFE_ID]);
    update_topic_status(fct_failsafe_lidar_info, topic_status[DIAG_LIDAR_FAILSAFE_ID],
                        FltConfig[DIAG_LIDAR_FAILSAFE_ID]);
    update_topic_status(fct_fim_mcu_sys_info, topic_status[DIAG_FIM_MCU_SYS_ID], FltConfig[DIAG_FIM_MCU_SYS_ID]);
    // update_topic_status(Nop_chassisctrl, topic_status[DIAG_NOP_CHASSIS_CTRL_TP_ID],
    //                     FltConfig[DIAG_NOP_CHASSIS_CTRL_TP_ID]);
    // update_topic_status(NopFunction_Status, topic_status[DIAG_NOP_FUNCTIONSTATUS_TP_ID],
    //                     FltConfig[DIAG_NOP_FUNCTIONSTATUS_TP_ID]);
    // update_topic_status(Nop_scenemgmt, topic_status[DIAG_NOP_SCENEMGMT_TP_ID], FltConfig[DIAG_NOP_SCENEMGMT_TP_ID]);
    update_topic_status(NOP_speedlimitvalue, topic_status[DIAG_NOP_SPEEDLIMIT_TP_ID],
                        FltConfig[DIAG_NOP_SPEEDLIMIT_TP_ID]);
    // update_topic_status(NOP_speed, topic_status[DIAG_NOP_SPEED_TP_ID], FltConfig[DIAG_NOP_SPEED_TP_ID]);
    // update_topic_status(NOP_vehicleout, topic_status[DIAG_NOP_VEHICLE_TP_ID], FltConfig[DIAG_NOP_VEHICLE_TP_ID]);

    static uint32_t last_gFctTopicNoInit = 0;
    static uint32_t last_gFctTopicLoss   = 0;
    gFctTopicNoInit                      = Diag_InitOutput(topic_status, DIAG_MAX_TP_NUM);
    gFctTopicLoss                        = Diag_FailedOutput(topic_status, DIAG_MAX_TP_NUM);
    if (last_gFctTopicNoInit != gFctTopicNoInit) {
      WARN_LOG << "gFctTopicNoInit: " << gFctTopicNoInit;
    }
    if (last_gFctTopicLoss != gFctTopicLoss) {
      WARN_LOG << "gFctTopicLoss: " << gFctTopicLoss;
    }
    last_gFctTopicNoInit = gFctTopicNoInit;
    last_gFctTopicLoss   = gFctTopicLoss;

    // Run time in second
    FctAppRunTime = FCT_CURRENT_SEC - gFctAppStartTime;

    // NT2ADD-4414
    // Vision app init checking only in gVsnInitCheckWindow(300s) after fct_app startup
    // After gVsnInitCheckWindow(300s) this flag will be set as "READY"
    // then loss comm check shall lead function into "FAILURE"
    if ((gFctTopicNoInit & gVsnNoReadyMask) == 0 || FctAppRunTime > gVsnInitCheckWindow) {
      fct_diag_interface.is_vision_no_ready = false;
    } else {
      fct_diag_interface.is_vision_no_ready = true;
    }

    if (topic_status[DIAG_VEH10MS_TP_ID].DiaStatus != DiagStatus_e::NoFault
        || topic_status[DIAG_VEH50MS_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
      fct_diag_interface.is_vehicle_input_loss_comm = true;
    } else {
      fct_diag_interface.is_vehicle_input_loss_comm = false;
    }
    if (topic_status[DIAG_EHY_TSE_TP_ID].DiaStatus != DiagStatus_e::NoFault
        || topic_status[DIAG_EHY_TSI_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
      fct_diag_interface.is_ehy_target_loss_comm = true;
    } else {
      fct_diag_interface.is_ehy_target_loss_comm = false;
    }
    if (topic_status[DIAG_EHY_TPP_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
      fct_diag_interface.is_ehy_traj_loss_comm = true;
    } else {
      fct_diag_interface.is_ehy_traj_loss_comm = false;
    }
    // NT2ADD-2245
    if (topic_status[DIAG_EHY_RME_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
      fct_diag_interface.is_ehy_rme_loss_comm = true;
    } else {
      fct_diag_interface.is_ehy_rme_loss_comm = false;
    }

    // [NIOP-2683] remove radar topic for 1orin
    if (isPlatformNt3) {
      gELKLossMask = 0x403;
      gDALossMask  = 0x45F;
      fct_diag_interface.is_vison_radar_loss_comm = false;
    } else {
      if (topic_status[DIAG_RADAR_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
        fct_diag_interface.is_vison_radar_loss_comm = true;
      } else {
        fct_diag_interface.is_vison_radar_loss_comm = false;
      }
    }

    // add by miles
    if (topic_status[DIAG_NOP_CHASSIS_CTRL_TP_ID].DiaStatus != DiagStatus_e::NoFault) {
      fct_diag_interface.is_NOP_chassctrl_loss_comm = true;
    } else {
      fct_diag_interface.is_NOP_chassctrl_loss_comm = false;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gLKALossMask) == 0) {
      fct_diag_interface.is_LKA_TopicFault = false;
    } else {
      fct_diag_interface.is_LKA_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gLDWLossMask) == 0) {
      fct_diag_interface.is_LDW_TopicFault = false;
    } else {
      fct_diag_interface.is_LDW_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gELKLossMask) == 0) {
      fct_diag_interface.is_ELK_TopicFault = false;
    } else {
      fct_diag_interface.is_ELK_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gAHCLossMask) == 0) {
      fct_diag_interface.is_AHC_TopicFault = false;
    } else {
      fct_diag_interface.is_AHC_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gDALossMask) == 0) {
      fct_diag_interface.is_DA_TopicFault = false;
    } else {
      fct_diag_interface.is_DA_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & giACCLossMask) == 0) {
      fct_diag_interface.is_iACC_TopicFault = false;
    } else {
      fct_diag_interface.is_iACC_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gEASLossMask) == 0) {
      fct_diag_interface.is_EAS_TopicFault = false;
    } else {
      fct_diag_interface.is_EAS_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gSASLossMask) == 0) {
      fct_diag_interface.is_SAS_TopicFault = false;
    } else {
      fct_diag_interface.is_SAS_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gHeaterLossMask) == 0) {
      fct_diag_interface.is_Heater_TopicFault = false;
    } else {
      fct_diag_interface.is_Heater_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gGoNotifyLossMask) == 0) {
      fct_diag_interface.is_GoNotify_TopicFault = false;
    } else {
      fct_diag_interface.is_GoNotify_TopicFault = true;
    }
    if (((gFctTopicNoInit | gFctTopicLoss) & gNOPLossMask) == 0) {
      fct_diag_interface.is_NOP_TopicFault = false;
    } else {
      fct_diag_interface.is_NOP_TopicFault = true;
    }
  };

  // TODO: Update structure : FIM process
  {
    fct_update_fim(fct_fim_diag, fim_camera_info, fim_can_info, fim_sw_info, fim_can_fea_info, fim_power_info,
                   fim_mcu_sys_info, fim_mcu_soc_info, fim_lidar_info, fim_perception_info);
    gLkaFaultSt = update_function_fault_status(fct_fim_diag, gLkaFimByte, kGlobLkaMskByte);
    gLdwFaultSt = update_function_fault_status(fct_fim_diag, gLdwFimByte, kGlobLdwMskByte);
    if (IDS_flgIsLeftHandElk_C == 0) {
      gElkFaultSt = update_function_fault_status(fct_fim_diag, gElkRiRudderFimByte, kGlobElkRiRudderMskByte);
    } else {
      gElkFaultSt = update_function_fault_status(fct_fim_diag, gElkFimByte, kGlobElkMskByte);
    }
    gAHCFaultSt         = update_function_fault_status(fct_fim_diag, gAHCFaultFimByte, kGlobAHCFaultMskByte);
    gAHCPassiveSt       = update_function_fault_status(fct_fim_diag, gAHCPassiveFimByte, kGlobAHCPassiveMskByte);
    gGoNotifyUSSFaultSt = update_function_fault_status(fct_fim_diag, gGoNotifyUSSFimByte, kGlobGoNotifyUSSMskByte);
    gGoNotifySysFaultSt = update_function_fault_status(fct_fim_diag, gGoNotifySysFimByte, kGlobGoNotifySysMskByte);
    gPilotNPFaultSt     = update_function_fault_status(fct_fim_diag, gPilotNPByte, kGlobPilotNPMskByte);
    gALCCamFaultSts     = update_function_fault_status(fct_fim_diag, gAlcCamFimByte, kGlobAlcCamMskByte);
    gALCRadFaultSts     = update_function_fault_status(fct_fim_diag, gAlcRadFimByte, kGlobAlcRadMskByte);

    gEasFaultSts = update_function_fault_status(fct_fim_diag, gEasFimByte, kGlobEasMskByte);
    // gEasLgtFaultSts     = update_function_fault_status(fct_fim_diag, gEasLgtFimByte, kGlobEasLgtMskByte);
    // gEasLatFaultSts     = update_function_fault_status(fct_fim_diag, gEasLatFimByte, kGlobEasLatMskByte);
    gHeaterFaultSt = update_function_fault_status(fct_fim_diag, gHeaterFimByte, kGlobHeaterMskByte);
    gNOPFaultSts   = update_function_fault_status(fct_fim_diag, gNOPFimByte, kGlobNOPMskByte);
    // gAAappIntFaultSts = update_function_fault_status(fct_fim_diag, gAAappInterFimByte, kGlobAAIntErrMskByte);
    gPSPFaultSt = update_function_fault_status(fct_fim_diag, gPSPFimByte, kGlobPSPMskByte);

    // NT2ADD-7486
    if ((fct_diag_interface.is_vision_no_ready == false && gLdwFaultSt == FimFault_e::NoFault)
        || FctAppRunTime > gLdwFimInitCheckWindow) {
      fct_diag_interface.is_ldw_fim_no_ready = false;
    } else {
      fct_diag_interface.is_ldw_fim_no_ready = true;
    }
    if ((fct_diag_interface.is_vision_no_ready == false && gLkaFaultSt == FimFault_e::NoFault)
        || FctAppRunTime > gLkaFimInitCheckWindow) {
      fct_diag_interface.is_lka_fim_no_ready = false;
    } else {
      fct_diag_interface.is_lka_fim_no_ready = true;
    }
    if ((fct_diag_interface.is_vision_no_ready == false && gElkFaultSt == FimFault_e::NoFault)
        || FctAppRunTime > gElkFimInitCheckWindow) {
      fct_diag_interface.is_elk_fim_no_ready = false;
    } else {
      fct_diag_interface.is_elk_fim_no_ready = true;
    }

    fct_fim.da_np_fim.is_np_fault            = gPilotNPFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.da_np_fim.is_vcuvehdispspd_fault = gPilotNPByte[20] & 0x02;                   // REQ: DA-20210712-03 [RMM-20221221-06]
    fct_fim.da_np_fim.is_aba_fault           = gPilotNPByte[95] & 0x20;                   // REQ: DA-20210712-10
    fct_fim.da_np_fim.is_abp_fault           = gPilotNPByte[95] & 0x40;                   // REQ: DA-20210712-11
    fct_fim.da_np_fim.is_brkoverheat_fault   = gPilotNPByte[95] & 0x80;                   // REQ: DA-20210712-26
    fct_fim.da_np_fim.is_vdctcsfail_fault    = gPilotNPByte[14] & 0x10;                   // REQ: DA-20210712-31
    fct_fim.da_np_fim.is_hodsensor_fault     = gPilotNPByte[92] & 0x08;                   // REQ: DA-20210817-02
    fct_fim.da_np_fim.is_eps_fault = gPilotNPByte[17] & 0x38 || gPilotNPByte[49] & 0x3C;  // REQ: RMM-20221222-10
    fct_fim.da_np_fim.is_acm_fault = gPilotNPByte[1] & 0xFF;                              // REQ: DA-20210929-05
    fct_fim.da_np_fim.is_bcm_fault = gPilotNPByte[9] & 0xFF || gPilotNPByte[10] & 0xFF || gPilotNPByte[11] & 0x01
                                     || gPilotNPByte[121] & 0x01;  // REQ: DA-20210929-06
    fct_fim.da_np_fim.is_bcu_fault = gPilotNPByte[12] & 0xFF || gPilotNPByte[13] & 0xE7 || gPilotNPByte[14] & 0x07
                                     || gPilotNPByte[36] & 0x3F;                            // REQ: DA-20210929-07
    fct_fim.da_np_fim.is_scm_fault   = gPilotNPByte[30] & 0x8F || gPilotNPByte[31] & 0x03;  // REQ: DA-20210929-08
    fct_fim.da_np_fim.is_can_bus_off = gPilotNPByte[40] & 0x1B;                             // REQ: DA-20210929-09
    fct_fim.da_np_fim.is_cdc_fault   = gPilotNPByte[41] & 0x6F || gPilotNPByte[42] & 0x7D || gPilotNPByte[43] & 0xFE
                                     || gPilotNPByte[44] & 0x9F;  // REQ: DA-20210929-10
    fct_fim.da_np_fim.is_vcu_fault =
      gPilotNPByte[20] & 0x08 || gPilotNPByte[34] & 0xFF || gPilotNPByte[35] & 0x31;      // REQ: DA-20210930-01
    fct_fim.da_np_fim.is_swc_fault = gPilotNPByte[32] & 0x7F;                             // REQ: DA-20210930-02
    fct_fim.da_np_fim.is_dms_fault = gPilotNPByte[24] & 0x04 || gPilotNPByte[98] & 0x20;  // REQ: DA-20210930-04
    fct_fim.da_np_fim.is_f30_fault =
      gPilotNPByte[24] & 0x08 || gPilotNPByte[59] & 0x01 || gPilotNPByte[67] & 0x10;  // REQ: DA-20210930-05
    fct_fim.da_np_fim.is_f120_fault = gPilotNPByte[24] & 0x01 || gPilotNPByte[58] & 0x80 || gPilotNPByte[67] & 0x08
                                      || gPilotNPByte[92] & 0x04;  // REQ: DA-20210930-06   DA-20211230-20
    fct_fim.da_np_fim.is_gnss_fault = gPilotNPByte[56] & 0x48;     // REQ: DA-20210930-07
    fct_fim.da_np_fim.is_lidar_fault =
      gPilotNPByte[45] & 0x03 || gPilotNPByte[62] & 0x01 || gPilotNPByte[70] & 0x02;  // REQ: DA-20210930-08
    // fct_fim.da_np_fim.is_lidar_overheating = gPilotNPByte[46] & 0x03;                 // DA-20220126-01
    // fct_fim.da_np_fim.is_lidar_blocked     = gPilotNPByte[45] & 0x3C;                 // DA-20220411-03
    fct_fim.da_np_fim.is_radfc_fault =
      gPilotNPByte[19] & 0x80 || gPilotNPByte[40] & 0x08 || gPilotNPByte[54] & 0x01;  // REQ: DA-20210930-09 [RMM-20221221-03]
    fct_fim.da_np_fim.is_power_fault = gPilotNPByte[26] & 0x00 || gPilotNPByte[27] & 0x00 || gPilotNPByte[28] & 0x00
                                       || gPilotNPByte[29] & 0x00;                            // REQ: DA-20210930-16
    fct_fim.da_np_fim.is_soc1adp_fault = gPilotNPByte[154] & 0x01;                            // REQ: DA-20210930-17
    fct_fim.da_np_fim.is_soc2dcb_fault = false;                                               // REQ: DA-20210930-18
    fct_fim.da_np_fim.is_soc3adb_fault = gPilotNPByte[74] & 0x08 || gPilotNPByte[154] & 0x04; // REQ: DA-20210930-19
    fct_fim.da_np_fim.is_soc4ads_fault = gPilotNPByte[74] & 0x00;                             // REQ: DA-20210930-20
    fct_fim.da_np_fim.is_apa_fault     = gPilotNPByte[2] & 0xFF || gPilotNPByte[3] & 0xFF || gPilotNPByte[4] & 0x00
                                     || gPilotNPByte[5] & 0x00 || gPilotNPByte[6] & 0xD4
                                     || gPilotNPByte[7] & 0x00;                                  // REQ: DA-20210930-22
    fct_fim.da_np_fim.is_awb_fault        = gPilotNPByte[14] & 0x08;                             // REQ: DA-20210930-23
    fct_fim.da_np_fim.is_bgw_fault        = gPilotNPByte[37] & 0xE0 || gPilotNPByte[38] & 0x4C;  // REQ: DA-20211119-19
    fct_fim.da_np_fim.is_failsafefc_fault = gPilotNPByte[64] & 0x60 || gPilotNPByte[74] & 0x80;  // REQ: DA-20211130-01
    fct_fim.da_np_fim.is_failsafelidar_fault = gPilotNPByte[90] & 0x01;                          // REQ: DA-20211130-03
    fct_fim.da_np_fim.is_othercan_fault = gPilotNPByte[48] & 0x05 || gPilotNPByte[62] & 0x02;    // REQ: DA-20211230-02
    fct_fim.da_np_fim.is_aaapp_fault = gPilotNPByte[156] & 0x01;                                 // REQ: DA-20211230-03
    fct_fim.da_np_fim.is_percepapp_fault = gPilotNPByte[61] & 0x20 || gPilotNPByte[153] & 0x02;  // REQ: DA-20211230-04
    fct_fim.da_np_fim.is_svc_fault       = false;                                       // NT2ADD-6285
    // gPilotNPByte[24] & 0x80 || gPilotNPByte[59] & 0x80 || gPilotNPByte[68] & 0x08;  // REQ: DA-20211230-06
    fct_fim.da_np_fim.is_mcu_fault = gPilotNPByte[97] & 0x01;  //[RMM-20221221-08]
      // gPilotNPByte[71] & 0x80 || gPilotNPByte[72] & 0x01 || gPilotNPByte[97] & 0x21;  // REQ: DA-20211230-07
    fct_fim.da_np_fim.is_windcalibra_fault     = gPilotNPByte[70] & 0x04;             // REQ: DA-20211230-20
    fct_fim.da_np_fim.is_DaAdClassified_fault  = gPilotNPByte[111] & 0x40;
    fct_fim.da_np_fim.is_DaTdClassified_fault  = gPilotNPByte[111] & 0x20;
    fct_fim.da_np_fim.is_DaEasClassified_fault = gPilotNPByte[111] & 0x01;
    fct_fim.da_np_fim.is_DaLatCtrl_Suppress    = gPilotNPByte[111] & 0x04;

    fct_fim.da_np_fim.is_radfs_fault = gPilotRadfsFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.da_np_fim.is_radrs_fault = gPilotRadrsFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.da_np_fim.is_camfs_fault = gPilotCamfsFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.da_np_fim.is_camrs_fault = gPilotCamrsFaultSt != FimFault_e::NoFault ? true : false;
    // DA-20220227-03
    fct_fim.is_AAapp_da_internal_fault.Stop_Vehicle_Standstil           = gPilotNPByte[111] & 0x01;
    fct_fim.is_AAapp_da_internal_fault.Deactivate_Function              = gPilotNPByte[111] & 0x02;
    fct_fim.is_AAapp_da_internal_fault.Lateral_Control_Suppression      = gPilotNPByte[111] & 0x04;
    fct_fim.is_AAapp_da_internal_fault.Longitudinal_Control_Suppression = gPilotNPByte[111] & 0x08;
    fct_fim.is_AAapp_da_internal_fault.Attention_Warning                = gPilotNPByte[111] & 0x40;
    fct_fim.is_AAapp_da_internal_fault.Takeover_Warning                 = gPilotNPByte[111] & 0x20;
    // DA-20220227-02
    fct_fim.is_AAapp_nop_internal_fault.Stop_Vehicle_Standstil           = 0;//gPilotNPByte[110] & 0x01;
    fct_fim.is_AAapp_nop_internal_fault.Deactivate_Function              = 0;//gPilotNPByte[110] & 0x02;
    fct_fim.is_AAapp_nop_internal_fault.Lateral_Control_Suppression      = gPilotNPByte[110] & 0x04;
    fct_fim.is_AAapp_nop_internal_fault.Longitudinal_Control_Suppression = 0;//gPilotNPByte[110] & 0x08;
    fct_fim.is_AAapp_nop_internal_fault.Attention_Warning                = gPilotNPByte[110] & 0x40;
    fct_fim.is_AAapp_nop_internal_fault.Takeover_Warning                 = gPilotNPByte[110] & 0x20;

    fct_fim.da_np_fim.is_frontCam_lidar_fault = gPilotNPByte[62] & 0x61 || gPilotNPByte[67] & 0x18
                                                || gPilotNPByte[45] & 0x03
                                                || gPilotNPByte[70] & 0x02
                                                || gPilotNPByte[24] & 0x09;  // REQ: DA-20220411-01

    fct_fim.da_np_fim.is_lidar_overheating_ad   = gPilotNPByte[46] & 0x03;    // REQ: DA-20220411-02
    fct_fim.da_np_fim.is_lidar_overheating = gPilotNPByte[96] & 0x02;     // REQ: DA-20220126-01
    fct_fim.da_np_fim.is_lidar_blocked       = gPilotNPByte[45] & 0x04;   // REQ: DA-20220411-03
    fct_fim.da_np_fim.is_dms_camera_occluded = gPilotNPByte[121] & 0x02;  // REQ: DA-20220302-01b
    fct_fim.da_np_fim.is_lidar_abnormal_sts  = gPilotNPByte[129] & 0x01;  // REQ: DA-20220614-01
    fct_fim.da_np_fim.is_critical_failure    = gPilotNPByte[21] & 0x01 || gPilotNPByte[73] & 0x80 ||
                                               gPilotNPByte[100] & 0x14 || gPilotNPByte[128] & 0x06
                                               || gPilotNPByte[155] & 0x01;  // [RMF-20221221-01]
    fct_fim.da_np_fim.is_perception_error = gPilotNPByte[156] & 0x14;      //[RMM-20221222-05]
    fct_fim.da_np_fim.is_critical_app_exited_abnormal = gPilotNPByte[21] & 0x14 ||
                                                        gPilotNPByte[100] & 0x03 ||
                                                        gPilotNPByte[101] & 0x04 ||
                                                        gPilotNPByte[128] & 0x08;  //[RMM-20221221-05]
    fct_fim.da_np_fim.is_critical_app_failure_cruising = gPilotNPByte[128] & 0x08; //[RMM-20230102-01]
    fct_fim.da_np_fim.is_fim_lidar_abnormal_status = gPilotNPByte[129] & 0x01; //[RMM-20230427-01]
    fct_fim.da_np_fim.is_fim_chs1_eps1_adcacioravl = gPilotNPByte[49] & 0x02; //[DA-20210825-01] new added

    // camera issue
    fct_fim.da_np_fim.is_camera_data_issue =
      gPilotNPByte[91] & 0x03 || gPilotNPByte[59] & 0x06 || gPilotNPByte[25] & 0x06;
    fct_fim.da_np_fim.is_camera_failsafe = false;

    // psp
    fct_fim.psp_fim.is_rad_fault      = gPSPFimByte[50] & 0x81 || gPSPFimByte[51] & 0x81 ||
                                        gPSPFimByte[52] & 0x81 || gPSPFimByte[53] & 0x81;  //[DA-20220610-10] [RMM-20221222-04]
    fct_fim.psp_fim.is_chs1_bcm_fault = gPSPFimByte[10] & 0xE0 || gPSPFimByte[11] & 0x01;  //[DA-20220610-11]
    fct_fim.psp_fim.is_camera_fault   = gPSPFimByte[67] & 0xE0 || gPSPFimByte[68] & 0x21 || gPSPFimByte[60] & 0xF2
                                      || gPSPFimByte[24] & 0x10 || gPSPFimByte[25] & 0x1E;  //[DA-20220610-12]
    fct_fim.psp_fim.is_svc_fault = gPSPFimByte[68] & 0x1E || gPSPFimByte[63] & 0x78 || gPSPFimByte[24] & 0xE0
                                   || gPSPFimByte[25] & 0x01;  //[DA-20220610-14]
    fct_fim.psp_fim.is_camera_data_error = gPSPFimByte[60] & 0xF0;

    fct_fim.psp_fim.apa_fim.is_vhe_upa_msglost = false;
    fct_fim.psp_fim.apa_fim.is_apa_can_error   = gPSPFimByte[3] & 0x80;
    fct_fim.psp_fim.apa_fim.is_upasys_invalid  = false;
    fct_fim.psp_fim.apa_fim.is_snsrflt_invalid = false;
    fct_fim.psp_fim.apa_fim.is_upasys_service_fault = false;
    fct_fim.psp_fim.apa_fim.is_upasys_disable       = false;
    fct_fim.psp_fim.apa_fim.is_apasts_failure       = false;
    fct_fim.psp_fim.apa_fim.is_apa_adc_msgerror     = gPSPFimByte[3] & 0x7F || gPSPFimByte[2] & 0xE0;
    fct_fim.psp_fim.apa_fim.is_apa_msgerror         = gPSPFimByte[2] & 0x1F;
    fct_fim.psp_fim.apa_fim.is_slot_msgerror        = gPSPFimByte[4] & 0x01;
    fct_fim.psp_fim.apa_fim.is_slot_obj1_msgerror = gPSPFimByte[4] & 0x02;
    fct_fim.psp_fim.apa_fim.is_slot_obj2_msgerror = false;
    fct_fim.psp_fim.apa_fim.is_sdwsts_invalid = false;
    fct_fim.psp_fim.map_loc_app_exited_abnormal = gPSPFimByte[128] & 0x20;
    fct_fim.psp_fim.psp_internal_error_deactivate_function = gPSPFimByte[129] & 0x2;
    fct_fim.psp_fim.psp_internal_error_takeover_warning = gPSPFimByte[129] & 0x00;
    fct_fim.psp_fim.is_perception_issue = gPSPFimByte[129] & 0x04;
    fct_fim.psp_fim.is_critical_app_failure_psp = gPSPFimByte[156] & 0x02;                // [RMM-20230102-02]
    fct_fim.psp_fim.is_epb_error_psp = gPSPFimByte[15] & 0x32 || gPSPFimByte[16] & 0x06;  // [RMM-20221222-07]
    fct_fim.psp_fim.is_critical_app_fault_psp = gPSPFimByte[128] & 0x10;                  // [RMM-20221222-11]
    fct_fim.psp_fim.is_psp_specific_system_issue = gPSPFimByte[156] & 0x08;               // [RMM-20221222-06]

    //NT2ADR-3847
    fct_fim.is_radar_fim_msgerror = gNOPFimByte[50] & 0xFF || gNOPFimByte[51] & 0xFF ||
                                    gNOPFimByte[52] & 0xFF || gNOPFimByte[53] & 0xFF;     // [NOP-20220504-02-B]
  }
  // TODO: Update structure: Failsafe process
  {
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fw(), gFWFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fn(), gFNFailsafe);
    fct_failsafe_diag.lidar_FailsafeEncoder(failsafe_lidar_info->failsafe(), gLidarFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fl(), gFLFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fr(), gFRFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_r(), gRrFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_rl(), gRLFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_rr(), gRRFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_svc_front(), gSVCFtFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_svc_rear(), gSVCRrFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_svc_left(), gSVCLftFailsafe);
    fct_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_svc_right(), gSVCRgtFailsafe);

    if (((gFWFailsafe.high & kFailsafeMskByte) == 0) && ((gFNFailsafe.high & kFailsafeMskByte) == 0)) {
      gGoNotifyFailSafeSt = FimFault_e::NoFault;
    } else {
      gGoNotifyFailSafeSt = FimFault_e::RevFault;
    }

    if (((gFWFailsafe.high & kFailsafeMskByte) == 0) && ((gFNFailsafe.high & kFailsafeMskByte) == 0)) {
      gTLGoNotifyFailSafeSt = FimFault_e::NoFault;
    } else {
      gTLGoNotifyFailSafeSt = FimFault_e::RevFault;
    }

    if (((gFWFailsafe.high & kFailsafeMskByte) == 0) && ((gFNFailsafe.high & kFailsafeMskByte) == 0)
        && ((gLidarFailsafe.high & kLidarFailsafeMskByte) == 0)) {
      gDAFailSafeTDSts = FimFault_e::NoFault;
    } else {
      gDAFailSafeTDSts = FimFault_e::RevFault;  //[NT2ADD-3191]changed Lidar Vision Failsafe Soft inhibit from AD to TD.
    }
    if (((gFLFailsafe.high & kFailsafeMskByte) == 0) && ((gFRFailsafe.high & kFailsafeMskByte) == 0)
        && ((gRrFailsafe.high & kFailsafeMskByte) == 0) && ((gRLFailsafe.high & kFailsafeMskByte) == 0)
        && ((gRRFailsafe.high & kFailsafeMskByte) == 0)) {
      gALCFailSafeSupSts = FimFault_e::NoFault;
      gNOPFailSafeSupSts = FimFault_e::NoFault;
    } else {
      gALCFailSafeSupSts = FimFault_e::RevFault;  // [NT2ADD-3191]{DA_ALCSsuppression} = 1 (active ALCS Suppression)
      gNOPFailSafeSupSts = FimFault_e::RevFault;
    }

    if (((gFNFailsafe.high & kAHC_FNfsMskByte) != 0) || ((gFWFailsafe.high & kAHC_FWfsMskByte) != 0)
        || (fct_diag_interface.is_AHC_TopicFault == true)) {
      gAHCPassiveSt = FimFault_e::RevFault;
    } else {
      /*nothing*/
    }

    if (((gFWFailsafe.high & kLaneAssistFailsafeMskByte) == 0)
        && ((gFNFailsafe.high & kLaneAssistFailsafeMskByte) == 0)) {
      /*nothing*/
    } else {
      gLkaFaultSt = FimFault_e::RevFault;
    }

    if (((gFWFailsafe.high & kLaneAssistFailsafeMskByte) == 0)
        && ((gFNFailsafe.high & kLaneAssistFailsafeMskByte) == 0)) {
      /*nothing*/
    } else {
      gLdwFaultSt = FimFault_e::RevFault;
    }

    if (((gFWFailsafe.high & kLaneAssistFailsafeMskByte) == 0) && ((gFNFailsafe.high & kLaneAssistFailsafeMskByte) == 0)
        && ((gFLFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gFRFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gSVCLftFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gSVCRgtFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gRLFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gRRFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)
        && ((gRrFailsafe.high & kLaneAssistFailsafeSideCamMskByte) == 0)) {
      /*nothing*/
    } else {
      gElkFaultSt = FimFault_e::RevFault;
    }

    if (((gFWFailsafe.high & kFailsafeMskByte) == 0) && ((gFNFailsafe.high & kFailsafeMskByte) == 0)
        && ((gLidarFailsafe.high & kFailsafeMskByte) == 0)) {
      /*nothing*/
    } else {
      gEasFaultSts = FimFault_e::RevFault;
    }

    fct_fim.da_FailSafe.is_Lidar_FailSafe = (gLidarFailsafe.high & kLidarFailsafeMskByte) != 0 ? true : false;
    //[DA-20211130-01] BL110
    // fct_fim.da_FailSafe.is_CamFW_FailSafe    = (gFWFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    if (0 != (gFWFailsafe.high & (kFailsafeMskByte & ~static_cast<uint16_t>(0x07)))) {
      fct_fim.da_FailSafe.is_CamFW_FailSafe = true;
    } else {
      fct_fim.da_FailSafe.is_CamFW_FailSafe = false;
    }
    // fct_fim.da_FailSafe.is_CamFN_FailSafe    = (gFNFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    if (0 != (gFNFailsafe.high & (kFailsafeMskByte & ~static_cast<uint16_t>(0x07)))) {
      fct_fim.da_FailSafe.is_CamFN_FailSafe = true;
    } else {
      fct_fim.da_FailSafe.is_CamFN_FailSafe = false;
    }
    if (0 != (gFWFailsafe.high & static_cast<uint16_t>(0x07))) {
      fct_fim.da_FailSafe.is_CamWeaFW_FailSafe = true;
    } else {
      fct_fim.da_FailSafe.is_CamWeaFW_FailSafe = false;
    }
    if (0 != (gFNFailsafe.high & static_cast<uint16_t>(0x07))) {
      fct_fim.da_FailSafe.is_CamWeaFN_FailSafe = true;
    } else {
      fct_fim.da_FailSafe.is_CamWeaFN_FailSafe = false;
    }
    fct_fim.da_FailSafe.is_CamFL_FailSafe    = (gFLFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamFR_FailSafe    = (gFRFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamR_FailSafe     = (gRrFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamRL_FailSafe    = (gRLFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamRR_FailSafe    = (gRRFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamSVCFt_FailSafe = (gSVCFtFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamSVCRr_FailSafe = (gSVCRrFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamSVCLf_FailSafe = (gSVCLftFailsafe.high & kFailsafeMskByte) != 0 ? true : false;
    fct_fim.da_FailSafe.is_CamSVCRt_FailSafe = (gSVCRgtFailsafe.high & kFailsafeMskByte) != 0 ? true : false;

    //[DA-20220610-13]
    fct_fim.psp_FailSafe.is_CamFL_FailSafe    = (gFLFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamFR_FailSafe    = (gFRFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamR_FailSafe     = (gRrFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamRL_FailSafe    = (gRLFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamRR_FailSafe    = (gRRFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamSVCFt_FailSafe = (gSVCFtFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamSVCLf_FailSafe = (gSVCLftFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamSVCRr_FailSafe = (gSVCRrFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;
    fct_fim.psp_FailSafe.is_CamSVCRt_FailSafe = (gSVCRgtFailsafe.high & kPSPFailsafeMskByte) != 0 ? true : false;

    fct_fim.is_lka_fault     = gLkaFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.is_ldw_fault     = gLdwFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.is_elk_fault     = gElkFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.is_heater_fault  = gHeaterFaultSt != FimFault_e::NoFault ? true : false;
    fct_fim.is_ALCS_Failsafe = gALCFailSafeSupSts != FimFault_e::NoFault ? true : false;
    fct_fim.is_ALCS_Cam_Fim  = gALCCamFaultSts != FimFault_e::NoFault ? true : false;
    fct_fim.is_ALCS_Rad_Fim  = gALCRadFaultSts != FimFault_e::NoFault ? true : false;
    fct_fim.is_eas_fault     = is_eas_inhibit;
    // fct_fim.is_eas_lgtfault  = gEasLgtFaultSts != FimFault_e::NoFault ? true : false;
    // fct_fim.is_eas_latfault  = gEasLatFaultSts != FimFault_e::NoFault ? true : false;

    fct_fim.is_NOP_Fim      = gNOPFaultSts != FimFault_e::NoFault ? true : false;
    fct_fim.is_NOP_Failsafe = gNOPFailSafeSupSts != FimFault_e::NoFault ? true : false;
    if (nullptr != failsafe_vision_info && failsafe_vision_info->failsafe_fw().has_fs_rain()) {
      fct_fim.fw_fs_rain = failsafe_vision_info->failsafe_fw().fs_rain();
    };
    // fct_fim.fw_fs_rain = static_cast<uint32_t> (veh_drvr.FrntWiprInterSpd);
  };
}

void fct_logout_losscom_time(
  const std::map<uint8_t, std::pair<std::string, std::deque<nio::ncyber::TimeRecord>>>& timeRecordMap,
  const uint32_t                                                                        FctTopicLossBit,
  const bool                                                                            isPlatformNt3) {
  uint32_t enable_bit = 0x7FFFF7FC; // [NIOP-2696] remove objectsDetection
  if (isPlatformNt3) {
    enable_bit = 0x7FFFE7FC;  // [NIOP-2683] remove radar topic for 1orin
  }
  for (uint8_t i = 0; i < DIAG_MAX_TP_NUM && i < timeRecordMap.size(); i++) {
    if ((0 != (FctTopicLossBit & (0x01 << i))) && ((0x01 << i) & enable_bit)) {
      WARN_LOG << "topic loss name :" << timeRecordMap.at(i).first << "\n";
      int last = timeRecordMap.at(i).second.size() - 1;
      for (auto iter = timeRecordMap.at(i).second.begin(); iter != timeRecordMap.at(i).second.end(); iter++) {
        AINFO << "receive_ts last[" << last << "]: " << iter->receive_ts << ", "
              << "send_ts last[" << last << "]: " << iter->send_ts;
        last--;
      }
    }
  }
}

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
