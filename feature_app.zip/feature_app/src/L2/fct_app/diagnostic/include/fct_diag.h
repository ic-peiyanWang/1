#pragma once
#include <algorithm>
#include "ahc_param.h"
#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "common/proto/car_info.pb.h"
#include "common/proto/perception_object.pb.h"
#include "failsafe_encoder.h"
#include "fct_diag_interface.h"
#include "fct_diag_param.h"
#include "fct_input_adapter.h"
#include "fim_encoder.h"
#include "niodds/application/application.h"
#include "np/apps/ehy_lpp_outputs.pb.h"
#include "np/apps/ehy_tpp_outputs.pb.h"
#include "np/apps/ehy_tse_outputs.pb.h"
#include "np/apps/ehy_tsi_outputs.pb.h"
#include "topic_status.h"
#include "common/ncyber/ncyber.h"

namespace nio {
namespace ad {
namespace fctapp {
#define DIAG_VEH10MS_TP_ID (0U)
#define DIAG_VEH50MS_TP_ID (1U)
#define DIAG_EHY_TSE_TP_ID (2U)
#define DIAG_EHY_TSI_TP_ID (3U)
#define DIAG_EHY_TPP_TP_ID (4U)
#define DIAG_EHY_LPP_TP_ID (5U)
#define DIAG_EHY_RME_TP_ID (6U)
#define DIAG_EHY_HA_TP_ID (7U)
#define DIAG_EHY_EVD_TP_ID (8U)
#define DIAG_EHY_FUSION_TP_ID (9U)
#define DIAG_ROAD_DETECT_ID (10U)
#define DIAG_VISION_TP_ID (11U)
#define DIAG_RADAR_TP_ID (12U)
#define DIAG_DMS_RESULT_ID (13U)
#define DIAG_VEH_UPA_ID (14U)
#define DIAG_FIM_CAMERA_ID (15U)
#define DIAG_FIM_CAN_ID (16U)
#define DIAG_FIM_SW_ID (17U)
#define DIAG_FIM_CAN_FEA_ID (18U)
#define DIAG_FIM_POWER_ID (19U)
#define DIAG_FIM_MCU_SOC_ID (20U)
#define DIAG_FIM_LIDAR_ID (21U)
#define DIAG_VISION_FAILSAFE_ID (22U)
#define DIAG_LIDAR_FAILSAFE_ID (23U)
#define DIAG_FIM_MCU_SYS_ID (24U)
#define DIAG_NOP_CHASSIS_CTRL_TP_ID (25U)
#define DIAG_NOP_FUNCTIONSTATUS_TP_ID (26U)
#define DIAG_NOP_SCENEMGMT_TP_ID (27U)
#define DIAG_NOP_SPEEDLIMIT_TP_ID (28U)
#define DIAG_NOP_VEHICLE_TP_ID (29U)
#define DIAG_NOP_SPEED_TP_ID (30U)
#define DIAG_MAX_TP_NUM (31U)

#define FCT_CURRENT_SEC nio::ad::Time::Ptp(nio::ad::Time::Seconds)

extern uint64_t gFctAppStartTime;
extern uint64_t FctAppRunTime;

extern nio::ad::DiagFim fct_fim_diag;
extern uint32_t         gFctTopicNoInit;
extern uint32_t         gFctTopicLoss;
extern uint8_t          gFctDiagCycleCount;
extern uint32_t gTseTopicLossMask;

extern FimFault_e gLkaFaultSt;
extern FimFault_e gLdwFaultSt;
extern FimFault_e gElkFaultSt;
extern FimFault_e gAHCFaultSt;
extern FimFault_e gAHCPassiveSt;
extern FimFault_e gPilotNPFaultSt;
extern FimFault_e gNOPFaultSts;
extern FimFault_e gPilotAcmFaultSt;
extern FimFault_e gPilotBcmFaultSt;
extern FimFault_e gPilotBcuFaultSt;
extern FimFault_e gPilotScmFaultSt;
extern FimFault_e gPilotVcuFaultSt;
extern FimFault_e gPilotSwcFaultSt;
extern FimFault_e gPilotDmsFaultSt;
extern FimFault_e gPilotF30FaultSt;
extern FimFault_e gPilotSvcFaultSt;
extern FimFault_e gPilotApaFaultSt;
extern FimFault_e gPilotBgwFaultSt;
extern FimFault_e gPilotCdcFaultSt;
extern FimFault_e gPilotF120FaultSt;
extern FimFault_e gPilotRadfcFaultSt;
extern FimFault_e gPilotRadfsFaultSt;
extern FimFault_e gPilotRadrsFaultSt;
extern FimFault_e gPilotCamfsFaultSt;
extern FimFault_e gPilotCamrsFaultSt;
extern FimFault_e gPilotCanBusOffFaultSt;
extern FimFault_e gHeaterFaultSt;
extern FimFault_e gGoNotifyUSSFaultSt;
extern FimFault_e gGoNotifySysFaultSt;
extern FimFault_e gGoNotifyFailSafeSt;
extern FimFault_e gTLGoNotifyFailSafeSt;
extern FimFault_e gDAFailSafeTDSts;
extern FimFault_e gALCFailSafeSupSts;
extern FimFault_e gNOPFailSafeSupSts;
extern FimFault_e gEasFaultSts;
extern FimFault_e gEasLgtFaultSts;
extern FimFault_e gEasLatFaultSts;
// extern FimFault_e gAAappIntFaultSts;
extern FimFault_e gPSPFaultSt;

extern T_FS gFWFailsafe;
extern T_FS gFNFailsafe;
extern T_FS gLidarFailsafe;
extern T_FS gFLFailsafe;
extern T_FS gFRFailsafe;
extern T_FS gRrFailsafe;
extern T_FS gRLFailsafe;
extern T_FS gRRFailsafe;
extern T_FS gSVCFtFailsafe;
extern T_FS gSVCRrFailsafe;
extern T_FS gSVCLftFailsafe;
extern T_FS gSVCRgtFailsafe;

extern void fct_update_fim(nio::ad::DiagFim&                                            fim_table,
                           const std::shared_ptr<nio::ad::messages::CameraFimInfo>&     fim_camera_info,
                           const std::shared_ptr<nio::ad::messages::FimCanInfo>&        fim_can_info,
                           const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&   fim_sw_info,
                           const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                           const std::shared_ptr<nio::ad::messages::PowerFimInfo>&      fim_power_info,
                           const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&  fim_mcu_sys_info,
                           const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>& fim_mcu_soc_info,
                           const std::shared_ptr<nio::ad::messages::LidarFimInfo>&      fim_lidar_info,
                           const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>& fim_perception_info);

extern FimFault_e update_function_fault_status(nio::ad::DiagFim& fim_table, uint8_t (&rev_fim)[DIAG_FIM_MAX_MASK_NUM],
                                               uint8_t (&rev_mask)[DIAG_FIM_MAX_MASK_NUM]);

extern bool update_platform_fault_status();

extern void fct_diag_main(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&           fim_camera_info,
                          const std::shared_ptr<nio::ad::messages::FimCanInfo>&              fim_can_info,
                          const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&         fim_sw_info,
                          const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>&       fim_can_fea_info,
                          const std::shared_ptr<nio::ad::messages::PowerFimInfo>&            fim_power_info,
                          const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&        fim_mcu_sys_info,
                          const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>&       fim_mcu_soc_info,
                          const std::shared_ptr<nio::ad::messages::LidarFimInfo>&            fim_lidar_info,
                          const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>&       fim_perception_info,
                          const std::shared_ptr<nio::ad::messages::FailSafeDetection>&       failsafe_vision_info,
                          const std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>& failsafe_lidar_info,
                          const std::shared_ptr<proto::CarInfo>&                             veh_info,
                          const bool                                                         isPlatformNt3 = false);
extern void fct_logout_losscom_time(
  const std::map<uint8_t, std::pair<std::string, std::deque<nio::ncyber::TimeRecord>>>& timeRecordMap,
  const uint32_t                                                                        FctTopicLossBit,
  const bool                                                                            isPlatformNt3 = false);

}  // namespace fctapp
}  // namespace ad
}  // namespace nio
