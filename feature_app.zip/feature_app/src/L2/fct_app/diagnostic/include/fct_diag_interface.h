#pragma once

struct FctDiagIf {
  bool is_vehicle_input_loss_comm = true;
  bool is_ehy_traj_loss_comm      = true;
  bool is_ehy_target_loss_comm    = true;
  bool is_LKA_TopicFault          = true;
  bool is_LDW_TopicFault          = true;
  bool is_ELK_TopicFault          = true;
  bool is_AHC_TopicFault          = true;
  bool is_DA_TopicFault           = true;
  bool is_EAS_TopicFault          = true;
  bool is_SAS_TopicFault          = true;
  bool is_Heater_TopicFault       = true;
  bool is_GoNotify_TopicFault     = true;
  bool is_vision_no_ready         = true;
  bool is_ldw_fim_no_ready        = true;
  bool is_lka_fim_no_ready        = true;
  bool is_elk_fim_no_ready        = true;
  bool is_NOP_TopicFault          = true;
  bool is_NOP_chassctrl_loss_comm = true;
  bool is_iACC_TopicFault         = true;
  bool is_ehy_rme_loss_comm       = true;
  bool is_vison_radar_loss_comm   = true;
};

struct DaNpFim {
  bool is_np_fault;
  bool is_eps_fault;
  bool is_acm_fault;
  bool is_bcm_fault;
  bool is_bcu_fault;
  bool is_scm_fault;
  bool is_can_bus_off;
  bool is_vcu_fault;
  bool is_swc_fault;
  bool is_dms_fault;
  bool is_f30_fault;
  bool is_f120_fault;
  bool is_radfc_fault;
  bool is_radfs_fault;  // front radar side
  bool is_radrs_fault;  // rear radar side
  bool is_camfs_fault;  // front side camera
  bool is_camrs_fault;  // rear side camera
  bool is_svc_fault;
  bool is_apa_fault;
  bool is_bgw_fault;
  bool is_cdc_fault;
  bool is_gnss_fault;
  bool is_lidar_fault;
  bool is_power_fault;
  bool is_soc1adp_fault;
  bool is_soc2dcb_fault;
  bool is_soc3adb_fault;
  bool is_soc4ads_fault;
  bool is_awb_fault;
  bool is_failsafefc_fault;
  bool is_failsafelidar_fault;
  bool is_othercan_fault;
  bool is_aaapp_fault;
  bool is_mcu_fault;
  bool is_windcalibra_fault;
  bool is_vcuvehdispspd_fault;
  bool is_aba_fault;
  bool is_abp_fault;
  bool is_brkoverheat_fault;
  bool is_vdctcsfail_fault;
  bool is_hodsensor_fault;
  bool is_percepapp_fault;
  bool is_DaAdClassified_fault;
  bool is_DaTdClassified_fault;
  bool is_DaLatCtrl_Suppress;
  bool is_lidar_overheating;
  bool is_lidar_blocked;
  bool is_dms_camera_occluded;
  bool is_frontCam_lidar_fault;
  bool is_DaEasClassified_fault;
  bool is_lidar_abnormal_sts;
  bool is_critical_failure;
  bool is_lidar_overheating_ad;
  bool is_perception_error;
  bool is_critical_app_exited_abnormal;
  bool is_critical_app_failure_cruising;
  bool is_fim_lidar_abnormal_status;
  bool is_fim_chs1_eps1_adcacioravl;
  bool is_camera_data_issue;
  bool is_camera_failsafe;
};

struct DaFailSafe {
  bool is_Lidar_FailSafe;
  bool is_CamFW_FailSafe;
  bool is_CamFN_FailSafe;
  bool is_CamFL_FailSafe;
  bool is_CamFR_FailSafe;
  bool is_CamR_FailSafe;
  bool is_CamRL_FailSafe;
  bool is_CamRR_FailSafe;
  bool is_CamSVCFt_FailSafe;
  bool is_CamSVCRr_FailSafe;
  bool is_CamSVCLf_FailSafe;
  bool is_CamSVCRt_FailSafe;
  bool is_CamWeaFW_FailSafe;
  bool is_CamWeaFN_FailSafe;
};

struct AAInternalFault {
  bool Stop_Vehicle_Standstil;
  bool Deactivate_Function;
  bool Lateral_Control_Suppression;
  bool Longitudinal_Control_Suppression;
  bool Lane_Change_Suppression;
  bool Takeover_Warning;
  bool Attention_Warning;
  bool Insignificant;
};

struct APAFim {
  bool is_vhe_upa_msglost;
  bool is_apa_can_error;
  bool is_upasys_invalid;
  bool is_snsrflt_invalid;
  bool is_upasys_service_fault;
  bool is_upasys_disable;
  bool is_apasts_failure;
  bool is_apa_adc_msgerror;
  bool is_apa_msgerror;
  bool is_slot_msgerror;
  bool is_slot_obj1_msgerror;
  bool is_slot_obj2_msgerror;
  bool is_sdwsts_invalid;
};

struct PSPFim {
  bool   is_rad_fault;          //[DA-20220610-10]
  bool   is_chs1_bcm_fault;     //[DA-20220610-11]
  bool   is_camera_fault;       //[DA-20220610-12]
  bool   is_svc_fault;          //[DA-20220610-14]
  bool   is_camera_data_error;  // DA-20220610-25
  APAFim apa_fim;               //[DA-20220613-01]
  bool   psp_internal_error_deactivate_function;
  bool   psp_internal_error_takeover_warning;
  bool   map_loc_app_exited_abnormal;
  bool   is_perception_issue;
  bool   is_critical_app_failure_psp;
  bool   is_epb_error_psp;
  bool   is_critical_app_fault_psp;
  bool   is_psp_specific_system_issue;
};

struct PSPFailSafe {
  bool is_CamFL_FailSafe;
  bool is_CamFR_FailSafe;
  bool is_CamR_FailSafe;
  bool is_CamRL_FailSafe;
  bool is_CamRR_FailSafe;
  bool is_CamSVCFt_FailSafe;
  bool is_CamSVCLf_FailSafe;
  bool is_CamSVCRr_FailSafe;
  bool is_CamSVCRt_FailSafe;
};

struct FctFim {
  bool            is_lka_fault = false;
  bool            is_ldw_fault = false;
  bool            is_elk_fault = false;
  bool            is_eas_fault = false;
  DaNpFim         da_np_fim;
  bool            is_heater_fault = false;
  DaFailSafe      da_FailSafe;
  bool            is_ALCS_Cam_Fim;
  bool            is_ALCS_Rad_Fim;
  bool            is_ALCS_Failsafe;
  bool            is_eas_lgtfault = false;
  bool            is_eas_latfault = false;
  bool            is_NOP_Fim;
  bool            is_NOP_Failsafe;
  AAInternalFault is_AAapp_da_internal_fault;
  AAInternalFault is_AAapp_nop_internal_fault;
  int             fw_fs_rain;
  PSPFim          psp_fim;
  PSPFailSafe     psp_FailSafe;
  bool            is_radar_fim_msgerror;
};

extern FctDiagIf fct_diag_interface;
extern FctFim    fct_fim;
