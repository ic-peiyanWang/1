#pragma once
#include <chrono>
#include <string>
#include "ahc_proc.h"
#include "common/cfgmgr/cfg_task_switch.pb.h"
#include "common/diagnostic/fault/fault_lidar_internal.pb.h"
// #include "common/nop/nop_chassis_control.pb.h"
// #include "common/nop/nop_functionstatus.pb.h"
// #include "common/nop/nop_scenemgmt.pb.h"
// #include "common/nop/nop_speed.pb.h"
#include "common/nop/nop_speedlimitvalue.pb.h"
// #include "common/nop/nop_vehicleout.pb.h"
#include "common/perception/vision_failsafe.pb.h"
#include "common/perception/vision_feature_flag.pb.h"
#include "common/perception/vision_road_detection.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"

#include "eth_interface.h"
#include "fct/include/fct_main.h"
#include "fct_diag.h"
#include "fct_edr_proc.h"
#include "fct_evm_proc.h"
#include "fct_in_proc.h"
#include "fct_input_adapter.h"
#include "fct_loc_cfg.h"
#include "ids_mil.h"
#include "niodds/application/application.h"
#include "niodds/messaging/cyber_subscriber.h"
#include "np/apps/fct_dlb.pb.h"
#include "parameters_configurator.h"
#include "common/ncyber/ncyber.h"
#include "xcp_if.h"
#include "state_machine/state_machine_wrapper.h"
#include "planner/common_data_process/speed_control.h"
#include "planner/common_data_process/taugap_process.h"
#include "planner/common_data_process/sas_function.h"
#include "common/proto/state_restore.pb.h"
#include "comm_exec.h"
namespace nio {
namespace planner {

using nio::ad::Subscriber;
using nio::ad::Publisher;
using nio::ad::messages::esd_np_feature;
class IOAdapter;
class PilotPlanner {
 private:
  std::shared_ptr<NopOutput> nop_initial_input_ = nullptr;
  typedef nio::ad::messages::RoadDetection           RoadDetection;
  typedef nio::ad::messages::Features                Features;
  typedef nio::ad::messages::FailSafeDetection       FailSafeDetection;
  typedef nio::ad::messages::Lidar_FailSafeDetection Lidar_FailSafeDetection;
  typedef nio::ad::APP_state_e                       APP_state_e;
  typedef nio::ad::messages::VEH10ms                 VEH10ms;
  typedef nio::ad::messages::VEH50ms                 VEH50ms;

  const uint32_t kDefaultInterval = 50;
  std::vector<std::shared_ptr<RoadDetection>>     m_roadDetection;
  std::shared_ptr<RoadDetection>             m_lastRoadDetection;
  std::shared_ptr<RoadDetection>             m_latestRoadDetection;

  std::vector<std::shared_ptr<Features>>     m_featureFlag;
  std::shared_ptr<Features>             m_lastFeatureFlag;
  std::shared_ptr<Features>             m_latestFeatureFlag;
  std::vector<std::shared_ptr<FailSafeDetection>>     m_failSafeDetection;
  std::shared_ptr<FailSafeDetection>             m_lastFailSafeDetection;
  std::shared_ptr<FailSafeDetection>             m_latestFailSafeDetection;
  std::vector<std::shared_ptr<Lidar_FailSafeDetection>>     m_Lidar_FailSafeDetection;
  std::shared_ptr<Lidar_FailSafeDetection>             m_lastLidar_FailSafeDetection;
  std::shared_ptr<Lidar_FailSafeDetection>             m_latestLidar_FailSafeDetection;
  std::vector<std::shared_ptr<VEH10ms>>     m_veh10ms;
  std::shared_ptr<VEH10ms>             m_lastVeh10ms;
  std::shared_ptr<VEH10ms>             m_latestVeh10ms;
  std::vector<std::shared_ptr<VEH50ms>>     m_veh50ms;
  std::shared_ptr<VEH50ms>             m_lastVeh50ms;
  std::shared_ptr<VEH50ms>             m_latestVeh50ms;
  std::shared_ptr<proto::CarInfo>      m_latestVeh;  // from car_info
  std::shared_ptr<nio::ad::messages::CameraFimInfo>     m_latest_fim_camera_;
  std::shared_ptr<nio::ad::messages::FimCanInfo>        m_latest_fim_can_;
  std::shared_ptr<nio::ad::messages::FimSoftwareInfo>   m_latest_fim_sw_;
  std::shared_ptr<nio::ad::messages::CanFeatureFimInfo> m_latest_fim_can_fea_;
  std::shared_ptr<nio::ad::messages::PowerFimInfo>      m_latest_fim_power_;
  std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo> m_latest_fim_mcu_soc_;
  std::shared_ptr<nio::ad::messages::LidarFimInfo>      m_latest_fim_lidar_;
  std::shared_ptr<nio::ad::messages::McuSystemFimInfo>  m_latest_fim_mcu_sys_;
  std::shared_ptr<nio::ad::messages::PerceptionFimInfo> m_latest_fim_perception_;
  // std::shared_ptr<nio::ad::messages::FailSafeDetection>   m_latest_failsafe_vision_calib_;
  std::shared_ptr<nio::ad::messages::IlluminanceFeatures> m_latest_vision_illuminance_info_;
  std::shared_ptr<nio::ad::messages::VehVariantCode>      veh_var_code_out;
  std::shared_ptr<nio::proto::StateRestore>      state_restore_data;
  nio::ad::messages::CameraFimInfo           fim_camera_info_;
  nio::ad::messages::FimCanInfo              fim_can_info_;
  nio::ad::messages::FimSoftwareInfo         fim_sw_info_;
  nio::ad::messages::CanFeatureFimInfo       fim_can_fea_info_;
  nio::ad::messages::PowerFimInfo            fim_power_info_;
  nio::ad::messages::MCUWithSOCFimInfo       fim_mcu_soc_info_;
  nio::ad::messages::LidarFimInfo            fim_lidar_info_;
  nio::ad::messages::McuSystemFimInfo        fim_mcu_sys_info_;
  nio::ad::messages::PerceptionFimInfo       fim_perception_info_;
  nio::ad::messages::FailSafeDetection       failsafe_vision_info_;
  nio::ad::messages::Lidar_FailSafeDetection failsafe_lidar_info_;
  // nio::ad::messages::FailSafeDetection       failsafe_vision_calib_;
  nio::ad::messages::IlluminanceFeatures vision_illuminance_info_;



  // std::shared_ptr<ncyber::Reader<nio::ad::messages::PowerSwapPilotState>>    m_nop_powerswap_pilotstate_;

  // TODO: declare publisers as output
  // std::shared_ptr<ncyber::Writer<FctOut>> m_pub;

  // std::shared_ptr<ncyber::Writer<esd_np_feature>> m_pub_esd;

  // std::shared_ptr<ncyber::Writer<nio::ad::messages::FctOut>> m_pub_fctout_;
  // std::shared_ptr<ncyber::Writer<nio::ad::messages::debug::FCTDebugOut>> m_pub_fct_debug;
  // std::shared_ptr<ncyber::Writer<nio::ad::messages::FCTDlbOut>>          m_pub_fct_dlb;
  // std::shared_ptr<ncyber::Writer<nio::ad::messages::FctDaInhibit>>       m_pub_fct_da_inhibit;

 public:
  // Getters for accessing the latest instance of the messages and the possible previous instance of the message
  // recevied in the current frame
  const std::shared_ptr<RoadDetection>& GetLastRoadDetection() const {
    return m_lastRoadDetection;
  };
  const std::shared_ptr<RoadDetection>& GetLatestRoadDetection() const {
    return m_latestRoadDetection;
  };

  const std::shared_ptr<Features>& GetLastFeatureFlags() const {
    return m_lastFeatureFlag;
  };
  const std::shared_ptr<Features>& GetLatestFeatureFlags() const {
    return m_latestFeatureFlag;
  };

  const std::shared_ptr<FailSafeDetection>& GetLastFailSafeDetection() const {
    return m_lastFailSafeDetection;
  };
  const std::shared_ptr<FailSafeDetection>& GetLatestFailSafeDetection() const {
    return m_latestFailSafeDetection;
  };

  const std::shared_ptr<Lidar_FailSafeDetection>& GetLastLidarFailSafeDetection() const {
    return m_lastLidar_FailSafeDetection;
  };
  const std::shared_ptr<Lidar_FailSafeDetection>& GetLatestLidarFailSafeDetection() const {
    return m_latestLidar_FailSafeDetection;
  };

  const std::shared_ptr<VEH10ms>& GetLastVeh10ms() const {
    return m_lastVeh10ms;
  };
  const std::shared_ptr<VEH10ms>& GetLatestVeh10ms() const {
    return m_latestVeh10ms;
  };

  const std::shared_ptr<VEH50ms>& GetLastVeh50ms() const {
    return m_lastVeh50ms;
  };
  const std::shared_ptr<VEH50ms>& GetLatestVeh50ms() const {
    return m_latestVeh50ms;
  };



  APP_state_e fct_state;
  APP_state_e fct_state_lf;
  std::shared_ptr<IOAdapter> io_adapter_;
  std::unique_ptr<sm_wrapper::StateMachineWrapper> state_machine_wrapper_ptr_;  // unified np&nop state machine
  std::unique_ptr<SpeedController> speed_controller;
  std::unique_ptr<TauGapProcess> tau_gap_process;
  std::unique_ptr<SasFunction> sas_function;

  std::chrono::steady_clock::time_point last_call_ts_;
 public:
  bool OnInit(std::shared_ptr<IOAdapter> adapter);
  void adaptReaderCallBack();
  int32_t OnProc(const PncInputDataType& input, PncOutputDataType& output);
  void OnFinalize();
  bool restorePilotPlanner(std::shared_ptr<nio::proto::StateRestore> state_restore_data);

 private:
  bool traceFctOutMsg(std::shared_ptr<FctOut>& fct_out);
};

}  // namespace planner
}  // namespace nio
