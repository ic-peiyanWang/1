#include <gtest/gtest.h>
#include "ids_lib.h"
//TEST(testcasename, testname) no _ is allowed in the two arguments.
//{
//}
#if 1

TEST(EdgeCheck, edgerise)
{
   EdgeRise sigtst;
   bool tt = false;
   EXPECT_EQ(false,sigtst.EdgeRising(tt));
   tt = false; 
   EXPECT_EQ(false,sigtst.EdgeRising(tt));
   tt = true; 
   EXPECT_EQ(true,sigtst.EdgeRising(tt));
   tt = true; 
   EXPECT_EQ(false,sigtst.EdgeRising(tt));
   tt = false; 
   EXPECT_EQ(false,sigtst.EdgeRising(tt));
}

TEST(EdgeCheck, edgefall)
{
   EdgeFall sigtst;
   bool tt = true;
   EXPECT_EQ(false,sigtst.EdgeFalling(tt));
   tt = true; 
   EXPECT_EQ(false,sigtst.EdgeFalling(tt));
   tt = false; 
   EXPECT_EQ(true,sigtst.EdgeFalling(tt));
   tt = false; 
   EXPECT_EQ(false,sigtst.EdgeFalling(tt));
   tt = true; 
   EXPECT_EQ(false,sigtst.EdgeFalling(tt));
}






TEST(turnondelaypositive, turnondelay)
{
      TurnOnDelay tTondlay;
      tTondlay.set_time_to_delay(1);
      double cycletime = 0.05;

      for(int i = 1; i <= 100; ++i) {
	if (i <= tTondlay.get_time_to_delay()/cycletime)
 		EXPECT_EQ(false,tTondlay.TURN_ON_DELAY(1,1,0.05));
        else 
		EXPECT_EQ(true,tTondlay.TURN_ON_DELAY(1,1,0.05));
      }
	EXPECT_EQ(false,tTondlay.TURN_ON_DELAY(1,0,0.05));
}

TEST(turnondelaynegative, turnondelay)
{
      TurnOnDelay tTondlay;
      tTondlay.set_time_to_delay(1);
      double cycletime = 0.05;
      for(int i = 1; i <= 30; ++i) {
	if (i < tTondlay.get_time_to_delay()/cycletime)
 		EXPECT_EQ(false,tTondlay.TURN_ON_DELAY(1,1,0.05));
        else 
		EXPECT_EQ(false,tTondlay.TURN_ON_DELAY(1,0,0.05));
      }
}
#endif
#if 1
TEST(turnoffdelaypositive, turnoffdelay)
{
      TurnOffDelay tToffdlay;
      tToffdlay.set_time_to_delay(1);
      double cycletime = 0.05;
      EXPECT_EQ(true,tToffdlay.TURN_OFF_DELAY(1,1,0.05));
      for(int i = 1; i <= 100; ++i) {
	if (i <= tToffdlay.get_time_to_delay()/cycletime)
 		EXPECT_EQ(true,tToffdlay.TURN_OFF_DELAY(1,0,0.05));
        else 
		EXPECT_EQ(false,tToffdlay.TURN_OFF_DELAY(1,0,0.05));
      }
	EXPECT_EQ(true,tToffdlay.TURN_OFF_DELAY(1,1,0.05));
}

TEST(turnoffdelaynegative, turnoffdelay)
{
      TurnOffDelay tToffdlay;
      tToffdlay.set_time_to_delay(1);
      double cycletime = 0.05;
      tToffdlay.TURN_OFF_DELAY(1,1,0.05);
      for(int i = 1; i <= 30; ++i) {
	if (i < tToffdlay.get_time_to_delay()/cycletime)
 		EXPECT_EQ(true,tToffdlay.TURN_OFF_DELAY(1,0,0.05));
        else 
		EXPECT_EQ(true,tToffdlay.TURN_OFF_DELAY(1,1,0.05));
      }
}
#endif


TEST(hysteresistest,lhorlo)
{
    HystrssLHORLO   hysterelhorlo;
    double lvalue = 3.14, rvalue = 3.45;
    EXPECT_EQ(false, hysterelhorlo.Hysteresis_LHO_RLO(3.20,lvalue,rvalue));
    EXPECT_EQ(true , hysterelhorlo.Hysteresis_LHO_RLO(3.13,lvalue,rvalue));
    EXPECT_EQ(true , hysterelhorlo.Hysteresis_LHO_RLO(3.44,lvalue,rvalue));
    EXPECT_EQ(true , hysterelhorlo.Hysteresis_LHO_RLO(3.45,lvalue,rvalue));
    EXPECT_EQ(false, hysterelhorlo.Hysteresis_LHO_RLO(3.46,lvalue,rvalue));
}

TEST(hysteresistest,llorho)
{
    HystrssLLORHO hysterellorho;
    double lvalue = 3.14, rvalue = 3.45;
    EXPECT_EQ(false, hysterellorho.Hysteresis_LLO_RHO(3.20,lvalue,rvalue));
    EXPECT_EQ(true , hysterellorho.Hysteresis_LLO_RHO(3.46,lvalue,rvalue));
    EXPECT_EQ(true , hysterellorho.Hysteresis_LLO_RHO(3.14,lvalue,rvalue));
    EXPECT_EQ(false, hysterellorho.Hysteresis_LLO_RHO(3.13,lvalue,rvalue));
    EXPECT_EQ(true , hysterellorho.Hysteresis_LLO_RHO(3.46,lvalue,rvalue));
}






#if 1
int main(int argc, char* argv[])
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
#endif
