#include <algorithm>
#include "ids_lib.h"
using std::min;
using std::max;

EdgeCheck::EdgeCheck()
{
    signal_ll = false;
}

EdgeCheck::~EdgeCheck()
{

}

bool EdgeRise::EdgeRising(bool signal)
{
    bool er = false; 
    if(signal && ! signal_ll)
	er = true;
    else{
    }
    signal_ll = signal;
    return er;
}

bool EdgeFall::EdgeFalling(bool signal)
{
    bool er = false; 
    if(!signal && signal_ll)
	er = true;
    else{
    }
    signal_ll = signal;
    return er;
}

TurnDelay::TurnDelay(/* args */)
{
    signaltodelay_ll = false;
}

TurnDelay::~TurnDelay()
{
}

void TurnDelay::set_time_to_delay(double timethr)
{
    timetodelay = timethr;
}

double TurnDelay::get_time_to_delay(void)
{
    return timetodelay;
}	

bool TurnOnDelay::TURN_ON_DELAY(double timetodelay,bool signaltodelay,double cycletime){
        
    if(!signaltodelay || (signaltodelay && !signaltodelay_ll ))
    {
        this->timer =  0.0; 
    }
    else
    {
        timer += cycletime;
        timer = min(timetodelay + cycletime,timer);
    }

    signaltodelay_ll = signaltodelay;

    return (timer >= timetodelay && signaltodelay);
}


bool TurnOffDelay::TURN_OFF_DELAY(double timetodelay,bool signaltodelay,double cycletime){
        
    if(!signaltodelay && signaltodelay_ll )
    {
        timer =  timetodelay; 
    }
    else
    {
        timer -= cycletime;
        timer = max(0.0,timer);
    }

    signaltodelay_ll = signaltodelay;

    return (timer >  0.0 || signaltodelay);  
}


HysteresisLR::HysteresisLR(/* args */)
{
    output_ll = false;
}

HysteresisLR::~HysteresisLR()
{
}

bool HystrssLHORLO::Hysteresis_LHO_RLO(double input,double lvalue,double rvalue){

    bool output = false;

    if (input < lvalue)
        output = true;
    else if (input > rvalue)
        output = false;
    else
    {
        output = output_ll;
    }

    output_ll = output;
    
    return output; 

}

bool HystrssLLORHO::Hysteresis_LLO_RHO(double input,double lvalue,double rvalue){

    bool output = false;
    if (input > rvalue){
        output = true;
    }
    else if (input < lvalue){
        output = false;
    }
    else
    {
        output = output_ll;
    }

    output_ll = output;
    
    return output; 

}

double TimerEnabled::timer(bool enable,bool reset,double cycletime){
   double ti = 0.0;
   if (reset){
       ti = 0.0;
   }else if(enable) {
      ti += cycletime; 
   }else {

   }
    return ti;
}
TimerEnabled::TimerEnabled(/* args */)
{
    ti = 0.0;
}

TimerEnabled::~TimerEnabled()
{
}
PT1::PT1(/* args */)
{
    filtered = 0.0;
}

PT1::~PT1()
{
}
LowPassT::LowPassT(/* args */)
{
}

LowPassT::~LowPassT()
{
}

double LowPassT::filt(double input, double t,double dt){

    if (t <= 0.0)
      return input;

    filtered = (input - filtered)*dt/t + filtered;

    return filtered;
}