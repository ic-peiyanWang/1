#ifndef IDS_LIB_H
#define IDS_LIB_H

class EdgeCheck
{
     protected:
	bool signal_ll;
     public:
	EdgeCheck();
	~EdgeCheck();
};

class EdgeRise:public EdgeCheck
{
    public:
	bool EdgeRising(bool); 
};

class EdgeFall:public EdgeCheck
{
    public:
	bool EdgeFalling(bool); 
};


class TurnDelay
{
   // private:
    protected:
        /* data */
        double timer;
        double timetodelay;
        bool   signaltodelay_ll;
    public:
        TurnDelay(/* args */);
        ~TurnDelay();
	void set_time_to_delay(double);
	double get_time_to_delay(void);
};

class TurnOnDelay:public TurnDelay
{
    public:
        bool TURN_ON_DELAY(double timetodelay,bool signaltodelay,double cycletime);
};
class TurnOffDelay:public TurnDelay
{
    public:
    	bool TURN_OFF_DELAY(double timetodelay,bool signaltodelay,double cycletime);
};

class HysteresisLR
{
//    private:
    protected:
        /* data */
        bool output_ll;    
    public:
        HysteresisLR(/* args */);
        ~HysteresisLR();
};

class HystrssLLORHO:public HysteresisLR
{
    public:
        //hysteresis with both left and right open switching point
        //x < lsp false is returned; x > rsp true is returned;
        //return value is kept in between (lsp,rsp)
        bool Hysteresis_LLO_RHO(double input,double lvalue,double rvalue);
};
class HystrssLHORLO:public HysteresisLR
{
    public:
        //hysteresis with both left and right open switching point
        //x < lsp true is returned; x > rsp false is returned;
        //return value is kept in between (lsp,rsp)
        bool Hysteresis_LHO_RLO(double input,double lvalue,double rvalue);
};

class TimerEnabled
{
private:
    /* data */
    double ti;
public:
    TimerEnabled(/* args */);
    ~TimerEnabled();
    double timer(bool,bool,double);
};
#if 0
TimerEnabled::TimerEnabled(/* args */)
{
    ti = 0.0;
}

TimerEnabled::~TimerEnabled()
{
}
#endif
class PT1
{
protected:
    /* data */
    double filtered;
public:
    PT1(/* args */);
    ~PT1();
};
#if 0
PT1::PT1(/* args */)
{
    filtered = 0.0;
}

PT1::~PT1()
{
}
#endif
class LowPassT:public PT1
{
private:
    /* data */
public:
    LowPassT(/* args */);
    ~LowPassT();
    double filt(double, double t,double dt);
};
#if 0
LowPassT::LowPassT(/* args */)
{
}

LowPassT::~LowPassT()
{
}

double LowPassT::filt(double input, double t,double dt){

    if (t <= 0.0)
      return input;

    filtered = (input - filtered)*dt/t + filtered;

    return filtered;
}
#endif
#endif
