#include <math.h>
#include "go_notifier.h"

namespace nio{
namespace ad{
namespace fctapp{

bool    MdTlGn_CNavl            = true;
bool    MdTlGn_EUavl            = false;
float   MdTlGn_DistToCIPV1      = 8;
float   MdTlGn_DistToCIPV2      = 3;
float   MdTlGn_SLFarDist        = 100;
bool    is_nt3                  = danop_sm.one_orin_signals.is_open_one_orin_func;
float   MdTlGn_SLMidDist        = is_nt3 ? 60 : 30;
float   MdTlGn_SLNearDist       = -8;

LOGoNotifier::LOGoNotifier(){}
LOGoNotifier::~LOGoNotifier(){}

void LOGoNotifier::GetInput(){

    input_.cipv_obj         = ehy_tse.tse_obj[2];
    input_.gn_switch        = veh_drvr.AdFunCfg.GoNotifierOnOff;
    input_.np_sts           = static_cast<messages::HwaOut_NadSts_e>(HWA_out.HWASM.NadSts);
    input_.dms_phylink_fim  = cam_fim.dms_fim_info.DMSPhysicalLinkage_Error;
    input_.dms_sts          = dms_sys.dms_status;
    input_.dms_result_valid = dms_sys.dms_dstr_result_valid;
    input_.dms_result_conf  = dms_sys.dms_dstr_result_conf;
    input_.dms_dstr_lvl     = dms_sys.dms_dstr_lvl;
    input_.ego_gear         = veh_pt.Gear.ActGear;
    input_.ego_spdmps       = veh_dyn.VehSpd.VehSpdkph/Mps2Kph;
    input_.ego_spddir       = veh_dyn.VehSpd.VehMovgDir;
    input_.obs_dist_fl      = veh_upa.UsRegnDst[0].RegnDst[1];
    input_.obs_dist_fm      = veh_upa.UsRegnDst[0].RegnDst[2];
    input_.obs_dist_fr      = veh_upa.UsRegnDst[0].RegnDst[3];
}

void LOGoNotifier::EgoCondCheck(){

    output_.driver_act      = false;

    if(veh_pt.AccrPedal.ActPosn > MinDrvActBrkPed || fabs(str_sys.StrWhlAgSpd) > MinDrvActStrGrad){
        driver_act_age_++;
    }
    else{
        driver_act_age_ = 0;
    }

    driver_act_age_ = fmin(driver_act_age_, MinDrvActAge);

    if(driver_act_age_ >= MinDrvActAge){
        output_.driver_act = true;
    }

    output_.ego_standstill  = false;

    if(input_.ego_spdmps < MaxStandSpdMps &&
        (input_.ego_spddir == VehMovDir_e::Stst || input_.ego_spddir == VehMovDir_e::ForWard)){ 
          standstill_check_age_++;
    }
    else{
        standstill_check_age_ = 0;
    }

    standstill_check_age_ = fmin(standstill_check_age_, MinStandCheckAge);

    if(standstill_check_age_ >= MinStandCheckAge){
        output_.ego_standstill = true;
        output_.ego_standstill_age++;
    }

    if(input_.ego_spdmps >= MinMoveSpdMps ){
        output_.ego_standstill      = false;
        output_.ego_standstill_age  = 0;

        if(output_.smstate != LoGnSMState::kActive){
            output_.req_send_flag       = false;
        }
    }

    output_.ego_standstill_age = fmin(output_.ego_standstill_age, MaxStandStillAge);

    if(output_.ego_standstill == true && output_.lead_obj.obj_exist == false){
        if(output_.ego_standstill_age <= NoLeadObjAgeThres){
            output_.no_lead_obj_age++;
        }
    }
    else{
        output_.no_lead_obj_age = 0;
    }

    if(input_.np_sts    == messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdOff ||
        input_.np_sts   == messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdPassive ||
        input_.np_sts   == messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdRdy ||
        input_.np_sts   == messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdAccStby ||
        input_.np_sts   == messages::HwaOut_NadSts_e::HwaOut_NadSts_e_MdPilotStby){
            output_.np_cond = true;
    }
    else{
        output_.np_cond = false;
    }

    if((input_.gn_switch == GoNotifierSwitch_e::BothOn || input_.gn_switch == GoNotifierSwitch_e::VehOn) &&
        output_.ego_standstill == true &&
        output_.driver_act == false &&
        input_.ego_gear == 1 && 
        output_.no_lead_obj_age < NoLeadObjAgeThres && 
        output_.np_cond == true){
            output_.ego_cond = true;
    }
    else{
        output_.ego_cond = false;
    }
}

void LOGoNotifier::DMSStateCheck(){

    if(input_.dms_phylink_fim == true){
        output_.drv_distracted = false;
    }
    else{
        if(input_.dms_sts == DMSStatus_e::NIO_DMS_SUCCESS &&
            input_.dms_result_valid == true &&
            (input_.dms_dstr_lvl == DMSDistractionLevel_e::DMS_DISTRACTION_LEVEL_MEDIUM ||
             input_.dms_dstr_lvl == DMSDistractionLevel_e::DMS_DISTRACTION_LEVEL_HEAVY) &&
             input_.dms_result_conf >= MinDmsConf){
                 output_.drv_distracted = true;
        }
        else{
            output_.drv_distracted = false;
        }
    }

    if(output_.drv_distracted == true){
        lead_obj_dist_thres_ = EarlyLonDistThres;
        lead_obj_age_thres_  = EarlyAgeThres;
    }
    else{
        lead_obj_dist_thres_ = MediumLonDistThres;
        lead_obj_age_thres_  = MediumAgeThres;
    }
}

void LOGoNotifier::LeadObjCheck(){

    if(output_.ego_standstill == false){
        ClearObj(output_.lead_obj.obj_last);
        output_.lead_obj.obj_cond   = false;
        output_.lead_obj.obj_exist  = false;
        output_.lead_obj.leave_age  = 0;
        output_.lead_obj.dis_age    = 0;
    }
    else{
        if(output_.lead_obj.obj_exist == false){
            CheckLeadObj(input_.cipv_obj);
            if(output_.lead_obj.obj_exist == true){
                output_.lead_obj.obj_last = input_.cipv_obj;
                output_.lead_obj.leave_age = 0;
                output_.lead_obj.dis_age   = 0;
            }
            else{
                ClearObj(output_.lead_obj.obj_last);
            }
        }
        else{
            if(input_.cipv_obj.valid != 0){
                if(input_.cipv_obj.obj_index == output_.lead_obj.obj_last.obj_index){
                    output_.lead_obj.obj_last = input_.cipv_obj;
                    if(input_.cipv_obj.lon_pos_vcs > lead_obj_dist_thres_){
                        output_.lead_obj.leave_age++;
                        output_.lead_obj.dis_age = 0;
                    }
                }
                else{
                    CheckLeadObj_New(input_.cipv_obj);
                    if(output_.lead_obj.obj_exist == true){
                        output_.lead_obj.obj_last = input_.cipv_obj;
                        if(input_.cipv_obj.lon_pos_vcs > lead_obj_dist_thres_){
                            output_.lead_obj.leave_age++;
                            output_.lead_obj.dis_age    = 0;
                        }
                        else{
                            output_.lead_obj.leave_age  = 0;
                            output_.lead_obj.dis_age    = 0;
                        }
                    }
                }
            }
            else{
                if(output_.lead_obj.obj_last.valid != 0){
                    if(output_.lead_obj.obj_last.lon_pos_vcs > lead_obj_dist_thres_){
                        output_.lead_obj.leave_age++;
                        output_.lead_obj.dis_age = 0;
                    }
                    else{
                        output_.lead_obj.dis_age++;
                        output_.lead_obj.leave_age = 0;
                    }
                }
                else{
                    output_.lead_obj.obj_exist = false;
                    output_.lead_obj.leave_age = 0;
                    output_.lead_obj.dis_age   = 0;
                }
            }
        }
    }

    if(output_.lead_obj.leave_age > lead_obj_age_thres_ || output_.lead_obj.dis_age > lead_obj_age_thres_){

        output_.lead_obj.obj_cond = true;

        output_.lead_obj.obj_exist = false;
        ClearObj(output_.lead_obj.obj_last);

        output_.lead_obj.leave_age = 0;
        output_.lead_obj.dis_age   = 0;
    }
    else{
        output_.lead_obj.obj_cond = false;
    }
}

void LOGoNotifier::ObstabcleCheck(){

    output_.uss_fail   = (gGoNotifyUSSFaultSt != FimFault_e::NoFault);

    if(output_.uss_fail == true){
        output_.obs_cond = true;
    }
    else if(output_.ego_standstill == false){
        output_.obs_cond = false;
    }
    else{
        if((input_.obs_dist_fl != 0xFE && input_.obs_dist_fl > 0 && input_.obs_dist_fl < MaxObsDist)  ||
            (input_.obs_dist_fm != 0xFE && input_.obs_dist_fm > 0 && input_.obs_dist_fm < MaxObsDist) ||
            (input_.obs_dist_fr != 0xFE && input_.obs_dist_fr > 0 && input_.obs_dist_fr < MaxObsDist)){
                output_.obs_cond = false;
        }
        else{
            output_.obs_cond = true;
        }
    }
}

void LOGoNotifier::SystemFaultCheck(){
    
    output_.sys_fail   = (gGoNotifySysFaultSt != FimFault_e::NoFault || gGoNotifyFailSafeSt != FimFault_e::NoFault) ;
}

void LOGoNotifier::StateMachine(){

    switch(output_.smstate){
        case LoGnSMState::kInit:
            if(output_.ego_cond             == true &&
                output_.lead_obj.obj_cond   == true &&
                output_.obs_cond            == true &&
                output_.sys_fail            == false){
                    output_.smstate = LoGnSMState::kActive;
            }
            else if(output_.sys_fail == true){
                output_.smstate = LoGnSMState::kError;
                    }
            else{
                output_.smstate = LoGnSMState::kInit;
            }
            break;

        case LoGnSMState::kError:
            if(output_.ego_cond             == true &&
                output_.lead_obj.obj_cond   == true &&
                output_.obs_cond            == true &&
                output_.sys_fail            == false){
                    output_.smstate = LoGnSMState::kActive;
            }
            else if(output_.sys_fail == true){
                output_.smstate = LoGnSMState::kError;
            }
            else{
                output_.smstate = LoGnSMState::kInit;
            }
            break;

        case LoGnSMState::kActive:
            if(output_.req_send_flag == true){
                    output_.smstate = LoGnSMState::kInit;
            }
            else{
                output_.smstate = LoGnSMState::kActive;
            }

            break;
            
        default:
            output_.smstate = LoGnSMState::kInit;

        break;
    }
}

void LOGoNotifier::SetReq(){

    if(output_.smstate == LoGnSMState::kActive &&
        output_.req_send_flag   == false){
            output_.gn_request  = true;
            output_.gn_request_age++;
        }
    else{
        output_.gn_request      = false;
        output_.gn_request_age  = 0;
    }
    if(output_.gn_request_age > GnReqAgeThres){
        output_.gn_request      = false;
        output_.gn_request_age  = 0;
        output_.req_send_flag   = true;
    }
}

void LOGoNotifier::MainFunction(){

    GetInput();
    EgoCondCheck();
    DMSStateCheck();
    LeadObjCheck();
    ObstabcleCheck();
    SystemFaultCheck();
    StateMachine();
    SetReq();
}

void LOGoNotifier::CheckLeadObj(const TgtObj_s& obj){
    if(obj.valid != 0 &&
        (obj.lon_pos_vcs <= LeadObjLonThres_Static && obj.lon_pos_vcs > LeadObjMinDist) &&
        fabs(obj.lat_pos_vcs) <= LeadObjLatThres &&
        fabs(obj.lon_vel) <= MinObjPrecSpdMps &&
        fabs(obj.phi_angle) < MaxLeadObjAng &&
        (obj.fusion_source == 2 || obj.fusion_source == 3) &&
        (obj.type == 0 || obj.type == 1 || obj.type == 13 ||
            obj.type == 14 || obj.type == 15 || obj.type == 16 || obj.type == 17) &&
        output_.ego_standstill == true){
            output_.lead_obj.obj_exist = true;
    }
    else{
        output_.lead_obj.obj_exist = false;
    }
}

void LOGoNotifier::CheckLeadObj_New(const TgtObj_s& obj){
    if(obj.valid != 0 &&
        (obj.lon_pos_vcs > LeadObjMinDist && 
        fabs(obj.lat_pos_vcs) <= LeadObjLatThres) &&
        //obj.lon_vel >= MinObjPrecSpdMps &&
        fabs(obj.phi_angle) < MaxLeadObjAng &&
        (obj.fusion_source == 2 || obj.fusion_source == 3) &&
        (obj.type == 0 || obj.type == 1 || obj.type == 13 ||
            obj.type == 14 || obj.type == 15 || obj.type == 16 || obj.type == 17) &&
        output_.ego_standstill == true){
            output_.lead_obj.obj_exist = true;
    }
    else{
        output_.lead_obj.obj_exist = false;
    }
}

void LOGoNotifier::ClearObj(TgtObj_s& obj){
    obj.obj_index       = 0;
    obj.lon_pos_vcs     = 0;
    obj.lat_pos_vcs     = 0;
    obj.lon_vel         = 0;
    obj.status          = 0;
    obj.type            = 0;
    obj.valid           = 0;
    obj.phi_angle       = 0;
    obj.fusion_source   = 0;
}

LOGoNotifier gonotifier;

bool Debounceb(bool fl, uint32_t &cnt, const uint32_t trs) {
    if(fl || (cnt > 0 && cnt <= trs)){
        cnt++;
        return true;
    }else{
        cnt = 0;
        return false;
    }
}

TLGoNotifier::TLGoNotifier(){}
TLGoNotifier::~TLGoNotifier(){}

void TLGoNotifier::GetInput() {
    cipv_obj_ = ehy_tse.tse_obj[0];
    gn_switch_ = veh_drvr.AdFunCfg.GoNotifierOnOff;
    sales_region_ = veh_param.VarCodeInfo.sales_region;
    nop_plus_subscribe_ = veh_param.VarCodeInfo.nop_plus_subscribe_avail;
    nad_subscribe_ = veh_param.VarCodeInfo.NAD_subscribe_avail;
    da_sts_ = HWA_out.HWASM.NadSts;
    da_wti_.iacc = HWA_out.HWASM.DA_iACC_WTIs;
    da_wti_.pilot = HWA_out.HWASM.DA_Pilot_WTIs;
    da_wti_.nop = HWA_out.HWASM.DA_NOP_WTIs;
    da_wti_.nad = HWA_out.HWASM.DA_NAD_WTIs;
    da_wti_.psp = HWA_out.HWASM.DA_PSP_WTIs;
    ego_gear_ = veh_pt.Gear.ActGear;
    standstillsts_ = brk_sys.StstSts;
    brkpedsts_ = brk_sys.BrkPdl.BrkPedlSts;
    ego_spd_ = veh_dyn.VehSpd.VehSpdkph/Mps2Kph;
    dms_driver_in_loop_ = !dms_sys.dms_driver_in_loop;
    gn_failsafe_st_ = static_cast<uint8_t>(gTLGoNotifyFailSafeSt);
}

bool TLGoNotifier::ProcessTlLight(const std::shared_ptr<proto::DynamicMap> &dynamic_map) {
    tl_light_lf_ = tl_light_;

    tl_light_.color = 0;
    tl_light_.timer = 65535;
    has_tl_junction_matched_ = false;
    distance_to_entry_ = 10000;
    hd_junction_id_ = -1;
    is_navi_on_ = false;
    road_sign_ = 0;
    road_sign_has_navi_dir_ = false;
    is_single_road_sign_ = false;

    auto set_default = [&](EsdTld *tld) {
        tld->tld_valid = false;
        tld->tld_type = 0;
        tld->tld_color = 0;
        tld->tld_status = 2;
        tld->tld_timer = 65535;
    };

    set_default(&lane_tld_);
    set_default(&navi_tld_);
    set_default(&esd_tld_);

    if(nullptr == dynamic_map) {
        return false;
    }

    proto::TrafficLightJunction cur_tl_junction;
    if(0 != dynamic_map->traffic_light_junctions().size()) {
        const auto &junctions = dynamic_map->traffic_light_junctions();
        const auto iter = find_if(junctions.begin(), junctions.end(), 
                    [&](const auto &junction) { return junction.is_controlled_by_traffic_light() && (junction.source() == 2 || junction.source() == 4); });
        if(iter != junctions.end()) {
            has_tl_junction_matched_ = true;
            cur_tl_junction = (*iter);
            distance_to_entry_ = iter->distance_to_entry();
            hd_junction_id_ = iter->hd_junction_id();
        }
    }

    if(dynamic_map->has_navi_map()) {
        const auto &navi_map = dynamic_map->navi_map();
        is_navi_on_ = (navi_map.has_navigation_state() && navi_map.navigation_state() == 3);
    }

    if(0 != vision_road_sign.road_sign.size() && has_tl_junction_matched_ && 
                (distance_to_entry_ >= MdTlGn_SLNearDist && 
                    distance_to_entry_ <= MdTlGn_SLMidDist)) {
        if(distance_to_entry_ >= 0) {
            const auto &road_signs = vision_road_sign.road_sign;
            float max_x = -1000.0;
            for(const auto &road_sign:road_signs) {
                if(1 == road_sign.roadsign_lane_assign) {
                    if(road_sign.center_x > max_x) {
                        max_x = road_sign.center_x;
                        road_sign_ = road_sign.roadsign_class;
                    }
                }
            }
        }else {
            road_sign_ = road_sign_lf_;
        }
    }

    road_sign_lf_ = road_sign_;

    if(is_navi_on_) {
        if(has_tl_junction_matched_ && cur_tl_junction.has_tl_straight()) {
            navi_tld_.tld_valid = true;
            navi_tld_.tld_type = 3;
            navi_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_straight().color());
            navi_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_straight().is_flash());
            navi_tld_.tld_timer = cur_tl_junction.tl_straight().countdown();
        }
        const auto &navi_stubs = dynamic_map->navi_map().long_range_info().navi_stub();
        const auto iter = find_if(navi_stubs.begin(), navi_stubs.end(), [&](const auto &stub) {return hd_junction_id_ == stub.id(); } );
        if(iter != navi_stubs.end()) {
                switch (iter->turn_direction()) {
                    case nio::proto::NaviStub_TurnDirection::NaviStub_TurnDirection_STRAIGHT:
                        if(has_tl_junction_matched_ && cur_tl_junction.has_tl_straight()) {
                            navi_tld_.tld_valid = true;
                            navi_tld_.tld_type = 3;
                            navi_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_straight().color());
                            navi_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_straight().is_flash());
                            navi_tld_.tld_timer = cur_tl_junction.tl_straight().countdown();
                        }
                        if(road_sign_ == 204 || road_sign_ == 205 || road_sign_ == 206) {
                            road_sign_has_navi_dir_ = true;
                        }
                        break;
                    case nio::proto::NaviStub_TurnDirection::NaviStub_TurnDirection_LEFT:
                        if(has_tl_junction_matched_ && cur_tl_junction.has_tl_left()) {
                            navi_tld_.tld_valid = true;
                            navi_tld_.tld_type = 1;
                            navi_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_left().color());
                            navi_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_left().is_flash());
                            navi_tld_.tld_timer = cur_tl_junction.tl_left().countdown();
                        }
                        if(road_sign_ == 201 || road_sign_ == 203 || road_sign_ == 206 || road_sign_ == 208) {
                            road_sign_has_navi_dir_ = true;
                        }
                        break;
                    case nio::proto::NaviStub_TurnDirection::NaviStub_TurnDirection_RIGHT:
                        if(has_tl_junction_matched_ && cur_tl_junction.has_tl_right()) {
                            navi_tld_.tld_valid = true;
                            navi_tld_.tld_type = 2;
                            navi_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_right().color());
                            navi_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_right().is_flash());
                            navi_tld_.tld_timer = cur_tl_junction.tl_right().countdown();
                        }
                        if(road_sign_ == 202 || road_sign_ == 203 || road_sign_ == 205) {
                            road_sign_has_navi_dir_ = true;
                        }
                        break;
                    case nio::proto::NaviStub_TurnDirection::NaviStub_TurnDirection_TURN_AROUND:
                        if(has_tl_junction_matched_ && cur_tl_junction.has_tl_uturn()) {
                            navi_tld_.tld_valid = true;
                            navi_tld_.tld_type = 5;
                            navi_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_uturn().color());
                            navi_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_uturn().is_flash());
                            navi_tld_.tld_timer = cur_tl_junction.tl_uturn().countdown();
                        }
                        if(road_sign_ == 207 || road_sign_ == 208 || road_sign_ == 209) {
                            road_sign_has_navi_dir_ = true;
                        }
                        break;
                    default:
                        set_default(&navi_tld_);
                        road_sign_has_navi_dir_ =false;
                        break;
                }
        }
    }

    is_single_road_sign_ = (road_sign_ == 201 || road_sign_ == 202 || road_sign_ == 204 || road_sign_ == 207 || road_sign_ == 208);

    switch(road_sign_) {
        case 204:
            if(has_tl_junction_matched_ && cur_tl_junction.has_tl_straight()) {
                lane_tld_.tld_valid = true;
                lane_tld_.tld_type = 3;
                lane_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_straight().color());
                lane_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_straight().is_flash());
                lane_tld_.tld_timer = cur_tl_junction.tl_straight().countdown();
            }
            break;
        case 201:
            if(has_tl_junction_matched_ && cur_tl_junction.has_tl_left()) {
                lane_tld_.tld_valid = true;
                lane_tld_.tld_type = 1;
                lane_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_left().color());
                lane_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_left().is_flash());
                lane_tld_.tld_timer = cur_tl_junction.tl_left().countdown();
            }
            break;
        case 202:
            if(has_tl_junction_matched_ && cur_tl_junction.has_tl_right()) {
                lane_tld_.tld_valid = true;
                lane_tld_.tld_type = 2;
                lane_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_right().color());
                lane_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_right().is_flash());
                lane_tld_.tld_timer = cur_tl_junction.tl_right().countdown();
            }
            break;
        case 207:
            if(has_tl_junction_matched_ && cur_tl_junction.has_tl_uturn()) {
                lane_tld_.tld_valid = true;
                lane_tld_.tld_type = 5;
                lane_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_uturn().color());
                lane_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_uturn().is_flash());
                lane_tld_.tld_timer = cur_tl_junction.tl_uturn().countdown();
            }
            break;
        case 208:
            if(has_tl_junction_matched_ && cur_tl_junction.has_tl_uturn()) {
                lane_tld_.tld_valid = true;
                lane_tld_.tld_type = 5;
                lane_tld_.tld_color = static_cast<int>(cur_tl_junction.tl_uturn().color());
                lane_tld_.tld_status = static_cast<int>(cur_tl_junction.tl_uturn().is_flash());
                lane_tld_.tld_timer = cur_tl_junction.tl_uturn().countdown();
            }
            break;
        default:
            set_default(&lane_tld_);
            break;
    }

    EsdTld esd_tld;
    set_default(&esd_tld);
    if(has_tl_junction_matched_ && cur_tl_junction.has_distance_to_entry()) {
        if(distance_to_entry_ > MdTlGn_SLMidDist && distance_to_entry_ < MdTlGn_SLFarDist) {
            if(is_navi_on_) {
                esd_tld = navi_tld_;
            }
        }else if(distance_to_entry_ >= MdTlGn_SLNearDist && distance_to_entry_ <= MdTlGn_SLMidDist) {
            if(road_sign_ != 0) {
                if(road_sign_has_navi_dir_) {
                    esd_tld = navi_tld_;
                }else if(!road_sign_has_navi_dir_ || !is_navi_on_) {
                    if(is_single_road_sign_) {
                        esd_tld = lane_tld_;
                    }
                }
            }else {
                if(is_navi_on_) {
                    esd_tld = navi_tld_;
                }
            }
        }
        dist_to_cipv_trs_ = (cipv_obj_.lon_pos_vcs < distance_to_entry_) ? MdTlGn_DistToCIPV1 : MdTlGn_DistToCIPV2;
    }

    esd_tld_ = esd_tld;
    if(esd_tld.tld_valid) {
        tl_light_.timer =  esd_tld.tld_timer;
        switch(esd_tld.tld_color) {
            case 0:
                tl_light_.color = 0;
                break;
            case 1:
                tl_light_.color = 1;
                break;
            case 2:
                tl_light_.color = 3;
                break;
            case 3:
                tl_light_.color = 4;
                break;
            case 4:
                tl_light_.color = 0;
                break;
            default:
                tl_light_.color = 0;
                break;
        }
    }
    return true;
}

void TLGoNotifier::FaultCondCheck() {
    uint32_t fault = (gn_failsafe_st_ != 0) |
            (cam_fim.fw_adc_fim_info.FIM_FWPhysicalLinkage_Error << 1) |
            (cam_fim.fw_adc_fim_info.FIM_FW_Camera_Failsafe_3 << 2) |
            (cam_fim.fw_adc_fim_info.FIM_FW_Camera_Cal_Error << 3) |
            (cam_fim.fw_adc_fim_info.FIM_Windshield_Cal_Error << 4) |
            (cam_fim.fn_adc_fim_info.FIM_FNPhysicalLinkage_Error << 5) |
            (cam_fim.fn_adc_fim_info.FIM_FN_Camera_Failsafe_3 << 6) |
            (cam_fim.fn_adc_fim_info.FIM_FN_Camera_Cal_Error << 7);
    uint32_t sw_fault = 0;
    if(nullptr != faut_software) {
        sw_fault = 
        (faut_software->s1_process_fault_info().can_rx_exited_abnormal() << 8) |
        (faut_software->s1_process_fault_info().can_tx_exited_abnormal() << 9) |
        (faut_software->s1_process_fault_info().camera_sal_exited_abnormal() << 10) |
        (faut_software->s1_process_fault_info().position_app_exited_abnormal() << 11) |
        (faut_software->s1_process_fault_info().aa_app_exited_abnormal() << 12) |
        (faut_software->s1_process_fault_info().ehy_app_exited_abnormal() << 13) |
        (faut_software->s1_process_fault_info().fct_app_exited_abnormal() << 14) |
        (faut_software->s1_process_fault_info().fam_extied_abnoraml() << 15) |
        (faut_software->s1_process_fault_info().rel_loc_app_exited_abnoraml() << 16) |
        (faut_software->s1_process_fault_info().adhmi_exited_abnormal() << 17) |
        (faut_software->s1_process_fault_info().map_loc_app_exited_abnormal() << 18);
    }
    fault_bit_ = fault | sw_fault;
    fault_precondition_ = !fault_bit_;
}

void TLGoNotifier::DMSAvailCheck() {
    dms_fault_bit_ = cam_fim.dms_fim_info.DMSPhysicalLinkage_Error |
                        (cam_fim.dms_fim_info.DMS_License_NotAvailable << 1) |
                        (cam_fim.dms_fim_info.DMS_Function_NotAvailable << 2) |
                        (cam_fim.dms_fim_info.DMS_Camera_Occluded << 3) |
                        (cam_fim.dms_fim_info.DMS_No_Image_Recv << 4) |
                        ((nullptr != faut_software)?faut_software->s1_process_fault_info().dms_exited_abnormal():0 << 5);
    dms_available_ = !dms_fault_bit_;

}

void TLGoNotifier::PreCondCheck() {
    cn_config_condition_ = ((sales_region_ == SalesRegionTyp_e::CN) && MdTlGn_CNavl && (gn_switch_ == GoNotifierSwitch_e::LightOn || gn_switch_ == GoNotifierSwitch_e::BothOn) && (nop_plus_subscribe_ || nad_subscribe_));
    eu_config_condition_ = ((sales_region_ == SalesRegionTyp_e::EU) && MdTlGn_EUavl && (gn_switch_ == GoNotifierSwitch_e::LightOn || gn_switch_ == GoNotifierSwitch_e::BothOn));
    da_active_ = !(da_sts_ == 1 || da_sts_ == 2 || da_sts_ == 3 || da_sts_ == 4 || da_sts_ == 5);
    da_has_wti_ = (da_wti_.iacc || da_wti_.pilot || da_wti_.nop || da_wti_.nad || da_wti_.psp);
    is_standstill_ = (standstillsts_ == StstSts_e::Stst_Hold) || ((brkpedsts_ == BrkPdlSts_e::Prssd) && (ego_spd_ < MaxStandSpdMps));
    is_first_vehicle_ = !(cipv_obj_.valid && (cipv_obj_.lon_pos_vcs < dist_to_cipv_trs_) && 
                            (cipv_obj_.type == 0 || cipv_obj_.type == 1 || cipv_obj_.type == 6 || cipv_obj_.type == 13 || 
                            cipv_obj_.type == 14 || cipv_obj_.type == 15 || cipv_obj_.type == 16 || cipv_obj_.type == 17 || cipv_obj_.type == 18));
    pre_condition_ = (cn_config_condition_ || eu_config_condition_) && !da_active_ && !da_has_wti_ && (ego_gear_ == 1) && is_standstill_ && is_first_vehicle_ && !tl_request_lf_.suppress;
    FaultCondCheck();
    DMSAvailCheck();
    driver_distracted_ = (!dms_available_ || !dms_driver_in_loop_);
    color_turn_green_ = (tl_light_lf_.color != 4 && tl_light_.color == 4);
    has_timer_ = (nullptr != dynamic_map) && tl_light_.timer != 65535;
    timer_turn_3_ = has_timer_ && tl_light_lf_.timer > 3 && tl_light_.timer == 3 && tl_light_.color == 1;
}

uint8_t TLGoNotifier::GnRequestIn() {
    if(pre_condition_ && fault_precondition_) {
        if(!has_timer_ && color_turn_green_) {
            if(driver_distracted_) {
                return 0x06;
            }else {
                return 0x06;
            }
        }else if(timer_turn_3_) {
            if(driver_distracted_) {
                return 0x03;
            }else {
                return 0x03;
            }
        }else if(has_timer_ && color_turn_green_) {
            return 0x04;
        }
    }
    return 0x00;
}

void TLGoNotifier::GnRequest() {
    static uint32_t req_counter = 0;
    static uint32_t suppress_counter = 0;
    tl_request_.type_in = GnRequestIn();
    tl_request_.type = tl_request_.type_in;
    tl_request_.req = Debounceb(!(tl_request_lf_.type_in) && tl_request_.type_in, req_counter, TLRequestAgeTrs);
    tl_request_.age = req_counter*tl_request_.req;
    if(tl_request_.req && tl_request_lf_.type) {
        tl_request_.type = tl_request_lf_.type;
    }

    tl_request_.suppress = Debounceb(tl_request_lf_.req && !tl_request_.req, suppress_counter, TLRequestSprsTrs);

    tl_request_lf_ = tl_request_;
}

void TLGoNotifier::MainFunction() {
    GetInput();
    ProcessTlLight(dynamic_map);
     PreCondCheck();
    GnRequest();
}

TLGoNotifier tl_gonotifier;

} //namespace fctapp
} //namespace ad
} //namespace nio