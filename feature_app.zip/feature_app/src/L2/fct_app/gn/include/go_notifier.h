#ifndef GO_NOTIFIER_H_
#define GO_NOTIFIER_H_

#include "gtest/gtest_prod.h"
#include "fct_input_adapter.h"
#include "np/apps/fct_out.pb.h"
#include "ids_mil.h"
#include "go_notifier_par.h"
#include "fct_diag.h"

using namespace std;

namespace nio{
namespace ad{
namespace fctapp{

class LOGoNotifier{
    private:

        struct LeadObj{
            TgtObj_s    obj_last;
            bool        obj_exist;
            float       leave_age;
            float       dis_age;
            bool        obj_cond;
        };

        struct GnInput{
            TgtObj_s                    cipv_obj;
            GoNotifierSwitch_e          gn_switch;
            messages::HwaOut_NadSts_e   np_sts;
            bool                        dms_phylink_fim;
            DMSStatus_e                 dms_sts;
            bool                        dms_result_valid;
            float                       dms_result_conf;
            DMSDistractionLevel_e       dms_dstr_lvl;
            uint8_t                     ego_gear; //0x0:Neutral 0x1:Drive 0x2:Reverse
            float                       ego_spdmps;
            VehMovDir_e                 ego_spddir;
            uint32_t                    obs_dist_fl;
            uint32_t                    obs_dist_fm;
            uint32_t                    obs_dist_fr;
        };

        struct GnOutput{
            bool                        driver_act;
            bool                        ego_standstill;
            float                       ego_standstill_age;
            bool                        req_send_flag;
            float                       no_lead_obj_age;
            bool                        np_cond;
            bool                        ego_cond;
            bool                        drv_distracted;
            LeadObj                     lead_obj;
            bool                        uss_fail;
            bool                        obs_cond;
            bool                        sys_fail;
            LoGnSMState                 smstate;
            bool                        gn_request;
            float                       gn_request_age;
        };

        uint8_t driver_act_age_;
        uint8_t standstill_check_age_;
        float   lead_obj_dist_thres_;
        float   lead_obj_age_thres_;

        void GetInput();
        void EgoCondCheck();
        void DMSStateCheck();
        void LeadObjCheck();
        void ObstabcleCheck();
        void SystemFaultCheck();
        void StateMachine();
        void SetReq();
        void CheckLeadObj(const TgtObj_s& obj);
        void CheckLeadObj_New(const TgtObj_s& obj);
        void ClearObj(TgtObj_s& obj);

    public:
        GnInput     input_;
        GnOutput    output_;
        void MainFunction();
        LOGoNotifier();
        ~LOGoNotifier();
};

extern LOGoNotifier gonotifier;

bool Debounceb(bool fl, uint32_t &cnt, const uint32_t trs);

class TLGoNotifier{
    private:
        struct DaWtiInfo{
            uint8_t iacc;
            uint8_t pilot;
            uint8_t nop;
            uint8_t nad;
            uint8_t psp;
        };

        struct TlLightStatus {
            uint8_t color; //0:no light 1:red 2:yellow and red 3:yellow 4:green
            uint32_t timer;
        };

        struct EsdTld {
            bool tld_valid;//0:无效 1：有效
            int tld_type; //0:Unkonw 1:Left 2:Right 3:Straight 5 U_turn
            int tld_color; //0：Unknown, 1：Red, 2：Yellow, 3：Green 4:Gray
            int tld_status; //0：常亮，1：闪烁  2:无灯
            uint32_t tld_timer; //65535表示无效值
        };

        struct TLRequestOut {
            uint8_t type_in;
            uint8_t type;
            bool    req;
            uint8_t age;
            bool    suppress;
        };

        TgtObj_s cipv_obj_;
        GoNotifierSwitch_e gn_switch_;
        SalesRegionTyp_e sales_region_;
        bool nop_plus_subscribe_;
        bool nad_subscribe_;
        uint8_t da_sts_;
        DaWtiInfo da_wti_;
        uint8_t ego_gear_; //0x0:Neutral 0x1:Drive 0x2:Reverse
        StstSts_e standstillsts_;
        BrkPdlSts_e brkpedsts_;
        float ego_spd_;
        bool dms_driver_in_loop_;

        bool has_tl_junction_matched_;
        float distance_to_entry_;
        int hd_junction_id_;
        bool is_navi_on_;
        int road_sign_lf_;
        int road_sign_; //0:unknown 100:stopline 200:road arrow  201: left 202:right 203:left right 204:straight 205:straight right
                        //206:straight left 207:only turn 208:left turn 209: straight turn 210:left merge 211:right merge 212:forbid sign
        bool road_sign_has_navi_dir_;
        bool is_single_road_sign_;
        float dist_to_cipv_trs_;

        EsdTld lane_tld_;
        EsdTld navi_tld_;
        EsdTld esd_tld_;

        TlLightStatus tl_light_;
        TlLightStatus tl_light_lf_;
        bool has_timer_;
        uint8_t gn_failsafe_st_;

        bool cn_config_condition_;
        bool eu_config_condition_;
        bool da_active_;
        bool da_has_wti_;
        bool is_standstill_;
        bool is_first_vehicle_;
        bool pre_condition_;

        bool fault_software_available_;
        uint32_t fault_bit_;
        bool fault_precondition_;
        uint32_t dms_fault_bit_;
        bool dms_available_;
        bool driver_distracted_;

        bool color_turn_green_;
        bool timer_turn_3_;

        TLRequestOut tl_request_;
        TLRequestOut tl_request_lf_;

        void GetInput();
        bool ProcessTlLight(const std::shared_ptr<proto::DynamicMap> &dynamic_map);
        void FaultCondCheck();
        void DMSAvailCheck();
        void PreCondCheck();
        uint8_t GnRequestIn();
        void GnRequest();
        FRIEND_TEST(go_notifier, processtltest);

    public:
        GoNotifierSwitch_e GnSwitch() {return gn_switch_;};
        SalesRegionTyp_e SalesRegion() {return sales_region_;};
        bool NopPlusSubscribe() {return nop_plus_subscribe_;};
        bool NadSubscribe() {return nad_subscribe_;};
        bool DmsDriverInLoop() {return dms_driver_in_loop_;};

        bool HasTLJunctionMatched() {return has_tl_junction_matched_;};
        float DistanceToEntry() {return distance_to_entry_;};
        int HdJunctionID() {return hd_junction_id_;};
        bool IsNaviOn() {return is_navi_on_;};
        int RoadSign() {return road_sign_;};
        bool RoadSignHasNaviDir() {return road_sign_has_navi_dir_;};
        bool IsSingleRoadSign() {return is_single_road_sign_;};
        float DistToCipvTrs() {return dist_to_cipv_trs_;};

        EsdTld LaneEsdTrafficLight() {return lane_tld_;};
        EsdTld NaviEsdTrafficLight() {return navi_tld_;};
        EsdTld EsdTrafficLight() {return esd_tld_;};

        TlLightStatus TrafficLight() {return tl_light_;};
        uint8_t GnFailSafeState() {return gn_failsafe_st_;};
        bool CNConfig() {return cn_config_condition_;};
        bool EUConfig() {return eu_config_condition_;};
        bool DaActive() {return da_active_;};
        bool DaHasWti() {return da_has_wti_;};
        bool IsStandstill() {return is_standstill_;};
        bool IsFirstVehicle() {return is_first_vehicle_;};
        bool PreCondition() {return pre_condition_;};
        uint32_t FaultBit() {return fault_bit_;};
        bool FaultPreCondition() {return fault_precondition_;};
        uint32_t DmsFaultBit()  {return dms_fault_bit_;};
        bool DmsAvailable() {return dms_available_;};
        bool DriverDistracted() {return driver_distracted_;};
        bool ColorTurn() {return color_turn_green_;};
        bool HasTimer() {return has_timer_;};
        bool TimerTurn() {return timer_turn_3_;};
        TLRequestOut TLRequest() {return tl_request_;};

        void MainFunction();
        TLGoNotifier();
        ~TLGoNotifier();
};

extern TLGoNotifier tl_gonotifier;

} //namespace fctapp
} //namespace ad
} //namespace nio

#endif //GO_NOTIFIER_H_