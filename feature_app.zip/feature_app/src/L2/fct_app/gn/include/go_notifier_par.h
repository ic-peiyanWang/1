#ifndef GO_NOTIFIER_PAR_H_
#define GO_NOTIFIER_PAR_H_

#include "fct_input_adapter.h"

namespace nio{
namespace ad{
namespace fctapp{

enum LoGnSMState{
    kInit       = 0,
    kError      = 1,
    kActive     = 2,
};

const float     FctCycleTime            = 0.05;

const float     Mps2Kph                 = 3.6;

const float     MinDrvActBrkPed         = 5.0;

const float     MinDrvActStrGrad        = 200.0;

const uint8_t   MinDrvActAge            = 5;

const float     MaxStandSpdMps          = 0.1;

const uint8_t   MinStandCheckAge        = 4;

const float     MinMoveSpdMps           = 0.1;

const float     MinObjPrecSpdMps        = 0.1;

const float     LeadObjLonThres_Static  = 6.0;

const float     LeadObjMinDist          = 0.0;

const float     LeadObjLatThres         = 1.0;

const float     MaxLeadObjAng           = 0.3;

const float     EarlyLonDistThres       = 6.0;
const float     EarlyAgeThres           = 0.5/FctCycleTime;

const float     MediumLonDistThres      = 7.0;
const float     MediumAgeThres          = 1/FctCycleTime;

/* const float     LateLonDistThres        = 10.0;
const float     LateAgeThres            = 4/FctCycleTime; */

const float     GnReqAgeThres           = 3/FctCycleTime;

const float     NoLeadObjAgeThres       = 20/FctCycleTime;

const float     MaxStandStillAge        = 30/FctCycleTime;

//const float     FrBumper2ReAxel         = 3.9;

const uint32_t  MaxObsDist              = 80;

const float     MinDmsConf              = 0.6;

extern  bool    MdTlGn_CNavl;

extern  bool    MdTlGn_EUavl;

const uint32_t  TLRequestAgeTrs         = 5/FctCycleTime;

const uint32_t  TLRequestSprsTrs        = 20/FctCycleTime;

} //namespace fctapp
} //namespace ad
} //namespace nio

#endif //GO_NOTIFIER_PAR_H_