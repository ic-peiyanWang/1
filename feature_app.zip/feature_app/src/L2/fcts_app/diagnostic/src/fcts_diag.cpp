#include "fcts_diag.h"
#include "aeb_ctrlparam.h"

namespace nio {
namespace ad {
extern std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>       arb_radar_data_;
extern std::vector<std::shared_ptr<nio::ad::messages::ForceSideFeatures>> arb_side_feature_;
extern std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>  arb_vision_objects_;  // 100ms
extern std::vector<std::shared_ptr<nio::ad::messages::VEH10ms>>           arb_vehicle_input_10_;
extern std::vector<std::shared_ptr<nio::ad::messages::VEH50ms>>           arb_vehicle_input_50_;
extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>     arb_road_detection_;  // 100ms
extern std::vector<std::shared_ptr<nio::ad::messages::EHYObfOutputs>>     arb_fusion_object_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEgoOutputs>>     arb_ehy_ego_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>     arb_ehy_lpp_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>     arb_ehy_rme_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>     arb_ehy_tse_;

extern std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>           arb_fim_camera_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>              arb_fim_can_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>         arb_fim_sw_info;
extern std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>>       arb_fim_can_fea_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>            arb_fim_power_info;
extern std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>>       arb_fim_mcu_soc_info;
extern std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>            arb_fim_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::McuSystemFimInfo>>        arb_fim_mcu_sys_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PerceptionFimInfo>>       arb_fim_perception_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_info;
extern std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> arb_failsafe_lidar_info;

uint8_t kAEBMskByte[DIAG_FIM_MAX_MASK_NUM] = {
  0xFF, 0x18, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xDF,  // byte 00~09
  0xEE, 0xFF, 0x9F, 0x3B, 0xFA, 0xFF, 0xFF, 0xFF, 0xFF, 0x00,  // byte 10~19
  0xFF, 0xF8, 0xFF, 0xFF, 0xF6, 0xFF, 0xE4, 0xFF, 0xFF, 0xF9,  // byte 20~29
  0x78, 0xFC, 0xFF, 0xFF, 0x6C, 0xFF, 0xFE, 0xFF, 0xBA, 0xFF,  // byte 30~39
  0xF4, 0xFB, 0xBF, 0x7D, 0xFF, 0x40, 0xFC, 0xFF, 0xFA, 0xFF,  // byte 40~49
  0xFF, 0xFF, 0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0x7F, 0xFE,  // byte 50~59
  0xF3, 0xDF, 0x98, 0xFF, 0x93, 0xFF, 0xFC, 0xE7, 0x3F, 0xFF,  // byte 60~69
  0xFD, 0xFF, 0xDB, 0x7F, 0x57, 0x00, 0x00, 0xE0, 0xFF, 0xFF,  // byte 70~79
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 80~89
  0x00, 0xFF, 0xFB, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xE4, 0xFF,  // byte 90~99
  0xEC, 0xFB, 0xFF, 0xFF, 0xFF, 0xFC, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 100~109
  0xFF, 0xFF, 0xFD, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 110~119
  0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 120~129
};
uint8_t kFCWMskByte[DIAG_FIM_MAX_MASK_NUM] = {
  0xFF, 0x18, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xDF,  // byte 00~09
  0xEE, 0xFF, 0xDF, 0xBB, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0x00,  // byte 10~19
  0xFF, 0xF8, 0xFF, 0xFF, 0xF6, 0xFF, 0xE4, 0xFF, 0xFF, 0xF9,  // byte 20~29
  0x78, 0xFC, 0xFF, 0xFF, 0x6C, 0xFF, 0xFF, 0xFF, 0xBA, 0xFF,  // byte 30~39
  0xF4, 0xFB, 0xBF, 0x7D, 0xFF, 0x40, 0xFC, 0xFF, 0xFA, 0xFF,  // byte 40~49
  0xFF, 0xFF, 0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0x7F, 0xFE,  // byte 50~59
  0xF3, 0xDF, 0x98, 0xFF, 0x93, 0xFF, 0xFC, 0xE7, 0x3F, 0xFF,  // byte 60~69
  0xFD, 0xFF, 0xDB, 0x7F, 0x57, 0x00, 0x00, 0xE0, 0xFF, 0xFF,  // byte 70~79
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 80~89
  0x00, 0xFF, 0xFB, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xE4, 0xFF,  // byte 90~99
  0xEC, 0xFB, 0xFF, 0xFF, 0xFF, 0xFC, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 100~109
  0xFF, 0xFF, 0xFD, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 110~119
  0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 120~129
};
uint8_t kRearAEBMskByte[DIAG_FIM_MAX_MASK_NUM] = {
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 00~09
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 10~19
  0xFF, 0xFF, 0xFF, 0xFF, 0xEF, 0xFF, 0xE4, 0xFF, 0xFF, 0xFF,  // byte 20~29
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 30~39
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 40~49
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 50~59
  0xFD, 0xEF, 0xFF, 0x7F, 0xFF, 0xFF, 0xFF, 0xFF, 0xDF, 0xFF,  // byte 60~69
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 70~79
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 80~89
  0xFF, 0xFF, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 90~99
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFB, 0xFF, 0xFF, 0xFF,  // byte 100~109
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 110~119
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // byte 120~129
};

uint8_t               gAEBFimByte[DIAG_FIM_MAX_MASK_NUM];
uint8_t               gFCWFimByte[DIAG_FIM_MAX_MASK_NUM];
uint8_t               gRearAEBFimByte[DIAG_FIM_MAX_MASK_NUM];
FimFault_e            gAEBFimSt;
FimFault_e            gFCWFimSt;
FimFault_e            gRearAEBFimSt;
FimFault_e            gAEBFaultSt;
FimFault_e            gFCWFaultSt;
FimFault_e            gRearAEBFaultSt;
T_FS                  gFWfailsafe;
T_FS                  gFNfailsafe;
T_FS                  gLidarfailsafe;
T_FS                  gRearfailsafe;
nio::ad::DiagFim      Arb_fim_diag;
nio::ad::DiagFailsafe Arb_failsafe_diag;
// timestamps unit is ns, arb_app run time is 20ms, threshold set as 10ms
// const uint64_t P_TsLossCommThres = 10000;
uint32_t           Arb_TopicNoInit = 0;
uint32_t           Arb_TopicLoss   = 0;
uint8_t            Arb_CycleCount  = 0;
uint8_t            AEB_FIMnum      = 0;
uint8_t            FCW_FIMnum      = 0;
uint8_t            RearAEB_FIMnum  = 0;
TopicStatus        Topic[Topic_MaxNum];
const FltThreshold FltConfig[Topic_MaxNum] = {
  /*0*/ { 0, 5, 1, 2 },   /*arb_radar_data_ID*/
  /*1*/ { 0, 5, 1, 2 },   /*arb_side_feature_ID*/
  /*2*/ { 0, 5, 1, 2 },   /*arb_vision_objects_ID*/
  /*3*/ { 0, 10, 1, 5 },  /*arb_vehicle_input_10_ID*/
  /*4*/ { 0, 5, 1, 2 },   /*arb_vehicle_input_50_ID*/
  /*5*/ { 0, 5, 1, 2 },   /*arb_road_detection_ID*/
  /*6*/ { 0, 5, 1, 2 },   /*arb_fusion_object_ID*/
  /*7*/ { 0, 5, 1, 2 },   /*arb_ehy_ego_ID*/
  /*8*/ { 0, 5, 1, 2 },   /*arb_ehy_lpp_ID*/
  /*9*/ { 0, 5, 1, 2 },   /*arb_ehy_rme_ID*/
  /*10*/ { 0, 5, 1, 2 },  /*arb_ehy_tse_ID*/
  /*11*/ { 0, 10, 1, 2 }, /*arb_fim_camera_ID*/
  /*12*/ { 0, 10, 1, 2 }, /*arb_fim_can_ID*/
  /*13*/ { 0, 10, 1, 2 }, /*arb_fim_sw_ID*/
  /*14*/ { 0, 10, 1, 2 }, /*arb_fim_can_fea_ID*/
  /*15*/ { 0, 10, 1, 2 }, /*arb_fim_power_ID*/
  /*16*/ { 0, 10, 1, 2 }, /*arb_fim_mcu_soc_ID*/
  /*17*/ { 0, 10, 1, 2 }, /*arb_fim_lidar_ID*/
  /*18*/ { 0, 10, 1, 2 }, /*arb_fim_mcu_sys_ID*/
  /*19*/ { 0, 10, 1, 2 }, /*arb_fim_perception_ID*/
  /*20*/ { 0, 10, 1, 2 }, /*arb_failsafe_vision_ID*/
  /*21*/ { 0, 10, 1, 2 }  /*arb_failsafe_lidar_ID*/
};

void Arb_update_fim(nio::ad::DiagFim&                                            fim_table,
                    const std::shared_ptr<nio::ad::messages::CameraFimInfo>&     fim_camera_info,
                    const std::shared_ptr<nio::ad::messages::FimCanInfo>&        fim_can_info,
                    const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&   fim_sw_info,
                    const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                    const std::shared_ptr<nio::ad::messages::PowerFimInfo>&      fim_power_info,
                    const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&  fim_mcu_sys_info,
                    const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>& fim_mcu_soc_info,
                    const std::shared_ptr<nio::ad::messages::LidarFimInfo>&      fim_lidar_info,
                    const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>& fim_perception_info) {
  fim_table.FimEncoder(fim_camera_info, fim_can_info, fim_sw_info, fim_can_fea_info, fim_power_info, fim_mcu_sys_info,
                       fim_mcu_soc_info, fim_lidar_info, fim_perception_info);
}

FimFault_e update_funtion_fault_status(nio::ad::DiagFim& fim_table, uint8_t (&rev_fim)[DIAG_FIM_MAX_MASK_NUM],
                                       uint8_t (&rev_mask)[DIAG_FIM_MAX_MASK_NUM]) {
  bool is_rev_fault = false;
  for (uint8_t iter = 0; iter < DIAG_FIM_MAX_MASK_NUM; iter++) {
    rev_fim[iter] = fim_table.get_relative_fim_byte(rev_mask[iter], iter);
    is_rev_fault |= (rev_fim[iter] != 0U ? true : false);
  }
  if (true == is_rev_fault) {
    return FimFault_e::RevFault;
  } else {
    return FimFault_e::NoFault;
  }
}

void arb_diag_main(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&           fim_camera_info,
                   const std::shared_ptr<nio::ad::messages::FimCanInfo>&              fim_can_info,
                   const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&         fim_sw_info,
                   const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>&       fim_can_fea_info,
                   const std::shared_ptr<nio::ad::messages::PowerFimInfo>&            fim_power_info,
                   const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&        fim_mcu_sys_info,
                   const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>&       fim_mcu_soc_info,
                   const std::shared_ptr<nio::ad::messages::LidarFimInfo>&            fim_lidar_info,
                   const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>&       fim_perception_info,
                   const std::shared_ptr<nio::ad::messages::FailSafeDetection>&       failsafe_vision_info,
                   const std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>& failsafe_lidar_info) {

  Arb_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fw(), gFWfailsafe);
  Arb_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_fn(), gFNfailsafe);
  Arb_failsafe_diag.vision_FailsafeEncoder(failsafe_vision_info->failsafe_r(), gRearfailsafe);
  Arb_failsafe_diag.lidar_FailsafeEncoder(failsafe_lidar_info->failsafe(), gLidarfailsafe);

  Arb_update_fim(Arb_fim_diag, fim_camera_info, fim_can_info, fim_sw_info, fim_can_fea_info, fim_power_info,
                 fim_mcu_sys_info, fim_mcu_soc_info, fim_lidar_info, fim_perception_info);
  gAEBFimSt     = update_funtion_fault_status(Arb_fim_diag, gAEBFimByte, kAEBMskByte);
  gFCWFimSt     = update_funtion_fault_status(Arb_fim_diag, gFCWFimByte, kFCWMskByte);
  gRearAEBFimSt = update_funtion_fault_status(Arb_fim_diag, gRearAEBFimByte, kRearAEBMskByte);

  AEB_FIMnum = 0;
  if (gAEBFimSt != FimFault_e::NoFault) {
    for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
      if (gAEBFimByte[index] != 0) {
        AEB_FIMnum = index;
        break;
      }
    }
  }
  FCW_FIMnum = 0;
  if (gFCWFimSt != FimFault_e::NoFault) {
    for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
      if (gFCWFimByte[index] != 0) {
        FCW_FIMnum = index;
        break;
      }
    }
  }
  RearAEB_FIMnum = 0;
  if (gRearAEBFimSt != FimFault_e::NoFault) {
    for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
      if (gRearAEBFimByte[index] != 0) {
        RearAEB_FIMnum = index;
        break;
      }
    }
  }

  if (((gFWfailsafe.high & AEB_FWfailsafeMsk) == 0) && ((gFNfailsafe.high & AEB_FNfailsafeMsk) == 0)
      && ((gLidarfailsafe.high & AEB_LidarfailsafeMsk) == 0)) {
    gAEBFaultSt = gAEBFimSt;
    gFCWFaultSt = gFCWFimSt;
  } else {
    gAEBFaultSt = FimFault_e::RevFault;
    gFCWFaultSt = FimFault_e::RevFault;
  }

  if ((gRearfailsafe.high & AEB_RearfailsafeMsk) == 0) {
    gRearAEBFaultSt = gRearAEBFimSt;
  } else {
    gRearAEBFaultSt = FimFault_e::RevFault;
  }

  Arb_CycleCount++;
  update_topic_status(arb_vehicle_input_10_, Topic[arb_vehicle_input_10_ID], FltConfig[arb_vehicle_input_10_ID]);
  update_topic_status(arb_fim_camera_info, Topic[arb_fim_camera_ID], FltConfig[arb_fim_camera_ID]);
  update_topic_status(arb_fim_can_info, Topic[arb_fim_can_ID], FltConfig[arb_fim_can_ID]);
  update_topic_status(arb_fim_sw_info, Topic[arb_fim_sw_ID], FltConfig[arb_fim_sw_ID]);
  update_topic_status(arb_fim_can_fea_info, Topic[arb_fim_can_fea_ID], FltConfig[arb_fim_can_fea_ID]);
  update_topic_status(arb_fim_power_info, Topic[arb_fim_power_ID], FltConfig[arb_fim_power_ID]);
  update_topic_status(arb_fim_mcu_soc_info, Topic[arb_fim_mcu_soc_ID], FltConfig[arb_fim_mcu_soc_ID]);
  update_topic_status(arb_fim_lidar_info, Topic[arb_fim_lidar_ID], FltConfig[arb_fim_lidar_ID]);
  update_topic_status(arb_fim_mcu_sys_info, Topic[arb_fim_mcu_sys_ID], FltConfig[arb_fim_mcu_sys_ID]);
  update_topic_status(arb_fim_perception_info, Topic[arb_fim_perception_ID], FltConfig[arb_fim_perception_ID]);
  update_topic_status(arb_failsafe_vision_info, Topic[arb_failsafe_vision_ID], FltConfig[arb_failsafe_vision_ID]);

  if (Arb_CycleCount % 3 == 0)  // 50ms cycle time
  {
    update_topic_status(arb_radar_data_, Topic[arb_radar_data_ID], FltConfig[arb_radar_data_ID]);
    update_topic_status(arb_side_feature_, Topic[arb_side_feature_ID], FltConfig[arb_side_feature_ID]);
    update_topic_status(arb_vehicle_input_50_, Topic[arb_vehicle_input_50_ID], FltConfig[arb_vehicle_input_50_ID]);
    update_topic_status(arb_fusion_object_, Topic[arb_fusion_object_ID], FltConfig[arb_fusion_object_ID]);
    update_topic_status(arb_ehy_ego_, Topic[arb_ehy_ego_ID], FltConfig[arb_ehy_ego_ID]);
    update_topic_status(arb_ehy_lpp_, Topic[arb_ehy_lpp_ID], FltConfig[arb_ehy_lpp_ID]);
    update_topic_status(arb_ehy_rme_, Topic[arb_ehy_rme_ID], FltConfig[arb_ehy_rme_ID]);
    update_topic_status(arb_ehy_tse_, Topic[arb_ehy_tse_ID], FltConfig[arb_ehy_tse_ID]);
  }
  if (Arb_CycleCount % 5 == 0)  // 100ms cycle time
  {
    update_topic_status(arb_vision_objects_, Topic[arb_vision_objects_ID], FltConfig[arb_vision_objects_ID]);
    update_topic_status(arb_road_detection_, Topic[arb_road_detection_ID], FltConfig[arb_road_detection_ID]);
    update_topic_status(arb_failsafe_lidar_info, Topic[arb_failsafe_lidar_ID], FltConfig[arb_failsafe_lidar_ID]);
  }
  if (Arb_CycleCount >= 15) {
    Arb_CycleCount = 0;
  }
  Arb_TopicNoInit = Diag_InitOutput(Topic, Topic_MaxNum);
  Arb_TopicLoss   = Diag_FailedOutput(Topic, Topic_MaxNum);
}
}  // namespace ad
}  // namespace nio
