#pragma once

#include <algorithm>
#include "common/perception/perception_objects.pb.h"
#include "common/perception/radar_object.pb.h"
#include "common/perception/side_feature.pb.h"
#include "common/perception/vision_road_detection.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "failsafe_encoder.h"
#include "fim_encoder.h"
#include "niodds/application/application.h"
#include "np/apps/ehy_ego_outputs.pb.h"
#include "np/apps/ehy_evd_outputs.pb.h"
#include "np/apps/ehy_ha_outputs.pb.h"
#include "np/apps/ehy_lpp_outputs.pb.h"
#include "np/apps/ehy_obf_outputs.pb.h"
#include "np/apps/ehy_rme_road_outputs.pb.h"
#include "np/apps/ehy_tpp_outputs.pb.h"
#include "np/apps/ehy_tse_outputs.pb.h"
#include "np/apps/ehy_tsi_outputs.pb.h"
#include "np/apps/ehy_tsr_outputs.pb.h"
#include "np/apps/fct_out.pb.h"
#include "np/apps/parking_outputs.pb.h"
#include "topic_status.h"

#define arb_radar_data_ID (0U)
#define arb_side_feature_ID (1U)
#define arb_vision_objects_ID (2U)
#define arb_vehicle_input_10_ID (3U)
#define arb_vehicle_input_50_ID (4U)
#define arb_road_detection_ID (5U)
#define arb_fusion_object_ID (6U)
#define arb_ehy_ego_ID (7U)
#define arb_ehy_lpp_ID (8U)
#define arb_ehy_rme_ID (9U)
#define arb_ehy_tse_ID (10U)
#define arb_fim_camera_ID (11U)
#define arb_fim_can_ID (12U)
#define arb_fim_sw_ID (13U)
#define arb_fim_can_fea_ID (14U)
#define arb_fim_power_ID (15U)
#define arb_fim_mcu_soc_ID (16U)
#define arb_fim_lidar_ID (17U)
#define arb_fim_mcu_sys_ID (18U)
#define arb_fim_perception_ID (19U)
#define arb_failsafe_vision_ID (20U)
#define arb_failsafe_lidar_ID (21U)
#define Topic_MaxNum (22U)

namespace nio {
namespace ad {
extern uint32_t           Arb_TopicNoInit;
extern uint32_t           Arb_TopicLoss;
extern TopicStatus        Topic[Topic_MaxNum];
extern const FltThreshold FltConfig[Topic_MaxNum];
extern uint8_t            Arb_CycleCount;
extern void               arb_diag_main(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&           fim_camera_info,
                                        const std::shared_ptr<nio::ad::messages::FimCanInfo>&              fim_can_info,
                                        const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&         fim_sw_info,
                                        const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>&       fim_can_fea_info,
                                        const std::shared_ptr<nio::ad::messages::PowerFimInfo>&            fim_power_info,
                                        const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&        fim_mcu_sys_info,
                                        const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>&       fim_mcu_soc_info,
                                        const std::shared_ptr<nio::ad::messages::LidarFimInfo>&            fim_lidar_info,
                                        const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>&       fim_perception_info,
                                        const std::shared_ptr<nio::ad::messages::FailSafeDetection>&       failsafe_vision_info,
                                        const std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>& failsafe_lidar_info);

extern uint8_t          kAEBMskByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t          gAEBFimByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t          kFCWMskByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t          gFCWFimByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t          kRearAEBMskByte[DIAG_FIM_MAX_MASK_NUM];
extern uint8_t          gRearAEBFimByte[DIAG_FIM_MAX_MASK_NUM];
extern FimFault_e       gAEBFaultSt;
extern FimFault_e       gFCWFaultSt;
extern FimFault_e       gRearAEBFaultSt;
extern T_FS             gFWfailsafe;
extern T_FS             gFNfailsafe;
extern T_FS             gRearfailsafe;
extern T_FS             gLidarfailsafe;
extern uint8_t          AEB_FIMnum;
extern uint8_t          FCW_FIMnum;
extern uint8_t          RearAEB_FIMnum;
extern nio::ad::DiagFim Arb_fim_diag;

}  // namespace ad
}  // namespace nio
