#include <memory>
#include <string>
#include "aeb/aeb_interface/include/aeb_output_publisher.h"
#include "aeb/aeb_main/include/aeb_in_house.h"
#include "aeb_calibration.h"
#include "eth_interface.h"
#include "fcts/include/fcts_esd_out.h"
#include "fcts/include/fcts_input_adapter.h"
#include "fcts/include/fcts_loc_cfg.h"
#include "fcts/include/fcts_main.h"
#include "niodds/application/application.h"
#include "np/apps/parking_outputs.pb.h"
#include "xcp_if.h"
#include "common/basics/trace_utils.h"

using namespace std;
using namespace nio::ad::messages;
using namespace nio::ad::messages::debug;

namespace nio {
namespace ad {
extern ARBSIN* arb_sin;

extern ARBInputAdapter arb_input_adapter_;

extern AEBInHouse aeb_;

extern AEBOutputPublisher aeb_output_pub_;

AEBOutputPublisher aeb_output_pub_;

// extern std::shared_ptr<nio::ad::messages::ARBOut>             arb_out_data;
// extern std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_debug_data;

extern std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>       arb_radar_data_;
extern std::vector<std::shared_ptr<nio::ad::messages::ForceSideFeatures>> arb_side_feature_;
extern std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>  arb_vision_objects_;
extern std::vector<std::shared_ptr<nio::ad::messages::VEH10ms>>           arb_vehicle_input_10_;
extern std::vector<std::shared_ptr<nio::ad::messages::VEH50ms>>           arb_vehicle_input_50_;
extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>     arb_road_detection_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYObfOutputs>>     arb_fusion_object_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEgoOutputs>>     arb_ehy_ego_;
// extern std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>     arb_ehy_evd_;
// extern std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>  arb_ehy_ha_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>> arb_ehy_lpp_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>> arb_ehy_rme_;
// extern std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>> arb_ehy_tpp_;
// extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>> arb_ehy_tsi_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>> arb_ehy_tse_;
// extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsrOutputs>> arb_ehy_tsr_;
extern std::vector<std::shared_ptr<nio::ad::messages::FctOut>> m_fctOut;
// extern std::vector<std::shared_ptr<nio::ad::messages::ParkingOut>>        m_parking_;

extern std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>     arb_fim_camera_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>        arb_fim_can_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>   arb_fim_sw_info;
extern std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>> arb_fim_can_fea_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>      arb_fim_power_info;
extern std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>> arb_fim_mcu_soc_info;
extern std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>      arb_fim_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::McuSystemFimInfo>>  arb_fim_mcu_sys_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PerceptionFimInfo>> arb_fim_perception_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>> arb_failsafe_vision_info;
// extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_calib;
extern std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> arb_failsafe_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::VehVariantCode>>          arb_vehicle_variant_info;
extern std::vector<std::shared_ptr<nio::ad::messages::VehicleAdfFod>>          arb_vehicle_adf_fod_info;

class FCTSApp : public Application {
 private:
  const uint32_t kDefaultInterval = 20;

  // Declare subscribers as input
  shared_ptr<Subscriber<FctOut>> m_sub;
  // vector<shared_ptr<FctOut>> m_fctOut;
  shared_ptr<FctOut> m_lastFctOut;
  shared_ptr<FctOut> m_latestFctOut;

  shared_ptr<Subscriber<VEH10ms>> m_subVeh10ms;
  vector<shared_ptr<VEH10ms>>     m_veh10ms;
  shared_ptr<VEH10ms>             m_lastVeh10ms;
  shared_ptr<VEH10ms>             m_latestVeh10ms;

  shared_ptr<Subscriber<VEH50ms>> m_subVeh50ms;
  vector<shared_ptr<VEH50ms>>     m_veh50ms;
  shared_ptr<VEH50ms>             m_lastVeh50ms;
  shared_ptr<VEH50ms>             m_latestVeh50ms;

  // std::shared_ptr<Subscriber<nio::ad::messages::ParkingOut>> m_sub_parking_;
  // std::shared_ptr<nio::ad::messages::ParkingOut> m_latest_parking_;

  std::shared_ptr<Subscriber<nio::ad::messages::ObjectsDetection>>  m_sub_vision_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::RadarSensor>>       m_sub_radar_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::ForceSideFeatures>> m_sub_side_feature_;
  std::shared_ptr<Subscriber<nio::ad::messages::VEH10ms>>           m_sub_vehicle_10_;
  std::shared_ptr<Subscriber<nio::ad::messages::VEH50ms>>           m_sub_vehicle_50_;
  std::shared_ptr<Subscriber<nio::ad::messages::RoadDetection>>     m_sub_road_detection_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYObfOutputs>>     m_sub_fusion_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYEgoOutputs>>     m_sub_ehy_ego_;
  // std::shared_ptr<Subscriber<nio::ad::messages::EHYEvdOutputs>>           m_sub_ehy_evd_;
  // std::shared_ptr<Subscriber<nio::ad::messages::EHYHaOutputs>>            m_sub_ehy_ha_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYLppOutputs>> m_sub_ehy_lpp_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYRmeOutputs>> m_sub_ehy_rme_;
  // std::shared_ptr<Subscriber<nio::ad::messages::EHYTppOutputs>>           m_sub_ehy_tpp_;
  // std::shared_ptr<Subscriber<nio::ad::messages::EHYTsiOutputs>>           m_sub_ehy_tsi_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYTseOutputs>> m_sub_ehy_tse_;
  // std::shared_ptr<Subscriber<nio::ad::messages::EHYTsrOutputs>>           m_sub_ehy_tsr_;
  std::shared_ptr<Subscriber<nio::ad::messages::CameraFimInfo>>     m_sub_fim_camera_;
  std::shared_ptr<Subscriber<nio::ad::messages::FimCanInfo>>        m_sub_fim_can_;
  std::shared_ptr<Subscriber<nio::ad::messages::FimSoftwareInfo>>   m_sub_fim_sw_;
  std::shared_ptr<Subscriber<nio::ad::messages::CanFeatureFimInfo>> m_sub_fim_can_fea_;
  std::shared_ptr<Subscriber<nio::ad::messages::PowerFimInfo>>      m_sub_fim_power_;
  std::shared_ptr<Subscriber<nio::ad::messages::MCUWithSOCFimInfo>> m_sub_fim_mcu_soc_;
  std::shared_ptr<Subscriber<nio::ad::messages::LidarFimInfo>>      m_sub_fim_lidar_;
  std::shared_ptr<Subscriber<nio::ad::messages::McuSystemFimInfo>>  m_sub_fim_mcu_sys_;
  std::shared_ptr<Subscriber<nio::ad::messages::PerceptionFimInfo>> m_sub_fim_perception_;
  std::shared_ptr<Subscriber<nio::ad::messages::FailSafeDetection>> m_sub_failsafe_vision_;
  // std::shared_ptr<Subscriber<nio::ad::messages::FailSafeDetection>>       m_sub_failsafe_vision_calib_;
  std::shared_ptr<Subscriber<nio::ad::messages::Lidar_FailSafeDetection>> m_sub_failsafe_lidar_;
  std::shared_ptr<Subscriber<nio::ad::messages::VehVariantCode>>          m_sub_vehicle_variantcode_;
  std::shared_ptr<Subscriber<nio::ad::messages::VehicleAdfFod>>          m_sub_vehicle_adf_fod_;

  nio::ad::messages::CameraFimInfo     fim_camera_info_;
  nio::ad::messages::FimCanInfo        fim_can_info_;
  nio::ad::messages::FimSoftwareInfo   fim_sw_info_;
  nio::ad::messages::CanFeatureFimInfo fim_can_fea_info_;
  nio::ad::messages::PowerFimInfo      fim_power_info_;
  nio::ad::messages::MCUWithSOCFimInfo fim_mcu_soc_info_;
  nio::ad::messages::LidarFimInfo      fim_lidar_info_;
  nio::ad::messages::McuSystemFimInfo  fim_mcu_sys_info_;
  nio::ad::messages::PerceptionFimInfo fim_perception_info_;
  nio::ad::messages::FailSafeDetection failsafe_vision_info_;
  // nio::ad::messages::FailSafeDetection       failsafe_vision_calib_;
  nio::ad::messages::Lidar_FailSafeDetection failsafe_lidar_info_;

  std::shared_ptr<nio::ad::messages::CameraFimInfo>     m_latest_fim_camera_;
  std::shared_ptr<nio::ad::messages::FimCanInfo>        m_latest_fim_can_;
  std::shared_ptr<nio::ad::messages::FimSoftwareInfo>   m_latest_fim_sw_;
  std::shared_ptr<nio::ad::messages::CanFeatureFimInfo> m_latest_fim_can_fea_;
  std::shared_ptr<nio::ad::messages::PowerFimInfo>      m_latest_fim_power_;
  std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo> m_latest_fim_mcu_soc_;
  std::shared_ptr<nio::ad::messages::LidarFimInfo>      m_latest_fim_lidar_;
  std::shared_ptr<nio::ad::messages::McuSystemFimInfo>  m_latest_fim_mcu_sys_;
  std::shared_ptr<nio::ad::messages::PerceptionFimInfo> m_latest_fim_perception_;
  std::shared_ptr<nio::ad::messages::FailSafeDetection> m_latest_failsafe_vision_;
  // std::shared_ptr<nio::ad::messages::FailSafeDetection>       m_latest_failsafe_vision_calib_;
  std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> m_latest_failsafe_lidar_;

  // declare publisers as output
  shared_ptr<Publisher<FctsOut>> m_pub;

  // shared_ptr<Publisher<esd_np_feature>> m_pub_esd;

  std::shared_ptr<Publisher<nio::ad::messages::ARBOut>>             m_pub_arbout_;
  std::shared_ptr<Publisher<nio::ad::messages::debug::AEBDebugOut>> m_pub_aebdebugout_;

  // nio::ad::messages::ParkingOut m_dummy_parking_data_;
  nio::ad::messages::FctOut m_dummy_fct_data_;

 public:
  // Getters for accessing the latest instance of the messages and the possible previous instance of the message
  // recevied in the current frame
  const shared_ptr<FctOut>& GetLastFctOut() const {
    return m_lastFctOut;
  };
  const shared_ptr<FctOut>& GetLatestFctOut() const {
    return m_latestFctOut;
  };

  const shared_ptr<VEH10ms>& GetLastVeh10ms() const {
    return m_lastVeh10ms;
  };
  const shared_ptr<VEH10ms>& GetLatestVeh10ms() const {
    return m_latestVeh10ms;
  };

  const shared_ptr<VEH50ms>& GetLastVeh50ms() const {
    return m_lastVeh50ms;
  };
  const shared_ptr<VEH50ms>& GetLatestVeh50ms() const {
    return m_latestVeh50ms;
  };

 public:
  std::string OnInit() override {
    // Create subscribers and publishers
    m_sub = m_node->CreateSubscriber<FctOut>("np/apps/fct_out");
    m_pub = m_node->CreatePublisher<FctsOut>("np/apps/fcts_out");
    // m_pub_esd = m_node->CreatePublisher<esd_np_feature>("common/esd/esd_np_feature");

    m_subVeh10ms = m_node->CreateSubscriber<VEH10ms>("common/vehicle_in/vehicle_10ms");
    m_subVeh50ms = m_node->CreateSubscriber<VEH50ms>("common/vehicle_in/vehicle_50ms");
    // m_sub_parking_ = m_node->CreateSubscriber<nio::ad::messages::ParkingOut>("np/apps/parking_outputs");

    m_pub_arbout_ = m_node->CreatePublisher<nio::ad::messages::ARBOut>("np/apps/arb_out");
    m_pub_aebdebugout_ =
      m_node->CreatePublisher<nio::ad::messages::debug::AEBDebugOut>("np/debug/dgb_aebstrategy", QoS::SensorDataQoS());

    m_sub_vision_object_ =
      m_node->CreateSubscriber<nio::ad::messages::ObjectsDetection>("common/perception/perception_objects");
    m_sub_radar_object_ = m_node->CreateSubscriber<nio::ad::messages::RadarSensor>("common/perception/radar_object");
    m_sub_side_feature_ =
      m_node->CreateSubscriber<nio::ad::messages::ForceSideFeatures>("common/perception/side_feature");
    m_sub_road_detection_ = m_node->CreateSubscriber<nio::ad::messages::RoadDetection>(
      "common/perception/vision_road_detection", QoS::SensorDataQoS(), nullptr);
    m_sub_fusion_object_ = m_node->CreateSubscriber<nio::ad::messages::EHYObfOutputs>("np/apps/ehy_obf_outputs");
    m_sub_ehy_ego_       = m_node->CreateSubscriber<nio::ad::messages::EHYEgoOutputs>("np/apps/ehy_ego_outputs");
    // m_sub_ehy_evd_       = m_node->CreateSubscriber<nio::ad::messages::EHYEvdOutputs>("np/apps/ehy_evd_outputs");
    // m_sub_ehy_ha_        = m_node->CreateSubscriber<nio::ad::messages::EHYHaOutputs>("np/apps/ehy_ha_outputs");
    m_sub_ehy_lpp_ = m_node->CreateSubscriber<nio::ad::messages::EHYLppOutputs>("np/apps/ehy_lpp_outputs");
    m_sub_ehy_rme_ = m_node->CreateSubscriber<nio::ad::messages::EHYRmeOutputs>("np/apps/ehy_rme_road_outputs");
    // m_sub_ehy_tpp_       = m_node->CreateSubscriber<nio::ad::messages::EHYTppOutputs>("np/apps/ehy_tpp_outputs");
    // m_sub_ehy_tsi_       = m_node->CreateSubscriber<nio::ad::messages::EHYTsiOutputs>("np/apps/ehy_tsi_outputs");
    m_sub_ehy_tse_ = m_node->CreateSubscriber<nio::ad::messages::EHYTseOutputs>("np/apps/ehy_tse_outputs");
    // m_sub_ehy_tsr_       = m_node->CreateSubscriber<nio::ad::messages::EHYTsrOutputs>("np/apps/ehy_tsr_outputs");

    m_sub_fim_camera_ = m_node->CreateSubscriber<nio::ad::messages::CameraFimInfo>("common/diagnostic/fim/fim_cameras");
    m_sub_fim_can_    = m_node->CreateSubscriber<nio::ad::messages::FimCanInfo>("common/diagnostic/fim/fim_can");
    m_sub_fim_sw_ = m_node->CreateSubscriber<nio::ad::messages::FimSoftwareInfo>("common/diagnostic/fim/fim_software");
    m_sub_fim_can_fea_ =
      m_node->CreateSubscriber<nio::ad::messages::CanFeatureFimInfo>("common/diagnostic/fim/fim_can_feature");
    m_sub_fim_power_ =
      m_node->CreateSubscriber<nio::ad::messages::PowerFimInfo>("common/diagnostic/fim/fim_power_rail");
    m_sub_fim_mcu_soc_ =
      m_node->CreateSubscriber<nio::ad::messages::MCUWithSOCFimInfo>("common/diagnostic/fim/fim_mcuwithsoc_can");
    m_sub_fim_lidar_ = m_node->CreateSubscriber<nio::ad::messages::LidarFimInfo>("common/diagnostic/fim/fim_lidar");
    m_sub_fim_mcu_sys_ =
      m_node->CreateSubscriber<nio::ad::messages::McuSystemFimInfo>("common/diagnostic/fim/fim_mcu_system");
    m_sub_fim_perception_ =
      m_node->CreateSubscriber<nio::ad::messages::PerceptionFimInfo>("common/diagnostic/fim/fim_perception");
    m_sub_failsafe_vision_ =
      m_node->CreateSubscriber<nio::ad::messages::FailSafeDetection>("common/perception/vision_failsafe");
    // m_sub_failsafe_vision_calib_ =
    //   m_node->CreateSubscriber<nio::ad::messages::FailSafeDetection>("common/perception/vision_failsafe_calibration");
    m_sub_failsafe_lidar_ =
      m_node->CreateSubscriber<nio::ad::messages::Lidar_FailSafeDetection>("common/perception/lidar_failsafe");
    m_sub_vehicle_variantcode_ = m_node->CreateSubscriber<nio::ad::messages::VehVariantCode>(
      "common/platform/mcu_proxy/vehicle/vehicle_variant_code");
    m_sub_vehicle_adf_fod_ = m_node->CreateSubscriber<nio::ad::messages::VehicleAdfFod>(
      "common/platform/mcu_proxy/vehicle/vehicle_adf_fod");

    m_latest_fim_camera_  = std::make_shared<nio::ad::messages::CameraFimInfo>(fim_camera_info_);
    m_latest_fim_can_     = std::make_shared<nio::ad::messages::FimCanInfo>(fim_can_info_);
    m_latest_fim_sw_      = std::make_shared<nio::ad::messages::FimSoftwareInfo>(fim_sw_info_);
    m_latest_fim_can_fea_ = std::make_shared<nio::ad::messages::CanFeatureFimInfo>(fim_can_fea_info_);
    m_latest_fim_power_   = std::make_shared<nio::ad::messages::PowerFimInfo>(fim_power_info_);
    m_latest_fim_mcu_soc_ = std::make_shared<nio::ad::messages::MCUWithSOCFimInfo>(fim_mcu_soc_info_);
    m_latest_fim_lidar_   = std::make_shared<nio::ad::messages::LidarFimInfo>(fim_lidar_info_);
    // m_latest_parking_               = std::make_shared<nio::ad::messages::ParkingOut>(m_dummy_parking_data_);
    m_latestFctOut            = std::make_shared<nio::ad::messages::FctOut>(m_dummy_fct_data_);
    m_latest_fim_mcu_sys_     = std::make_shared<nio::ad::messages::McuSystemFimInfo>(fim_mcu_sys_info_);
    m_latest_fim_perception_  = std::make_shared<nio::ad::messages::PerceptionFimInfo>(fim_perception_info_);
    m_latest_failsafe_vision_ = std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_vision_info_);
    // m_latest_failsafe_vision_calib_ = std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_vision_calib_);
    m_latest_failsafe_lidar_ = std::make_shared<nio::ad::messages::Lidar_FailSafeDetection>(failsafe_lidar_info_);

    // Init features
    INFO_LOG << "Pre Init featuers";
    std::vector<std::string> intput_args = niodds::GetArguments();
    /*     if (std::find(intput_args.begin(), intput_args.end(), "--shadowmode") != intput_args.end()) {
          k_AEBShadowMode_active = true;
          DEBUG_LOG << "AEB shadow mode active";
        } else {
          k_AEBShadowMode_active = false;
          DEBUG_LOG << "AEB in normal mode";
        }

        if (std::find(intput_args.begin(), intput_args.end(), "--shadowmode_soft") != intput_args.end()) {
          kAebShadowModeSoft = true;
          DEBUG_LOG << "AEB shadow mode soft active";
        } else {
          kAebShadowModeSoft = false;
          DEBUG_LOG << "AEB in normal mode";
        } */

    if (std::find(intput_args.begin(), intput_args.end(), "--hilmode") != intput_args.end()) {
      kAebHilMode = true;
      DEBUG_LOG << "AEB hil mode active";
    } else {
      kAebHilMode = false;
      DEBUG_LOG << "AEB in normal mode";
    }

    arb_init();



    ArbState = APP_state_e::Init;
#ifdef ARB_XCP_ENABLED
    INFO_LOG << "xcp init";
    TcpServerStart(9997);
    xcp_if_init();
#endif
    INFO_LOG << "Post Init features";
    m_interval = kDefaultInterval;  // set the app to run in 20hz by default
                                    // this value can be overriden by providing a manifest file to the launcher
    return "";
  }

  std::string OnProc(uint64_t timestamp, int32_t dt) override {
    // Read frames from subscribers
    if (m_sub->HasReceived()) {
      auto temp_received_ = m_fctOut;
      // update the object list
      m_sub->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        m_fctOut = temp_received_;
        if (m_fctOut.size() > 1) {
          m_lastFctOut = m_fctOut[m_fctOut.size() - 2];
        }
        m_latestFctOut = m_fctOut[m_fctOut.size() - 1];
        DEBUG_LOG << "Received " << m_fctOut.size() << " FctOut messages";
        DEBUG_LOG << "fctout received in arb";
      } else {
        m_lastFctOut.reset();
        DEBUG_LOG << "Did not Receive FctOut message";
        DEBUG_LOG << "Did not Receive FctOut message";
      }
    } else {
      m_lastFctOut.reset();
      DEBUG_LOG << "Did not Receive FctOut message";
      DEBUG_LOG << "Did not Receive FctOut message";
    }
    // Only pass the latest messages to fct_main, and it is also possible that multiple instances of same type of
    // messages have been received If need to check from inside fct_main about if there are additional messages recevied
    // in the current frame, do it like the following code snippets: auto& v50ms =
    // Application::GetInstance("FctApp").GetLastVeh50ms(); if(v50ms)
    //{
    //  //Process the two veh50ms messages together
    //}

    if (m_subVeh10ms->HasReceived()) {
      // update the object list
      auto temp_received_ = m_veh10ms;
      m_subVeh10ms->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        m_veh10ms             = temp_received_;
        arb_vehicle_input_10_ = m_veh10ms;
        if (m_veh10ms.size() > 1) {
          m_lastVeh10ms = m_veh10ms[m_veh10ms.size() - 2];
        }
        m_latestVeh10ms = m_veh10ms[m_veh10ms.size() - 1];
        DEBUG_LOG << "Received " << m_veh10ms.size() << " Veh10ms messages";
        DEBUG_LOG << "vehicle_10ms received in arb";
      } else {
        m_lastVeh10ms.reset();
        DEBUG_LOG << "Did not Receive Veh10ms message";
        DEBUG_LOG << "Did not Receive Veh10ms message";
      }
    } else {
      m_lastVeh10ms.reset();
      DEBUG_LOG << "Did not Receive Veh10ms message";
      DEBUG_LOG << "Did not Receive Veh10ms message";
    }

    if (m_subVeh50ms->HasReceived()) {
      // update the object list
      auto temp_received_ = m_veh50ms;
      m_subVeh50ms->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        m_veh50ms             = temp_received_;
        arb_vehicle_input_50_ = m_veh50ms;
        if (m_veh50ms.size() > 1) {
          m_lastVeh50ms = m_veh50ms[m_veh50ms.size() - 2];
        }
        m_latestVeh50ms = m_veh50ms[m_veh50ms.size() - 1];
        DEBUG_LOG << "Received " << m_veh50ms.size() << " Veh50ms messages";
        DEBUG_LOG << "vehicle_50ms received in arb";
      } else {
        m_lastVeh50ms.reset();
        DEBUG_LOG << "Did not Receive Veh50ms message";
        DEBUG_LOG << "Did not Receive Veh50ms message";
      }
    } else {
      m_lastVeh50ms.reset();
      DEBUG_LOG << "Did not Receive Veh50ms message";
      DEBUG_LOG << "Did not Receive Veh50ms message";
    }
    // update the parking app output
    // if (m_sub_parking_->HasReceived()) {
    //   auto temp_received_ = m_parking_;
    //   m_sub_parking_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     m_parking_        = temp_received_;
    //     m_latest_parking_ = m_parking_.back();
    //     DEBUG_LOG << "Received " << m_parking_.size() << " ParkingOutputs messages";
    //     DEBUG_LOG << "ParkingOutputs received in arb";
    //   } else {
    //     DEBUG_LOG << "Did not Receive ParkingOutputs message";
    //     DEBUG_LOG << "Did not Receive ParkingOutputs message";
    //   }
    // } else {
    //   // m_parking_.clear();
    //   DEBUG_LOG << "Did not Receive ParkingOutputs message";
    //   DEBUG_LOG << "Did not Receive ParkingOutputs message";
    // }

    if (m_sub_vision_object_->HasReceived()) {
      // update the object list
      auto temp_received_ = arb_vision_objects_;
      m_sub_vision_object_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_vision_objects_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_vision_object_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_vision_object_: NOT RECEIVE";
    }

    if (m_sub_radar_object_->HasReceived()) {
      // update the radar object list
      auto temp_received_ = arb_radar_data_;
      m_sub_radar_object_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_radar_data_ = temp_received_;
        DEBUG_LOG << "Fcts_fault_log_radar_object_:  RECEIVE";
      } else {
        DEBUG_LOG << "Fcts_fault_log_radar_object_:  EMPTY";
      }
    } else {
      DEBUG_LOG << "Fcts_fault_log_radar_object_: NOT RECEIVE";
    }

    if (m_sub_side_feature_->HasReceived()) {
      // update the side feature list
      auto temp_received_ = arb_side_feature_;
      m_sub_side_feature_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_side_feature_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_side_feature_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_side_feature_: NOT RECEIVE";
    }

    if (m_sub_road_detection_->HasReceived()) {
      // Update road info
      auto temp_received_ = arb_road_detection_;
      m_sub_road_detection_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_road_detection_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_road_detection_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_road_detection_: NOT RECEIVE";
    }

    if (m_sub_fusion_object_->HasReceived()) {
      // update obf
      auto temp_received_ = arb_fusion_object_;
      m_sub_fusion_object_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fusion_object_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_fusion_object_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_fusion_object_: NOT RECEIVE";
    }

    if (m_sub_ehy_ego_->HasReceived()) {
      // update ego
      auto temp_received_ = arb_ehy_ego_;
      m_sub_ehy_ego_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_ehy_ego_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_ehy_ego_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_ehy_ego_: NOT RECEIVE";
    }

    if (m_sub_vehicle_variantcode_->HasReceived()) {
      auto temp_received_ = arb_vehicle_variant_info;
      m_sub_vehicle_variantcode_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_vehicle_variant_info = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_ehy_ego_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_ehy_ego_: NOT RECEIVE";
    }

    // if (m_sub_ehy_evd_->HasReceived()) {
    //   // update evd
    //   auto temp_received_ = arb_ehy_evd_;
    //   m_sub_ehy_evd_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_ehy_evd_ = temp_received_;
    //   } else {
    //     DEBUG_LOG << "m_sub_ehy_evd_: EMPTY RECEIVE";
    //   }
    // } else {
    //   DEBUG_LOG << "m_sub_ehy_evd_: NOT RECEIVE";
    // }

    // if (m_sub_ehy_ha_->HasReceived()) {
    //   // update ha
    //   auto temp_received_ = arb_ehy_ha_;
    //   m_sub_ehy_ha_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_ehy_ha_ = temp_received_;
    //   } else {
    //     DEBUG_LOG << "m_sub_ehy_ha_: EMPTY RECEIVE";
    //   }
    // } else {
    //   DEBUG_LOG << "m_sub_ehy_ha_: NOT RECEIVE";
    // }

    if (m_sub_ehy_lpp_->HasReceived()) {
      // update lpp
      auto temp_received_ = arb_ehy_lpp_;
      m_sub_ehy_lpp_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_ehy_lpp_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_ehy_lpp_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_ehy_lpp_: NOT RECEIVE";
    }

    if (m_sub_ehy_rme_->HasReceived()) {
      // update rme
      auto temp_received_ = arb_ehy_rme_;
      m_sub_ehy_rme_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_ehy_rme_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_ehy_rme_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_ehy_rme_: NOT RECEIVE";
    }

    // if (m_sub_ehy_tpp_->HasReceived()) {
    //   // update tpp
    //   auto temp_received_ = arb_ehy_tpp_;
    //   m_sub_ehy_tpp_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_ehy_tpp_ = temp_received_;
    //   } else {
    //     DEBUG_LOG << "m_sub_ehy_tpp_: EMPTY RECEIVE";
    //   }
    // } else {
    //   DEBUG_LOG << "m_sub_ehy_tpp_: NOT RECEIVE";
    // }

    // if (m_sub_ehy_tsi_->HasReceived()) {
    //   // update tsi
    //   auto temp_received_ = arb_ehy_tsi_;
    //   m_sub_ehy_tsi_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_ehy_tsi_ = temp_received_;
    //   } else {
    //     DEBUG_LOG << "m_sub_ehy_tsi_: EMPTY RECEIVE";
    //   }
    // } else {
    //   DEBUG_LOG << "m_sub_ehy_tsi_: NOT RECEIVE";
    // }

    if (m_sub_ehy_tse_->HasReceived()) {
      // update tse
      auto temp_received_ = arb_ehy_tse_;
      m_sub_ehy_tse_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_ehy_tse_ = temp_received_;
      } else {
        DEBUG_LOG << "m_sub_ehy_tse_: EMPTY RECEIVE";
      }
    } else {
      DEBUG_LOG << "m_sub_ehy_tse_: NOT RECEIVE";
    }

    // if (m_sub_ehy_tsr_->HasReceived()) {
    //   // update ego
    //   auto temp_received_ = arb_ehy_tsr_;
    //   m_sub_ehy_tsr_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_ehy_tsr_ = temp_received_;
    //   } else {
    //     DEBUG_LOG << "m_sub_ehy_tsr_: EMPTY RECEIVE";
    //   }
    // } else {
    //   DEBUG_LOG << "m_sub_ehy_tsr_: NOT RECEIVE";
    // }

    if (m_sub_fim_camera_->HasReceived()) {
      auto temp_received_ = arb_fim_camera_info;
      m_sub_fim_camera_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_camera_info  = temp_received_;
        m_latest_fim_camera_ = arb_fim_camera_info.back();
        DEBUG_LOG << "Received " << arb_fim_camera_info.size() << "arb_fim_camera_info";
        DEBUG_LOG << "arb_fim_camera_info received in fcts";
      } else {
        DEBUG_LOG << " Receive  empty arb_fim_camera_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_camera_info message";
    }

    if (m_sub_fim_can_->HasReceived()) {
      auto temp_received_ = arb_fim_can_info;
      m_sub_fim_can_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_can_info  = temp_received_;
        m_latest_fim_can_ = arb_fim_can_info.back();
        DEBUG_LOG << "Received " << arb_fim_can_info.size() << "arb_fim_can_info";
        DEBUG_LOG << "arb_fim_can_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_can_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_can_info message";
    }

    if (m_sub_fim_sw_->HasReceived()) {
      auto temp_received_ = arb_fim_sw_info;
      m_sub_fim_sw_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_sw_info  = temp_received_;
        m_latest_fim_sw_ = arb_fim_sw_info.back();
        DEBUG_LOG << "Received " << arb_fim_sw_info.size() << "arb_fim_sw_info";
        DEBUG_LOG << "arb_fim_sw_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_sw_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_sw_info message";
    }

    if (m_sub_fim_can_fea_->HasReceived()) {
      auto temp_received_ = arb_fim_can_fea_info;
      m_sub_fim_can_fea_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_can_fea_info  = temp_received_;
        m_latest_fim_can_fea_ = arb_fim_can_fea_info.back();
        DEBUG_LOG << "arb_fim_camera_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_can_fea_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_can_fea_info message";
    }

    if (m_sub_fim_power_->HasReceived()) {
      auto temp_received_ = arb_fim_power_info;
      m_sub_fim_power_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_power_info  = temp_received_;
        m_latest_fim_power_ = arb_fim_power_info.back();
        DEBUG_LOG << "arb_fim_power_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_power_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_power_info message";
    }

    if (m_sub_fim_mcu_soc_->HasReceived()) {
      auto temp_received_ = arb_fim_mcu_soc_info;
      m_sub_fim_mcu_soc_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_mcu_soc_info  = temp_received_;
        m_latest_fim_mcu_soc_ = arb_fim_mcu_soc_info.back();
        DEBUG_LOG << "arb_fim_mcu_soc_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_mcu_soc_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_mcu_soc_info message";
    }

    if (m_sub_fim_lidar_->HasReceived()) {
      auto temp_received_ = arb_fim_lidar_info;
      m_sub_fim_lidar_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_lidar_info  = temp_received_;
        m_latest_fim_lidar_ = arb_fim_lidar_info.back();
        DEBUG_LOG << "arb_fim_lidar_info received in fcts";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_lidar_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_lidar_info message";
    }

    if (m_sub_fim_mcu_sys_->HasReceived()) {
      auto temp_received_ = arb_fim_mcu_sys_info;
      m_sub_fim_mcu_sys_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_mcu_sys_info  = temp_received_;
        m_latest_fim_mcu_sys_ = arb_fim_mcu_sys_info.back();
        DEBUG_LOG << "arb_fim_mcu_sys_info received in fct";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_mcu_sys_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_mcu_sys_info message";
    }

    if (m_sub_fim_perception_->HasReceived()) {
      auto temp_received_ = arb_fim_perception_info;
      m_sub_fim_perception_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_fim_perception_info  = temp_received_;
        m_latest_fim_perception_ = arb_fim_perception_info.back();
        DEBUG_LOG << "arb_fim_perception_info received in fct";
      } else {
        DEBUG_LOG << "Receive empty arb_fim_perception_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fim_perception_info message";
    }

    if (m_sub_failsafe_vision_->HasReceived()) {
      auto temp_received_ = arb_failsafe_vision_info;
      m_sub_failsafe_vision_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_failsafe_vision_info  = temp_received_;
        m_latest_failsafe_vision_ = arb_failsafe_vision_info.back();
        DEBUG_LOG << "arb_fsailsafe_vision_info received in fct";
      } else {
        DEBUG_LOG << "Receive empty arb_fsailsafe_vision_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_fsailsafe_vision_info message";
    }

    // if (m_sub_failsafe_vision_calib_->HasReceived()) {
    //   auto temp_received_ = arb_failsafe_vision_calib;
    //   m_sub_failsafe_vision_calib_->ReadReceived(temp_received_);
    //   if (!temp_received_.empty()) {
    //     arb_failsafe_vision_calib       = temp_received_;
    //     m_latest_failsafe_vision_calib_ = arb_failsafe_vision_calib.back();
    //     DEBUG_LOG << "arb_failsafe_vision_calibration received in fct";
    //   } else {
    //     DEBUG_LOG << "Receive empty arb_failsafe_vision_calibration message";
    //   }
    // } else {
    //   DEBUG_LOG << "Did not Receive arb_failsafe_vision_calibration message";
    // }

    if (m_sub_failsafe_lidar_->HasReceived()) {
      auto temp_received_ = arb_failsafe_lidar_info;
      m_sub_failsafe_lidar_->ReadReceived(temp_received_);
      if (!temp_received_.empty()) {
        arb_failsafe_lidar_info  = temp_received_;
        m_latest_failsafe_lidar_ = arb_failsafe_lidar_info.back();
        DEBUG_LOG << "arb_failsafe_lidar_info received in fct";
      } else {
        DEBUG_LOG << "Receive empty arb_failsafe_lidar_info message";
      }
    } else {
      DEBUG_LOG << "Did not Receive arb_failsafe_lidar_info message";
    }

    init_max_cnt++;
    if (init_max_cnt > 20000) {
      init_max_cnt = 20000;
    }
    ArbState_lf = ArbState;
    arb_diag_main(m_latest_fim_camera_, m_latest_fim_can_, m_latest_fim_sw_, m_latest_fim_can_fea_, m_latest_fim_power_,
                  m_latest_fim_mcu_sys_, m_latest_fim_mcu_soc_, m_latest_fim_lidar_, m_latest_fim_perception_,
                  m_latest_failsafe_vision_, m_latest_failsafe_lidar_);
    ArbState = APP_StateManage(Arb_TopicNoInit, Arb_InitMask, Arb_TopicLoss, Arb_LossMask);

    if ((gAEBFaultSt != FimFault_e::NoFault) && (init_max_cnt < 15000)) {
      ArbState = APP_state_e::Suspend;
    }

    if (ArbState == APP_state_e::Suspend && init_max_cnt >= 15000) {
      ArbState = APP_state_e::Failure;
    }

    if (ArbState_lf != ArbState) {
      INFO_LOG << "fcts_app state transform : " << static_cast<uint32_t>(ArbState_lf) << " ->  "
               << static_cast<uint32_t>(ArbState);
      INFO_LOG << "Fcts_Fault_Log TopicNoInit : " << static_cast<uint32_t>(Arb_TopicNoInit);
      INFO_LOG << "Fcts_Fault_Log TopicLoss : " << static_cast<uint32_t>(Arb_TopicLoss);
      INFO_LOG << "Fcts_Fault_Log init_max_cnt : " << static_cast<uint32_t>(init_max_cnt);
    }

    auto arb_out_data   = make_shared<ARBOut>();
    auto aeb_debug_data = make_shared<AEBDebugOut>();
    auto fctsout        = make_shared<FctsOut>();
    // auto fcts_esd_out   = make_shared<esd_np_feature>();
    if (ArbState == APP_state_e::Suspend) {
      DEBUG_LOG << "FCTS_app Suspend";
      // ads_message_fill(*ads, m_latest_parking_, 0, 0);
      fcts_init_output(*fctsout);
      fcts_esd_init_output(*fctsout);
      aeb_output_pub_.fill_in_AEBdebug_outputs(aeb_debug_data);
      fcts_fault_log(*fctsout);
      m_pub->Publish(fctsout);
      // m_pub_esd->Publish(fcts_esd_out);
      m_pub_arbout_->Publish(arb_out_data);
      m_pub_aebdebugout_->Publish(aeb_debug_data);
    } else if ((ArbState == APP_state_e::PartialActive) || (ArbState == APP_state_e::FullActive)) {
      // auto ts = Time::Now();
      DEBUG_LOG << "Calling arb_main";
      arb_main(*m_latestVeh10ms, *m_latestVeh50ms, *fctsout, arb_sin, &arb_input_adapter_, &aeb_output_pub_,
               Arb_TopicNoInit, Arb_TopicLoss);
      aeb_output_pub_.fill_in_ARBflag_outputs(arb_out_data);
      aeb_output_pub_.fill_in_AEBdebug_outputs(aeb_debug_data);
      fcts_esd_fill_output(*fctsout);
      fcts_fault_log(*fctsout);
      // auto dur = Time::Now() - ts;
      if (arb_fusion_object_.size() > 0) {
        nio::common::TraceUtils::fillTraceFields(arb_fusion_object_.back(), fctsout, "fcts_out");
      }
      m_pub->Publish(fctsout);
      // m_pub_esd->Publish(fcts_esd_out);
      m_pub_arbout_->Publish(arb_out_data);
      m_pub_aebdebugout_->Publish(aeb_debug_data);
#ifdef ARB_XCP_ENABLED
      xcp_if_service();
#endif
      // DEBUG_LOG << "Cost: " << Time::Now() - ts << "ms";
      // DEBUG_LOG << "Cost: " << dur << "ms";
    } else if (ArbState == APP_state_e::Failure) {
      DEBUG_LOG << "FCTS_app Failure";
      // ads_message_fill(*ads, m_latest_parking_, 0xFFFFFFFF, 0xFFFFFFFF);
      fcts_fail_output(*fctsout);
      fcts_esd_fail_output(*fctsout);
      aeb_output_pub_.fill_in_AEBdebug_outputs(aeb_debug_data);
      fcts_fault_log(*fctsout);
      m_pub->Publish(fctsout);
      // m_pub_esd->Publish(fcts_esd_out);
      m_pub_arbout_->Publish(arb_out_data);
      m_pub_aebdebugout_->Publish(aeb_debug_data);
      // TODO
    }
    return "";
  }

  std::string OnFinalize() override {
    // TODO: put your clean up code here
    DEBUG_LOG << "FCTS_app exit";
    ArbState = APP_state_e::exit;
    if (ArbState_lf != ArbState) {
      INFO_LOG << "fcts_app state transform : " << static_cast<uint32_t>(ArbState_lf) << " ->  "
               << static_cast<uint32_t>(ArbState);
    }
    ArbState_lf = ArbState;
    return "";
  }

  using Application::Application;
};  // namespace ad
REGISTER_APP("fcts_app", FCTSApp);
}  // namespace ad
}  // namespace nio
