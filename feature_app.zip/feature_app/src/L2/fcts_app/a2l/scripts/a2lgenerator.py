#!/usr/bin/env python3
import re
import sys


class AxisPts:
    def __init__(self):
        self.name_ = None              #
        self.long_identifier_ = None   #optional
        self.ECU_address_ = None       #optional
        self.input_quantity_ = "NO_INPUT_QUANTITY"    
        self.record_layout_ = None     #
        self.maxdiff_ = None           #?
        self.conversion_method_ = None #
        self.num_axis_pts_ = None      #
        self.lower_limit_ = None
        self.upper_limit_ = None

    def set_param(self, info):
        self.name_ = info["name"]              
        self.long_identifier_ = info["long_identifier"]   
        self.ECU_address_ = info["ecu_address"] 
        self.record_layout_ = info["record_layout"]  
        self.maxdiff_ = info["maxdiff"]          
        self.conversion_method_ = info["cm"] 
        self.num_axis_pts_ = info["num_axis_pts"]      
        self.lower_limit_ = info["lower_limit"]
        self.upper_limit_ = info["upper_limit"]

    def get_block(self, indent1, indent2):
        lines = ""
        lines += "\n"
        lines += indent1*" " + "/begin AXIS_PTS\n"
        lines += indent2*" " + "/* Name                   */      " + self.name_              + "\n"
        lines += indent2*" " + "/* Long Identifier        */      " + self.long_identifier_   + "\n"   
        lines += indent2*" " + "/* ECU Address            */      " + self.ECU_address_       + " /* @ECU_Address@" + self.name_ + "@ */" + "\n"                           
        lines += indent2*" " + "/* Input Quantity         */      " + self.input_quantity_    + "\n"
        lines += indent2*" " + "/* Record Layout          */      " + self.record_layout_     + "\n"
        lines += indent2*" " + "/* Maximum Difference     */      " + self.maxdiff_           + "\n"
        lines += indent2*" " + "/* Conversion Method      */      " + self.conversion_method_ + "\n"
        lines += indent2*" " + "/* Number of Axis Pts     */      " + self.num_axis_pts_      + "\n"
        lines += indent2*" " + "/* Lower Limit            */      " + self.lower_limit_       + "\n"
        lines += indent2*" " + "/* Upper Limit            */      " + self.upper_limit_       + "\n" 
        lines += indent1*" " + "/end AXIS_PTS\n"
        return lines


class AxisDescr:
    def __init__(self):
        self.xy_axis_ = None              #
        self.axis_type_ = None            #required?
        self.ref_to_input_ = None
        self.conversion_method_ = None    #optional
        self.num_axis_pts_ = None         #
        self.lower_limit_ = None          #optional  
        self.upper_limit_ = None          #optional
        self.axis_pts_ref = None          #
    
    def set_param(self, info):
        self.xy_axis_ = info["xy_axis"]        
        self.axis_type_ = info["axis_type"]           
        self.ref_to_input_ = "NO_INPUT_QUANTITY"
        self.conversion_method_ = info["cm"]    
        self.num_axis_pts_ = info["num_axis_pts"]      
        self.lower_limit_ = info["lower_limit"]
        self.upper_limit_ = info["upper_limit"]        
        self.axis_pts_ref = info["axis_pts_ref"]      

    def get_block(self, indent1, indent2):
        lines = ""
        lines += indent1*" " + "/begin AXIS_DESCR\n"
        lines += indent2*" " + "/* Description of " + self.xy_axis_ + "-Axis Points */" + "\n"  #一个descr的情况下都是x，map的情况下第一个是y，第二个是x
        lines += indent2*" " + "/* Axis Type            */      " + self.axis_type_         + "\n"
        lines += indent2*" " + "/* Reference to Input   */      " + self.ref_to_input_      + "\n"
        lines += indent2*" " + "/* Conversion Method    */      " + self.conversion_method_ + "\n"
        lines += indent2*" " + "/* Number of Axis Pts   */      " + self.num_axis_pts_      + "\n"
        lines += indent2*" " + "/* Lower Limit          */      " + self.lower_limit_       + "\n"
        lines += indent2*" " + "/* Upper Limit          */      " + self.upper_limit_       + "\n" 
        lines += indent2*" " + "AXIS_PTS_REF                    " + self.axis_pts_ref       + "\n"
        lines += indent1*" " + "/end AXIS_DESCR\n"
        return lines


class Characteristic:
    def __init__(self):
        self.name_ = None                 #
        self.type_ = None                 #optional
        self.long_identifier_ = None      #optional
        self.characteristic_type_ = None  #
        self.ECU_address_ = None          #optional
        self.record_layout_ = None        #
        self.maxdiff_ = None              #    
        self.conversion_method_ = None    #
        self.lower_limit_ = None          #optional
        self.upper_limit_ = None          #optional
        self.axis_descr_list_ = []
        self.axis_pts_list_ = []
        
    def set_param(self, info):
        self.name_ = info["name"]       
        self.type_ = info["type"]       
        self.long_identifier_ = info["long_identifier"]   
        self.characteristic_type_ = info["ctype"]
        self.ECU_address_ = info["ecu_address"]
        self.record_layout_ = info["record_layout"]        
        self.maxdiff_ = info["maxdiff"]
        self.conversion_method_ = info["cm"]    
        self.lower_limit_ = info["lower_limit"]
        self.upper_limit_ = info["upper_limit"]
        for i in range(len(info["axis_descr_info"])):
            new_descr = AxisDescr() 
            new_pts = AxisPts()
            new_descr.set_param(info["axis_descr_info"][i])
            new_pts.set_param(info["axis_pts_info"][i])
            self.axis_descr_list_.append(new_descr)
            self.axis_pts_list_.append(new_pts)

    def get_block(self, indent1, indent2, exist_axis, has_axis=True):
        lines = ""
        lines += "\n"
        lines += indent1*" " + "/begin CHARACTERISTIC\n"
        lines += indent2*" " + "/* Name                   */      " + self.name_              + "\n"
        lines += indent2*" " + "/* Long Identifier        */      " + self.long_identifier_   + "\n"  
        if has_axis: 
            lines += indent2*" " + "/* Characteristic Type    */      " + self.characteristic_type_ + "\n"
        else:
            lines += indent2*" " + "/* Type                   */      " + self.type_ + "\n"
        lines += indent2*" " + "/* ECU Address            */      " + self.ECU_address_       + " /* @ECU_Address@" + self.name_ + "@ */" + "\n"                           
        lines += indent2*" " + "/* Record Layout          */      " + self.record_layout_     + "\n"
        lines += indent2*" " + "/* Maximum Difference     */      " + self.maxdiff_           + "\n"
        lines += indent2*" " + "/* Conversion Method      */      " + self.conversion_method_ + "\n"
        lines += indent2*" " + "/* Lower Limit            */      " + self.lower_limit_       + "\n"
        lines += indent2*" " + "/* Upper Limit            */      " + self.upper_limit_       + "\n" 
        for axis_descr in self.axis_descr_list_:
            lines += axis_descr.get_block(indent1+2, indent2+2)
        lines += indent1*" " + "/end CHARACTERISTIC\n"
        for axis_pts in self.axis_pts_list_:
            if axis_pts.name_ not in exist_axis:
                lines += axis_pts.get_block(indent1, indent2)
                exist_axis.append(axis_pts.name_)
        return lines


class Measurement:
    def __init__(self):
        self.name_ = None              #
        self.long_identifier_ = None   #optional
        self.data_type_ = None
        self.conversion_method_ = None    #optional
        self.resolution_ = None           #
        self.accuracy_ = None             #
        self.lower_limit_ = None          #optional  
        self.upper_limit_ = None  
        self.ecu_address_ = None

    def set_param(self, info):
        self.name_ = info["name"]
        self.long_identifier_ = info["long_identifier"]
        self.data_type_ = info["data_type"]
        self.conversion_method_ = info["cm"]
        self.resolution_ = info["res"]
        self.accuracy_ = info["accuracy"]
        self.lower_limit_ = info["lower_limit"]
        self.upper_limit_ = info["upper_limit"]
        self.ecu_address_ = info["ecu_address"]

    def get_block(self, indent1, indent2):
        lines = ""
        lines += "\n"
        lines += indent1*" " + "/begin MEASUREMENT\n"
        lines += indent2*" " + "/* Name                   */      " + self.name_              + "\n"
        lines += indent2*" " + "/* Long Identifier        */      " + self.long_identifier_   + "\n" 
        lines += indent2*" " + "/* Data type              */      " + self.data_type_         + "\n"
        lines += indent2*" " + "/* Conversion Method      */      " + self.conversion_method_ + "\n"
        lines += indent2*" " + "/* Resolution (Not used)  */      " + self.resolution_        + "\n"
        lines += indent2*" " + "/* Accuracy (Not used)    */      " + self.accuracy_          + "\n"
        lines += indent2*" " + "/* Lower Limit            */      " + self.lower_limit_       + "\n"
        lines += indent2*" " + "/* Upper Limit            */      " + self.upper_limit_       + "\n" 
        lines += indent2*" " + "ECU_ADDRESS                       " + self.ecu_address_       + " /* @ECU_Address@" + self.name_ + "@ */" + "\n"
        lines += indent1*" " + "/end MEASUREMENT\n"
        return lines


class CompuMethod:
    def __init__(self, name):
        type2format = {
            "single":"8.6",
            "double":"15.10",
            "boolean":"1.0",
            "uint8":"3.0",
            "uint16":"5.0",
            "uint32":"10.0",
            "int8":"3.0",
            "int16":"5.0",
            "int32":"10.0",
        }
        name_splited = name.split('_')
        base_pos = 0
        for i, token in enumerate(name_splited):
            if token == 'CM':
                base_pos = i
        type_str = name_splited[base_pos+1]
        self.name_ = name
        if type_str in type2format:
            self.format_ = type2format[type_str]
            self.units_ = ""
            if len(name_splited) - base_pos == 3:
                self.units_ = name_splited[-1]
        else: #enmu as int16
            self.format_ = "5.0"
            self.units_ = ""

    def get_block(self, indent1, indent2):
        quote_mark = "\""
        lines = ""
        lines += "\n"
        lines += indent1*" " + "/begin COMPU_METHOD\n"
        lines += indent2*" " + self.name_ + "\n"
        lines += indent2*" " + quote_mark + "Q = V" + quote_mark + "\n"
        lines += indent2*" " + "RAT_FUNC" + "\n"
        lines += indent2*" " + quote_mark + "%" + self.format_ + quote_mark + "\n"
        lines += indent2*" " + quote_mark + self.units_ + quote_mark + "\n"
        lines += indent2*" " + "COEFFS 0 1 0 0 0 1" + "\n"
        lines += indent1*" " + "/end COMPU_METHOD\n"
        return lines



def parse(line, info):
    fields = line.split('@')
    for i, field in enumerate(fields):
        if i == 0:
            continue
        field_name = field.split()[0]
        field_val = field.split(': ')[1].split(';')[0].strip()
        info[field_name] = field_val
    return info


def name_correction(name):
    if name[-1]==';':
        return name[:-1]
    return name


def type2rl(token, isMES=False):
    type_dict = {
        "float":"FLOAT32_IEEE",
        "real32_T":"FLOAT32_IEEE",
        "double":"FLOAT64_IEEE",
        "real_T":"FLOAT64_IEEE",
        "bool":"BOOLEAN", 
        "boolean_T":"BOOLEAN", 
        "uint8_t":"UBYTE",
        "uint8_T":"UBYTE",
        "uint16_t":"UWORD",
        "uint16_T":"UWORD",
        "uint32_t":"ULONG",
        "uint32_T":"ULONG",
        "int8_t":"SBYTE",
        "int8_T":"SBYTE",
        "int16_t":"SWORD",
        "int16_T":"SWORD",
        "int32_t":"SLONG",
        "int32_T":"SLONG",
    }
    if token in type_dict.keys():
        rl_suffix = type_dict[token]
        if isMES and type_dict[token] == "BOOLEAN":
            rl_suffix = "UBYTE"
    else:
        rl_suffix = "UWORD"
    return rl_suffix


def get_common_info(line, prefix, info):
    init_ecu_address = "0x0000"
    type_range = {
        "float": ["-3.4E+38", "3.4E+38"],
        "real32_T": ["-3.4E+38", "3.4E+38"],
        "double": ["-1.7E+308", "1.7E+308"],
        "real_T": ["-1.7E+308", "1.7E+308"],
        "bool": ["0", "1"],
        "boolean_T": ["0", "1"],
        "uint8_t": ["0", "255"],
        "uint8_T": ["0", "255"],
        "uint16_t": ["0", "65535"],
        "uint16_T": ["0", "65535"],
        "uint32_t": ["0", "4294967295"],
        "uint32_T": ["0", "4294967295"],
        "int8_t": ["-127", "127"],
        "int8_T": ["-127", "127"],
        "int16_t": ["-32768", "32767"],
        "int16_T": ["-32768", "32767"],
        "int32_t": ["-2147483648", "2147483647"],
        "int32_T": ["-2147483648", "2147483647"],
    }
    token2type = {
        "float": "single",
        "real32_T": "single",
        "double": "double",
        "real_T": "double",
        "bool": "boolean",
        "boolean_T": "boolean",
        "uint8_t": "uint8",
        "uint8_T": "uint8",
        "uint16_t": "uint16",
        "uint16_T": "uint16",
        "uint32_t": "uint32",
        "uint32_T": "uint32",
        "int8_t": "int8",
        "int8_T": "int8",
        "int16_t": "int16",
        "int16_T": "int16",
        "int32_t": "int32",
        "int32_T": "int32",
    }
    tokens = line.split()
    token1 = tokens[1]
    token2 = tokens[2]
    # on setup
    info["axis_descr_info"] = []
    info["axis_pts_info"] = []
    info["ctype"] = "None"
    # name
    if re.match(".*\[.*\]", token2) == None:
        info["name"] = token2
    else:
        info["name"] = token2.split('[')[0]
    info["name"] = name_correction(info["name"])
    # long identifier
    info["long_identifier"] = "\"\""
    # type
    info["type"] = "VALUE"
    # ECU addr
    info["ecu_address"] = init_ecu_address
    # max diff
    info["maxdiff"] = "0"
    # cm
    info["cm"] = prefix+"_CM_"+ "enmu"
    # lower and upper limit
    if token1 in type_range.keys():
        info["cm"] = prefix + "_CM_" + token2type[token1]
        info["lower_limit"] = type_range[token1][0]
        info["upper_limit"] = type_range[token1][1]
    else:
        info["lower_limit"] = type_range["uint16_t"][0]
        info["upper_limit"] = type_range["uint16_t"][1]
    # optional info
    info = parse(line, info)
    return info


def set_axis_info(axis_name, cur_idx, lines, prefix, ismap, isfirst=False): # search for axis name in all lines
    target_line = ""
    idx = -1
    for i, line in enumerate(lines):
        if re.match("^CAL_VAR.*", line) and re.match(".*"+axis_name+".*", line) and not re.match(".*//.*"+axis_name+".*", line):
            target_line = line
            idx = i
            break
    if idx == -1:
        return None, None, None
    axis_descr_info = {}
    axis_pts_info = {}
    # axis_pts_info
    axis_pts_info = get_common_info(target_line, prefix, info=axis_pts_info)
    # set num axis pts
    axis_pts_info["num_axis_pts"] = target_line.split('[')[1].split(']')[0]
    # set record layout
    if ismap:
        axis_pts_info["record_layout"] = "Lookup2D_X_"+type2rl(target_line.split()[1])
    else:
        axis_pts_info["record_layout"] = "Lookup1D_X_"+type2rl(target_line.split()[1])
    # axis_descr_info
    axis_descr_info["cm"] = axis_pts_info["cm"]
    axis_descr_info["num_axis_pts"] = axis_pts_info["num_axis_pts"]
    axis_descr_info["lower_limit"] = axis_pts_info["lower_limit"]
    axis_descr_info["upper_limit"] = axis_pts_info["upper_limit"]
    axis_descr_info["axis_pts_ref"] = axis_pts_info["name"]
    if ismap and isfirst:
        axis_descr_info["xy_axis"] = "Y"
    else:
        axis_descr_info["xy_axis"] = "X"
    # get axis_type from comment
    axis_descr_info["axis_type"] = "COM_AXIS"
    axis_descr_info = parse(target_line, axis_descr_info)
    return axis_descr_info, axis_pts_info


def generator(filename, out_filename):
    with open(filename, "r+") as input_file, open(out_filename, "a") as out_file:
        output_lines = []
        exist_axis = []
        CAL_start = 0
        cur_statr = 0
        CAL_end = 0
        cur_end = 0
        cur_idx = 0
        required_compu_methods = []
        input_lines = input_file.readlines()
        cur_len = len(input_lines) - 1
        prefix = filename.split('.')[0]
        if '/' in prefix:
            prefix = prefix.split('/')[-1]
        print(prefix)
        while cur_idx <= cur_len:
            cur_line = input_lines[cur_idx]
            has_no_axis = False
            # match pattern for definition line of CHAEACTERISTIC
            if not re.search("^CAL_VAR.*", cur_line) == None:
               CAL_start = 1
               cur_statr = cur_idx
            if CAL_start == 1 and not re.search(";", cur_line) == None:
                CAL_end =1
                CAL_start = 0
                cur_end = cur_idx
                if cur_statr != cur_end :
                    cur_line = input_lines[cur_statr]+ input_lines[cur_end] 
            if  CAL_end == 1 :   
                CAL_end = 0
                info = {}
                tokens = cur_line.split()
                token0 = tokens[0]
                token1 = tokens[1]
                token2 = tokens[2]
                # print(cur_idx)
                # print(token0+" "+token1+" "+token2)
                # common fields
                info = get_common_info(cur_line, prefix, info)
                if info["cm"] not in required_compu_methods:
                    required_compu_methods.append(info["cm"])
                # type(characteristic type, record layout)
                if info["ctype"] == "CURVE":
                    info["record_layout"] = "Lookup1D_"+type2rl(token1)
                elif info["ctype"] == "MAP":                    
                    info["record_layout"] = "Lookup2D_"+type2rl(token1)
                else:
                    has_no_axis = True
                    info["record_layout"] = "Scalar_"+type2rl(token1)     
                if has_no_axis:
                    new_characteristic_block = Characteristic()
                    new_characteristic_block.set_param(info)
                    output_lines.append(new_characteristic_block.get_block(4, 6, exist_axis, has_axis=False))
                    cur_idx = cur_idx + 1
                    continue
                # CHARACTERISTIC
                if info["ctype"] == "CURVE":
                    axis_descr_info, axis_pts_info = set_axis_info(info["ref_axis_x"], cur_idx, input_lines, prefix, False, True)
                    info["axis_descr_info"].append(axis_descr_info)
                    info["axis_pts_info"].append(axis_pts_info)
                if info["ctype"] == "MAP":
                    axis_descr_info, axis_pts_info= set_axis_info(info["ref_axis_y"], cur_idx, input_lines, prefix, True, True)
                    info["axis_descr_info"].append(axis_descr_info)
                    info["axis_pts_info"].append(axis_pts_info)
                    axis_descr_info, axis_pts_info = set_axis_info(info["ref_axis_x"], cur_idx, input_lines, prefix, True, False)
                    info["axis_descr_info"].append(axis_descr_info)
                    info["axis_pts_info"].append(axis_pts_info)
                new_characteristic_block = Characteristic()
                new_characteristic_block.set_param(info)
                output_lines.append(new_characteristic_block.get_block(4, 6, exist_axis))
            # match pattern for definition line of MEASUREMENT
            if not re.match("^MES_VAR.*", cur_line) == None:
                tokens = cur_line.split()
                token0 = tokens[0]
                token1 = tokens[1]
                token2 = tokens[2]
                # print(cur_idx)
                # print(token0+" "+token1+" "+token2)
                info = {}
                info["res"] = "0"
                info["accuracy"] = "0"
                info["data_type"] = type2rl(cur_line.split()[1], isMES=True)
                info = get_common_info(cur_line, prefix, info)
                if info["cm"] not in required_compu_methods:
                    required_compu_methods.append(info["cm"])
                info["name"] = name_correction(info["name"])
                new_measurement_block = Measurement()
                new_measurement_block.set_param(info)
                output_lines.append(new_measurement_block.get_block(4, 6))
            cur_idx = cur_idx + 1
        for name in required_compu_methods:
            new_compu_methods = CompuMethod(name)
            output_lines.append(new_compu_methods.get_block(4, 6))
        out_file.writelines(output_lines)  


generator(sys.argv[1], sys.argv[2])
                



        
