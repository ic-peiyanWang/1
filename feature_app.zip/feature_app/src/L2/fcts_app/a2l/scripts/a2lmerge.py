#!/usr/bin/env python3
import sys


def get_idx_inarr(arr, elem):
    idx = -1
    for i, tmp in enumerate(arr):
        if tmp == elem:
            idx = i
            break
    return idx


def get_insert_pos(file_lines, key_list):
    out_dict = {}
    back_insert_pos = 0
    for i in range(len(file_lines)):
        cur_line = file_lines[-(i+1)]
        if cur_line.strip() in key_list:
            out_dict[get_idx_inarr(key_list, cur_line.strip())] = len(file_lines) - i - 1
        if cur_line.strip() == "/end MODULE":
            back_insert_pos = len(file_lines) - i - 2
    # if some of the types are missing
    offset = 0.1
    for i in range(4):
        if i not in out_dict.keys():
            out_dict[i] = back_insert_pos + offset
            offset += 0.1
    return out_dict


def processor(lines, cur_line, line_type, cur_status):
    if cur_status > 0:
        lines[cur_status-1].append(cur_line)
        if line_type + cur_status == 0:
            lines[cur_status-1].append("\n")
            cur_status = 0
    if cur_status == 0:
        if line_type > 0:
            cur_status += line_type
            lines[cur_status-1].append(cur_line)
    return lines, cur_status


def get_seq(insert_pos):
    out_arr = []
    pos_list = list(insert_pos.values())
    pos_list.sort(reverse=True)
    for pos in pos_list:
        out_arr.append(get_idx_inarr(insert_pos.values(), pos))
    return out_arr


# merge files 1:-1 to file 0 and write to output file
def merge_a2l_files(filename_list, output_filename):
    # def key words
    tmp_str = "/begin "
    key_list1 = [tmp_str+"MEASUREMENT", tmp_str+"AXIS_PTS", tmp_str+"CHARACTERISTIC", tmp_str+"COMPU_METHOD"]
    tmp_str = "/end "
    key_list2 = [tmp_str+"MEASUREMENT", tmp_str+"AXIS_PTS", tmp_str+"CHARACTERISTIC", tmp_str+"COMPU_METHOD"]
    with open(filename_list[0], "r") as file0:
        base_lines = file0.readlines()
        with open(output_filename, "w+") as output_file:
            insert_pos = get_insert_pos(base_lines, key_list2)
            existed_names = []
            lines = [[], [], [], []]
            # scan file0 to get initial existed_names list
            for i, line in enumerate(base_lines):
                if line.strip() == key_list1[3]:
                    name_of_cm = base_lines.copy()[i+1].split()[-1]
                    if name_of_cm not in existed_names:
                        existed_names.append(name_of_cm)
            # get lines for insertion
            for i, tmp_filename in enumerate(filename_list):
                if i > 0:
                    with open(tmp_filename, "r") as cur_file:
                        cur_status = 0
                        cur_file_lines = cur_file.readlines()
                        for k, line in enumerate(cur_file_lines):
                            # get line type
                            line_type = 0
                            line_strip = line.strip()
                            if line_strip in key_list1:
                                line_type = get_idx_inarr(key_list1, line_strip) + 1
                            elif line_strip in key_list2:
                                line_type = - get_idx_inarr(key_list2, line_strip) - 1
                            # handle conflict
                            if line_type == 4:
                                name_of_cm = cur_file_lines[k+1].split()[-1]
                                if name_of_cm in existed_names:
                                    line_type == 0
                                else:
                                    existed_names.append(name_of_cm)
                            # process
                            lines, cur_status = processor(lines, line, line_type, cur_status)
            # insertion (from larger line number to smaller one)
            seq_list = get_seq(insert_pos)
            insert_pos_key = list(insert_pos.keys())
            base_lines += ["\n"] + ["\n"] + ["\n"]
            for idx in seq_list:
                cur_key = insert_pos_key[idx]
                base_lines = base_lines[:int(insert_pos[cur_key])+1] + ["\n"] + lines[cur_key] + ["\n"] + ["\n"] +base_lines[int(insert_pos[cur_key])+1:]
            output_file.writelines(base_lines)


filename_list = sys.argv[1:-1]
output_filename  = sys.argv[-1]
# run with
# ./a2lmerge.py xcp_tcp_carpc.A2L fake1.A2L fake2.A2L out.A2L
merge_a2l_files(filename_list, output_filename)

