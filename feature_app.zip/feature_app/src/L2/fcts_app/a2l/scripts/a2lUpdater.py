#!/usr/bin/env python3
import re
import os
import sys

# find variables in A2L file under "CHARACTERISTIC", "MEASUREMENT" and "AXIS_PTS" block and store the varibale name, line num of the name and line num of the address in two arraies

# helper func
def find_str_in_interval(target_str, str_line, end_line, input_lines):
    cur_line = str_line
    while cur_line < end_line:
        if not re.match(target_str, input_lines[cur_line]) == None:
            return cur_line
        else:
            cur_line += 1
    return -1

def find_str_in_multi_interval(target_str, str_line, end_line, input_lines, sub_str):
    for i in range(len(str_line)):
        cur_str_line = str_line[i]
        cur_end_line = end_line[i]+1
        target_pos = find_str_in_interval(target_str, cur_str_line, cur_end_line, input_lines)
        if target_pos != -1:
            return target_pos
        else:
            target_pos = find_str_in_interval(sub_str, cur_str_line, cur_end_line, input_lines)
            if target_pos != -1:
                return target_pos
    return -1

# helper func
def get_var_atpos(line, input_lines, pos):
    cur_line_str = input_lines[line]
    words = cur_line_str.split()
    return words[pos]

# get mes_arr and cal_arr
def get_var_array(a2l_filename):
    with open(a2l_filename, "r") as a2l_file:
        a2l_input_lines = a2l_file.readlines()
        mes_arr = []
        cal_arr = []
        for i, line in enumerate(a2l_input_lines):
            if not re.match("\s*(/begin CHARACTERISTIC)\s*", line) == None:
                str_line = i
                end_line = find_str_in_interval("\s*(/end CHARACTERISTIC)\s*", str_line, len(a2l_input_lines), a2l_input_lines)
                name_line = find_str_in_interval(".*(Name).*", str_line, end_line, a2l_input_lines)
                cur_var_name = get_var_atpos(name_line, a2l_input_lines, -1)
                addr_line = find_str_in_interval(".*(0x[0-9a-f]+).*", str_line, end_line, a2l_input_lines)
                cur_var_addr = get_var_atpos(addr_line, a2l_input_lines, 4)
                cal_arr.append({"name":cur_var_name, "addr":cur_var_addr, "line":addr_line})
            if not re.match("\s*(/begin AXIS_PTS)\s*", line) == None:
                str_line = i
                end_line = find_str_in_interval("\s*(/end AXIS_PTS)\s*", str_line, len(a2l_input_lines), a2l_input_lines)
                name_line = find_str_in_interval(".*(Name).*", str_line, end_line, a2l_input_lines)
                cur_var_name = get_var_atpos(name_line, a2l_input_lines, -1)
                addr_line = find_str_in_interval(".*(0x[0-9a-f]+).*", str_line, end_line, a2l_input_lines)
                cur_var_addr = get_var_atpos(addr_line, a2l_input_lines, 4)
                cal_arr.append({"name":cur_var_name, "addr":cur_var_addr, "line":addr_line})
            if not re.match("\s*(/begin MEASUREMENT)\s*", line) == None:
                str_line = i
                end_line = find_str_in_interval("\s*(/end MEASUREMENT)\s*", str_line, len(a2l_input_lines), a2l_input_lines)
                name_line = find_str_in_interval(".*(Name).*", str_line, end_line, a2l_input_lines)
                cur_var_name = get_var_atpos(name_line, a2l_input_lines, -1)
                addr_line = find_str_in_interval(".*(0x[0-9a-f]+).*", str_line, end_line, a2l_input_lines)
                cur_var_addr = get_var_atpos(addr_line, a2l_input_lines, 1)[0:-2]
                mes_arr.append({"name":cur_var_name, "addr":cur_var_addr, "line":addr_line})   
    return mes_arr, cal_arr


def get_sec_interval(pattern, input_lines):
    str_pos = []
    end_pos = []
    for i, line in enumerate(input_lines):
        if not re.match(pattern, line) == None:
            tmp_counter = i
            str_pos.append(i)
            while tmp_counter < len(input_lines):
                if not re.match("^\s*$", input_lines[tmp_counter]) == None:
                    end_pos.append(tmp_counter-1)       
                    break
                tmp_counter += 1
    return str_pos, end_pos


# get updated addr in map file
def get_updated_addr(map_filename, mes_arr, cal_arr):
    with open(map_filename, "r") as map_file:
        map_input_lines = map_file.readlines()
        info_arr = []
        # find interval of .calsec and .messec
        cal_str_pos, cal_end_pos = get_sec_interval("^\s.calsec", map_input_lines)
        mes_str_pos, mes_end_pos = get_sec_interval("^\s.messec", map_input_lines)
        # look for var name in target section
        for i, record in enumerate(mes_arr):
            pattern = "\s*" + "(0x[0-9a-f]+)" + "\s*" + record["name"] + ".*"
            sub_pattern = "\s*" + "(0x[0-9a-f]+)" + "\s*" + ".*" +"::" + record["name"] + ".*"
            tmp_line = find_str_in_multi_interval(pattern, mes_str_pos, mes_end_pos, map_input_lines, sub_pattern)
            if not tmp_line == -1:
                tmp_addr = get_var_atpos(tmp_line, map_input_lines, 0)
                mes_arr[i]["addr"] = tmp_addr
            else:
                info_arr.append({"name":record["name"], "type":".messec"})
        
        for i, record in enumerate(cal_arr):
            pattern = "\s*" + "(0x[0-9a-f]+)" + "\s*" + record["name"] + ".*"
            sub_pattern = "\s*" + "(0x[0-9a-f]+)" + "\s*" + ".*" +"::" + record["name"] + ".*"
            tmp_line = find_str_in_multi_interval(pattern, cal_str_pos, cal_end_pos, map_input_lines, sub_pattern)
            if not tmp_line == -1:
                tmp_addr = get_var_atpos(tmp_line, map_input_lines, 0)
                cal_arr[i]["addr"] = tmp_addr
            else:
                info_arr.append({"name":record["name"], "type":".calsec"})
    return mes_arr, cal_arr, info_arr


def merge(mes_arr, cal_arr):
    out = {}
    for record in cal_arr:
        out[int(record["line"])] = record["addr"]
    for record in mes_arr:
        out[int(record["line"])] = record["addr"]
    return out


def add_offset(addr, offset):
    return str(hex(int(addr, 16) + int(offset, 16)))


# write updated addr back to a2l file and write infomation about missing variables to info_filename 
def write_back(sec_addr_dict, merged_dict, info_arr, a2l_filename, new_a2l_filename, info_filename, offset):
    #update address with offset
    sec_addr_dict["mes"]["addr"] = add_offset(sec_addr_dict["mes"]["addr"], offset)
    sec_addr_dict["cal"]["addr"] = add_offset(sec_addr_dict["cal"]["addr"], offset)
    for key, val in merged_dict.items():
        merged_dict[key] = add_offset(val, offset)
    with open(a2l_filename, "r") as a2l_file, open(info_filename, "w+") as info_file, open(new_a2l_filename, "w+") as new_a2l_file:
        sec_info = {}
        # find sec addr line number
        a2l_file_lines = a2l_file.readlines()
        for i, line in enumerate(a2l_file_lines):
            if not re.match("\s*0x([0-9a-f]+)/\*@@MEASUREMENT_SEGBASEADDR@@\*/\s*", line) == None:
                tmp_str = re.sub("0x[0-9a-f]+", sec_addr_dict["mes"]["addr"], line)
                sec_info[i] = tmp_str
                tmp_str = re.sub("0x[0-9a-f]+", sec_addr_dict["mes"]["length"], a2l_file_lines[i+1])
                sec_info[i+1] = tmp_str
            if not re.match("\s*0x([0-9a-f]+)/\*@@CALIBRATION_SEGBASEADDR@@\*/\s*", line) == None:
                tmp_str = re.sub("0x[0-9a-f]+", sec_addr_dict["cal"]["addr"], line)
                sec_info[i] = tmp_str
                tmp_str = re.sub("0x[0-9a-f]+", sec_addr_dict["cal"]["length"], a2l_file_lines[i+1])
                sec_info[i+1] = tmp_str
        # write info file
        for record in info_arr:
            tmp_line = record["name"] + "       " + record["type"] + "\n"
            info_file.write(tmp_line)
        # write back addr
        for i, line in enumerate(a2l_file_lines):
            cur_line = line
            if i in merged_dict.keys():
                cur_line = re.sub("0x[0-9a-f]+", merged_dict[i], cur_line)
            if i in sec_info.keys():
                cur_line = sec_info[i]
            new_a2l_file.write(cur_line)


def get_sec_addr(map_filename):
    out_dict = {}
    cal_addr, cal_length, mes_addr, mes_length = "", "", "", ""
    with open(map_filename, "r") as map_file:
        map_file_lines = map_file.readlines()
        pattern = "\s+" + "0x[0-9a-f]+" + "\s+" + "0x[0-9a-f]+"
        for i, line in enumerate(map_file_lines):
            res = re.match(".calsec"+pattern, line)
            if not res == None:
                cal_addr = get_var_atpos(i, map_file_lines, 1)
                cal_length = get_var_atpos(i, map_file_lines, 2)
                out_dict["cal"] = {"addr":cal_addr, "length":cal_length}
            else:
                res = re.match(".messec"+pattern, line)
                if not res == None:
                    mes_addr = get_var_atpos(i, map_file_lines, 1)
                    mes_length = get_var_atpos(i, map_file_lines, 2)
                    out_dict["mes"] = {"addr":mes_addr, "length":mes_length}
    return out_dict


def a2lUpdater(a2l_filename, map_filename, info_filename, new_a2l_filename, offset):
    mes_arr, cal_arr = get_var_array(a2l_filename)
    mes_arr, cal_arr, info_arr = get_updated_addr(map_filename, mes_arr, cal_arr)
    out_dict = merge(mes_arr, cal_arr)
    out_dict2 = get_sec_addr(map_filename)
    write_back(out_dict2, out_dict, info_arr, a2l_filename, new_a2l_filename, info_filename, offset)


a2l_filename = sys.argv[1]
map_filename = sys.argv[2]
info_filename = sys.argv[3]
new_a2l_filename = sys.argv[4]
offset = sys.argv[5]
# Comment the next 4 lines in practical use
# a2l_filename = "fct_app.A2L"
# map_filename = "fct_app.map"
# new_a2l_filename = "new_fct_app.A2L"
# info_filename = "info.txt"


a2lUpdater(a2l_filename, map_filename, info_filename, new_a2l_filename, offset)
