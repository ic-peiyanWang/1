1. 文件结构和使用方法
用于生成的文件(.cpp)放入src，自动生成的A2L文件放入merge。map文件放在当前目录下。运行gen.sh来生成updated.a2l。生成的结果在output文件夹下。
使用clean.sh来清理src, output以及当前目录下的map文件和中间文件。

2. 对map文件格式的要求
.calsec  num1     num2
 .calsec(前面一个空格，一个.calsec的section结束后留空行)
    var1
    var2
    ...

 .calsec
    var
 ...

.messec  num1  num2
 .messec(前面一个空格)
 ...

3. 对cpp文件的格式要求和格式转换规则
见store/pattern



4. 定义的类型（见a2lgenerator.cpp）

用于定义标定量的record layout以及观测量的data type
type_dict = { 
   "float":"FLOAT32_IEEE",
   "real32_T":"FLOAT32_IEEE",
   "double":"FLOAT64_IEEE",
   "real_T":"FLOAT64_IEEE",
   "bool":"BOOLEAN", 
   "boolean_T":"BOOLEAN", 
   "uint8_t":"UBYTE",
   "uint8_T":"UBYTE",
   "uint16_t":"UWORD",
   "uint16_T":"UWORD",
   "uint32_t":"ULONG",
   "uint32_T":"ULONG",
   "int8_t":"SBYTE",
   "int16_t":"SWORD",
   "int16_T":"SWORD",
   "int32_t":"SLONG",
   "int32_T":"SLONG",
}

用于定义lower limit和upper limit
type_range = {
   "float": ["-3.4E+38", "3.4E+38"],
   "real32_T": ["-3.4E+38", "3.4E+38"],
   "double": ["-1.7E+308", "1.7E+308"],
   "real_T": ["-1.7E+308", "1.7E+308"],
   "bool": ["0", "1"],
   "boolean_T": ["0", "1"],
   "uint8_t": ["0", "255"],
   "uint8_T": ["0", "255"],
   "uint16_t": ["0", "65535"],
   "uint16_T": ["0", "65535"],
   "uint32_t": ["0", "4294967295"],
   "uint32_T": ["0", "4294967295"],
   "int8_t": ["-127", "127"],
   "int8_T": ["-127", "127"],
   "int16_t": ["-32768", "32767"],
   "int16_T": ["-32768", "32767"],
   "int32_t": ["-2147483648", "2147483647"],
   "int32_T": ["-2147483648", "2147483647"],
}

用于把在cpp文件中监测到的类型转化为conversion method中的数据类型
token2type = {
   "float": "single",
   "real32_T": "single",
   "double": "double",
   "real_T": "double",
   "bool": "boolean",
   "boolean_T": "boolean",
   "uint8_t": "uint8",
   "uint8_T": "uint8",
   "uint16_t": "uint16",
   "uint16_T": "uint16",
   "uint32_t": "uint32",
   "uint32_T": "uint32",
   "int8_t": "int8",
   "int8_T": "int8",
   "int16_t": "int16",
   "int16_T": "int16",
   "int32_t": "int32",
   "int32_T": "int32",
}

用于定义COMPU_METHOD的format
type2format = {
   "single":"8.6",
   "double":"15.10",
   "boolean":"1.0",
   "uint8":"3.0",
   "uint16":"5.0",
   "uint32":"10.0",
   "int8":"3.0",
   "int16":"5.0",
   "int32":"10.0",
}

未知数据类型（目前主要是枚举）定义为uint16
在更新新的变量时，修改上述对应的字典。











###Pattern
# characteristic
<Macro> <type> <var_name>[num] = { //@<field1_name> : <field1_val> ; @<field2_name> : <field2_val> ; ... ;
val0, val1, val2 ...    };

0.判断一行是否是definition for a variable
以 CAR_VAR 或 MES_VAR开始

1.判断line的类型：
以CAL_VAR开头是CHARACTERISTIC, MES_VAR开头是MEASUREMENT. 判断是否是CURVE和MAP从注释的ctype判断(ctype includes 'MAP', 'CURVE')
补充：MAP 和 CURVE 的 轴 查找：按照定义中设置的 @ref_axis_x 和 @ref_axis_y 来更改。例：//@ref_axis_x : sample_name1_C ; @ref_axis_y : sample_name2_C ;

2.maxdiff:
default : 0

3.conversion method:
都带IEEE
<filename_prefix>_CM_<var_type>_IEEE

4.record layout
MAP -> Lookup2D
CURVE -> Lookup1D
独立的 -> Scalar
AXIS_PTS -> Lookup1D_X or Lookup2D_x

5. upper and lower limit
似乎不完全由类型决定 
TODO: 增加实际数值

6. num_axis_pts
假设pattern 存在*[*]*

7. var_name
measurement:
删除最后的分号，取"[:-1]" (以后可能有问题)
characteristic: 如果检测到[], 删除

8. measurement的resulution and accuracy:
0


9.可以在注释中设置的field:
在a2lgenerator的4个类下，查看info["field_name"]，一般在set_param下。只要存在的field_name都可以设置，且优先级最高（大部分）。

