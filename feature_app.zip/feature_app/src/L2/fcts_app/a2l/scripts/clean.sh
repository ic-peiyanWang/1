#!/bin/sh

cd ..

rm src/*.cpp
rm -rf out
# rm output/*
rm fcts_app.map
