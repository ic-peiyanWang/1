#pragma once

#include "fcts_diag.h"
namespace nio
{
    namespace ad
    {



        extern APP_state_e AebState;
        
        extern bool aeb_suppress;
        extern bool aebrear_suppress;

        extern void update_aeb_conditions(void);
    }
}
