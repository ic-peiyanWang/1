#pragma once
//#include "ids_lib.h"   
#include "aeb_type.h"
//#include "aeb_in_house.h"
#include "aeb_ctrlparam.h"
#include "fcts_input_adapter.h"
#include "aeb_strategy_type.h"

namespace nio {
    namespace ad {

        extern AEBFLG AEBFlg;
        extern AEBTRGETFLG AEBActuFlg;
        extern AEBSM AEBSm;
        extern AebRearSm aebrearsm;
        extern AEBREQ AEBReq;
        extern bool   aebreq_lf;

        extern void update_aebrear_flag(AEBFLG& aebflg);
        extern void update_aeb_flag(AEBFLG& aebflg);

        extern void udpate_aeb_target_flag(AEBFLG& aebflg,AEBTRGETFLG& aebactuflg);

        extern void update_aeb_deceleration_request(AEBSM& aebsm,AEBREQ& aebreq,AEBTRGETFLG aebflgreq,bool drvrovrd, bool holdovrd);
        extern bool aeb_driver_override(AEBREQ& aebreq,
                                double accpdlpstn,
                                double accpdlpstnrate,
                                double strwhlspd,
                                double dyawrate);
        extern void update_aeb_deceleration_request(AEBREQ& aebreq);
        extern void update_eba_req(AEBREQ& aebreq,double brkpres,
                            double brkpresgrad,unsigned char gear, AEBTRGETFLG aebflgreq);

        extern void update_aba_req(AEBREQ& aebreq);

        extern bool hold_override(float accelped, float brkped, bool brkpressed);

        void update_aeb_ctrlparam(ARBSIN *arbsin);
    }
}
