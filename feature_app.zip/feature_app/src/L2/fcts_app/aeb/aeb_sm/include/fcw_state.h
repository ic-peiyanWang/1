#pragma once 
#include "aeb_type.h"
#include "fcw_type.h"
#include "ehy_math/nio_vmath.h"

namespace nio {
    namespace ad {

        extern FCWSM FCWSm;
        extern FcwRearSm fcwrearsm;
        extern FCWREQ FCWReq;
        extern bool fcw_driver_override(FCWREQ& fcwreq,
                                double accpdlpstn,
                                double accpdlpstnrate,
                                double strwhlspd,
                                double dyawrate);
        extern void update_fcw_req(FCWREQ& fcwreq,FCWSM& fcwsm,AEBTRGETFLG aebactuflg);
        extern void update_awb_req(FCWSM& fcwsm, FCWREQ& fcwreq, double vehspd, bool awbflg);

    }
}