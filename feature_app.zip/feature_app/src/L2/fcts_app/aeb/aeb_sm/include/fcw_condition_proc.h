
#pragma once

#include "fcts_diag.h"
namespace nio {
    namespace ad {



        extern void update_fcw_conditions(void);
                
        extern bool         fcw_active_lf;
        extern int16_t      fcw_active_age;
        extern bool         fcw_suppress;
        extern int16_t      fcw_suppress_age;

        extern bool         fcwrear_active_lf;
        extern uint16_t     fcwrear_active_age;
        extern bool         fcwrear_suppress;
        extern uint16_t     fcwrear_suppress_age;

        extern APP_state_e  FcwState;

    }
}