
#include <iostream>
#include "fcw_condition_proc.h"
#include "aeb_calibration.h"
#include "aeb_ctrlparam.h"
#include "aeb_state.h"
#include "fcts_diag.h"
#include "fcw_state.h"
#include "fcw_type.h"
//#include "aeb_in_house.h"
#define Fcw_InitMask (0x00000018)
#define Fcw_LossMask (0x0000005D)

namespace nio {
namespace ad {

APP_state_e FcwState;

extern AEBTRGETFLG AEBActuFlg;

uint32_t fcw_psvcdn0_mask = 0x00000000;

uint32_t fcw_psvcdn1_mask = 0xFFFFFFFF;

uint32_t fcw_psvcdn2_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail0_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail1_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail2_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail3_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail4_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail5_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail6_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail7_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail8_mask = 0xFFFFFFFF;

uint32_t fcw_tmpfail9_mask = 0x00000000;

bool    fcw_active_lf    = false;
int16_t fcw_active_age   = 0;
bool    fcw_suppress     = false;
int16_t fcw_suppress_age = 0;

bool     fcwrear_active_lf    = false;
uint16_t fcwrear_active_age   = 0;
bool     fcwrear_suppress     = false;
uint16_t fcwrear_suppress_age = 0;

uint16_t MaxFcwActAge          = 100;
uint16_t MaxFcwSuppressAge     = (kAebHilMode == false) ? 1500 : 250;
uint16_t MaxFcwRearActAge      = 100;
uint16_t MaxFcwRearSuppressAge = (kAebHilMode == false) ? 1500 : 250;

void FcwRearSm::UpdateOffCondition() {
  set_off_cdn((stFCWSet == 3) || (stTrailerMode == 1));
}

void FcwRearSm::UpdateActiveCondition() {

  bool fcwrear_active = false;

  if (AEBFlg.pedrear.prewarn == true && fcwrear_suppress == false && stActGear == 2) {
    fcwrear_active = true;
  }

  if (fcwrear_active == true && fcwrear_active_age <= MaxFcwRearActAge) {
    fcwrear_active_age++;
  } else if (fcwrear_active == false && fcwrear_active_lf == true && fcwrear_active_age <= MaxFcwRearActAge) {
    fcwrear_active = true;
    fcwrear_active_age++;
  } else {
    fcwrear_active     = false;
    fcwrear_active_age = 0;
  }

  if (fcwrear_active_lf == true && fcwrear_active == false && stActGear == 2) {
    fcwrear_suppress = true;
  }

  if (fcwrear_suppress == true && fcwrear_suppress_age <= MaxFcwRearSuppressAge) {
    fcwrear_suppress_age++;
  } else {
    fcwrear_suppress     = false;
    fcwrear_suppress_age = 0;
  }

  fcwrear_active_lf = fcwrear_active;

  set_act_cdn(fcwrear_active);
};

void fcw_off_condition(AEBSM& fcwsm) {
  fcwsm.set_aebonff_cdn(stFCWSet != 3);
  //     std::cout<<"stFCWSet is "<< (int)stFCWSet << std::endl;
}

void fcw_passive_condition(AEBSM& fcwsm) {

  uint32_t psvcdn0 = 0, psvcdn1 = 0, psvcdn2 = 0;

  psvcdn0 = (flgSeatBltFrntLeSts == 0)
            //     + ((stEPBSwt == 3) << 1)
            + ((flgBrkOvht == 1) << 2) + ((stEPBSts != 3) << 3) + ((stHDCSts == 3) << 4) + ((stAVHSts == 3) << 5)
            + ((stStandstillSts == 3) << 6) + ((flgTCSDeactv == 1) << 7);

  psvcdn1 = (flgVDCDeactv == 1) + ((stDoorAjarFLSts == 0) << 1) + ((stVehSt != 2) << 2) + ((!(stLvlAdjSts == 0)) << 3)
            + ((!(stActGear == 1 || stActGear == 0 || stActGear == 2)) << 4)
            + ((!(stVehRdy >= 3 && stVehRdy <= 5)) << 5);

  //     psvcdn2 = (!(flgAWBAvl == 1))
  //             + ((!(flgABAAvl == 1)) << 1)
  //             + ((!(flgAutoBrkgAvl == 1)) << 2)
  //             + ((!(flgEBPAvl == 1)) << 3)
  //             + ((!(flgEBAAvl == 1)) << 4);

  FCWSm.set_psv_cdn(((psvcdn0 & fcw_psvcdn0_mask) || (psvcdn1 & fcw_psvcdn1_mask) || (psvcdn2 & fcw_psvcdn2_mask))
                    && fcwsm.get_aebOnff_cdn());
  // stVehAEBSwt
}

void fcw_temp_fail_condition(AEBSM& fcwsm) {

  uint32_t tmpfail0 = 0, tmpfail1 = 0, tmpfail2 = 0, tmpfail3 = 0, tmpfail4 = 0, tmpfail5 = 0, tmpfail6 = 0,
           tmpfail7 = 0, tmpfail8 = 0, tmpfail9 = 0;

  tmpfail0 = ((flgVehStInld)) + ((flgHMIFail) << 1) + ((flgADCInternalFault) << 2) + ((flgLatAccValInvld) << 3)
             + ((flgYawrateInvld) << 4) + ((flgLonAccValInvld) << 5) + ((flgSeatOccpFrntLeInvld) << 6)
             + ((flgSeatOccpFrntLeFailure) << 7);

  tmpfail1 = (flgBrkPrsOfsInvld) + (flgVehSpdInvld << 1) + (flgBrkPrssInvld << 2) + (flgBrkPdlInvld << 3);
  +(flgWhlSpdInvld << 4);
  +(flgWhlPulCntInvld << 5);

  tmpfail2 = ((flgStrngWhlAgSnsrFail)) + ((flgStrngWhlAgSpdInvld) << 1) + ((flgStrngWhlAgSnsrNotCal) << 2)
             + ((flgAccPdlActPosnInvld) << 3) + ((flgGearInvld) << 4);

  tmpfail3 = (flgSCMLossCommFault) + (flgBCMLossCommFault << 1) + (flgVCULossCommFault << 2)
             + (flgBCULossCommFault << 3) + (flgACMLossCommFault << 4) + (flgCGWLossCommFault << 5)
             + (flgCDCLossCommADAS_Fault << 6) + (flgSCMFail << 7);
  //
  // flgEQ4NonRecoverableFault
  // flgEQ4RecoverableFault
  // flgEQ4Coredump
  // flgEQ4LossCommFault

  tmpfail4 = (flgFS_partialBlockage_2) + (flgFS_partialBlockage_3 << 1) + (flgFS_fullBlockage_1 << 2)
             + (flgFS_fullBlockage_2 << 3) + (flgFS_fullBlockage_3 << 4) + (flgRADFCLossCommFault << 5)
             + (flgRADFC_Blindness << 6) + (flgRADFC_Failure << 7);

  tmpfail5 = ((flgFS_autofixOutOfCalibHorizon)) + ((flgFS_autofixOutOfCalibYAW) << 1)
             + ((flgFS_TSR_outOfCalib_mode) << 2) + ((flgFS_out_of_focus_2) << 3) + ((flgFS_out_of_focus_3) << 4)
             + ((flgFS_frozenWindshield) << 5);

  tmpfail6 = ((flgFS_blurredImage_1)) + ((flgFS_blurredImage_2) << 1) + ((flgFS_blurredImage_3) << 2)
             + ((flgFS_lowSun_3) << 3) + ((flgFS_splashes_2) << 4);

  tmpfail7 = ((flgFS_sunRay_1)) + ((flgFS_sunRay_2) << 1) + ((flgFS_rain_2) << 2) + ((flgFS_rain_3) << 3)
             + ((flgFS_fog_2) << 4) + ((flgFS_fog_3) << 5);

  tmpfail8 = (!(flgAWBAvl == 1)) + ((!(flgABAAvl == 1)) << 1) + ((!(flgAutoBrkgAvl == 1)) << 2)
             + ((!(flgEBPAvl == 1)) << 3) + ((!(flgEBAAvl == 1)) << 4);

  fcwsm.set_tmpfail_cdn(((tmpfail0 & fcw_tmpfail0_mask) || (tmpfail1 & fcw_tmpfail0_mask)
                         || (tmpfail2 & fcw_tmpfail0_mask) || (tmpfail3 & fcw_tmpfail0_mask)
                         || (tmpfail4 & fcw_tmpfail0_mask) || (tmpfail5 & fcw_tmpfail0_mask)
                         || (tmpfail6 & fcw_tmpfail0_mask) || (tmpfail7 & fcw_tmpfail0_mask)
                         || (FcwState != APP_state_e::FullActive) || (gFCWFaultSt != FimFault_e::NoFault))
                        && fcwsm.get_aebOnff_cdn());
}

void fcw_perm_fail_condition(AEBSM& fcwsm) {
  fcwsm.set_permfail_cdn(false);
}

void fcw_forward_activation_condition(AEBSM& fcwsm, AEBTRGETFLG& actflg) {

  bool fcw_active = false;

  if (actflg.prewarn == true && fcw_suppress == false && stActGear == 1) {
    fcw_active = true;
  }

  if (fcw_active == true && fcw_active_age <= MaxFcwActAge) {
    fcw_active_age++;
  } else if (fcw_active == false && fcw_active_lf == true && fcw_active_age <= MaxFcwActAge) {
    fcw_active = true;
    fcw_active_age++;
  } else {
    fcw_active     = false;
    fcw_active_age = 0;
  }

  if (fcw_active_lf == true && fcw_active == false && stActGear == 1) {
    fcw_suppress = true;
  }

  if (fcw_suppress == true && fcw_suppress_age <= MaxFcwSuppressAge) {
    fcw_suppress_age++;
  } else {
    fcw_suppress     = false;
    fcw_suppress_age = 0;
  }

  fcw_active_lf = fcw_active;

  fcwsm.set_frwrdactv_cdn(fcw_active && fcwsm.get_aebOnff_cdn() && !fcwsm.get_permfail_cdn() && !fcwsm.get_psv_cdn()
                          && !fcwsm.get_tmpfail_cdn());
}

void fcw_backward_activation_condition(AEBSM& fcwsm, FcwRearSm& sm) {
  if (kAebRearEnable == true) {
    fcwsm.set_bckwrdactv_cdn(sm.get_state() == RearSmSt::kActive);
  } else {
    fcwsm.set_bckwrdactv_cdn(false);
  }
}

void fcw_standby_condition(AEBSM& fcwsm) {
  fcwsm.set_stdby_cdn(fcwsm.get_aebOnff_cdn() && !fcwsm.get_psv_cdn() && !fcwsm.get_permfail_cdn()
                      && !fcwsm.get_tmpfail_cdn());
}
void update_fcw_conditions(void) {
  FcwState = APP_StateManage(Arb_TopicNoInit, Fcw_InitMask, Arb_TopicLoss, Fcw_LossMask);
  fcw_off_condition(FCWSm);
  fcw_passive_condition(FCWSm);
  fcw_standby_condition(FCWSm);
  fcw_temp_fail_condition(FCWSm);
  fcw_perm_fail_condition(FCWSm);
  fcw_forward_activation_condition(FCWSm, AEBActuFlg);
  fcw_backward_activation_condition(FCWSm, fcwrearsm);
}
}  // namespace ad
}  // namespace nio
