#include <iostream>
#include <math.h>
#include "ids_lib.h"
//#include "aeb_type.h"
//#include "aeb_ctrlparam.h"
#include "fcts_in_proc.h"
//#include "aeb_in_house.h"
#include "aeb_calibration.h"
#include "aeb_state.h"
#include "aeb_strategy_type.h"
#include "fcts_loc_cfg.h"

namespace nio {
namespace ad {

AEBFLG       AEBFlg;
AEBTRGETFLG  AEBActuFlg;
AEBSM        AEBSm;
AebRearSm    aebrearsm;
AEBREQ       AEBReq;
bool         aebreq_lf = false;
TimerEnabled AebOvrdPdlPstnTimer;
TimerEnabled AebOvrdPdlRateTimer;
LowPassT     StrWhlSpdFilt;

void RearSm::UpdateState() {
  switch (sm_state_) {
  case RearSmSt::kOff:
    if (get_off_cdn()) {
      sm_state_ = RearSmSt::kOff;
    } else if (get_fail_cdn()) {
      sm_state_ = RearSmSt::kFail;
    } else {
      sm_state_ = RearSmSt::kStandby;
    }
    break;
  case RearSmSt::kStandby:
    if (get_off_cdn()) {
      sm_state_ = RearSmSt::kOff;
    } else if (get_fail_cdn()) {
      sm_state_ = RearSmSt::kFail;
    } else if (get_psv_cdn()) {
      sm_state_ = RearSmSt::kPassive;
    } else {
      sm_state_ = RearSmSt::kStandby;
    }
    break;
  case RearSmSt::kPassive:
    if (get_off_cdn()) {
      sm_state_ = RearSmSt::kOff;
    } else if (get_fail_cdn()) {
      sm_state_ = RearSmSt::kFail;
    } else if (!get_psv_cdn()) {
      sm_state_ = RearSmSt::kStandby;
    } else if (get_act_cdn()) {
      sm_state_ = RearSmSt::kActive;
    } else {
      sm_state_ = RearSmSt::kPassive;
    }
    break;
  case RearSmSt::kFail:
    if (get_off_cdn()) {
      sm_state_ = RearSmSt::kOff;
    } else if (get_fail_cdn()) {
      sm_state_ = RearSmSt::kFail;
    } else if (get_psv_cdn()) {
      sm_state_ = RearSmSt::kPassive;
    } else {
      sm_state_ = RearSmSt::kStandby;
    }
    break;
  case RearSmSt::kActive:
    if (get_off_cdn()) {
      sm_state_ = RearSmSt::kOff;
    } else if (get_fail_cdn()) {
      sm_state_ = RearSmSt::kFail;
    } else if (!get_psv_cdn()) {
      sm_state_ = RearSmSt::kStandby;
    } else if (get_act_cdn()) {
      sm_state_ = RearSmSt::kActive;
    } else {
      sm_state_ = RearSmSt::kPassive;
    }
    break;
  default:
    sm_state_ = RearSmSt::kOff;
    break;
  }
}

// fcw_state()
void AEBSM::update_AEB_State(void) {
  if (m_AebSt == aebst_e::off) {
    m_AebSt    = aebst_e::off;
    m_AebSysSt = aebsysst_e::off;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    } else {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    }
  } else if (m_AebSt == aebst_e::passive) {
    m_AebSt    = aebst_e::passive;
    m_AebSysSt = aebsysst_e::standby;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    } else {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    }
  } else if (m_AebSt == aebst_e::standby) {
    m_AebSt    = aebst_e::standby;
    m_AebSysSt = aebsysst_e::standby;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_frwrdactv_cdn()) {
      m_AebSt    = aebst_e::factive;
      m_AebSysSt = aebsysst_e::active;
    } else if (get_bckwrdactv_cdn()) {
      m_AebSt    = aebst_e::ractive;
      m_AebSysSt = aebsysst_e::active;
    } else {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    }
  } else if (m_AebSt == aebst_e::factive) {
    m_AebSt    = aebst_e::factive;
    m_AebSysSt = aebsysst_e::active;
    
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_frwrdactv_cdn()) {
      m_AebSt    = aebst_e::factive;
      m_AebSysSt = aebsysst_e::active;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    } else {
      m_AebSt    = aebst_e::factive;
      m_AebSysSt = aebsysst_e::active;
    }
  } else if (m_AebSt == aebst_e::ractive) {
    m_AebSt    = aebst_e::ractive;
    m_AebSysSt = aebsysst_e::active;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_bckwrdactv_cdn()) {
      m_AebSt    = aebst_e::ractive;
      m_AebSysSt = aebsysst_e::active;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    } else {
      m_AebSt    = aebst_e::ractive;
      m_AebSysSt = aebsysst_e::active;
    }
  } else if (m_AebSt == aebst_e::tmperr) {
    m_AebSt    = aebst_e::tmperr;
    m_AebSysSt = aebsysst_e::inhibit;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_AebSt    = aebst_e::tmperr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    } else if (get_bckwrdactv_cdn()) {
      m_AebSt    = aebst_e::ractive;
      m_AebSysSt = aebsysst_e::active;
    } else if (get_psv_cdn()) {
      m_AebSt    = aebst_e::passive;
      m_AebSysSt = aebsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    } else {
      m_AebSt    = aebst_e::standby;
      m_AebSysSt = aebsysst_e::standby;
    }
  } else if (m_AebSt == aebst_e::prmnterr) {
    m_AebSt    = aebst_e::prmnterr;
    m_AebSysSt = aebsysst_e::inhibit;
    if (!get_aebOnff_cdn()) {
      m_AebSt    = aebst_e::off;
      m_AebSysSt = aebsysst_e::off;
    } else {
      m_AebSt    = aebst_e::prmnterr;
      m_AebSysSt = aebsysst_e::inhibit;
    }
  } else {
  }
  // std::cout<<"in state condition
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"m_AebSt is"<<(int)m_AebSt<<std::endl;
  // std::cout<<"m_AebSysSt is"<<(int)m_AebSysSt<<std::endl;
}

void update_aebrear_flag(AEBFLG& aebflg) {

  const uint32_t kActive    = 0xAA55;
  aebflg.pedrear.latentwarn = false;
  aebflg.pedrear.warnbrk    = false;

  if (FusionVRURearFlag_.highbrake_flag == kActive) {
    if (vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0) {
      aebflg.pedrear.hardbrk = true;
    }
  } else {
    aebflg.pedrear.hardbrk = false;
  }

  if (FusionVRURearFlag_.lowbrake_flag == kActive) {
    if (vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0) {
      aebflg.pedrear.softbrk = true;
    }
  } else {
    aebflg.pedrear.softbrk = false;
  }

  if (FusionVRURearFlag_.prefill_flag == kActive) {
    if (vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill > 0) {
      aebflg.pedrear.prefill = true;
    }
  } else {
    aebflg.pedrear.prefill = false;
  }

  if (FusionVRURearFlag_.Warning_flag == kActive) {
    if (vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0
        || vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0
        || vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill > 0
        || vru_candidate.pedestrian_rearcross_Candidate_.u8_warning > 0) {
      aebflg.pedrear.prewarn = true;
    } else {
      aebflg.pedrear.prewarn = true;
    }
  } else {
    aebflg.pedrear.prewarn = false;
  }

  if (FusionVRURearFlag_.hold_flag == kActive) {
    aebflg.pedrear.hold_req = true;
  } else {
    aebflg.pedrear.hold_req = false;
  }
}

void update_aeb_flag(AEBFLG& aebflg) {
  // uint32_t kinactive = 0x9966;
  uint32_t kactive      = 0xAA55;
  aebflg.car.warnbrk_lf = aebflg.car.warnbrk;
  aebflg.car.hardbrk    = false;
  aebflg.car.softbrk    = false;
  aebflg.car.warnbrk    = false;
  aebflg.car.prefill    = false;
  aebflg.car.prewarn    = false;
  aebflg.car.latentwarn = false;
  aebflg.car.iba_req    = false;
  aebflg.car.hold_req   = false;

  if (FusionCCRFlag_.highbrake_flag == kactive) {
    aebflg.car.hardbrk = true;
  }
  if (FusionCCRFlag_.lowbrake_flag == kactive) {
    aebflg.car.softbrk = true;
  }
  if (FusionCCRFlag_.prefill_flag == kactive) {
    aebflg.car.prefill = true;
  }
  if (FusionCCRFlag_.Warning_flag == kactive) {
    aebflg.car.prewarn = true;
  }
  if (FusionCCRFlag_.warnbrake_flag == kactive) {
    aebflg.car.warnbrk = true;
  }
  if (FusionCCRFlag_.readyforIBA == 1) {
    aebflg.car.iba_req = true;
  }
  if (FusionCCRFlag_.hold_flag == kactive) {
    aebflg.car.hold_req = true;
  }

  if (FusionVRUFlag_.highbrake_flag == kactive) {
    if (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0
        || vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.ped.hardbrk = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.cyclist.hardbrk = true;
    }
  } else {
    aebflg.ped.hardbrk     = false;
    aebflg.cyclist.hardbrk = false;
  }

  if (FusionVRUFlag_.lowbrake_flag == kactive) {
    if (vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0
        || vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0 || vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0
        || vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.ped.softbrk = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0 || vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.cyclist.softbrk = true;
    }
  } else {
    aebflg.ped.softbrk     = false;
    aebflg.cyclist.softbrk = false;
  }

  if (FusionVRUFlag_.prefill_flag == kactive) {
    if (vru_candidate.pedestrian_cross_Candidate_.u8_prefill > 0
        || vru_candidate.pedestrian_oncom_Candidate_.u8_prefill > 0) {
      aebflg.ped.prefill = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_prefill > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_prefill > 0) {
      aebflg.cyclist.prefill = true;
    }
  } else {
    aebflg.ped.prefill     = false;
    aebflg.cyclist.prefill = false;
  }

  if (FusionVRUFlag_.Warning_flag == kactive) {
    if (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0
        || vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.ped.prewarn = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0) {
      aebflg.cyclist.prewarn = true;
    } else if (vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0
               || vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0) {
      aebflg.ped.prewarn = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0) {
      aebflg.cyclist.prewarn = true;
    } else if (vru_candidate.pedestrian_cross_Candidate_.u8_prefill > 0
               || vru_candidate.pedestrian_oncom_Candidate_.u8_prefill > 0) {
      aebflg.ped.prewarn = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_prefill > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_prefill > 0) {
      aebflg.cyclist.prewarn = true;
    } else if (vru_candidate.pedestrian_cross_Candidate_.u8_warning > 0
               || vru_candidate.pedestrian_oncom_Candidate_.u8_warning > 0) {
      aebflg.ped.prewarn = true;
    } else if (vru_candidate.bicycle_cross_Candidate_.u8_warning > 0
               || vru_candidate.bicycle_oncom_Candidate_.u8_warning > 0) {
      aebflg.cyclist.prewarn = true;
    } else {
      aebflg.ped.prewarn = true;
    }
  } else {
    aebflg.ped.prewarn     = false;
    aebflg.cyclist.prewarn = false;
  }

  if (FusionVRUFlag_.hold_flag == kactive) {
    aebflg.ped.hold_req = true;
  } else {
    aebflg.ped.hold_req = false;
  }

  aebflg.ped.latentwarn     = false;
  aebflg.cyclist.latentwarn = false;
  aebflg.ped.warnbrk        = false;
  aebflg.cyclist.warnbrk    = false;
#ifdef AEB_DEBUG
  // std::cout<<"in flag update
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"aebflg.car.hardbrk is"<<(int)aebflg.car.hardbrk<<std::endl;
  // std::cout<<"aebflg.car.softbrk is"<<(int)aebflg.car.softbrk<<std::endl;
#endif
}

void udpate_aeb_target_flag(AEBFLG& aebflg, AEBTRGETFLG& aebactuflg) {

  aebactuflg.prewarn    = false;
  aebactuflg.latentwarn = false;
  aebactuflg.softbrk    = false;
  aebactuflg.prefill    = false;
  aebactuflg.warnbrk    = false;
  aebactuflg.hardbrk    = false;
  aebactuflg.warntype   = 0;
  aebactuflg.iba_req    = false;
  aebactuflg.hold_req   = false;

  if (aebflg.car.prewarn || ((aebflg.cyclist.prewarn || aebflg.ped.prewarn || aebflg.pedrear.prewarn) && k_AEBShadowMode_active == 0)) {
    aebactuflg.prewarn = true;
    if (aebflg.car.prewarn) {
      aebactuflg.warntype = 1;
    } else if (aebflg.cyclist.prewarn) {
      aebactuflg.warntype = 3;
    } else if (aebflg.ped.prewarn || aebflg.pedrear.prewarn) {
      aebactuflg.warntype = 2;
    } else {
      aebactuflg.warntype = 1;
    }
  }

  if (aebflg.car.latentwarn || aebflg.cyclist.latentwarn || aebflg.ped.latentwarn || aebflg.pedrear.latentwarn) {
    aebactuflg.latentwarn = false;
  }

  if (aebflg.car.hardbrk || ((aebflg.cyclist.hardbrk || aebflg.ped.hardbrk || aebflg.pedrear.hardbrk) && kAebShadowModeSoft == 0 && k_AEBShadowMode_active == 0)) {
    aebactuflg.hardbrk = true;
  }

  if (aebflg.car.softbrk || ((aebflg.cyclist.softbrk || aebflg.ped.softbrk || aebflg.pedrear.softbrk) && kAebShadowModeSoft == 0 && k_AEBShadowMode_active == 0)) {
    aebactuflg.softbrk = true;
  }

  if ((aebflg.car.warnbrk == true && aebflg.car.warnbrk_lf == false) || aebflg.cyclist.warnbrk || aebflg.ped.warnbrk
      || aebflg.pedrear.warnbrk) {
    aebactuflg.warnbrk = true;
  }

  if (aebflg.car.prefill || ((aebflg.cyclist.prefill || aebflg.ped.prefill || aebflg.pedrear.prefill) && kAebShadowModeSoft == 0 && k_AEBShadowMode_active == 0)) {
    aebactuflg.prefill = true;
  }

  if (aebflg.car.iba_req || ((aebflg.cyclist.iba_req || aebflg.ped.iba_req || aebflg.pedrear.iba_req) && kAebShadowModeSoft == 0 && k_AEBShadowMode_active == 0)) {
    aebactuflg.iba_req = true;
  }

  if (aebflg.car.hold_req || ((aebflg.cyclist.hold_req || aebflg.ped.hold_req || aebflg.pedrear.hold_req) && kAebShadowModeSoft == 0 && k_AEBShadowMode_active == 0)) {
    aebactuflg.hold_req = true;
  }
  // if (k_AEBShadowMode_active == 1
  //     && (aebactuflg.iba_req == true || aebactuflg.prefill == true || aebactuflg.warnbrk == true
  //         || aebactuflg.softbrk == true || aebactuflg.hardbrk == true)) {
  //   aebactuflg.prewarn  = true;
  //   aebactuflg.iba_req  = false;
  //   aebactuflg.prefill  = false;
  //   aebactuflg.warnbrk  = false;
  //   aebactuflg.softbrk  = false;
  //   aebactuflg.hardbrk  = false;
  //   aebactuflg.hold_req = false;
  // }

  aebactuflg.prewarn_lf = aebactuflg.prewarn;

#ifdef AEB_DEBUG
  // std::cout<<"in actual flag update
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"aebactuflg.hardbrk is"<<(int)aebactuflg.hardbrk<<std::endl;
  // std::cout<<"aebactuflg.softbrk is"<<(int)aebactuflg.softbrk<<std::endl;
  // std::cout<<"aebactuflg.prefill is"<<(int)aebactuflg.prefill<<std::endl;
  // std::cout<<"aebactuflg.prewarn is"<<(int)aebactuflg.prewarn<<std::endl;
#endif
}
void update_aeb_deceleration_request(AEBSM& aebsm, AEBREQ& aebreq, AEBTRGETFLG aebflgreq, bool drvrovrd,
                                     bool holdovrd) {

  aebreq_lf = aebreq.get_aeb_req();

  if (aebsm.get_aeb_sys_st() == aebsysst_e::active) {
    if (aebflgreq.iba_req && !drvrovrd) {
      aebreq.set_dec_req(-9.81);        
      aebreq.set_eba_req(true);
      aebreq.set_aeb_req(true);
      aebreq.set_abp_req(false);
    } else if (aebflgreq.hardbrk && !aebflgreq.iba_req && !drvrovrd) {  
      aebreq.set_dec_req(-7.99);  
      aebreq.set_aeb_req(true);
      aebreq.set_abp_req(false);
      aebreq.set_eba_req(false);
    } else if (aebflgreq.softbrk && !aebflgreq.hardbrk && !aebflgreq.iba_req && !drvrovrd) {
      aebreq.set_dec_req(-2.99);
      aebreq.set_aeb_req(true);
      aebreq.set_abp_req(false);
      aebreq.set_eba_req(false);
    } else if (aebflgreq.hold_req && !aebflgreq.softbrk && !aebflgreq.hardbrk && !aebflgreq.iba_req && !holdovrd) {
      aebreq.set_dec_req(-7.99);          
      aebreq.set_aeb_req(true);
      aebreq.set_abp_req(false);
      aebreq.set_eba_req(false);
    } else if (aebflgreq.prefill && !aebflgreq.softbrk && !aebflgreq.hardbrk && !aebflgreq.iba_req && !drvrovrd) {
      aebreq.set_dec_req(0.0);
      aebreq.set_aeb_req(false);
      aebreq.set_abp_req(true);
      aebreq.set_eba_req(false);
    } else {
      aebreq.set_dec_req(0.0);
      aebreq.set_aeb_req(false);
      aebreq.set_abp_req(false);
      aebreq.set_eba_req(false);
    }
  } else {
    aebreq.set_dec_req(0.0);
    aebreq.set_aeb_req(false);
    aebreq.set_abp_req(false);
    aebreq.set_eba_req(false);
  }

  if ((aebflgreq.hardbrk || aebflgreq.softbrk || aebflgreq.iba_req) && !drvrovrd) {
    AEBDecelReq_Dummy = 2;
  }
  else {
    AEBDecelReq_Dummy = 1;
  }
#ifdef AEB_DEBUG
  // std::cout<<"in aeb decel
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"decel is"<<aebreq.get_dec_req()<<std::endl;
  // std::cout<<"aebreq is"<<(int)aebreq.get_aeb_req()<<std::endl;
  // std::cout<<"abpreq is"<<(int)aebreq.get_abp_req()<<std::endl;
#endif
}

void update_eba_req(AEBREQ& aebreq, double brkpres, double brkpresgrad, unsigned char gear, AEBTRGETFLG aebflgreq) {

  // if (gear == 1 && aebreq.get_dec_req() < -0.1
  //     && (brkpres > EBA_pDrvAppBrkPresThr_C
  //         || brkpresgrad > EBA_dpDrvAppBrkPresGradThr_C)
  // ){
  //     aebreq.set_eba_req(true);
  //     aebreq.set_dec_req(-9.81);
  // }
  // else
  //     aebreq.set_eba_req(false);

  if (aebflgreq.iba_req == 1) {
    aebreq.set_eba_req(true);
    aebreq.set_dec_req(-9.81);
  } else {
    aebreq.set_eba_req(false);
    aebreq.set_dec_req(0);
  }
  // here dec req will be kept other than set to zero if no eba is needed.
}

void update_aba_req(AEBREQ& aebreq) {

  if (aebreq.get_eba_req() || aebreq.get_dec_req() < -5) {

    aebreq.set_aba_req(true);
    aebreq.set_abalvl_req(3);

  } else if (aebreq.get_dec_req() < -2.5) {

    aebreq.set_aba_req(true);
    aebreq.set_abalvl_req(2);

  } else if (aebreq.get_abp_req()) {

    aebreq.set_aba_req(true);
    aebreq.set_abalvl_req(1);

  } else {

    aebreq.set_aba_req(false);
    aebreq.set_abalvl_req(0);
  }
}

bool aeb_driveroverride_accpedal(double accpdlpstn, double accpdlpstnrate, AEBREQ& aebreq) {
  double cycletime  = 0.02;
  bool   brkreqactv = false;
  brkreqactv        = aebreq.get_dec_req() < 0.0;

  bool pstnset       = accpdlpstn >= AEB_pctAbsAccPedOvrd_C && brkreqactv;
  bool pstnreset     = !brkreqactv;
  bool pstnrateset   = accpdlpstn >= AEB_pctRelAccPedOvrd_C && accpdlpstnrate >= AEB_xRelAccPedRateOvrd_C && brkreqactv;
  bool pstnratereset = !brkreqactv;

  return (AebOvrdPdlPstnTimer.timer(pstnset, pstnreset, cycletime) > AEB_tiAbsAccPedOvrdTimer_C
          || AebOvrdPdlRateTimer.timer(pstnrateset, pstnratereset, cycletime) > AEB_tiRelAccPedOvrdTimer_C);
}

bool aeb_driver_steering_override(double strwhlspd, double dyawrate) {
  double cycletime = 0.02;
  bool   strovrd = false, dyawovrd = false;
  strovrd = StrWhlSpdFilt.filt(std::fabs(strwhlspd), cycletime / (1 - AEB_pctStrngWhlAgSpdGain_C), cycletime)
            > AEB_xStrngWhlAgSpdOvrd_C;
  dyawovrd = std::fabs(dyawrate) > AEB_xVehYawrateOvrd_C;

  return (strovrd || dyawovrd);
}

bool aeb_driver_override(AEBREQ& aebreq, double accpdlpstn, double accpdlpstnrate, double strwhlspd, double dyawrate) {
  // to do
  return (aeb_driveroverride_accpedal(accpdlpstn, accpdlpstnrate, aebreq)
          || aeb_driver_steering_override(strwhlspd, dyawrate));
}

bool hold_override(float accelped, float brkped, bool brkpressed) {
  if (accelped >= 15 || (brkped > 15 && brkpressed == true)) {
    return true;
  } else {
    return false;
  }
}

void update_aeb_ctrlparam(ARBSIN* arbsin) {
  flgSeatBltFrntLeSts = arbsin->vehicleinfo_in.vehiclebody.SeatBltSts[0];

  stAEBOnOff = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehicledrive.AdFunCfg.AEBOnOffReq);

  // std::cout<< "stAEBOnOff is " << (int)stAEBOnOff <<std::endl;

  stTrailerMode = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehiclebody.TrailerModReq);

  stEPBSwt = static_cast<unsigned char>(arbsin->vehicleinfo_in.brakesys.PrkBrk.EPBSwtSts);

  flgBrkOvht = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkOverHeat);

  stEPBSts = static_cast<unsigned char>(arbsin->vehicleinfo_in.brakesys.PrkBrk.EPBSts);

  stHDCSts = static_cast<unsigned char>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.HDCSts);

  stAVHSts = static_cast<unsigned char>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.AVHSts);

  stStandstillSts = static_cast<unsigned char>(0);

  flgTCSDeactv = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.TCSDeactv);

  FlgTCSActive  = arbsin->vehicleinfo_in.brakesys.BrkFunSt.TCSActv;

  stFCWSet = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehicledrive.AdFunCfg.FCWSetReq);

  flgVDCDeactv = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.VDCDeactv);

  FlgVDCActive  = arbsin->vehicleinfo_in.brakesys.BrkFunSt.VDCActv;

  FlgDTCActive  = arbsin->vehicleinfo_in.brakesys.BrkFunSt.DTCActv;

  FlgABSActive  = arb_sin->vehicleinfo_in.brakesys.BrkFunSt.ABSActv;

  stDoorAjarFLSts = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehiclebody.Door.DoorAjarSts[0]);

  stVehSt = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehiclebody.VehStatus.VehState);

  stLvlAdjSts = static_cast<unsigned char>(0);

  stActGear = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehiclept.Gear.ActGear);

  stVehRdy = static_cast<unsigned char>(arbsin->vehicleinfo_in.vehiclebody.VehStatus.VehMode);

  flgAWBAvl = static_cast<bool>(/*arbsin->vehicleinfo_in.brakesys.BrkFunSt.*/ 1);  // need to add AWB

  flgABAAvl = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.ABAAvl);

  flgAutoBrkgAvl = static_cast<bool>(arbsin->vehicleinfo_in.vehiclecontrol.LngCtrlIf.AutoBrkgAvl);  // need to add AEB

  flgEBPAvl = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.ABPAvl);

  flgEBAAvl = static_cast<bool>(arbsin->vehicleinfo_in.brakesys.BrkFunSt.EBAAvl);

  flgVehStInld = arbsin->vehicle_info.arb_fim.flgVehStInld;

  flgHMIFail = arbsin->vehicle_info.arb_fim.flgHMIFail;

  flgADCInternalFault = arbsin->vehicle_info.arb_fim.flgADCInternalFault;

  flgLatAccValInvld = arbsin->vehicle_info.arb_fim.flgLatAccValInvld;

  flgYawrateInvld = arbsin->vehicle_info.arb_fim.flgYawrateInvld;

  flgLonAccValInvld = arbsin->vehicle_info.arb_fim.flgLonAccValInvld;

  flgSeatOccpFrntLeInvld = arbsin->vehicle_info.arb_fim.flgSeatOccpFrntLeInvld;

  flgSeatOccpFrntLeFailure = arbsin->vehicle_info.arb_fim.flgSeatOccpFrntLeFailure;

  flgBrkPrsOfsInvld = arbsin->vehicle_info.arb_fim.flgBrkPrsOfsInvld;

  flgVehSpdInvld = arbsin->vehicle_info.arb_fim.flgVehSpdInvld;

  flgWhlSpdInvld = arbsin->vehicle_info.arb_fim.flgWhlSpdInvld;

  flgWhlPulCntInvld = arbsin->vehicle_info.arb_fim.flgWhlPulCntInvld;

  flgBrkPrssInvld = arbsin->vehicle_info.arb_fim.flgBrkPrssInvld;

  flgBrkPdlInvld = arbsin->vehicle_info.arb_fim.flgBrkPdlInvld;

  flgStrngWhlAgSnsrFail = arbsin->vehicle_info.arb_fim.flgStrngWhlAgSnsrFail;

  flgStrngWhlAgSpdInvld = arbsin->vehicle_info.arb_fim.flgStrngWhlAgSpdInvld;

  flgStrngWhlAgSnsrNotCal = arbsin->vehicle_info.arb_fim.flgStrngWhlAgSnsrNotCal;

  flgAccPdlActPosnInvld = arbsin->vehicle_info.arb_fim.flgAccPdlActPosnInvld;

  flgGearInvld = arbsin->vehicle_info.arb_fim.flgGearInvld;

  flgSCMLossCommFault = arbsin->vehicle_info.arb_fim.flgSCMLossCommFault;

  flgBCMLossCommFault = arbsin->vehicle_info.arb_fim.flgBCMLossCommFault;

  flgVCULossCommFault = arbsin->vehicle_info.arb_fim.flgVCULossCommFault;

  flgBCULossCommFault = arbsin->vehicle_info.arb_fim.flgBCULossCommFault;

  flgACMLossCommFault = arbsin->vehicle_info.arb_fim.flgACMLossCommFault;

  flgCGWLossCommFault = arbsin->vehicle_info.arb_fim.flgCGWLossCommFault;

  flgCDCLossCommADAS_Fault = arbsin->vehicle_info.arb_fim.flgCDCLossCommADAS_Fault;

  flgSCMFail = arbsin->vehicle_info.arb_fim.flgSCMFail;

  flgRADFCLossCommFault = arbsin->vehicle_info.arb_fim.FIM_flgRADFCLossCommFault;

  flgRADFC_Blindness = arbsin->vehicle_info.arb_fim.FIM_flgRADFC_Blindness;

  flgRADFC_Failure = arbsin->vehicle_info.arb_fim.FIM_flgRADFC_Failure;

  flgFS_partialBlockage_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_partialBlockage_2;

  flgFS_partialBlockage_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_partialBlockage_3;

  flgFS_fullBlockage_1 = arbsin->vehicle_info.arb_fim.FIM_flgFS_fullBlockage_1;

  flgFS_fullBlockage_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_fullBlockage_2;

  flgFS_fullBlockage_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_fullBlockage_3;

  flgFS_autofixOutOfCalibHorizon = arbsin->vehicle_info.arb_fim.FIM_flgFS_autofixOutOfCalibHorizon;

  flgFS_autofixOutOfCalibYAW = arbsin->vehicle_info.arb_fim.FIM_flgFS_autofixOutOfCalibYAW;

  flgFS_TSR_outOfCalib_mode = arbsin->vehicle_info.arb_fim.FIM_flgFS_TSR_outOfCalib_mode;

  flgFS_out_of_focus_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_out_of_focus_2;

  flgFS_out_of_focus_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_out_of_focus_3;

  flgFS_frozenWindshield = arbsin->vehicle_info.arb_fim.FIM_flgFS_frozenWindshield;

  flgFS_blurredImage_1 = arbsin->vehicle_info.arb_fim.FIM_flgFS_blurredImage_1;

  flgFS_blurredImage_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_blurredImage_2;

  flgFS_blurredImage_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_blurredImage_3;

  flgFS_lowSun_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_lowSun_3;

  flgFS_splashes_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_splashes_2;

  flgFS_sunRay_1 = arbsin->vehicle_info.arb_fim.FIM_flgFS_sunRay_1;

  flgFS_sunRay_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_sunRay_2;

  flgFS_rain_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_rain_2;

  flgFS_rain_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_rain_3;

  flgFS_fog_2 = arbsin->vehicle_info.arb_fim.FIM_flgFS_fog_2;

  flgFS_fog_3 = arbsin->vehicle_info.arb_fim.FIM_flgFS_fog_3;
}

RearSm::RearSm() {}
RearSm::~RearSm() {}

AebRearSm::AebRearSm() {}
AebRearSm::~AebRearSm() {}

AEBSM::AEBSM(/* args */) {}

AEBSM::~AEBSM() {}

void AEBSM::set_tmpfail_cdn(bool cdn) {
  m_tmpfail = cdn;
}
void AEBSM::set_permfail_cdn(bool cdn) {
  m_permfail = cdn;
}
void AEBSM::set_psv_cdn(bool cdn) {
  m_psvcdn = cdn;
}
void AEBSM::set_aebonff_cdn(bool cdn) {
  m_isAEBOn = cdn;
}
void AEBSM::set_frwrdactv_cdn(bool cdn) {
  m_frwrdactv = cdn;
}
void AEBSM::set_bckwrdactv_cdn(bool cdn) {
  m_bckwrdactv = cdn;
}
void AEBSM::set_stdby_cdn(bool cdn) {
  m_stdby = cdn;
}
void AEBSM::set_snsrblk_cdn(bool cdn) {
  m_snsrblk = cdn;
}
bool AEBSM::get_tmpfail_cdn(void) {
  return m_tmpfail;
}
bool AEBSM::get_permfail_cdn(void) {
  return m_permfail;
}
bool AEBSM::get_psv_cdn(void) {
  return m_psvcdn;
}
bool AEBSM::get_aebOnff_cdn(void) {
  return m_isAEBOn;
}
bool AEBSM::get_frwrdactv_cdn(void) {
  return m_frwrdactv;
}
bool AEBSM::get_bckwrdactv_cdn(void) {
  return m_bckwrdactv;
}
bool AEBSM::get_stdby_cdn(void) {
  return m_stdby;
}
bool AEBSM::get_snsrblk_cdn(void) {
  return m_snsrblk;
}

aebst_e AEBSM::get_aeb_st(void) {
  return m_AebSt;
}

aebsysst_e AEBSM::get_aeb_sys_st(void) {
  return m_AebSysSt;
}

AEBREQ::AEBREQ(/* args */) {
  m_decreq            = 0.0;
  m_aebreq            = false;
  m_txtinfo           = aebmsg_e::off;
  m_txttime           = 0.0;
  m_txttithr          = 3.0;
  m_snsblk_displayed  = false;
  m_tmpfail_displayed = false;
  m_prmfail_displayed = false;
}

AEBREQ::~AEBREQ() {}
void AEBREQ::set_eba_req(bool req) {
  m_ebareq = req;
}
void AEBREQ::set_aba_req(bool req) {
  m_abareq = req;
}
void AEBREQ::set_aeb_req(bool req) {
  m_aebreq = req;
}
void AEBREQ::set_dec_req(double req) {
  m_decreq = req;
}
void AEBREQ::set_abalvl_req(unsigned char req) {
  m_abalvl = req;
}
void AEBREQ::set_abp_req(bool req) {
  m_abpreq = req;
}
bool AEBREQ::get_eba_req(void) {
  return m_ebareq;
}
bool AEBREQ::get_aba_req(void) {
  return m_abareq;
}
bool AEBREQ::get_aeb_req(void) {
  return m_aebreq;
}
double AEBREQ::get_dec_req(void) {
  return m_decreq;
}
unsigned char AEBREQ::get_abalvl_req(void) {
  return m_abalvl;
}
bool AEBREQ::get_abp_req(void) {
  return m_abpreq;
}

void AEBREQ::set_aeb_txt_info(bool snsblk, bool tmpfail, bool prmfail) {

  // 1:temp failure
  // 2:perm failure
  // 12: sensor blockage

  double cycletime = 0.02;

  if (m_txtinfo == aebmsg_e::temp_fail) {

    if (prmfail == true) {
      m_txtinfo           = aebmsg_e::perm_fail;
      m_txttime           = cycletime;
      m_prmfail_displayed = true;
    } else {
    }
    m_txttime += cycletime;
    if (m_txttime >= m_txttithr) {
      m_tmpfail_displayed = true;
      if (snsblk) {
        m_txtinfo          = aebmsg_e::snsr_blk;
        m_txttime          = cycletime;
        m_snsblk_displayed = true;
      } else {
        m_txttime = 0.0;
      }

    } else {
    }
  } else if (m_txtinfo == aebmsg_e::perm_fail) {
    if (m_txttime >= m_txttithr) {
      if (tmpfail) {
        m_txtinfo           = aebmsg_e::temp_fail;
        m_txttime           = cycletime;
        m_tmpfail_displayed = true;
      } else if (snsblk) {
        m_txtinfo          = aebmsg_e::snsr_blk;
        m_txttime          = cycletime;
        m_snsblk_displayed = true;
      } else {
      }
    } else {
      m_txttime += cycletime;
    }
  } else if (m_txtinfo == aebmsg_e::snsr_blk) {
    if (prmfail) {
      m_txtinfo           = aebmsg_e::perm_fail;
      m_txttime           = cycletime;
      m_prmfail_displayed = true;
    } else if (tmpfail) {
      m_txtinfo           = aebmsg_e::temp_fail;
      m_txttime           = cycletime;
      m_tmpfail_displayed = true;
    } else {
    }
    m_txttime += cycletime;
    if (m_txttime > m_txttithr) {
      m_txttime = 0.0;
      m_txtinfo = aebmsg_e::off;
    } else {
    }
  } else {
    if (prmfail) {
      m_txtinfo           = aebmsg_e::perm_fail;
      m_txttime           = cycletime;
      m_prmfail_displayed = true;
    } else if (tmpfail) {
      m_txtinfo           = aebmsg_e::temp_fail;
      m_txttime           = cycletime;
      m_tmpfail_displayed = true;
    } else if (snsblk) {
      m_txtinfo          = aebmsg_e::snsr_blk;
      m_txttime          = cycletime;
      m_snsblk_displayed = true;
    } else {
      /* code */
    }
  }
}
}  // namespace ad
}  // namespace nio