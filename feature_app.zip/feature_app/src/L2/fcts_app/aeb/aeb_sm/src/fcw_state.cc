#include <iostream>
#include <math.h>
#include "aeb_ctrlparam.h"
#include "aeb_type.h"
#include "fcts_loc_cfg.h"
#include "fcw_type.h"
#include "ids_lib.h"

namespace nio {
namespace ad {

FCWSM     FCWSm;
FcwRearSm fcwrearsm;
FCWREQ    FCWReq;

unsigned char fcwsetst = 2;
uint8_t       awbcycle = 0;

TimerEnabled    FcwOvrdPdlPstnTimer;
TimerEnabled    FcwOvrdPdlRateTimer;
static LowPassT StrWhlSpdFilt;

void FCWSM::update_FCW_State(void) {
  if (m_fcwst == fcwst_e::off) {
    m_fcwst    = fcwst_e::off;
    m_fcwsysst = fcwsysst_e::off;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    } else {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    }
  } else if (m_fcwst == fcwst_e::passive) {
    m_fcwst    = fcwst_e::passive;
    m_fcwsysst = fcwsysst_e::standby;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    } else {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    }
  } else if (m_fcwst == fcwst_e::standby) {
    m_fcwst    = fcwst_e::standby;
    m_fcwsysst = fcwsysst_e::standby;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_frwrdactv_cdn()) {
      m_fcwst    = fcwst_e::factive;
      m_fcwsysst = fcwsysst_e::active;
    } else if (get_bckwrdactv_cdn()) {
      m_fcwst    = fcwst_e::ractive;
      m_fcwsysst = fcwsysst_e::active;
    } else {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    }
  } else if (m_fcwst == fcwst_e::factive) {
    m_fcwst    = fcwst_e::factive;
    m_fcwsysst = fcwsysst_e::active;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_frwrdactv_cdn()) {
      m_fcwst    = fcwst_e::factive;
      m_fcwsysst = fcwsysst_e::active;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    } else {
      m_fcwst    = fcwst_e::factive;
      m_fcwsysst = fcwsysst_e::active;
    }
  } else if (m_fcwst == fcwst_e::ractive) {
    m_fcwst    = fcwst_e::ractive;
    m_fcwsysst = fcwsysst_e::active;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_bckwrdactv_cdn()) {
      m_fcwst    = fcwst_e::ractive;
      m_fcwsysst = fcwsysst_e::active;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    } else {
      m_fcwst    = fcwst_e::ractive;
      m_fcwsysst = fcwsysst_e::active;
    }
  } else if (m_fcwst == fcwst_e::tmperr) {
    m_fcwst    = fcwst_e::tmperr;
    m_fcwsysst = fcwsysst_e::inhibit;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else if (get_tmpfail_cdn()) {
      m_fcwst    = fcwst_e::tmperr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_permfail_cdn()) {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    } else if (get_psv_cdn()) {
      m_fcwst    = fcwst_e::passive;
      m_fcwsysst = fcwsysst_e::standby;
    } else if (get_stdby_cdn()) {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    } else {
      m_fcwst    = fcwst_e::standby;
      m_fcwsysst = fcwsysst_e::standby;
    }
  } else if (m_fcwst == fcwst_e::prmnterr) {
    m_fcwst    = fcwst_e::prmnterr;
    m_fcwsysst = fcwsysst_e::inhibit;
    if (!get_aebOnff_cdn()) {
      m_fcwst    = fcwst_e::off;
      m_fcwsysst = fcwsysst_e::off;
    } else {
      m_fcwst    = fcwst_e::prmnterr;
      m_fcwsysst = fcwsysst_e::inhibit;
    }
  } else {
  }
  // std::cout<<"in state condition
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"m_fcwst is"<<(int)m_fcwst<<std::endl;
  // std::cout<<"m_fcwsysst is"<<(int)m_fcwsysst<<std::endl;

  if (m_fcwsysst == fcwsysst_e::off) {
    fcwsetst = 3;
  } else {
    fcwsetst = stFCWSet;
  }
}
bool fcw_driveroverride_accpedal(double accpdlpstn, double accpdlpstnrate, FCWREQ& fcwreq) {
  double cycletime  = 0.02;
  bool   brkreqactv = false;
  brkreqactv        = fcwreq.get_pre_warn() || fcwreq.get_latent_warn();

  bool pstnset       = accpdlpstn >= FCW_pctAbsAccPedOvrd_C && brkreqactv;
  bool pstnreset     = !brkreqactv;
  bool pstnrateset   = accpdlpstn >= FCW_pctRelAccPedOvrd_C && accpdlpstnrate >= FCW_xRelAccPedRateOvrd_C && brkreqactv;
  bool pstnratereset = !brkreqactv;

  return (FcwOvrdPdlPstnTimer.timer(pstnset, pstnreset, cycletime) > FCW_tiAbsAccPedOvrdTimer_C
          || FcwOvrdPdlRateTimer.timer(pstnrateset, pstnratereset, cycletime) > FCW_tiRelAccPedOvrdTimer_C);
}

bool fcw_driver_steering_override(double strwhlspd, double dyawrate) {
  double cycletime = 0.02;
  bool   strovrd = false, dyawovrd = false;
  strovrd = StrWhlSpdFilt.filt(fabsf(strwhlspd), cycletime / (1 - FCW_pctStrngWhlAgSpdGain_C), cycletime)
            > FCW_xStrngWhlAgSpdOvrd_C;
  dyawovrd = fabsf(dyawrate) > FCW_xVehYawrateOvrd_C;

  return (strovrd || dyawovrd);
}

bool fcw_driver_override(FCWREQ& fcwreq, double accpdlpstn, double accpdlpstnrate, double strwhlspd, double dyawrate) {
  return (fcw_driveroverride_accpedal(accpdlpstn, accpdlpstnrate, fcwreq)
          || fcw_driver_steering_override(strwhlspd, dyawrate));
}

void update_fcw_req(FCWREQ& fcwreq, FCWSM& fcwsm, AEBTRGETFLG aebactuflg) {
  if (fcwsm.get_fcw_sys_st() == fcwsysst_e::active) {
    if (aebactuflg.prewarn == true) {
      fcwreq.set_pre_warn(aebactuflg.warntype);
      fcwreq.set_latent_warn(false);
    } else if (aebactuflg.latentwarn == true) {
      fcwreq.set_pre_warn(0);
      fcwreq.set_latent_warn(true);
    } 
/*     else {
      fcwreq.set_pre_warn(0);
      fcwreq.set_latent_warn(false);
    } */
  } else {
    fcwreq.set_pre_warn(0);
    fcwreq.set_latent_warn(false);
  }
#ifdef FCW_DEBUG
  // std::cout<<"in fcwreq
  // =========================================================================================================================="<<std::endl;
  // std::cout<<"prewarn is"<<(int)fcwreq.get_pre_warn()<<std::endl;
  // std::cout<<"latentwarn is"<<(int)fcwreq.get_latent_warn()<<std::endl;
#endif
}

void update_awb_req(FCWSM& fcwsm, FCWREQ& fcwreq, double vehspd, bool awbflg) {
  if (awbflg == true && awbcycle <= 10) {
    fcwreq.set_awb_req(true);
    fcwreq.set_awb_lvl(3);
    awbcycle++;
  } else if (awbflg == false && awbcycle <= 10 && awbcycle > 0) {
    fcwreq.set_awb_req(true);
    fcwreq.set_awb_lvl(3);
    awbcycle++;
  } else {
    fcwreq.set_awb_req(false);
    fcwreq.set_awb_lvl(0);
    awbcycle = 0;
  }
}

FcwRearSm::FcwRearSm() {}
FcwRearSm::~FcwRearSm() {}

FCWSM::FCWSM(/* args */) {}

FCWSM::~FCWSM() {}

fcwsysst_e FCWSM::get_fcw_sys_st() {
  return m_fcwsysst;
}

FCWREQ::FCWREQ(/* args */) {}

FCWREQ::~FCWREQ() {}

void FCWREQ::set_pre_warn(int warn) {
  m_prewarn = warn;
}
void FCWREQ::set_latent_warn(bool warn) {
  m_latentwarn = warn;
}
void FCWREQ::set_awb_req(bool req) {
  m_awbreq = req;
}
void FCWREQ::set_awb_lvl(unsigned char lvl) {
  m_awblvl = lvl;
}
int FCWREQ::get_pre_warn(void) {
  return m_prewarn;
}
bool FCWREQ::get_latent_warn(void) {
  return m_latentwarn;
}
bool FCWREQ::get_awb_req(void) {
  return m_awbreq;
}
unsigned char FCWREQ::get_awb_lvl(void) {
  return m_awblvl;
}
}  // namespace ad
}  // namespace nio