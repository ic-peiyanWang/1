#include "aeb_type.h"
#include "aeb_ctrlparam.h"
#include "aeb_state.h"
#include "fcts_diag.h"
#include "aeb_calibration.h"
//#include "aeb_in_house.h"
#define Aeb_InitMask                                (0x00000018)
#define Aeb_LossMask                                (0x0000005D)

namespace nio {
    namespace ad {

        //aebsysst_e  aeb_sys_st_lf;
        bool        aeb_suppress            = false;
        uint16_t    aeb_suppress_age        = 0;

        //RearSmSt    aebrear_st_lf;
        bool        aebrear_suppress        = false;
        uint16_t    aebrear_suppress_age    = 0;

        uint16_t    MaxAebSuppressAge       = (kAebHilMode == false) ? 1500:250;
        uint16_t    MaxAebRearSuppressAge   = (kAebHilMode == false) ? 1500:250;

        //extern nio::ad::AEBInHouse aeb_;
        APP_state_e AebState;

        extern AEBTRGETFLG AEBActuFlg;

        uint32_t psvcdn0_mask = 0x00000000;

        uint32_t psvcdn1_mask = 0xFFFFFFFF;

        uint32_t psvcdn2_mask = 0xFFFFFFFF;

        uint32_t tmpfail0_mask = 0xFFFFFFFF;

        uint32_t tmpfail1_mask = 0xFFFFFFFF;

        uint32_t tmpfail2_mask = 0xFFFFFFFF;

        uint32_t tmpfail3_mask = 0xFFFFFFFF;

        uint32_t tmpfail4_mask = 0xFFFFFFFF;

        uint32_t tmpfail5_mask = 0xFFFFFFFF;

        uint32_t tmpfail6_mask = 0xFFFFFFFF;

        uint32_t tmpfail7_mask = 0xFFFFFFFF;

        uint32_t tmpfail8_mask = 0x00000000;

        uint32_t tmpfail9_mask = 0x00000000;


        void RearSm::UpdateOffCondition(){
            /* void */
        }

        //off condition
        void AebRearSm::UpdateOffCondition(){

            set_off_cdn((stAEBOnOff == 0) || (stTrailerMode == 1) || (kAebRearEnable == false));
        }

        void RearSm::UpdateStandbyCondition(){
            /* void */
        }

        void RearSm::UpdatePassiveCondition(){

            uint32_t temp = 0x00000000;

            //0: condition pass   1: condition fail
            temp = (
                    /* ((flgSeatBltFrntLeSts == 0)  << 0) |
                    ((flgBrkOvht == 1) << 1) |
                    ((stEPBSts != 3) << 2) |
                    ((stHDCSts == 3)  << 3) |
                    ((stAVHSts == 3) << 4) |
                    ((flgTCSDeactv == 1) << 5) | */

                    ((flgVDCDeactv == 1) << 6) |
                    ((stDoorAjarFLSts == 0) << 7) |
                    ((stVehSt != 2) << 8) |
                    ((!(stLvlAdjSts != 2)) << 9) |
                    ((!(stActGear == 1 || stActGear == 0 || stActGear == 2)) << 10) |
                    ((!(stVehRdy>=3 && stVehRdy<=5)) << 11) |
                    ((FlgVDCActive == true) << 12) |
                    ((FlgTCSActive == true) << 13) | 
                    ((FlgDTCActive == true) << 14) |
                    ((FlgABSActive == true) << 15));

            set_psv_cdn_bit(temp);
            set_psv_cdn(get_psv_cdn_bit() == 0);
        }

        void RearSm::UpdateFailCondition(){

            set_fail_cdn((AEBSm.get_aeb_sys_st() == aebsysst_e::inhibit) || (gRearAEBFaultSt != FimFault_e::NoFault));
        };

        void RearSm::UpdateActiveCondition(){
            /* void */
        }

        void AebRearSm::UpdateActiveCondition(){

            bool aebrear_active  = false;

            if(aebreq_lf == true && (AEBReq.get_aeb_req() == false) && stActGear == 2){
                aebrear_suppress = true;
            }

            if(aebrear_suppress == true && aebrear_suppress_age <= MaxAebRearSuppressAge){
                aebrear_suppress_age++;
            }
            else{
                aebrear_suppress     = false;
                aebrear_suppress_age = 0;
            }

            if((AEBFlg.pedrear.hardbrk == true || AEBFlg.pedrear.softbrk == true || AEBFlg.pedrear.prefill == true || AEBFlg.pedrear.hold_req == true) &&
                aebrear_suppress == false &&
                stActGear == 2){
                    aebrear_active = true;
                }

            //aebrear_st_lf = get_state();
            set_act_cdn(aebrear_active);
        };

        void RearSm::Main(){
            UpdateOffCondition();
            UpdateStandbyCondition();
            UpdatePassiveCondition();
            UpdateFailCondition();
            UpdateActiveCondition();
            UpdateState();
        }

        void aeb_off_condition(AEBSM& aebsm){
            aebsm.set_aebonff_cdn((stAEBOnOff == true));
        }

        void aeb_passive_condition(AEBSM& aebsm){

            uint32_t psvcdn0 = 0,psvcdn1 = 0,psvcdn2 = 0;

            psvcdn0 = (flgSeatBltFrntLeSts == 0) 
                //     + ((stEPBSwt == 3) << 1)
                    + ((flgBrkOvht == 1) << 2)
                    + ((stEPBSts != 3) << 3)
                    + ((stHDCSts == 3) << 4)
                    + ((stAVHSts == 3) << 5 )
                    + ((stStandstillSts == 3) << 6)
                    + ((flgTCSDeactv == 1) << 7); 

            psvcdn1 = (flgVDCDeactv == 1) 
                    + ((stDoorAjarFLSts == 0) << 1)
                    + ((stVehSt != 2) << 2)
                    + ((!(stLvlAdjSts == 0)) << 3)
                    + ((!(stActGear == 1 || stActGear == 0 || stActGear == 2)) << 4)
                    + ((!(stVehRdy>=3 && stVehRdy<=5)) << 5);

            psvcdn2 = (FlgVDCActive == true) + 
                        ((FlgTCSActive == true) << 1) + 
                        ((FlgDTCActive == true) << 2) +
                        ((FlgABSActive == true) << 3);

            AEBSm.set_psv_cdn(((psvcdn0 & psvcdn0_mask)|| (psvcdn1 & psvcdn1_mask) || (psvcdn2 & psvcdn2_mask)) && aebsm.get_aebOnff_cdn());
                // std::cout << "psvcdn0 is "<< psvcdn0 <<std::endl;
                // std::cout << "psvcdn1 is "<< psvcdn1 <<std::endl;
                // std::cout << "psvcdn2 is "<< psvcdn2 <<std::endl;
                // std::cout << "flgSeatBltFrntLeSts is "<< (int)flgSeatBltFrntLeSts <<std::endl;
                // std::cout << "stEPBSts is "<< (int)stEPBSts <<std::endl;
                // std::cout << "flgTCSDeactv is "<< (int)flgTCSDeactv <<std::endl;

            //stVehAEBSwt 
        }

        void aeb_temp_fail_condition(AEBSM& aebsm){

            uint32_t tmpfail0 = 0,tmpfail1 = 0,tmpfail2 = 0,tmpfail3 = 0,
                tmpfail4 = 0,tmpfail5 = 0,tmpfail6 = 0,tmpfail7 = 0,tmpfail8 = 0,tmpfail9 = 0;

                tmpfail0 = (flgVehStInld)
                    + (flgHMIFail << 1)
                    + (flgADCInternalFault  << 2)
                    + (flgLatAccValInvld << 3)
                    + (flgYawrateInvld << 4)
                    + (flgLonAccValInvld << 5)
                    + (flgSeatOccpFrntLeInvld << 6)
                    + (flgSeatOccpFrntLeFailure << 7);

                tmpfail1 = (flgBrkPrsOfsInvld)
                    + (flgVehSpdInvld << 1)
                    + (flgBrkPrssInvld << 2)
                    + (flgBrkPdlInvld << 3);
                    + (flgWhlSpdInvld << 4);
                    + (flgWhlPulCntInvld << 5);

                tmpfail2 = (flgStrngWhlAgSnsrFail)
                    + (flgStrngWhlAgSpdInvld << 1)
                    + (flgStrngWhlAgSnsrNotCal  << 2)
                    + (flgAccPdlActPosnInvld << 3)
                    + (flgGearInvld << 4);

                tmpfail3 = (flgSCMLossCommFault)
                    + (flgBCMLossCommFault << 1)
                    + (flgVCULossCommFault << 2)
                    + (flgBCULossCommFault << 3) 
                    + (flgACMLossCommFault << 4) 
                    + (flgCGWLossCommFault << 5) 
                    + (flgCDCLossCommADAS_Fault << 6)
                    + (flgSCMFail << 7);
            // 
            //flgEQ4NonRecoverableFault 
            //flgEQ4RecoverableFault 
            //flgEQ4Coredump 
            //flgEQ4LossCommFault 

                tmpfail4 = (flgFS_partialBlockage_2)
                    + (flgFS_partialBlockage_3 << 1)
                    + (flgFS_fullBlockage_1 << 2)
                    + (flgFS_fullBlockage_2 << 3)
                    + (flgFS_fullBlockage_3 << 4)
                    + (flgRADFCLossCommFault << 5)
                    + (flgRADFC_Blindness << 6)
                    + (flgRADFC_Failure << 7);

                tmpfail5 = (flgFS_autofixOutOfCalibHorizon)
                    + (flgFS_autofixOutOfCalibYAW << 1)
                    + (flgFS_TSR_outOfCalib_mode << 2)
                    + (flgFS_out_of_focus_2 << 3)
                    + (flgFS_out_of_focus_3 << 4)
                    + (flgFS_frozenWindshield << 5);

                tmpfail6 = (flgFS_blurredImage_1)
                    + (flgFS_blurredImage_2 << 1)
                    + (flgFS_blurredImage_3 << 2)
                    + (flgFS_lowSun_3 << 3)
                    + (flgFS_splashes_2 << 4);

                tmpfail7 = (flgFS_sunRay_1)
                    + (flgFS_sunRay_2 << 1)
                    + (flgFS_rain_2 << 2)
                    + (flgFS_rain_3 << 3)
                    + (flgFS_fog_2 << 4)
                    + (flgFS_fog_3 << 5);

                tmpfail8 = (!(flgAWBAvl == 1)) 
                    + ((!(flgABAAvl == 1)) << 1) 
                    + ((!(flgAutoBrkgAvl == 1)) << 2) 
                    + ((!(flgEBPAvl == 1)) << 3) 
                    + ((!(flgEBAAvl == 1)) << 4);


                // std::cout << "tmpfail0 is "<< tmpfail0 <<std::endl;
                // std::cout << "tmpfail1 is "<< tmpfail1 <<std::endl;
                // std::cout << "tmpfail2 is "<< tmpfail2 <<std::endl;
                // std::cout << "tmpfail3 is "<< tmpfail3 <<std::endl;
                // std::cout << "tmpfail4 is "<< tmpfail4 <<std::endl;
                // std::cout << "tmpfail5 is "<< tmpfail5 <<std::endl;
                // std::cout << "tmpfail6 is "<< tmpfail6 <<std::endl;
                // std::cout << "tmpfail7 is "<< tmpfail7 <<std::endl;
                // std::cout << "tmpfail8 is "<< tmpfail8 <<std::endl;

            aebsm.set_tmpfail_cdn(((tmpfail0 & tmpfail0_mask) || (tmpfail1 & tmpfail1_mask) || (tmpfail2 & tmpfail2_mask) || (tmpfail3 & tmpfail3_mask) || (tmpfail4 & tmpfail4_mask)
            || (tmpfail5 & tmpfail5_mask) || (tmpfail6 & tmpfail6_mask) || (tmpfail7 & tmpfail7_mask) || (tmpfail8 && tmpfail8_mask) 
            || (AebState != APP_state_e::FullActive)||(gAEBFaultSt != FimFault_e::NoFault)) && aebsm.get_aebOnff_cdn());
            
        }

        void aeb_perm_fail_condition(AEBSM& aebsm){
        aebsm.set_permfail_cdn(false); 
        }

        void aeb_forward_activation_condition(AEBSM& aebsm, AEBTRGETFLG &actflg, AEBREQ &aebreq){
            bool aebactive = false;

            if(aebreq_lf == true && (aebreq.get_aeb_req() == false) && stActGear == 1){
                aeb_suppress = true;
            }
            if(aeb_suppress == true && aeb_suppress_age <= MaxAebSuppressAge){
                aeb_suppress_age++;
            }
            else{
                aeb_suppress     = false;
                aeb_suppress_age = 0;
            }

            if ((actflg.hardbrk == true || actflg.softbrk == true ||actflg.prefill == true || actflg.iba_req == true ||actflg.hold_req == true) &&
            (aeb_suppress == false) &&
            stActGear == 1) {
                aebactive = true;
            }

            aebsm.set_frwrdactv_cdn(aebactive);
        }

        void aeb_backward_activation_condition(AEBSM& aebsm, AebRearSm& sm){
            if(kAebRearEnable == true){
                aebsm.set_bckwrdactv_cdn(sm.get_state() == RearSmSt::kActive);
            }
            else{
                aebsm.set_bckwrdactv_cdn(false);
            }
        }

        void aeb_standby_condition(AEBSM& aebsm){
            aebsm.set_stdby_cdn(aebsm.get_aebOnff_cdn() && !aebsm.get_psv_cdn() && !aebsm.get_permfail_cdn()  && !aebsm.get_tmpfail_cdn());
        }
        void update_aeb_conditions(void){
            AebState = APP_StateManage(Arb_TopicNoInit,Aeb_InitMask,Arb_TopicLoss,Aeb_LossMask);
            aeb_off_condition(AEBSm);
            aeb_passive_condition(AEBSm);
            aeb_standby_condition(AEBSm);
            aeb_temp_fail_condition(AEBSm);
            aeb_perm_fail_condition(AEBSm);
            aeb_forward_activation_condition(AEBSm, AEBActuFlg, AEBReq);
            aeb_backward_activation_condition(AEBSm, aebrearsm);
        }

    }

}
