#include "aeb_calibration.h"
#include "update_force_cal.h"
#include <string.h>

void update_force_calibration() {
    float EAEB_dstPredLongPedBik_v_force[64]  = { 
    0.8F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.85F,  0.75F,  0.6F,  0.6F,  0.6F,  0.55F,  0.5F,  0.5F,  
    0.9F,  0.8F,  0.7F,  0.65F,  0.65F,  0.55F,  0.5F,  0.5F,  
    0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  
    0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
    0.8F,  0.75F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
    0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F,  
    0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F 
    }; 
    memcpy(EAEB_dstPredLongPedBik_v, EAEB_dstPredLongPedBik_v_force, sizeof(EAEB_dstPredLongPedBik_v_force));

    float EAEB_dstPredCrossPedBik_v_force[64]  = { 
    0.8F,  0.75F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.85F,  0.8F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  
    0.8F,  0.8F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.65F,  0.6F,  0.5F,  
    0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.6F,  0.5F,  
    0.75F,  0.75F,  0.8F,  0.7F,  0.7F,  0.65F,  0.6F,  0.5F,  
    0.7F,  0.7F,  0.85F,  0.8F,  0.75F,  0.75F,  0.65F,  0.5F,  
    0.7F,  0.7F,  0.7F,  0.75F,  0.8F,  0.8F,  0.7F,  0.5F 
    }; 
    memcpy(EAEB_dstPredCrossPedBik_v, EAEB_dstPredCrossPedBik_v_force, sizeof(EAEB_dstPredCrossPedBik_v_force));

    float EAEB_dstPredStatPedBik_v_force[64]  = { 
    0.75F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.75F,  0.6F,  0.6F,  0.6F,  0.55F,  0.5F,  0.5F,  
    0.85F,  0.8F,  0.7F,  0.65F,  0.65F,  0.55F,  0.5F,  0.5F,  
    0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  
    0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
    0.8F,  0.75F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
    0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F,  
    0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F 
    }; 
    memcpy(EAEB_dstPredStatPedBik_v, EAEB_dstPredStatPedBik_v_force, sizeof(EAEB_dstPredStatPedBik_v_force));

    float EAEB_dstCurrLongPedBik_v_force[64]  = { 
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F 
    }; 
    memcpy(EAEB_dstCurrLongPedBik_v, EAEB_dstCurrLongPedBik_v_force, sizeof(EAEB_dstCurrLongPedBik_v_force));

    float EAEB_dstCurrCrossPedBik_v_force[64]  = { 
    2.0F,  1.9F,  1.9F,  1.9F,  1.8F,  1.8F,  1.6F,  1.35F,  
    2.0F,  1.9F,  1.9F,  1.9F,  1.8F,  1.8F,  1.6F,  1.35F,  
    2.2F,  2.1F,  2.1F,  2.0F,  1.9F,  1.9F,  1.7F,  1.35F,  
    2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  1.9F,  1.7F,  1.35F,  
    2.3F,  2.3F,  2.15F,  2.1F,  2.0F,  2.0F,  1.9F,  1.35F,  
    2.3F,  2.4F,  2.3F,  2.2F,  2.2F,  2.2F,  2.0F,  1.35F,  
    2.3F,  2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  2.1F,  1.35F,  
    2.2F,  2.5F,  2.5F,  2.75F,  2.75F,  2.75F,  2.1F,  1.35F 
    }; 
    memcpy(EAEB_dstCurrCrossPedBik_v, EAEB_dstCurrCrossPedBik_v_force, sizeof(EAEB_dstCurrCrossPedBik_v_force));

    float EAEB_dstCurrStatPedBik_v_force[64]  = { 
    0.60F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.65F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.7F,  0.7F,  0.63F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.75F,  0.65F,  0.55F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.77F,  0.68F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.78F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.8F,  0.73F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
    0.8F,  0.8F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F 
    }; 
    memcpy(EAEB_dstCurrStatPedBik_v, EAEB_dstCurrStatPedBik_v_force, sizeof(EAEB_dstCurrStatPedBik_v_force));

    float EAEB_dstPredLongPedBik_warn_v_force[64]  = { 
    0.8F,  0.7F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
    0.85F,  0.75F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  0.55F,  
    0.9F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
    0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.65F,  0.55F,  0.55F,  
    0.85F,  0.8F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
    0.8F,  0.75F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
    0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  
    0.7F,  0.65F,  0.65F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F 
    }; 
    memcpy(EAEB_dstPredLongPedBik_warn_v, EAEB_dstPredLongPedBik_warn_v_force, sizeof(EAEB_dstPredLongPedBik_warn_v_force));

    float EAEB_dstPredCrossPedBik_warn_v_force[64]  = { 
    0.8F,  0.75F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
    0.85F,  0.8F,  0.75F,  0.65F,  0.65F,  0.65F,  0.65F,  0.55F,  
    0.8F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.65F,  0.55F,  
    0.75F,  0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  
    0.75F,  0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  
    0.75F,  0.75F,  0.7F,  0.7F,  0.7F,  0.65F,  0.6F,  0.55F,  
    0.7F,  0.7F,  0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.5F,  
    0.7F,  0.7F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.5F 
    }; 
    memcpy(EAEB_dstPredCrossPedBik_warn_v, EAEB_dstPredCrossPedBik_warn_v_force, sizeof(EAEB_dstPredCrossPedBik_warn_v_force));

    float EAEB_dstPredStatPedBik_warn_v_force[64]  = { 
    0.8F,  0.7F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
    0.85F,  0.75F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  0.55F,  
    0.9F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
    0.9F,  0.85F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
    0.85F,  0.8F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
    0.8F,  0.75F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
    0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.55F,  
    0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.55F 
    }; 
    memcpy(EAEB_dstPredStatPedBik_warn_v, EAEB_dstPredStatPedBik_warn_v_force, sizeof(EAEB_dstPredStatPedBik_warn_v_force));

    float EAEB_dstCurrLongPedBik_warn_v_force[64]  = { 
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F 
    }; 
    memcpy(EAEB_dstCurrLongPedBik_warn_v, EAEB_dstCurrLongPedBik_warn_v_force, sizeof(EAEB_dstCurrLongPedBik_warn_v_force));

    float EAEB_dstCurrCrossPedBik_warn_v_force[64]  = { 
    2.2F,  2.2F,  2.1F,  2.1F,  2.0F,  2.0F,  1.8F,  1.55F,  
    2.2F,  2.1F,  2.1F,  2.1F,  2.0F,  2.0F,  1.8F,  1.55F,  
    2.4F,  2.3F,  2.3F,  2.2F,  2.1F,  2.1F,  1.9F,  1.55F,  
    2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.1F,  1.9F,  1.55F,  
    2.5F,  2.5F,  2.35F,  2.3F,  2.2F,  2.2F,  2.1F,  1.55F,  
    2.5F,  2.6F,  2.5F,  2.4F,  2.4F,  2.4F,  2.2F,  1.55F,  
    2.5F,  2.7F,  2.7F,  2.7F,  2.7F,  2.7F,  2.3F,  1.55F,  
    2.4F,  2.7F,  2.7F,  2.85F,  2.85F,  2.85F,  2.3F,  1.55F 
    }; 
    memcpy(EAEB_dstCurrCrossPedBik_warn_v, EAEB_dstCurrCrossPedBik_warn_v_force, sizeof(EAEB_dstCurrCrossPedBik_warn_v_force));

    float EAEB_dstCurrStatPedBik_warn_v_force[64]  = { 
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
    0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F  
    }; 
    memcpy(EAEB_dstCurrStatPedBik_warn_v, EAEB_dstCurrStatPedBik_warn_v_force, sizeof(EAEB_dstCurrStatPedBik_warn_v_force));

    float EAEB_spdExpand_Latvel_x_force[5]  = { 
    1.6F,  2.2F,  4.0F,  6.0F,  8.0F };
    memcpy(EAEB_spdExpand_Latvel_x, EAEB_spdExpand_Latvel_x_force, sizeof(EAEB_spdExpand_Latvel_x_force));

    float EAEB_dstPredExpandSide_v_force[40]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
    0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
    0.1F,  0.2F,  0.2F,  0.2F,  0.2F,  
    0.2F,  0.2F,  0.2F,  0.2F,  0.4F,  
    0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.4F,  0.2F,  0.4F,  0.6F,  0.6F,  
    0.6F,  0.6F,  0.6F,  0.4F,  0.2F 
    }; 
    memcpy(EAEB_dstPredExpandSide_v, EAEB_dstPredExpandSide_v_force, sizeof(EAEB_dstPredExpandSide_v_force));

    float EAEB_dstCurrExpandSide_v_force[40]  = { 
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  1.0F,  1.0F,  
    1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  
    1.0F,  1.5F,  2.0F,  2.0F,  2.0F,  
    2.0F,  1.5F,  1.0F,  0.5F,  1.5F,  
    2.0F,  2.0F,  2.0F,  2.0F,  1.5F,  
    1.0F,  0.5F,  1.5F,  2.0F,  2.0F,  
    2.0F,  2.0F,  1.5F,  1.0F,  0.5F 
    }; 
    memcpy(EAEB_dstCurrExpandSide_v, EAEB_dstCurrExpandSide_v_force, sizeof(EAEB_dstCurrExpandSide_v_force));

    float EAEB_dstPredExpandSide_warn_v_force[40]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.2F,  0.2F,  0.2F,  0.2F,  
    0.2F,  0.2F,  0.2F,  0.2F,  0.4F,  
    0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.4F,  0.2F,  0.4F,  0.6F,  0.6F,  
    0.6F,  0.6F,  0.6F,  0.4F,  0.2F 
    }; 
    memcpy(EAEB_dstPredExpandSide_warn_v, EAEB_dstPredExpandSide_warn_v_force, sizeof(EAEB_dstPredExpandSide_warn_v_force));

    float EAEB_dstCurrExpandSide_warn_v_force[40]  = { 
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  1.0F,  1.0F,  
    1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  
    1.0F,  1.5F,  2.0F,  2.0F,  2.0F,  
    2.0F,  1.5F,  1.0F,  0.5F,  1.5F,  
    2.0F,  2.0F,  2.0F,  2.0F,  1.5F,  
    1.0F,  0.5F,  1.5F,  2.0F,  2.0F,  
    2.0F,  2.0F,  1.5F,  1.0F,  0.5F 
    }; 
    memcpy(EAEB_dstCurrExpandSide_warn_v, EAEB_dstCurrExpandSide_warn_v_force, sizeof(EAEB_dstCurrExpandSide_warn_v_force));

    float EAEB_dstPredExpandSide_Bik_v_force[40]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
    0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
    0.1F,  0.3F,  0.3F,  0.3F,  0.3F,  
    0.3F,  0.3F,  0.3F,  0.3F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F 
    }; 
    memcpy(EAEB_dstPredExpandSide_Bik_v, EAEB_dstPredExpandSide_Bik_v_force, sizeof(EAEB_dstPredExpandSide_Bik_v_force));

    float EAEB_dstCurrExpandSide_Bik_v_force[40]  = { 
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  1.5F,  1.5F,  
    1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  
    1.5F,  4.0F,  4.0F,  4.0F,  4.0F,  
    5.0F,  5.0F,  4.0F,  4.0F,  5.0F,  
    5.0F,  5.0F,  5.0F,  6.0F,  6.0F,  
    5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
    5.0F,  5.0F,  5.0F,  5.0F,  5.0F 
    }; 
    memcpy(EAEB_dstCurrExpandSide_Bik_v, EAEB_dstCurrExpandSide_Bik_v_force, sizeof(EAEB_dstCurrExpandSide_Bik_v_force));

    float EAEB_dstPredExpandSide_Bik_warn_v_force[40]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
    0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
    0.1F,  0.3F,  0.3F,  0.3F,  0.3F,  
    0.3F,  0.3F,  0.3F,  0.3F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F 
    }; 
    memcpy(EAEB_dstPredExpandSide_Bik_warn_v, EAEB_dstPredExpandSide_Bik_warn_v_force, sizeof(EAEB_dstPredExpandSide_Bik_warn_v_force));

    float EAEB_dstCurrExpandSide_Bik_warn_v_force[40]  = { 
    0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
    0.5F,  0.5F,  0.5F,  1.5F,  1.5F,  
    1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  
    1.5F,  4.0F,  4.0F,  4.0F,  4.0F,  
    4.0F,  4.0F,  4.0F,  4.0F,  5.0F,  
    5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
    5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
    5.0F,  5.0F,  5.0F,  5.0F,  5.0F 
    }; 
    memcpy(EAEB_dstCurrExpandSide_Bik_warn_v, EAEB_dstCurrExpandSide_Bik_warn_v_force, sizeof(EAEB_dstCurrExpandSide_Bik_warn_v_force));

    float EAEB_TTCPedBik_Egospd_x_force[10]  = { 
    1.5F,  2.78F,  4.16F,  5.55F,  6.95F,  8.33F,  9.5F,  11.11F,  13.88F,  16.66F };
    memcpy(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPedBik_Egospd_x_force, sizeof(EAEB_TTCPedBik_Egospd_x_force));

    float EAEB_TTCCrossPed_Pref_v_force[10]  = { 
    0.9F,  0.85F,  0.9F,  0.9F,  0.95F,  1.0F,  1.05F,  1.15F,  1.35F,  1.45F }; 
    memcpy(EAEB_TTCCrossPed_Pref_v, EAEB_TTCCrossPed_Pref_v_force, sizeof(EAEB_TTCCrossPed_Pref_v_force));
    
    float EAEB_TTCCrossPed_Warn_v_force[10]  = { 
    1.25F,  1.2F,  1.2F,  1.2F,  1.25F,  1.3F,  1.35F,  1.45F,  1.5F,  1.6F }; 
    memcpy(EAEB_TTCCrossPed_Warn_v, EAEB_TTCCrossPed_Warn_v_force, sizeof(EAEB_TTCCrossPed_Warn_v_force));
    
    float EAEB_TTCCrossPed_LowB_v_force[10]  = { 
    0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  1.0F,  1.05F,  1.10F,  1.3F,  1.4F };  
    memcpy(EAEB_TTCCrossPed_LowB_v, EAEB_TTCCrossPed_LowB_v_force, sizeof(EAEB_TTCCrossPed_LowB_v_force));
    
    float EAEB_TTCCrossPed_HigB_v_force[10]  = { 
    0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  0.95F,  1.0F,  1.05F,  1.2F,  1.3F };  
    memcpy(EAEB_TTCCrossPed_HigB_v, EAEB_TTCCrossPed_HigB_v_force, sizeof(EAEB_TTCCrossPed_HigB_v_force));
    
    float EAEB_TTCRearCrossPed_Pref_v_force[10]  = { 
    1.55F,  1.5F,  1.5F,  1.5F,  1.55F,  1.6F,  1.65F,  1.75F,  1.9F,  2.0F };  
    memcpy(EAEB_TTCRearCrossPed_Pref_v, EAEB_TTCRearCrossPed_Pref_v_force, sizeof(EAEB_TTCRearCrossPed_Pref_v_force));
    
    float EAEB_TTCRearCrossPed_Warn_v_force[10]  = { 
    1.55F,  1.5F,  1.5F,  1.5F,  1.55F,  1.6F,  1.65F,  1.75F,  1.9F,  2.0F };  
    memcpy(EAEB_TTCRearCrossPed_Warn_v, EAEB_TTCRearCrossPed_Warn_v_force, sizeof(EAEB_TTCRearCrossPed_Warn_v_force));
    
    float EAEB_TTCRearCrossPed_LowB_v_force[10]  = { 
    1.35F,  1.3F,  1.3F,  0.95F,  1.0F,  1.0F,  1.2F,  1.35F,  1.5F,  1.6F };  
    memcpy(EAEB_TTCRearCrossPed_LowB_v, EAEB_TTCRearCrossPed_LowB_v_force, sizeof(EAEB_TTCRearCrossPed_LowB_v_force));
    
    float EAEB_TTCRearCrossPed_HigB_v_force[10]  = { 
    1.3F,  1.25F,  1.25F,  0.85F,  0.9F,  0.9F,  1.1F,  1.25F,  1.4F,  1.5F };  
    memcpy(EAEB_TTCRearCrossPed_HigB_v, EAEB_TTCRearCrossPed_HigB_v_force, sizeof(EAEB_TTCRearCrossPed_HigB_v_force));
    
    float EAEB_TTCCrossBik_Pref_v_force[10]  = { 
    0.9F,  0.85F,  0.9F,  0.9F,  0.95F,  1.0F,  1.05F,  1.15F,  1.35F,  1.45F };  
    memcpy(EAEB_TTCCrossBik_Pref_v, EAEB_TTCCrossBik_Pref_v_force, sizeof(EAEB_TTCCrossBik_Pref_v_force));
    
    float EAEB_TTCCrossBik_Warn_v_force[10]  = { 
    1.25F,  1.2F,  1.2F,  1.2F,  1.25F,  1.3F,  1.35F,  1.45F,  1.5F,  1.6F };  
    memcpy(EAEB_TTCCrossBik_Warn_v, EAEB_TTCCrossBik_Warn_v_force, sizeof(EAEB_TTCCrossBik_Warn_v_force));
    
    float EAEB_TTCCrossBik_LowB_v_force[10]  = { 
    0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  1.0F,  1.05F,  1.10F,  1.3F,  1.4F };  
    memcpy(EAEB_TTCCrossBik_LowB_v, EAEB_TTCCrossBik_LowB_v_force, sizeof(EAEB_TTCCrossBik_LowB_v_force));
    
    float EAEB_TTCCrossBik_HigB_v_force[10]  = { 
    0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  0.95F,  1.0F,  1.05F,  1.2F,  1.3F };  
    memcpy(EAEB_TTCCrossBik_HigB_v, EAEB_TTCCrossBik_HigB_v_force, sizeof(EAEB_TTCCrossBik_HigB_v_force));
    
    float EAEB_TTCOncomPed_Pref_v_force[10]  = { 
    0.7F,  0.6F,  0.65F,  0.7F,  0.8F,  0.9F,  1.1F,  1.2F,  1.2F,  1.2F };  
    memcpy(EAEB_TTCOncomPed_Pref_v, EAEB_TTCOncomPed_Pref_v_force, sizeof(EAEB_TTCOncomPed_Pref_v_force));
    
    float EAEB_TTCOncomPed_Warn_v_force[10]  = { 
    1.25F,  1.2F,  1.0F,  0.95F,  1.0F,  1.0F,  1.2F,  1.45F,  1.6F,  1.7F };  
    memcpy(EAEB_TTCOncomPed_Warn_v, EAEB_TTCOncomPed_Warn_v_force, sizeof(EAEB_TTCOncomPed_Warn_v_force));
    
    float EAEB_TTCOncomPed_LowB_v_force[10]  = { 
    0.5F,  0.4F,  0.45F,  0.5F,  0.6F,  0.7F,  0.9F,  1.0F,  1.0F,  1.0F };  
    memcpy(EAEB_TTCOncomPed_LowB_v, EAEB_TTCOncomPed_LowB_v_force, sizeof(EAEB_TTCOncomPed_LowB_v_force));
    
    float EAEB_TTCOncomPed_HigB_v_force[10]  = { 
    0.4F,  0.3F,  0.35F,  0.4F,  0.5F,  0.6F,  0.7F,  0.8F,  0.8F,  0.8F };  
    memcpy(EAEB_TTCOncomPed_HigB_v, EAEB_TTCOncomPed_HigB_v_force, sizeof(EAEB_TTCOncomPed_HigB_v_force));
    
    float EAEB_TTCOncomBik_Pref_v_force[10]  = { 
    0.7F,  0.6F,  0.65F,  0.7F,  0.8F,  0.9F,  1.1F,  1.2F,  1.2F,  1.2F };  
    memcpy(EAEB_TTCOncomBik_Pref_v, EAEB_TTCOncomBik_Pref_v_force, sizeof(EAEB_TTCOncomBik_Pref_v_force));
    
    float EAEB_TTCOncomBik_Warn_v_force[10]  = { 
    1.25F,  1.2F,  1.0F,  0.95F,  1.0F,  1.0F,  1.2F,  1.45F,  1.6F,  1.7F };  
    memcpy(EAEB_TTCOncomBik_Warn_v, EAEB_TTCOncomBik_Warn_v_force, sizeof(EAEB_TTCOncomBik_Warn_v_force));
    
    float EAEB_TTCOncomBik_LowB_v_force[10]  = { 
    0.5F,  0.4F,  0.45F,  0.5F,  0.6F,  0.7F,  0.9F,  1.0F,  1.0F,  1.0F };  
    memcpy(EAEB_TTCOncomBik_LowB_v, EAEB_TTCOncomBik_LowB_v_force, sizeof(EAEB_TTCOncomBik_LowB_v_force));
    
    float EAEB_TTCOncomBik_HigB_v_force[10]  = { 
    0.4F,  0.3F,  0.35F,  0.4F,  0.5F,  0.6F,  0.7F,  0.8F,  0.8F,  0.8F };  
    memcpy(EAEB_TTCOncomBik_HigB_v, EAEB_TTCOncomBik_HigB_v_force, sizeof(EAEB_TTCOncomBik_HigB_v_force));
    
    float EAEB_TTCPrecedPed_Pref_v_force[10]  = { 
    1.1F,  1.1F,  0.87F,  0.9F,  1.0F,  1.05F,  1.18F,  1.29F,  1.39F,  1.37F };  
    memcpy(EAEB_TTCPrecedPed_Pref_v, EAEB_TTCPrecedPed_Pref_v_force, sizeof(EAEB_TTCPrecedPed_Pref_v_force));
    
    float EAEB_TTCPrecedPed_Warn_v_force[10]  = { 
    1.2F,  1.18F,  1.1F,  1.1F,  1.15F,  1.25F,  1.3F,  1.5F,  1.75F,  1.75F };  
    memcpy(EAEB_TTCPrecedPed_Warn_v, EAEB_TTCPrecedPed_Warn_v_force, sizeof(EAEB_TTCPrecedPed_Warn_v_force));
    
    float EAEB_TTCPrecedPed_LowB_v_force[10]  = { 
    1.0F,  0.98F,  0.89F,  0.91F,  0.95F,  1.05F,  1.1F,  1.15F,  1.2F,  1.25F };  
    memcpy(EAEB_TTCPrecedPed_LowB_v, EAEB_TTCPrecedPed_LowB_v_force, sizeof(EAEB_TTCPrecedPed_LowB_v_force));
    
    float EAEB_TTCPrecedPed_HigB_v_force[10]  = { 
    0.8F,  0.78F,  0.69F,  0.71F,  0.8F,  0.9F,  0.9F,  0.95F,  1.05F,  1.15F };  
    memcpy(EAEB_TTCPrecedPed_HigB_v, EAEB_TTCPrecedPed_HigB_v_force, sizeof(EAEB_TTCPrecedPed_HigB_v_force));
    
    float EAEB_TTCPrecedBik_Pref_v_force[10]  = { 
    1.1F,  1.1F,  0.87F,  0.9F,  1.0F,  1.05F,  1.18F,  1.29F,  1.39F,  1.37F };  
    memcpy(EAEB_TTCPrecedBik_Pref_v, EAEB_TTCPrecedBik_Pref_v_force, sizeof(EAEB_TTCPrecedBik_Pref_v_force));
    
    float EAEB_TTCPrecedBik_Warn_v_force[10]  = { 
    1.2F,  1.18F,  1.1F,  1.1F,  1.15F,  1.25F,  1.3F,  1.5F,  1.75F,  1.75F };  
    memcpy(EAEB_TTCPrecedBik_Warn_v, EAEB_TTCPrecedBik_Warn_v_force, sizeof(EAEB_TTCPrecedBik_Warn_v_force));
    
    float EAEB_TTCPrecedBik_LowB_v_force[10]  = { 
    1.0F,  0.98F,  0.89F,  0.91F,  0.95F,  1.05F,  1.1F,  1.15F,  1.2F,  1.25F };  
    memcpy(EAEB_TTCPrecedBik_LowB_v, EAEB_TTCPrecedBik_LowB_v_force, sizeof(EAEB_TTCPrecedBik_LowB_v_force));
    
    float EAEB_TTCPrecedBik_HigB_v_force[10]  = { 
    0.8F,  0.78F,  0.69F,  0.71F,  0.8F,  0.9F,  0.9F,  0.95F,  1.05F,  1.15F };  
    memcpy(EAEB_TTCPrecedBik_HigB_v, EAEB_TTCPrecedBik_HigB_v_force, sizeof(EAEB_TTCPrecedBik_HigB_v_force));
    
    float EAEB_dstStatInFunnel_v_force[8]  = { 
    2.2F,  2.9F,  2.6F,  2.5F,  2.2F,  2.0F,  2.0F,  2.0F };  
    memcpy(EAEB_dstStatInFunnel_v, EAEB_dstStatInFunnel_v_force, sizeof(EAEB_dstStatInFunnel_v_force));
    
    float EAEB_dstMovInFunnel_v_force[8]  = { 
    2.2F,  2.9F,  2.6F,  2.5F,  2.2F,  2.0F,  2.0F,  2.0F };  
    memcpy(EAEB_dstMovInFunnel_v, EAEB_dstMovInFunnel_v_force, sizeof(EAEB_dstMovInFunnel_v_force));
    
    float EAEB_dstMovOutFunnel_v_force[8]  = { 
    2.8F,  3.6F,  3.6F,  3.6F,  3.6F,  3.6F,  3.2F,  2.8F };  
    memcpy(EAEB_dstMovOutFunnel_v, EAEB_dstMovOutFunnel_v_force, sizeof(EAEB_dstMovOutFunnel_v_force));
    
    float EAEB_TTCLowB_norm_v_force[144]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.5F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.75F,  0.75F,  0.7F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.9F,  0.9F,  0.85F,  0.8F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.1F,  1.1F,  1.0F,  0.95F,  0.9F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.25F,  1.25F,  1.15F,  1.1F,  1.02F,  0.96F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.25F,  1.2F,  1.1F,  1.05F,  
    0.0F,  0.0F,  0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
    0.0F,  0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
    0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
    0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
    1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
    1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F
    };  
    memcpy(EAEB_TTCLowB_norm_v, EAEB_TTCLowB_norm_v_force, sizeof(EAEB_TTCLowB_norm_v_force));
    
    float EAEB_TTCHighB_norm_v_force[144]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.3F,  0.45F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.7F,  0.7F,  0.6F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.85F,  0.85F,  0.75F,  0.65F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.05F,  1.05F,  0.9F,  0.8F,  0.7F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.15F,  1.15F,  1.05F,  0.95F,  0.9F,  0.8F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
    0.0F,  0.0F,  0.0F,  0.0F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
    0.0F,  0.0F,  0.0F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
    0.0F,  0.0F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
    0.0F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,   
    1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
    1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F 
    };  
    memcpy(EAEB_TTCHighB_norm_v, EAEB_TTCHighB_norm_v_force, sizeof(EAEB_TTCHighB_norm_v_force));
    
    float EAEB_TTCPrefill_norm_v_force[144]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.5F,  0.7F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.1F,  1.1F,  1.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.1F,  1.1F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.2F,  1.2F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.6F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    0.0F,  0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
    1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F 
    };  
    memcpy(EAEB_TTCPrefill_norm_v, EAEB_TTCPrefill_norm_v_force, sizeof(EAEB_TTCPrefill_norm_v_force));
    
    float EAEB_TTCWarn_norm_v_force[144]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.5F,  0.7F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.1F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.3F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.6F,  1.6F,  1.5F,  1.4F,  1.4F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.8F,  1.8F,  1.7F,  1.6F,  1.5F,  1.5F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.9F,  1.9F,  1.8F,  1.7F,  1.7F,  1.6F,  1.6F,  
    0.0F,  0.0F,  0.0F,  0.0F,  2.4F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  1.8F,  
    0.0F,  0.0F,  0.0F,  2.6F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  
    0.0F,  0.0F,  2.8F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  
    0.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  
    3.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  
    3.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F 
    };  
    memcpy(EAEB_TTCWarn_norm_v, EAEB_TTCWarn_norm_v_force, sizeof(EAEB_TTCWarn_norm_v_force));
    
    float EAEB_TTCWarn_addins_v_force[144]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCWarn_addins_v, EAEB_TTCWarn_addins_v_force, sizeof(EAEB_TTCWarn_addins_v_force));
    
    float EAEB_TTCLowB_decel_v_force[64]  = { 
    0.3F,  0.3F,  0.45F,  0.45F,  0.3F,  0.2F,  0.15F,  0.0F,  
    0.3F,  0.3F,  0.4F,  0.4F,  0.25F,  0.15F,  0.1F,  0.0F,  
    0.2F,  0.2F,  0.25F,  0.3F,  0.125F,  0.1F,  0.1F,  0.0F,  
    0.1F,  0.1F,  0.15F,  0.2F,  0.1F,  0.125F,  0.05F,  0.0F,  
    0.0F,  0.0F,  0.05F,  0.1F,  0.1F,  0.125F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCLowB_decel_v, EAEB_TTCLowB_decel_v_force, sizeof(EAEB_TTCLowB_decel_v_force));
    
    float EAEB_TTCHighB_decel_v_force[64]  = { 
    0.3F,  0.3F,  0.45F,  0.45F,  0.3F,  0.2F,  0.15F,  0.0F,  
    0.3F,  0.3F,  0.4F,  0.4F,  0.25F,  0.15F,  0.1F,  0.0F,  
    0.2F,  0.2F,  0.25F,  0.3F,  0.125F,  0.1F,  0.1F,  0.0F, 
    0.1F,  0.1F,  0.15F,  0.2F,  0.1F,  0.125F,  0.05F,  0.0F,  
    0.0F,  0.0F,  0.05F,  0.1F,  0.1F,  0.125F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCHighB_decel_v, EAEB_TTCHighB_decel_v_force, sizeof(EAEB_TTCHighB_decel_v_force));
    
    float EAEB_TTCPrefill_decel_v_force[64]  = { 
    0.45F,  0.45F,  0.4F,  0.4F,  0.35F,  0.3F,  0.3F,  0.0F,  
    0.35F,  0.35F,  0.3F,  0.3F,  0.25F,  0.2F,  0.2F,  0.0F,  
    0.3F,  0.3F,  0.25F,  0.25F,  0.25F,  0.2F,  0.2F,  0.0F,  
    0.25F,  0.25F,  0.2F,  0.2F,  0.2F,  0.2F,  0.2F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.2F,  0.2F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCPrefill_decel_v, EAEB_TTCPrefill_decel_v_force, sizeof(EAEB_TTCPrefill_decel_v_force));
    
    float EAEB_TTCWarn_decel_v_force[64]  = { 
    -0.1F,  -0.1F,  0.0F,  0.2F,  0.25F,  0.3F,  0.35F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.1F,  0.2F,  0.25F,  0.3F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.1F,  0.15F,  0.2F,  0.25F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.05F,  0.1F,  0.15F,  0.2F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.05F,  0.2F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    -0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCWarn_decel_v, EAEB_TTCWarn_decel_v_force, sizeof(EAEB_TTCWarn_decel_v_force));
    
    float EAEB_TTCWarn_deceladdins_v_force[64]  = { 
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
    0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
    };  
    memcpy(EAEB_TTCWarn_deceladdins_v, EAEB_TTCWarn_deceladdins_v_force, sizeof(EAEB_TTCWarn_deceladdins_v_force));
    
    float EAEB_tiFTAPwarn_TTC_v_force[8]  = { 
    0.95F,  1.05F,  1.2F,  1.35F,  1.35F,  1.35F,  1.35F,  1.35F }; 
    memcpy(EAEB_tiFTAPwarn_TTC_v, EAEB_tiFTAPwarn_TTC_v_force, sizeof(EAEB_tiFTAPwarn_TTC_v_force));
    
    float EAEB_tiFTAPpref_TTC_v_force[8]  = { 
    0.85F,  0.95F,  1.1F,  1.25F,  1.25F,  1.25F,  1.25F,  1.25F }; 
    memcpy(EAEB_tiFTAPpref_TTC_v, EAEB_tiFTAPpref_TTC_v_force, sizeof(EAEB_tiFTAPpref_TTC_v_force));
    
    float EAEB_tiFTAPlowB_TTC_v_force[8]  = { 
    0.7F,  0.8F,  0.95F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F }; 
    memcpy(EAEB_tiFTAPlowB_TTC_v, EAEB_tiFTAPlowB_TTC_v_force, sizeof(EAEB_tiFTAPlowB_TTC_v_force));
    
    float EAEB_tiFTAPhighB_TTC_v_force[8]  = { 
    0.7F,  0.75F,  0.9F,  1.05F,  1.05F,  1.05F,  1.05F,  1.05F }; 
    memcpy(EAEB_tiFTAPhighB_TTC_v, EAEB_tiFTAPhighB_TTC_v_force, sizeof(EAEB_tiFTAPhighB_TTC_v_force));

    //driver monitor
    float EAEB_Dm_Min_Brk_Ped_force                = 5.0;
    EAEB_Dm_Min_Brk_Ped = EAEB_Dm_Min_Brk_Ped_force;

    float EAEB_Dm_Fdb3_Hardbrk_Ped_force           = 30;
    EAEB_Dm_Fdb3_Hardbrk_Ped = EAEB_Dm_Fdb3_Hardbrk_Ped_force;

    uint8_t EAEB_Dm_Fdb3_Hardbrk_Age_force         = 10;
    EAEB_Dm_Fdb3_Hardbrk_Age = EAEB_Dm_Fdb3_Hardbrk_Age_force;

    float EAEB_Dm_Fdb3_Hardbrk_AccThres_force      = -4.99;
    EAEB_Dm_Fdb3_Hardbrk_AccThres = EAEB_Dm_Fdb3_Hardbrk_AccThres_force;

    float EAEB_Dm_Fdb2_Hardbrk_Ped_force           = 10;
    EAEB_Dm_Fdb2_Hardbrk_Ped = EAEB_Dm_Fdb2_Hardbrk_Ped_force;

    uint8_t EAEB_Dm_Fdb2_Hardbrk_Age_force         = 5;
    EAEB_Dm_Fdb2_Hardbrk_Age = EAEB_Dm_Fdb2_Hardbrk_Age_force;

    float EAEB_Dm_Fb1_DrvMod_force[5]              = {0,  1,  2,  3,  4};
    memcpy(EAEB_Dm_Fb1_DrvMod, EAEB_Dm_Fb1_DrvMod_force, sizeof(EAEB_Dm_Fb1_DrvMod_force));

    float EAEB_Dm_Fdb1_High_Ped_force[5]           = {90.0,  90.0,  88.0,  85.0,  85.0};
    memcpy(EAEB_Dm_Fdb1_High_Ped, EAEB_Dm_Fdb1_High_Ped_force, sizeof(EAEB_Dm_Fdb1_High_Ped_force));

    float EAEB_Dm_Fdb1_Low_Ped_force[5]            = {40.0,  40.0,  38.0,  35.0,  35.0};
    memcpy(EAEB_Dm_Fdb1_Low_Ped, EAEB_Dm_Fdb1_Low_Ped_force, sizeof(EAEB_Dm_Fdb1_Low_Ped_force));

    float EAEB_Dm_Fdb1_Low_Grad_force[5]           = {250.0, 250.0, 250.0, 250.0, 250.0};
    memcpy(EAEB_Dm_Fdb1_Low_Grad, EAEB_Dm_Fdb1_Low_Grad_force, sizeof(EAEB_Dm_Fdb1_Low_Grad_force));

    uint8_t EAEB_Dm_Fdb1_Hardacc_Age_force         = 20;
    EAEB_Dm_Fdb1_Hardacc_Age = EAEB_Dm_Fdb1_Hardacc_Age_force;

    float EAEB_Dm_Fdb1_Time_force                  = 0.5;
    EAEB_Dm_Fdb1_Time = EAEB_Dm_Fdb1_Time_force;

    float EAEB_Dm_Fdb2_Time_force                  = 0.5;
    EAEB_Dm_Fdb2_Time = EAEB_Dm_Fdb2_Time_force;

    float EAEB_Dm_Fdb3_Time_force                  = 0.2;
    EAEB_Dm_Fdb3_Time = EAEB_Dm_Fdb3_Time_force;

    float EAEB_Dm_Act1Grad_Vx_x_force[2]           = {1.38, 16.67};
    memcpy(EAEB_Dm_Act1Grad_Vx_x, EAEB_Dm_Act1Grad_Vx_x_force, sizeof(EAEB_Dm_Act1Grad_Vx_x_force));

    float EAEB_Dm_Act1Grad_StrGrad_y_force[2]      = {45, 20.0};
    memcpy(EAEB_Dm_Act1Grad_StrGrad_y, EAEB_Dm_Act1Grad_StrGrad_y_force, sizeof(EAEB_Dm_Act1Grad_StrGrad_y_force));

    float EAEB_Dm_Act2Ang_Vx_x_force[8]            = {1.39,   2.78,   4.17,   5.56,   6.94,   8.33,   9.72,   11.11};
    memcpy(EAEB_Dm_Act2Ang_Vx_x, EAEB_Dm_Act2Ang_Vx_x_force, sizeof(EAEB_Dm_Act2Ang_Vx_x_force));

    float EAEB_Dm_Act2Ang_StrAng_y_force[8]        = {260.0,  250.0,  200.0,  190.0,  180.0,  150.0,  140.0,  120.0};
    memcpy(EAEB_Dm_Act2Ang_StrAng_y, EAEB_Dm_Act2Ang_StrAng_y_force, sizeof(EAEB_Dm_Act2Ang_StrAng_y_force));

    float EAEB_Dm_Act2Grad_Vx_x_force[2]           = {5.0, 15.0};
    memcpy(EAEB_Dm_Act2Grad_Vx_x, EAEB_Dm_Act2Grad_Vx_x_force, sizeof(EAEB_Dm_Act2Grad_Vx_x_force));

    float EAEB_Dm_Act2Grad_StrGrad_y_force[2]      = {200.0, 100.0}; 
    memcpy(EAEB_Dm_Act2Grad_StrGrad_y, EAEB_Dm_Act2Grad_StrGrad_y_force, sizeof(EAEB_Dm_Act2Grad_StrGrad_y_force));

    float EAEB_Dm_Act3Grad_Vx_x_force[2]           = {0.0, 15.0};
    memcpy(EAEB_Dm_Act3Grad_Vx_x, EAEB_Dm_Act3Grad_Vx_x_force, sizeof(EAEB_Dm_Act3Grad_Vx_x_force));

    float EAEB_Dm_Act3Grad_StrGrad_y_force[2]      = {1000.0, 400.0}; 
    memcpy(EAEB_Dm_Act3Grad_StrGrad_y, EAEB_Dm_Act3Grad_StrGrad_y_force, sizeof(EAEB_Dm_Act3Grad_StrGrad_y_force));

    float EAEB_Dm_Act1_Time_force                  = 1.0;
    EAEB_Dm_Act1_Time = EAEB_Dm_Act1_Time_force;

    float EAEB_Dm_Act2_Time_Low_force              = 0.5;
    EAEB_Dm_Act2_Time_Low = EAEB_Dm_Act2_Time_Low_force;

    float EAEB_Dm_Act2_Time_High_force             = 2.0;
    EAEB_Dm_Act2_Time_High = EAEB_Dm_Act2_Time_High_force;

    float EAEB_Dm_Act3_Time_force                  = 1.0;
    EAEB_Dm_Act3_Time = EAEB_Dm_Act3_Time_force;

    float EAEB_Dm_Fo3_Hardbrk_Ped_force            = 15.0;
    EAEB_Dm_Fo3_Hardbrk_Ped = EAEB_Dm_Fo3_Hardbrk_Ped_force;

    uint8_t EAEB_Dm_Fo3_Hardbrk_Age_force          = 10;
    EAEB_Dm_Fo3_Hardbrk_Age = EAEB_Dm_Fo3_Hardbrk_Age_force;

    float EAEB_Dm_Foc1_High_Grad_force             = 150.0;
    EAEB_Dm_Foc1_High_Grad = EAEB_Dm_Foc1_High_Grad_force;

    float EAEB_Dm_Foc1_Low_Grad_force              = -180.0;
    EAEB_Dm_Foc1_Low_Grad = EAEB_Dm_Foc1_Low_Grad_force;

    float EAEB_Dm_Foc1_Mid_Ped_force               = 1.0;
    EAEB_Dm_Foc1_Mid_Ped = EAEB_Dm_Foc1_Mid_Ped_force;

    float EAEB_Dm_Foc1_Mid_Grad_force              = -4.0;
    EAEB_Dm_Foc1_Mid_Grad = EAEB_Dm_Foc1_Mid_Grad_force;

    float EAEB_Dm_Foc1_Str_Grad_force              = 100.0;
    EAEB_Dm_Foc1_Str_Grad = EAEB_Dm_Foc1_Str_Grad_force;

    float EAEB_Dm_Foc2_Min_Velx_force              = 13.89;
    EAEB_Dm_Foc2_Min_Velx = EAEB_Dm_Foc2_Min_Velx_force;

    float EAEB_Dm_Foc2Ped_Vx_x_force[2]            = {25, 45};
    memcpy(EAEB_Dm_Foc2Ped_Vx_x, EAEB_Dm_Foc2Ped_Vx_x_force, sizeof(EAEB_Dm_Foc2Ped_Vx_x_force));

    float EAEB_Dm_Foc2Ped_Ped_y_force[2]           = {40.0, 80.0};
    memcpy(EAEB_Dm_Foc2Ped_Ped_y, EAEB_Dm_Foc2Ped_Ped_y_force, sizeof(EAEB_Dm_Foc2Ped_Ped_y_force));

    float EAEB_Dm_Foc3_Max_Velx_force              = 16.67;
    EAEB_Dm_Foc3_Max_Velx = EAEB_Dm_Foc3_Max_Velx_force;

    float EAEB_Dm_Foc3_Max_Ax_force                = -1.2;
    EAEB_Dm_Foc3_Max_Ax = EAEB_Dm_Foc3_Max_Ax_force;

    float EAEB_Dm_Foc4Ax_Vx_x_force[7]             = {5.56, 11.11, 16.67, 22.22, 27.78, 33.33, 38.89};
    memcpy(EAEB_Dm_Foc4Ax_Vx_x, EAEB_Dm_Foc4Ax_Vx_x_force, sizeof(EAEB_Dm_Foc4Ax_Vx_x_force));

    float EAEB_Dm_Foc4Ax_Ax_y_force[7]             = {-3.0, -2.8,  -2.5,  -2.3,  -2.0,  -1.9, -1.8}; 
    memcpy(EAEB_Dm_Foc4Ax_Ax_y, EAEB_Dm_Foc4Ax_Ax_y_force, sizeof(EAEB_Dm_Foc4Ax_Ax_y_force));

    float EAEB_Dm_Foc1_Time_force                  = 2.5;
    EAEB_Dm_Foc1_Time = EAEB_Dm_Foc1_Time_force;

    float EAEB_Dm_Foc2_Time_force                  = 1.0;
    EAEB_Dm_Foc2_Time = EAEB_Dm_Foc2_Time_force;

    float EAEB_Dm_Foc3_Time_force                  = 0.5;
    EAEB_Dm_Foc3_Time = EAEB_Dm_Foc3_Time_force;

    float EAEB_Dm_Foc4_Time_force                  = 0.5;
    EAEB_Dm_Foc4_Time = EAEB_Dm_Foc4_Time_force;

    float EAEB_Dm_Ccftap_Max_Vel_force             = 11.11;
    EAEB_Dm_Ccftap_Max_Vel = EAEB_Dm_Ccftap_Max_Vel_force;

    float EAEB_Dm_Ccftap_Min_Yawrate_force         = 0.1;
    EAEB_Dm_Ccftap_Min_Yawrate = EAEB_Dm_Ccftap_Min_Yawrate_force;

    float EAEB_Dm_Ccftap_Max_StrAng_force          = 300.0;
    EAEB_Dm_Ccftap_Max_StrAng = EAEB_Dm_Ccftap_Max_StrAng_force;

    float EAEB_Dm_Fwd_Max_Vel_force                = 41.7;
    EAEB_Dm_Fwd_Max_Vel = EAEB_Dm_Fwd_Max_Vel_force;

    float EAEB_Dm_Fwd_Min_Vel_force                = 1.11;
    EAEB_Dm_Fwd_Min_Vel =EAEB_Dm_Fwd_Min_Vel_force;

    float EAEB_Dm_Bwd_Max_Vel_force                = -0.83;
    EAEB_Dm_Bwd_Max_Vel = EAEB_Dm_Bwd_Max_Vel_force;

    float EAEB_Dm_Bwd_Min_Vel_force                = -4.17;
    EAEB_Dm_Bwd_Min_Vel = EAEB_Dm_Bwd_Min_Vel_force;

    float EAEB_Dm_Static_Vel_force                 = 0.25;
    EAEB_Dm_Static_Vel = EAEB_Dm_Static_Vel_force;

    float EAEB_Dm_Min_Acc_GasPed_force             = 8.0;
    EAEB_Dm_Min_Acc_GasPed = EAEB_Dm_Min_Acc_GasPed_force;

    float EAEB_Dm_Sdy_Gasgrad_force                = 10.0;
    EAEB_Dm_Sdy_Gasgrad = EAEB_Dm_Sdy_Gasgrad_force;

    float EAEB_Dm_Vel_Dev_Thres_force              = 0.5;
    EAEB_Dm_Vel_Dev_Thres = EAEB_Dm_Vel_Dev_Thres_force;

    float EAEB_Dm_Sdy_Time_force                   = 5.0;
    EAEB_Dm_Sdy_Time = EAEB_Dm_Sdy_Time_force;

    float EAEB_Dm_Ramp_Time_force                  = 2.0;
    EAEB_Dm_Ramp_Time = EAEB_Dm_Ramp_Time_force;

    bool  EAEB_Dm_SdyDetect_Switch_force           = false;
    EAEB_Dm_SdyDetect_Switch = EAEB_Dm_SdyDetect_Switch_force;

    float EAEB_Dm_Foc1_DampFactor_force[32]        = {
    1.0,  0.85,  0.9,  0.9,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    };
    memcpy(EAEB_Dm_Foc1_DampFactor, EAEB_Dm_Foc1_DampFactor_force, sizeof(EAEB_Dm_Foc1_DampFactor_force));

    float EAEB_Dm_Foc2_DampFactor_force[32]        = {
    1.0,  0.5,   0.75, 0.8,  1.0,  1.0,  0.8,  0.75,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    };
    memcpy(EAEB_Dm_Foc2_DampFactor, EAEB_Dm_Foc2_DampFactor_force, sizeof(EAEB_Dm_Foc2_DampFactor_force));

    float EAEB_Dm_Foc3_DampFactor_force[32]        = {
    1.0,  0.4,   0.65, 0.8,  1.0,  1.0,  0.7,  0.65,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    };
    memcpy(EAEB_Dm_Foc3_DampFactor, EAEB_Dm_Foc3_DampFactor_force, sizeof(EAEB_Dm_Foc3_DampFactor_force));

    float EAEB_Dm_Foc4_DampFactor_force[32]        = {
    1.0,  0.4,   0.65, 0.6,  1.0,  1.0,  0.6,  0.65,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
    };
    memcpy(EAEB_Dm_Foc4_DampFactor, EAEB_Dm_Foc4_DampFactor_force, sizeof(EAEB_Dm_Foc4_DampFactor_force));

    bool    kAebRearEnable_force          = true;
    kAebRearEnable = kAebRearEnable_force;

    float EAEB_dmsteer_egospd_x_force[12]  = { 
    2.78F,  5.56F,  8.33F,  11.11F,  13.89F,  16.67F,  19.44F,  22.22F, 25.0F, 27.78F, 30.56F, 33.33F };
    memcpy(EAEB_dmsteer_egospd_x, EAEB_dmsteer_egospd_x_force, sizeof(EAEB_dmsteer_egospd_x_force));

    float EAEB_dmsteer_stwangle_v_force[12]  = { 
    150.0F,  100.0F,  75.0F,  50.0F,  50.0F,  50.0F,  50.0F,  50.0F, 50.0F, 50.0F, 40.0F, 40.0F };  
    memcpy(EAEB_dmsteer_stwangle_v, EAEB_dmsteer_stwangle_v_force, sizeof(EAEB_dmsteer_stwangle_v_force));
    

    float EAEB_dmsteer_yawrate_v_force[12]  = { 
    0.1F,  0.15F,  0.20F,  0.28F,  0.35F,  0.42F,  0.5F,  0.56F, 0.65F, 0.7F, 0.77F, 0.85F };  
    memcpy(EAEB_dmsteer_yawrate_v, EAEB_dmsteer_yawrate_v_force, sizeof(EAEB_dmsteer_yawrate_v_force));
    

    float EAEB_overtake_steerangle_v_force[12]  = { 
    80.0F,  35.0F,  28.0F,  25.0F,  20.0F,  17.0F,  15.0F,  12.0F,  10.0F,  8.0F,  8.0F,  8.0F };  
    memcpy(EAEB_overtake_steerangle_v, EAEB_overtake_steerangle_v_force, sizeof(EAEB_overtake_steerangle_v_force));
    


    float EAEB_overtake_gasped_v_force[12]  = { 
    30.0F,  20.0F,  15.0F,  15.0F,  15.0F,  15.0F,  15.0F,  20.0F,  20.0F,  20.0F,  20.0F,  20.0F };  
    memcpy(EAEB_overtake_gasped_v, EAEB_overtake_gasped_v_force, sizeof(EAEB_overtake_gasped_v_force));
}

