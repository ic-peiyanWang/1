#include "aeb_calibration.h"

CAL_VAR float EAEB_tiTTC_EgoVel_x[5]  = { 
2.78F,  8.33F,  13.89F,  22.5F,  33.33F };
CAL_VAR float EAEB_tiTTC_RelVel_y[5]  = { 
2.78F,  8.33F,  13.89F,  22.5F,  33.33F };
CAL_VAR float EAEB_tiTTC_B_v[25]  = { 
1.0F,  1.2F,  1.5F,  1.6F,  1.3F,  
1.0F,  1.2F,  1.5F,  1.6F,  1.3F,  
1.05F,  1.3F,  1.5F,  1.6F,  1.3F,  
1.05F,  1.3F,  1.5F,  1.6F,  1.3F,  
1.0F,  1.2F,  1.4F,  1.6F,  1.3F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_tiTTC_EgoVel_x ; @ref_axis_y : EAEB_tiTTC_RelVel_y ;
CAL_VAR float EAEB_tiTTC_D_v[25]  = { 
1.0F,  1.2F,  1.5F,  1.6F,  1.3F,  
1.0F,  1.2F,  1.5F,  1.6F,  1.3F,  
1.05F,  1.3F,  1.5F,  1.6F,  1.3F,  
1.05F,  1.3F,  1.5F,  1.6F,  1.3F,  
1.0F,  1.2F,  1.4F,  1.6F,  1.3F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_tiTTC_EgoVel_x ; @ref_axis_y : EAEB_tiTTC_RelVel_y ;
CAL_VAR float EAEB_tiTTC_E_v[25]  = { 
1.0F,  1.1F,  1.3F,  1.4F,  1.0F,  
1.0F,  1.1F,  1.3F,  1.4F,  1.0F,  
1.0F,  1.1F,  1.3F,  1.4F,  1.0F,  
1.0F,  1.1F,  1.3F,  1.4F,  1.0F,  
1.0F,  1.1F,  1.2F,  1.25F,  1.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_tiTTC_EgoVel_x ; @ref_axis_y : EAEB_tiTTC_RelVel_y ;
CAL_VAR float EAEB_tiOverlapOfs_Overlap_x[5]  = { 
1.4F,  1.0F,  0.56F,  0.55F,  0.3F };
CAL_VAR float EAEB_tiOverlapOfs_RelVel_y[5]  = { 
1.39F,  2.5F,  22.5F,  25.0F,  27.78F };
CAL_VAR float EAEB_tiOverlapOfs_v[25]  = { 
2.0F,  2.0F,  2.0F,  2.0F,  2.0F,  
0.3F,  0.3F,  0.3F,  0.7F,  0.9F,  
0.0F,  0.0F,  0.0F,  0.4F,  0.5F,  
0.0F,  0.0F,  0.0F,  0.2F,  0.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_tiOverlapOfs_Overlap_x ; @ref_axis_y : EAEB_tiOverlapOfs_RelVel_y ;
CAL_VAR float EAEB_tiBrkOfs_EgoAcc_x[3]  = { 
-2.5F,  -1.0F,  0.0F };
CAL_VAR float EAEB_tiBrkOfs_v[3]  = { 
0.6F,  0.3F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiBrkOfs_EgoAcc_x ;
CAL_VAR float EAEB_tiTTCPedL1_EgoSpd_x[4]  = { 
2.77778F,  5.55556F,  8.33333F,  16.6666F };
CAL_VAR float EAEB_tiTTCPedL1_v[4]  = { 
1.0F,  1.1F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL1_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCPedNightL1_v[4]  = { 
1.0F,  1.1F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL1_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleL1_EgoSpd_x[4]  = { 
2.77778F,  5.55556F,  8.33333F,  16.6666F };
CAL_VAR float EAEB_tiTTCBicycleL1_v[4]  = { 
1.0F,  1.1F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL1_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleNightL1_v[4]  = { 
1.0F,  1.1F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL1_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCPedL2_EgoSpd_x[4]  = { 
2.5F,  4.16666F,  5.55556F,  16.6666F };
CAL_VAR float EAEB_tiTTCPedL2_v[4]  = { 
1.0F,  1.2F,  1.4F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL2_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCPedNightL2_v[4]  = { 
1.0F,  1.0F,  1.4F,  1.4F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL2_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleL2_EgoSpd_x[4]  = { 
2.5F,  4.16666F,  5.55556F,  16.6666F };
CAL_VAR float EAEB_tiTTCBicycleL2_v[4]  = { 
1.0F,  1.2F,  1.4F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL2_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleNightL2_v[4]  = { 
1.0F,  1.0F,  1.4F,  1.4F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL2_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCPedL3_EgoSpd_x[4]  = { 
2.5F,  4.16666F,  5.55556F,  16.6666F };
CAL_VAR float EAEB_tiTTCPedL3_v[4]  = { 
1.4F,  1.6F,  1.8F,  1.9F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL3_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCPedNightL3_v[4]  = { 
1.4F,  1.4F,  1.8F,  1.8F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCPedL3_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleL3_EgoSpd_x[4]  = { 
2.5F,  4.16666F,  5.55556F,  16.6666F };
CAL_VAR float EAEB_tiTTCBicycleL3_v[4]  = { 
1.4F,  1.6F,  1.8F,  1.9F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL3_EgoSpd_x ;
CAL_VAR float EAEB_tiTTCBicycleNightL3_v[4]  = { 
1.4F,  1.4F,  1.8F,  1.8F }; //@ctype : CURVE ; @ref_axis_x : EAEB_tiTTCBicycleL3_EgoSpd_x ;
CAL_VAR float EAEB_dstSide_EgoSpd_x[2]  = { 
0.0F,  30.0F };
CAL_VAR float EAEB_dstCurrSidePedL1_v[2]  = { 
0.2F,  0.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstPredSidePedL1_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstSideBicycleL1_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandPedL1_v[2]  = { 
2.2F,  2.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandBicycleL1_v[2]  = { 
5.5F,  5.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCurrSidePedL2_v[2]  = { 
0.5F,  0.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstPredSidePedL2_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstSideBicycleL2_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandPedL2_v[2]  = { 
2.5F,  2.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandBicycleL2_v[2]  = { 
5.5F,  5.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCurrSidePedL3_v[2]  = { 
0.5F,  0.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstPredSidePedL3_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstSideBicycleL3_v[2]  = { 
0.1F,  0.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandPedL3_v[2]  = { 
2.5F,  2.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstCrossExpandBicycleL3_v[2]  = { 
5.5F,  5.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstSide_EgoSpd_x ;
CAL_VAR float EAEB_dstVFcheck_LongPos_x[9]  = { 
0.0F,  3.0F,  5.0F,  10.0F,  15.0F,  20.0F,  30.0F,  40.0F,  50.0F };
CAL_VAR float EAEB_dstVFcheck_LatPos_v[9]  = { 
1.0F,  0.6F,  0.4F,  0.35F,  0.35F,  0.35F,  0.45F,  0.5F,  0.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstVFcheck_LongPos_x ;
CAL_VAR float EAEB_spdVFcheck_LatVel_v[9]  = { 
1.0F,  0.6F,  0.4F,  0.35F,  0.35F,  0.35F,  0.45F,  0.5F,  0.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstVFcheck_LongPos_x ;
CAL_VAR float EAEB_spdLongMove_LongVel_v[9]  = { 
0.6F,  0.6F,  0.5F,  0.5F,  0.6F,  0.8F,  1.0F,  1.4F,  1.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstVFcheck_LongPos_x ;
CAL_VAR float EAEB_spdLatMove_LatVel_v[9]  = { 
0.9F,  0.8F,  0.7F,  0.7F,  0.7F,  0.8F,  1.0F,  1.4F,  1.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstVFcheck_LongPos_x ;
CAL_VAR uint8_t EAEB_agecheck_AEBconf_x[4]  = { 
0U,  1U,  2U,  3U };
CAL_VAR uint8_t EAEB_agelongmove_ageplau_v[4]  = { 
199U,  50U,  30U,  20U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agecross_ageplau_v[4]  = { 
199U,  10U,  4U,  2U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agelongmove_age_v[4]  = { 
254U,  120U,  70U,  40U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agecross_age_v[4]  = { 
254U,  254U,  30U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agecross_age_turn_v[4]  = { 
254U,  254U,  60U,  20U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agelongmove_age_warn_v[4]  = { 
254U,  100U,  55U,  35U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agecross_age_warn_v[4]  = { 
254U,  25U,  20U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_agecross_age_turn_warn_v[4]  = { 
254U,  254U,  60U,  20U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR float EAEB_spdSide_hostspd_x[8]  = { 
1.5F,  2.78F,  4.16F,  5.55F,  6.95F,  8.33F,  11.11F,  13.88F };
CAL_VAR float EAEB_disSide_range_y[8]  = { 
0.0F,  5.0F,  10.0F,  15.0F,  20.0F,  30.0F,  40.0F,  50.0F };
CAL_VAR float EAEB_dstPredLongPedBik_v[64]  = { 
0.8F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.85F,  0.75F,  0.6F,  0.6F,  0.6F,  0.55F,  0.5F,  0.5F,  
0.9F,  0.8F,  0.7F,  0.65F,  0.65F,  0.55F,  0.5F,  0.5F,  
0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  
0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
0.8F,  0.75F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F,  
0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredCrossPedBik_v[64]  = { 
0.8F,  0.75F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.85F,  0.8F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  
0.8F,  0.8F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.65F,  0.6F,  0.5F,  
0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.6F,  0.5F,  
0.75F,  0.75F,  0.8F,  0.7F,  0.7F,  0.65F,  0.6F,  0.5F,  
0.7F,  0.7F,  0.85F,  0.8F,  0.75F,  0.75F,  0.65F,  0.5F,  
0.7F,  0.7F,  0.7F,  0.75F,  0.8F,  0.8F,  0.7F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredStatPedBik_v[64]  = { 
0.75F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.75F,  0.6F,  0.6F,  0.6F,  0.55F,  0.5F,  0.5F,  
0.85F,  0.8F,  0.7F,  0.65F,  0.65F,  0.55F,  0.5F,  0.5F,  
0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  
0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
0.8F,  0.75F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  
0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F,  
0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrLongPedBik_v[64]  = { 
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.75F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrCrossPedBik_v[64]  = { 
2.0F,  1.9F,  1.9F,  1.9F,  1.8F,  1.8F,  1.6F,  1.35F,  
2.0F,  1.9F,  1.9F,  1.9F,  1.8F,  1.8F,  1.6F,  1.35F,  
2.2F,  2.1F,  2.1F,  2.0F,  1.9F,  1.9F,  1.7F,  1.35F,  
2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  1.9F,  1.7F,  1.35F,  
2.3F,  2.3F,  2.15F,  2.1F,  2.0F,  2.0F,  1.9F,  1.35F,  
2.3F,  2.4F,  2.3F,  2.2F,  2.2F,  2.2F,  2.0F,  1.35F,  
2.3F,  2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  2.1F,  1.35F,  
2.2F,  2.5F,  2.5F,  2.75F,  2.75F,  2.75F,  2.1F,  1.35F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrStatPedBik_v[64]  = { 
0.60F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.65F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.7F,  0.7F,  0.63F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.75F,  0.65F,  0.55F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.77F,  0.68F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.78F,  0.7F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.8F,  0.73F,  0.65F,  0.6F,  0.5F,  0.5F,  0.5F,  
0.8F,  0.8F,  0.75F,  0.7F,  0.65F,  0.6F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredLongPedBik_warn_v[64]  = { 
0.8F,  0.7F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
0.85F,  0.75F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  0.55F,  
0.9F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
0.9F,  0.85F,  0.75F,  0.7F,  0.65F,  0.65F,  0.55F,  0.55F,  
0.85F,  0.8F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
0.8F,  0.75F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  
0.7F,  0.65F,  0.65F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredCrossPedBik_warn_v[64]  = { 
0.8F,  0.75F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
0.85F,  0.8F,  0.75F,  0.65F,  0.65F,  0.65F,  0.65F,  0.55F,  
0.8F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.65F,  0.55F,  
0.75F,  0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  
0.75F,  0.75F,  0.75F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  
0.75F,  0.75F,  0.7F,  0.7F,  0.7F,  0.65F,  0.6F,  0.55F,  
0.7F,  0.7F,  0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.5F,  
0.7F,  0.7F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredStatPedBik_warn_v[64]  = { 
0.8F,  0.7F,  0.65F,  0.55F,  0.55F,  0.55F,  0.55F,  0.55F,  
0.85F,  0.75F,  0.65F,  0.65F,  0.65F,  0.6F,  0.55F,  0.55F,  
0.9F,  0.8F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
0.9F,  0.85F,  0.75F,  0.7F,  0.7F,  0.65F,  0.55F,  0.55F,  
0.85F,  0.8F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
0.8F,  0.75F,  0.75F,  0.7F,  0.65F,  0.65F,  0.65F,  0.55F,  
0.75F,  0.7F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.55F,  
0.7F,  0.65F,  0.65F,  0.65F,  0.6F,  0.6F,  0.55F,  0.55F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrLongPedBik_warn_v[64]  = { 
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrCrossPedBik_warn_v[64]  = { 
2.2F,  2.2F,  2.1F,  2.1F,  2.0F,  2.0F,  1.8F,  1.55F,  
2.2F,  2.1F,  2.1F,  2.1F,  2.0F,  2.0F,  1.8F,  1.55F,  
2.4F,  2.3F,  2.3F,  2.2F,  2.1F,  2.1F,  1.9F,  1.55F,  
2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.1F,  1.9F,  1.55F,  
2.5F,  2.5F,  2.35F,  2.3F,  2.2F,  2.2F,  2.1F,  1.55F,  
2.5F,  2.6F,  2.5F,  2.4F,  2.4F,  2.4F,  2.2F,  1.55F,  
2.5F,  2.7F,  2.7F,  2.7F,  2.7F,  2.7F,  2.3F,  1.55F,  
2.4F,  2.7F,  2.7F,  2.85F,  2.85F,  2.85F,  2.3F,  1.55F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrStatPedBik_warn_v[64]  = { 
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F,  
0.85F,  0.85F,  0.8F,  0.75F,  0.7F,  0.6F,  0.6F,  0.6F  
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdSide_hostspd_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_spdExpand_Latvel_x[5]  = { 
1.6F,  2.2F,  4.0F,  6.0F,  8.0F };
CAL_VAR float EAEB_dstPredExpandSide_v[40]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
0.1F,  0.2F,  0.2F,  0.2F,  0.2F,  
0.2F,  0.2F,  0.2F,  0.2F,  0.4F,  
0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.4F,  0.2F,  0.4F,  0.6F,  0.6F,  
0.6F,  0.6F,  0.6F,  0.4F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrExpandSide_v[40]  = { 
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  1.0F,  1.0F,  
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  
1.0F,  1.5F,  2.0F,  2.0F,  2.0F,  
2.0F,  1.5F,  1.0F,  0.5F,  1.5F,  
2.0F,  2.0F,  2.0F,  2.0F,  1.5F,  
1.0F,  0.5F,  1.5F,  2.0F,  2.0F,  
2.0F,  2.0F,  1.5F,  1.0F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredExpandSide_warn_v[40]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.2F,  0.2F,  0.2F,  0.2F,  
0.2F,  0.2F,  0.2F,  0.2F,  0.4F,  
0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.4F,  0.2F,  0.4F,  0.6F,  0.6F,  
0.6F,  0.6F,  0.6F,  0.4F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrExpandSide_warn_v[40]  = { 
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  1.0F,  1.0F,  
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  
1.0F,  1.5F,  2.0F,  2.0F,  2.0F,  
2.0F,  1.5F,  1.0F,  0.5F,  1.5F,  
2.0F,  2.0F,  2.0F,  2.0F,  1.5F,  
1.0F,  0.5F,  1.5F,  2.0F,  2.0F,  
2.0F,  2.0F,  1.5F,  1.0F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredExpandSide_Bik_v[40]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
0.1F,  0.3F,  0.3F,  0.3F,  0.3F,  
0.3F,  0.3F,  0.3F,  0.3F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrExpandSide_Bik_v[40]  = { 
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  1.5F,  1.5F,  
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  
1.5F,  4.0F,  4.0F,  4.0F,  4.0F,  
5.0F,  5.0F,  4.0F,  4.0F,  5.0F,  
5.0F,  5.0F,  5.0F,  6.0F,  6.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstPredExpandSide_Bik_warn_v[40]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  
0.1F,  0.1F,  0.1F,  0.1F,  0.1F,  
0.1F,  0.3F,  0.3F,  0.3F,  0.3F,  
0.3F,  0.3F,  0.3F,  0.3F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_dstCurrExpandSide_Bik_warn_v[40]  = { 
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.5F,  0.5F,  0.5F,  1.5F,  1.5F,  
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  
1.5F,  4.0F,  4.0F,  4.0F,  4.0F,  
4.0F,  4.0F,  4.0F,  4.0F,  5.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdExpand_Latvel_x ; @ref_axis_y : EAEB_disSide_range_y ;
CAL_VAR float EAEB_TTCPedBik_Egospd_x[10]  = { 
1.5F,  2.78F,  4.16F,  5.55F,  6.95F,  8.33F,  9.5F,  11.11F,  13.88F,  16.66F };
CAL_VAR float EAEB_TTCCrossPed_Pref_v[10]  = { 
0.9F,  0.85F,  0.9F,  0.9F,  0.95F,  1.0F,  1.05F,  1.15F,  1.35F,  1.45F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossPed_Warn_v[10]  = { 
1.25F,  1.2F,  1.2F,  1.2F,  1.25F,  1.3F,  1.35F,  1.45F,  1.5F,  1.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossPed_LowB_v[10]  = { 
0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  1.0F,  1.05F,  1.10F,  1.3F,  1.4F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossPed_HigB_v[10]  = { 
0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  0.95F,  1.0F,  1.05F,  1.2F,  1.3F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCRearCrossPed_Pref_v[10]  = { 
1.55F,  1.5F,  1.5F,  1.5F,  1.55F,  1.6F,  1.65F,  1.75F,  1.9F,  2.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCRearCrossPed_Warn_v[10]  = { 
1.55F,  1.5F,  1.5F,  1.5F,  1.55F,  1.6F,  1.65F,  1.75F,  1.9F,  2.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCRearCrossPed_LowB_v[10]  = { 
1.35F,  1.3F,  1.3F,  0.95F,  1.0F,  1.0F,  1.2F,  1.35F,  1.5F,  1.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCRearCrossPed_HigB_v[10]  = { 
1.3F,  1.25F,  1.25F,  0.85F,  0.9F,  0.9F,  1.1F,  1.25F,  1.4F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossBik_Pref_v[10]  = { 
0.9F,  0.85F,  0.9F,  0.9F,  0.95F,  1.0F,  1.05F,  1.15F,  1.35F,  1.45F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossBik_Warn_v[10]  = { 
1.25F,  1.2F,  1.2F,  1.2F,  1.25F,  1.3F,  1.35F,  1.45F,  1.5F,  1.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossBik_LowB_v[10]  = { 
0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  1.0F,  1.05F,  1.10F,  1.3F,  1.4F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCCrossBik_HigB_v[10]  = { 
0.9F,  0.85F,  0.85F,  0.87F,  0.9F,  0.95F,  1.0F,  1.05F,  1.2F,  1.3F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomPed_Pref_v[10]  = { 
0.7F,  0.6F,  0.65F,  0.7F,  0.8F,  0.9F,  1.1F,  1.2F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomPed_Warn_v[10]  = { 
1.25F,  1.2F,  1.0F,  0.95F,  1.0F,  1.0F,  1.2F,  1.45F,  1.6F,  1.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomPed_LowB_v[10]  = { 
0.5F,  0.4F,  0.45F,  0.5F,  0.6F,  0.7F,  0.9F,  1.0F,  1.0F,  1.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomPed_HigB_v[10]  = { 
0.4F,  0.3F,  0.35F,  0.4F,  0.5F,  0.6F,  0.7F,  0.8F,  0.8F,  0.8F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomBik_Pref_v[10]  = { 
0.7F,  0.6F,  0.65F,  0.7F,  0.8F,  0.9F,  1.1F,  1.2F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomBik_Warn_v[10]  = { 
1.25F,  1.2F,  1.0F,  0.95F,  1.0F,  1.0F,  1.2F,  1.45F,  1.6F,  1.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomBik_LowB_v[10]  = { 
0.5F,  0.4F,  0.45F,  0.5F,  0.6F,  0.7F,  0.9F,  1.0F,  1.0F,  1.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCOncomBik_HigB_v[10]  = { 
0.4F,  0.3F,  0.35F,  0.4F,  0.5F,  0.6F,  0.7F,  0.8F,  0.8F,  0.8F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedPed_Pref_v[10]  = { 
1.1F,  1.1F,  0.87F,  0.9F,  1.0F,  1.05F,  1.18F,  1.29F,  1.39F,  1.37F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedPed_Warn_v[10]  = { 
1.2F,  1.18F,  1.1F,  1.1F,  1.15F,  1.25F,  1.3F,  1.5F,  1.75F,  1.75F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedPed_LowB_v[10]  = { 
1.0F,  0.98F,  0.89F,  0.91F,  0.95F,  1.05F,  1.1F,  1.15F,  1.2F,  1.25F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedPed_HigB_v[10]  = { 
0.8F,  0.78F,  0.69F,  0.71F,  0.8F,  0.9F,  0.9F,  0.95F,  1.05F,  1.15F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedBik_Pref_v[10]  = { 
1.1F,  1.1F,  0.87F,  0.9F,  1.0F,  1.05F,  1.18F,  1.29F,  1.39F,  1.37F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedBik_Warn_v[10]  = { 
1.2F,  1.18F,  1.1F,  1.1F,  1.15F,  1.25F,  1.3F,  1.5F,  1.75F,  1.75F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedBik_LowB_v[10]  = { 
1.0F,  0.98F,  0.89F,  0.91F,  0.95F,  1.05F,  1.1F,  1.15F,  1.2F,  1.25F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_TTCPrecedBik_HigB_v[10]  = { 
0.8F,  0.78F,  0.69F,  0.71F,  0.8F,  0.9F,  0.9F,  0.95F,  1.05F,  1.15F }; //@ctype : CURVE ; @ref_axis_x : EAEB_TTCPedBik_Egospd_x ;
CAL_VAR float EAEB_dstFunnelRange_x[8]  = { 
4.0F,  12.0F,  20.0F,  40.0F,  60.0F,  80.0F,  100.0F,  150.0F };
CAL_VAR float EAEB_dstStatInFunnel_v[8]  = { 
2.2F,  2.9F,  2.6F,  2.5F,  2.2F,  2.0F,  2.0F,  2.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstFunnelRange_x ;
CAL_VAR float EAEB_dstMovInFunnel_v[8]  = { 
2.2F,  2.9F,  2.6F,  2.5F,  2.2F,  2.0F,  2.0F,  2.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstFunnelRange_x ;
CAL_VAR float EAEB_dstMovOutFunnel_v[8]  = { 
2.8F,  3.6F,  3.6F,  3.6F,  3.6F,  3.6F,  3.2F,  2.8F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstFunnelRange_x ;
CAL_VAR float EAEB_dstLongPosCheck_LongPos_x[9]  = { 
0.0F,  3.0F,  5.0F,  10.0F,  15.0F,  20.0F,  30.0F,  40.0F,  50.0F };
CAL_VAR float EAEB_spdLongPosCheck_Rrate_y[7]  = { 
-1.5F,  -2.78F,  -5.55F,  -8.33F,  -11.11F,  -13.88F,  -20.0F };
CAL_VAR float EAEB_dstLongPosCheck_Poserror_v[63]  = { 
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  2.5F,  2.5F,  
2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  3.0F,  3.0F,  3.0F,  3.0F,  
3.0F,  3.0F,  3.0F,  100.0F,  100.0F,  5.0F,  5.0F,  5.0F,  5.0F,  
5.0F,  100.0F,  100.0F,  100.0F,  8.0F,  8.0F,  8.0F,  8.0F,  100.0F,  
100.0F,  100.0F,  100.0F,  12.0F,  12.0F,  12.0F,  100.0F,  100.0F,  100.0F,  
100.0F,  100.0F,  16.0F,  16.0F,  100.0F,  100.0F,  100.0F,  100.0F,  100.0F,  
100.0F,  100.0F,  100.0F,  100.0F,  100.0F,  100.0F,  100.0F,  100.0F,  100.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstLongPosCheck_LongPos_x ; @ref_axis_y : EAEB_spdLongPosCheck_Rrate_y ;
CAL_VAR float EAEB_spdCCR_egospd_x[12]  = { 
2.78F,  5.56F,  8.33F,  11.11F,  13.89F,  16.67F,  19.4F,  22.22F,  25.0F,  27.78F,  30.56F,  33.33F };
CAL_VAR float EAEB_spdCCR_RRate_y[12]  = { 
-33.33F,  -30.56F,  -27.78F,  -25.0F,  -22.22F,  -19.4F,  -16.67F,  -13.89F,  -11.11F,  -8.33F,  -5.56F,  -2.78F };
CAL_VAR float EAEB_TTCLowB_norm_v[144]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.5F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.75F,  0.75F,  0.7F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.9F,  0.9F,  0.85F,  0.8F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.1F,  1.1F,  1.0F,  0.95F,  0.9F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.25F,  1.25F,  1.15F,  1.1F,  1.02F,  0.96F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.25F,  1.2F,  1.1F,  1.05F,  
0.0F,  0.0F,  0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
0.0F,  0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
0.0F,  0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
0.0F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F,  
1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.45F,  1.4F,  1.35F,  1.3F,  1.2F,  1.1F
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_TTCHighB_norm_v[144]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.3F,  0.45F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.7F,  0.7F,  0.6F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.85F,  0.85F,  0.75F,  0.65F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.05F,  1.05F,  0.9F,  0.8F,  0.7F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.15F,  1.15F,  1.05F,  0.95F,  0.9F,  0.8F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
0.0F,  0.0F,  0.0F,  0.0F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
0.0F,  0.0F,  0.0F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
0.0F,  0.0F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
0.0F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,   
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.2F,  1.15F,  1.05F,  1.0F,  0.95F,  0.9F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_TTCPrefill_norm_v[144]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.5F,  0.7F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.1F,  1.1F,  1.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.1F,  1.1F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.2F,  1.2F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.6F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
0.0F,  0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
0.0F,  0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
0.0F,  0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
0.0F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F,  
1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.7F,  1.6F,  1.5F,  1.4F,  1.3F,  1.3F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_TTCWarn_norm_v[144]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.5F,  0.7F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.2F,  1.2F,  1.1F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.4F,  1.4F,  1.3F,  1.3F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.6F,  1.6F,  1.5F,  1.4F,  1.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.8F,  1.8F,  1.7F,  1.6F,  1.5F,  1.5F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  1.9F,  1.9F,  1.8F,  1.7F,  1.7F,  1.6F,  1.6F,  
0.0F,  0.0F,  0.0F,  0.0F,  2.4F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  1.8F,  
0.0F,  0.0F,  0.0F,  2.6F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  1.9F,  
0.0F,  0.0F,  2.8F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  2.0F,  
0.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  
3.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F,  
3.0F,  3.0F,  3.0F,  2.9F,  2.8F,  2.7F,  2.6F,  2.5F,  2.4F,  2.3F,  2.2F,  2.1F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_TTCWarn_addins_v[144]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.1F,  0.1F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_dstCCRdecl_Range_x[8]  = { 
5.0F,  10.0F,  15.0F,  20.0F,  25.0F,  30.0F,  35.0F,  40.0F };
CAL_VAR float EAEB_accCCRdecl_TargDecl_y[8]  = { 
-9.81F,  -6.8F,  -5.0F,  -3.8F,  -2.93F,  -2.5F,  -2.1F,  -1.0F };
CAL_VAR float EAEB_TTCLowB_decel_v[64]  = { 
0.3F,  0.3F,  0.45F,  0.45F,  0.3F,  0.2F,  0.15F,  0.0F,  
0.3F,  0.3F,  0.4F,  0.4F,  0.25F,  0.15F,  0.1F,  0.0F,  
0.2F,  0.2F,  0.25F,  0.3F,  0.125F,  0.1F,  0.1F,  0.0F,  
0.1F,  0.1F,  0.15F,  0.2F,  0.1F,  0.125F,  0.05F,  0.0F,  
0.0F,  0.0F,  0.05F,  0.1F,  0.1F,  0.125F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstCCRdecl_Range_x ; @ref_axis_y : EAEB_accCCRdecl_TargDecl_y ;
CAL_VAR float EAEB_TTCHighB_decel_v[64]  = { 
0.3F,  0.3F,  0.45F,  0.45F,  0.3F,  0.2F,  0.15F,  0.0F,  
0.3F,  0.3F,  0.4F,  0.4F,  0.25F,  0.15F,  0.1F,  0.0F,  
0.2F,  0.2F,  0.25F,  0.3F,  0.125F,  0.1F,  0.1F,  0.0F, 
0.1F,  0.1F,  0.15F,  0.2F,  0.1F,  0.125F,  0.05F,  0.0F,  
0.0F,  0.0F,  0.05F,  0.1F,  0.1F,  0.125F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstCCRdecl_Range_x ; @ref_axis_y : EAEB_accCCRdecl_TargDecl_y ;
CAL_VAR float EAEB_TTCPrefill_decel_v[64]  = { 
0.45F,  0.45F,  0.4F,  0.4F,  0.35F,  0.3F,  0.3F,  0.0F,  
0.35F,  0.35F,  0.3F,  0.3F,  0.25F,  0.2F,  0.2F,  0.0F,  
0.3F,  0.3F,  0.25F,  0.25F,  0.25F,  0.2F,  0.2F,  0.0F,  
0.25F,  0.25F,  0.2F,  0.2F,  0.2F,  0.2F,  0.2F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.2F,  0.2F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstCCRdecl_Range_x ; @ref_axis_y : EAEB_accCCRdecl_TargDecl_y ;
CAL_VAR float EAEB_TTCWarn_decel_v[64]  = { 
-0.1F,  -0.1F,  0.0F,  0.2F,  0.25F,  0.3F,  0.35F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.1F,  0.2F,  0.25F,  0.3F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.1F,  0.15F,  0.2F,  0.25F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.05F,  0.1F,  0.15F,  0.2F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.05F,  0.2F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
-0.2F,  -0.2F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstCCRdecl_Range_x ; @ref_axis_y : EAEB_accCCRdecl_TargDecl_y ;
CAL_VAR float EAEB_TTCWarn_deceladdins_v[64]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_dstCCRdecl_Range_x ; @ref_axis_y : EAEB_accCCRdecl_TargDecl_y ;
CAL_VAR float EAEB_dstInPath_Range_x[10]  = { 
0.0F,  10.0F,  20.0F,  30.0F,  40.0F,  50.0F,  60.0F,  70.0F,  80.0F,  90.0F };
CAL_VAR float EAEB_dstInPath_HitDistBef_v[10]  = { 
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.2F,  1.2F,  1.2F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_dstInPath_HitDistAft_v[10]  = { 
4.0F,  4.0F,  4.0F,  4.0F,  4.0F,  4.0F,  4.0F,  4.0F,  4.0F,  4.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_dstInPath_YawDistBef_v[10]  = { 
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_dstInPath_YawDistAft_v[10]  = { 
1.75F,  1.75F,  1.75F,  1.75F,  1.75F,  1.75F,  1.75F,  1.75F,  1.75F,  1.75F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_dstInPath_XOLCBef_v[10]  = { 
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.2F,  1.2F,  1.2F,  1.2F,  1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_dstInPath_XOLCAft_v[10]  = { 
1.2F,  1.2F,  1.2F,  1.2F,  1.2F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstInPath_Range_x ;
CAL_VAR float EAEB_perTTCcalc_XOLCperc_x[9]  = { 
0.0F,  0.2F,  0.4F,  0.6F,  0.8F,  1.0F,  1.2F,  1.6F,  2.0F };
CAL_VAR float EAEB_perWarn_TTCperc_v[9]  = { 
0.0F,  0.0F,  0.0F,  -0.1F,  -0.15F,  -0.2F,  -0.3F,  -0.5F,  -0.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perWarnMO_TTCperc_v[9]  = { 
0.0F,  0.0F,  -1.1F,  -1.1F,  -1.15F,  -1.2F,  -1.4F,  -1.6F,  -1.9F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perLowB_TTCperc_v[9]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  -0.3F,  -0.5F,  -0.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perLowBMO_TTCperc_v[9]  = { 
0.0F,  0.0F,  -0.8F,  -0.9F,  -1.1F,  -1.2F,  -1.2F,  -1.2F,  -1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perPref_TTCperc_v[9]  = { 
0.0F,  0.0F,  0.0F,  -0.1F,  -0.15F,  -0.2F,  -0.3F,  -0.5F,  -0.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perPrefMO_TTCperc_v[9]  = { 
0.0F,  0.0F,  -1.1F,  -1.1F,  -1.15F,  -1.2F,  -1.4F,  -1.6F,  -1.9F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perHighB_TTCperc_v[9]  = { 
0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  0.0F,  -0.3F,  -0.5F,  -0.7F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_perHighBMO_TTCperc_v[9]  = { 
0.0F,  0.0F,  -0.8F,  -0.9F,  -1.0F,  -1.0F,  -1.0F,  -1.0F,  -1.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR uint8_t EAEB_ageCCR_inpathage_v[4]  = { 
254U,  254U,  15U,  10U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_ageUndef_inpathage_v[4]  = { 
254U,  254U,  55U,  30U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR float EAEB_perdeltayawrate_v[9]  = { 
5.0F,  5.0F,  2.0F,  0.5F,  0.3F,  0.2F,  0.2F,  0.2F,  0.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_dstTarget_Range_x[10]  = { 
5.0F,  10.0F,  15.0F,  20.0F,  25.0F,  30.0F,  35.0F,  40.0F,  45.0F,  50.0F };
CAL_VAR float EAEB_dstCollisionPoint_Range_y[8]  = { 
5.0F,  10.0F,  15.0F,  20.0F,  25.0F,  30.0F,  35.0F,  40.0F };
CAL_VAR float EAEB_spdFTAP_egospd_x[8]  = { 
1.39F,  2.78F,  4.17F,  5.56F,  6.94F,  8.33F,  9.72F,  11.11F };
CAL_VAR float EAEB_spdFTAP_targspd_x[8]  = { 
2.78F,  5.56F,  8.33F,  11.11F,  13.89F,  16.67F,  19.44F,  22.22F };
CAL_VAR float EAEB_spdOncom_targspd_v[10]  = { 
-1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F,  -1.2F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dstTarget_Range_x ;
CAL_VAR float EAEB_dstFTAP_predictpath_v[64]  = { 
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.5F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  0.5F,  
0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAP_currentpath_v[64]  = { 
6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  2.5F,  1.35F,  
8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  3.0F,  1.35F,  
9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  4.0F,  1.35F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAPwarn_predictpath_v[64]  = { 
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.5F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  0.5F,  
0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAPwarn_currentpath_v[64]  = { 
6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  2.5F,  1.35F,  
8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  3.0F,  1.35F,  
9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  4.0F,  1.35F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAP_predictext_v[64]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.1F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  0.2F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  0.2F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAP_currentext_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  1.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  3.0F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  5.0F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAPwarn_predictext_v[64]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.1F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  0.2F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  0.2F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAPwarn_currentext_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  1.0F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  3.0F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;
CAL_VAR float EAEB_dstFTAPTOI_Range_v[8]  = { 
30.0F,  35.0F,  40.0F,  40.0F,  40.0F,  40.0F,  40.0F,  40.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdFTAP_egospd_x ;
CAL_VAR uint8_t EAEB_ageFTAP_inpathage_v[4]  = { 
254U,  254U,  60U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_ageFTAPwarn_inpathage_v[4]  = { 
254U,  254U,  60U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR float EAEB_tiFTAPwarn_TTC_v[8]  = { 
0.95F,  1.05F,  1.2F,  1.35F,  1.35F,  1.35F,  1.35F,  1.35F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdFTAP_egospd_x ;
CAL_VAR float EAEB_tiFTAPpref_TTC_v[8]  = { 
0.85F,  0.95F,  1.1F,  1.25F,  1.25F,  1.25F,  1.25F,  1.25F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdFTAP_egospd_x ;
CAL_VAR float EAEB_tiFTAPlowB_TTC_v[8]  = { 
0.7F,  0.8F,  0.95F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdFTAP_egospd_x ;
CAL_VAR float EAEB_tiFTAPhighB_TTC_v[8]  = { 
0.7F,  0.75F,  0.9F,  1.05F,  1.05F,  1.05F,  1.05F,  1.05F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdFTAP_egospd_x ;
CAL_VAR float EAEB_dstFTAP_predictext_after_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.5F,  0.5F,  
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.5F,  0.5F,  
2.0F,  2.0F,  2.0F,  2.0F,  2.0F,  2.0F,  0.5F,  0.5F,  
2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdFTAP_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_y ;

//driver monitor
CAL_VAR float EAEB_Dm_Min_Brk_Ped                = 5.0;

CAL_VAR float EAEB_Dm_Fdb3_Hardbrk_Ped           = 30;
CAL_VAR uint8_t EAEB_Dm_Fdb3_Hardbrk_Age         = 10;
CAL_VAR float EAEB_Dm_Fdb3_Hardbrk_AccThres      = -4.99;
CAL_VAR float EAEB_Dm_Fdb2_Hardbrk_Ped           = 10;
CAL_VAR uint8_t EAEB_Dm_Fdb2_Hardbrk_Age         = 5;

CAL_VAR float EAEB_Dm_Fb1_DrvMod[5]              = {0,  1,  2,  3,  4};
CAL_VAR float EAEB_Dm_Fdb1_High_Ped[5]           = {90.0,  90.0,  88.0,  85.0,  85.0};//@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Fb1_DrvMod ;
CAL_VAR float EAEB_Dm_Fdb1_Low_Ped[5]            = {40.0,  40.0,  38.0,  35.0,  35.0};
CAL_VAR float EAEB_Dm_Fdb1_Low_Grad[5]           = {250.0, 250.0, 250.0, 250.0, 250.0};
CAL_VAR uint8_t EAEB_Dm_Fdb1_Hardacc_Age         = 20;

CAL_VAR float EAEB_Dm_Fdb1_Time                  = 0.5;
CAL_VAR float EAEB_Dm_Fdb2_Time                  = 0.5;
CAL_VAR float EAEB_Dm_Fdb3_Time                  = 0.2;

CAL_VAR float EAEB_Dm_Act1Grad_Vx_x[2]           = {1.38, 16.67};
CAL_VAR float EAEB_Dm_Act1Grad_StrGrad_y[2]      = {45, 20.0}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Act1Grad_Vx_x ;

CAL_VAR float EAEB_Dm_Act2Ang_Vx_x[8]            = {1.39,   2.78,   4.17,   5.56,   6.94,   8.33,   9.72,   11.11};
CAL_VAR float EAEB_Dm_Act2Ang_StrAng_y[8]        = {260.0,  250.0,  200.0,  190.0,  180.0,  150.0,  140.0,  120.0}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Act2Ang_Vx_x ;

CAL_VAR float EAEB_Dm_Act2Grad_Vx_x[2]           = {5.0, 15.0};
CAL_VAR float EAEB_Dm_Act2Grad_StrGrad_y[2]      = {200.0, 100.0}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Act2Grad_Vx_x ;

CAL_VAR float EAEB_Dm_Act3Grad_Vx_x[2]           = {0.0, 15.0};
CAL_VAR float EAEB_Dm_Act3Grad_StrGrad_y[2]      = {1000.0, 400.0}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Act3Grad_Vx_x ;

CAL_VAR float EAEB_Dm_Act1_Time                  = 1.0;
CAL_VAR float EAEB_Dm_Act2_Time_Low              = 0.5;
CAL_VAR float EAEB_Dm_Act2_Time_High             = 2.0;
CAL_VAR float EAEB_Dm_Act3_Time                  = 1.0;

CAL_VAR float EAEB_Dm_Fo3_Hardbrk_Ped            = 15.0;
CAL_VAR uint8_t EAEB_Dm_Fo3_Hardbrk_Age          = 10;

CAL_VAR float EAEB_Dm_Foc1_High_Grad             = 150.0;
CAL_VAR float EAEB_Dm_Foc1_Low_Grad              = -180.0;
CAL_VAR float EAEB_Dm_Foc1_Mid_Ped               = 1.0;
CAL_VAR float EAEB_Dm_Foc1_Mid_Grad              = -4.0;
CAL_VAR float EAEB_Dm_Foc1_Str_Grad              = 100.0;

CAL_VAR float EAEB_Dm_Foc2_Min_Velx              = 13.89;

CAL_VAR float EAEB_Dm_Foc2Ped_Vx_x[2]            = {25, 45};
CAL_VAR float EAEB_Dm_Foc2Ped_Ped_y[2]           = {40.0, 80.0}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Foc2Ped_Vx_x ;

CAL_VAR float EAEB_Dm_Foc3_Max_Velx              = 16.67;
CAL_VAR float EAEB_Dm_Foc3_Max_Ax                = -1.2;

CAL_VAR float EAEB_Dm_Foc4Ax_Vx_x[7]             = {5.56, 11.11, 16.67, 22.22, 27.78, 33.33, 38.89};
CAL_VAR float EAEB_Dm_Foc4Ax_Ax_y[7]             = {-3.0, -2.8,  -2.5,  -2.3,  -2.0,  -1.9, -1.8}; //@ctype : CURVE ; @ref_axis_x : EAEB_Dm_Foc4Ax_Vx_x ;

CAL_VAR float EAEB_Dm_Foc1_Time                  = 2.5;
CAL_VAR float EAEB_Dm_Foc2_Time                  = 1.0;
CAL_VAR float EAEB_Dm_Foc3_Time                  = 0.5;
CAL_VAR float EAEB_Dm_Foc4_Time                  = 0.5;

CAL_VAR float EAEB_Dm_Ccftap_Max_Vel             = 11.11;
CAL_VAR float EAEB_Dm_Ccftap_Min_Yawrate         = 0.1;
CAL_VAR float EAEB_Dm_Ccftap_Max_StrAng          = 300.0;

CAL_VAR float EAEB_Dm_Fwd_Max_Vel                = 41.7;
CAL_VAR float EAEB_Dm_Fwd_Min_Vel                = 1.11;
CAL_VAR float EAEB_Dm_Bwd_Max_Vel                = -0.83;
CAL_VAR float EAEB_Dm_Bwd_Min_Vel                = -4.17;
CAL_VAR float EAEB_Dm_Static_Vel                 = 0.25;
CAL_VAR float EAEB_Dm_Min_Acc_GasPed             = 8.0;

CAL_VAR float EAEB_Dm_Sdy_Gasgrad                = 10.0;
CAL_VAR float EAEB_Dm_Vel_Dev_Thres              = 0.5;
CAL_VAR float EAEB_Dm_Sdy_Time                   = 5.0;
CAL_VAR float EAEB_Dm_Ramp_Time                  = 2.0;
CAL_VAR bool  EAEB_Dm_SdyDetect_Switch           = false;

CAL_VAR float EAEB_Dm_Foc1_DampFactor[32]        = {
1.0,  0.85,  0.9,  0.9,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
};

CAL_VAR float EAEB_Dm_Foc2_DampFactor[32]        = {
1.0,  0.5,   0.75, 0.8,  1.0,  1.0,  0.8,  0.75,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
};

CAL_VAR float EAEB_Dm_Foc3_DampFactor[32]        = {
1.0,  0.4,   0.65, 0.8,  1.0,  1.0,  0.7,  0.65,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
};

CAL_VAR float EAEB_Dm_Foc4_DampFactor[32]        = {
1.0,  0.4,   0.65, 0.6,  1.0,  1.0,  0.6,  0.65,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
1.0,  1.0,   1.0,  1.0,  1.0,  1.0,  1.0,  1.0,
};

//gen object filter
CAL_VAR float EAEB_Gof_Max_PedVel                = 15.0;
CAL_VAR float EAEB_Gof_Max_BikVel                = 20.0;
CAL_VAR float EAEB_Gof_Max_MoBikVel              = 55.6;
CAL_VAR float EAEB_Gof_Max_SmallVehVel           = 55.6;
CAL_VAR float EAEB_Gof_Max_BigVehVel             = 55.6;
CAL_VAR float EAEB_Gof_Max_GenObjVel             = 0.1;

CAL_VAR float EAEB_Gof_Max_FusionConf            = 0.6;
CAL_VAR float EAEB_Gof_Max_VisConf               = 0.6;
CAL_VAR float EAEB_Gof_Max_RadarConf             = 0.6;

CAL_VAR uint8_t EAEB_Gof_Max_FusionAge           = 2;
CAL_VAR uint8_t EAEB_Gof_Max_VisAge              = 2;
CAL_VAR uint8_t EAEB_Gof_Max_RadarAge            = 2;

//AEB CCC scenarios
CAL_VAR float EAEB_dstCollisionPoint_Range_CCC_y[8]  = { 
5.0F,  10.0F,  15.0F,  20.0F,  25.0F,  30.0F,  35.0F,  40.0F };
CAL_VAR float EAEB_spdccc_egospd_x[8]  = { 
1.39F,  2.78F,  4.17F,  5.56F,  6.94F,  8.33F,  9.72F,  11.11F };
CAL_VAR float EAEB_spdccc_targspd_x[8]  = { 
2.78F,  5.56F,  8.33F,  11.11F,  13.89F,  16.67F,  19.44F,  22.22F };
CAL_VAR float EAEB_dstccc_predictpath_v[64]  = { 
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.5F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  0.5F,  
0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstccc_currentpath_v[64]  = { 
6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  2.5F,  1.35F,  
8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  3.0F,  1.35F,  
9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  4.0F,  1.35F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstcccwarn_predictpath_v[64]  = { 
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.5F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.55F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  1.3F,  0.6F,  
1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  1.1F,  0.5F,  
0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstcccwarn_currentpath_v[64]  = { 
6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  6.5F,  2.5F,  1.35F,  
8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  8.0F,  3.0F,  1.35F,  
9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  9.5F,  4.0F,  1.35F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F,  
13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  13.0F,  5.0F,  1.35F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_egospd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstccc_predictext_v[64]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.1F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  0.2F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  0.2F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstccc_currentext_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  1.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  3.0F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  5.0F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstcccwarn_predictext_v[64]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.1F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  0.2F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  0.2F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  0.2F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstcccwarn_currentext_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.0F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.0F,  
5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  5.0F,  1.0F,  
7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  7.0F,  3.0F,  
9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  9.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F,  
11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  11.0F,  5.0F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
CAL_VAR float EAEB_dstCCCTOI_Range_v[8]  = { 
30.0F,  35.0F,  40.0F,  40.0F,  40.0F,  40.0F,  40.0F,  40.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdccc_egospd_x ;
CAL_VAR uint8_t EAEB_ageCCC_inpathage_v[4]  = { 
254U,  254U,  60U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR uint8_t EAEB_ageCCCwarn_inpathage_v[4]  = { 
254U,  254U,  60U,  5U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR float EAEB_tiCCCwarn_TTC_v[8]  = { 
1.8F,  1.8F,  1.8F,  1.85F,  1.9F,  2.35F,  2.45F,  2.6F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdccc_egospd_x ;
CAL_VAR float EAEB_tiCCCpref_TTC_v[8]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdccc_egospd_x ;
CAL_VAR float EAEB_tiCCClowB_TTC_v[8]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdccc_egospd_x ;
CAL_VAR float EAEB_tiCCChighB_TTC_v[8]  = { 
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdccc_egospd_x ;
CAL_VAR float EAEB_dstccc_predictext_after_v[64]  = { 
1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  1.0F,  0.5F,  0.5F,  
1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  1.5F,  0.5F,  0.5F,  
2.0F,  2.0F,  2.0F,  2.0F,  2.0F,  2.0F,  0.5F,  0.5F,  
2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  2.5F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F,  
3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  3.0F,  0.5F,  0.5F 
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdccc_targspd_x ; @ref_axis_y : EAEB_dstCollisionPoint_Range_CCC_y ;
//ShadowMode
CAL_VAR bool    k_AEBShadowMode_active  = 0 ;
CAL_VAR float   k_yawratefilter_limit   = 0.1 ;
CAL_VAR bool    kAebRearEnable          = true;
CAL_VAR bool    kAebShadowModeSoft      = false;
CAL_VAR bool    kAebHilMode             = false;

CAL_VAR float EAEB_dmsteer_egospd_x[12]  = { 
2.78F,  5.56F,  8.33F,  11.11F,  13.89F,  16.67F,  19.44F,  22.22F, 25.0F, 27.78F, 30.56F, 33.33F };

CAL_VAR float EAEB_dmsteer_stwangle_v[12]  = { 
150.0F,  100.0F,  75.0F,  50.0F,  50.0F,  50.0F,  50.0F,  50.0F, 50.0F, 50.0F, 40.0F, 40.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dmsteer_egospd_x ;

CAL_VAR float EAEB_dmsteer_yawrate_v[12]  = { 
0.1F,  0.15F,  0.20F,  0.28F,  0.35F,  0.42F,  0.5F,  0.56F, 0.65F, 0.7F, 0.77F, 0.85F }; //@ctype : CURVE ; @ref_axis_x : EAEB_dmsteer_egospd_x ;

CAL_VAR float EAEB_overtake_steerangle_v[12]  = { 
80.0F,  35.0F,  28.0F,  25.0F,  20.0F,  17.0F,  15.0F,  12.0F,  10.0F,  8.0F,  8.0F,  8.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdCCR_egospd_x ;


CAL_VAR float EAEB_overtake_gasped_v[12]  = { 
30.0F,  20.0F,  15.0F,  15.0F,  15.0F,  15.0F,  15.0F,  20.0F,  20.0F,  20.0F,  20.0F,  20.0F }; //@ctype : CURVE ; @ref_axis_x : EAEB_spdCCR_egospd_x ;


CAL_VAR float k_single_target_increase = 0.4 ;
CAL_VAR float k_drive_straight_decrease = 0.4 ;
CAL_VAR bool k_add_motor_inccr = 0 ;
CAL_VAR bool k_add_undef_inccr = 0 ;

CAL_VAR float EAEB_dstccr_timetobrake_safezone_v[12] = {
0.2F, 0.3F, 0.4F, 0.5F, 0.6F, 0.7F, 0.8F, 0.9F, 1.0F, 1.0F, 1.0F, 1.0F
}; //@ctype : CURVE ; @ref_axis_x : EAEB_spdCCR_egospd_x ;
CAL_VAR float EAEB_dstccr_timetoturn_safelat_v[9] = {
0.3, 0.3, 0.3, 0.2, 0.2, 0.2, 0.1, 0.1, 0.1
}; //@ctype : CURVE ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ;
CAL_VAR float EAEB_TTB_offset_v[144] = { 
0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.4F,  0.4F,  0.3F,  0.3F,  0.3F,  0.3F,  0.3F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.4F,  0.4F,  0.3F,  0.3F,  0.3F,  0.3F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.4F,  0.4F,  0.4F,  0.3F,  0.3F,  
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.4F,  0.4F,  0.3F,  0.3F,  
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.3F,  
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  0.4F,  
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.4F,  0.4F,  
0.7F,  0.7F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.7F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F,  
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.5F,  0.5F
}; //@ctype : MAP ; @ref_axis_x : EAEB_spdCCR_egospd_x ; @ref_axis_y : EAEB_spdCCR_RRate_y ;
CAL_VAR float EAEB_TTT_offset_v[108] = {
0.4F,  0.4F,  0.4F,  0.4F,  0.5F,  0.8F,  1.2F,  0.8F,  0.6F,  0.6F,  0.6F,  0.6F,  
0.4F,  0.4F,  0.4F,  0.4F,  0.5F,  0.8F,  1.2F,  0.8F,  0.6F,  0.6F,  0.6F,  0.6F,  
0.3F,  0.3F,  0.3F,  0.3F,  0.4F,  0.8F,  1.2F,  0.8F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.3F,  0.3F,  0.3F,  0.3F,  0.4F,  0.8F,  1.2F,  0.8F,  0.5F,  0.5F,  0.5F,  0.5F,  
0.6F,  0.6F,  0.7F,  0.7F,  0.8F,  0.8F,  1.2F,  0.8F,  0.9F,  0.9F,  0.9F,  0.9F,  
0.6F,  0.6F,  0.7F,  0.7F,  0.8F,  0.8F,  1.2F,  0.8F,  0.9F,  0.9F,  0.9F,  0.9F,  
0.6F,  0.6F,  0.7F,  0.7F,  0.8F,  0.8F,  1.2F,  0.8F,  0.9F,  0.9F,  0.9F,  0.9F,  
0.6F,  0.6F,  0.7F,  0.7F,  0.8F,  0.8F,  1.2F,  0.8F,  0.9F,  0.9F,  0.9F,  0.9F,  
0.6F,  0.6F,  0.7F,  0.7F,  0.8F,  0.8F,  1.2F,  0.8F,  0.9F,  0.9F,  0.9F,  0.9F
}; //@ctype : MAP ; @ref_axis_x : EAEB_perTTCcalc_XOLCperc_x ; @ref_axis_y : EAEB_spdCCR_egospd_x ;
CAL_VAR float EAES_spdCCR_range_x[10]  = { 
4.0F,  12.0F,  20.0F,  40.0F,  60.0F,  80.0F,  100.0F,  120.0F,  140.0F,  160.0F };
CAL_VAR float EAES_spdCCR_RRate_y[10]  = { 
-55.6F,  -50.0F,  -44.5F,  -38.9F,  -33.3F,  -27.8F,  -22.2F,  -16.7F,  -11.11F,  -5.56F };
CAL_VAR float EAES_InPath_current_v[100]  = { 
0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  
0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,  0.9F,   
0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,   
0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,   
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,   
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,   
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,   
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F
}; //@ctype : MAP ; @ref_axis_x : EAES_spdCCR_range_x ; @ref_axis_y : EAES_spdCCR_RRate_y ;
CAL_VAR float EAES_InPath_predict_v[100]  = { 
0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  
0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,  0.8F,   
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,   
0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  0.7F,  
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,   
0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,  0.6F,   
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,   
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,    
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,   
0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F,  0.5F
}; //@ctype : MAP ; @ref_axis_x : EAES_spdCCR_range_x ; @ref_axis_y : EAES_spdCCR_RRate_y ;
CAL_VAR uint8_t EAES_InPath_age_v[4]  = { 
199U,  50U,  30U,  20U }; //@ctype : CURVE ; @ref_axis_x : EAEB_agecheck_AEBconf_x ;
CAL_VAR float k_AESLateralSafeZone = 0.4 ;
CAL_VAR float k_AESMaxPlanRange = 100 ;
CAL_VAR float k_AESMinPlanRange = 15 ;
CAL_VAR float k_AESInLaneC1_limitation = 0.18 ;
CAL_VAR float k_AESDefaultVehicleWidth = 2.4 ;
CAL_VAR uint8_t k_AESHoldAge = 50 ;
CAL_VAR uint8_t k_AESExternReq = 0 ;
CAL_VAR float EAES_egospd_x[8]  = {13.89F,  16.67F,  19.4F,  22.22F,  25.0F,  27.78F,  30.56F,  33.33F };
CAL_VAR float EAES_latacc_threshold_v[8]  = {5.89F,  5.89F,  5.40F,  4.91F,  4.91F,  4.91F,  4.91F,  4.91F }; //@ctype : CURVE ; @ref_axis_x : EAES_egospd_x ;
CAL_VAR uint8_t k_AESMaxLongEsti = 2 ;
CAL_VAR float k_AESLongCostGain = 0.1 ;
CAL_VAR float k_AESLatCostGain = 0.5 ;