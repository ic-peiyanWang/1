#include <stdint.h>
#include "asimov_compiler.h"
#define uchar unsigned char

namespace nio {
namespace ad {

MES_VAR uchar stAEBOnOff    = 1;
MES_VAR uchar stTrailerMode = 0;
MES_VAR bool  flgSeatBltFrntLeSts;
MES_VAR uchar stEPBSwt;
MES_VAR bool  flgBrkOvht      = false;
MES_VAR uchar stEPBSts        = 0;
MES_VAR uchar stHDCSts        = 0;
MES_VAR uchar stAVHSts        = 0;
MES_VAR uchar stStandstillSts = 0;
MES_VAR bool  flgTCSDeactv    = false;
MES_VAR uchar stFCWSet        = 1;

MES_VAR bool FlgTCSActive = false;
MES_VAR bool FlgVDCActive = false;
MES_VAR bool FlgDTCActive = false;
MES_VAR bool FlgABSActive = false;

MES_VAR bool  flgVDCDeactv    = false;
MES_VAR uchar stDoorAjarFLSts = 1;
MES_VAR uchar stVehSt;
MES_VAR uchar stLvlAdjSts;
MES_VAR uchar stActGear;
MES_VAR uchar stVehRdy;

MES_VAR bool flgAWBAvl      = true;
MES_VAR bool flgABAAvl      = true;
MES_VAR bool flgAutoBrkgAvl = true;
MES_VAR bool flgEBPAvl      = true;
MES_VAR bool flgEBAAvl      = true;

MES_VAR bool flgVehStInld             = false;
MES_VAR bool flgHMIFail               = false;
MES_VAR bool flgADCInternalFault      = false;
MES_VAR bool flgLatAccValInvld        = false;
MES_VAR bool flgYawrateInvld          = false;
MES_VAR bool flgLonAccValInvld        = false;
MES_VAR bool flgSeatOccpFrntLeInvld   = false;
MES_VAR bool flgSeatOccpFrntLeFailure = false;
MES_VAR bool flgBrkPrsOfsInvld        = false;
MES_VAR bool flgVehSpdInvld           = false;
MES_VAR bool flgWhlSpdInvld           = false;
MES_VAR bool flgWhlPulCntInvld        = false;
MES_VAR bool flgBrkPrssInvld          = false;
MES_VAR bool flgBrkPdlInvld           = false;
MES_VAR bool flgStrngWhlAgSnsrFail    = false;
MES_VAR bool flgStrngWhlAgSpdInvld    = false;
MES_VAR bool flgStrngWhlAgSnsrNotCal  = false;
MES_VAR bool flgAccPdlActPosnInvld    = false;
MES_VAR bool flgGearInvld             = false;
MES_VAR bool flgSCMLossCommFault      = false;
MES_VAR bool flgSCMFail               = false;
MES_VAR bool flgBCMLossCommFault      = false;
MES_VAR bool flgVCULossCommFault      = false;
MES_VAR bool flgBCULossCommFault      = false;
MES_VAR bool flgACMLossCommFault      = false;
MES_VAR bool flgCGWLossCommFault      = false;
MES_VAR bool flgCDCLossCommADAS_Fault = false;

MES_VAR bool flgRADFCLossCommFault = false;
MES_VAR bool flgRADFC_Blindness    = false;
MES_VAR bool flgRADFC_Failure      = false;

MES_VAR bool flgFS_partialBlockage_2        = false;
MES_VAR bool flgFS_partialBlockage_3        = false;
MES_VAR bool flgFS_fullBlockage_1           = false;
MES_VAR bool flgFS_fullBlockage_2           = false;
MES_VAR bool flgFS_fullBlockage_3           = false;
MES_VAR bool flgFS_autofixOutOfCalibHorizon = false;
MES_VAR bool flgFS_autofixOutOfCalibYAW     = false;
MES_VAR bool flgFS_TSR_outOfCalib_mode      = false;
MES_VAR bool flgFS_out_of_focus_2           = false;
MES_VAR bool flgFS_out_of_focus_3           = false;
MES_VAR bool flgFS_frozenWindshield         = false;
MES_VAR bool flgFS_blurredImage_1           = false;
MES_VAR bool flgFS_blurredImage_2           = false;
MES_VAR bool flgFS_blurredImage_3           = false;
MES_VAR bool flgFS_lowSun_3                 = false;
MES_VAR bool flgFS_splashes_2               = false;
MES_VAR bool flgFS_sunRay_1                 = false;
MES_VAR bool flgFS_sunRay_2                 = false;
MES_VAR bool flgFS_rain_2                   = false;
MES_VAR bool flgFS_rain_3                   = false;
MES_VAR bool flgFS_fog_2                    = false;
MES_VAR bool flgFS_fog_3                    = false;

CAL_VAR double EBA_pDrvAppBrkPresThr_C      = 15;
CAL_VAR double EBA_dpDrvAppBrkPresGradThr_C = 800;
CAL_VAR double AEB_pctAbsAccPedOvrd_C       = 80;
CAL_VAR double AEB_pctRelAccPedOvrd_C       = 50;
CAL_VAR double AEB_xRelAccPedRateOvrd_C     = 40;
CAL_VAR double AEB_tiAbsAccPedOvrdTimer_C   = 1;
CAL_VAR double AEB_tiRelAccPedOvrdTimer_C   = 0.1;
CAL_VAR double AEB_pctStrngWhlAgSpdGain_C   = 0.606;
CAL_VAR double AEB_xStrngWhlAgSpdOvrd_C     = 200;
CAL_VAR double AEB_xVehYawrateOvrd_C        = 100;

CAL_VAR double FCW_pctAbsAccPedOvrd_C      = 80;
CAL_VAR double FCW_pctRelAccPedOvrd_C      = 50;
CAL_VAR double FCW_xRelAccPedRateOvrd_C    = 40;
CAL_VAR double FCW_tiAbsAccPedOvrdTimer_C  = 1;
CAL_VAR double FCW_tiRelAccPedOvrdTimer_C  = 0.1;
CAL_VAR double FCW_pctStrngWhlAgSpdGain_C  = 0.606;
CAL_VAR double FCW_xStrngWhlAgSpdOvrd_C    = 200;
CAL_VAR double FCW_xVehYawrateOvrd_C       = 100;
CAL_VAR bool   AWB_flgForceDisableAWB_C    = 1;
CAL_VAR double AWB_v1stLvlVehSpdLowerLmt_C = 8.33;
CAL_VAR double AWB_v2ndLvlVehSpdLowerLmt_C = 15.27;
CAL_VAR double AWB_v3rdLvlVehSpdLowerLmt_C = 25;

CAL_VAR uint16_t AEB_FWfailsafeMsk    = 0x1FEE;
CAL_VAR uint16_t AEB_FNfailsafeMsk    = 0x1FEE;
CAL_VAR uint16_t AEB_LidarfailsafeMsk = 0xFFFF;
CAL_VAR uint16_t AEB_RearfailsafeMsk  = 0x1FEE;
}  // namespace ad
}  // namespace nio
