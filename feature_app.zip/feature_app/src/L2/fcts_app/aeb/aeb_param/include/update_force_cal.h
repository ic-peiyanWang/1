#ifndef FORCE_CAL_H_
#define FORCE_CAL_H_
#include <stdint.h>
#include "asimov_compiler.h"
#include "aeb_calibration.h"

void update_force_calibration();

#endif // FORCE_CAL_H_