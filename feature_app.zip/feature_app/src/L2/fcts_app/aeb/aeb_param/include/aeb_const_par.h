#ifndef AEB_CONST_PAR_H_
#define AEB_CONST_PAR_H_

#include <stdint.h>
#include <math.h>

namespace nio {
namespace ad {

constexpr uint8_t kMECamObjectNum = 40U;
constexpr uint8_t kAEBObjectNum = kMECamObjectNum;
constexpr uint8_t kAEBAlertNum = 4U;

constexpr bool kVnFplauscheckenable = 1;
constexpr bool kageplauscheckenable = 1;
constexpr bool kLFplauscheckenable = 1;
constexpr bool kinpathageplauscheckenable = 1;
constexpr bool kAEBBicycleEnable = 1;
constexpr bool kAEBOncomingEnable = 1;
constexpr uint8_t kAEBlowbrakeminage = 2;
constexpr bool kVisionIDCheckEnable = 1;
constexpr bool kFusionAEBDecision = 1;

const float     MaxLatAcc               = 3.94f;

const float     VehicleWidthBuffer      = 0.2f;

const float     EgoMaxBrakeAcc          = 7.84f;

const float     CCRYawDistLimit         = 8.0f;

const float     CcrToiRangeMax          = 45.0f;

const float     CcrToiRangeMaxMove      = 75.0f;

const uint8_t   MaxFusedObjIndex        = 128;

const uint8_t   MaxVisionIndex          = 255;

const float     MaxHoldVehSpdMps        = 1.5f;

const float     MaxHoldVehSpdMpsRear    = 1.5f;

const uint8_t   MaxCcrHighBrakeHoldAge  = 10;

const uint8_t   MaxVruHighBrakeHoldAge  = 15;

const uint8_t   MaxVruHighBrakeHoldRearAge = 15;

const float     MaxHoldAccPedPos        = 2.0f;

const float     MaxHoldAccPedPosRear    = 2.0f;

const float     MaxHoldBrkPedTrvl       = 5.0f;

const float     MaxHoldBrkPedTrvlRear   = 5.0f;

const uint8_t   MinRearLowBrkAge        = 2;

const float     G_ms2                   = 9.8f;

const float     Degree90ToRad           = 1.57;

const float     OncVxThres              = -1.2f;

const float     OncVxRearThres          = 1.2f;

const float     PrecVxThres             = 0.5f;

const float     PrecVxRearThres         = -0.5f;

const float     AgeCheckXThres          = 30.0f;

const uint8_t   AgeCheckFusAgeThres     = 10;

const float     CcrObjHeadThres         = 0.5233f;

const float     CcrObjVxThres           = 1.5f;

const float     CcrCloseObjYThres       = 5.0f;

const float     VruToiXolcThres         = 40.0f;

const float     VruToiVyThres           = 10.0f;

const float     VruToiDistThres         = 50.0f;

const float     Degree45ToRad           = 0.785f;

const float     Degree40ToRad           = 0.698f;

const float     VruToiRearXolcThres     = 40.0f;

const float     VruToiRearVyThres       = 10.0f;

const float     VruToiRearDistThres     = -50.0f;

const float     VruCloseObjRangeThres   = 2.0f;

const float     VruCloseObjYThres       = 0.5f;

const float     MaxEgoRoc               = 50000.0f;

const float     MaxRocRaw               = 50000.0f;

const float     MaxFtapRoc              = 100000.0f;

const float     MaxCandiHeading         = 10000.0f;

const float     MaxDeltaR               = 10000.0f;

const float     DefaultCollPos          = 1000.0f;

const float     DefaultPos              = 1000.0f;

const float     DefaultRangeRoc         = 1000.0f;

const float     DefaultPredRoc          = 1000.0f;

const float     DefaultCorner           = 1000.0f;

const float     MinEgoRocThres          = 5000.0f;

const float     DefaultTTC              = 25.5f;

const float     MaxTTC                  = 24.0f;

const float     DefaultTTL              = 25.5f;

const float     DefaultTTT              = 25.0f;

const float     DefaultTTB              = 25.0f;

const float     Pi                      = 2*asinf(1.0);

const float     HalfWidth               = 0.9f;

const float     RearAxleToBack          = 1.5f;

const float     MaxEgoAccThres          = 0.3f;

const float     MaxLatVelThres          = 0.1f;

const float     DefaultRange            = 1000.0f;

const float     MaxCcrVfCheckEgoAcc     = 2.5f;

const uint8_t   MinFusionObjAge         = 10u;

const uint8_t   MinVisionObjAge         = 100u;

const float     MinRadarObjAge          = 30000u;

const float     FrontSafeZone           = 0.5f;

const float     MatchConfThres          = 0.8f;

const float     MinConfThres            = 0.6f;

const float     ToiTargetSpdThrs        = 7.0f;

const float     ToiLatVelThres          = 0.2f;

const float     MinToiTargetAngle       = 1.31f;

const float     MaxToiTargetAngle       = 1.58f;

const float     TargetLengthThres       = 4.5f;

const uint8_t   InPathAgeStep           = 5u;

const uint8_t   MaxInpathAge            = 250u;

const float     WarnTTCBuffer           = 0.2f;

const float     DefaultDeltaAy          = 1000.0f;

const float     RocVehSpdThres          = 1.0f;

const float     RocThres                = 1.0f;

const float     DeltaYawrateThres       = 0.125f;

const float     YawDistTTCThrs          = 7.0f;

const float     HitDistTTCThrs          = 4.0f;

const float     CandiYawrateThres       = 1.0f;

const float     CandiFunnelBuffer       = 0.6f;

const float     CandiTTCThres           = 5.0f;

const float     LengthBuffer1           = 1.2f;

const float     LengthBuffer2           = 1.8f;

const float     ToiRangeThres           = 1.5f;

const float     ToiYThres               = 1.1f;

const float     TargetHeadThres         = 1.1f;

const float     CandiSpdThres           = 0.83f;

const float     CandiYThres             = 1.4f;

const float     CandiRangeRearThres     = 8.0f;

const float     CandiRangeRateThres     = -1.0f;

const float     CandiMinSpd             = 1.5f;

const float     EgoSpdThres             = 1.11f;

const float     CandiMaxRange           = 25.0f;

const float     CandiMaxRangeRate       = 2.0f;

const float     CandiBicYThres          = 2.5f;

const float     CandiBicMaxRange        = 12.0f;

const float     CandiOncYThres          = 1.3f;

const float     LongVelBuffer           = 0.2f;

const float     CheckHostAccThres       = 2.5f;

const uint8_t   MaxLostAge              = 250u;

const float     HostPosTarThres         = -3.8f;

const float     Mps2Kph                 = 3.6f;

const float     McPressThres            = 15.0f;

const float     McPressRateThres        = 800.0f;

const float     BrakePosThres           = 40.0f;

const float     SupressSpdHighThres     = 36.2f;

const float     SupressSpdLowThres      = 22.0f;

const float     SuppressMinSpd          = 2.2f;

const float     SuppressFtapSpdThres    = 11.11f;

const float     SuppressMcPressThres    = 350.0f;

const float     SuppressBrkPos1         = 40.0f;

const float     SuppressBrkPos2         = 70.0f;

const float     SuppressBrkPos3         = 90.0f;

const float     SuppressSteerAngThres   = 180.0f;

const float     SuppressAccPosThres     = 80.0f;

const float     SuppressAccRateThres    = 400.0f;

const float     FusionSpdThres          = 5.88f;

const uint8_t   FusionHoldAgeThres      = 20.0f;

const uint8_t   FusionHoldAgeRearThres  = 20.0f;

const float     HeadCheckThresLow       = 0.523f;

const float     HeadCheckThresMid       = 2.617f;

const float     HeadCheckThresHigh      = 3.15f;

const float     TruckHeadCheckLow       = 0.175;

const float     TruckHeadCheckHigh      = 2.967;

const uint8_t   MaxVelHisNr             = 5;

const uint16_t  AebWtiDelayAge          = 500;


















































} //namespace ad
} //namespace nio

#endif //AEB_CONST_PAR_H_