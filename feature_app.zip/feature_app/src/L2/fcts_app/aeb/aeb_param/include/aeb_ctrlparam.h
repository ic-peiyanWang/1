#pragma once
#include <stdint.h>
namespace nio {
namespace ad {
extern unsigned char stAEBOnOff;
extern unsigned char stTrailerMode;
extern bool          flgSeatBltFrntLeSts;
extern unsigned char stEPBSwt;
extern bool          flgBrkOvht;
extern unsigned char stEPBSts;
extern unsigned char stHDCSts;
extern unsigned char stAVHSts;
extern unsigned char stStandstillSts;
extern bool          flgTCSDeactv;
extern unsigned char stFCWSet;

extern bool FlgTCSActive;
extern bool FlgVDCActive;
extern bool FlgDTCActive;
extern bool FlgABSActive;

extern bool          flgVDCDeactv;
extern unsigned char stDoorAjarFLSts;
extern unsigned char stVehSt;
extern unsigned char stLvlAdjSts;
extern unsigned char stActGear;
extern unsigned char stVehRdy;

extern bool flgAWBAvl;
extern bool flgABAAvl;
extern bool flgAutoBrkgAvl;
extern bool flgEBPAvl;
extern bool flgEBAAvl;

extern bool flgVehStInld;
extern bool flgHMIFail;
extern bool flgADCInternalFault;
extern bool flgLatAccValInvld;
extern bool flgYawrateInvld;
extern bool flgLonAccValInvld;
extern bool flgSeatOccpFrntLeInvld;
extern bool flgSeatOccpFrntLeFailure;
extern bool flgBrkPrsOfsInvld;
extern bool flgVehSpdInvld;
extern bool flgWhlSpdInvld;
extern bool flgWhlPulCntInvld;
extern bool flgBrkPrssInvld;
extern bool flgBrkPdlInvld;
extern bool flgStrngWhlAgSnsrFail;
extern bool flgStrngWhlAgSpdInvld;
extern bool flgStrngWhlAgSnsrNotCal;
extern bool flgAccPdlActPosnInvld;
extern bool flgGearInvld;
extern bool flgSCMLossCommFault;
extern bool flgBCMLossCommFault;
extern bool flgVCULossCommFault;
extern bool flgBCULossCommFault;
extern bool flgACMLossCommFault;
extern bool flgCGWLossCommFault;
extern bool flgCDCLossCommADAS_Fault;
extern bool flgSCMFail;

extern bool flgRADFCLossCommFault;
extern bool flgRADFC_Blindness;
extern bool flgRADFC_Failure;

extern bool flgFS_partialBlockage_2;
extern bool flgFS_partialBlockage_3;
extern bool flgFS_fullBlockage_1;
extern bool flgFS_fullBlockage_2;
extern bool flgFS_fullBlockage_3;
extern bool flgFS_autofixOutOfCalibHorizon;
extern bool flgFS_autofixOutOfCalibYAW;
extern bool flgFS_TSR_outOfCalib_mode;
extern bool flgFS_out_of_focus_2;
extern bool flgFS_out_of_focus_3;
extern bool flgFS_frozenWindshield;
extern bool flgFS_blurredImage_1;
extern bool flgFS_blurredImage_2;
extern bool flgFS_blurredImage_3;
extern bool flgFS_lowSun_3;
extern bool flgFS_splashes_2;
extern bool flgFS_sunRay_1;
extern bool flgFS_sunRay_2;
extern bool flgFS_rain_2;
extern bool flgFS_rain_3;
extern bool flgFS_fog_2;
extern bool flgFS_fog_3;

extern double EBA_pDrvAppBrkPresThr_C;
extern double EBA_dpDrvAppBrkPresGradThr_C;
extern double AEB_pctAbsAccPedOvrd_C;
extern double AEB_pctRelAccPedOvrd_C;
extern double AEB_xRelAccPedRateOvrd_C;
extern double AEB_tiAbsAccPedOvrdTimer_C;
extern double AEB_tiRelAccPedOvrdTimer_C;
extern double AEB_pctStrngWhlAgSpdGain_C;
extern double AEB_xStrngWhlAgSpdOvrd_C;
extern double AEB_xVehYawrateOvrd_C;
extern double FCW_pctAbsAccPedOvrd_C;
extern double FCW_pctRelAccPedOvrd_C;
extern double FCW_xRelAccPedRateOvrd_C;
extern double FCW_tiAbsAccPedOvrdTimer_C;
extern double FCW_tiRelAccPedOvrdTimer_C;
extern double FCW_pctStrngWhlAgSpdGain_C;
extern double FCW_xStrngWhlAgSpdOvrd_C;
extern double FCW_xVehYawrateOvrd_C;
extern double AWB_v1stLvlVehSpdLowerLmt_C;
extern double AWB_v2ndLvlVehSpdLowerLmt_C;
extern double AWB_v3rdLvlVehSpdLowerLmt_C;

extern uint16_t AEB_FWfailsafeMsk;
extern uint16_t AEB_FNfailsafeMsk;
extern uint16_t AEB_LidarfailsafeMsk;
extern uint16_t AEB_RearfailsafeMsk;
}  // namespace ad
}  // namespace nio