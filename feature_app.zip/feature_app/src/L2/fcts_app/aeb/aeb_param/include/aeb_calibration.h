#ifndef AEB_CALIBRATION_H_
#define AEB_CALIBRATION_H_
#include <stdint.h>
//#include "ids_mil.h"
#include "asimov_compiler.h"

#ifndef CAL_VAR
#define CAL_VAR
#endif
extern CAL_VAR bool k_AEBShadowMode_active;
extern CAL_VAR float EAEB_tiTTC_EgoVel_x[5]  ;   // 
extern CAL_VAR float EAEB_tiTTC_RelVel_y[5]  ;   // 
extern CAL_VAR float EAEB_tiTTC_B_v[25]  ;   // 
extern CAL_VAR float EAEB_tiTTC_D_v[25]  ;   // 
extern CAL_VAR float EAEB_tiTTC_E_v[25]  ;   // 
extern CAL_VAR float EAEB_tiOverlapOfs_Overlap_x[5]  ;   // 
extern CAL_VAR float EAEB_tiOverlapOfs_RelVel_y[5]  ;   // 
extern CAL_VAR float EAEB_tiOverlapOfs_v[25]  ;   // 
extern CAL_VAR float EAEB_tiBrkOfs_EgoAcc_x[3]  ;   // 
extern CAL_VAR float EAEB_tiBrkOfs_v[3]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL1_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL1_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedNightL1_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL1_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL1_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleNightL1_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL2_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL2_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedNightL2_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL2_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL2_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleNightL2_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL3_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedL3_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCPedNightL3_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL3_EgoSpd_x[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleL3_v[4]  ;   // 
extern CAL_VAR float EAEB_tiTTCBicycleNightL3_v[4]  ;   // 
extern CAL_VAR float EAEB_dstSide_EgoSpd_x[2]  ;   // 
extern CAL_VAR float EAEB_dstCurrSidePedL1_v[2]  ;   // 
extern CAL_VAR float EAEB_dstPredSidePedL1_v[2]  ;   // 
extern CAL_VAR float EAEB_dstSideBicycleL1_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandPedL1_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandBicycleL1_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCurrSidePedL2_v[2]  ;   // 
extern CAL_VAR float EAEB_dstPredSidePedL2_v[2]  ;   // 
extern CAL_VAR float EAEB_dstSideBicycleL2_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandPedL2_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandBicycleL2_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCurrSidePedL3_v[2]  ;   // 
extern CAL_VAR float EAEB_dstPredSidePedL3_v[2]  ;   // 
extern CAL_VAR float EAEB_dstSideBicycleL3_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandPedL3_v[2]  ;   // 
extern CAL_VAR float EAEB_dstCrossExpandBicycleL3_v[2]  ;   // 
extern CAL_VAR float EAEB_dstVFcheck_LongPos_x[9]  ;   // 
extern CAL_VAR float EAEB_dstVFcheck_LatPos_v[9]  ;   // 
extern CAL_VAR float EAEB_spdVFcheck_LatVel_v[9]  ;   // 
extern CAL_VAR float EAEB_spdLongMove_LongVel_v[9]  ;   // 
extern CAL_VAR float EAEB_spdLatMove_LatVel_v[9]  ;   // 
extern CAL_VAR uint8_t EAEB_agecheck_AEBconf_x[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agelongmove_ageplau_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agecross_ageplau_v[4]  ;   //
extern CAL_VAR uint8_t EAEB_agelongmove_age_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agecross_age_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agecross_age_turn_v[4]  ;   //
extern CAL_VAR uint8_t EAEB_agelongmove_age_warn_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agecross_age_warn_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_agecross_age_turn_warn_v[4]  ;   //
extern CAL_VAR float EAEB_spdSide_hostspd_x[8]  ;   // 
extern CAL_VAR float EAEB_disSide_range_y[8]  ;   // 
extern CAL_VAR float EAEB_dstPredLongPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstPredCrossPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstPredStatPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrLongPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrCrossPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrStatPedBik_v[64]  ;   // 
extern CAL_VAR float EAEB_dstPredLongPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_dstPredCrossPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_dstPredStatPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrLongPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrCrossPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_dstCurrStatPedBik_warn_v[64]  ;   // 
extern CAL_VAR float EAEB_spdExpand_Latvel_x[5]  ;   // 
extern CAL_VAR float EAEB_dstPredExpandSide_v[40]  ;   // 
extern CAL_VAR float EAEB_dstCurrExpandSide_v[40]  ;   // 
extern CAL_VAR float EAEB_dstPredExpandSide_warn_v[40]  ;   // 
extern CAL_VAR float EAEB_dstCurrExpandSide_warn_v[40]  ;   // 
extern CAL_VAR float EAEB_dstPredExpandSide_Bik_v[40]  ;   // 
extern CAL_VAR float EAEB_dstCurrExpandSide_Bik_v[40]  ;   // 
extern CAL_VAR float EAEB_dstPredExpandSide_Bik_warn_v[40]  ;   // 
extern CAL_VAR float EAEB_dstCurrExpandSide_Bik_warn_v[40]  ;   // 
extern CAL_VAR float EAEB_TTCPedBik_Egospd_x[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossPed_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossPed_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossPed_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossPed_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCRearCrossPed_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCRearCrossPed_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCRearCrossPed_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCRearCrossPed_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossBik_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossBik_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossBik_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCCrossBik_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomPed_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomPed_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomPed_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomPed_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomBik_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomBik_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomBik_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCOncomBik_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedPed_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedPed_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedPed_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedPed_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedBik_Pref_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedBik_Warn_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedBik_LowB_v[10]  ;   // 
extern CAL_VAR float EAEB_TTCPrecedBik_HigB_v[10]  ;   // 
extern CAL_VAR float EAEB_dstFunnelRange_x[8]  ;   // 
extern CAL_VAR float EAEB_dstStatInFunnel_v[8]  ;   // 
extern CAL_VAR float EAEB_dstMovInFunnel_v[8]  ;   // 
extern CAL_VAR float EAEB_dstMovOutFunnel_v[8]  ;   // 
extern CAL_VAR float EAEB_dstLongPosCheck_LongPos_x[9]  ;   // 
extern CAL_VAR float EAEB_spdLongPosCheck_Rrate_y[7]  ;   // 
extern CAL_VAR float EAEB_dstLongPosCheck_Poserror_v[63]  ;   // 
extern CAL_VAR float EAEB_spdCCR_egospd_x[12]  ;   // 
extern CAL_VAR float EAEB_spdCCR_RRate_y[12]  ;   // 
extern CAL_VAR float EAEB_TTCLowB_norm_v[144]  ;   // 
extern CAL_VAR float EAEB_TTCHighB_norm_v[144]  ;   // 
extern CAL_VAR float EAEB_TTCPrefill_norm_v[144]  ;   // 
extern CAL_VAR float EAEB_TTCWarn_norm_v[144]  ;   // 
extern CAL_VAR float EAEB_dstCCRdecl_Range_x[8]  ;   // 
extern CAL_VAR float EAEB_accCCRdecl_TargDecl_y[8]  ;   // 
extern CAL_VAR float EAEB_TTCLowB_decel_v[64]  ;   // 
extern CAL_VAR float EAEB_TTCHighB_decel_v[64]  ;   // 
extern CAL_VAR float EAEB_TTCPrefill_decel_v[64]  ;   // 
extern CAL_VAR float EAEB_TTCWarn_decel_v[64]  ;   // 
extern CAL_VAR float EAEB_dstInPath_Range_x[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_HitDistBef_v[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_HitDistAft_v[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_YawDistBef_v[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_YawDistAft_v[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_XOLCBef_v[10]  ;   // 
extern CAL_VAR float EAEB_dstInPath_XOLCAft_v[10]  ;   // 
extern CAL_VAR float EAEB_perTTCcalc_XOLCperc_x[9]  ;   // 
extern CAL_VAR float EAEB_perWarn_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perWarnMO_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perLowB_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perLowBMO_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perPref_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perPrefMO_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perHighB_TTCperc_v[9]  ;   // 
extern CAL_VAR float EAEB_perHighBMO_TTCperc_v[9]  ;   // 
extern CAL_VAR uint8_t EAEB_ageCCR_inpathage_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_ageUndef_inpathage_v[4]  ;   // 
extern CAL_VAR float EAEB_perdeltayawrate_v[9]  ;   // 
extern CAL_VAR float EAEB_dstTarget_Range_x[10]  ;   // 
extern CAL_VAR float EAEB_dstCollisionPoint_Range_y[8]  ;   // 
extern CAL_VAR float EAEB_spdFTAP_egospd_x[8]  ;   // 
extern CAL_VAR float EAEB_spdFTAP_targspd_x[8]  ;   // 
extern CAL_VAR float EAEB_spdOncom_targspd_v[10]  ;   // 
extern CAL_VAR float EAEB_dstFTAP_predictpath_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAP_currentpath_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAPwarn_predictpath_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAPwarn_currentpath_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAP_predictext_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAP_currentext_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAPwarn_predictext_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAPwarn_currentext_v[64]  ;   // 
extern CAL_VAR float EAEB_dstFTAPTOI_Range_v[8]  ;   // 
extern CAL_VAR uint8_t EAEB_ageFTAP_inpathage_v[4]  ;   // 
extern CAL_VAR uint8_t EAEB_ageFTAPwarn_inpathage_v[4]  ;   // 
extern CAL_VAR float EAEB_tiFTAPwarn_TTC_v[8]  ;   // 
extern CAL_VAR float EAEB_tiFTAPpref_TTC_v[8]  ;   // 
extern CAL_VAR float EAEB_tiFTAPlowB_TTC_v[8]  ;   // 
extern CAL_VAR float EAEB_tiFTAPhighB_TTC_v[8]  ;   // 
extern CAL_VAR float EAEB_dstFTAP_predictext_after_v[64]  ;   // 

extern CAL_VAR float EAEB_Dm_Min_Brk_Ped;
extern CAL_VAR float EAEB_Dm_Fdb3_Hardbrk_Ped;
extern CAL_VAR uint8_t EAEB_Dm_Fdb3_Hardbrk_Age;
extern CAL_VAR float EAEB_Dm_Fdb3_Hardbrk_AccThres;
extern CAL_VAR float EAEB_Dm_Fdb2_Hardbrk_Ped;
extern CAL_VAR uint8_t EAEB_Dm_Fdb2_Hardbrk_Age;
extern CAL_VAR float EAEB_Dm_Fb1_DrvMod[5];
extern CAL_VAR float EAEB_Dm_Fdb1_High_Ped[5];
extern CAL_VAR float EAEB_Dm_Fdb1_Low_Ped[5];
extern CAL_VAR float EAEB_Dm_Fdb1_Low_Grad[5];
extern CAL_VAR uint8_t EAEB_Dm_Fdb1_Hardacc_Age;
extern CAL_VAR float EAEB_Dm_Fdb1_Time;
extern CAL_VAR float EAEB_Dm_Fdb2_Time;
extern CAL_VAR float EAEB_Dm_Fdb3_Time;
extern CAL_VAR float EAEB_Dm_Act1Grad_Vx_x[2];
extern CAL_VAR float EAEB_Dm_Act1Grad_StrGrad_y[2];
extern CAL_VAR float EAEB_Dm_Act2Ang_Vx_x[8];
extern CAL_VAR float EAEB_Dm_Act2Ang_StrAng_y[8];
extern CAL_VAR float EAEB_Dm_Act2Grad_Vx_x[2];
extern CAL_VAR float EAEB_Dm_Act2Grad_StrGrad_y[2];
extern CAL_VAR float EAEB_Dm_Act3Grad_Vx_x[2];
extern CAL_VAR float EAEB_Dm_Act3Grad_StrGrad_y[2];
extern CAL_VAR float EAEB_Dm_Act1_Time;
extern CAL_VAR float EAEB_Dm_Act2_Time_Low;
extern CAL_VAR float EAEB_Dm_Act2_Time_High;
extern CAL_VAR float EAEB_Dm_Act3_Time;
extern CAL_VAR float EAEB_Dm_Fo3_Hardbrk_Ped;
extern CAL_VAR uint8_t EAEB_Dm_Fo3_Hardbrk_Age;
extern CAL_VAR float EAEB_Dm_Foc1_High_Grad;
extern CAL_VAR float EAEB_Dm_Foc1_Low_Grad;
extern CAL_VAR float EAEB_Dm_Foc1_Mid_Ped;
extern CAL_VAR float EAEB_Dm_Foc1_Mid_Grad;
extern CAL_VAR float EAEB_Dm_Foc1_Str_Grad;
extern CAL_VAR float EAEB_Dm_Foc2_Min_Velx;
extern CAL_VAR float EAEB_Dm_Foc2Ped_Vx_x[2];
extern CAL_VAR float EAEB_Dm_Foc2Ped_Ped_y[2];
extern CAL_VAR float EAEB_Dm_Foc3_Max_Velx;
extern CAL_VAR float EAEB_Dm_Foc3_Max_Ax;
extern CAL_VAR float EAEB_Dm_Foc4Ax_Vx_x[7];
extern CAL_VAR float EAEB_Dm_Foc4Ax_Ax_y[7];
extern CAL_VAR float EAEB_Dm_Foc1_Time;
extern CAL_VAR float EAEB_Dm_Foc2_Time;
extern CAL_VAR float EAEB_Dm_Foc3_Time;
extern CAL_VAR float EAEB_Dm_Foc4_Time;
extern CAL_VAR float EAEB_Dm_Ccftap_Max_Vel;
extern CAL_VAR float EAEB_Dm_Ccftap_Min_Yawrate;
extern CAL_VAR float EAEB_Dm_Ccftap_Max_StrAng;
extern CAL_VAR float EAEB_Dm_Fwd_Max_Vel;
extern CAL_VAR float EAEB_Dm_Fwd_Min_Vel;
extern CAL_VAR float EAEB_Dm_Bwd_Max_Vel;
extern CAL_VAR float EAEB_Dm_Bwd_Min_Vel;
extern CAL_VAR float EAEB_Dm_Static_Vel;
extern CAL_VAR float EAEB_Dm_Min_Acc_GasPed;

extern CAL_VAR float EAEB_Dm_Sdy_Gasgrad;
extern CAL_VAR float EAEB_Dm_Vel_Dev_Thres;
extern CAL_VAR float EAEB_Dm_Sdy_Time;
extern CAL_VAR float EAEB_Dm_Ramp_Time;
extern CAL_VAR bool  EAEB_Dm_SdyDetect_Switch;

extern CAL_VAR float EAEB_Dm_Foc1_DampFactor[32];
extern CAL_VAR float EAEB_Dm_Foc2_DampFactor[32];
extern CAL_VAR float EAEB_Dm_Foc3_DampFactor[32];
extern CAL_VAR float EAEB_Dm_Foc4_DampFactor[32];

extern CAL_VAR float EAEB_Gof_Max_PedVel;
extern CAL_VAR float EAEB_Gof_Max_BikVel;
extern CAL_VAR float EAEB_Gof_Max_MoBikVel;
extern CAL_VAR float EAEB_Gof_Max_SmallVehVel;
extern CAL_VAR float EAEB_Gof_Max_BigVehVel;
extern CAL_VAR float EAEB_Gof_Max_GenObjVel;
extern CAL_VAR float EAEB_Gof_Max_FusionConf;
extern CAL_VAR float EAEB_Gof_Max_VisConf;
extern CAL_VAR float EAEB_Gof_Max_RadarConf;
extern CAL_VAR uint8_t EAEB_Gof_Max_FusionAge;
extern CAL_VAR uint8_t EAEB_Gof_Max_VisAge;
extern CAL_VAR uint8_t EAEB_Gof_Max_RadarAge;

extern CAL_VAR float EAEB_dstCollisionPoint_Range_CCC_y[8];
extern CAL_VAR float EAEB_spdccc_egospd_x[8];
extern CAL_VAR float EAEB_spdccc_targspd_x[8];
extern CAL_VAR float EAEB_dstccc_predictpath_v[64];
extern CAL_VAR float EAEB_dstccc_currentpath_v[64];
extern CAL_VAR float EAEB_dstcccwarn_predictpath_v[64];
extern CAL_VAR float EAEB_dstcccwarn_currentpath_v[64];
extern CAL_VAR float EAEB_dstccc_predictext_v[64];
extern CAL_VAR float EAEB_dstccc_currentext_v[64];
extern CAL_VAR float EAEB_dstcccwarn_predictext_v[64];
extern CAL_VAR float EAEB_dstcccwarn_currentext_v[64];
extern CAL_VAR float EAEB_dstCCCTOI_Range_v[8];
extern CAL_VAR uint8_t EAEB_ageCCC_inpathage_v[4];
extern CAL_VAR uint8_t EAEB_ageCCCwarn_inpathage_v[4];
extern CAL_VAR float EAEB_tiCCCwarn_TTC_v[8];
extern CAL_VAR float EAEB_tiCCCpref_TTC_v[8];
extern CAL_VAR float EAEB_tiCCClowB_TTC_v[8];
extern CAL_VAR float EAEB_tiCCChighB_TTC_v[8];
extern CAL_VAR float EAEB_dstccc_predictext_after_v[64];
extern CAL_VAR float k_yawratefilter_limit;
extern CAL_VAR float EAEB_dstccr_timetobrake_safezone_v[12];
extern CAL_VAR float EAEB_dstccr_timetoturn_safelat_v[9];
extern CAL_VAR float EAEB_TTB_offset_v[144];
extern CAL_VAR float EAEB_TTT_offset_v[108];
extern CAL_VAR float EAES_spdCCR_range_x[10];
extern CAL_VAR float EAES_spdCCR_RRate_y[10];
extern CAL_VAR float EAES_InPath_current_v[100];
extern CAL_VAR float EAES_InPath_predict_v[100];
extern CAL_VAR uint8_t EAES_InPath_age_v[4];
extern CAL_VAR float k_AESLateralSafeZone;
extern CAL_VAR float k_AESMaxPlanRange;
extern CAL_VAR float k_AESMinPlanRange;
extern CAL_VAR float k_AESInLaneC1_limitation;
extern CAL_VAR float k_AESDefaultVehicleWidth;
extern CAL_VAR uint8_t k_AESHoldAge;
extern CAL_VAR uint8_t k_AESExternReq;
extern CAL_VAR float EAES_egospd_x[8];
extern CAL_VAR float EAES_latacc_threshold_v[8];
extern CAL_VAR uint8_t k_AESMaxLongEsti;
extern CAL_VAR float k_AESLongCostGain;
extern CAL_VAR float k_AESLatCostGain;
extern CAL_VAR bool  kAebRearEnable;
extern CAL_VAR bool  kAebShadowModeSoft;
extern CAL_VAR bool  kAebHilMode;

extern CAL_VAR float EAEB_dmsteer_egospd_x[12];
extern CAL_VAR float EAEB_dmsteer_stwangle_v[12];
extern CAL_VAR float EAEB_dmsteer_yawrate_v[12];
extern CAL_VAR float k_single_target_increase;
extern CAL_VAR float k_drive_straight_decrease;
extern CAL_VAR float EAEB_TTCWarn_addins_v[144];
extern CAL_VAR float EAEB_TTCWarn_deceladdins_v[64];
extern CAL_VAR float EAEB_overtake_steerangle_v[12];
extern CAL_VAR float EAEB_overtake_gasped_v[12];
extern CAL_VAR bool k_add_motor_inccr;
extern CAL_VAR bool k_add_undef_inccr;
#endif // AEB_CALIBRATION_H_