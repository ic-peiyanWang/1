#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aes_planning.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {
    aes_plan aes_path_plan_;

    aes_plan::aes_plan() {}

    void aes_plan::MainFunction() {
        UpdateCalibration();
        PathPlan();
    }

    void aes_plan::UpdateCalibration() {
        size_t egospd_size = sizeof(EAES_egospd_x) / sizeof(EAES_egospd_x[0]);
        threshold_AES_route_latacc_.init(EAES_egospd_x, EAES_latacc_threshold_v, egospd_size);
    }

    void aes_plan::UpdateParameter() {
        host_lane_lpp.isvalid = (ego_->ehy_lpp.trajectory.pt_conf >= 0.3) ? 1: 0;
        host_lane_lpp.path_c0 = ego_->ehy_lpp.trajectory.c0;
        host_lane_lpp.path_c1 = ego_->ehy_lpp.trajectory.c1;
        host_lane_lpp.path_c2 = ego_->ehy_lpp.trajectory.c2;
        host_lane_lpp.path_c3 = ego_->ehy_lpp.trajectory.c3;
        host_lane_lpp.width = ego_->ehy_lpp.trajectory.lm_width;
    }

    void aes_plan::PathPlan() {
        UpdateParameter();
        ClearRout();
        if (aes_candidate.AESCCR1_Candi_.steer_flag > 0 || aes_candidate.AESCCR2_Candi_.steer_flag > 0) {
            PlanFirstPath();
            PlanAlterPath();
            for (int i = 0; i <=5; i++) {
                aes_path_group_lf[i] = aes_path_group[i];
            }
        }
        else {
            for (int i = 0; i <=5; i++) {
                aes_path_group[i] = aes_path_group_lf[i];
                aes_path_group[i].explon = aes_path_group[i].explon - (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * 0.02);
            }
        }

        for (int i = 0; i <= 5; i++) {
            FiltAESPath(aes_path_group[i]);
        }        
    }

    void aes_plan::PlanFirstPath() {
        float vehspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        aes_path_group[0].cos_a = (host_lane_lpp.path_c0 - aes_ctrl_input.explatdst)/2 * aes_ctrl_input.steering_direction;
        aes_path_group[0].cos_b = Pi/aes_ctrl_input.explondst;
        aes_path_group[0].cos_phi = asinf(((-2 * host_lane_lpp.path_c1 * aes_ctrl_input.explondst)/(Pi * (host_lane_lpp.path_c0 - aes_ctrl_input.explatdst))) * aes_ctrl_input.steering_direction);
        aes_path_group[0].cos_n = (host_lane_lpp.path_c0 + aes_ctrl_input.explatdst)/2;
        aes_path_group[0].curv = ego_->ehy_lpp.trajectory.c2;
        aes_path_group[0].dcurv = ego_->ehy_lpp.trajectory.c3;
        aes_path_group[0].explat = aes_ctrl_input.explatdst;
        aes_path_group[0].explon = aes_ctrl_input.explondst;
        aes_path_group[0].max_ay = -2 * aes_path_group[0].cos_a * aes_path_group[0].cos_b * aes_path_group[0].cos_b * vehspd * vehspd;
        aes_path_group[0].isvalid = 1;
        CalcRoutCost(aes_path_group[0], aes_candidate.AESCCR1_Candi_, host_lane_lpp);
        last_valid_rout = 1;
    }

    void aes_plan::PlanAlterPath() {
        float vehspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        longpos_min = aes_ctrl_input.explondst;
        
        float latacc_threshold = threshold_AES_route_latacc_.interpolate(vehspd);
        
        if (aes_ctrl_input.steering_direction == -1) {
            latpos_inner = aes_ctrl_input.explatdst;
            latpos_outer = host_lane_lpp.width/2 - 0.8;
        }
        else if (aes_ctrl_input.steering_direction == 1) {
            latpos_inner = aes_ctrl_input.explatdst;
            latpos_outer = (host_lane_lpp.width/2) * -1 + 0.8;
        } 

        if (fabsf(latpos_inner) <= fabsf(latpos_outer)) {
            latshift_valid = 1;
        }
        else {
            latshift_valid = 0;
        } 

        float longpos_dest = aes_ctrl_input.explondst * k_AESMaxLongEsti;
        float latpos_dest = latpos_inner;

        longplan_cnt = 0;
        latplan_cnt = 0;
        
        while (longpos_dest > longpos_min && longpos_dest >= 3.9 && longplan_cnt < 50) {

            longpos_dest = longpos_dest - 1;
            longplan_cnt ++;

            while (fabsf(latpos_dest) < fabsf(latpos_outer) && latshift_valid == 1 && latplan_cnt < 30) {
                latplan_cnt ++;
                latpos_dest = latpos_dest + (0.1 * (aes_ctrl_input.steering_direction));

                AES_Plan_Group tmp_rout;
                tmp_rout.cos_a = (host_lane_lpp.path_c0 - aes_ctrl_input.explatdst)/2 * aes_ctrl_input.steering_direction;
                tmp_rout.cos_b = Pi/longpos_dest;
                tmp_rout.cos_phi = asinf(((-2 * host_lane_lpp.path_c1 * longpos_dest)/(Pi * (host_lane_lpp.path_c0 - latpos_dest))) * aes_ctrl_input.steering_direction);
                tmp_rout.cos_n = (host_lane_lpp.path_c0 + latpos_dest)/2;
                tmp_rout.curv = ego_->ehy_lpp.trajectory.c2;
                tmp_rout.dcurv = ego_->ehy_lpp.trajectory.c3;
                tmp_rout.explat = latpos_dest;
                tmp_rout.explon = longpos_dest;
                tmp_rout.max_ay = -2 * tmp_rout.cos_a * tmp_rout.cos_b * tmp_rout.cos_b * vehspd * vehspd;

                rout_valid = CheckRoutValid(tmp_rout, aes_candidate.AESCCR1_Candi_, longpos_dest);

                latacc_valid = (tmp_rout.max_ay <= latacc_threshold)?1:0;

                tmp_rout.isvalid = (rout_valid == 1 && latacc_valid == 1);

                CalcRoutCost(tmp_rout, aes_candidate.AESCCR1_Candi_, host_lane_lpp);

                if (rout_valid == 1 && latacc_valid == 1) {
                    for (int rout_i = 0; rout_i <= 5; rout_i ++) {
                        if (tmp_rout.rout_cost < aes_path_group[rout_i].rout_cost) {
                            for (int ch_i = rout_i; ch_i <= 4; ch_i ++) {
                                int tar_i = ch_i + 1;
                                aes_path_group[tar_i] = aes_path_group[ch_i];
                            }
                            aes_path_group[rout_i] = tmp_rout;
                        }
                    }
                    aes_path_group[last_valid_rout] = tmp_rout;
                    aes_path_group[last_valid_rout].isvalid = 1;
                    last_valid_rout ++;
                }
            }            
        }
    }

    bool aes_plan::CheckRoutValid(AES_Plan_Group aes_rout, AESObjectCCR aes_candi, float longposest) {
        float vehspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        // float ttc_max = longposest/vehspd;
        float longpos_start = 0;
        float remain_time = 25.5;
        float routeisvalid = false;

        AESObjectCCR tmp_obj = aes_candi;
        CalcFrenetPoint(tmp_obj.center_point, host_lane_lpp);
        CalcFrenetPoint(tmp_obj.close_left, host_lane_lpp);
        CalcFrenetPoint(tmp_obj.close_right, host_lane_lpp);
        CalcFrenetPoint(tmp_obj.remote_left, host_lane_lpp);
        CalcFrenetPoint(tmp_obj.remote_right, host_lane_lpp);

        while (longpos_start < longposest) {
            longpos_start = longpos_start + 1;
            remain_time = longpos_start/vehspd;

            CalcFrenetEsti(tmp_obj.center_point, remain_time, tmp_obj.obj.motion.GetVy(), tmp_obj.obj.motion.GetVx());
            CalcFrenetEsti(tmp_obj.close_left, remain_time, tmp_obj.obj.motion.GetVy(), tmp_obj.obj.motion.GetVx());
            CalcFrenetEsti(tmp_obj.close_right, remain_time, tmp_obj.obj.motion.GetVy(), tmp_obj.obj.motion.GetVx());
            CalcFrenetEsti(tmp_obj.remote_left, remain_time, tmp_obj.obj.motion.GetVy(), tmp_obj.obj.motion.GetVx());
            CalcFrenetEsti(tmp_obj.remote_right, remain_time, tmp_obj.obj.motion.GetVy(), tmp_obj.obj.motion.GetVx());

            float latpos_cos = aes_rout.cos_a * cosf(aes_rout.cos_b * longpos_start + aes_rout.cos_phi) + aes_rout.cos_n;

            float center_range = sqrtf(powf((tmp_obj.center_point.long_est - longpos_start), 2) + powf((tmp_obj.center_point.lat_est - latpos_cos), 2));
            float closel_range = sqrtf(powf((tmp_obj.close_left.long_est - longpos_start), 2) + powf((tmp_obj.close_left.lat_est - latpos_cos), 2));
            float closer_range = sqrtf(powf((tmp_obj.close_right.long_est - longpos_start), 2) + powf((tmp_obj.close_right.lat_est - latpos_cos), 2));
            float remotel_range = sqrtf(powf((tmp_obj.remote_left.long_est - longpos_start), 2) + powf((tmp_obj.remote_left.lat_est - latpos_cos), 2));
            float remoter_range = sqrtf(powf((tmp_obj.remote_right.long_est - longpos_start), 2) + powf((tmp_obj.remote_right.lat_est - latpos_cos), 2));

            routeisvalid = ((center_range >= 0.9) && (closel_range >= 0.9) && (closer_range >= 0.9) && (remotel_range >= 0.9) && (remoter_range >= 0.9)) ?1:0;

            if (routeisvalid == 0) {
                break;
            }
        }
        return routeisvalid;        
    }

    void aes_plan::FiltAESPath(AES_Plan_Group &aes_rout) {
        if (aes_rout.isvalid == 1) {
            if (aes_rout.explon >= k_AESMinPlanRange && aes_rout.explon <= k_AESMaxPlanRange) {
                aes_rout.explon = aes_rout.explon;
            }
            else if (aes_rout.explon > k_AESMaxPlanRange) {
                aes_rout.explon = k_AESMaxPlanRange;
            }
            else {
                aes_rout.explon = k_AESMinPlanRange;
            }
        }
    }

    void aes_plan::CalcFrenetEsti(CornerPos &cornerpoint, float remain_time, float latspd_tar, float longspd_tar) {
        cornerpoint.lat_est = cornerpoint.cur_y + latspd_tar * remain_time;
        cornerpoint.long_est = cornerpoint.cur_x + longspd_tar * remain_time;
    }

    void aes_plan::CalcFrenetPoint(CornerPos &cornerpoint, Lpp_Poli lpp_lane) {
        float vehspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        cornerpoint.cur_x = cornerpoint.pos_x;
        float frenet_roc = 50000;
        if (fabsf(lpp_lane.path_c2) < 0.001) {
            frenet_roc = 50000;
        }
        else {
            frenet_roc = 1/(2 * lpp_lane.path_c2);
        }
        float distance_tar = sqrtf(cornerpoint.pos_x * cornerpoint.pos_x + cornerpoint.pos_y * cornerpoint.pos_y);
        float y_offset = 0;
        y_offset = deltay(frenet_roc, distance_tar, vehspd);
        cornerpoint.cur_y = cornerpoint.pos_y - y_offset + lpp_lane.path_c0;
    }

    float aes_plan::deltay(float ROC, float Distance, float egospd) {
        if (powf(Distance, 2) / (ROC * 2)>= DefaultDeltaAy || (ROC <= RocThres && ROC >= 0.0F)) {
            return DefaultDeltaAy;
        } else if (powf(Distance, 2) / (ROC * 2) <= -DefaultDeltaAy ||
                    (ROC >= -RocThres && ROC < 0.0F)) {
            return -DefaultDeltaAy;
        } else {
            return powf(Distance, 2) / (ROC * 2);
        }
    }

    void aes_plan::CalcRoutCost(AES_Plan_Group &aes_rout, AESObjectCCR aes_candi, Lpp_Poli lpp_lane) {
        //Taowen: 20220111 there may be better solution for this cost estimation.
        float shiftrange = fabsf(aes_rout.explat - lpp_lane.path_c0);
        float longrangeoffset = fabsf(k_AESMaxLongEsti - aes_rout.explon);
        aes_rout.rout_cost = shiftrange * k_AESLatCostGain + longrangeoffset * k_AESLongCostGain;
    }

    void aes_plan::ClearRout() {
        for (int i = 0; i <= 5; i++) {
            ClearIndiRout(aes_path_group[i]);
        }
    }

    void aes_plan::ClearIndiRout(AES_Plan_Group &aes_rout) {
        aes_rout.cos_a = 0;
        aes_rout.cos_b = 0;
        aes_rout.cos_phi = 0;
        aes_rout.cos_n = 0;
        aes_rout.curv = 0;
        aes_rout.dcurv = 0;
        aes_rout.explat = 0;
        aes_rout.explon = 0;
        aes_rout.isvalid = 0;
        aes_rout.rout_cost = 100;
        aes_rout.max_ay = 0;
    }

}
}