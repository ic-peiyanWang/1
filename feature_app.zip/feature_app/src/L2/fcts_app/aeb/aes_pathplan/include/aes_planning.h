#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"
  

#ifndef AES_PLANNING_H_
#define AES_PLANNING_H_

namespace nio {
namespace ad {
    class aes_plan {
        public:
        aes_plan();

        void MainFunction();

        private:

        void UpdateCalibration();

        void PathPlan();

        void PlanFirstPath();

        void PlanAlterPath();

        void UpdateParameter();

        bool CheckRoutValid(AES_Plan_Group aes_rout, AESObjectCCR aes_candi, float longposest);

        void CalcFrenetPoint(CornerPos &cornerpoint, Lpp_Poli lpp_lane);

        void CalcFrenetEsti(CornerPos &cornerpoint, float remain_time, float latspd_tar, float longspd_tar);

        void CalcRoutCost(AES_Plan_Group &aes_rout, AESObjectCCR aes_candi, Lpp_Poli lpp_lane);

        void ClearRout();

        void ClearIndiRout(AES_Plan_Group &aes_rout);

        void FiltAESPath(AES_Plan_Group &aes_rout);

        float deltay(float ROC, float Distance, float egospd);

        float latpos_inner = 0;

        float latpos_outer = 0;

        bool latshift_valid = 0;

        float longpos_max = 0;

        float longpos_min = 0;

        uint8_t last_valid_rout = 1;

        bool rout_valid = 0;

        bool latacc_valid = 0;

        uint8_t longplan_cnt = 0;

        uint8_t latplan_cnt = 0;

        feature::math::LinearInterpolator<float> threshold_AES_route_latacc_;

    };
    extern aes_plan aes_path_plan_;
}
}
#endif   