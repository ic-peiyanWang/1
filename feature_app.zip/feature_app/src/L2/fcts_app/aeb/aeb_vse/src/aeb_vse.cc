#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aeb_vse.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"


namespace nio {
namespace ad {
    aeb_vse aeb_vse_;

    aeb_vse::aeb_vse() {}

    void aeb_vse::MainFunction() {
        vehicle_state_filter();

        vehicle_state_update();
    }

    void aeb_vse::vehicle_state_filter() {

        if (fabsf(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps) <= k_yawratefilter_limit) {
            ego_state_aeb.yawrate = ego_state_aeb.yawrate + (arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps - ego_state_aeb.yawrate) * 0.2;
        }
        else {
            ego_state_aeb.yawrate = arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps;
        }        
    }

    void aeb_vse::vehicle_state_update() {
        float ego_ROC = MaxEgoRoc;
        ego_ROC = ROC(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ego_state_aeb.yawrate);
        ego_state_aeb.vehspd = arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        ego_state_aeb.strwhlangle = arb_sin->vehicleinfo_in.steersys.StrWhlAg;
        ego_state_aeb.hostreverse = hostReverse;
        ego_state_aeb.brakepos = arb_sin->vehicleinfo_in.brakesys.BrkPdl.Trvl;
        ego_state_aeb.driverpress = driverpress;
        ego_state_aeb.maincypress = arb_sin->vehicleinfo_in.brakesys.BrkPrs.BrkPrs;
        ego_state_aeb.maincypressrate = arb_sin->vehicleinfo_in.brakesys.BrkPrs.BrkPrsGrad;
        ego_state_aeb.steerrate = ego_->vehicleinfo_in.steersys.StrWhlAgSpd;
        ego_state_aeb.roc = ego_ROC;
        ego_state_aeb.accpos = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn;
    }

    float aeb_vse::ROC(float vehspd, float yrate) {
        if (fabsf(vehspd) >= 1.0) {
            if (vehspd / yrate >= MaxEgoRoc || yrate == 0.0f) {
            return MaxEgoRoc;
            } else if (vehspd / yrate <= -MaxEgoRoc) {
            return -MaxEgoRoc;
            } else {
            return vehspd / yrate;
            }
        }
        else {
            return MaxEgoRoc;
        }
    }
}
}