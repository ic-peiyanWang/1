#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"


#ifndef FEATURE_AEB_VSE_H_
#define FEATURE_AEB_VSE_H_

namespace nio {
namespace ad {
    class aeb_vse {
        public:
        aeb_vse();

        void MainFunction();

        private:
        void vehicle_state_filter();

        void vehicle_state_update();

        float ROC(float vehspd, float yrate);
    };

    extern aeb_vse aeb_vse_;
}
}
#endif