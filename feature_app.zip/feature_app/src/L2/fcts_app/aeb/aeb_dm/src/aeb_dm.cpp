#include <iostream>
#include "aeb_dm.h"
#include "aeb_calibration.h"
#include "ehy_math/nio_vmath.h"

namespace nio{
namespace ad{
    
DriverMonitor::DriverMonitor(){}
DriverMonitor::~DriverMonitor(){}

void DriverMonitor::GetInput()
{
    input_.gaspedpos          = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn;
    input_.gaspedgrad         = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate;

    input_.driverbraking      = (ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts == BrkPdlSts_e::Prssd &&
                                 ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl >= EAEB_Dm_Min_Brk_Ped);

    input_.brkpedpos          = ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl;

    input_.steerwhlang        = fabs(ego_->vehicleinfo_in.steersys.StrWhlAg);
    input_.steerwhlgrad       = fabs(ego_->vehicleinfo_in.steersys.StrWhlAgSpd);

    input_.ego_velx           = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
    input_.ego_ax             = ego_->vehicleinfo_in.vehicledynamic.LgtAmpss;
    input_.ego_yawrate        = fabs(ego_->vehicleinfo_in.vehicledynamic.YawRateRps);

    input_.turnlight_on       = (ego_->vehicleinfo_in.vehicledrive.TurnIndcrSwtSts == TrnIndcrSwSt_e::Left ||
                                 ego_->vehicleinfo_in.vehicledrive.TurnIndcrSwtSts == TrnIndcrSwSt_e::Right);

    input_.ego_gear           = ego_->vehicleinfo_in.vehiclept.Gear.ActGear;

    input_.drive_mode         = (static_cast<uint8_t>(ego_->vehicleinfo_in.vehicledrive.VehAccrMod) <= 4) ? 
                                static_cast<uint8_t>(ego_->vehicleinfo_in.vehicledrive.VehAccrMod):0;

    if (AEBDumpSuppress > 0) {
        AEBDumpSuppress = AEBDumpSuppress - 1;
        output_.dampsuppressed = 1;
    }
    else {
        AEBDumpSuppress = 0;
        output_.dampsuppressed = 0;
    }

}

void DriverMonitor::CalcFeedbackState()
{

    uint8_t ret = 0;

    bool fb3_hardbrake = false;
    bool fb2_hardbrake = false;

    if (input_.driverbraking == true && input_.brkpedpos > EAEB_Dm_Fdb3_Hardbrk_Ped && input_.ego_ax <= EAEB_Dm_Fdb3_Hardbrk_AccThres)
    {
        fb3_hardbrake_age_++;
    }
    else
    {
        fb3_hardbrake_age_ = 0;
    }

    if (input_.driverbraking == true && input_.brkpedpos > EAEB_Dm_Fdb2_Hardbrk_Ped)
    {
        fb2_hardbrake_age_++;
    }
    else
    {
        fb2_hardbrake_age_ = 0;
    }

    fb3_hardbrake_age_ = fmin(fb3_hardbrake_age_, EAEB_Dm_Fdb3_Hardbrk_Age);
    fb2_hardbrake_age_ = fmin(fb2_hardbrake_age_, EAEB_Dm_Fdb2_Hardbrk_Age);


    if(fb3_hardbrake_age_ >= EAEB_Dm_Fdb3_Hardbrk_Age)
    {
        fb3_hardbrake = true;
    }
    else if(fb2_hardbrake_age_ >= EAEB_Dm_Fdb2_Hardbrk_Age)
    {
        fb2_hardbrake = true;
    }

    bool fb1_hardaccel = false;

    fb1_gasped_high_thres_.init(EAEB_Dm_Fb1_DrvMod, EAEB_Dm_Fdb1_High_Ped, 5);
    fb1_gasped_low_thres_.init(EAEB_Dm_Fb1_DrvMod, EAEB_Dm_Fdb1_Low_Ped, 5);
    fb1_gasgrad_low_thres_.init(EAEB_Dm_Fb1_DrvMod, EAEB_Dm_Fdb1_Low_Grad, 5);

    if(input_.gaspedpos >= fb1_gasped_high_thres_.interpolate(input_.drive_mode) ||
        (input_.gaspedpos >= fb1_gasped_low_thres_.interpolate(input_.drive_mode) && input_.gaspedgrad >= fb1_gasgrad_low_thres_.interpolate(input_.drive_mode)))
    {
        fb1_hardaccel_age_++;
    }
    else{
        fb1_hardaccel_age_ = 0;
    }

    fb1_hardaccel_age_ = fmin(fb1_hardaccel_age_, EAEB_Dm_Fdb1_Hardacc_Age);

    if(fb1_hardaccel_age_ >= EAEB_Dm_Fdb1_Hardacc_Age)
    {
        fb1_hardaccel = true;
    }

    feedback_lvl3_timer_      = fmax(feedback_lvl3_timer_   - ArbCycleTime, 0.0);
    feedback_lvl2_timer_      = fmax(feedback_lvl2_timer_   - ArbCycleTime, 0.0);
    feedback_lvl1_timer_      = fmax(feedback_lvl1_timer_   - ArbCycleTime, 0.0);

    if(fb3_hardbrake == true)
    {
        feedback_lvl3_timer_  = EAEB_Dm_Fdb3_Time;
        feedback_lvl1_timer_  = 0;
    }
    else if(fb2_hardbrake == true)
    {
        feedback_lvl2_timer_  = EAEB_Dm_Fdb2_Time;
        feedback_lvl1_timer_  = 0;
    }

    if(fb1_hardaccel == true)
    {
        feedback_lvl1_timer_  = EAEB_Dm_Fdb1_Time;
        feedback_lvl3_timer_  = 0;
        feedback_lvl2_timer_  = 0;
    }

    
    if (feedback_lvl1_timer_ > 0.0)
    {
        ret = 1;
    }
    else if (feedback_lvl3_timer_ > 0.0)
    {
        ret = 3;
    }

    else if (feedback_lvl2_timer_ > 0.0)
    {
        ret = 2;
    }
    else
    {
        ret = 0;
    }

    output_.feedbackstate = ret;

}

void DriverMonitor::CalcActivityState()
{
    uint8_t ret = 0;

    act_lvl2_timer_   = fmax(act_lvl2_timer_ - ArbCycleTime, 0.0);
    act_lvl1_timer_   = fmax(act_lvl1_timer_ - ArbCycleTime, 0.0);
    act_lvl3_timer_   = fmax(act_lvl3_timer_ - ArbCycleTime, 0.0);

    act2_ang_thres_.init(EAEB_Dm_Act2Ang_Vx_x, EAEB_Dm_Act2Ang_StrAng_y, 8);
    act2_grad_thres_.init(EAEB_Dm_Act2Grad_Vx_x, EAEB_Dm_Act2Grad_StrGrad_y, 2);
    act1_grad_thres_.init(EAEB_Dm_Act1Grad_Vx_x, EAEB_Dm_Act1Grad_StrGrad_y, 2);
    act3_grad_thres_.init(EAEB_Dm_Act3Grad_Vx_x, EAEB_Dm_Act3Grad_StrGrad_y, 2);

    if (input_.steerwhlang > act2_ang_thres_.interpolate(input_.ego_velx))
    {
        act_lvl2_timer_  = fmax(act_lvl2_timer_, EAEB_Dm_Act2_Time_Low);
    }
    if (input_.steerwhlgrad > act2_grad_thres_.interpolate(input_.ego_velx) && input_.steerwhlang > 20)
    {
        act_lvl2_timer_  = fmax(act_lvl2_timer_, EAEB_Dm_Act2_Time_High);
    }
    if (input_.steerwhlgrad > act1_grad_thres_.interpolate(input_.ego_velx))
    {
        act_lvl1_timer_  = fmax(act_lvl1_timer_, EAEB_Dm_Act1_Time);
    }
    if (input_.steerwhlgrad > act3_grad_thres_.interpolate(input_.ego_velx))
    {
        act_lvl3_timer_  = fmax(act_lvl3_timer_, EAEB_Dm_Act3_Time);
    }

    if (act_lvl3_timer_ > 0.0)
    {
        ret = 3;
    }
    else if (act_lvl2_timer_ > 0.0)
    {
        ret = 2;
    }
    else if (act_lvl1_timer_ > 0.0)
    {
        ret = 1;
    }
    else
    {
        ret = 0;
    }

    output_.activitystate = ret;

}

void DriverMonitor::CalcFocusState()
{
    uint8_t ret                     = 0;

    focus_lvl4_timer_           = fmax(focus_lvl4_timer_ - ArbCycleTime, 0.0);
    focus_lvl3_timer_           = fmax(focus_lvl3_timer_ - ArbCycleTime, 0.0);
    focus_lvl2_timer_           = fmax(focus_lvl2_timer_ - ArbCycleTime, 0.0);
    focus_lvl1_timer_           = fmax(focus_lvl1_timer_ - ArbCycleTime, 0.0);

    focus2_gasped_thres_.init(EAEB_Dm_Foc2Ped_Vx_x, EAEB_Dm_Foc2Ped_Ped_y, 2);
    focus4_ax_thres_.init(EAEB_Dm_Foc4Ax_Vx_x, EAEB_Dm_Foc4Ax_Ax_y, 7);

    bool fo_hardbrake = false;

    if (input_.driverbraking == true && input_.brkpedpos > EAEB_Dm_Fo3_Hardbrk_Ped)
    {
        fo_hardbrake_age_++;
    }
    else
    {
        fo_hardbrake_age_ = 0;
    }

    fo_hardbrake_age_ = fmin(fo_hardbrake_age_, EAEB_Dm_Fo3_Hardbrk_Age);

    if(fo_hardbrake_age_ >= EAEB_Dm_Fo3_Hardbrk_Age)
    {
        fo_hardbrake = true;
    }

    if ( input_.ego_ax <= focus4_ax_thres_.interpolate(input_.ego_velx) &&
            output_.dampsuppressed == false )
    {
        focus_lvl4_timer_       = EAEB_Dm_Foc4_Time;
        focus_lvl3_timer_       = EAEB_Dm_Foc3_Time;
        focus_lvl2_timer_       = EAEB_Dm_Foc2_Time;
        focus_lvl1_timer_       = EAEB_Dm_Foc1_Time;
    }
    else
    {
        if ( (fo_hardbrake == true) && 
                (input_.ego_velx < EAEB_Dm_Foc3_Max_Velx) &&
                (input_.ego_ax <= EAEB_Dm_Foc3_Max_Ax) &&
                output_.dampsuppressed == false)
        {
            focus_lvl3_timer_   = EAEB_Dm_Foc3_Time;
            focus_lvl2_timer_   = EAEB_Dm_Foc2_Time;
            focus_lvl1_timer_   = EAEB_Dm_Foc1_Time;
        }
        else
        {
            if ( (input_.gaspedpos > focus2_gasped_thres_.interpolate(input_.ego_velx) )
                || ((input_.turnlight_on == true) && (input_.ego_velx >= EAEB_Dm_Foc2_Min_Velx) )
                )
            {
                focus_lvl2_timer_   = EAEB_Dm_Foc2_Time;
                focus_lvl1_timer_   = EAEB_Dm_Foc1_Time;
            }
            else
            {
                if ( (input_.gaspedgrad > EAEB_Dm_Foc1_High_Grad)
                    || (input_.gaspedgrad < EAEB_Dm_Foc1_Low_Grad)
                    || ((input_.gaspedgrad < EAEB_Dm_Foc1_Mid_Grad) && (input_.gaspedpos < EAEB_Dm_Foc1_Mid_Ped))
                    || (input_.steerwhlgrad > EAEB_Dm_Foc1_Str_Grad)
                    )
                {
                    focus_lvl1_timer_   = EAEB_Dm_Foc1_Time;
                }
            }
        }
    }

    if (focus_lvl4_timer_ > 0.0)
    {
        ret = 4;
    }
    else if (focus_lvl3_timer_ > 0.0)
    {
        ret = 3;
    }
    else if (focus_lvl2_timer_ > 0.0)
    {
        ret = 2;
    }
    else if (focus_lvl1_timer_ > 0.0)
    {
        ret = 1;
    }
    else
    {
        ret = 0;
    }

    output_.focusstate = ret;

}

void DriverMonitor::SdyDetect(){
    output_.ramptimer = fmax(output_.ramptimer - ArbCycleTime, 0.0);
    for(int i = 0; i < MaxVelHisNr-1; i++){
        vel_hist[i] = vel_hist[i+1];
    }
    vel_hist[MaxVelHisNr-1] = input_.ego_velx;
    output_.vel_std_dev = StDev(vel_hist, MaxVelHisNr);
    if(input_.gaspedpos > 0.0 && fabs(input_.gaspedgrad) < EAEB_Dm_Sdy_Gasgrad && output_.vel_std_dev <= EAEB_Dm_Vel_Dev_Thres){
        output_.sdytimer += ArbCycleTime;
    }
    else{
         output_.sdytimer = 0;
    }
    if(output_.sdytimer >= EAEB_Dm_Sdy_Time){
        output_.ramptimer = EAEB_Dm_Ramp_Time;
    }
}

void DriverMonitor::SetSuppress()
{
    CalcFeedbackState();
    CalcActivityState();

    output_.suppressbit        &= 0x00000000;
    output_.abortbit           &= 0x00000000;

    if (output_.activitystate > 0 || output_.feedbackstate > 0)
    {
        if(output_.activitystate >= 2)
        {
            output_.suppressbit    |= (0xFFA00000);
            output_.abortbit       |= (0xFFA00000);
        }

        if(output_.feedbackstate == 1)
        {
            output_.suppressbit    |= (0xFFE00000);
            output_.abortbit       |= (0x1FE00000);
        }
        else if(output_.feedbackstate == 2)
        {
            output_.suppressbit    |= (0x1C000000);
            output_.abortbit       |= (0x1C000000);
        }
        else if(output_.feedbackstate == 3)
        {
            output_.suppressbit    |= (0x7F600000);
            output_.abortbit       |= (0x1C000000);
        }
    }

    //ccftap suppress
    if (input_.ego_velx > EAEB_Dm_Ccftap_Max_Vel || input_.ego_yawrate < EAEB_Dm_Ccftap_Min_Yawrate ||
        input_.steerwhlang > EAEB_Dm_Ccftap_Max_StrAng)
    {
        output_.suppressbit    |= (0x00400000);
    }

    if (input_.ego_velx <= EAEB_Dm_Bwd_Min_Vel || (input_.ego_velx >= EAEB_Dm_Bwd_Max_Vel && input_.ego_velx <= EAEB_Dm_Fwd_Min_Vel))
    {
        output_.suppressbit    |= (0xFFE00000);
    }
    
    if (input_.ego_velx >= EAEB_Dm_Fwd_Max_Vel)
    {
        output_.suppressbit    |= (0x9FE00000);
    }

    if(fabs(input_.ego_velx) <= EAEB_Dm_Static_Vel)
    {
        output_.abortbit       |= (0xFFE00000);
    }

    if(input_.ego_gear != 1)
    {
        output_.suppressbit    |= (0xFFC00000);
        output_.abortbit       |= (0xFFC00000);
    }

    if(input_.ego_gear != 2)
    {
        output_.suppressbit    |= (0x00200000);
        output_.abortbit       |= (0x00200000);
    }

    if(input_.ego_ax > 0.12 * G_ms2 && input_.gaspedpos > EAEB_Dm_Min_Acc_GasPed) {
        output_.suppressbit    |= (0xFC000000);
        output_.abortbit       |= (0xFC000000);
    }

}

void DriverMonitor::SetDamping()
{   
    CalcFocusState();
    if(output_.ramptimer == 0)
    {
        if(output_.focusstate == 1)
        {
            for(int i = 0; i < 32; i++)
            {
                output_.dampfactor[i] = EAEB_Dm_Foc1_DampFactor[i];
            }
        }
        else if(output_.focusstate == 2)
        {
            for(int i = 0; i < 32; i++)
            {
                output_.dampfactor[i] = EAEB_Dm_Foc2_DampFactor[i];
            }
        }
        else if(output_.focusstate == 3)
        {
            for(int i = 0; i < 32; i++)
            {
                output_.dampfactor[i] = EAEB_Dm_Foc3_DampFactor[i];
            }
        }
        else if(output_.focusstate == 4)
        {
            for(int i = 0; i < 32; i++)
            {
                output_.dampfactor[i] = EAEB_Dm_Foc4_DampFactor[i];
            }
        }
        else
        {
            for(int i = 0; i < 32; i++)
            {
                output_.dampfactor[i] = 1.0;
            }
        }
    }
    else
    {
        for(int i = 0; i < 32; i++)
        {
            output_.dampfactor[i] = 1.0;
        }
    }
}

float DriverMonitor::StDev(float *arr, uint8_t len){
    float   aver    = 0.0;
    float   var     = 0.0;
    float   stdev   = 0.0;
    for(int i = 0; i < len; i++){
        aver += arr[i]/len;
    }
    for(int j = 0; j < len; j++){
        var += powf(arr[j]-aver, 2)/len;
    }
    stdev = sqrtf(var);
    return stdev;
}

void DriverMonitor::UpdateCalibration() {
    size_t egospd_cal = sizeof(EAEB_dmsteer_egospd_x) / sizeof(EAEB_dmsteer_egospd_x[0]);
    driverturn_steerangle_thres_.init(EAEB_dmsteer_egospd_x, EAEB_dmsteer_stwangle_v, egospd_cal);
    driverturn_yawrate_thres_.init(EAEB_dmsteer_egospd_x, EAEB_dmsteer_yawrate_v, egospd_cal);
}

void DriverMonitor::SetDriverTurn() {
    float steerangle = ego_->vehicleinfo_in.steersys.StrWhlAg;
    float yawrate = ego_->vehicleinfo_in.vehicledynamic.YawRateRps;
    float egospd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

    float steerangle_threshold = driverturn_steerangle_thres_.interpolate(egospd);
    float yawrate_threshold = driverturn_yawrate_thres_.interpolate(egospd);
    
    bool driverturn_thiscycle = 0;
    driverturn_thiscycle = ((fabsf(steerangle) > steerangle_threshold) || (fabsf(yawrate) > yawrate_threshold)) ?1:0;

    if (driverturn_thiscycle == 1) {
        ego_turn_filter ++;
        if (ego_turn_filter > 250) {
            ego_turn_filter = 250;
        }
    }
    else {
        ego_turn_filter = 0;
    }

    if (ego_turn_filter > 5) {
        turn_suppress_cycle ++;
        if (turn_suppress_cycle > 250) {
            turn_suppress_cycle = 250;
        }
    }
    else {
        turn_suppress_cycle --;
        if (turn_suppress_cycle < 0) {
            turn_suppress_cycle = 0;
        }
    }

    if (turn_suppress_cycle > 1) {
        ego_turning = 1;
    }
    else {
        ego_turning = 0;
    }
}

void DriverMonitor::MainFunction()
{
    GetInput();
    UpdateCalibration();

    if(EAEB_Dm_SdyDetect_Switch == true){
        SdyDetect();
    }

    SetSuppress();
    SetDamping();
    SetDriverTurn();
}

DriverMonitor drimonitor;

} //namespace ad
} //namespace nio

