#ifndef AEB_DM_H
#define AEB_DM_H

#include <cstdint>
#include "aeb_strategy_type.h"
#include "niodds/application/application.h"

namespace nio{
namespace ad{

class DriverMonitor
{
    private:
        //Driver monitor input
        struct DmInput
        {
            float      gaspedpos;
            float      gaspedgrad;
            bool       driverbraking;
            float      brkpedpos;

            float      steerwhlang;
            float      steerwhlgrad;

            float      ego_velx;
            float      ego_ax;
            float      ego_yawrate;

            bool       turnlight_on;

            uint8_t    ego_gear;

            uint8_t    drive_mode;

        };

        //Driver monitor output
        struct DmOutput
        {
            uint8_t    feedbackstate;
            uint8_t    activitystate;
            uint8_t    focusstate;

            uint32_t   suppressbit;
            uint32_t   abortbit;
            float      dampfactor[32];

            float      vel_std_dev;
            float      sdytimer;
            float      ramptimer;
            
            bool       dampsuppressed;
        };

        const float    ArbCycleTime             = 0.02;

        uint32_t       fb3_hardbrake_age_       = 0;
        uint32_t       fb2_hardbrake_age_       = 0;
        uint32_t       fb1_hardaccel_age_       = 0;
        uint32_t       fo_hardbrake_age_        = 0;

        float          feedback_lvl1_timer_     = 0.0;
        float          feedback_lvl2_timer_     = 0.0;
        float          feedback_lvl3_timer_     = 0.0;

        float          act_lvl1_timer_          = 0.0;
        float          act_lvl2_timer_          = 0.0;
        float          act_lvl3_timer_          = 0.0;

        float          focus_lvl1_timer_        = 0.0;
        float          focus_lvl2_timer_        = 0.0;
        float          focus_lvl3_timer_        = 0.0;
        float          focus_lvl4_timer_        = 0.0;

        float          vel_hist[MaxVelHisNr]    = {};

        feature::math::LinearInterpolator<float> fb1_gasped_high_thres_;
        feature::math::LinearInterpolator<float> fb1_gasped_low_thres_;
        feature::math::LinearInterpolator<float> fb1_gasgrad_low_thres_;

        feature::math::LinearInterpolator<float> act1_grad_thres_;
        feature::math::LinearInterpolator<float> act2_ang_thres_;
        feature::math::LinearInterpolator<float> act2_grad_thres_;
        feature::math::LinearInterpolator<float> act3_grad_thres_;

        feature::math::LinearInterpolator<float> focus2_gasped_thres_;
        feature::math::LinearInterpolator<float> focus4_ax_thres_;

        feature::math::LinearInterpolator<float> driverturn_steerangle_thres_;
        feature::math::LinearInterpolator<float> driverturn_yawrate_thres_;
        
        void  GetInput();

        void  CalcFeedbackState();
        void  CalcActivityState();
        void  CalcFocusState();
        void  SdyDetect();

        void  SetSuppress();
        void  SetDamping();

        void  SetDriverTurn();
        void  UpdateCalibration();

        float StDev(float *arr, uint8_t len);

    public:

        DmInput    input_;
        DmOutput   output_;

        void MainFunction();

        DriverMonitor();
        ~DriverMonitor();
};

extern DriverMonitor drimonitor; 

} //namespace ad
} //namespace nio



#endif //AEB_DM_H