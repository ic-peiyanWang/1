#ifndef AEB_GOF_H
#define AEB_GOF_H

//#include "fcts_input_adapter.h"
#include "aeb_strategy_type.h"

namespace nio { 
namespace ad  {

class GenObjectFilter{
    
    private:

        void  ObjProcess();
        bool  ObjClassCheck(FusedObjFiltered obj_i);
        bool  ObjFuStCheck(FusedObjFiltered obj_i);
        bool  ObjAgeCheck(FusedObjFiltered obj_i);
        bool  ObjPredCheck(FusedObjFiltered obj_i);
        bool  ObjFreeSpaceCheck(FusedObjFiltered obj_i);
        void  ObjRefPosCalc(FusedObjFiltered &obj_i);

    public:


        void MainFunction();
        GenObjectFilter();
        ~GenObjectFilter();
};

//for external use
extern GenObjectFilter genobjfilter;

} //namesapce ad
} //namespace nio

#endif //AEB_GOF_H