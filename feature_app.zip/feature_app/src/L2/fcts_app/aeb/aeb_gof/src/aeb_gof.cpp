#include "aeb_gof.h"
#include "aeb_calibration.h"

namespace nio{
namespace ad{

GenObjectFilter::GenObjectFilter(){}
GenObjectFilter::~GenObjectFilter(){}

/******************************************************************************
* description       this function filter ehy object and output fused_obj_filtered for aeb
* param             {*}
* return            {*}
* *****************************************************************************/
void GenObjectFilter::ObjProcess(){
    
    //clean fused_obj_filtered
    fused_obj_filtered.clear();
    vehicle_count = 0;

    for(size_t i = 0; i < fused_obj_->size(); i++){

        FusedObjFiltered temp_obj;

        temp_obj.raw_data = fused_obj_->at(i);

        //add for debug
        temp_obj.gofcheck.classcheck      = ObjClassCheck(temp_obj);
        temp_obj.gofcheck.fustcheck       = ObjFuStCheck(temp_obj);
        temp_obj.gofcheck.agecheck        = ObjAgeCheck(temp_obj);
        temp_obj.gofcheck.predcheck       = ObjPredCheck(temp_obj);
        temp_obj.gofcheck.freespacecheck  = ObjFreeSpaceCheck(temp_obj);

        temp_obj.gofcheck.checkID = temp_obj.raw_data.GetID();

        temp_obj.gofcheck.check_valid   = false;

        if ( temp_obj.gofcheck.classcheck &&
             temp_obj.gofcheck.fustcheck  &&
             temp_obj.gofcheck.agecheck   && 
             temp_obj.gofcheck.predcheck  &&
             temp_obj.gofcheck.freespacecheck ) {
                    temp_obj.gofcheck.check_valid = true;
                }
        
        ObjRefPosCalc(temp_obj);

        if (temp_obj.raw_data.classification.IsVehicle() == 1 && temp_obj.raw_data.IsAllFused() && (temp_obj.raw_data.motion.GetX() < 80) && (fabsf(temp_obj.raw_data.motion.GetY()) < 10)) {
            vehicle_count ++;
        }
        
        //fill temp_obj in fused_obj_filtered list
        fused_obj_filtered.push_back(temp_obj);
    }

    float steeringangle = ego_->vehicleinfo_in.steersys.StrWhlAg;
    if (fabsf(steeringangle) < 20) {
        drivingstraight_filter ++;
        if (drivingstraight_filter > 250) {
            drivingstraight_filter = 250;
        }
    }
    else if (fabsf(steeringangle) > 50) {
        drivingstraight_filter = 0;
    }
    else {
        drivingstraight_filter --;
        if (drivingstraight_filter < 0) {
            drivingstraight_filter = 0;
        }
    }

    if (drivingstraight_filter > 100) {
        drivingstraight = 1;
    }
    else {
        drivingstraight = 0;
    }

    float vehspdsum_100ms = 0;
    bool speedsteady = 0;

    for (int avri = 0; avri < 5; avri ++) {
        vehspdsum_100ms = vehspdsum_100ms + ego_steady_vehspd[avri];
    }

    for (int spdi = 0; spdi < 4; spdi ++) {
        ego_steady_vehspd[spdi + 1] = ego_steady_vehspd[spdi];
    }
    ego_steady_vehspd[0] = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;    

    averagespd_100ms = vehspdsum_100ms/5;
    speedsteady = (fabsf(ego_steady_vehspd[0] - averagespd_100ms) <= 0.1)?1:0;

    if(speedsteady == 1) {
        drivingsteadycnt ++;
        if (drivingsteadycnt > 250) {
            drivingsteadycnt = 250;
        }
    }
    else {
        drivingsteadycnt = drivingsteadycnt - 5;
        if (drivingsteadycnt < 0) {
            drivingsteadycnt = 0;
        }
    }

    drivingsteady = (drivingsteadycnt > 100) ?1:0;

    single_target_scene = ((vehicle_count <= 2 && drivingstraight == 1 && drivingsteady == 1) || FusionCCRFlag_.Warning_flag == kAEBAlertActive)?1:0;
}

void GenObjectFilter::ObjRefPosCalc(FusedObjFiltered &obj_i) {
    float posx = obj_i.raw_data.motion.GetX();
    float posy = obj_i.raw_data.motion.GetY();
    float head = obj_i.raw_data.motion.GetHead();
    float length = obj_i.raw_data.motion.length();
    float width = obj_i.raw_data.motion.width();

    obj_i.ref_pos.heading = head;
    obj_i.ref_pos.centerpoint.pos_x = posx;
    obj_i.ref_pos.centerpoint.pos_y = posy;
    obj_i.ref_pos.centerpoint.range = sqrtf((posx * posx) + (posy * posy));

    obj_i.ref_pos.frontcenter.pos_x = posx + 0.5 * length * cosf(head);
    obj_i.ref_pos.frontcenter.pos_y = posy + 0.5 * length * sinf(head);
    obj_i.ref_pos.frontcenter.range = sqrtf((obj_i.ref_pos.frontcenter.pos_x * obj_i.ref_pos.frontcenter.pos_x) + (obj_i.ref_pos.frontcenter.pos_y * obj_i.ref_pos.frontcenter.pos_y));

    obj_i.ref_pos.rearcenter.pos_x = posx - 0.5 * length * cosf(head);
    obj_i.ref_pos.rearcenter.pos_y = posy - 0.5 * length * sinf(head);
    obj_i.ref_pos.rearcenter.range = sqrtf((obj_i.ref_pos.rearcenter.pos_x * obj_i.ref_pos.rearcenter.pos_x) + (obj_i.ref_pos.rearcenter.pos_y * obj_i.ref_pos.rearcenter.pos_y));

    obj_i.ref_pos.leftcenter.pos_x = posx + 0.5 * width * cosf(head);
    obj_i.ref_pos.leftcenter.pos_y = posy - 0.5 * width * sinf(head);
    obj_i.ref_pos.leftcenter.range = sqrtf((obj_i.ref_pos.leftcenter.pos_x * obj_i.ref_pos.leftcenter.pos_x) + (obj_i.ref_pos.leftcenter.pos_y * obj_i.ref_pos.leftcenter.pos_y));

    obj_i.ref_pos.rightcenter.pos_x = posx - 0.5 * width * cosf(head);
    obj_i.ref_pos.rightcenter.pos_y = posy + 0.5 * width * sinf(head);
    obj_i.ref_pos.rightcenter.range = sqrtf((obj_i.ref_pos.rightcenter.pos_x * obj_i.ref_pos.rightcenter.pos_x) + (obj_i.ref_pos.rightcenter.pos_y * obj_i.ref_pos.rightcenter.pos_y));

    if (obj_i.raw_data.classification.IsVehicle() == 1 || obj_i.raw_data.classification.IsBicycle() == 1 || obj_i.raw_data.classification.IsMotorbike() == 1) {
        float minrange = 1000;
        float miny = 1000;

        if (obj_i.ref_pos.frontcenter.range <= minrange) {
        obj_i.ref_pos.ref_character = 1;
        minrange = obj_i.ref_pos.frontcenter.range;
        miny = fabsf(obj_i.ref_pos.frontcenter.pos_y);
        obj_i.ref_pos.referencepoint = obj_i.ref_pos.frontcenter;
        }
        else {
            obj_i.ref_pos.ref_character = 0;
            minrange = obj_i.ref_pos.centerpoint.range;
            miny = fabsf(obj_i.ref_pos.centerpoint.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.centerpoint;
        }

        if (obj_i.ref_pos.rearcenter.range < minrange) {
            obj_i.ref_pos.ref_character = 2;
            minrange = obj_i.ref_pos.rearcenter.range;
            miny = fabsf(obj_i.ref_pos.rearcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.rearcenter;
        }
        else if (obj_i.ref_pos.rearcenter.range == minrange && fabsf(obj_i.ref_pos.rearcenter.pos_y) <= miny) {
            obj_i.ref_pos.ref_character = 2;
            minrange = obj_i.ref_pos.rearcenter.range;
            miny = fabsf(obj_i.ref_pos.rearcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.rearcenter;
        }

        if (obj_i.ref_pos.leftcenter.range < minrange) {
            obj_i.ref_pos.ref_character = 3;
            minrange = obj_i.ref_pos.leftcenter.range;
            miny = fabsf(obj_i.ref_pos.leftcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.leftcenter;
        }
        else if (obj_i.ref_pos.leftcenter.range == minrange && fabsf(obj_i.ref_pos.leftcenter.pos_y) < miny) {
            obj_i.ref_pos.ref_character = 3;
            minrange = obj_i.ref_pos.leftcenter.range;
            miny = fabsf(obj_i.ref_pos.leftcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.leftcenter;
        }

        if (obj_i.ref_pos.rightcenter.range < minrange) {
            obj_i.ref_pos.ref_character = 4;
            minrange = obj_i.ref_pos.rightcenter.range;
            miny = fabsf(obj_i.ref_pos.rightcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.rightcenter;
        }
        else if (obj_i.ref_pos.rightcenter.range == minrange && fabsf(obj_i.ref_pos.rightcenter.pos_y) < miny) {
            obj_i.ref_pos.ref_character = 4;
            minrange = obj_i.ref_pos.rightcenter.range;
            miny = fabsf(obj_i.ref_pos.rightcenter.pos_y);
            obj_i.ref_pos.referencepoint = obj_i.ref_pos.rightcenter;
        }
    }
    else if (obj_i.raw_data.classification.IsPedestrian() == 1) {
        obj_i.ref_pos.ref_character = 0;
        obj_i.ref_pos.referencepoint = obj_i.ref_pos.centerpoint;
    }
    else {
        obj_i.ref_pos.ref_character = 0;
        obj_i.ref_pos.referencepoint = obj_i.ref_pos.centerpoint;
    }    
}

/******************************************************************************
* description       this function check object classification and velocity
* param             {FusedObjFiltered} obj_i
* return            {*}
* *****************************************************************************/
bool GenObjectFilter::ObjClassCheck(FusedObjFiltered obj_i){

    bool ret = false;

    float abs_obj_vel = sqrtf( powf(obj_i.raw_data.motion.GetVx(), 2 )
                            + powf( obj_i.raw_data.motion.GetVy(), 2 ) );

        if (obj_i.raw_data.classification.IsPedestrian() == true){
            if (abs_obj_vel <= EAEB_Gof_Max_PedVel){
                ret = true;
            }
        }

        else if (obj_i.raw_data.classification.IsBicycle() == true){
            if (abs_obj_vel <= EAEB_Gof_Max_BikVel){
                ret = true;
            }
        }

        else if (obj_i.raw_data.classification.IsMotorbike() == true){
            if (abs_obj_vel <= EAEB_Gof_Max_MoBikVel){
                ret = true;
            }
        }

        else if (obj_i.raw_data.classification.GetClass() == feature::ehy::ClassEnum::kClassSmallVehicle ){
            if (abs_obj_vel <= EAEB_Gof_Max_SmallVehVel){
                ret = true;
            }
        }

        else if (obj_i.raw_data.classification.GetClass() == feature::ehy::ClassEnum::kClassBigVehicle ){
            if (abs_obj_vel <= EAEB_Gof_Max_BigVehVel){
                ret = true;
            }
        }

        else if (obj_i.raw_data.classification.GetClass() == feature::ehy::ClassEnum::kClassGeneralObject){
            if (abs_obj_vel <= EAEB_Gof_Max_GenObjVel){
                ret = true;
            }
        }

        else{
            /* nothing */
        }

        return ret;
}

/******************************************************************************
* description       this function check object fusion state and confidence
* param             {FusedObjFiltered} obj_i
* return            {*}
* *****************************************************************************/
bool GenObjectFilter::ObjFuStCheck(FusedObjFiltered obj_i){

    bool ret = false;
    
    if(obj_i.raw_data.IsAllFused() == true){
        if(obj_i.raw_data.valid_status() != 0 &&
           obj_i.raw_data.fusion_sup.confidence >= EAEB_Gof_Max_FusionConf){
            ret = true;
        }
    }

    else if(obj_i.raw_data.IsVisionOnly() == true){
        if(obj_i.raw_data.valid_status() != 0 &&
           //obj_i.raw_data.IsAllFusedHis() == true &&
           obj_i.raw_data.fusion_sup.confidence >= EAEB_Gof_Max_VisConf){
            ret = true;
        }
    }

    else if(obj_i.raw_data.IsRadarOnly() == true){
        if(obj_i.raw_data.valid_status() != 0 && 
           //obj_i.raw_data.IsAllFusedHis() == true &&
           obj_i.raw_data.fusion_sup.confidence >= EAEB_Gof_Max_RadarConf){
            ret = true;
        }
    }

    return ret;
}

/******************************************************************************
* description       this function check object age
* param             {FusedObjFiltered} obj_i
* return            {*}
* *****************************************************************************/
bool GenObjectFilter::ObjAgeCheck(FusedObjFiltered obj_i){
    
    bool ret = false;

    if (obj_i.raw_data.IsAllFused() == true){
        if(obj_i.raw_data.fusion_sup.age >= EAEB_Gof_Max_FusionAge){
            ret = true;
        }
    }

    else if(obj_i.raw_data.IsVisionOnly() == true){
        if(obj_i.raw_data.fusion_sup.age >= EAEB_Gof_Max_VisAge){
            ret = true;
        }
    }

    else if(obj_i.raw_data.IsRadarOnly() == true){
        if(obj_i.raw_data.fusion_sup.age >= EAEB_Gof_Max_RadarAge){
            ret = true;
        }
    }

    return ret;
}

//tbd
bool GenObjectFilter::ObjPredCheck(FusedObjFiltered obj_i){
    
    //bool ret = false;

    return true;
}

//tbd
bool GenObjectFilter::ObjFreeSpaceCheck(FusedObjFiltered obj_i){
    
    //bool ret = false;
    
    return true;
}

/******************************************************************************
* description       this function is main function
* param             {*}
* return            {*}
* *****************************************************************************/
void GenObjectFilter::MainFunction(){
    ObjProcess();
}

GenObjectFilter genobjfilter;

} //namespace ad
} //namespace nio