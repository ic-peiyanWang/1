#include <array>

#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"


#ifndef AEB_IN_HOUSE_H_
#define AEB_IN_HOUSE_H_

namespace nio {
namespace ad {

class AEBInHouse {
  public: 

  private:
  uint8_t aes_hold_age = 0;
  bool aes_hold_ready = 0;

  uint8_t steer_whl_spd_inh_cnt_ = 0U;
  float last_abs_vx_[kAEBObjectNum] = {0.0F};
  uint8_t last_id_[kAEBObjectNum] = {0U};
  float yawrate_LF = 0.0f;
  float brakepress_LF = 0.0f;
  float deltabrakepres = 0.0f;
  float accelpos_LF = 0.0f;
  float deltaaccelpos = 0.0f;
  float steerwhlang_LF = 0.0f;
  float deltasteerang = 0.0f;
  float brakepos = 0.0f;
  float brakepos_LF = 0.0f;
  
  bool speedhighact = 0;
  bool speedhighsupr = 0;
  bool speedhighsupr_LF = 0;
  uint8_t speedhigh_count = 0;
  uint8_t threshold_speedhigh_ = 4;
  
  bool speedlowact = 0;
  bool speedlowsupr = 0;
  bool speedlowsupr_LF = 0;
  uint8_t speedlow_count = 0;
  uint8_t threshold_speedlow_ = 4;
  
  bool yawrthighact = 0;
  bool yawrthighsupr = 0;
  bool yawrthighsupr_LF = 0;
  uint8_t yawrthigh_count = 0;
  uint8_t threshold_yawrthigh_ = 6;

  bool brakepressact = 0;
  bool brakepresssupr = 0;
  bool brakepresssupr_LF = 0;
  uint8_t brakepress_count = 0;
  uint8_t threshold_brakepress_ = 10;

  bool steerhighact = 0;
  bool steerhighsupr = 0;
  bool steerhighsupr_LF = 0;
  uint8_t steerhigh_count = 0;
  uint8_t threshold_steerhigh_ = 20;

  bool strspdhighact = 0;
  bool strspdhighsupr = 0;
  bool strspdhighsupr_LF = 0;
  uint8_t strspdhigh_count = 0;
  uint8_t threshold_strspdhigh_ = 10;

  bool accposhighact = 0;
  bool accposhighsupr = 0;
  bool accposhighsupr_LF = 0;
  uint8_t accposhigh_count = 0;
  uint8_t threshold_accposhigh_ = 10;

  bool accposrthighact = 0;
  bool accposrthighsupr = 0;
  bool accposrthighsupr_LF = 0;
  uint8_t accposrthigh_count = 0;
  uint8_t threshold_accposrthigh_ = 10;

  bool initiateROSAEB = 0u;

  uint8_t movingout_count = 0;
  uint8_t threshold_movingout = 10;

  void MatchVisInfo();
  void MatchLFInfo();
  void DecideDriverBehavior();
  void DecideSupression();
  void BrakeDecisionArbi();
  void VruRearFlagArbi();
  
  void Debug_output();
  void Fill_FusObj_Lf();
  void Ped_Debug(AEBCandidate &ped_candi);
  void CCR_Debug(AEBObjectCCR &ccr_candi);
  void CCF_Debug(AEBObjectFTAP &ccf_candi);

  bool lastframebrake(FusionAEBFlag &vruflag_lf, FusionAEBFlag &ccrflag_lf);

  bool SuppressionActive (bool issuppressed, uint8_t &suppression_counter, bool suppressst, uint8_t duration);  

  float ROC(float vehspd, float yrate);

  void CCRBrakeArbi();

  void CCRSteerArbi();

  void ClearCCRFlag();

  void ClearCCRAge();

  void ClearVruFlag();

  void ClearVruAge();

  void ClearVruRearFlag();

  void ClearVruRearAge();

  void UpdateCalibration();

  void clearsteerflag();

  void update_aesctrl(AESObjectCCR &ccr_candi, AES_Control_Input &aes_ctrl);

  void update_aescorner (CornerPos &point, AESObjectCCR &ccr_candi,AES_Control_Input &aes_ctrl);

 public:
  AEBInHouse(ARBSIN *aeb_sin, std::vector<feature::ehy::Object> *fused_obj,
             std::vector<feature::ehy::Object> *vis_obj);
  ~AEBInHouse();
  void MainFunction();

};

extern AEBInHouse aeb_;

}  // namespace ad
}  // namespace nio

#endif  // AEB_IN_HOUSE_H_