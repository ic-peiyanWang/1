#pragma once
#include "aeb_in_house.h"

namespace nio {
namespace ad {
void aeb_main(void);
}
}  // namespace nio