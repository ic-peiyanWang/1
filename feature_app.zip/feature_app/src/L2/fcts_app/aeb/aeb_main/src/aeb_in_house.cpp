#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aeb_in_house.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_extract_ccr.h"
#include "aeb_extract_vru.h"
#include "aeb_extract_ftap.h"
#include "aeb_extract_ccc.h"
#include "aeb_gof.h"
#include "aeb_dm.h"
#include "aeb_vse.h"
#include "aes_extract_ccr.h"
#include "aeb_calibration.h"
#include "aes_planning.h"

namespace nio {
namespace ad {

AEBInHouse aeb_(arb_sin, &arb_sin->fused_obj, &arb_sin->vis_obj);

extern extract_ftap ftap_extraction_;
extern extract_ccr ccr_extraction_;
extern extract_vru vru_extraction_;
extern extract_ccc ccc_extraction_;
extern aeb_vse aeb_vse_;
extern extract_aesccr aesccr_extraction_;
extern aes_plan aes_path_plan_;

AEBInHouse::AEBInHouse(ARBSIN *aeb_sin, std::vector<feature::ehy::Object> *fused_obj, std::vector<feature::ehy::Object> *vis_obj) {
  ego_ = aeb_sin;
  //sensor_ = sensor;
  fused_obj_ = fused_obj;
  vis_obj_ = vis_obj;

}

AEBInHouse::~AEBInHouse() {}

void AEBInHouse::MainFunction() {
  //std::cout << "aebinhouse start"<<std::endl;
  //auto ts = Time::Now();
  deltayawrate = ego_->vehicleinfo_in.vehicledynamic.YawRateRps - yawrate_LF;
  deltabrakepres = ego_->vehicleinfo_in.brakesys.BrkPrs.BrkPrs - brakepress_LF;
  deltasteerang = ego_->vehicleinfo_in.steersys.StrWhlAg - steerwhlang_LF;
  fcw_sensitive = static_cast<uint8_t>(ego_->vehicleinfo_in.vehicledrive.AdFunCfg.FCWSetReq);
  UpdateCalibration();
  DecideSupression();
  aeb_vse_.MainFunction();

  genobjfilter.MainFunction();
  drimonitor.MainFunction();

  DecideDriverBehavior();
  MatchVisInfo();
  vru_extraction_.MainFunction();
  BrakeDecisionArbi();
  VruRearFlagArbi();
  ccr_extraction_.MainFunction();
  ftap_extraction_.MainFunction();
  ccc_extraction_.MainFunction();
  CCRBrakeArbi();
  aesccr_extraction_.MainFunction();
  CCRSteerArbi();
  //aes_path_plan_.MainFunction();
  //==================for field test debug only ================================
  MatchLFInfo();
  //Debug_output();
  Fill_FusObj_Lf();
  //============================================================================
  lfbrake_active = lastframebrake(FusionVRUFlag_, FusionCCRFlag_);

  yawrate_LF = ego_->vehicleinfo_in.vehicledynamic.YawRateRps;
  brakepress_LF = ego_->vehicleinfo_in.brakesys.BrkPrs.BrkPrs;
  steerwhlang_LF = ego_->vehicleinfo_in.steersys.StrWhlAg;
  
  //auto dur = Time::Now() - ts;
}


void AEBInHouse::Debug_output() {
  if (vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID != 0) {
    std::cout << ">>>>>>>>vru_candidate.pedestrian_cross_Candidate_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.pedestrian_cross_Candidate_);
    std::cout << "........................................................" << std::endl;
    debug_loop ++;
    if (debug_loop > 5) {
      debug_loop = 0;
    }
    if (debug_loop == 4) {
      std::cout << ">>>>>>>>before target is selected, vru_candidate.pedestrian_cross_NS_ is selected<<<<<<<<<" <<std::endl;
      Ped_Debug(vru_candidate.pedestrian_cross_NS_);
      std::cout << "........................................................" << std::endl;
    }
  }

  if (vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID != 0) {
    std::cout << ">>>>>>>>vru_candidate.pedestrian_oncom_Candidate_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.pedestrian_oncom_Candidate_);
    std::cout << "........................................................" << std::endl;
    debug_loop ++;
    if (debug_loop > 5) {
      debug_loop = 0;
    }
    if (debug_loop == 4) {
      std::cout << ">>>>>>>>before target is selected, vru_candidate.pedestrian_oncom_NS_ is selected<<<<<<<<<" <<std::endl;
      Ped_Debug(vru_candidate.pedestrian_oncom_NS_);
      std::cout << "........................................................" << std::endl;
    }
  }

  if (vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID != 0) {
    std::cout << ">>>>>>>>vru_candidate.bicycle_cross_Candidate_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.bicycle_cross_Candidate_);
    std::cout << "........................................................" << std::endl;
    debug_loop ++;
    if (debug_loop > 5) {
      debug_loop = 0;
    }
    if (debug_loop == 4) {
      std::cout << ">>>>>>>>before target is selected, vru_candidate.bicycle_cross_NS_ is selected<<<<<<<<<" <<std::endl;
      Ped_Debug(vru_candidate.bicycle_cross_NS_);
      std::cout << "........................................................" << std::endl;
    }
  }

  if (vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID != 0) {
    std::cout << ">>>>>>>>vru_candidate.bicycle_oncom_Candidate_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.bicycle_oncom_Candidate_);
    std::cout << "........................................................" << std::endl;
    debug_loop ++;
    if (debug_loop > 5) {
      debug_loop = 0;
    }
    if (debug_loop == 4) {
      std::cout << ">>>>>>>>before target is selected, vru_candidate.bicycle_oncom_NS_ is selected<<<<<<<<<" <<std::endl;
      Ped_Debug(vru_candidate.bicycle_oncom_NS_);
      std::cout << "........................................................" << std::endl;
    }
  }

  if (ccr_candidate.CCRS_Candi_.u8_ID != 0) {
    std::cout << ">>>>>>>>ccr_candidate.CCRS_Candi_ is selected<<<<<<<<<" <<std::endl;
    CCR_Debug(ccr_candidate.CCRS_Candi_);
    std::cout << "........................................................" << std::endl;
  }

  if (ccr_candidate.CCRS_Candi_2_.u8_ID != 0) {
    std::cout << ">>>>>>>>ccr_candidate.CCRS_Candi_2_ is selected<<<<<<<<<" <<std::endl;
    CCR_Debug(ccr_candidate.CCRS_Candi_2_);
    std::cout << "........................................................" << std::endl;
  }

  if (ccr_candidate.CCRM_Candi_.u8_ID != 0) {
    std::cout << ">>>>>>>>ccr_candidate.CCRM_Candi_ is selected<<<<<<<<<" <<std::endl;
    CCR_Debug(ccr_candidate.CCRM_Candi_);
    std::cout << "........................................................" << std::endl;
  }

  if (ccr_candidate.CCRM_Candi_2_.u8_ID != 0) {
    std::cout << ">>>>>>>>ccr_candidate.CCRM_Candi_2_ is selected<<<<<<<<<" <<std::endl;
    CCR_Debug(ccr_candidate.CCRM_Candi_2_);
    std::cout << "........................................................" << std::endl;
  }

  if (ftap_candidate.FTAP_Candi_.u8_ID != 0) {
    std::cout << ">>>>>>>>ftap_candidate.FTAP_Candi_ is selected<<<<<<<<<" <<std::endl;
    CCF_Debug(ftap_candidate.FTAP_Candi_);
    std::cout << "........................................................" << std::endl;
    debug_loop ++;
    if (debug_loop > 5) {
      debug_loop = 0;
    }
    if (debug_loop == 4) {
      std::cout << ">>>>>>>>before target is selected, FTAP_NS_ is selected<<<<<<<<<" <<std::endl;
      CCF_Debug(ftap_candidate.FTAP_NS_);
      std::cout << "........................................................" << std::endl;
    }
  }

  if (ftap_candidate.FTAP_Candi_2_.u8_ID != 0) {
    std::cout << ">>>>>>>>ftap_candidate.FTAP_Candi_2_ is selected<<<<<<<<<" <<std::endl;
    CCF_Debug(ftap_candidate.FTAP_Candi_2_);
    std::cout << "........................................................" << std::endl;
  }

  if (vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID != vru_candidate.pedestrian_cross_Candidate_LF_.obj.u8_ID && fus_lf_idx.pedcross_idx != MaxFusedObjIndex && vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID != 0) {
    std::cout << ">>>>>>>>before target is selected, vru_candidate.pedestrian_cross_NS_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.pedestrian_cross_NS_);
    std::cout << "........................................................" << std::endl;
  }

  if (vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID != vru_candidate.pedestrian_oncom_Candidate_LF_.obj.u8_ID && fus_lf_idx.pedoncom_idx != MaxFusedObjIndex && vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID != 0) {
    std::cout << ">>>>>>>>before target is selected, vru_candidate.pedestrian_oncom_NS_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.pedestrian_oncom_NS_);
    std::cout << "........................................................" << std::endl;
  }

  if (vru_candidate.bicycle_cross_Candidate_.obj.u8_ID != vru_candidate.bicycle_cross_Candidate_LF_.obj.u8_ID && fus_lf_idx.bikcross_idx != MaxFusedObjIndex && vru_candidate.bicycle_cross_Candidate_.obj.u8_ID != 0) {
    std::cout << ">>>>>>>>before target is selected, vru_candidate.bicycle_cross_NS_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.bicycle_cross_NS_);
    std::cout << "........................................................" << std::endl;
  }

  if (vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID != vru_candidate.bicycle_oncom_Candidate_LF_.obj.u8_ID && fus_lf_idx.bikoncom_idx != MaxFusedObjIndex && vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID != 0) {
    std::cout << ">>>>>>>>before target is selected, vru_candidate.bicycle_oncom_NS_ is selected<<<<<<<<<" <<std::endl;
    Ped_Debug(vru_candidate.bicycle_oncom_NS_);
    std::cout << "........................................................" << std::endl;
  }

  if (ftap_candidate.FTAP_Candi_.u8_ID != ftap_candidate.FTAP_Candi_LF_.u8_ID && fus_lf_idx.ccftap_idx != MaxFusedObjIndex && ftap_candidate.FTAP_Candi_.u8_ID != 0) {
    std::cout << ">>>>>>>>before target is selected, FTAP_NS_ is selected<<<<<<<<<" <<std::endl;
    CCF_Debug(ftap_candidate.FTAP_NS_);
    std::cout << "........................................................" << std::endl;
  }
}

void AEBInHouse::Ped_Debug(AEBCandidate &ped_candi) {
  std::cout << "VRU target ID is "<< (int)ped_candi.u8_Candi_ID << std::endl;
  std::cout << "VRU target range is "<< ped_candi.obj.f4_range << std::endl;
  std::cout << "VRU target rangerate is "<< ped_candi.obj.f4_rangerate << std::endl;
  std::cout << "VRU target ttc is "<< ped_candi.obj.f4_TTC << std::endl;
  std::cout << "VRU target xolc is "<< ped_candi.obj.f4_XOLC << std::endl;
  std::cout << "VRU target aebconf is "<< (int)ped_candi.obj.u8_AEBconf << std::endl;
  std::cout << "VRU target isfused is "<< (int)ped_candi.obj.obj.IsAllFused() << std::endl;
  std::cout << "VRU target isvisonly is "<< (int)ped_candi.obj.obj.IsVisionOnly() << std::endl;
  std::cout << "VRU target isradaronly is "<< (int)ped_candi.obj.obj.IsRadarOnly() << std::endl;
  std::cout << "VRU target preceding is "<< (int)ped_candi.obj.u1_preceding << std::endl;
  std::cout << "VRU target oncoming is "<< (int)ped_candi.obj.u1_oncoming << std::endl;
  std::cout << "VRU target crossing is "<< (int)ped_candi.obj.u1_crossing << std::endl;
  std::cout << "VRU target latpos_est is "<< ped_candi.obj.f4_latpos_est << std::endl;
  std::cout << "VRU target target angle is "<< ped_candi.obj.f4_targetangle << std::endl;
  std::cout << "VRU target inpath is "<< (int)ped_candi.obj.u1_Inpath << std::endl;
  std::cout << "VRU target toi is "<< (int)ped_candi.obj.u1_TOI << std::endl;
  std::cout << "VRU target age is "<< (int)ped_candi.obj.obj.fusion_sup.age << std::endl;
  std::cout << "VRU target inpathage is "<< (int)ped_candi.obj.u8_Inpathage << std::endl;
  std::cout << "VRU target inpathagecheck is "<< (int)ped_candi.obj.u1_inpathagecheck << std::endl;
  std::cout << "VRU target warning is "<< (int)ped_candi.u8_warning << std::endl;
  std::cout << "VRU target prefill is "<< (int)ped_candi.u8_prefill << std::endl;
  std::cout << "VRU target lowbrake is "<< (int)ped_candi.u8_lowBrake << std::endl;
  std::cout << "VRU target highbrake is "<< (int)ped_candi.u8_highBrake << std::endl;
}

void AEBInHouse::CCR_Debug(AEBObjectCCR &ccr_candi) {
  std::cout << "CCR target ID is "<< (int)ccr_candi.u8_ID << std::endl;
  std::cout << "CCR target range is "<< ccr_candi.f4_range << std::endl;
  std::cout << "CCR target rangerate is "<< ccr_candi.f4_rangerate << std::endl;
  std::cout << "CCR target relatacc is "<< ccr_candi.f4_relatAcc << std::endl;
  std::cout << "CCR target ttc is "<< ccr_candi.f4_TTC << std::endl;
  std::cout << "CCR target xolc is "<< ccr_candi.f4_XOLC << std::endl;
  std::cout << "CCR target heading is "<< ccr_candi.f4_TrackHeadingEst << std::endl;
  std::cout << "CCR target vis id is "<< (int)ccr_candi.obj.fusion_sup.vision.ID << "and the index is "<<(int)ccr_candi.u8_VID << std::endl;
  std::cout << "CCR target aebconf is "<< (int)ccr_candi.u8_AEBconf << std::endl;
  std::cout << "CCR target isfused is "<< (int)ccr_candi.obj.IsAllFused() << std::endl;
  std::cout << "CCR target isvisonly is "<< (int)ccr_candi.obj.IsVisionOnly() << std::endl;
  std::cout << "CCR target isradaronly is "<< (int)ccr_candi.obj.IsRadarOnly() << std::endl;
  std::cout << "CCR target yawdist is "<< ccr_candi.yawdist << std::endl;
  std::cout << "CCR target hitdist is "<< ccr_candi.hitdist << std::endl;
  std::cout << "CCR target toi is "<< (int)ccr_candi.u1_TOI << std::endl;
  std::cout << "CCR target inpath before is "<< (int)ccr_candi.u1_Inpath_Before << std::endl;
  std::cout << "CCR target inpath after is "<< (int)ccr_candi.u1_Inpath_After << std::endl;
  std::cout << "CCR target inpath is "<< (int)ccr_candi.u1_Inpath << std::endl;
  std::cout << "CCR target inpathage is "<< (int)ccr_candi.u8_Inpathage << std::endl;
  std::cout << "CCR target inpathagecheck is "<< (int)ccr_candi.u1_inpathagecheck << std::endl;
  std::cout << "CCR target age is "<< (int)ccr_candi.obj.fusion_sup.age << std::endl;
  std::cout << "CCR target movestate is "<< (int)ccr_candi.u1_movingstate << "1 = Nueutral; 2 = Moving in; 3 = Moving out" << std::endl;
  std::cout << "CCR target ismovingout is "<< (int)ccr_candi.u1_ismovingout << std::endl;
  std::cout << "CCR target warning is "<< (int)ccr_candi.warnig_flag << std::endl;
  std::cout << "CCR target prefill is "<< (int)ccr_candi.prefill_flag << std::endl;
  std::cout << "CCR target lowbrake is "<< (int)ccr_candi.lowbrake_flag << std::endl;
  std::cout << "CCR target highbrake is "<< (int)ccr_candi.highbrake_flag << std::endl;
  std::cout << "CCR target fusionstate is "<< (int)ccr_candi.obj.fusion_sup.fusion << std::endl;
  std::cout << "CCR target isvision is "<< (int)ccr_candi.obj.IsVisionOnly() << std::endl;
  std::cout << "CCR target isfusion is "<< (int)ccr_candi.obj.IsAllFused() << std::endl;
}

void AEBInHouse::CCF_Debug(AEBObjectFTAP &ccf_candi) {
  std::cout << "FTAP target ID is "<< (int)ccf_candi.u8_ID << std::endl;
  std::cout << "FTAP target range is "<< ccf_candi.f4_range << std::endl;
  std::cout << "FTAP target rangerate is "<< ccf_candi.f4_rangerate << std::endl;
  std::cout << "FTAP target aebconf is "<< (int)ccf_candi.u8_AEBconf << std::endl;
  std::cout << "FTAP target longpos is "<< ccf_candi.f4_longpos << std::endl;
  std::cout << "FTAP target latpos is "<< ccf_candi.f4_latpos << std::endl;
  std::cout << "FTAP target longvel is "<< ccf_candi.f4_longvel << std::endl;
  std::cout << "FTAP target latvel is "<< ccf_candi.f4_latvel << std::endl;
  std::cout << "FTAP target heading is "<< ccf_candi.f4_Heading << std::endl;
  std::cout << "FTAP target headingangle is "<< ccf_candi.f4_Headangle << std::endl;
  std::cout << "FTAP target age is "<< (int)ccf_candi.obj.fusion_sup.age << std::endl;
  std::cout << "FTAP target toi before is "<< (int)ccf_candi.u1_TOI_Before << std::endl;
  std::cout << "FTAP target toi after is "<< (int)ccf_candi.u1_TOI_After << std::endl;
  std::cout << "FTAP target colnum is "<< (int)ccf_candi.u8_col_pointN << std::endl;
  std::cout << "FTAP target colx is "<< ccf_candi.f4_collisionx_1 << std::endl;
  std::cout << "FTAP target coly is "<< ccf_candi.f4_collisiony_1 << std::endl;
  std::cout << "FTAP target colr is "<< ccf_candi.f4_collisionr_1 << std::endl;
  std::cout << "FTAP host ttc is "<< ccf_candi.f4_TTC << std::endl;
  std::cout << "FTAP host ttl is "<< ccf_candi.f4_TTL << std::endl;
  std::cout << "FTAP target ttc is "<< ccf_candi.TTC_tar << std::endl;
  std::cout << "FTAP target ttl is "<< ccf_candi.TTL_tar << std::endl;
  std::cout << "FTAP target current range is "<< ccf_candi.f4_currentRange << std::endl;
  std::cout << "FTAP target estimate range is "<< ccf_candi.f4_rangeestimation << std::endl;
  std::cout << "FTAP target inpath current is "<< (int)ccf_candi.u1_inpathcur << std::endl;
  std::cout << "FTAP target inpath predict is "<< (int)ccf_candi.u1_inpathpre << std::endl;
  std::cout << "FTAP target inpath is "<< (int)ccf_candi.u1_Inpath << std::endl;
  std::cout << "FTAP target inpath tar is "<< (int)ccf_candi.u1_inpath_tar << std::endl;
  std::cout << "FTAP hostpos.x is "<< ccf_candi.HostPos.x << std::endl;
  std::cout << "FTAP hostpos.y is "<< ccf_candi.HostPos.y << std::endl;
  std::cout << "FTAP hostpos_tar.x is "<< ccf_candi.HostPos_tar.x << std::endl;
  std::cout << "FTAP hostpos_tar.y is "<< ccf_candi.HostPos_tar.y << std::endl;
  std::cout << "FTAP warning is "<< (int)ccf_candi.warnig_flag << std::endl;
  std::cout << "FTAP prefill is "<< (int)ccf_candi.prefill_flag << std::endl;
  std::cout << "FTAP lowbrake is "<< (int)ccf_candi.lowbrake_flag << std::endl;
  std::cout << "FTAP highbrake is "<< (int)ccf_candi.highbrake_flag << std::endl;
}

bool AEBInHouse::lastframebrake(FusionAEBFlag &vruflag_lf,
                                FusionAEBFlag &ccrflag_lf) {
  bool lastframebrake = 0;
  if (vruflag_lf.highbrake_flag == kAEBAlertActive ||
      vruflag_lf.lowbrake_flag == kAEBAlertActive ||
      ccrflag_lf.highbrake_flag == kAEBAlertActive ||
      ccrflag_lf.lowbrake_flag == kAEBAlertActive) {
    lastframebrake = 1;
  } else {
    lastframebrake = 0;
  }
  return lastframebrake;
}

void AEBInHouse::DecideDriverBehavior() {
  brakepos_LF = brakepos;

  float maincylinderpress = ego_->vehicleinfo_in.brakesys.BrkPrs.BrkPrs;

  float maincylinderpressrate = ego_->vehicleinfo_in.brakesys.BrkPrs.BrkPrsGrad;

  brakepos = ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl;

  driverpress = (static_cast<uint8_t>(ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts) == 1);

  float brakeposrate = (brakepos - brakepos_LF)/time_interval;

  bool vehspd_reverse = 0;
  
  bool veh_in_Rgear = 0;

  bool veh_in_Ngear = 0;

  vehspd_reverse = (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehMovgDir == VehMovDir_e::BackWard);
  
  veh_in_Rgear = (ego_->vehicleinfo_in.vehiclept.Gear.ActGear == 2);

  veh_in_Ngear = (ego_->vehicleinfo_in.vehiclept.Gear.ActGear == 0);

  hostReverse = (veh_in_Rgear || (veh_in_Ngear && vehspd_reverse));

  bool press_meet = 0;
  bool pressrate_meet = 0;
  bool pos_meet = 0;
  bool posrate_meet = 0;


  bool pressmeet_mask = 0;
  bool pressratemeet_mask = 1;
  bool posmeet_mask = 0;
  bool posratemeet_mask = 1;

  press_meet = (maincylinderpress >= McPressThres) ?1:0;
  pressrate_meet = (maincylinderpressrate >= McPressRateThres) ?1:0;
  pos_meet = (brakepos >= BrakePosThres) ?1:0;
  posrate_meet = (brakeposrate >= 1) ?1:0;

  driverBrake_intention = ((press_meet||pressmeet_mask)&&
                            (pressrate_meet||pressratemeet_mask)&&
                            (pos_meet||posmeet_mask)&&
                            (posrate_meet||posratemeet_mask)&&
                            (driverpress)) ?1:0;

  if (driverBrake_intention == true) {
    IBAcount = 1;
  }

  if (IBAcount >0 && driverpress && IBAcount<= 50) {
    driverenableIBA = 1;
    IBAcount ++;
  }
  else {
    driverenableIBA = 0;
    IBAcount = 0;
  }

  // float ego_ROC;
  // ego_ROC = ROC(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
  //                   ego_->vehicleinfo_in.vehicledynamic.YawRateRps);

  // ego_state_aeb.vehspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  // ego_state_aeb.yawrate = ego_->vehicleinfo_in.vehicledynamic.YawRateRps;
  // ego_state_aeb.strwhlangle = ego_->vehicleinfo_in.steersys.StrWhlAg;
  // ego_state_aeb.hostreverse = hostReverse;
  // ego_state_aeb.brakepos = brakepos;
  ego_state_aeb.brakeposrate = brakeposrate;
  // ego_state_aeb.driverpress = driverpress;
  // ego_state_aeb.maincypress = maincylinderpress;
  // ego_state_aeb.maincypressrate = maincylinderpressrate;
  ego_state_aeb.driverintention = driverBrake_intention;
  ego_state_aeb.drivereba = driverenableIBA;
  // ego_state_aeb.steerrate = ego_->vehicleinfo_in.steersys.StrWhlAgSpd;
  // ego_state_aeb.roc = ego_ROC;
}

float AEBInHouse::ROC(float vehspd, float yrate) {
  if (fabsf(vehspd) >= 1.0) {
    if (vehspd / yrate >= MaxEgoRoc || yrate == 0.0f) {
      return MaxEgoRoc;
    } else if (vehspd / yrate <= -MaxEgoRoc) {
      return -MaxEgoRoc;
    } else {
      return vehspd / yrate;
    }
  }
  else {
    return MaxEgoRoc;
  }
}

void AEBInHouse::MatchVisInfo() {
  for (size_t i = 0; i < fmin(fused_obj_filtered.size(),MaxFusedObjIndex); i++){
    VisMatchID_[i].vis_id = MaxVisionIndex;
    for (size_t vis_i = 0; vis_i < vis_obj_ ->size(); vis_i++){
      if (vis_obj_->at(vis_i).ID == fused_obj_filtered.at(i).raw_data.fusion_sup.vision.ID && vis_obj_->at(vis_i).ID != 0) {
        VisMatchID_[i].vis_id = vis_i;
        // std::cout <<"in vis remap process =============================="<< std::endl;
        // std::cout << "fusion id is "<<(int)fused_obj_filtered.at(i).raw_data.ID<<" and vision ID is " << (int)vis_obj_->at(vis_i).ID << " and vision index is "<< (int)VisMatchID_[i].vis_id << std::endl;
        break;
      }
    }
  }
}

void AEBInHouse::MatchLFInfo() {
  for (int lf_i = 0; lf_i < MaxFusedObjIndex; lf_i++) {
    fus_lf_idx.pedcross_idx = MaxFusedObjIndex;
    fus_lf_idx.pedoncom_idx = MaxFusedObjIndex;
    fus_lf_idx.bikcross_idx = MaxFusedObjIndex;
    fus_lf_idx.bikoncom_idx = MaxFusedObjIndex;
    fus_lf_idx.ccrs1_idx = MaxFusedObjIndex;
    fus_lf_idx.ccrm1_idx = MaxFusedObjIndex;
    fus_lf_idx.ccftap_idx = MaxFusedObjIndex;
    if (fuseobj_lastframe_[lf_i].ID == vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID && vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID != 0){
      fus_lf_idx.pedcross_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID && vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID != 0){
      fus_lf_idx.pedoncom_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == vru_candidate.bicycle_cross_Candidate_.obj.u8_ID && vru_candidate.bicycle_cross_Candidate_.obj.u8_ID != 0){
      fus_lf_idx.bikcross_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID && vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID != 0){
      fus_lf_idx.bikoncom_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == ccr_candidate.CCRS_Candi_.u8_ID && ccr_candidate.CCRS_Candi_.u8_ID != 0){
      fus_lf_idx.ccrs1_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == ccr_candidate.CCRM_Candi_.u8_ID && ccr_candidate.CCRM_Candi_.u8_ID != 0){
      fus_lf_idx.ccrm1_idx = lf_i;
    }
    if (fuseobj_lastframe_[lf_i].ID == ftap_candidate.FTAP_Candi_.u8_ID && ftap_candidate.FTAP_Candi_.u8_ID != 0){
      fus_lf_idx.ccftap_idx = lf_i;
    }
  }
}

void AEBInHouse::Fill_FusObj_Lf() {
  for(size_t fus_i = 0; fus_i < fmin(fused_obj_filtered.size(),MaxFusedObjIndex); fus_i ++) {
    int int_i = 0;
    int_i = static_cast<int>(fus_i);
    fuseobj_lastframe_[int_i] = fused_obj_filtered.at(fus_i).raw_data;
    // if (int_i == 0 || int_i == 1 || int_i == 2 || int_i == 3) {
    //   std::cout << "there is a last frame target ===========================" << std::endl;
    //   std::cout << "last frame target ID is " << (int)fuseobj_lastframe_[int_i].ID <<std::endl;
    //   std::cout << "last frame target is valid is " << (int)fuseobj_lastframe_[int_i].IsValid() <<std::endl;
    //   std::cout << "last frame target posx is " << fuseobj_lastframe_[int_i].motion.GetPos().x <<std::endl;
    //   std::cout << "last frame target posy is " << fuseobj_lastframe_[int_i].motion.GetPos().y <<std::endl;
    //   std::cout << "last frame target velx is " << fuseobj_lastframe_[int_i].motion.GetVel().x <<std::endl;
    //   std::cout << "last frame target vely is " << fuseobj_lastframe_[int_i].motion.GetVel().y <<std::endl;
    //   std::cout << "last frame target isfused is " << (int)fuseobj_lastframe_[int_i].IsAllFused() <<std::endl;
    //   std::cout << "last frame target isvision only is " << (int)fuseobj_lastframe_[int_i].IsVisionOnly() <<std::endl;
    //   std::cout << "last frame target isradar only is " << (int)fuseobj_lastframe_[int_i].IsRadarOnly() <<std::endl;
    // }
  }
}

void AEBInHouse::DecideSupression() {
  //std::cout << "updatesuppression start"<<std::endl;
  //auto ts = Time::Now();
  float hostspd;
  float hostyawrt;
  uint8_t hostgear;
  float maincyclinderpress;
  float accelpos;
  float hoststeerang;
  float accelposrate;
  float brakeposition;
  bool driverpressed;
  //bool strangtoohigh = 0;
  //bool strangtoofast = 0;
  hostspd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdkph/Mps2Kph;
  hostyawrt = ego_->vehicleinfo_in.vehicledynamic.YawRateRps;
  hostgear = ego_->vehicleinfo_in.vehiclept.Gear.ActGear;
  maincyclinderpress = ego_->vehicleinfo_in.brakesys.BrkPrs.BrkPrs;
  hoststeerang = ego_->vehicleinfo_in.steersys.StrWhlAg;
  accelpos = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn;
  accelposrate = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate;
  brakeposition = ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl;
  driverpressed = (static_cast<uint8_t>(ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts) == 1);

  speedhighsupr_LF = speedhighsupr;
  speedhighsupr = 0;
  speedlowsupr_LF = speedlowsupr;
  speedlowsupr = 0;
  yawrthighsupr_LF = yawrthighsupr;
  yawrthighsupr = 0;
  brakepresssupr_LF = brakepresssupr;
  brakepresssupr = 0;
  steerhighsupr_LF = steerhighsupr;
  steerhighsupr = 0;
  strspdhighsupr_LF = strspdhighsupr;
  strspdhighsupr = 0;
  accposhighsupr_LF = accposhighsupr;
  accposhighsupr = 0;
  accposrthighsupr_LF = accposrthighsupr;
  accposrthighsupr = 0;

  speedhighact = 0;
  speedlowact = 0;
  yawrthighact = 0;
  brakepressact = 0;
  steerhighact = 0;
  strspdhighact = 0;
  accposhighact = 0;
  accposrthighact =0;

  AEBSupressReason = 0x0000;
  AEBSupressReason_AfterPref = 0x0000;
  AEBSupressReason_AfterLowB = 0x0000;
  AEBSupressReason_AfterHighB = 0x0000;
  AEBSupressReason_SpeedLow = 0;
  AEBSupressReason_CCFTAP = 0x0000;
  AEBSupressReason_IBA = 0x0000;

  if (hostspd > SupressSpdHighThres) {
    speedhighact = 1;
    // AEBSupressReason = AEBSupressReason + 0x0001;
    // AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0001;
    // AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0001;
    // AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0001;
    // egospd too high
  }

  if (hostspd > SupressSpdLowThres) {
    //AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0001;
  }

  if (hostspd < SuppressMinSpd) {
    speedlowact = 1;
    // AEBSupressReason = AEBSupressReason + 0x0002;
    AEBSupressReason_SpeedLow = 1;
    // egospd too low
  }

  if (hostspd > SuppressFtapSpdThres) {
    AEBSupressReason_CCFTAP = AEBSupressReason_CCFTAP + 0x0001;
  }

  if (fabsf(hostyawrt) > 1.0f) {
    yawrthighact = 1;
    // AEBSupressReason = AEBSupressReason + 0x0004;
    // AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0004;
    // AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0004;
    // AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0004;
    // yaw rate too high
  }

  if (fabsf(hostyawrt) < 0.1) {
    AEBSupressReason_CCFTAP = AEBSupressReason_CCFTAP + 0x0080;
    // yaw rate too low
  }

  if (hostgear != 1) {
    AEBSupressReason = AEBSupressReason + 0x0008;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0008;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0008;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0008;
    // host vehicle is not in D gear
  }

  if ((maincyclinderpress > SuppressMcPressThres || brakeposition > SuppressBrkPos1) && driverpressed == 1) {
    brakepressact = 1;
    AEBSupressReason = AEBSupressReason + 0x0010;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0010;
    // brake pressure too high when AEB not engage
  }

  if ((maincyclinderpress > SuppressMcPressThres || brakeposition > SuppressBrkPos2) && driverpressed == 1) {
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0010;
    // brake pressure too high when AEB low engage
  }

  if ((maincyclinderpress > SuppressMcPressThres || brakeposition > SuppressBrkPos3) && driverpressed == 1) {
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0010;
    // brake pressure too high when AEB high engage
  }

  if (fabsf(hoststeerang) > SuppressSteerAngThres) {
    steerhighact = 1;
    // AEBSupressReason = AEBSupressReason + 0x0020;
    // AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0020;
    // AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0020;
    // AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0020;
    // steering wheel angle too high
  }

  if (((fabsf(deltasteerang)) / time_interval) > 1000) {
    strspdhighact = 1;
    // AEBSupressReason = AEBSupressReason + 0x0040;
    // AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0040;
    // AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0040;
    // AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0040;
    // steering wheel angle speed too high
  }

  if (accelpos > SuppressAccPosThres) {
    accposhighact = 1;
  }

  if (accelposrate > SuppressAccRateThres) {
    accposrthighact = 1;
  }

  speedhighsupr = SuppressionActive(speedhighact, speedhigh_count,
                                    speedhighsupr_LF, threshold_speedhigh_);

  speedlowsupr = SuppressionActive(speedlowact, speedlow_count, speedlowsupr_LF,
                                   threshold_speedlow_);

  yawrthighsupr = SuppressionActive(yawrthighact, yawrthigh_count,
                                    yawrthighsupr_LF, threshold_yawrthigh_);

  steerhighsupr = SuppressionActive(steerhighact, steerhigh_count,
                                    steerhighsupr_LF, threshold_steerhigh_);

  strspdhighsupr = SuppressionActive(strspdhighact, strspdhigh_count,
                                     strspdhighsupr_LF, threshold_strspdhigh_);

  accposhighsupr = SuppressionActive(accposhighact, accposhigh_count,
                                     accposhighsupr_LF, threshold_accposhigh_);

  accposrthighsupr = SuppressionActive(accposrthighact, accposrthigh_count,
                                     accposrthighsupr_LF, threshold_accposrthigh_);

  if (speedhighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0001;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0001;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0001;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0001;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0X0001;
  }

  if (speedlowsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0002;
    AEBSupressReason_SpeedLow = 1;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0002;
  }

  if (yawrthighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0004;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0004;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0004;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0004;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0004;
  }

  // if (brakepresssupr == 1) {
  //   AEBSupressReason = AEBSupressReason + 0x0010;
  //   AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0010;
  // }

  if (steerhighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0020;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0020;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0020;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0020;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0020;
  }

  if (strspdhighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0040;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0040;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0040;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0040;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0040;
  }

  if (accposhighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0080;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0080;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0080;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0080;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0080;
  }

  if (accposrthighsupr == 1) {
    AEBSupressReason = AEBSupressReason + 0x0100;
    AEBSupressReason_AfterPref = AEBSupressReason_AfterPref + 0x0100;
    AEBSupressReason_AfterLowB = AEBSupressReason_AfterLowB + 0x0100;
    AEBSupressReason_AfterHighB = AEBSupressReason_AfterHighB + 0x0100;
    AEBSupressReason_IBA = AEBSupressReason_IBA + 0x0100;
  }

  /*asap2::Measurement(&EAEB_AEBSuppressReason_mp, AEBSupressReason);
  asap2::Measurement(&EAEB_AEBSuppressReasonPref_mp,
                     AEBSupressReason_AfterPref);
  asap2::Measurement(&EAEB_AEBSuppressReasonLow_mp, AEBSupressReason_AfterLowB);
  asap2::Measurement(&EAEB_AEBSuppressReasonHigh_mp,
                     AEBSupressReason_AfterHighB);*/
  //auto dur = Time::Now() - ts;                   
  //std::cout << "updatesuppression complete,cost time"<<dur<<"ms"<<std::endl;
}

bool AEBInHouse::SuppressionActive(bool issuppressed,
                                   uint8_t &suppression_counter,
                                   bool suppressst_lf, uint8_t duration) {
  bool suppressst = 0;
  if (issuppressed == 1) {
    suppression_counter = 1;
    suppressst = 1;
  } else if (issuppressed == 0 && suppressst_lf == 1) {
    suppression_counter++;
    if (suppression_counter <= duration && suppression_counter >0) {
      suppressst = 1;
      //suppression_counter = duration;
    } else {
      suppressst = 0;
      suppression_counter = 0;
    }
  } else {
    suppressst = 0;
    suppression_counter = 0;
  }
  return suppressst;
}

void AEBInHouse::CCRSteerArbi() {
  clearsteerflag();

  //AEBSupressReason_AfterPref = 0;
  bool targetinrange = 0;
  bool targetvalid = 0;
  bool host_already_inlane = 0;
  float lpp_c1 = ego_->ehy_tpp.tpp_trajectory.c1;
  aes_hold_ready = 0;

  if ((aes_candidate.AESCCR1_Candi_.u8_ID > 0 && aes_candidate.AESCCR1_Candi_.steer_flag > 0) && (aes_candidate.AESCCR2_Candi_.u8_ID > 0 && aes_candidate.AESCCR2_Candi_.steer_flag > 0)) {
    //AEBSupressReason_AfterPref = 1;
    if (aes_candidate.AESCCR1_Candi_.f4_range < aes_candidate.AESCCR2_Candi_.f4_range || (aes_candidate.AESCCR1_Candi_.f4_range == aes_candidate.AESCCR2_Candi_.f4_range && aes_candidate.AESCCR1_Candi_.f4_TTC < aes_candidate.AESCCR2_Candi_.f4_TTC)) {
      
      update_aesctrl(aes_candidate.AESCCR1_Candi_, aes_ctrl_input);
    }
    else {
      update_aesctrl(aes_candidate.AESCCR2_Candi_, aes_ctrl_input);
    }
  }
  else if ((aes_candidate.AESCCR1_Candi_.u8_ID > 0 && aes_candidate.AESCCR1_Candi_.steer_flag > 0) && (aes_candidate.AESCCR2_Candi_.u8_ID == 0 || aes_candidate.AESCCR2_Candi_.steer_flag == 0)) {
    //AEBSupressReason_AfterPref = 2;
    update_aesctrl(aes_candidate.AESCCR1_Candi_, aes_ctrl_input);
  }
  else if ((aes_candidate.AESCCR2_Candi_.u8_ID > 0 && aes_candidate.AESCCR2_Candi_.steer_flag > 0) && (aes_candidate.AESCCR1_Candi_.u8_ID == 0 || aes_candidate.AESCCR1_Candi_.steer_flag == 0)) {
    //AEBSupressReason_AfterPref = 3;
    update_aesctrl(aes_candidate.AESCCR2_Candi_, aes_ctrl_input);
  }
  else {
    //AEBSupressReason_AfterPref = 4;
    aes_ctrl_input.explatdst = 0;
    aes_ctrl_input.explondst = 0;
    aes_ctrl_input.aesplanactv = 0;
    aes_ctrl_input.steering_direction = 0;
  }
  aes_ctrl_input.ltrldstlacntr = ego_->ehy_tpp.tpp_trajectory.c0;
  aes_ctrl_input.egolawdth = ego_->ehy_tpp.tpp_trajectory.lm_width;
  aes_ctrl_input.agvehlanecntr = ego_->ehy_tpp.tpp_trajectory.c1;
  aes_ctrl_input.lacurv = ego_->ehy_tpp.tpp_trajectory.c2;
  aes_ctrl_input.ladcurv = ego_->ehy_tpp.tpp_trajectory.c3;
  aes_ctrl_input.vehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdkph;
  aes_ctrl_input.dispvehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehDispSpd;

  if (aes_ctrl_input_lf.aesplanactv > 0 && aes_ctrl_input.aesplanactv == 0 && aes_hold_age == 0){
    //AEBSupressReason_AfterPref = 5;
    for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
      if (fused_obj_filtered.at(i).raw_data.ID == aes_ctrl_input_lf.aesplanactv) {
        //AEBSupressReason_AfterPref = 6;
        AESObjectCCR tmp_objCCR;
        tmp_objCCR.obj = fused_obj_filtered.at(i).raw_data;

        float range = 0;
        float vego = 0;
        float vtar = 0;
        //AEBSupressReason_AfterLowB = 0;
        //AEBSupressReason_AfterHighB = 0;
        range = sqrtf((tmp_objCCR.obj.motion.GetX()-3.9) * (tmp_objCCR.obj.motion.GetX()-3.9) + tmp_objCCR.obj.motion.GetY() * tmp_objCCR.obj.motion.GetY());
        vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        vtar = tmp_objCCR.obj.motion.GetVx();
        if (tmp_objCCR.obj.IsValid() == 1) {
          targetvalid = 1;
        }
        if (tmp_objCCR.obj.motion.GetX() >=0) {
          targetinrange = 1;
        }
        if (fabsf(lpp_c1) <= k_AESInLaneC1_limitation) {
          host_already_inlane = 1;
        }

        if (((targetvalid == 1 && targetinrange == 1)) /*&& host_already_inlane == 0*/) {
          float longest = 0;
          longest = (range-2) * vego/(vego-vtar);
          aes_ctrl_input = aes_ctrl_input_lf;
          if (longest >= k_AESMinPlanRange && longest <= k_AESMaxPlanRange) {
            aes_ctrl_input.explondst = longest;
          }
          else if (longest > k_AESMaxPlanRange) {
            aes_ctrl_input.explondst = k_AESMaxPlanRange;
          }
          else {
            aes_ctrl_input.explondst = k_AESMinPlanRange;
          }
          aes_ctrl_input.ltrldstlacntr = ego_->ehy_tpp.tpp_trajectory.c0;
          aes_ctrl_input.egolawdth = ego_->ehy_tpp.tpp_trajectory.lm_width;
          aes_ctrl_input.agvehlanecntr = ego_->ehy_tpp.tpp_trajectory.c1;
          aes_ctrl_input.lacurv = ego_->ehy_tpp.tpp_trajectory.c2;
          aes_ctrl_input.ladcurv = ego_->ehy_tpp.tpp_trajectory.c3;
          aes_ctrl_input.vehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdkph;
          aes_ctrl_input.dispvehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehDispSpd;
          aes_hold_ready = 1;
        }
        else if (aes_hold_ready == 1) {
          aes_hold_age = 100;
        }
      }
    }
  }
  else if (aes_hold_age > 0) {
    aes_ctrl_input = aes_ctrl_input_lf;
    aes_ctrl_input.aesplanactv = 1;
    aes_ctrl_input.ltrldstlacntr = ego_->ehy_tpp.tpp_trajectory.c0;
    aes_ctrl_input.egolawdth = ego_->ehy_tpp.tpp_trajectory.lm_width;
    aes_ctrl_input.agvehlanecntr = ego_->ehy_tpp.tpp_trajectory.c1;
    aes_ctrl_input.lacurv = ego_->ehy_tpp.tpp_trajectory.c2;
    aes_ctrl_input.ladcurv = ego_->ehy_tpp.tpp_trajectory.c3;
    aes_ctrl_input.vehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdkph;
    aes_ctrl_input.dispvehspdkph = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehDispSpd;
    aes_hold_age = aes_hold_age - 1;
  }

  aes_ctrl_input_lf = aes_ctrl_input;
}

void AEBInHouse::update_aesctrl(AESObjectCCR &ccr_candi, AES_Control_Input &aes_ctrl){
  float latpos_estimation = 0;
  float longpos_estimation = 0;
  float latpos_frenet = 0;
  float latpos_delta = 0;
  float latpos_sign = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float lpp_c0 = ego_->ehy_tpp.tpp_trajectory.c0;
  float lpp_c1 = ego_->ehy_tpp.tpp_trajectory.c1;
  float lpp_c2 = ego_->ehy_tpp.tpp_trajectory.c2;
  float target_width = k_AESDefaultVehicleWidth;
  if (ccr_candi.obj.width() < 1 || ccr_candi.obj.width() > 4) {
    target_width = k_AESDefaultVehicleWidth;
  }
  else {
    target_width = ccr_candi.obj.width();
  }

  if (ccr_candi.u8_closest_corner_estimate == 5) {
    latpos_estimation = ccr_candi.obj.motion.GetY() + (ccr_candi.obj.motion.GetVy() * ccr_candi.f4_TTC);
    longpos_estimation = -((ccr_candi.f4_range -2) * vego)/ccr_candi.f4_rangerate;
    latpos_frenet = lpp_c0 + lpp_c1 * longpos_estimation + lpp_c2 * longpos_estimation * longpos_estimation;

    latpos_delta = latpos_estimation - latpos_frenet;
    latpos_sign = ccr_candi.steer_direction;

    aes_ctrl.explatdst = (latpos_delta + (1.1 + target_width * 0.5 + k_AESLateralSafeZone) * latpos_sign) * -1;
    if (longpos_estimation >= k_AESMinPlanRange && longpos_estimation <= k_AESMaxPlanRange) {
      aes_ctrl.explondst = longpos_estimation;
    }
    else if (longpos_estimation > k_AESMaxPlanRange) {
      aes_ctrl.explondst = k_AESMaxPlanRange;
    }
    else {
      aes_ctrl.explondst = k_AESMinPlanRange;
    }
    
    aes_ctrl.aesplanactv = ccr_candi.u8_ID;
  }
  else if (ccr_candi.u8_closest_corner_estimate == 1) {
    update_aescorner(ccr_candi.close_left, ccr_candi, aes_ctrl);
  }
  else if (ccr_candi.u8_closest_corner_estimate == 2) {
    update_aescorner(ccr_candi.close_right, ccr_candi, aes_ctrl);
  }
  else if (ccr_candi.u8_closest_corner_estimate == 3) {
    update_aescorner(ccr_candi.remote_left, ccr_candi, aes_ctrl);
  }
  else if (ccr_candi.u8_closest_corner_estimate == 4) {
    update_aescorner(ccr_candi.remote_right, ccr_candi, aes_ctrl);
  }

  aes_ctrl.steering_direction = ccr_candi.steer_direction;
}

void AEBInHouse::update_aescorner (CornerPos &point, AESObjectCCR &ccr_candi, AES_Control_Input &aes_ctrl) {
  float latpos_estimation = 0;
  float longpos_estimation = 0;
  float latpos_frenet = 0;
  float latpos_delta = 0;
  float latpos_sign = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float lpp_c0 = ego_->ehy_tpp.tpp_trajectory.c0;
  float lpp_c1 = ego_->ehy_tpp.tpp_trajectory.c1;
  float lpp_c2 = ego_->ehy_tpp.tpp_trajectory.c2;
  latpos_estimation = point.pos_y + (ccr_candi.obj.motion.GetVy() * ccr_candi.f4_TTC);
  longpos_estimation = -((point.range - 2) * vego)/ccr_candi.f4_rangerate;
  latpos_frenet = lpp_c0 + lpp_c1 * longpos_estimation + lpp_c2 * longpos_estimation * longpos_estimation;

  latpos_delta = latpos_estimation - latpos_frenet;
  latpos_sign = ccr_candi.steer_direction;

  aes_ctrl.explatdst = (latpos_delta + (1.1 + k_AESLateralSafeZone) * latpos_sign) * -1;
  if (longpos_estimation >= k_AESMinPlanRange && longpos_estimation <= k_AESMaxPlanRange) {
    aes_ctrl.explondst = longpos_estimation;
  }
  else if (longpos_estimation > k_AESMaxPlanRange) {
    aes_ctrl.explondst = k_AESMaxPlanRange;
  }
  else {
    aes_ctrl.explondst = k_AESMinPlanRange;
  }
  
  aes_ctrl.aesplanactv = ccr_candi.u8_ID;
}

void AEBInHouse::clearsteerflag() {
  aes_ctrl_input.explatdst = 0;
  aes_ctrl_input.explondst = 0;
  aes_ctrl_input.aesplanactv = 0;
}

void AEBInHouse::CCRBrakeArbi() {
  /*uint8_t ME_VD_High = 0;
  uint8_t ME_VD_Low = 0;
  uint8_t ME_VD_Warn = 0;
  uint8_t ME_VD_Pref = 0;*/

  /*auto &me_aeb = SIN_out.Sens_out.CAMC_in.CAMC_FcwAeb;
  if (me_aeb.VD_alertPattern_setE == kAEBAlertActive) {
    ME_VD_High = 1;
  }
  if (me_aeb.VD_alertPattern_setD == kAEBAlertActive) {
    ME_VD_Low = 1;
  }
  if (me_aeb.VD_alertPattern_setB == kAEBAlertActive) {
    ME_VD_Pref = 1;
  }
  if (me_aeb.VD_alertPattern_setA == kAEBAlertActive) {
    ME_VD_Warn = 1;
  }*/
  uint8_t     ego_gear    = ego_->vehicleinfo_in.vehiclept.Gear.ActGear; //1: Drive 2:Reverse 3:Parking

  FusionCCRFlag_LF = FusionCCRFlag_;
  
  if(ego_gear == 1){
  ClearCCRFlag();
  if ((ccr_candidate.CCRS_Candi_.highbrake_flag == 1 || ccr_candidate.CCRS_Candi_2_.highbrake_flag == 1 ||
       ccr_candidate.CCRM_Candi_.highbrake_flag == 1 || ccr_candidate.CCRM_Candi_2_.highbrake_flag == 1 ||
       ftap_candidate.FTAP_Candi_.highbrake_flag > 0 || ftap_candidate.FTAP_Candi_2_.highbrake_flag > 0) &&
      (FusionCCRFlag_.lowbrake_age >= kAEBlowbrakeminage ||
       ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps <= FusionSpdThres)) {
    FusionCCRFlag_.highbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.lowbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.prefill_flag = kAEBAlertActive;
    FusionCCRFlag_.Warning_flag = kAEBAlertActive;
    FusionCCRFlag_.highbrake_hold_age = 0;
  } else if (((ccr_candidate.CCRS_Candi_.highbrake_flag == 0 &&
               ccr_candidate.CCRS_Candi_2_.highbrake_flag == 0 &&
               ccr_candidate.CCRM_Candi_.highbrake_flag == 0 &&
               ccr_candidate.CCRM_Candi_2_.highbrake_flag == 0 &&
               ftap_candidate.FTAP_Candi_.highbrake_flag == 0 &&
               ftap_candidate.FTAP_Candi_2_.highbrake_flag == 0) &&
              FusionCCRFlag_LF.highbrake_flag == kAEBAlertActive) &&
             (FusionCCRFlag_.highbrake_hold_age <= MaxCcrHighBrakeHoldAge ||
              (fabsf(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps) <= MaxHoldVehSpdMps && 
              ((FusionCCRFlag_.highbrake_hold_age <= FusionHoldAgeThres || 
              ego_->vehicleinfo_in.brakesys.BrkFunSt.AVHSts == static_cast<AvhSts_e>(1)) &&
              ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn < MaxHoldAccPedPos && 
              ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl < MaxHoldBrkPedTrvl && 
              ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts == static_cast<BrkPdlSts_e>(0))))) {
    FusionCCRFlag_.hold_flag = kAEBAlertActive;
    FusionCCRFlag_.highbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.lowbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.prefill_flag = kAEBAlertActive;
    FusionCCRFlag_.Warning_flag = kAEBAlertNoActive;
    FusionCCRFlag_.highbrake_hold_age = FusionCCRFlag_LF.highbrake_hold_age + 1;
  } else if ((ccr_candidate.CCRS_Candi_.highbrake_flag == 1 ||
              ccr_candidate.CCRS_Candi_2_.highbrake_flag == 1 ||
              ccr_candidate.CCRM_Candi_.highbrake_flag == 1 ||
              ccr_candidate.CCRM_Candi_2_.highbrake_flag == 1 ||
              ftap_candidate.FTAP_Candi_.highbrake_flag > 0 ||
              ftap_candidate.FTAP_Candi_2_.highbrake_flag > 0) &&
             (FusionCCRFlag_.lowbrake_age < kAEBlowbrakeminage &&
              ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > FusionSpdThres)) {
    FusionCCRFlag_.lowbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.prefill_flag = kAEBAlertActive;
    FusionCCRFlag_.Warning_flag = kAEBAlertActive;
    FusionCCRFlag_.lowbrake_age = FusionCCRFlag_LF.lowbrake_age + 1;
    FusionCCRFlag_.highbrake_hold_age = 0;
  } else if ((ccr_candidate.CCRS_Candi_.lowbrake_flag == 1 ||
              ccr_candidate.CCRS_Candi_2_.lowbrake_flag == 1 ||
              ccr_candidate.CCRM_Candi_.lowbrake_flag == 1 ||
              ccr_candidate.CCRM_Candi_2_.lowbrake_flag == 1 ||
              ftap_candidate.FTAP_Candi_.lowbrake_flag > 0 ||
              ftap_candidate.FTAP_Candi_2_.lowbrake_flag > 0)) {
    FusionCCRFlag_.lowbrake_flag = kAEBAlertActive;
    FusionCCRFlag_.prefill_flag = kAEBAlertActive;
    FusionCCRFlag_.Warning_flag = kAEBAlertActive;
    FusionCCRFlag_.lowbrake_age = FusionCCRFlag_LF.lowbrake_age + 1;
    FusionCCRFlag_.highbrake_hold_age = 0;
  } else if ((ccr_candidate.CCRS_Candi_.prefill_flag == 1 ||
              ccr_candidate.CCRS_Candi_2_.prefill_flag == 1 ||
              ccr_candidate.CCRM_Candi_.prefill_flag == 1 ||
              ccr_candidate.CCRM_Candi_2_.prefill_flag == 1 || ftap_candidate.FTAP_Candi_.prefill_flag > 0 ||
              ftap_candidate.FTAP_Candi_2_.prefill_flag > 0)) {
    FusionCCRFlag_.prefill_flag = kAEBAlertActive;
    FusionCCRFlag_.Warning_flag = kAEBAlertActive;
    FusionCCRFlag_.highbrake_hold_age = 0;
  } else if ((ccr_candidate.CCRS_Candi_.warnig_flag == 1 || ccr_candidate.CCRS_Candi_2_.warnig_flag == 1 ||
              ccr_candidate.CCRM_Candi_.warnig_flag == 1 || ccr_candidate.CCRM_Candi_2_.warnig_flag == 1 ||
              ftap_candidate.FTAP_Candi_.warnig_flag > 0 || ftap_candidate.FTAP_Candi_2_.warnig_flag > 0)) {
    FusionCCRFlag_.Warning_flag = kAEBAlertActive;
    FusionCCRFlag_.highbrake_hold_age = 0;
  } else {
    FusionCCRFlag_.lowbrake_age = 0;
    FusionCCRFlag_.highbrake_hold_age = 0;
  }

  if (((ccr_candidate.CCRS_Candi_.warnig_flag == 1 && 
        ccr_candidate.CCRS_Candi_.lowbrake_flag == 0 && 
        ccr_candidate.CCRS_Candi_.highbrake_flag == 0 &&
        ccr_candidate.CCRS_Candi_.f4_TTC >= 1.1 &&
        ccr_candidate.CCRS_Candi_.f4_TTC <= 1.9) || 

          (ccr_candidate.CCRS_Candi_2_.warnig_flag == 1 &&
          ccr_candidate.CCRS_Candi_2_.lowbrake_flag == 0 &&
          ccr_candidate.CCRS_Candi_2_.highbrake_flag == 0 &&
          ccr_candidate.CCRS_Candi_2_.f4_TTC >= 1.1 &&
        ccr_candidate.CCRS_Candi_2_.f4_TTC <= 1.9) ||

          (ccr_candidate.CCRM_Candi_.warnig_flag == 1 &&
          ccr_candidate.CCRM_Candi_.lowbrake_flag == 0 &&
          ccr_candidate.CCRM_Candi_.highbrake_flag == 0 &&
          ccr_candidate.CCRM_Candi_.f4_TTC >= 1.1 &&
        ccr_candidate.CCRM_Candi_.f4_TTC <= 1.9) ||

          (ccr_candidate.CCRM_Candi_2_.warnig_flag == 1 &&
          ccr_candidate.CCRM_Candi_2_.lowbrake_flag == 0 &&
          ccr_candidate.CCRM_Candi_2_.highbrake_flag == 0 &&
          ccr_candidate.CCRM_Candi_2_.f4_TTC >= 1.1 &&
        ccr_candidate.CCRM_Candi_2_.f4_TTC <= 1.9)) &&
          ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps >= 15.28 && fabsf(ego_->vehicleinfo_in.vehicledynamic.LgtAg) < 0.1 && fabsf(ego_->vehicleinfo_in.steersys.StrWhlAg) <= 5) {

    FusionCCRFlag_.warnbrake_flag = kAEBAlertActive;
  }
  else {
    FusionCCRFlag_.warnbrake_flag = kAEBAlertNoActive;
  }

  if ((ccr_candidate.CCRS_Candi_.iba_flag == 1 ||
      ccr_candidate.CCRS_Candi_2_.iba_flag == 1 || 
      ccr_candidate.CCRM_Candi_.iba_flag == 1 || 
      ccr_candidate.CCRM_Candi_2_.iba_flag == 1 || 
      ftap_candidate.FTAP_Candi_.iba_flag > 0 || 
      ftap_candidate.FTAP_Candi_2_.iba_flag > 0)&& 
      driverenableIBA == 1){
    FusionCCRFlag_.readyforIBA = 1;
  }
  else {
    FusionCCRFlag_.readyforIBA = 0;
  }
  if (FusionCCRFlag_.warnbrake_flag == kAEBAlertActive || FusionCCRFlag_.lowbrake_flag == kAEBAlertActive || FusionCCRFlag_.highbrake_flag == kAEBAlertActive || FusionCCRFlag_.readyforIBA == 1) {
    AEBDumpSuppress = 25;
  }
  }
  else{
    ClearCCRFlag();
    ClearCCRAge();
    //AEBDumpSuppress = 0;
  }
}

void AEBInHouse::BrakeDecisionArbi() {
  /*uint8_t ME_PD_High = 0;
  uint8_t ME_PD_Low = 0;
  uint8_t ME_PD_Warn = 0;
  uint8_t ME_PD_Pref = 0;*/

  /*auto &me_aeb = SIN_out.Sens_out.CAMC_in.CAMC_FcwAeb;
  if (me_aeb.PD_alertPattern_L1 == kAEBAlertActive) {
    ME_PD_High = 1;
  }
  if (me_aeb.PD_alertPattern_L2 == kAEBAlertActive) {
    ME_PD_Low = 1;
  }
  if (me_aeb.PD_alertPattern_L3 == kAEBAlertActive) {
    ME_PD_Pref = 1;
  }
  if (me_aeb.PD_alertPattern_L4 == kAEBAlertActive) {
    ME_PD_Warn = 1;
  }*/
  uint8_t     ego_gear    = ego_->vehicleinfo_in.vehiclept.Gear.ActGear; //1: Drive 2:Reverse 3:Parking

  FusionVRUFlag_LF      = FusionVRUFlag_;

  if(ego_gear == 1){
  ClearVruFlag();

  if ((vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0 ||
       vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0 ||
       vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0 ||
       vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0) &&
      ((FusionVRUFlag_.lowbrake_age >= kAEBlowbrakeminage &&
        ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps >= FusionSpdThres) ||
       ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps < FusionSpdThres)) {
    FusionVRUFlag_.highbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.highbrake_hold_age = 0;
    // high brake can only be engaged when the target have been selected as low
    // brake candidate for 200ms continuously;
  } else if (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake == 0 &&
             vru_candidate.bicycle_cross_Candidate_.u8_highBrake == 0 &&
             vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake == 0 &&
             vru_candidate.bicycle_oncom_Candidate_.u8_highBrake == 0 &&
             FusionVRUFlag_LF.highbrake_flag == kAEBAlertActive &&
             FusionVRUFlag_.lowbrake_flag == kAEBAlertNoActive &&
             (( fabsf(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps) <= MaxHoldVehSpdMps && 
             (((FusionVRUFlag_.highbrake_hold_age <= FusionHoldAgeThres || 
             ego_->vehicleinfo_in.brakesys.BrkFunSt.AVHSts == static_cast<AvhSts_e>(1)) && 
             ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn < MaxHoldAccPedPos && 
             ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl < MaxHoldBrkPedTrvl && 
             ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts == static_cast<BrkPdlSts_e>(0)))) ||
              (FusionVRUFlag_.highbrake_hold_age <= MaxVruHighBrakeHoldAge))) {
    FusionVRUFlag_.hold_flag = kAEBAlertActive;
    FusionVRUFlag_.highbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertNoActive;
    FusionVRUFlag_.highbrake_hold_age++;
    // high brake will hold for 200ms when target is lost in close range or  ego
    // speed is lower than 1m/s;
  } else if ((vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0 ||
              vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0 ||
              vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0 ||
              vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0) &&
             FusionVRUFlag_.lowbrake_age < kAEBlowbrakeminage &&
             ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps >= FusionSpdThres) {
    FusionVRUFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.lowbrake_age++;
    FusionVRUFlag_.highbrake_hold_age = 0;
  } else if ((vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.pedestrian_cross_Candidate_.u8_lastselectID ==
               vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.bicycle_cross_Candidate_.u8_lastselectID ==
               vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.pedestrian_oncom_Candidate_.u8_lastselectID ==
               vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.bicycle_oncom_Candidate_.u8_lastselectID ==
               vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID))) {
    FusionVRUFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.lowbrake_age++;
    FusionVRUFlag_.highbrake_hold_age = 0;
  } else if ((vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.pedestrian_cross_Candidate_.u8_lastselectID !=
               vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.bicycle_cross_Candidate_.u8_lastselectID !=
               vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.pedestrian_oncom_Candidate_.u8_lastselectID !=
               vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID)) ||
             (vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0 &&
              (vru_candidate.bicycle_oncom_Candidate_.u8_lastselectID !=
               vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID))) {
    FusionVRUFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRUFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.lowbrake_age = 1;
    FusionVRUFlag_.highbrake_hold_age = 0;
  } else if ((vru_candidate.pedestrian_cross_Candidate_.u8_prefill > 0 ||
              vru_candidate.bicycle_cross_Candidate_.u8_prefill > 0 ||
              vru_candidate.pedestrian_oncom_Candidate_.u8_prefill > 0 ||
              vru_candidate.bicycle_oncom_Candidate_.u8_prefill > 0) &&
             FusionVRUFlag_.highbrake_flag == kAEBAlertNoActive &&
             FusionVRUFlag_.lowbrake_flag == kAEBAlertNoActive) {
    FusionVRUFlag_.prefill_flag = kAEBAlertActive;
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.highbrake_hold_age = 0;
  } else if (vru_candidate.pedestrian_cross_Candidate_.u8_warning > 0 ||
             vru_candidate.bicycle_cross_Candidate_.u8_warning > 0 ||
             vru_candidate.pedestrian_oncom_Candidate_.u8_warning > 0 ||
             vru_candidate.bicycle_oncom_Candidate_.u8_warning > 0) {
    FusionVRUFlag_.Warning_flag = kAEBAlertActive;
    FusionVRUFlag_.highbrake_hold_age = 0;

  } else {
    FusionVRUFlag_.lowbrake_age = 0;
    FusionVRUFlag_.highbrake_hold_age = 0;
  }
  if (FusionVRUFlag_.lowbrake_flag == kAEBAlertActive || FusionVRUFlag_.highbrake_flag == kAEBAlertActive) {
    AEBDumpSuppress = 25;
  }
  }
  else{
    ClearVruFlag();
    ClearVruAge();
    //AEBDumpSuppress = 0;
  }

}

void AEBInHouse::VruRearFlagArbi(){
  float       ego_vx      = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  AvhSts_e    ego_avhsts  = ego_->vehicleinfo_in.brakesys.BrkFunSt.AVHSts;
  float       ego_acc_pos = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn;
  float       ego_brk_pos = ego_->vehicleinfo_in.brakesys.BrkPdl.Trvl;
  BrkPdlSts_e ego_brk_sts = ego_->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts;
  uint8_t     ego_gear    = ego_->vehicleinfo_in.vehiclept.Gear.ActGear; //1: Drive 2:Reverse 3:Parking
  FusionVRURearFlag_LF = FusionVRURearFlag_;

  if(ego_gear == 2){
  ClearVruRearFlag();
  if(vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0){
    FusionVRURearFlag_.highbrake_flag       = kAEBAlertActive;
    FusionVRURearFlag_.lowbrake_flag        = kAEBAlertActive;
    FusionVRURearFlag_.unconfirmed_flag     = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag         = kAEBAlertActive;
    FusionVRURearFlag_.highbrake_hold_age   = 0;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake == 0 &&
          FusionVRURearFlag_LF.highbrake_flag == kAEBAlertActive &&
          FusionVRURearFlag_.lowbrake_flag    == kAEBAlertNoActive &&
          ((fabsf(ego_vx) <= MaxHoldVehSpdMpsRear &&
          (FusionVRURearFlag_.highbrake_hold_age <= FusionHoldAgeRearThres || ego_avhsts == AvhSts_e::Avh_Stdby) &&
          ego_acc_pos < MaxHoldAccPedPosRear &&
          ego_brk_pos < MaxHoldBrkPedTrvlRear &&
          ego_brk_sts == BrkPdlSts_e::NotPrssd) ||
          FusionVRURearFlag_.highbrake_hold_age <= MaxVruHighBrakeHoldRearAge)){
    FusionVRURearFlag_.hold_flag        = kAEBAlertActive;
    FusionVRURearFlag_.highbrake_flag   = kAEBAlertActive;
    FusionVRURearFlag_.lowbrake_flag    = kAEBAlertActive;
    FusionVRURearFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag     = kAEBAlertNoActive;
    FusionVRURearFlag_.highbrake_hold_age++;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0 && 
          FusionVRURearFlag_.lowbrake_age < MinRearLowBrkAge){
    FusionVRURearFlag_.lowbrake_flag = kAEBAlertActive;
    FusionVRURearFlag_.unconfirmed_flag = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag = kAEBAlertActive;
    FusionVRURearFlag_.lowbrake_age++;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0 &&
          vru_candidate.pedestrian_rearcross_Candidate_.u8_lastselectID ==
          vru_candidate.pedestrian_rearcross_Candidate_.u8_Candi_ID){
    FusionVRURearFlag_.lowbrake_flag      = kAEBAlertActive;
    FusionVRURearFlag_.unconfirmed_flag   = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag       = kAEBAlertActive;
    FusionVRURearFlag_.lowbrake_age++;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0 &&
          vru_candidate.pedestrian_rearcross_Candidate_.u8_lastselectID !=
          vru_candidate.pedestrian_rearcross_Candidate_.u8_Candi_ID){
    FusionVRURearFlag_.lowbrake_flag      = kAEBAlertActive;
    FusionVRURearFlag_.unconfirmed_flag   = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag       = kAEBAlertActive;
    FusionVRURearFlag_.lowbrake_age       = 1;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill > 0 &&
          FusionVRURearFlag_.highbrake_flag == kAEBAlertNoActive &&
          FusionVRURearFlag_.lowbrake_flag  == kAEBAlertNoActive){
    FusionVRURearFlag_.prefill_flag       = kAEBAlertActive;
    FusionVRURearFlag_.Warning_flag       = kAEBAlertActive;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  else if(vru_candidate.pedestrian_rearcross_Candidate_.u8_warning > 0){
    FusionVRURearFlag_.Warning_flag       = kAEBAlertActive;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  else{
    FusionVRURearFlag_.lowbrake_age       = 0;
    FusionVRURearFlag_.highbrake_hold_age = 0;
  }
  if (FusionVRURearFlag_.lowbrake_flag == kAEBAlertActive || FusionVRURearFlag_.highbrake_flag == kAEBAlertActive) {
    AEBDumpSuppress = 25;
  }
  }
  else{
    ClearVruRearFlag();
    ClearVruRearAge();
    //AEBDumpSuppress = 0;
  }
}

void AEBInHouse::ClearVruFlag() {
  FusionVRUFlag_.highbrake_flag         = kAEBAlertNoActive;
  FusionVRUFlag_.lowbrake_flag          = kAEBAlertNoActive;
  FusionVRUFlag_.prefill_flag           = kAEBAlertNoActive;
  FusionVRUFlag_.Warning_flag           = kAEBAlertNoActive;
  FusionVRUFlag_.unconfirmed_flag       = kAEBAlertNoActive;
  FusionVRUFlag_.hold_flag              = kAEBAlertNoActive;
}

void AEBInHouse::ClearVruAge(){
  FusionVRUFlag_.lowbrake_age           = 0;
  FusionVRUFlag_.highbrake_hold_age     = 0;
}

void AEBInHouse::ClearVruRearFlag(){
  FusionVRURearFlag_.highbrake_flag     = kAEBAlertNoActive;
  FusionVRURearFlag_.lowbrake_flag      = kAEBAlertNoActive;
  FusionVRURearFlag_.prefill_flag       = kAEBAlertNoActive;
  FusionVRURearFlag_.Warning_flag       = kAEBAlertNoActive;
  FusionVRURearFlag_.unconfirmed_flag   = kAEBAlertNoActive;
  FusionVRURearFlag_.hold_flag          = kAEBAlertNoActive;
}

void AEBInHouse::ClearVruRearAge(){
  FusionVRURearFlag_.lowbrake_age       = 0;
  FusionVRURearFlag_.highbrake_hold_age = 0;
}

void AEBInHouse::ClearCCRFlag() {
  FusionCCRFlag_.highbrake_flag = kAEBAlertNoActive;
  FusionCCRFlag_.lowbrake_flag = kAEBAlertNoActive;
  FusionCCRFlag_.prefill_flag = kAEBAlertNoActive;
  FusionCCRFlag_.Warning_flag = kAEBAlertNoActive;
  FusionCCRFlag_.unconfirmed_flag = kAEBAlertNoActive;
  FusionCCRFlag_.warnbrake_flag = kAEBAlertNoActive;
  FusionCCRFlag_.hold_flag = kAEBAlertNoActive;
  FusionCCRFlag_.readyforIBA = 0;
}

void AEBInHouse::ClearCCRAge(){
  FusionCCRFlag_.lowbrake_age           = 0;
  FusionCCRFlag_.highbrake_hold_age     = 0;
}

void AEBInHouse::UpdateCalibration() {

}

}  // namespace ad
}  // namespace nio
