#include "aeb_main.h"
#include "aeb_condition_proc.h"
#include "aeb_in_house.h"
#include "aeb_output_publisher.h"
#include "aeb_state.h"
#include "aeb_type.h"
#include "fcts_in_proc.h"
#include "fcts_input_adapter.h"
#include "fcw_condition_proc.h"
#include "fcw_state.h"
#include "fcw_type.h"
#include "niodds/application/application.h"
#include "veh_in_type.h"
//#include "aespnc_main.h"
#include "path_verification.h"
#include "update_force_cal.h"

namespace nio {
namespace ad {

extern nio::ad::AEBInHouse aeb_;
extern nio::ad::ARBSIN*    arb_sin;
extern path_verification   path_verify_;
VehicleProjectType         vehicle_type_last = nio::ad::VehicleProjectType_Invalid;

void aeb_main(void) {
  // std::cout << "aeb_main start"<<std::endl;
  // auto ts = Time::Now();
  if (vehicle_type_last != arb_sin->vehicle_type) {
    INFO_LOG << "vehicle_type transform : " << static_cast<uint32_t>(vehicle_type_last) << " ->  "
             << static_cast<uint32_t>(arb_sin->vehicle_type);
    if (arb_sin->vehicle_type == nio::ad::VehicleProjectType_Force) {
      update_force_calibration();
      INFO_LOG << "update_force_calibration ";
    }
    vehicle_type_last = arb_sin->vehicle_type;
  }
  aeb_.MainFunction();
  update_aeb_ctrlparam(arb_sin);
  update_aebrear_flag(AEBFlg);
  update_aeb_flag(AEBFlg);
  udpate_aeb_target_flag(AEBFlg, AEBActuFlg);

  // fcw
  RearSm* rearsm = &fcwrearsm;
  rearsm->Main();

  update_fcw_conditions();
  FCWSm.update_FCW_State();

  bool drvovrd    = false;
  bool holdovrd   = false;
  bool brkpressed = false;

  brkpressed = (arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts == static_cast<BrkPdlSts_e>(1)) ? 1 : 0;

  drvovrd = fcw_driver_override(FCWReq, VehPt.AccrPedal.ActPosn, VehPt.AccrPedal.ActPosnRate, StrSys.StrWhlAgSpd,
                                VehDyn.dYawRateDpss);
  update_fcw_req(FCWReq, FCWSm, AEBActuFlg);
  update_awb_req(FCWSm, FCWReq, VehDyn.VehSpd.VehSpdkph, AEBActuFlg.warnbrk);
  // aeb

  rearsm = &aebrearsm;
  rearsm->Main();

  update_aeb_conditions();

  AEBSm.update_AEB_State();

  // AesPNC_Main();

  // path_verify_.MainFunction();

  drvovrd  = false;
  drvovrd  = aeb_driver_override(AEBReq, VehPt.AccrPedal.ActPosn, VehPt.AccrPedal.ActPosnRate, StrSys.StrWhlAgSpd,
                                VehDyn.dYawRateDpss);
  holdovrd = hold_override(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn,
                           arb_sin->vehicleinfo_in.brakesys.BrkPdl.Trvl, brkpressed);

  update_aeb_deceleration_request(AEBSm, AEBReq, AEBActuFlg, drvovrd, holdovrd);

  /*update_eba_req(AEBReq,
              BrkSys.BrkPrs.BrkPrs,
              BrkSys.BrkPrs.BrkPrsGrad,
              VehPt.Gear.ActGear, AEBActuFlg
              );*/

  update_aba_req(AEBReq);

  AEBReq.set_aeb_txt_info(AEBSm.get_snsrblk_cdn(), AEBSm.get_tmpfail_cdn(), AEBSm.get_permfail_cdn());
  // auto dur = Time::Now() - ts;
  // std::cout << "aeb_main complete, cost time"<<dur<<"ms"<<std::endl;
}
}  // namespace ad
}  // namespace nio
