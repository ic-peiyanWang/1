#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aeb_extract_ccr.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {

    extract_ccr ccr_extraction_;

    void extract_ccr::MainFunction() {

        UpdateCalibration();

        ExtractCCR();

    }

    extract_ccr::extract_ccr() {}

    void extract_ccr::UpdateCalibration() {
        size_t funnelrange =
            sizeof(EAEB_dstFunnelRange_x) / sizeof(EAEB_dstFunnelRange_x[0]);
        threshold_CCR_stationary_inner_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstStatInFunnel_v, funnelrange);
        threshold_CCR_longitude_inner_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstMovInFunnel_v, funnelrange);
        threshold_CCR_longitude_outter_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstMovOutFunnel_v, funnelrange);

        threshold_CCR_LongPos_VFcheck_.init(
            EAEB_dstLongPosCheck_LongPos_x, EAEB_spdLongPosCheck_Rrate_y,
            EAEB_dstLongPosCheck_Poserror_v,
            sizeof(EAEB_dstLongPosCheck_LongPos_x) /
                sizeof(EAEB_dstLongPosCheck_LongPos_x[0]),
            sizeof(EAEB_spdLongPosCheck_Rrate_y) /
                sizeof(EAEB_spdLongPosCheck_Rrate_y[0]));

        size_t norm_egospd_cal =
            sizeof(EAEB_spdCCR_egospd_x) / sizeof(EAEB_spdCCR_egospd_x[0]);
        size_t norm_rangerate_cal =
            sizeof(EAEB_spdCCR_RRate_y) / sizeof(EAEB_spdCCR_RRate_y[0]);
        threshold_CCR_LowB_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCLowB_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_CCR_HighB_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                        EAEB_TTCHighB_norm_v, norm_egospd_cal,
                                        norm_rangerate_cal);
        threshold_CCR_Pref_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCPrefill_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_CCR_Warn_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCWarn_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_CCR_Warn_TTC_Addin_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y, EAEB_TTCWarn_addins_v, norm_egospd_cal, norm_rangerate_cal);
        threshold_CCR_takeover_steerangle_.init(EAEB_spdCCR_egospd_x, EAEB_overtake_steerangle_v, norm_egospd_cal);
        threshold_CCR_takeover_gasped_.init(EAEB_spdCCR_egospd_x, EAEB_overtake_gasped_v, norm_egospd_cal);

        threshold_ccr_ttb_longsafe_.init(EAEB_spdCCR_egospd_x, EAEB_dstccr_timetobrake_safezone_v, norm_egospd_cal);
        threshold_ccr_ttb_offset_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y, EAEB_TTB_offset_v, norm_egospd_cal, norm_rangerate_cal);

        size_t decel_range_cal =
            sizeof(EAEB_dstCCRdecl_Range_x) / sizeof(EAEB_dstCCRdecl_Range_x[0]);
        size_t targ_decel_cal = sizeof(EAEB_accCCRdecl_TargDecl_y) /
                                sizeof(EAEB_accCCRdecl_TargDecl_y[0]);
        threshold_CCR_LowB_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y, EAEB_TTCLowB_decel_v,
            decel_range_cal, targ_decel_cal);
        threshold_CCR_HighB_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y,
            EAEB_TTCHighB_decel_v, decel_range_cal, targ_decel_cal);
        threshold_CCR_Pref_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y,
            EAEB_TTCPrefill_decel_v, decel_range_cal, targ_decel_cal);
        threshold_CCR_Warn_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y, EAEB_TTCWarn_decel_v,
            decel_range_cal, targ_decel_cal);
        threshold_CCR_Warn_decel_TTC_Addin_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y, EAEB_TTCWarn_deceladdins_v,
            decel_range_cal, targ_decel_cal);

        size_t inpath_range_cal =
            sizeof(EAEB_dstInPath_Range_x) / sizeof(EAEB_dstInPath_Range_x[0]);
        threshold_CCR_HitDist_Before_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_HitDistBef_v, inpath_range_cal);
        threshold_CCR_HitDist_After_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_HitDistAft_v, inpath_range_cal);
        threshold_CCR_YawDist_Before_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_YawDistBef_v, inpath_range_cal);
        threshold_CCR_YawDist_After_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_YawDistAft_v, inpath_range_cal);
        threshold_CCR_XOLC_Before_.init(EAEB_dstInPath_Range_x,
                                        EAEB_dstInPath_XOLCBef_v, inpath_range_cal);
        threshold_CCR_XOLC_After_.init(EAEB_dstInPath_Range_x,
                                        EAEB_dstInPath_XOLCAft_v, inpath_range_cal);

        size_t ttc_XOLCPer_cal = sizeof(EAEB_perTTCcalc_XOLCperc_x) /
                                sizeof(EAEB_perTTCcalc_XOLCperc_x[0]);
        threshold_CCR_XOLCper_Warn_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perWarn_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Pref_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perPref_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Low_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perLowB_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_High_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perHighB_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Warn_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perWarnMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Pref_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perPrefMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Low_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perLowBMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_High_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perHighBMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_movingout_deltayaw_.init(EAEB_perTTCcalc_XOLCperc_x,
                                            EAEB_perdeltayawrate_v, ttc_XOLCPer_cal);
        threshold_ccr_ttt_latsafe_.init(EAEB_perTTCcalc_XOLCperc_x, EAEB_dstccr_timetoturn_safelat_v, ttc_XOLCPer_cal);
        threshold_ccr_ttt_offset_.init(EAEB_perTTCcalc_XOLCperc_x, EAEB_spdCCR_egospd_x, EAEB_TTT_offset_v, ttc_XOLCPer_cal, norm_egospd_cal);

        size_t conf_cal =
        sizeof(EAEB_agecheck_AEBconf_x) / sizeof(EAEB_agecheck_AEBconf_x[0]);

        threshold_CCR_InPathAge_.init(EAEB_agecheck_AEBconf_x,
                                        EAEB_ageCCR_inpathage_v, conf_cal);
        threshold_Undef_InPathAge_.init(EAEB_agecheck_AEBconf_x,
                                        EAEB_ageUndef_inpathage_v, conf_cal);

    }

void extract_ccr::ExtractCCR() {
    //std::cout << "extractccr start"<<std::endl;
    //auto ts = Time::Now();
    ccr_candidate.CCRS_Candi_LF_ = ccr_candidate.CCRS_Candi_;
    ccr_candidate.CCRS_Candi_LF_2_ = ccr_candidate.CCRS_Candi_2_;
    ccr_candidate.CCRM_Candi_LF_ = ccr_candidate.CCRM_Candi_;
    ccr_candidate.CCRM_Candi_LF_2_ = ccr_candidate.CCRM_Candi_2_;
    clearCCRCandidate();
    //std::cout << "Fusion obj size in AEB is "<< (int)fused_obj_filtered.size() <<std::endl;
    for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
      if(fused_obj_filtered.at(i).gofcheck.check_valid == true){
        // std::cout<<"in AEBinhouse target information ========================================================================================================================"<<std::endl;

        // std::cout<<"fusion object size is"<<(int)fused_obj_filtered.size()<<std::endl;
        // std::cout << "extractccr start1 and int is "<< i<<std::endl;
        if ((fused_obj_filtered.at(i).raw_data.classification.IsVehicle() ||
            (fused_obj_filtered.at(i).raw_data.classification.IsMotorbike() && k_add_motor_inccr) ||
            (fused_obj_filtered.at(i).raw_data.classification.IsUndefined() &&
            fused_obj_filtered.at(i).raw_data.motion_status.IsMoved() && k_add_undef_inccr)) &&
            fused_obj_filtered.at(i).raw_data.IsValid() && fused_obj_filtered.at(i).raw_data.valid_status() == 2 &&
            fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x > 0) {

        // std::cout<<"CCR condition is"<<"is vehicle:"<<(int)fused_obj_filtered.at(i).raw_data.classification.IsVehicle()<<",is motor:"<<(int)fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()<<",is undef:"<<(int)fused_obj_filtered.at(i).raw_data.classification.IsUndefined()<<",is moved:"<<(int)fused_obj_filtered.at(i).raw_data.motion_status.IsMoved()<<",is valid:"<<(int)fused_obj_filtered.at(i).raw_data.IsValid()<<",target range is:"<<(int) fused_obj_filtered.at(i).raw_data.valid_status()<<fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x<<std::endl;
        // std::cout << "extractccr start1.5"<<std::endl;
        AEBObjectCCR tmp_objCCR;
        //std::cout << "extractccr start1.51"<<std::endl;
        tmp_objCCR.obj = fused_obj_filtered.at(i).raw_data;
        tmp_objCCR.ref_pos = fused_obj_filtered.at(i).ref_pos;
        tmp_objCCR.u8_ID = fused_obj_filtered.at(i).raw_data.GetID();
        tmp_objCCR.u8_IDX = i;
        //std::cout << "extractccr start1.52"<<std::endl;
        uint32_t vision_ID = MaxVisionIndex;
        vision_ID = VisMatchID_[i].vis_id;
        tmp_objCCR.u8_VID = vision_ID;
        //std::cout << "extractccr start1.53"<<std::endl;
        //std::cout << "visionid is "<<(int)vision_ID<<std::endl;
        if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID &&
            vision_ID != MaxVisionIndex) {
                //std::cout << "extractccr start1.534"<<std::endl;
                //std::cout << "visionid is "<<(int)vision_ID<<std::endl;
                //std::cout << " vis_obj_->size() is "<< (int) vis_obj_->size()<<std::endl;
                //std::cout << "vis_obj_->at(vision_ID).motion.GetX() is "<< vis_obj_->at(vision_ID).motion.GetX()<<std::endl;
            tmp_objCCR.f4_vissup_dx = vis_obj_->at(vision_ID).motion.GetX();
            //std::cout << "extractccr start1.535"<<std::endl;
        }
        //std::cout << "extractccr start1.54"<<std::endl;
        tmp_objCCR.objectvalid = fused_obj_filtered.at(i).raw_data.IsValid();
        //std::cout << "extractccr start1.6"<<std::endl;
        tmp_objCCR.f4_range = sqrtf(
            powf((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle), 2) +
            powf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y, 2));
        tmp_objCCR.f4_rangerate =
            fused_obj_filtered.at(i).raw_data.motion.GetVx() - ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

        if (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps < 2 && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps >= 0 && fused_obj_filtered.at(i).raw_data.motion.GetVx() <= 0 && fused_obj_filtered.at(i).raw_data.motion.GetVx() >= -1.2) {
          tmp_objCCR.f4_rangerate = -ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        }
        float ego_ROC;
        ego_ROC = ROC(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                        ego_state_aeb.yawrate);
        tmp_objCCR.f4_XOLC = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y -
                            deltay(ego_ROC, tmp_objCCR.f4_range,
                                    ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);
        //std::cout << "extractccr start2"<<std::endl;
        if (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps < 2.2 && ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2 > 0) {
          tmp_objCCR.f4_relatAcc = -fused_obj_filtered.at(i).raw_data.motion.GetAx();
        }
        else {
          tmp_objCCR.f4_relatAcc = ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2 - fused_obj_filtered.at(i).raw_data.motion.GetAx();
        }
        
        tmp_objCCR.f4_TTC = CalCCRTTC(
            tmp_objCCR.f4_rangerate, tmp_objCCR.f4_relatAcc, tmp_objCCR.f4_range);
        tmp_objCCR.f4_TTC_new = CalCCRTTC_1(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, tmp_objCCR.obj.motion.GetVx(), ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81, tmp_objCCR.obj.motion.GetAx(), tmp_objCCR.f4_range, tmp_objCCR.obj.motion_status.IsOncoming());
        
        tmp_objCCR.f4_TTCbased =
            CalCCRTTCBased(tmp_objCCR.f4_rangerate, tmp_objCCR.f4_range);

        if (lfbrake_active == 1 || ego_->vehicleinfo_in.vehicledynamic.LgtAg > 0.15) {
            tmp_objCCR.f4_TTC = tmp_objCCR.f4_TTCbased;
        }

        //tmp_objCCR.f4_TTC = tmp_objCCR.f4_TTCbased;

        tmp_objCCR.f4_TrackHeadingEst = CalcHeadingEst(
            fused_obj_filtered.at(i).raw_data.motion.GetVx(), fused_obj_filtered.at(i).raw_data.motion.GetVy(),
            fused_obj_filtered.at(i).raw_data.motion.GetHead(),
            fused_obj_filtered.at(i).raw_data.motion.GetHeadRate(), tmp_objCCR.f4_TTC);


        CalCCRTTB(tmp_objCCR);
        CalCCRTTT(tmp_objCCR);
        if (tmp_objCCR.TTB.tt >= tmp_objCCR.TTT.tt) {
            tmp_objCCR.f4_TTEmax = tmp_objCCR.TTB.tt;
            tmp_objCCR.f4_TTEmin = tmp_objCCR.TTT.tt;
        } else {
            tmp_objCCR.f4_TTEmin = tmp_objCCR.TTB.tt;
            tmp_objCCR.f4_TTEmax = tmp_objCCR.TTT.tt;
        }
        tmp_objCCR.u8_AEBconf = DecideCCR_AEBConf(tmp_objCCR);
    #if defined(GENESIS_DEBUG)
        // this logic is for resim temporary.
        if (tmp_objCCR.obj.motion_status.IsMoved() == 0 &&
            tmp_objCCR.obj.IsVisionOnly() == 1 &&
            fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x <= 30.0f) {
            tmp_objCCR.u8_AEBconf = 2;
        }
        //=============================================================================
        #endif
        //std::cout << "extractccr start3"<<std::endl;
        if (tmp_objCCR.obj.IsRadarOnly() != 1 && tmp_objCCR.obj.IsVisionOnly() != 1) {
            tmp_objCCR.u1_vfplaucheck = CCR_VF_Longpos_check(
                fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x, tmp_objCCR.f4_vissup_dx,
                tmp_objCCR.f4_rangerate, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2));
        } else {
            tmp_objCCR.u1_vfplaucheck = 1;
        }

        //taowen 20210720: short termly by-pass the vision fusion check
        tmp_objCCR.u1_vfplaucheck = 1;

        if (tmp_objCCR.obj.motion.GetVx() < OncVxThres) {
            tmp_objCCR.u1_oncoming = 1;
        } else {
            tmp_objCCR.u1_oncoming = 0;
        }

        tmp_objCCR.u1_ageplaucheck = CCR_Age_check(
            tmp_objCCR.obj.IsAllFused(), tmp_objCCR.obj.IsRadarOnly(),
            tmp_objCCR.obj.IsVisionOnly(),
            sizeof(tmp_objCCR.obj.fusion_sup.radar_list),
            tmp_objCCR.obj.fusion_sup.age);

        if (tmp_objCCR.obj.motion_status.IsMoving() == 0 &&
            tmp_objCCR.obj.IsVisionOnly() == 1 &&
            fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x <= AgeCheckXThres &&
            tmp_objCCR.obj.fusion_sup.age >= AgeCheckFusAgeThres) {
            tmp_objCCR.u1_ageplaucheck = 1;
        }

        tmp_objCCR.u1_headplaucheck = 0;
        if ((tmp_objCCR.obj.motion.GetHead() >= -HeadCheckThresLow && tmp_objCCR.obj.motion.GetHead() <= HeadCheckThresLow) || 
            (tmp_objCCR.obj.motion.GetHead() >= -HeadCheckThresHigh && tmp_objCCR.obj.motion.GetHead() <= -HeadCheckThresMid) || 
            (tmp_objCCR.obj.motion.GetHead() >= HeadCheckThresMid && tmp_objCCR.obj.motion.GetHead() <= HeadCheckThresHigh)) {
          tmp_objCCR.u1_headplaucheck = 1;
        }
        else {
          tmp_objCCR.u1_headplaucheck = 0;
        }

        if(tmp_objCCR.obj.classification.IsTruck() == true){
          if((tmp_objCCR.obj.motion.GetHead() >= TruckHeadCheckLow && tmp_objCCR.obj.motion.GetHead() <= TruckHeadCheckHigh) ||
              (tmp_objCCR.obj.motion.GetHead() <= -TruckHeadCheckLow && tmp_objCCR.obj.motion.GetHead() >= -TruckHeadCheckHigh)){
                tmp_objCCR.u1_headplaucheck = 0;
          }
        }

        tmp_objCCR.u1_movingstate =
            DecideMoveState(tmp_objCCR.f4_XOLC, deltayawrate);

        tmp_objCCR.u1_ismovingout = 0;
        tmp_objCCR.u1_ismovingout =
            DecideMoveOut(tmp_objCCR.f4_XOLC, deltayawrate);

        tmp_objCCR.u1_TOI =
            DecideTOI(tmp_objCCR.f4_range, tmp_objCCR.f4_XOLC,
                        tmp_objCCR.obj.motion.GetVy(), tmp_objCCR.f4_rangerate,
                        tmp_objCCR.obj.motion_status.IsMovable(), ego_->vehicle_info.arb_vehicle.width, tmp_objCCR.ref_pos);

        tmp_objCCR.yawdist =
            CalcYawDist(deltayawrate, tmp_objCCR.f4_TTC, tmp_objCCR.f4_range,
                        tmp_objCCR.u1_movingstate, tmp_objCCR.f4_XOLC);

        tmp_objCCR.hitdist = CalcHitDist(
            tmp_objCCR.f4_XOLC, tmp_objCCR.obj.motion.GetVy(), tmp_objCCR.f4_TTC);
        //std::cout << "extractccr start4"<<std::endl;

        if ((tmp_objCCR.obj.classification.IsVehicle() == 1 ||
            tmp_objCCR.obj.classification.IsMotorbike() == 1) &&
            tmp_objCCR.obj.motion_status.IsMoved() == 0 &&
            tmp_objCCR.u1_oncoming == 0) {
            uint8_t isCCRSX = 0;
            if (tmp_objCCR.u8_AEBconf >= 2 && tmp_objCCR.u1_vfplaucheck == 1 &&
                ((tmp_objCCR.u1_ageplaucheck == 1) ||
                tmp_objCCR.u8_ID == ccr_candidate.CCRS_Candi_LF_.u8_ID ||
                tmp_objCCR.u8_ID == ccr_candidate.CCRS_Candi_LF_2_.u8_ID)) {
            isCCRSX = SelectCCRSCandi(tmp_objCCR.f4_range, tmp_objCCR.f4_XOLC,
                                        tmp_objCCR.f4_TTC, tmp_objCCR.f4_minTTC,
                                        tmp_objCCR.f4_minRange);
            if (isCCRSX == 1) {
                tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
                tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
                if (ccr_candidate.CCRS_Candi_.u8_ID > 0) {
                ccr_candidate.CCRS_Candi_2_ = ccr_candidate.CCRS_Candi_;
                }
                ccr_candidate.CCRS_Candi_ = tmp_objCCR;
            } else if (isCCRSX == 2) {
                tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
                tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
                ccr_candidate.CCRS_Candi_2_ = tmp_objCCR;
            }
          }
        } else if ((tmp_objCCR.obj.classification.IsVehicle() == 1 ||
                    tmp_objCCR.obj.classification.IsMotorbike() == 1 /*||
                    tmp_objCCR.obj.classification.IsUndefined() == 1*/) &&
                    tmp_objCCR.obj.motion_status.IsMoved() == 1 &&
                    tmp_objCCR.u1_oncoming == 0) {
            uint8_t isCCRMX = 0;
            if (tmp_objCCR.u8_AEBconf >= 2 && tmp_objCCR.u1_vfplaucheck == 1 &&
                (fabsf(tmp_objCCR.obj.motion.GetHead()) < CcrObjHeadThres ||
                tmp_objCCR.obj.motion.GetVx() < CcrObjVxThres) &&
                ((tmp_objCCR.u1_ageplaucheck == 1) ||
                tmp_objCCR.u8_ID == ccr_candidate.CCRM_Candi_LF_.u8_ID ||
                tmp_objCCR.u8_ID == ccr_candidate.CCRM_Candi_LF_2_.u8_ID)) {
            isCCRMX = SelectCCRMCandi(
                tmp_objCCR.f4_range, tmp_objCCR.f4_XOLC, tmp_objCCR.f4_TTC,
                tmp_objCCR.f4_minTTC, tmp_objCCR.f4_minRange, tmp_objCCR.u8_ID,
                ego_state_aeb.yawrate);
            if (isCCRMX == 1) {
                tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
                tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
                if (ccr_candidate.CCRM_Candi_.u8_ID > 0) {
                ccr_candidate.CCRM_Candi_2_ = ccr_candidate.CCRM_Candi_;
                }
                ccr_candidate.CCRM_Candi_ = tmp_objCCR;
            } else if (isCCRMX == 2) {
                tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
                tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
                ccr_candidate.CCRM_Candi_2_ = tmp_objCCR;
            }
          }
        }

        if (fabsf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y)<= CcrCloseObjYThres &&(tmp_objCCR.obj.IsVisionOnly() == 1 || tmp_objCCR.obj.IsAllFused() == 1)) {
            close_CCR = tmp_objCCR;
        }

        

        //std::cout << "extractccr start5"<<std::endl;
        #ifdef AEB_DEBUG
        // if (i <128) {
        //   std::cout<<"target id is "<<(int)tmp_objCCR.u8_ID<<"and associated vision id is "<<(int)tmp_objCCR.u8_VID<< std::endl;

        //   std::cout<<"target is valid? "<<(int)tmp_objCCR.objectvalid<<std::endl;

        //   std::cout<<"target range is "<<tmp_objCCR.f4_range<<std::endl;

        //   std::cout<<"target range rate is "<<tmp_objCCR.f4_rangerate<<std::endl;

        //   std::cout<<"target acc is "<<tmp_objCCR.f4_relatAcc<<std::endl;

        //   std::cout<<"target ttc is "<<tmp_objCCR.f4_TTC<<std::endl;

        //   std::cout<<"target ttcbased is "<<tmp_objCCR.f4_TTCbased<<std::endl;

        //   std::cout<<"target xolc is "<<tmp_objCCR.f4_XOLC<<std::endl;

        //   std::cout<<"target heading is "<<tmp_objCCR.f4_TrackHeadingEst<<std::endl;

        //   std::cout<<"target toi is "<<(int)tmp_objCCR.u1_TOI<<std::endl;

        //   std::cout<<"target vfcheck is "<<(int)tmp_objCCR.u1_vfplaucheck<<std::endl;

        //   std::cout<<"target agecheck is "<<(int)tmp_objCCR.u1_ageplaucheck<<std::endl;

        //   std::cout<<"target aebconf is "<<(int)tmp_objCCR.u8_AEBconf<<std::endl;

        //   std::cout<<"target movingout is "<<(int)tmp_objCCR.u1_ismovingout<<std::endl;

        //   std::cout<<"============================================================================================================================================="<<std::endl;
        // }
        #endif
      }
    }
    }
    //std::cout << "out of for"<<std::endl;

    DecideCCRInPath(ccr_candidate.CCRS_Candi_);

    DecideCCRInPath(ccr_candidate.CCRS_Candi_2_);

    DecideCCRInPath(ccr_candidate.CCRM_Candi_);

    DecideCCRInPath(ccr_candidate.CCRM_Candi_2_);

    CalcCCRInPathAge(ccr_candidate.CCRS_Candi_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_);

    CalcCCRInPathAge(ccr_candidate.CCRS_Candi_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_);

    CalcCCRInPathAge(ccr_candidate.CCRM_Candi_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_);

    CalcCCRInPathAge(ccr_candidate.CCRM_Candi_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_);
    //std::cout << "extractccr start6"<<std::endl;

    DecideOvertake(ccr_candidate.CCRS_Candi_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_);

    DecideOvertake(ccr_candidate.CCRS_Candi_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_);

    DecideOvertake(ccr_candidate.CCRM_Candi_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_);

    DecideOvertake(ccr_candidate.CCRM_Candi_2_, ccr_candidate.CCRM_Candi_LF_, ccr_candidate.CCRM_Candi_LF_2_, ccr_candidate.CCRS_Candi_LF_, ccr_candidate.CCRS_Candi_LF_2_);
    
    DecideCCRBrakeFlag(ccr_candidate.CCRS_Candi_,ccr_candidate.CCRS_Candi_LF_,ccr_candidate.CCRS_Candi_LF_2_,ccr_candidate.CCRM_Candi_LF_,ccr_candidate.CCRM_Candi_LF_2_);

    DecideCCRBrakeFlag(ccr_candidate.CCRS_Candi_2_,ccr_candidate.CCRS_Candi_LF_,ccr_candidate.CCRS_Candi_LF_2_,ccr_candidate.CCRM_Candi_LF_,ccr_candidate.CCRM_Candi_LF_2_);

    DecideCCRBrakeFlag(ccr_candidate.CCRM_Candi_,ccr_candidate.CCRS_Candi_LF_,ccr_candidate.CCRS_Candi_LF_2_,ccr_candidate.CCRM_Candi_LF_,ccr_candidate.CCRM_Candi_LF_2_);

    DecideCCRBrakeFlag(ccr_candidate.CCRM_Candi_2_,ccr_candidate.CCRS_Candi_LF_,ccr_candidate.CCRS_Candi_LF_2_,ccr_candidate.CCRM_Candi_LF_,ccr_candidate.CCRM_Candi_LF_2_);

    // clearCCRCandidate_LF();
    //auto dur = Time::Now() - ts;
    //std::cout << "extractccr complete,cost time"<<dur<<"ms"<<std::endl;

}

void extract_ccr::DecideOvertake(AEBObjectCCR &Candi, AEBObjectCCR &CS_lf1, AEBObjectCCR &CS_lf2, AEBObjectCCR &CM_lf1, AEBObjectCCR &CM_lf2) {
  Candi.driverovertake = 0;
  Candi.driverovertake_warn = 0;
  if (Candi.u8_ID == CS_lf1.u8_ID && Candi.u8_ID != 0) {
    CalculateMotion(Candi, CS_lf1);
  }
  else if (Candi.u8_ID == CM_lf1.u8_ID && Candi.u8_ID != 0) {
    CalculateMotion(Candi, CM_lf1);
  }
  else if (Candi.u8_ID == CS_lf2.u8_ID && Candi.u8_ID != 0) {
    CalculateMotion(Candi, CS_lf2);
  }
  else if (Candi.u8_ID == CM_lf2.u8_ID && Candi.u8_ID != 0) {
    CalculateMotion(Candi, CM_lf2);
  }
}

void extract_ccr::CalculateMotion(AEBObjectCCR &Candi, AEBObjectCCR &Candi_lf) {
  float delta_xolc = 0;
  bool movingout = 0;
  bool constmovingout = 0;
  float steerangle = ego_->vehicleinfo_in.steersys.StrWhlAg;
  float egospd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float gasped = ego_->vehicleinfo_in.vehiclept.AccrPedal.ActPosn;
  delta_xolc = Candi.f4_XOLC - Candi_lf.f4_XOLC; //negetive moving right
  if (delta_xolc < 0) {
    Candi.movingrightcount = Candi_lf.movingrightcount + 1;
    Candi.movingleftcount = 0;
    if (Candi.movingrightcount > 250){
      Candi.movingrightcount = 250;
    }
  }
  else if (delta_xolc > 0) {
    Candi.movingleftcount = Candi_lf.movingleftcount + 1;
    Candi.movingrightcount = 0;
    if (Candi.movingleftcount > 250){
      Candi.movingleftcount = 250;
    }
  }
  movingout = ((Candi.movingrightcount > 5 && steerangle >= 5) || (Candi.movingleftcount > 5 && steerangle <= -5)) ?1:0;

  constmovingout = ((Candi.movingrightcount > 30 && steerangle >= 5) || (Candi.movingleftcount > 30 && steerangle <= -5)) ?1:0;

  bool ttcinrange = 0;
  ttcinrange = (Candi.f4_TTC < 2.5)?1:0;

  bool xolcoutrange = 0;
  xolcoutrange = (fabsf(Candi.f4_XOLC) > 0.5)?1:0;

  bool hostout = 0;
  hostout = (Candi.f4_XOLC * steerangle < 0)?1:0;

  bool driversteer = 0;
  bool driveraccel = 0;
  float takover_steer_threshold = threshold_CCR_takeover_steerangle_.interpolate(egospd);
  float takover_gasped_threshold = threshold_CCR_takeover_gasped_.interpolate(egospd);
  driversteer = (fabsf(steerangle) >= takover_steer_threshold) ?1:0;
  driveraccel = (gasped >= takover_gasped_threshold) ?1:0;
  
  Candi.driverovertake = ttcinrange && xolcoutrange && hostout && ((movingout && driversteer && driveraccel) || (constmovingout && fabsf(steerangle) >= 10));
  Candi.driverovertake_warn = ttcinrange && xolcoutrange && hostout && ((movingout && driversteer) || (constmovingout && fabsf(steerangle) >= 10));
}

float extract_ccr::ROC(float vehspd, float yrate) {
  if (fabsf(vehspd) >= RocVehSpdThres) {
    if (vehspd / yrate >= MaxEgoRoc || yrate == 0.0f) {
      return MaxEgoRoc;
    } else if (vehspd / yrate <= -MaxEgoRoc) {
      return -MaxEgoRoc;
    } else {
      return vehspd / yrate;
    }
  }
  else {
    return MaxEgoRoc;
  }
}

float extract_ccr::deltay(float ROC, float Distance, float egospd) {
  /*float predict_c2;
  if (fabsf(egospd) <= 1.0f) {
    predict_c2 = 0;
  } else {
    predict_c2 = c2;
  }

  return powf(Distance, 2) * predict_c2;*/
  if (powf(Distance, 2) / (ROC * 2)>= DefaultDeltaAy || (ROC <= RocThres && ROC >= 0.0F)) {
    return DefaultDeltaAy;
  } else if (powf(Distance, 2) / (ROC * 2) <= -DefaultDeltaAy ||
             (ROC >= -RocThres && ROC < 0.0F)) {
    return -DefaultDeltaAy;
  } else {
    return powf(Distance, 2) / (ROC * 2);
  }
}

float extract_ccr::CalCCRTTC(float rrate, float relatacc, float range) {
  float TTC_final;
  if (fabsf(relatacc) < 0.1f) {
    if (rrate >= 0.0f) {
      TTC_final = MaxTTC;
    } else {
      TTC_final = -(range / rrate);
    }
  } else {
    if (rrate * rrate + 2 * relatacc * range < 0.0f) {
      TTC_final = MaxTTC;
    } else {
      TTC_final =
          (rrate + sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;
    }
  }
  if (TTC_final < 0) {
    return MaxTTC;
  } else if (TTC_final >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_final;
  }
}

float extract_ccr::CalCCRTTC_1(float vego, float vtar,float aego, float atar, float range, bool isoncoming) {
  float TTC_raw = 25.0;
  float TTC_final = 25.0;
  float rrate = vtar - vego;
  float relatacc = aego - atar;
  bool ttc_solvable = true;
  if (fabsf(relatacc) < 0.1f) {
    if (rrate >= 0.0f) {
      TTC_raw = 25.0f;
      ttc_solvable = true;
    }
    else {
      TTC_raw = range / (vego - vtar);
      ttc_solvable = true;
    }
  }
  else {
    if (rrate * rrate + 2 * relatacc * range < 0.0f) {
      TTC_raw = 25.0f;
      ttc_solvable = false;
    }
    else if (rrate * rrate + 2 * relatacc * range == 0.0f) {
      TTC_raw = rrate / relatacc;
      ttc_solvable = true;
    }
    else {
      float tt1 = 25;
      //float tt2 = 25;
      
      tt1 = (rrate + sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;
      //tt2 = (rrate - sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;

      TTC_raw = tt1;
      ttc_solvable = true;
    }
  }

  if (TTC_raw < 0 || (((vtar + atar * TTC_raw) < -1.2) && isoncoming == 0) || (((vtar + atar * TTC_raw) > 1.2) && isoncoming == 1) || ttc_solvable == false) {
    if (isoncoming == 0) {
      if (fabsf(aego) <= 0.2) {
        TTC_final = (range + fabsf((vtar * vtar)/(2 * atar)))/vego;
      }
      else {
        if ((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar)))) == 0) {
          TTC_final = (vego/aego) * (-1);
        }
        else if ((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar)))) > 0) {
          float tt1 = 25;
          //float tt2 = 25;

          tt1 = (vego * (-1) + sqrtf((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar))))))/aego;
          //tt2 = (vego * (-1) - sqrtf((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar))))))/aego;

          TTC_final = tt1;
        }
        else {
          TTC_final = 25;
        }
      }
    }
    else {
      if (fabsf(aego) <= 0.2) {
        TTC_final = (range - fabsf((vtar * vtar)/(2 * atar)))/vego;
      }
      else {
        if ((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar)))) == 0) {
          TTC_final = (vego/aego) * (-1);
        }
        else if ((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar)))) > 0) {
          float tt1 = 25;
          //float tt2 = 25;
          
          tt1 = (vego * (-1) + sqrtf((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar))))))/aego;
          //tt2 = (vego * (-1) - sqrtf((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar))))))/aego;

          TTC_final = tt1;
        }
        else {
          TTC_final = 25;
        }
      }
    }
  }
  else {
    TTC_final = TTC_raw;
  }

  if (TTC_final < 0 || TTC_final >= 25) {
    return 25;
  }
  else {
    return TTC_final;
  }
}

void extract_ccr::CalCCRTTT (AEBObjectCCR &ccr_tar) {
  float XOLCPercent_;
  XOLCPercent_ = ((2 * fabsf(ccr_tar.f4_XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  float roc_ttt = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float vtar = ccr_tar.obj.motion.GetVx();
  float aego = ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81;
  float atar = ccr_tar.obj.motion.GetAx();
  float range = ccr_tar.f4_range;
  float latest_sign = 1;
  float delta_y = 0;
  float delta_x = 0;
  float delta_r = 0;
  float target_width = 2.4;
  float lateral_safe = threshold_ccr_ttt_latsafe_.interpolate(XOLCPercent_);
  ccr_tar.steer_direction = 0;

  roc_ttt = ((vego * vego)/4);

  if (ccr_tar.f4_latest >= 0) {
    latest_sign = 1;
    ccr_tar.steer_direction = -1; //turn left;
  }
  else {
    latest_sign = -1;
    ccr_tar.steer_direction = 1; //turn right;
  }

  if (ccr_tar.obj.width() < 1 || ccr_tar.obj.width() > 4) {
    target_width = 2.4;
  }
  else {
    target_width = ccr_tar.obj.width();
  }

  if (fabsf(ccr_tar.f4_latest) < (1.1 + (target_width/2))) {
    delta_y = (1.1 + (target_width/2) - fabsf(ccr_tar.f4_latest) + lateral_safe) * latest_sign * (-1);

    delta_x = sqrtf((roc_ttt * roc_ttt) - ((roc_ttt - fabsf(delta_y)) * (roc_ttt - fabsf(delta_y))));

    delta_r = acosf((roc_ttt- fabsf(delta_y))/roc_ttt) * roc_ttt;

    ccr_tar.TTT.tt = delta_r/(vego - vtar);

    ccr_tar.TTT.isvalid = true;

    ccr_tar.position_esti.latpos = delta_y;

    ccr_tar.position_esti.longpos = (range * vego)/(vego -vtar);
  }
  else {
    ccr_tar.TTT.tt = 0;
    ccr_tar.TTT.isvalid = false;
    ccr_tar.position_esti.latpos = 0;
    ccr_tar.position_esti.longpos = 0;
  }

  if (ccr_tar.TTT.isvalid == true) {
    if (ccr_tar.TTT.tt < 0) {
      ccr_tar.TTT.tt = 0;
    }
    else if (ccr_tar.TTT.tt > 30){
      ccr_tar.TTT.tt = 30;
    }
  }  
}

void extract_ccr::CalCCRTTB (AEBObjectCCR &ccr_tar) {
  calc_tt ttb_bef;
  float ttb_saferange = 0;
  float ttb_a = 0;
  float ttb_b = 0;
  float ttb_c = 0;
  float ttb_c_new = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

  ttb_saferange = threshold_ccr_ttb_longsafe_.interpolate (vego);

  float vtar = ccr_tar.obj.motion.GetVx();
  float aego = ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81;
  float atar = ccr_tar.obj.motion.GetAx();
  float range = 0;
  if (ccr_tar.f4_range >= ttb_saferange) {
    range = ccr_tar.f4_range - ttb_saferange;
  }
  else {
    range = ccr_tar.f4_range;
  }

  if (fabsf(aego) <= 0.1 && fabsf(atar) <= 0.1) {
    ccr_tar.TTB.tt = (vego - vtar)/8;
    ccr_tar.TTB.isvalid = true;
  }
  else if (ccr_tar.obj.motion_status.IsOncoming() == false){
    if((vtar + atar * ccr_tar.f4_TTC) > -1.2) {
      ttb_a = (aego * 0.5) + (aego *(aego - atar)/(8 + atar)) - ((4 * (aego - atar) * (aego - atar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (aego + 8) * (aego + 8)) / ((8 + atar) * (8 + atar)));

      ttb_b = (((vego - vtar) * (aego + 8))/(8 + atar)) + ((aego * (vego -vtar))/(8 + atar)) - ((4 * (aego - atar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (aego + 8) * (vego - vtar))/((8 + atar) * (8 + atar)));

      ttb_c = (((vego - vtar) * (vego - vtar))/(8 + atar)) - ((4 * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - range;

      ttb_c_new = (((vego - vtar) * (vego - vtar))/(8 + atar)) - ((4 * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = (((aego - atar)/(8 + atar)) * ttb_bef.tt) + ((vego - vtar)/(8 + atar));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
    else {
      ttb_a = (aego/2 + (aego*aego)/16);

      ttb_b = (vego + ((3 * vego * aego)/16));

      ttb_c = (((vego * vego)/16) - fabsf((vtar * vtar)/(2 * atar)) - range);

      ttb_c_new = (((vego * vego)/16) - fabsf((vtar * vtar)/(2 * atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    } 
  }
  else {
    if ((vtar + atar * ccr_tar.f4_TTC) < 1.2) {
      ttb_a = ((aego/2) + ((aego * aego)/16) - ((((8 + aego) * (8 + aego)) * atar)/128));

      ttb_b = (vego + ((3 * vego * aego)/16) - vtar - ((vtar * aego)/8) - ((atar * vego * (8 + aego))/128));

      ttb_c = (((vego * vego)/16) - ((vego *vtar)/8) - ((atar * vego * vego)/128) - range);

      ttb_c_new = (((vego * vego)/16) - ((vego *vtar)/8) - ((atar * vego * vego)/128));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
    else {
      ttb_a = ((aego/2) + ((aego * aego)/16));

      ttb_b = (vego + ((3 * vego * aego)/16));

      ttb_c = (((vego * vego)/16) + fabsf((vtar * vtar)/(2 * atar)) - range);

      ttb_c_new = (((vego * vego)/16) + fabsf((vtar * vtar)/(2 * atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
  }

  //ccr_tar.TTB_bf = ttb_bef;

  // if (ccr_tar.TTB.isvalid == true) {
  //   if (ccr_tar.TTB.tt < 0) {
  //     ccr_tar.TTB.tt = 0;
  //   }
  //   else if (ccr_tar.TTB.tt > 30){
  //     ccr_tar.TTB.tt = 30;
  //   }
  // }
}

float extract_ccr::CalCCRTTCBased(float rrate, float range) {
  float TTC_based = MaxTTC;
  if (rrate >= 0.0f) {
    TTC_based = MaxTTC;
  } else {
    TTC_based = -(range / rrate);
  }

  if (TTC_based < 0) {
    return MaxTTC;
  } else if (TTC_based >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_based;
  }
}

float extract_ccr::CalcHeadingEst(float Longvel, float Latvel,
                                    float heading, float headingrate,
                                    float TTC) {
  float TrackHeading;
  float TrackHeadEst;
  if (fabsf(Longvel) <= CandiMinSpd && fabsf(Latvel) <= CandiMinSpd) {
    TrackHeading = heading;
  } else {
    if (fabsf(Longvel) == 0.0f && Latvel < 0) {
      TrackHeading = -Pi/2;
    } else if (fabsf(Longvel) == 0.0f && Latvel > 0) {
      TrackHeading = Pi/2;
    } else {
      TrackHeading = atanf(Latvel / Longvel);
    }
  }
  TrackHeadEst = TrackHeading + headingrate * TTC;
  return TrackHeadEst;
}

// float extract_ccr::CalCCRTTT(float vehWidth, float XOLC,
//                             float LataccMax, float ego_spd,
//                             float extendbuffer) {
//   float overlap;
//   float ROCmin;
//   overlap = (0.5 * vehWidth) + extendbuffer - fabsf(XOLC);
//   ROCmin = (ego_spd * ego_spd) / LataccMax;
//   if (fabsf(ego_spd) < 0.1f ||
//       ((0.5 * vehWidth) + extendbuffer - fabsf(XOLC)) < 0) {
//     return 25.0f;
//   } else {
//     return (sqrtf(2 * overlap * ROCmin + overlap * overlap)) / ego_spd;
//   }
// }

// float extract_ccr::CalCCRTTB(float RangeRate, float targetAcc) {
//   float TTBprim;
//   if (fabsf(targetAcc + 7.84f) < 0.01f) {
//     TTBprim = 25.0f;
//   } else {
//     TTBprim = (RangeRate / (targetAcc + 7.84f)) * (-1.0f);
//   }

//   if (TTBprim >= 25.0f || TTBprim < 0) {
//     return 25.0f;
//   } else {
//     return TTBprim;
//   }
// }

uint8_t extract_ccr::DecideCCR_AEBConf(AEBObjectCCR &tmpobj) {
  if ((tmpobj.obj.IsAllFused() == 1 && tmpobj.obj.fusion_sup.confidence >= MatchConfThres)) {
    if (tmpobj.obj.HasLidarFused() == 1) {
      if (tmpobj.obj.HasVisionFused() == 1) {
        return 3;
      }
      else {
        return 1;
      }
    } 
    else {
      return 3;
    }
  } else if ((tmpobj.obj.IsVisionOnly() == 1 && tmpobj.obj.IsAllFusedHis() == 1) && tmpobj.obj.fusion_sup.confidence >= MatchConfThres) {
    return 2;
  } else if ((tmpobj.obj.IsVisionOnly() == 1 || tmpobj.obj.IsRadarOnly() == 1) && tmpobj.obj.IsAllFusedHis() == 0) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccr::CCR_Age_check(bool isfusion, bool isradar, bool isvision,
                               size_t tracklet_count, uint8_t age) {
  //vis age turn into 20 for tempo test;
  if ((isfusion == 1 && age >= MinFusionObjAge) ||
      (isradar == 1 && tracklet_count >= 2 && age >= MinRadarObjAge) ||
      (isradar == 1 && tracklet_count == 1 && age >= MinRadarObjAge) ||
      (isvision == 1 && age >= MinVisionObjAge)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccr::CCR_VF_Longpos_check(float fusionLongPos,
                                      float visionLongPos,
                                      float Rangerate, float egoacc) {
  float LongPosError;
  LongPosError =
      threshold_CCR_LongPos_VFcheck_.interpolate(fusionLongPos, Rangerate);
  if (fabsf(egoacc) >= MaxCcrVfCheckEgoAcc) {
    return 1;
  } else {
    if (fabsf(fusionLongPos - visionLongPos - (ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - ego_->vehicle_info.arb_vehicle.epm_pos_to_front_bumper)) <= LongPosError) {
      return 1;
    } else {
      return 0;
    }
  }
}

MoveState  extract_ccr::DecideMoveState(float XOLC, float deltayawrate) {
  if ((fabsf(deltayawrate) <= DeltaYawrateThres) || XOLC == 0) {
    return nio::ad::MoveState::kNueutral ;
  } else if ((XOLC > 0) == (deltayawrate > 0)) {
    return nio::ad::MoveState::kMoving_in;
  } else if ((XOLC > 0 && deltayawrate < 0) || (XOLC < 0 && deltayawrate > 0)) {
    return nio::ad::MoveState::kMoving_out;
  }
  return nio::ad::MoveState::kNueutral;
}

bool extract_ccr::DecideMoveOut(float XOLC, float deltayawrate) {
  float XOLCPercent_;
  XOLCPercent_ = ((2 * fabsf(XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  float deltayaw_threshold = 0.0f;
  deltayaw_threshold = threshold_movingout_deltayaw_.interpolate(XOLCPercent_);

  if (((fabsf(deltayawrate)/0.02) <= deltayaw_threshold) || XOLC == 0) {
    return 0;
  } else if ((XOLC > 0) == (deltayawrate > 0)) {
    return 0;
  } else if ((XOLC > 0.3 && deltayawrate < 0) || (XOLC < -0.3 && deltayawrate > 0)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccr::DecideTOI(float Range, float XOLC, float latvel,
                           float rangerate, bool ismovable,
                           float vehicle_width, targetpos position) {
  bool rangecheck = 0;
  bool rangeratecheck = 0;
  bool movemotioncheck = 0;
  bool positioncheck = 0;
  if (((ismovable == 1 && Range <= CcrToiRangeMaxMove) ||
       (ismovable == 0 && Range <= CcrToiRangeMax)) &&
      position.referencepoint.pos_x >= 3.6) {
    rangecheck = 1;
  } else {
    rangecheck = 0;
  }
  if ((ismovable == 1 &&
       ((XOLC < ((-0.5) * vehicle_width - VehicleWidthBuffer) && latvel < -ToiLatVelThres) ||
        ((XOLC >= 0.5 * vehicle_width + VehicleWidthBuffer) && latvel > ToiLatVelThres))) ||
      (ismovable == 0 && fabsf(XOLC) > (0.5 * vehicle_width + VehicleWidthBuffer))) {
    movemotioncheck = 0;
  } else {
    movemotioncheck = 1;
  }
  if (rangerate > CandiMinSpd) {
    rangeratecheck = 0;
  } else {
    rangeratecheck = 1;
  }
  if ((position.referencepoint.pos_x > 0 && position.centerpoint.pos_x < 0) || (position.referencepoint.pos_x < 0 && position.centerpoint.pos_x > 0)) {
    positioncheck = 0;
  }
  else {
    positioncheck = 1;
  }
  if (rangecheck == 1 && movemotioncheck == 1 && positioncheck == 1/*&& rangeratecheck == 1*/) {
    return 1;
  } else {
    return 0;
  }
}

float extract_ccr::CalcYawDist(float EgoYawrate, float TTC,
                                 float Range, float targetmotion,
                                 float XOLC) {
  float yawdist_1 = 0;
  float yawdist_2 = 0;
  float TTC_saturate = 0;

  if (TTC >= YawDistTTCThrs) {
    TTC_saturate = YawDistTTCThrs;
  } else {
    TTC_saturate = TTC;
  }

  if (Range * sinf(EgoYawrate * TTC_saturate) >= CCRYawDistLimit) {
    yawdist_1 = CCRYawDistLimit;
  } else if (Range * sinf(EgoYawrate * TTC_saturate) <= -CCRYawDistLimit) {
    yawdist_1 = -CCRYawDistLimit;
  } else {
    yawdist_1 = Range * sinf(EgoYawrate * TTC_saturate);
  }

  if (targetmotion == nio::ad::MoveState::kNueutral) {
    yawdist_2 = fabsf(XOLC);
  } else if (targetmotion == nio::ad::MoveState::kMoving_in) {
    yawdist_2 = fabsf(fabsf(XOLC) - fabsf(yawdist_1));
  } else if (targetmotion == nio::ad::MoveState::kMoving_out) {
    yawdist_2 = fabsf(fabsf(XOLC) + fabsf(yawdist_1));
  }

  if (fabsf(EgoYawrate) * TTC_saturate >= (Pi/3)) {
    return CCRYawDistLimit;
  } else {
    return yawdist_2;
  }
}

float extract_ccr::CalcHitDist(float XOLC, float latvel, float TTC) {
  if (TTC > HitDistTTCThrs) {
    return 0.0f;
  } else {
    return fabsf(XOLC + (latvel * TTC));
  }
}

uint8_t extract_ccr::SelectCCRSCandi(float Range, float XOLC, float TTC,
                                    float minTTC, float minRange) {
  float funnel_threshold_;
  funnel_threshold_ =
      threshold_CCR_stationary_inner_funnel_.interpolate(Range) * 0.5;
  if (fabsf(XOLC) <= funnel_threshold_) {
    if (TTC < ccr_candidate.CCRS_Candi_.f4_minTTC ||
        (TTC == ccr_candidate.CCRS_Candi_.f4_minTTC && Range < ccr_candidate.CCRS_Candi_.f4_minRange)) {
      return 1;
    } else if ((TTC > ccr_candidate.CCRS_Candi_.f4_minTTC ||
                (TTC == ccr_candidate.CCRS_Candi_.f4_minTTC &&
                 Range >= ccr_candidate.CCRS_Candi_.f4_minRange)) &&
               (TTC < ccr_candidate.CCRS_Candi_2_.f4_minTTC ||
                (TTC == ccr_candidate.CCRS_Candi_2_.f4_minTTC &&
                 Range < ccr_candidate.CCRS_Candi_2_.f4_minRange))) {
      return 2;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}

uint8_t extract_ccr::SelectCCRMCandi(float Range, float XOLC, float TTC,
                                    float minTTC, float minRange,
                                    uint8_t ID, float ego_yawrate) {
  float inner_funnel_threshold_;
  float outer_funnel_threshold_;
  inner_funnel_threshold_ =
      threshold_CCR_longitude_inner_funnel_.interpolate(Range) * 0.5;
  if (fabsf(ego_yawrate )<= CandiYawrateThres) {
    outer_funnel_threshold_ =
        threshold_CCR_longitude_outter_funnel_.interpolate(Range) * 0.5;
  } else {
    outer_funnel_threshold_ =
        threshold_CCR_longitude_outter_funnel_.interpolate(Range) * 0.5 + CandiFunnelBuffer;
  }
  if (fabsf(XOLC) <= inner_funnel_threshold_ ||
      (fabsf(XOLC) <= outer_funnel_threshold_ &&
       (ID == ccr_candidate.CCRM_Candi_LF_.u8_ID || ID == ccr_candidate.CCRM_Candi_LF_2_.u8_ID))) {
    if (TTC >= CandiTTCThres && ((ccr_candidate.CCRM_Candi_.f4_minTTC >= CandiTTCThres && ccr_candidate.CCRM_Candi_.u8_ID != 0) || ccr_candidate.CCRM_Candi_.u8_ID == 0)) {
      if (Range < ccr_candidate.CCRM_Candi_.f4_minRange ||
          (Range == ccr_candidate.CCRM_Candi_.f4_minRange && TTC < ccr_candidate.CCRM_Candi_.f4_minTTC)) {
        return 1;
      } else if ((Range > ccr_candidate.CCRM_Candi_.f4_minRange ||
                  (Range = ccr_candidate.CCRM_Candi_.f4_minRange &&
                           TTC >= ccr_candidate.CCRM_Candi_.f4_minTTC)) &&
                 (Range < ccr_candidate.CCRM_Candi_2_.f4_minRange ||
                  (Range = ccr_candidate.CCRM_Candi_2_.f4_minRange &&
                           TTC < ccr_candidate.CCRM_Candi_2_.f4_minTTC))) {
        return 2;
      } else {
        return 0;
      }
    } else {
      if (TTC < ccr_candidate.CCRM_Candi_.f4_minTTC ||
          (TTC == ccr_candidate.CCRM_Candi_.f4_minTTC && Range < ccr_candidate.CCRM_Candi_.f4_minRange)) {
        return 1;
      } else if ((TTC > ccr_candidate.CCRM_Candi_.f4_minTTC ||
                  (TTC == ccr_candidate.CCRM_Candi_.f4_minTTC &&
                   Range >= ccr_candidate.CCRM_Candi_.f4_minRange)) &&
                 (TTC < ccr_candidate.CCRM_Candi_2_.f4_minTTC ||
                  (TTC == ccr_candidate.CCRM_Candi_2_.f4_minTTC &&
                   Range < ccr_candidate.CCRM_Candi_2_.f4_minRange))) {
        return 2;
      } else {
        return 0;
      }
    }
  } else {
    return 0;
  }
}

void extract_ccr::DecideCCRInPath (AEBObjectCCR &ccr_candi) {
  float HitDist_Before_Threshold = 0;
  float HitDist_After_Threshold = 0;
  float YawDist_Before_Threshold = 0;
  float YawDist_After_Threshold = 0;
  float XOLC_Before_Threshold = 0;
  float XOLC_After_Threshold = 0;
  HitDist_Before_Threshold = threshold_CCR_HitDist_Before_.interpolate(ccr_candi.f4_range);
  YawDist_Before_Threshold = threshold_CCR_YawDist_Before_.interpolate(ccr_candi.f4_range);
  HitDist_After_Threshold = threshold_CCR_HitDist_After_.interpolate(ccr_candi.f4_range);
  YawDist_After_Threshold = threshold_CCR_YawDist_After_.interpolate(ccr_candi.f4_range);
  XOLC_Before_Threshold = threshold_CCR_XOLC_Before_.interpolate(ccr_candi.f4_range);
  XOLC_After_Threshold = threshold_CCR_XOLC_After_.interpolate(ccr_candi.f4_range);
  if (ccr_candi.highbrake_flag == 1 || ccr_candi.lowbrake_flag == 1) {
    if (fabsf(ccr_candi.f4_XOLC) <= XOLC_After_Threshold) {
      ccr_candi.u1_Inpath_Before = 1;
    } else {
      ccr_candi.u1_Inpath_Before = 0;
    }
    if (fabsf(ccr_candi.hitdist) <= HitDist_After_Threshold &&
        fabsf(ccr_candi.yawdist) <= YawDist_After_Threshold) {
      ccr_candi.u1_Inpath_After = 1;
    } else {
      ccr_candi.u1_Inpath_After = 0;
    }
  } else {
    if (fabsf(ccr_candi.f4_XOLC) <= XOLC_Before_Threshold) {
      ccr_candi.u1_Inpath_Before = 1;
    } else {
      ccr_candi.u1_Inpath_Before = 0;
    }
    if (fabsf(ccr_candi.hitdist) <= HitDist_Before_Threshold &&
        fabsf(ccr_candi.yawdist) <= YawDist_Before_Threshold) {
      ccr_candi.u1_Inpath_After = 1;
    } else {
      ccr_candi.u1_Inpath_After = 0;
    }
  }
  if (ccr_candi.u1_Inpath_After == 1 && ccr_candi.u1_Inpath_Before == 1) {
    ccr_candi.u1_Inpath = 1;
  } else {
    ccr_candi.u1_Inpath = 0;
  }
}

void extract_ccr::CalcCCRInPathAge(AEBObjectCCR &ccr_candi, AEBObjectCCR &ccr_candi_lf1, AEBObjectCCR &ccr_candi_lf2, AEBObjectCCR &ccr_candi_lf3, AEBObjectCCR &ccr_candi_lf4) {
  if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf1.u8_ID && ccr_candi.u8_ID != 0) {
    ccr_candi.u8_Inpathage = ccr_candi_lf1.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf2.u8_ID && ccr_candi.u8_ID != 0) {
    ccr_candi.u8_Inpathage = ccr_candi_lf2.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf3.u8_ID && ccr_candi.u8_ID != 0) {
    ccr_candi.u8_Inpathage = ccr_candi_lf3.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf4.u8_ID && ccr_candi.u8_ID != 0) {
    ccr_candi.u8_Inpathage = ccr_candi_lf4.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID != ccr_candi_lf1.u8_ID && ccr_candi.u8_ID != ccr_candi_lf2.u8_ID && ccr_candi.u8_ID != ccr_candi_lf3.u8_ID && ccr_candi.u8_ID != ccr_candi_lf4.u8_ID && ccr_candi.u8_ID != 0) {
    ccr_candi.u8_Inpathage = 1;
  } else {
    ccr_candi.u8_Inpathage = 0;
  }
  if (ccr_candi.u8_Inpathage >= MaxInpathAge) {
    ccr_candi.u8_Inpathage = MaxInpathAge;
  }

  uint8_t InPathAge_Threshold = MaxInpathAge;
  if (ccr_candi.obj.classification.IsVehicle() == 1 || ccr_candi.obj.classification.IsMotorbike() == 1) {
    InPathAge_Threshold = threshold_CCR_InPathAge_.interpolate(ccr_candi.u8_AEBconf);
  } else if (ccr_candi.obj.classification.IsUndefined() == 1) {
    InPathAge_Threshold = threshold_Undef_InPathAge_.interpolate(ccr_candi.u8_AEBconf);
  }

  if (ccr_candi.u8_Inpathage >= InPathAge_Threshold) {
    ccr_candi.u1_inpathagecheck = 1;
  } else {
    ccr_candi.u1_inpathagecheck = 0;
  }
}

void extract_ccr::DecideCCRBrakeFlag(
    AEBObjectCCR &Candi, AEBObjectCCR &CS_lf1, AEBObjectCCR &CS_lf2, AEBObjectCCR &CM_lf1, AEBObjectCCR &CM_lf2) {
  float prefillTTC_threshold_ = 0;
  float warnTTC_threshold_ = 0;
  float lowbrakeTTC_threshold_ = 0;
  float highbrakeTTC_threshold_ = 0;
  float XOLCPercent_ReduceWarn_ = 0;
  float XOLCPercent_ReducePref_ = 0;
  float XOLCPercent_ReduceLow_ = 0;
  float XOLCPercent_ReduceHigh_ = 0;
  float XOLCPercent_;
  float egospd;
  float rangerate;
  float range;
  float targetdecel;

  egospd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  rangerate = Candi.f4_rangerate;
  range = Candi.f4_range;
  targetdecel = Candi.obj.motion.GetAx();

  Candi.iba_flag = 0;

  XOLCPercent_ = ((2 * fabsf(Candi.f4_XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  if (Candi.u1_ismovingout == 1 || XOLCPercent_ >= 1.0f || Candi.driverovertake == 1) {
    XOLCPercent_ReduceWarn_ =
        threshold_CCR_XOLCper_Warn_Mout_.interpolate(XOLCPercent_);
    XOLCPercent_ReducePref_ =
        threshold_CCR_XOLCper_Pref_Mout_.interpolate(XOLCPercent_);
    XOLCPercent_ReduceLow_ =
        threshold_CCR_XOLCper_Low_Mout_.interpolate(XOLCPercent_);
    XOLCPercent_ReduceHigh_ =
        threshold_CCR_XOLCper_High_Mout_.interpolate(XOLCPercent_);
  } else {
    XOLCPercent_ReduceWarn_ =
        threshold_CCR_XOLCper_Warn_.interpolate(XOLCPercent_);
    XOLCPercent_ReducePref_ =
        threshold_CCR_XOLCper_Pref_.interpolate(XOLCPercent_);
    XOLCPercent_ReduceLow_ =
        threshold_CCR_XOLCper_Low_.interpolate(XOLCPercent_);
    XOLCPercent_ReduceHigh_ =
        threshold_CCR_XOLCper_High_.interpolate(XOLCPercent_);
  }

  if (Candi.u1_ismovingout == 1 || XOLCPercent_ >= 1.0f || Candi.driverovertake_warn == 1) {
    XOLCPercent_ReduceWarn_ =
        threshold_CCR_XOLCper_Warn_Mout_.interpolate(XOLCPercent_);
    XOLCPercent_ReducePref_ =
        threshold_CCR_XOLCper_Pref_Mout_.interpolate(XOLCPercent_);
  } else {
    XOLCPercent_ReduceWarn_ =
        threshold_CCR_XOLCper_Warn_.interpolate(XOLCPercent_);
    XOLCPercent_ReducePref_ =
        threshold_CCR_XOLCper_Pref_.interpolate(XOLCPercent_);
  }

  warnTTC_threshold_ =
      (/*TTEmax + */ threshold_CCR_Warn_TTC_.interpolate(egospd, rangerate) +
       threshold_CCR_Warn_decel_TTC_.interpolate(range, targetdecel)) +
      XOLCPercent_ReduceWarn_ + (threshold_CCR_Warn_TTC_Addin_.interpolate(egospd, rangerate) + threshold_CCR_Warn_decel_TTC_Addin_.interpolate(range, targetdecel)) * single_target_scene - k_drive_straight_decrease * ego_turning;

  prefillTTC_threshold_ =
      (/*TTEmax + */ threshold_CCR_Pref_TTC_.interpolate(egospd, rangerate) +
       threshold_CCR_Pref_decel_TTC_.interpolate(range, targetdecel)) +
      XOLCPercent_ReducePref_;

  lowbrakeTTC_threshold_ =
      (/*TTEmax + */ threshold_CCR_LowB_TTC_.interpolate(egospd, rangerate) +
       threshold_CCR_LowB_decel_TTC_.interpolate(range, targetdecel)) +
      XOLCPercent_ReduceLow_;

  highbrakeTTC_threshold_ =
      (/*TTEmin + */ threshold_CCR_HighB_TTC_.interpolate(egospd, rangerate) +
       threshold_CCR_HighB_decel_TTC_.interpolate(range, targetdecel)) +
      XOLCPercent_ReduceHigh_;

    //delay ttc according to driver focus state with damping factor
    warnTTC_threshold_      *= drimonitor.output_.dampfactor[1];
    prefillTTC_threshold_   *= drimonitor.output_.dampfactor[4];
    lowbrakeTTC_threshold_  *= drimonitor.output_.dampfactor[6]; 
    highbrakeTTC_threshold_ *= drimonitor.output_.dampfactor[6];

  if (fcw_sensitive == 0) {
    warnTTC_threshold_ = warnTTC_threshold_ + WarnTTCBuffer;
  }
  else if (fcw_sensitive == 2) {
    warnTTC_threshold_ = warnTTC_threshold_ - WarnTTCBuffer;
  }

  bool lastbrakeactive = 0;
  bool lastbrakeactive2 = 0;
  bool lastbrakeactive3 = 0;
  bool lastbrakeactive4 = 0;

  bool lastibaactive = 0;

  if (CS_lf1.iba_flag == 1 || CS_lf2.iba_flag == 1 || CM_lf1.iba_flag == 1 || CM_lf2.iba_flag == 1){
    lastibaactive = 1;
  }

  if (CS_lf1.highbrake_flag == 1 || CS_lf1.lowbrake_flag == 1 || CS_lf1.prefill_flag == 1) {
    lastbrakeactive = 1;
  } else {
    lastbrakeactive = 0;
  }

  if (CS_lf2.highbrake_flag == 1 || CS_lf2.lowbrake_flag == 1 || CS_lf2.prefill_flag == 1) {
    lastbrakeactive2 = 1;
  } else {
    lastbrakeactive2 = 0;
  }

  if (CM_lf1.highbrake_flag == 1 || CM_lf1.lowbrake_flag == 1 || CM_lf1.prefill_flag == 1) {
    lastbrakeactive3 = 1;
  } else {
    lastbrakeactive3 = 0;
  }

  if (CM_lf2.highbrake_flag == 1 || CM_lf2.lowbrake_flag == 1 || CM_lf2.prefill_flag == 1) {
    lastbrakeactive4 = 1;
  } else {
    lastbrakeactive4 = 0;
  }

  if ((Candi.u1_Inpath == 1 || fabsf(Candi.f4_XOLC) <= 1.3f) && rangerate <= CandiMinSpd) {
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_vfplaucheck == 1 && Candi.u1_TOI == 1 && egospd > EgoSpdThres && Candi.u1_headplaucheck == 1) ||
          (lastbrakeactive == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (lastbrakeactive2 == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (lastbrakeactive3 == 1 && Candi.u8_ID == CM_lf1.u8_ID) ||
          (lastbrakeactive4 == 1 && Candi.u8_ID == CM_lf2.u8_ID)) &&
       // ((Candi.f4_TTC <= highbrakeTTC_threshold_ && AEBSupressReason_SpeedLow == 0) ||
          ((Candi.f4_TTC <= highbrakeTTC_threshold_ && ((drimonitor.output_.suppressbit & 0x02000000) == 0x00000000) ) ||
          (CS_lf1.highbrake_flag == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (CS_lf2.highbrake_flag == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (CM_lf2.highbrake_flag == 1 && Candi.u8_ID == CM_lf2.u8_ID) ||
          (CM_lf1.highbrake_flag == 1 && Candi.u8_ID == CM_lf1.u8_ID))) &&
        //AEBSupressReason_AfterHighB == 0x0000) {
          (drimonitor.output_.abortbit & 0x02000000) == 0x00000000 ){
      Candi.highbrake_flag = 1;
    }
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_vfplaucheck == 1 && Candi.u1_TOI == 1 && egospd > EgoSpdThres && Candi.u1_headplaucheck == 1) ||
          (lastbrakeactive == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (lastbrakeactive2 == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (lastbrakeactive3 == 1 && Candi.u8_ID == CM_lf1.u8_ID) ||
          (lastbrakeactive4 == 1 && Candi.u8_ID == CM_lf2.u8_ID)) &&
        //((Candi.f4_TTC <= lowbrakeTTC_threshold_ && AEBSupressReason_SpeedLow == 0) ||
          ((Candi.f4_TTC <= lowbrakeTTC_threshold_ && ((drimonitor.output_.suppressbit & 0x02000000) == 0x00000000) ) ||
          (CS_lf1.lowbrake_flag == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (CS_lf2.lowbrake_flag == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (CM_lf2.lowbrake_flag == 1 && Candi.u8_ID == CM_lf2.u8_ID) ||
          (CM_lf1.lowbrake_flag == 1 && Candi.u8_ID == CM_lf1.u8_ID)) &&
         (Candi.highbrake_flag != 1)) &&
        //AEBSupressReason_AfterLowB == 0x0000) {
          (drimonitor.output_.abortbit & 0x02000000) == 0x00000000 ) {
      Candi.lowbrake_flag = 1;
    }
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_vfplaucheck == 1 && Candi.u1_TOI == 1 && egospd > EgoSpdThres && Candi.u1_headplaucheck == 1) ||
          (lastbrakeactive == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (lastbrakeactive2 == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (lastbrakeactive3 == 1 && Candi.u8_ID == CM_lf1.u8_ID) ||
          (lastbrakeactive4 == 1 && Candi.u8_ID == CM_lf2.u8_ID)) &&
          ((Candi.f4_TTC <= prefillTTC_threshold_ && ((drimonitor.output_.suppressbit & 0x08000000) == 0x00000000))) &&
         (Candi.highbrake_flag != 1) &&
         (Candi.lowbrake_flag != 1)) &&
        //AEBSupressReason_AfterPref == 0x0000) {
          (drimonitor.output_.abortbit & 0x08000000) == 0x00000000 ) {
      Candi.prefill_flag = 1;
    }
    if (((Candi.u1_inpathagecheck == 1 && Candi.u1_vfplaucheck == 1 && Candi.u1_TOI == 1 && Candi.u1_headplaucheck == 1) &&
         (Candi.f4_TTC <= warnTTC_threshold_ && ((drimonitor.output_.suppressbit & 0x40000000) == 0x00000000 ) ) &&
         (Candi.highbrake_flag != 1) &&
         (Candi.lowbrake_flag != 1) && (Candi.prefill_flag != 1)) &&
        //AEBSupressReason == 0x0000) {
         (drimonitor.output_.abortbit & 0x40000000) == 0x00000000 ) { 
      Candi.warnig_flag = 1;
    }
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_vfplaucheck == 1 && Candi.u1_TOI == 1 && egospd > EgoSpdThres && Candi.u1_headplaucheck == 1) ||
          (lastibaactive == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (lastibaactive == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (lastibaactive == 1 && Candi.u8_ID == CM_lf1.u8_ID) ||
          (lastibaactive == 1 && Candi.u8_ID == CM_lf2.u8_ID)) &&
        //((Candi.f4_TTC <= prefillTTC_threshold_ && AEBSupressReason_SpeedLow == 0) ||
          ((Candi.f4_TTC <= highbrakeTTC_threshold_ && ((drimonitor.output_.suppressbit & 0x00800000) == 0x00000000) ) ||
          (CS_lf1.iba_flag == 1 && Candi.u8_ID == CS_lf1.u8_ID) ||
          (CS_lf2.iba_flag == 1 && Candi.u8_ID == CS_lf2.u8_ID) ||
          (CM_lf2.iba_flag == 1 && Candi.u8_ID == CM_lf2.u8_ID) ||
          (CM_lf1.iba_flag == 1 && Candi.u8_ID == CM_lf1.u8_ID))) &&
       //AEBSupressReason_IBA == 0x0000) {
         (drimonitor.output_.abortbit & 0x00800000) == 0x00000000 ) {
      Candi.iba_flag = 1;
    }
  } else {
    Candi.highbrake_flag = 0;
    Candi.lowbrake_flag = 0;
    Candi.prefill_flag = 0;
    Candi.warnig_flag = 0;
    Candi.iba_flag = 0;
  }
}

void extract_ccr::ClearRefPos(targetpos &ref_pos) {
  ref_pos.ref_character = 0;
  ref_pos.centerpoint.pos_x = 0;
  ref_pos.centerpoint.pos_y = 0;
  ref_pos.centerpoint.range = 0;
  ref_pos.frontcenter.pos_x = 0;
  ref_pos.frontcenter.pos_y = 0;
  ref_pos.frontcenter.range = 0;
  ref_pos.rearcenter.pos_x = 0;
  ref_pos.rearcenter.pos_y = 0;
  ref_pos.rearcenter.range = 0;
  ref_pos.leftcenter.pos_x = 0;
  ref_pos.leftcenter.pos_y = 0;
  ref_pos.leftcenter.range = 0;
  ref_pos.rightcenter.pos_x = 0;
  ref_pos.rightcenter.pos_y = 0;
  ref_pos.rightcenter.range = 0;
  ref_pos.referencepoint.pos_x = 0;
  ref_pos.referencepoint.pos_y = 0;
  ref_pos.referencepoint.range = 0;
  ref_pos.heading = 0;
}

void extract_ccr::clearCCRCandidate() {
ccr_candidate.CCRS_Candi_.obj.clear();
ClearRefPos(ccr_candidate.CCRS_Candi_.ref_pos);
ccr_candidate.CCRS_Candi_.u8_ID = 0U;
ccr_candidate.CCRS_Candi_.u8_IDX = MaxVisionIndex;
ccr_candidate.CCRS_Candi_.u8_VID = 0u;
ccr_candidate.CCRS_Candi_.objectvalid = 0U;
ccr_candidate.CCRS_Candi_.f4_range = 0.0f;
ccr_candidate.CCRS_Candi_.f4_rangerate = 0.0f;
ccr_candidate.CCRS_Candi_.f4_relatAcc = 0.0f;
ccr_candidate.CCRS_Candi_.f4_TTC = DefaultTTC;
ccr_candidate.CCRS_Candi_.f4_XOLC = 0.0f;
ccr_candidate.CCRS_Candi_.f4_vissup_dx = 0.0f;
ccr_candidate.CCRS_Candi_.f4_TrackHeadingEst = 0.0f;
ccr_candidate.CCRS_Candi_.f4_TTEmax = 0.0f;
ccr_candidate.CCRS_Candi_.f4_TTEmin = 0.0f;
ccr_candidate.CCRS_Candi_.u8_Inpathage = 0U;
ccr_candidate.CCRS_Candi_.u1_Inpath_Before = 0U;
ccr_candidate.CCRS_Candi_.u1_Inpath_After = 0U;
ccr_candidate.CCRS_Candi_.u1_Inpath = 0U;
ccr_candidate.CCRS_Candi_.u1_TOI = 0U;
ccr_candidate.CCRS_Candi_.u1_vfplaucheck = 0U;
ccr_candidate.CCRS_Candi_.u1_ageplaucheck = 0U;
ccr_candidate.CCRS_Candi_.u1_inpathagecheck = 0U;
ccr_candidate.CCRS_Candi_.u1_oncoming = 0U;
ccr_candidate.CCRS_Candi_.u1_preceding = 0U;
ccr_candidate.CCRS_Candi_.u1_longmove = 0U;
ccr_candidate.CCRS_Candi_.u1_latmove = 0U;
ccr_candidate.CCRS_Candi_.u1_crossing = 0U;
ccr_candidate.CCRS_Candi_.u8_AEBconf = 0U;
ccr_candidate.CCRS_Candi_.u8_lostradarage = 0U;
ccr_candidate.CCRS_Candi_.f4_minTTC = DefaultTTC;
ccr_candidate.CCRS_Candi_.f4_minRange = 200.0f;
ccr_candidate.CCRS_Candi_.warnig_flag = 0u;
ccr_candidate.CCRS_Candi_.prefill_flag = 0u;
ccr_candidate.CCRS_Candi_.lowbrake_flag = 0u;
ccr_candidate.CCRS_Candi_.highbrake_flag = 0u;
ccr_candidate.CCRS_Candi_2_.obj.clear();
ClearRefPos(ccr_candidate.CCRS_Candi_2_.ref_pos);
ccr_candidate.CCRS_Candi_2_.u8_ID = 0U;
ccr_candidate.CCRS_Candi_2_.u8_IDX = MaxVisionIndex;
ccr_candidate.CCRS_Candi_2_.u8_VID = 0u;
ccr_candidate.CCRS_Candi_2_.objectvalid = 0U;
ccr_candidate.CCRS_Candi_2_.f4_range = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_rangerate = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_relatAcc = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_TTC = DefaultTTC;
ccr_candidate.CCRS_Candi_2_.f4_XOLC = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_vissup_dx = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_TrackHeadingEst = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_TTEmax = 0.0f;
ccr_candidate.CCRS_Candi_2_.f4_TTEmin = 0.0f;
ccr_candidate.CCRS_Candi_2_.u8_Inpathage = 0U;
ccr_candidate.CCRS_Candi_2_.u1_Inpath_Before = 0U;
ccr_candidate.CCRS_Candi_2_.u1_Inpath_After = 0U;
ccr_candidate.CCRS_Candi_2_.u1_Inpath = 0U;
ccr_candidate.CCRS_Candi_2_.u1_TOI = 0U;
ccr_candidate.CCRS_Candi_2_.u1_vfplaucheck = 0U;
ccr_candidate.CCRS_Candi_2_.u1_ageplaucheck = 0U;
ccr_candidate.CCRS_Candi_2_.u1_inpathagecheck = 0U;
ccr_candidate.CCRS_Candi_2_.u1_oncoming = 0U;
ccr_candidate.CCRS_Candi_2_.u1_preceding = 0U;
ccr_candidate.CCRS_Candi_2_.u1_longmove = 0U;
ccr_candidate.CCRS_Candi_2_.u1_latmove = 0U;
ccr_candidate.CCRS_Candi_2_.u1_crossing = 0U;
ccr_candidate.CCRS_Candi_2_.u8_AEBconf = 0U;
ccr_candidate.CCRS_Candi_2_.u8_lostradarage = 0U;
ccr_candidate.CCRS_Candi_2_.f4_minTTC = DefaultTTC;
ccr_candidate.CCRS_Candi_2_.f4_minRange = 200.0f;
ccr_candidate.CCRS_Candi_2_.warnig_flag = 0u;
ccr_candidate.CCRS_Candi_2_.prefill_flag = 0u;
ccr_candidate.CCRS_Candi_2_.lowbrake_flag = 0u;
ccr_candidate.CCRS_Candi_2_.highbrake_flag = 0u;
ccr_candidate.CCRM_Candi_.obj.clear();
ClearRefPos(ccr_candidate.CCRM_Candi_.ref_pos);
ccr_candidate.CCRM_Candi_.u8_ID = 0U;
ccr_candidate.CCRM_Candi_.u8_IDX = MaxVisionIndex;
ccr_candidate.CCRM_Candi_.u8_VID = 0u;
ccr_candidate.CCRM_Candi_.objectvalid = 0U;
ccr_candidate.CCRM_Candi_.f4_range = 0.0f;
ccr_candidate.CCRM_Candi_.f4_rangerate = 0.0f;
ccr_candidate.CCRM_Candi_.f4_relatAcc = 0.0f;
ccr_candidate.CCRM_Candi_.f4_TTC = DefaultTTC;
ccr_candidate.CCRM_Candi_.f4_XOLC = 0.0f;
ccr_candidate.CCRM_Candi_.f4_vissup_dx = 0.0f;
ccr_candidate.CCRM_Candi_.f4_TrackHeadingEst = 0.0f;
ccr_candidate.CCRM_Candi_.f4_TTEmax = 0.0f;
ccr_candidate.CCRM_Candi_.f4_TTEmin = 0.0f;
ccr_candidate.CCRM_Candi_.u8_Inpathage = 0U;
ccr_candidate.CCRM_Candi_.u1_Inpath_Before = 0U;
ccr_candidate.CCRM_Candi_.u1_Inpath_After = 0U;
ccr_candidate.CCRM_Candi_.u1_Inpath = 0U;
ccr_candidate.CCRM_Candi_.u1_TOI = 0U;
ccr_candidate.CCRM_Candi_.u1_vfplaucheck = 0U;
ccr_candidate.CCRM_Candi_.u1_ageplaucheck = 0U;
ccr_candidate.CCRM_Candi_.u1_inpathagecheck = 0U;
ccr_candidate.CCRM_Candi_.u1_oncoming = 0U;
ccr_candidate.CCRM_Candi_.u1_preceding = 0U;
ccr_candidate.CCRM_Candi_.u1_longmove = 0U;
ccr_candidate.CCRM_Candi_.u1_latmove = 0U;
ccr_candidate.CCRM_Candi_.u1_crossing = 0U;
ccr_candidate.CCRM_Candi_.u8_AEBconf = 0U;
ccr_candidate.CCRM_Candi_.u8_lostradarage = 0U;
ccr_candidate.CCRM_Candi_.f4_minTTC = DefaultTTC;
ccr_candidate.CCRM_Candi_.f4_minRange = 200.0f;
ccr_candidate.CCRM_Candi_.warnig_flag = 0u;
ccr_candidate.CCRM_Candi_.prefill_flag = 0u;
ccr_candidate.CCRM_Candi_.lowbrake_flag = 0u;
ccr_candidate.CCRM_Candi_.highbrake_flag = 0u;
ccr_candidate.CCRM_Candi_2_.obj.clear();
ClearRefPos(ccr_candidate.CCRM_Candi_2_.ref_pos);
ccr_candidate.CCRM_Candi_2_.u8_ID = 0U;
ccr_candidate.CCRM_Candi_2_.u8_IDX = MaxVisionIndex;
ccr_candidate.CCRM_Candi_2_.u8_VID = 0u;
ccr_candidate.CCRM_Candi_2_.objectvalid = 0U;
ccr_candidate.CCRM_Candi_2_.f4_range = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_rangerate = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_relatAcc = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_TTC = DefaultTTC;
ccr_candidate.CCRM_Candi_2_.f4_XOLC = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_vissup_dx = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_TrackHeadingEst = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_TTEmax = 0.0f;
ccr_candidate.CCRM_Candi_2_.f4_TTEmin = 0.0f;
ccr_candidate.CCRM_Candi_2_.u8_Inpathage = 0U;
ccr_candidate.CCRM_Candi_2_.u1_Inpath_Before = 0U;
ccr_candidate.CCRM_Candi_2_.u1_Inpath_After = 0U;
ccr_candidate.CCRM_Candi_2_.u1_Inpath = 0U;
ccr_candidate.CCRM_Candi_2_.u1_TOI = 0U;
ccr_candidate.CCRM_Candi_2_.u1_vfplaucheck = 0U;
ccr_candidate.CCRM_Candi_2_.u1_ageplaucheck = 0U;
ccr_candidate.CCRM_Candi_2_.u1_inpathagecheck = 0U;
ccr_candidate.CCRM_Candi_2_.u1_oncoming = 0U;
ccr_candidate.CCRM_Candi_2_.u1_preceding = 0U;
ccr_candidate.CCRM_Candi_2_.u1_longmove = 0U;
ccr_candidate.CCRM_Candi_2_.u1_latmove = 0U;
ccr_candidate.CCRM_Candi_2_.u1_crossing = 0U;
ccr_candidate.CCRM_Candi_2_.u8_AEBconf = 0U;
ccr_candidate.CCRM_Candi_2_.u8_lostradarage = 0U;
ccr_candidate.CCRM_Candi_2_.f4_minTTC = DefaultTTC;
ccr_candidate.CCRM_Candi_2_.f4_minRange = 200.0f;
ccr_candidate.CCRM_Candi_2_.warnig_flag = 0u;
ccr_candidate.CCRM_Candi_2_.prefill_flag = 0u;
ccr_candidate.CCRM_Candi_2_.lowbrake_flag = 0u;
ccr_candidate.CCRM_Candi_2_.highbrake_flag = 0u;
}


void extract_ccr::clearCCRCandidate_LF() {
    ccr_candidate.CCRS_Candi_LF_.obj.clear();
    ccr_candidate.CCRS_Candi_LF_.u8_ID = 0U;
    ccr_candidate.CCRS_Candi_LF_.u8_IDX = MaxVisionIndex;
    ccr_candidate.CCRS_Candi_LF_.u8_VID = 0u;
    ccr_candidate.CCRS_Candi_LF_.objectvalid = 0U;
    ccr_candidate.CCRS_Candi_LF_.f4_range = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_rangerate = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_relatAcc = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_TTC = DefaultTTC;
    ccr_candidate.CCRS_Candi_LF_.f4_XOLC = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_vissup_dx = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_TrackHeadingEst = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_TTEmax = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.f4_TTEmin = 0.0f;
    ccr_candidate.CCRS_Candi_LF_.u8_Inpathage = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_Inpath_Before = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_Inpath_After = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_Inpath = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_TOI = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_vfplaucheck = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_ageplaucheck = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_inpathagecheck = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_oncoming = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_preceding = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_longmove = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_latmove = 0U;
    ccr_candidate.CCRS_Candi_LF_.u1_crossing = 0U;
    ccr_candidate.CCRS_Candi_LF_.u8_AEBconf = 0U;
    ccr_candidate.CCRS_Candi_LF_.u8_lostradarage = 0U;
    ccr_candidate.CCRS_Candi_LF_.f4_minTTC = DefaultTTC;
    ccr_candidate.CCRS_Candi_LF_.f4_minRange = 200.0f;
    ccr_candidate.CCRS_Candi_LF_.warnig_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_.prefill_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_.lowbrake_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_.highbrake_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_2_.obj.clear();
    ccr_candidate.CCRS_Candi_LF_2_.u8_ID = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u8_IDX = MaxVisionIndex;
    ccr_candidate.CCRS_Candi_LF_2_.u8_VID = 0u;
    ccr_candidate.CCRS_Candi_LF_2_.objectvalid = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.f4_range = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_rangerate = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_relatAcc = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_TTC = DefaultTTC;
    ccr_candidate.CCRS_Candi_LF_2_.f4_XOLC = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_vissup_dx = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_TrackHeadingEst = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_TTEmax = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.f4_TTEmin = 0.0f;
    ccr_candidate.CCRS_Candi_LF_2_.u8_Inpathage = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_Inpath_Before = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_Inpath_After = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_Inpath = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_TOI = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_vfplaucheck = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_ageplaucheck = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_inpathagecheck = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_oncoming = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_preceding = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_longmove = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_latmove = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u1_crossing = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u8_AEBconf = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.u8_lostradarage = 0U;
    ccr_candidate.CCRS_Candi_LF_2_.f4_minTTC = DefaultTTC;
    ccr_candidate.CCRS_Candi_LF_2_.f4_minRange = 200.0f;
    ccr_candidate.CCRS_Candi_LF_2_.warnig_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_2_.prefill_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_2_.lowbrake_flag = 0u;
    ccr_candidate.CCRS_Candi_LF_2_.highbrake_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_.obj.clear();
    ccr_candidate.CCRM_Candi_LF_.u8_ID = 0U;
    ccr_candidate.CCRM_Candi_LF_.u8_IDX = MaxVisionIndex;
    ccr_candidate.CCRM_Candi_LF_.u8_VID = 0u;
    ccr_candidate.CCRM_Candi_LF_.objectvalid = 0U;
    ccr_candidate.CCRM_Candi_LF_.f4_range = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_rangerate = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_relatAcc = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_TTC = DefaultTTC;
    ccr_candidate.CCRM_Candi_LF_.f4_XOLC = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_vissup_dx = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_TrackHeadingEst = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_TTEmax = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.f4_TTEmin = 0.0f;
    ccr_candidate.CCRM_Candi_LF_.u8_Inpathage = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_Inpath_Before = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_Inpath_After = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_Inpath = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_TOI = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_vfplaucheck = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_ageplaucheck = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_inpathagecheck = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_oncoming = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_preceding = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_longmove = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_latmove = 0U;
    ccr_candidate.CCRM_Candi_LF_.u1_crossing = 0U;
    ccr_candidate.CCRM_Candi_LF_.u8_AEBconf = 0U;
    ccr_candidate.CCRM_Candi_LF_.u8_lostradarage = 0U;
    ccr_candidate.CCRM_Candi_LF_.f4_minTTC = DefaultTTC;
    ccr_candidate.CCRM_Candi_LF_.f4_minRange = 200.0f;
    ccr_candidate.CCRM_Candi_LF_.warnig_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_.prefill_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_.lowbrake_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_.highbrake_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_2_.obj.clear();
    ccr_candidate.CCRM_Candi_LF_2_.u8_ID = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u8_IDX = MaxVisionIndex;
    ccr_candidate.CCRM_Candi_LF_2_.u8_VID = 0u;
    ccr_candidate.CCRM_Candi_LF_2_.objectvalid = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.f4_range = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_rangerate = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_relatAcc = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_TTC = DefaultTTC;
    ccr_candidate.CCRM_Candi_LF_2_.f4_XOLC = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_vissup_dx = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_TrackHeadingEst = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_TTEmax = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.f4_TTEmin = 0.0f;
    ccr_candidate.CCRM_Candi_LF_2_.u8_Inpathage = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_Inpath_Before = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_Inpath_After = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_Inpath = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_TOI = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_vfplaucheck = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_ageplaucheck = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_oncoming = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_preceding = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_longmove = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_latmove = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u1_crossing = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u8_AEBconf = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.u8_lostradarage = 0U;
    ccr_candidate.CCRM_Candi_LF_2_.f4_minTTC = DefaultTTC;
    ccr_candidate.CCRM_Candi_LF_2_.f4_minRange = 200.0f;
    ccr_candidate.CCRM_Candi_LF_2_.warnig_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_2_.prefill_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_2_.lowbrake_flag = 0u;
    ccr_candidate.CCRM_Candi_LF_2_.highbrake_flag = 0u;
}


}
}