#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aeb_extract_ftap.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {

extract_ftap ftap_extraction_;

void extract_ftap::MainFunction() {

    UpdateCalibration();

    ExtractBrakePoint();

}

extract_ftap::extract_ftap() {}

void extract_ftap::UpdateCalibration() {
    threshold_CCR_LongPos_VFcheck_.init(
      EAEB_dstLongPosCheck_LongPos_x, EAEB_spdLongPosCheck_Rrate_y,
      EAEB_dstLongPosCheck_Poserror_v,
      sizeof(EAEB_dstLongPosCheck_LongPos_x) /
          sizeof(EAEB_dstLongPosCheck_LongPos_x[0]),
      sizeof(EAEB_spdLongPosCheck_Rrate_y) /
          sizeof(EAEB_spdLongPosCheck_Rrate_y[0]));

    size_t distance_targetrange =
            sizeof(EAEB_dstTarget_Range_x) / sizeof(EAEB_dstTarget_Range_x[0]);
    threshold_FTAP_OncomingSpd_.init(
            EAEB_dstTarget_Range_x, EAEB_spdOncom_targspd_v, distance_targetrange);

    size_t egospdFTAP_cal =
            sizeof(EAEB_spdFTAP_egospd_x) / sizeof(EAEB_spdFTAP_egospd_x[0]);
    size_t ColRange_cal = sizeof(EAEB_dstCollisionPoint_Range_y) /
                                sizeof(EAEB_dstCollisionPoint_Range_y[0]);
    threshold_FTAP_predict_.init(
            EAEB_spdFTAP_egospd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAP_predictpath_v, egospdFTAP_cal, ColRange_cal);
    threshold_FTAP_current_.init(
            EAEB_spdFTAP_egospd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAP_currentpath_v, egospdFTAP_cal, ColRange_cal);
    threshold_FTAP_predict_warn_.init(
            EAEB_spdFTAP_egospd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAPwarn_predictpath_v, egospdFTAP_cal, ColRange_cal);
    threshold_FTAP_current_warn_.init(
            EAEB_spdFTAP_egospd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAPwarn_currentpath_v, egospdFTAP_cal, ColRange_cal);

    size_t targspdFTAP_cal =
            sizeof(EAEB_spdFTAP_targspd_x) / sizeof(EAEB_spdFTAP_targspd_x[0]);
    threshold_FTAP_expend_predict_.init(
            EAEB_spdFTAP_targspd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAP_predictext_v, targspdFTAP_cal, ColRange_cal);
    threshold_FTAP_expend_current_.init(
            EAEB_spdFTAP_targspd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAP_currentext_v, targspdFTAP_cal, ColRange_cal);
    threshold_FTAP_expend_predict_warn_.init(
            EAEB_spdFTAP_targspd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAPwarn_predictext_v, targspdFTAP_cal, ColRange_cal);
    threshold_FTAP_expend_current_warn_.init(
            EAEB_spdFTAP_targspd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAPwarn_currentext_v, targspdFTAP_cal, ColRange_cal);
    threshold_FTAP_expend_predict_after_.init(
            EAEB_spdFTAP_targspd_x, EAEB_dstCollisionPoint_Range_y,
            EAEB_dstFTAP_predictext_after_v, targspdFTAP_cal, ColRange_cal);

    threshold_FTAP_range_.init(EAEB_spdFTAP_egospd_x, EAEB_dstFTAPTOI_Range_v,
                                    egospdFTAP_cal);

    size_t conf_cal =
            sizeof(EAEB_agecheck_AEBconf_x) / sizeof(EAEB_agecheck_AEBconf_x[0]);

    threshold_CCFTAP_InPathAge_.init(EAEB_agecheck_AEBconf_x,
                                        EAEB_ageFTAP_inpathage_v, conf_cal);
    threshold_CCFTAP_InPathAge_warn_.init(EAEB_agecheck_AEBconf_x,
                                                EAEB_ageFTAPwarn_inpathage_v, conf_cal);

    threshold_CCFTAP_WarningTTC_.init(EAEB_spdFTAP_egospd_x,
                                            EAEB_tiFTAPwarn_TTC_v, egospdFTAP_cal);
    threshold_CCFTAP_PrefillTTC_.init(EAEB_spdFTAP_egospd_x,
                                            EAEB_tiFTAPpref_TTC_v, egospdFTAP_cal);
    threshold_CCFTAP_LowBrakeTTC_.init(EAEB_spdFTAP_egospd_x,
                                            EAEB_tiFTAPlowB_TTC_v, egospdFTAP_cal);
    threshold_CCFTAP_HighBrakeTTC_.init(EAEB_spdFTAP_egospd_x,
                                            EAEB_tiFTAPhighB_TTC_v, egospdFTAP_cal);
}

void extract_ftap::ExtractBrakePoint() {
  //std::cout << "extractftap start"<<std::endl;
  //auto ts = Time::Now();
  ////std::cout << "fusionobf size is"<< fused_obj_filtered.size() <<std::endl;
  ftap_candidate.FTAP_Candi_LF_ = ftap_candidate.FTAP_Candi_;
  ftap_candidate.FTAP_Candi_LF_2_ = ftap_candidate.FTAP_Candi_2_;
  ClearFTAPCandi();

  for (size_t i = 0; i < fused_obj_->size(); i++) {
    if(fused_obj_filtered.at(i).gofcheck.check_valid == true){
    if ((fused_obj_filtered.at(i).raw_data.classification.IsVehicle() ||
         (fused_obj_filtered.at(i).raw_data.classification.IsMotorbike() && k_add_motor_inccr)) &&
        fused_obj_filtered.at(i).raw_data.motion_status.IsMoved() &&
        fused_obj_filtered.at(i).raw_data.IsValid() && fused_obj_filtered.at(i).raw_data.valid_status() == 2 &&
        fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x > 0) {
      AEBObjectFTAP tmp_objFTAP;
      tmp_objFTAP.obj = fused_obj_filtered.at(i).raw_data;
      UpdateRefPos(fused_obj_filtered.at(i).ref_pos);
      tmp_objFTAP.ref_pos = fused_obj_filtered.at(i).ref_pos;
      tmp_objFTAP.u8_ID = fused_obj_filtered.at(i).raw_data.GetID();
      tmp_objFTAP.u8_IDX = i;
      uint8_t vision_ID;
      vision_ID = VisMatchID_[i].vis_id;
      tmp_objFTAP.u8_VID = vision_ID;
      if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID &&
          vision_ID != MaxVisionIndex) {
        tmp_objFTAP.f4_vissup_dx = vis_obj_->at(vision_ID).motion.GetX();
        tmp_objFTAP.f4_vissup_dy = vis_obj_->at(vision_ID).motion.GetY();
        tmp_objFTAP.f4_vissup_vx = vis_obj_->at(vision_ID).motion.GetVx();
        tmp_objFTAP.f4_vissup_vy = vis_obj_->at(vision_ID).motion.GetVy();
      }
      tmp_objFTAP.objectvalid = fused_obj_filtered.at(i).raw_data.IsValid();
      tmp_objFTAP.f4_longpos = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x;
      tmp_objFTAP.f4_latpos = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y;
      tmp_objFTAP.f4_longvel = fused_obj_filtered.at(i).raw_data.motion.GetVx();
      tmp_objFTAP.f4_latvel = fused_obj_filtered.at(i).raw_data.motion.GetVy();

      tmp_objFTAP.f4_range = sqrtf(
          powf((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle), 2) +
          powf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y, 2));

      tmp_objFTAP.f4_rangerate =
          sqrtf(tmp_objFTAP.f4_longvel * tmp_objFTAP.f4_longvel +
                tmp_objFTAP.f4_latvel * tmp_objFTAP.f4_latvel) -
          ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

      float ego_ROC = MaxEgoRoc;
      if (ego_->vehicle_info.arb_vehicle.pp_c2 != 0.0f) {
        ego_ROC = 1 / (2 * ego_->vehicle_info.arb_vehicle.pp_c2);
      } else {
        ego_ROC = MaxFtapRoc;
      }
      float ROC_raw = MaxRocRaw;
      if (fabsf(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps) > 1) {
        if (ego_->vehicleinfo_in.vehicledynamic.YawRateRps != 0.0f) {
          ROC_raw = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps /
                    ego_->vehicleinfo_in.vehicledynamic.YawRateRps;
        } else {
          ROC_raw = MaxRocRaw;
        }
      }
      else {
        ROC_raw = MaxRocRaw;
      }
      
      ego_ROC = ROC_raw;

          if (fabsf(tmp_objFTAP.f4_latvel) <= MaxLatVelThres) {
        tmp_objFTAP.f4_Heading = MaxCandiHeading;
      } else {
        tmp_objFTAP.f4_Heading = tmp_objFTAP.f4_longvel / tmp_objFTAP.f4_latvel;
      }
      tmp_objFTAP.f4_Headangle = 0.0f;
      if (tmp_objFTAP.f4_Heading >= 0.0f) {
        tmp_objFTAP.f4_Headangle = atanf(tmp_objFTAP.f4_Heading);
      } else {
        tmp_objFTAP.f4_Headangle = atanf(tmp_objFTAP.f4_Heading) + Pi;
      }
      // Heading is not the same as target heading angle, here it shall be equal
      // to ctan(headingangle);
      float deltaR = MaxDeltaR;
      deltaR = tmp_objFTAP.f4_longpos -
               (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_latpos);
      float alfa_1 = 0.0;
      alfa_1 = (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1) * ego_ROC *
                   ego_ROC -
               (tmp_objFTAP.f4_Heading * ego_ROC + deltaR) *
                   (tmp_objFTAP.f4_Heading * ego_ROC + deltaR);

      if (fabsf(tmp_objFTAP.f4_latvel) <= MaxLatVelThres) {
        if ((tmp_objFTAP.f4_latpos <= 2 * ego_ROC &&
             tmp_objFTAP.f4_latpos >= 0) ||
            (tmp_objFTAP.f4_latpos >= 2 * ego_ROC &&
             tmp_objFTAP.f4_latpos <= 0)) {
          tmp_objFTAP.u8_col_pointN = 1;
          tmp_objFTAP.f4_collisiony_1 = tmp_objFTAP.f4_latpos;
          tmp_objFTAP.f4_collisionx_1 =
              sqrtf(2 * ego_ROC * tmp_objFTAP.f4_latpos -
                    tmp_objFTAP.f4_latpos * tmp_objFTAP.f4_latpos);
          tmp_objFTAP.f4_collisiony_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_1 =
              CalculateCirRange(tmp_objFTAP.f4_collisiony_1, ego_ROC);
          tmp_objFTAP.f4_collisionr_2 = DefaultCollPos;
        } else {
          tmp_objFTAP.u8_col_pointN = 0;
          tmp_objFTAP.f4_collisiony_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisiony_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_2 = DefaultCollPos;
        }
      } else {
        if (alfa_1 == 0) {
          tmp_objFTAP.u8_col_pointN = 1;
          tmp_objFTAP.f4_collisiony_1 =
              (ego_ROC - tmp_objFTAP.f4_Heading * deltaR) /
              (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);
          tmp_objFTAP.f4_collisionx_1 =
              CalculateCirX(tmp_objFTAP.f4_collisiony_1, tmp_objFTAP.f4_longpos,
                            tmp_objFTAP.f4_latpos, tmp_objFTAP.f4_Heading);
          tmp_objFTAP.f4_collisionr_1 =
              CalculateCirRange(tmp_objFTAP.f4_collisiony_1, ego_ROC);
          tmp_objFTAP.f4_collisiony_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_2 = DefaultCollPos;
        } else if (alfa_1 > 0) {
          float coly1 = DefaultCollPos;
          float coly2 = DefaultCollPos;
          float colx1 = DefaultCollPos;
          float colx2 = DefaultCollPos;
          float colr1 = DefaultCollPos;
          float colr2 = DefaultCollPos;

          coly1 =
              ((ego_ROC - tmp_objFTAP.f4_Heading * deltaR) + sqrtf(alfa_1)) /
              (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);

          coly2 =
              ((ego_ROC - tmp_objFTAP.f4_Heading * deltaR) - sqrtf(alfa_1)) /
              (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);

          colx1 = CalculateCirX(coly1, tmp_objFTAP.f4_longpos,
                                tmp_objFTAP.f4_latpos, tmp_objFTAP.f4_Heading);

          colx2 = CalculateCirX(coly2, tmp_objFTAP.f4_longpos,
                                tmp_objFTAP.f4_latpos, tmp_objFTAP.f4_Heading);

          colr1 = CalculateCirRange(coly1, ego_ROC);

          colr2 = CalculateCirRange(coly2, ego_ROC);

          if (colx1 >= 0 && colx2 >= 0) {
            tmp_objFTAP.u8_col_pointN = 2;
            if (fabsf(colr1) >= fabsf(colr2)) {
              tmp_objFTAP.f4_collisiony_1 = coly2;
              tmp_objFTAP.f4_collisiony_2 = coly1;
              tmp_objFTAP.f4_collisionx_1 = colx2;
              tmp_objFTAP.f4_collisionx_2 = colx1;
              tmp_objFTAP.f4_collisionr_1 = colr2;
              tmp_objFTAP.f4_collisionr_2 = colr1;
            } else {
              tmp_objFTAP.f4_collisiony_1 = coly1;
              tmp_objFTAP.f4_collisiony_2 = coly2;
              tmp_objFTAP.f4_collisionx_1 = colx1;
              tmp_objFTAP.f4_collisionx_2 = colx2;
              tmp_objFTAP.f4_collisionr_1 = colr1;
              tmp_objFTAP.f4_collisionr_2 = colr2;
            }
          } else if ((colx1 >= 0 && colx2 < 0)) {
            tmp_objFTAP.u8_col_pointN = 1;
            tmp_objFTAP.f4_collisiony_1 = coly1;
            tmp_objFTAP.f4_collisionx_1 = colx1;
            tmp_objFTAP.f4_collisionr_1 = colr1;
          } else if ((colx1 < 0 && colx2 >= 0)) {
            tmp_objFTAP.u8_col_pointN = 1;
            tmp_objFTAP.f4_collisiony_1 = coly2;
            tmp_objFTAP.f4_collisionx_1 = colx2;
            tmp_objFTAP.f4_collisionr_1 = colr2;
          } else {
            tmp_objFTAP.u8_col_pointN = 0;
            tmp_objFTAP.f4_collisiony_1 = DefaultCollPos;
            tmp_objFTAP.f4_collisiony_2 = DefaultCollPos;
            tmp_objFTAP.f4_collisionx_1 = DefaultCollPos;
            tmp_objFTAP.f4_collisionx_2 = DefaultCollPos;
            tmp_objFTAP.f4_collisionr_1 = DefaultCollPos;
            tmp_objFTAP.f4_collisionr_2 = DefaultCollPos;
          }
        } else {
          tmp_objFTAP.u8_col_pointN = 0;
          tmp_objFTAP.f4_collisiony_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_2 = DefaultCollPos;
          tmp_objFTAP.f4_collisiony_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionx_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_1 = DefaultCollPos;
          tmp_objFTAP.f4_collisionr_2 = DefaultCollPos;
        }
      }

      tmp_objFTAP.f4_cornerx = DefaultCorner;
      tmp_objFTAP.f4_cornery = DefaultCorner;
      tmp_objFTAP.f4_cornerr = DefaultCorner;

      int8_t ROC_sign = 0;
      if (ego_ROC >= 0) {
        ROC_sign = 1;
      } else {
        ROC_sign = -1;
      }

      float theta_1 = 0.0f;
      float beta_1 = -1.0f;
      theta_1 =
          (ROC_sign * ego_->vehicle_info.arb_vehicle.width / (cosf(tmp_objFTAP.f4_Headangle) * 2)) -
          tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_latpos +
          tmp_objFTAP.f4_longpos;

      beta_1 = powf(((theta_1 - 1) * tmp_objFTAP.f4_Heading), 2) -
               (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1) *
                   (theta_1 * theta_1 -
                    powf((ROC_sign * ego_ROC - ego_->vehicle_info.arb_vehicle.width / 2), 2));

      float cornerpointx_1 = DefaultCollPos;
      float cornerpointy_1 = DefaultCollPos;
      float cornerpointx_2 = DefaultCollPos;
      float cornerpointy_2 = DefaultCollPos;

      if (beta_1 < 0) {
        tmp_objFTAP.u8_cornerNum = 0;
        tmp_objFTAP.f4_cornerx = 0;
        tmp_objFTAP.f4_cornery = 0;
      } else if (beta_1 == 0) {
        cornerpointy_1 = tmp_objFTAP.f4_Heading * (1 - theta_1) /
                         (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);
        cornerpointx_1 = tmp_objFTAP.f4_Heading * cornerpointy_1 + theta_1;

        if (cornerpointx_1 <= 0 && fabsf(cornerpointy_1) >= fabsf(ego_ROC)) {
          tmp_objFTAP.u8_cornerNum = 0;
          tmp_objFTAP.f4_cornerx = 0;
          tmp_objFTAP.f4_cornery = 0;
        } else {
          tmp_objFTAP.u8_cornerNum = 1;
          tmp_objFTAP.f4_cornerx = cornerpointx_1;
          tmp_objFTAP.f4_cornery = cornerpointy_1;
        }
      } else {
        cornerpointy_1 =
            (tmp_objFTAP.f4_Heading * (1 - theta_1) + sqrtf(beta_1)) /
            (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);
        cornerpointy_2 =
            (tmp_objFTAP.f4_Heading * (1 - theta_1) - sqrtf(beta_1)) /
            (tmp_objFTAP.f4_Heading * tmp_objFTAP.f4_Heading + 1);
        cornerpointx_1 = tmp_objFTAP.f4_Heading * cornerpointy_1 + theta_1;
        cornerpointx_2 = tmp_objFTAP.f4_Heading * cornerpointy_2 + theta_1;

        if (cornerpointx_1 <= 0 && cornerpointx_2 <= 0) {
          tmp_objFTAP.u8_cornerNum = 0;
          tmp_objFTAP.f4_cornerx = 0;
          tmp_objFTAP.f4_cornery = 0;
        } else if (cornerpointx_1 > 0 && cornerpointx_2 <= 0) {
          if (fabsf(cornerpointy_1) >= fabsf(ego_ROC)) {
            tmp_objFTAP.u8_cornerNum = 0;
            tmp_objFTAP.f4_cornerx = 0;
            tmp_objFTAP.f4_cornery = 0;
          } else {
            tmp_objFTAP.u8_cornerNum = 1;
            tmp_objFTAP.f4_cornerx = cornerpointx_1;
            tmp_objFTAP.f4_cornery = cornerpointy_1;
          }
        } else if (cornerpointx_1 <= 0 && cornerpointx_2 > 0) {
          if (fabsf(cornerpointy_2) >= fabsf(ego_ROC)) {
            tmp_objFTAP.u8_cornerNum = 0;
            tmp_objFTAP.f4_cornerx = 0;
            tmp_objFTAP.f4_cornery = 0;
          } else {
            tmp_objFTAP.u8_cornerNum = 1;
            tmp_objFTAP.f4_cornerx = cornerpointx_2;
            tmp_objFTAP.f4_cornery = cornerpointy_2;
          }
        } else {
          if (fabsf(cornerpointy_1) <= fabsf(cornerpointy_2)) {
            if (fabsf(cornerpointy_1) >= fabsf(ego_ROC)) {
              tmp_objFTAP.u8_cornerNum = 0;
              tmp_objFTAP.f4_cornerx = 0;
              tmp_objFTAP.f4_cornery = 0;
            } else {
              tmp_objFTAP.u8_cornerNum = 1;
              tmp_objFTAP.f4_cornerx = cornerpointx_1;
              tmp_objFTAP.f4_cornery = cornerpointy_1;
            }
          } else {
            if (fabsf(cornerpointy_2) >= fabsf(ego_ROC)) {
              tmp_objFTAP.u8_cornerNum = 0;
              tmp_objFTAP.f4_cornerx = 0;
              tmp_objFTAP.f4_cornery = 0;
            } else {
              tmp_objFTAP.u8_cornerNum = 1;
              tmp_objFTAP.f4_cornerx = cornerpointx_2;
              tmp_objFTAP.f4_cornery = cornerpointy_2;
            }
          }
        }
      }
      if (tmp_objFTAP.u8_cornerNum > 0) {
        tmp_objFTAP.f4_cornerr =
            CalculateCornerRange(tmp_objFTAP.f4_cornery, ego_ROC);
      } else {
        tmp_objFTAP.f4_cornerr = DefaultCorner;
      }

      if (tmp_objFTAP.u8_col_pointN > 0 /*&& tmp_objFTAP.u8_cornerNum > 0*/) {
        tmp_objFTAP.u8_col_pointN = 1;
      } else {
        tmp_objFTAP.u8_col_pointN = 0;
      }

      tmp_objFTAP.f4_TTC = CalculateCirTTC(
          tmp_objFTAP.f4_collisionr_1, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
          tmp_objFTAP.u8_col_pointN, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2),
          lfbrake_active);

      tmp_objFTAP.f4_TTL = CalculateCirTTL(
          tmp_objFTAP.f4_collisionr_1, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
          tmp_objFTAP.u8_col_pointN, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2),
          lfbrake_active);

      tmp_objFTAP.f4_currentRange = CalculateCirCurRange(
          tmp_objFTAP.f4_longpos, tmp_objFTAP.f4_latpos,
          tmp_objFTAP.f4_collisionx_1, tmp_objFTAP.f4_collisiony_1,
          tmp_objFTAP.u8_col_pointN, tmp_objFTAP.f4_longvel);

      tmp_objFTAP.f4_rangeestimation = CalculateCirPreRange(
          tmp_objFTAP.f4_longpos, tmp_objFTAP.f4_latpos, tmp_objFTAP.f4_longvel,
          tmp_objFTAP.f4_latvel, tmp_objFTAP.f4_TTC,
          tmp_objFTAP.f4_collisionx_1, tmp_objFTAP.f4_collisiony_1,
          tmp_objFTAP.u8_col_pointN, tmp_objFTAP.obj.motion.GetAx(),
          tmp_objFTAP.obj.motion.GetAy());

      tmp_objFTAP.u1_movingstate = DecideMoveState(
          tmp_objFTAP.f4_longpos, tmp_objFTAP.f4_latpos, tmp_objFTAP.f4_longvel,
          tmp_objFTAP.f4_latvel, tmp_objFTAP.f4_TTC, ego_ROC);
      // 4 is moving cross

      tmp_objFTAP.u8_AEBconf = DecideCCR_AEBConf(tmp_objFTAP);

      if (tmp_objFTAP.obj.IsRadarOnly() != 1) {
        tmp_objFTAP.u1_vfplaucheck = CCR_VF_Longpos_check(
            fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x, tmp_objFTAP.f4_vissup_dx,
            tmp_objFTAP.f4_rangerate, ego_->vehicleinfo_in.vehicledynamic.LgtAg);
      } else {
        tmp_objFTAP.u1_vfplaucheck = 1;
      }

      if (tmp_objFTAP.obj.motion.GetVx() < OncVxThres) {
        tmp_objFTAP.u1_oncoming = 1;
      } else {
        tmp_objFTAP.u1_oncoming = 0;
      }

      tmp_objFTAP.u1_ageplaucheck = CCR_Age_check(
          tmp_objFTAP.obj.IsAllFused(), tmp_objFTAP.obj.IsRadarOnly(),
          tmp_objFTAP.obj.IsVisionOnly(),
          sizeof(tmp_objFTAP.obj.fusion_sup.radar_list),
          tmp_objFTAP.obj.fusion_sup.age);

      if (tmp_objFTAP.obj.motion_status.IsMoving() == 0 &&
          tmp_objFTAP.obj.IsVisionOnly() == 1 &&
          fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x <= AgeCheckXThres &&
          tmp_objFTAP.obj.fusion_sup.age >= AgeCheckFusAgeThres) {
        tmp_objFTAP.u1_ageplaucheck = 1;
      }

      tmp_objFTAP.u1_oncoming =
          DecideTargetOncoming(tmp_objFTAP.f4_longvel, tmp_objFTAP.f4_range);

      // 20210226: according to suggestion from Binbin, using coordinate vector
      // to calculate path as reference.=============

      feature::math::Vector2f CollisionP;
      CollisionP.x = tmp_objFTAP.f4_collisionx_1;
      CollisionP.y = tmp_objFTAP.f4_collisiony_1;

      float coordiangle = 0.0f;
      if (tmp_objFTAP.u8_col_pointN >= 1) {
        coordiangle = CalculateCirAngle(tmp_objFTAP.f4_collisiony_1, ego_ROC);
      }

      feature::math::Vector2f FutureP;
      FutureP.x =
          tmp_objFTAP.f4_longpos + tmp_objFTAP.f4_longvel * tmp_objFTAP.f4_TTC;
      FutureP.y =
          tmp_objFTAP.f4_latpos + tmp_objFTAP.f4_latvel * tmp_objFTAP.f4_TTC;

      feature::math::Matrix2f rotate_m = feature::math::from_angle(coordiangle * (-1));

      feature::math::Vector2f CurPCol;
      feature::math::Vector2f FutPCol;
      feature::math::Vector2f MidVect;

      MidVect.x = tmp_objFTAP.obj.motion.GetPos().x - CollisionP.x;
      MidVect.y = tmp_objFTAP.obj.motion.GetPos().y - CollisionP.y;

      // changed_vector = Matrix (-angle) * (changing_vector -
      // newcoordinate_center_vector)
      CurPCol = rotate_m * MidVect;
      FutPCol = rotate_m * (FutureP - CollisionP);

      bool ismovingcross = 0;
      bool notmovingout = 0;
      if (tmp_objFTAP.u8_col_pointN >= 1) {
        ismovingcross = ((CurPCol.y <= 0 && FutPCol.y >= 0) || (CurPCol.y >= 0 && FutPCol.y <= 0))? 1: 0;
        notmovingout = (ismovingcross || (((CurPCol.y >= 0 && FutPCol.y >= 0) || (CurPCol.y <= 0 && FutPCol.y <= 0)) && (fabsf(CurPCol.y) >= fabsf(FutPCol.y)))) ?1:0;
      }
      tmp_objFTAP.ismovingcross = ismovingcross;
      tmp_objFTAP.notmovingout = notmovingout;

      if (ismovingcross == 1) {
        tmp_objFTAP.u1_movingstate = MoveState::kMoving_through;
      } else {
        tmp_objFTAP.u1_movingstate = MoveState::kInit;
      }

      // end coordinate rotation===============================

      tmp_objFTAP.u1_TOI_Before = DecideFTAPTOI(
          tmp_objFTAP.f4_range, tmp_objFTAP.f4_longvel, tmp_objFTAP.f4_latvel,
          tmp_objFTAP.obj.motion.angle(), tmp_objFTAP.u1_oncoming,
          ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, tmp_objFTAP.notmovingout);

      tmp_objFTAP.u1_inpathpre = DecideInpathpre(
          tmp_objFTAP.f4_range, tmp_objFTAP.obj.length(),
          tmp_objFTAP.f4_Heading, tmp_objFTAP.u1_movingstate,
          tmp_objFTAP.f4_rangeestimation, tmp_objFTAP.f4_collisionr_1,
          (tmp_objFTAP.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

      tmp_objFTAP.u1_inpathpre_warn = DecideInpathpre_warn(
          tmp_objFTAP.f4_range, tmp_objFTAP.obj.length(),
          tmp_objFTAP.f4_Heading, tmp_objFTAP.u1_movingstate,
          tmp_objFTAP.f4_rangeestimation, tmp_objFTAP.f4_collisionr_1,
          (tmp_objFTAP.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

      tmp_objFTAP.u1_inpathcur = DecideInpathcur(
          tmp_objFTAP.f4_range, tmp_objFTAP.obj.length(),
          tmp_objFTAP.f4_Heading, tmp_objFTAP.f4_currentRange,
          tmp_objFTAP.f4_collisionr_1,
          (tmp_objFTAP.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

      tmp_objFTAP.u1_inpathcur_warn = DecideInpathcur(
          tmp_objFTAP.f4_range, tmp_objFTAP.obj.length(),
          tmp_objFTAP.f4_Heading, tmp_objFTAP.f4_currentRange,
          tmp_objFTAP.f4_collisionr_1,
          (tmp_objFTAP.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

      bool inpathpre_after = 0;
      inpathpre_after = DecideInpathpre_after(
          tmp_objFTAP.f4_range, tmp_objFTAP.obj.length(),
          tmp_objFTAP.f4_Heading, tmp_objFTAP.u1_movingstate,
          tmp_objFTAP.f4_rangeestimation, tmp_objFTAP.f4_collisionr_1,
          (tmp_objFTAP.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

      tmp_objFTAP.u1_TOI_After =
          (inpathpre_after > 0 && tmp_objFTAP.u1_inpathcur > 0) ? 1 : 0;

      tmp_objFTAP.u1_Inpath =
          ((tmp_objFTAP.u1_inpathcur == 1) && (tmp_objFTAP.u1_inpathpre == 1))
              ? 1
              : 0;

      tmp_objFTAP.u1_Inpath_warn = ((tmp_objFTAP.u1_inpathcur_warn == 1) &&
                                    (tmp_objFTAP.u1_inpathpre_warn == 1))
                                       ? 1
                                       : 0;
      
      tmp_objFTAP.u1_headplaucheck = 0;
      if ((tmp_objFTAP.obj.motion.GetHead() >= -HeadCheckThresLow && tmp_objFTAP.obj.motion.GetHead() <= HeadCheckThresLow) || 
            (tmp_objFTAP.obj.motion.GetHead() >= -HeadCheckThresHigh && tmp_objFTAP.obj.motion.GetHead() <= -HeadCheckThresMid) || 
            (tmp_objFTAP.obj.motion.GetHead() >= HeadCheckThresMid && tmp_objFTAP.obj.motion.GetHead() <= HeadCheckThresHigh)) {
          tmp_objFTAP.u1_headplaucheck = 1;
        }
        else {
          tmp_objFTAP.u1_headplaucheck = 0;
        }

      bool iscandi_1 = 0;
      bool iscandi_2 = 0;

      if (tmp_objFTAP.objectvalid == 1 && tmp_objFTAP.u1_TOI_Before == 1 &&
          tmp_objFTAP.u8_AEBconf >= 2 &&
          ((tmp_objFTAP.u8_col_pointN >= 1 &&
            tmp_objFTAP.u1_ageplaucheck == 1 && tmp_objFTAP.u1_headplaucheck == 1 && (tmp_objFTAP.u1_Inpath_warn == 1 || tmp_objFTAP.u1_Inpath == 1)) ||
           (ftap_candidate.FTAP_Candi_LF_.highbrake_flag == tmp_objFTAP.u8_ID ||
            ftap_candidate.FTAP_Candi_LF_.lowbrake_flag == tmp_objFTAP.u8_ID ||
            ftap_candidate.FTAP_Candi_LF_2_.highbrake_flag == tmp_objFTAP.u8_ID ||
            ftap_candidate.FTAP_Candi_LF_2_.lowbrake_flag == tmp_objFTAP.u8_ID))) {
        if ((tmp_objFTAP.f4_TTC < ftap_candidate.FTAP_Candi_.f4_minTTC) ||
            (tmp_objFTAP.f4_TTC == ftap_candidate.FTAP_Candi_.f4_minTTC &&
             tmp_objFTAP.f4_collisionr_1 < ftap_candidate.FTAP_Candi_.f4_minRange)) {
          iscandi_1 = 1;
        } else if ((tmp_objFTAP.f4_TTC < ftap_candidate.FTAP_Candi_2_.f4_minTTC) ||
                   (tmp_objFTAP.f4_TTC == ftap_candidate.FTAP_Candi_2_.f4_minTTC &&
                    tmp_objFTAP.f4_collisionr_1 < ftap_candidate.FTAP_Candi_2_.f4_minRange)) {
          iscandi_2 = 1;
        } else {
          iscandi_1 = 0;
          iscandi_2 = 0;
        }
      }

      if (iscandi_1 == 1) {
        ftap_candidate.FTAP_Candi_2_ = ftap_candidate.FTAP_Candi_;
        ftap_candidate.FTAP_Candi_ = tmp_objFTAP;
        ftap_candidate.FTAP_Candi_.f4_minTTC = tmp_objFTAP.f4_TTC;
        ftap_candidate.FTAP_Candi_.f4_minRange = tmp_objFTAP.f4_collisionr_1;
      }

      if (iscandi_2 == 1) {
        ftap_candidate.FTAP_Candi_2_ = tmp_objFTAP;
        ftap_candidate.FTAP_Candi_2_.f4_minTTC = tmp_objFTAP.f4_TTC;
        ftap_candidate.FTAP_Candi_2_.f4_minRange = tmp_objFTAP.f4_collisionr_1;
      }
    }
  }
  }
  ftap_candidate.FTAP_Candi_.u8_Inpathage =
      CalculateInPathAge(ftap_candidate.FTAP_Candi_.u1_Inpath, ftap_candidate.FTAP_Candi_LF_.u8_Inpathage,
                         ftap_candidate.FTAP_Candi_LF_2_.u8_Inpathage, ftap_candidate.FTAP_Candi_.u8_ID,
                         ftap_candidate.FTAP_Candi_LF_.u8_ID, ftap_candidate.FTAP_Candi_LF_2_.u8_ID);

  ftap_candidate.FTAP_Candi_.u8_Inpathage_warn = CalculateInPathAge(
      ftap_candidate.FTAP_Candi_.u1_Inpath_warn, ftap_candidate.FTAP_Candi_LF_.u8_Inpathage_warn,
      ftap_candidate.FTAP_Candi_LF_2_.u8_Inpathage_warn, ftap_candidate.FTAP_Candi_.u8_ID,
      ftap_candidate.FTAP_Candi_LF_.u8_ID, ftap_candidate.FTAP_Candi_LF_2_.u8_ID);

  ftap_candidate.FTAP_Candi_.u1_inpathagecheck =
      DecideInPathAgeCheck(ftap_candidate.FTAP_Candi_.u8_Inpathage, ftap_candidate.FTAP_Candi_.u8_AEBconf);

  ftap_candidate.FTAP_Candi_.u1_inpathagecheck_warn = DecideInPathAgeCheck_warn(
      ftap_candidate.FTAP_Candi_.u8_Inpathage_warn, ftap_candidate.FTAP_Candi_.u8_AEBconf);

  ftap_candidate.FTAP_Candi_2_.u8_Inpathage =
      CalculateInPathAge(ftap_candidate.FTAP_Candi_2_.u1_Inpath, ftap_candidate.FTAP_Candi_LF_.u8_Inpathage,
                         ftap_candidate.FTAP_Candi_LF_2_.u8_Inpathage, ftap_candidate.FTAP_Candi_2_.u8_ID,
                         ftap_candidate.FTAP_Candi_LF_.u8_ID, ftap_candidate.FTAP_Candi_LF_2_.u8_ID);

  ftap_candidate.FTAP_Candi_2_.u8_Inpathage_warn = CalculateInPathAge(
      ftap_candidate.FTAP_Candi_2_.u1_Inpath_warn, ftap_candidate.FTAP_Candi_LF_.u8_Inpathage_warn,
      ftap_candidate.FTAP_Candi_LF_2_.u8_Inpathage_warn, ftap_candidate.FTAP_Candi_2_.u8_ID,
      ftap_candidate.FTAP_Candi_LF_.u8_ID, ftap_candidate.FTAP_Candi_LF_2_.u8_ID);

  ftap_candidate.FTAP_Candi_2_.u1_inpathagecheck = DecideInPathAgeCheck(
      ftap_candidate.FTAP_Candi_2_.u8_Inpathage, ftap_candidate.FTAP_Candi_2_.u8_AEBconf);

  ftap_candidate.FTAP_Candi_2_.u1_inpathagecheck_warn = DecideInPathAgeCheck_warn(
      ftap_candidate.FTAP_Candi_2_.u8_Inpathage_warn, ftap_candidate.FTAP_Candi_2_.u8_AEBconf);

  DecideInpathTar(ftap_candidate.FTAP_Candi_, ftap_candidate.FTAP_Candi_LF_, ftap_candidate.FTAP_Candi_LF_2_);
  DecideInpathTar(ftap_candidate.FTAP_Candi_2_, ftap_candidate.FTAP_Candi_LF_, ftap_candidate.FTAP_Candi_LF_2_);
  
  DecideFTAPFlag(ftap_candidate.FTAP_Candi_, ftap_candidate.FTAP_Candi_LF_, ftap_candidate.FTAP_Candi_LF_2_);
  DecideFTAPFlag(ftap_candidate.FTAP_Candi_2_, ftap_candidate.FTAP_Candi_LF_, ftap_candidate.FTAP_Candi_LF_2_);
  //auto dur = Time::Now() - ts;
  //std::cout << "extractftap complete,cost time"<<dur<<"ms"<<std::endl;

}

void extract_ftap::ClearRefPos(targetpos &ref_pos) {
  ref_pos.ref_character = 0;
  ref_pos.centerpoint.pos_x = 0;
  ref_pos.centerpoint.pos_y = 0;
  ref_pos.centerpoint.range = 0;
  ref_pos.frontcenter.pos_x = 0;
  ref_pos.frontcenter.pos_y = 0;
  ref_pos.frontcenter.range = 0;
  ref_pos.rearcenter.pos_x = 0;
  ref_pos.rearcenter.pos_y = 0;
  ref_pos.rearcenter.range = 0;
  ref_pos.leftcenter.pos_x = 0;
  ref_pos.leftcenter.pos_y = 0;
  ref_pos.leftcenter.range = 0;
  ref_pos.rightcenter.pos_x = 0;
  ref_pos.rightcenter.pos_y = 0;
  ref_pos.rightcenter.range = 0;
  ref_pos.referencepoint.pos_x = 0;
  ref_pos.referencepoint.pos_y = 0;
  ref_pos.referencepoint.range = 0;
  ref_pos.heading = 0;
}

void extract_ftap::ClearFTAPCandi() {
  ClearRefPos(ftap_candidate.FTAP_Candi_.ref_pos);
  ftap_candidate.FTAP_Candi_.u8_ID = 0U;
  ftap_candidate.FTAP_Candi_.u8_IDX = MaxVisionIndex;
  ftap_candidate.FTAP_Candi_.u8_VID = 0u;
  ftap_candidate.FTAP_Candi_.objectvalid = 0U;
  ftap_candidate.FTAP_Candi_.f4_TTC = DefaultTTC;
  ftap_candidate.FTAP_Candi_.f4_range = DefaultRange;
  ftap_candidate.FTAP_Candi_.f4_rangerate = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_vissup_dx = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_vissup_dy = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_vissup_vx = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_vissup_vy = 0.0f;
  ftap_candidate.FTAP_Candi_.u8_col_pointN = 0u;
  ftap_candidate.FTAP_Candi_.f4_collisionx_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_collisiony_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_collisionr_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_collisionx_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_collisiony_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_collisionr_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_.f4_longpos = DefaultRange;
  ftap_candidate.FTAP_Candi_.f4_latpos = DefaultRange;
  ftap_candidate.FTAP_Candi_.f4_longvel = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_latvel = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_Heading = 0.0f;
  ftap_candidate.FTAP_Candi_.f4_currentRange = DefaultRange;
  ftap_candidate.FTAP_Candi_.f4_rangeestimation = DefaultRange;
  ftap_candidate.FTAP_Candi_.u8_Inpathage = 0U;
  ftap_candidate.FTAP_Candi_.u8_Inpathage_warn = 0u;
  ftap_candidate.FTAP_Candi_.u1_inpathcur = 0;
  ftap_candidate.FTAP_Candi_.u1_inpathpre = 0;
  ftap_candidate.FTAP_Candi_.u1_Inpath = 0;
  ftap_candidate.FTAP_Candi_.u1_inpathcur_warn = 0;
  ftap_candidate.FTAP_Candi_.u1_inpathpre_warn = 0;
  ftap_candidate.FTAP_Candi_.u1_Inpath_warn = 0;
  ftap_candidate.FTAP_Candi_.u1_TOI_Before = 0U;
  ftap_candidate.FTAP_Candi_.u1_TOI_After = 0U;
  ftap_candidate.FTAP_Candi_.u1_vfplaucheck = 0U;
  ftap_candidate.FTAP_Candi_.u1_ageplaucheck = 0U;
  ftap_candidate.FTAP_Candi_.u1_inpathagecheck = 0U;
  ftap_candidate.FTAP_Candi_.u1_inpathagecheck_warn = 0U;
  ftap_candidate.FTAP_Candi_.u1_oncoming = 0U;
  ftap_candidate.FTAP_Candi_.u8_AEBconf = 0U;
  ftap_candidate.FTAP_Candi_.u8_lostradarage = 0U;
  ftap_candidate.FTAP_Candi_.f4_minTTC = DefaultTTC;
  ftap_candidate.FTAP_Candi_.f4_minRange = 200.0f;
  ftap_candidate.FTAP_Candi_.u1_movingstate = MoveState::kInit;
  ftap_candidate.FTAP_Candi_.warnig_flag = 0U;
  ftap_candidate.FTAP_Candi_.prefill_flag = 0U;
  ftap_candidate.FTAP_Candi_.lowbrake_flag = 0U;
  ftap_candidate.FTAP_Candi_.highbrake_flag = 0U;
  ClearRefPos(ftap_candidate.FTAP_Candi_2_.ref_pos);
  ftap_candidate.FTAP_Candi_2_.u8_ID = 0U;
  ftap_candidate.FTAP_Candi_2_.u8_IDX = MaxVisionIndex;
  ftap_candidate.FTAP_Candi_2_.u8_VID = 0u;
  ftap_candidate.FTAP_Candi_2_.objectvalid = 0U;
  ftap_candidate.FTAP_Candi_2_.f4_TTC = DefaultTTC;
  ftap_candidate.FTAP_Candi_2_.f4_range = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_rangerate = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_vissup_dx = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_vissup_dy = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_vissup_vx = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_vissup_vy = 0.0f;
  ftap_candidate.FTAP_Candi_2_.u8_col_pointN = 0u;
  ftap_candidate.FTAP_Candi_2_.f4_collisionx_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_collisiony_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_collisionr_1 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_collisionx_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_collisiony_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_collisionr_2 = DefaultCollPos;
  ftap_candidate.FTAP_Candi_2_.f4_longpos = DefaultRange;
  ftap_candidate.FTAP_Candi_2_.f4_latpos = DefaultRange;
  ftap_candidate.FTAP_Candi_2_.f4_longvel = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_latvel = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_Heading = 0.0f;
  ftap_candidate.FTAP_Candi_2_.f4_currentRange = DefaultRange;
  ftap_candidate.FTAP_Candi_2_.f4_rangeestimation = DefaultRange;
  ftap_candidate.FTAP_Candi_2_.u8_Inpathage = 0U;
  ftap_candidate.FTAP_Candi_2_.u8_Inpathage_warn = 0u;
  ftap_candidate.FTAP_Candi_2_.u1_inpathcur = 0;
  ftap_candidate.FTAP_Candi_2_.u1_inpathpre = 0;
  ftap_candidate.FTAP_Candi_2_.u1_Inpath = 0;
  ftap_candidate.FTAP_Candi_2_.u1_inpathcur_warn = 0;
  ftap_candidate.FTAP_Candi_2_.u1_inpathpre_warn = 0;
  ftap_candidate.FTAP_Candi_2_.u1_Inpath_warn = 0;
  ftap_candidate.FTAP_Candi_2_.u1_TOI_Before = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_TOI_After = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_vfplaucheck = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_ageplaucheck = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_inpathagecheck = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_inpathagecheck_warn = 0U;
  ftap_candidate.FTAP_Candi_2_.u1_oncoming = 0U;
  ftap_candidate.FTAP_Candi_2_.u8_AEBconf = 0U;
  ftap_candidate.FTAP_Candi_2_.u8_lostradarage = 0U;
  ftap_candidate.FTAP_Candi_2_.f4_minTTC = DefaultTTC;
  ftap_candidate.FTAP_Candi_2_.f4_minRange = 200.0f;
  ftap_candidate.FTAP_Candi_2_.u1_movingstate = MoveState::kInit;
  ftap_candidate.FTAP_Candi_2_.warnig_flag = 0U;
  ftap_candidate.FTAP_Candi_2_.prefill_flag = 0U;
  ftap_candidate.FTAP_Candi_2_.lowbrake_flag = 0U;
  ftap_candidate.FTAP_Candi_2_.highbrake_flag = 0U;
}

float extract_ftap::CalculateCirRange(float col_y, float ego_roc) {
  float col_r = DefaultCollPos;
  float theta_1 = 0.0f;
  if (fabsf(col_y) >= fabsf(ego_roc) && fabsf(col_y) <= 2 * fabsf(ego_roc)) {
    theta_1 = Pi - acosf((fabsf(col_y - ego_roc)) / fabsf(ego_roc));
    col_r = theta_1 * fabsf(ego_roc);
  } else if (fabsf(col_y) < fabsf(ego_roc)) {
    theta_1 = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
    col_r = theta_1 * fabsf(ego_roc);
  } else {
    col_r = DefaultCollPos;
  }
  return col_r;
}

void extract_ftap::UpdateRefPos(targetpos &ref_pos) {
  // float range_front = 1000;
  // float range_rear = 1000;
  // float range_center = 1000;
  // range_front = ref_pos.frontcenter.range;
  // range_rear = ref_pos.rearcenter.range;
  // range_center = ref_pos.centerpoint.range;
  // if (range_front <= range_rear && range_front <= range_center) {
  //   ref_pos.ref_character = 1;
  //   ref_pos.referencepoint = ref_pos.frontcenter;
  // }
  // else if (range_rear < range_front && range_rear <= range_center) {
  //   ref_pos.ref_character = 2;
  //   ref_pos.referencepoint = ref_pos.rearcenter;
  // }
  // else {
  //   ref_pos.ref_character = 0;
  //   ref_pos.referencepoint = ref_pos.centerpoint;
  // }
  ref_pos.ref_character = 1;
  ref_pos.referencepoint = ref_pos.frontcenter;
}

float extract_ftap::CalculateCirX(float col_y, float longpos,
                                float latpos, float heading) {
  float col_x = DefaultCollPos;
  col_x = heading * (col_y - latpos) + longpos;
  return col_x;
}

float extract_ftap::CalculateCornerRange(float col_y, float ego_roc) {
  float col_r = DefaultCollPos;
  float theta_1 = 0.0f;
  theta_1 =
      acosf(fabsf(col_y - ego_roc) / (fabsf(ego_roc) - ego_->vehicle_info.arb_vehicle.width * 0.5));
  col_r = theta_1 * (fabsf(ego_roc) - ego_->vehicle_info.arb_vehicle.width * 0.5);
  return col_r;
}

float extract_ftap::CalculateCirTTC(float col_r1, float egospd,
                                  uint8_t col_N, float egoacc,
                                  bool AEBactive) {
  float Col_TTC = DefaultTTC;
  float Col_TTC_based = DefaultTTC;
  if (col_N >= 1) {
    Col_TTC_based = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth) / egospd;

    if (fabsf(egoacc) <= MaxEgoAccThres) {
      Col_TTC = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth) / egospd;
    } else {
      if ((egospd * egospd + 2 * egoacc * col_r1) >= 0) {
        Col_TTC =
            ((-1) * egospd +
             sqrtf(egospd * egospd +
                   2 * egoacc *
                       (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth))) /
            egoacc;
      } else {
        Col_TTC = DefaultTTC;
      }
    }
  } else {
    Col_TTC = DefaultTTC;
  }

  if (AEBactive == 1) {
    Col_TTC = Col_TTC_based;
  }

  return Col_TTC;
}

float extract_ftap::CalculateCirTTL(float col_r1, float egospd,
                                  uint8_t col_N, float egoacc,
                                  bool AEBactive) {
  float Col_TTC = DefaultTTC;
  float Col_TTC_based = DefaultTTC;
  if (col_N >= 1) {
    Col_TTC_based = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + RearAxleToBack) / egospd;

    if (fabsf(egoacc) <= MaxEgoAccThres) {
      Col_TTC = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + RearAxleToBack) / egospd;
    } else {
      if ((egospd * egospd + 2 * egoacc * col_r1) >= 0) {
        Col_TTC =
            ((-1) * egospd +
             sqrtf(egospd * egospd +
                   2 * egoacc *
                       (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + 0.5f))) /
            egoacc;
      } else {
        Col_TTC = DefaultTTC;
      }
    }
  } else {
    Col_TTC = DefaultTTC;
  }

  if (AEBactive == 1) {
    Col_TTC = Col_TTC_based;
  }

  return Col_TTC;
}

float extract_ftap::CalculateCirPreRange(float longpos, float latpos,
                                       float longspd, float latspd,
                                       float TTC, float colx,
                                       float coly, uint8_t col_N,
                                       float longacc, float latacc) {
  float predx = DefaultPos;
  float predy = DefaultPos;
  float predr = DefaultPos;
  predx = longpos + longspd * TTC + 0.5 * longacc * TTC * TTC;
  predy = latpos + latspd * TTC + 0.5 * latacc * TTC * TTC;
  if (col_N >= 1) {
    if ((predx <= colx && longspd <= 0) || (predx >= colx && longspd >= 0)) {
      predr = sqrtf((predx - colx) * (predx - colx) +
                  (predy - coly) * (predy - coly)) * (-1);
    }
    else {
      predr = sqrtf((predx - colx) * (predx - colx) +
                  (predy - coly) * (predy - coly));
    }
  } else {
    predr = DefaultPos;
  }
  return predr;
}

float extract_ftap::CalculateCirCurRange(float longpos, float latpos,
                                       float colx, float coly,
                                       uint8_t col_N, float longspd) {
  float currentrange = DefaultRange;
  if (col_N >= 1) {
    if ((longpos <= colx && longspd <= 0) || (longpos >= colx && longspd >= 0)) {
      currentrange = sqrtf((longpos - colx) * (longpos - colx) +
                         (latpos - coly) * (latpos - coly)) * (-1);
    }
    else {
      currentrange = sqrtf((longpos - colx) * (longpos - colx) +
                         (latpos - coly) * (latpos - coly));
    }
  } else {
    currentrange = DefaultRange;
  }

  return currentrange;
}

MoveState extract_ftap::DecideMoveState(float longpos, float latpos,
                                    float longspd, float latspd,
                                    float TTC, float ROC) {
  float predx = DefaultPos;
  float predy = DefaultPos;
  predx = longpos + longspd * TTC;
  predy = latpos + latspd * TTC;
  float rangeroc = DefaultRangeRoc;
  float predroc = DefaultPredRoc;

  rangeroc = longpos * longpos + (latpos - ROC) * (latpos - ROC);
  predroc = predx * predx + (predy - ROC) * (predy - ROC);

  if (((rangeroc >= ROC * ROC) && (predroc <= ROC * ROC)) ||
      ((rangeroc <= ROC * ROC) && (predroc >= ROC * ROC))) {
    return MoveState::kMoving_through;
  }
  return MoveState::kInit;
}

uint8_t extract_ftap::DecideCCR_AEBConf(AEBObjectFTAP &tmpobj) {
  if ((tmpobj.obj.IsAllFused() == 1 && tmpobj.obj.fusion_sup.confidence >= MatchConfThres)) {
    if (tmpobj.obj.HasLidarFused() == 1) {
      if (tmpobj.obj.HasVisionFused() == 1) {
        return 3;
      }
      else {
        return 1;
      }
    }
    else {
      return 3;
    }
  } else if ((tmpobj.obj.IsVisionOnly() == 1 && tmpobj.obj.IsAllFusedHis() == 1) && tmpobj.obj.fusion_sup.confidence >= MatchConfThres) {
    return 2;
  } else if ((tmpobj.obj.IsVisionOnly() == 1 || tmpobj.obj.IsRadarOnly() == 1) && tmpobj.obj.IsAllFusedHis() == 0) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ftap::CCR_VF_Longpos_check(float fusionLongPos,
                                      float visionLongPos,
                                      float Rangerate, float egoacc) {
  float LongPosError;
  LongPosError =
      threshold_CCR_LongPos_VFcheck_.interpolate(fusionLongPos, Rangerate);
  if (fabsf(egoacc) >= MaxCcrVfCheckEgoAcc) {
    return 1;
  } else {
    if (fabsf(fusionLongPos - visionLongPos - (ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - ego_->vehicle_info.arb_vehicle.epm_pos_to_front_bumper)) <= LongPosError) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ftap::CCR_Age_check(bool isfusion, bool isradar, bool isvision,
                               size_t tracklet_count, uint8_t age) {
  //vis age turn into 20 for tempo test;
  if ((isfusion == 1 && age >= MinFusionObjAge) ||
      (isradar == 1 && tracklet_count >= 2 && age >= MinRadarObjAge) ||
      (isradar == 1 && tracklet_count == 1 && age >= MinRadarObjAge) ||
      (isvision == 1 && age >= MinVisionObjAge)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ftap::DecideTargetOncoming(float longvel, float range) {
  bool isoncoming = 0;
  float oncomingspdthreshold = -1000.0f;
  oncomingspdthreshold = threshold_FTAP_OncomingSpd_.interpolate(range);
  if (longvel <= oncomingspdthreshold) {
    isoncoming = 1;
  } else {
    isoncoming = 0;
  }
  return isoncoming;
}

float extract_ftap::CalculateCirAngle(float col_y, float ego_roc) {
  float CirAngle = 0.0;

  if (col_y <= 0 && col_y > ego_roc) {
    CirAngle = (acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc))) * (-1);
  } else if (col_y <= 0 && col_y <= ego_roc && col_y >= (ego_roc)*2) {
    CirAngle = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc)) - Pi;
  } else if (col_y > 0 && col_y < ego_roc) {
    CirAngle = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
  } else if (col_y > 0 && col_y >= ego_roc && col_y <= (ego_roc)*2) {
    CirAngle = Pi - acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
  }

  return CirAngle;
}

uint8_t extract_ftap::DecideFTAPTOI(float range, float longvel,
                                  float latvel, float targetangle,
                                  bool isoncoming, float egospd, bool notmoveout) {
  float FTAPRangeThres = 0.0f;
  bool isinrange = 0;
  bool spdinrange = 0;
  bool anginrange = 0;
  bool isinTOI = 0;

  float targetspd = 0.0f;

  FTAPRangeThres = threshold_FTAP_range_.interpolate(egospd);
  targetspd = sqrtf(longvel * longvel + latvel * latvel);

  isinrange = (range <= FTAPRangeThres) ? 1 : 0;

  spdinrange = (targetspd >= ToiTargetSpdThrs) ? 1 : 0;

  anginrange = (fabsf(targetangle) <= Degree90ToRad) ? 1 : 0;

  anginrange = 1;

  isinTOI = (isinrange && spdinrange && anginrange && isoncoming && notmoveout) ? 1 : 0;

  return isinTOI;
}

bool extract_ftap::DecideInpathpre(float range, float targetlength,
                                 float headingangle, MoveState movestate,
                                 float rangeestimate, float ColRange,
                                 float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_FTAP_predict_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_FTAP_expend_predict_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((fabsf(rangeestimate) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (fabsf(rangeestimate) <= predictside) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ftap::DecideInpathpre_warn(float range, float targetlength,
                                      float headingangle, MoveState movestate,
                                      float rangeestimate, float ColRange,
                                      float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_FTAP_predict_warn_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_FTAP_expend_predict_warn_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((fabsf(rangeestimate) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (fabsf(rangeestimate) <= predictside) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ftap::DecideInpathcur(float range, float targetlength,
                                 float headingangle, float rangecur,
                                 float ColRange, float targetspd) {
  float currentrange = 0.0f;
  currentrange = threshold_FTAP_current_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float currentexpandrange = 0.0f;
  currentexpandrange =
      threshold_FTAP_expend_current_.interpolate(targetspd, ColRange);

  float currentside = 0.0f;
  currentside = currentrange + currentexpandrange;

  if (fabsf(rangecur) <= currentside) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ftap::DecideInpathcur_warn(float range, float targetlength,
                                      float headingangle, float rangecur,
                                      float ColRange, float targetspd) {
  float currentrange = 0.0f;
  currentrange = threshold_FTAP_current_warn_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float currentexpandrange = 0.0f;
  currentexpandrange =
      threshold_FTAP_expend_current_warn_.interpolate(targetspd, ColRange);

  float currentside = 0.0f;
  currentside = currentrange + currentexpandrange;

  if (fabsf(rangecur) <= currentside) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ftap::DecideInpathpre_after(float range, float targetlength,
                                       float headingangle, MoveState movestate,
                                       float rangeestimate,
                                       float ColRange, float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_FTAP_predict_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_FTAP_expend_predict_.interpolate(targetspd, ColRange);

  float predictexpand_after = 0.0f;
  predictexpand_after =
      threshold_FTAP_expend_predict_after_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((fabsf(rangeestimate) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((fabsf(rangeestimate) - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (fabsf(rangeestimate) <= predictside + predictexpand_after) {
      return 1;
    } else {
      return 0;
    }
  }
}

uint8_t extract_ftap::CalculateInPathAge(bool inpath, uint8_t inpathage_1,
                                       uint8_t inpathage_2, uint8_t ID,
                                       uint8_t ID_1, uint8_t ID_2) {
  uint8_t inpathage = 0;

  if (ID == ID_1) {
    inpathage = inpathage_1;
  } else if (ID == ID_2) {
    inpathage = inpathage_2;
  } else {
    inpathage = 0;
  }

  if (inpath == 1) {
    inpathage++;
  } else {
    if (inpathage >= InPathAgeStep) {
      inpathage = inpathage - InPathAgeStep;
    } else {
      inpathage = 0;
    }
  }
  if (inpathage >= MaxInpathAge) {
    inpathage = MaxInpathAge;
  }
  return inpathage;
}

bool extract_ftap::DecideInPathAgeCheck(uint8_t inpathage, uint8_t AEBconf) {
  uint8_t inpathage_threshold = 0;
  inpathage_threshold = threshold_CCFTAP_InPathAge_.interpolate(AEBconf);

  bool inpathage_check = 0;
  inpathage_check = (inpathage >= inpathage_threshold) ? 1 : 0;

  return inpathage_check;
}

bool extract_ftap::DecideInPathAgeCheck_warn(uint8_t inpathage, uint8_t AEBconf) {
  uint8_t inpathage_threshold = 0;
  inpathage_threshold = threshold_CCFTAP_InPathAge_warn_.interpolate(AEBconf);

  bool inpathage_check = 0;
  inpathage_check = (inpathage >= inpathage_threshold) ? 1 : 0;

  return inpathage_check;
}

void extract_ftap::DecideInpathTar(AEBObjectFTAP &Candi, AEBObjectFTAP &Candi_LF, AEBObjectFTAP &Candi_LF2) {
  float targetlength = 0;
  if (Candi.obj.length() > TargetLengthThres) {
    targetlength = Candi.obj.length();
  }
  else {
    targetlength = TargetLengthThres;
  }
  
  feature::math::Vector2f MidVect;
  Candi.HostPos_tar.x = 0;
  Candi.HostPos_tar.y = 0;
  Candi.HostPos.x = ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle;
  Candi.HostPos.y = 0;
  Candi.turnangle = 0;
  Candi.turnangle = Degree90ToRad + Candi.f4_Headangle;
  feature::math::Matrix2f rotate_m = feature::math::from_angle(Candi.turnangle);
  
  MidVect.x = Candi.HostPos.x - Candi.obj.motion.GetPos().x;
  MidVect.y = Candi.HostPos.y - Candi.obj.motion.GetPos().y;

  Candi.HostPos_tar = rotate_m * MidVect;
  Candi.HostVel.x = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * sinf(Candi.turnangle + Degree90ToRad);
  Candi.HostVel.y = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * cosf(Candi.turnangle + Degree90ToRad) * (-1);
  Candi.target_spd = sqrtf(Candi.obj.motion.GetVx() * Candi.obj.motion.GetVx() + Candi.obj.motion.GetVy() * Candi.obj.motion.GetVy());
  Candi.TTC_tar = (Candi.f4_currentRange - ego_->vehicle_info.arb_vehicle.width*(0.5) - 1)/Candi.target_spd;
  Candi.TTL_tar = (Candi.f4_currentRange + targetlength + ego_->vehicle_info.arb_vehicle.width*(0.5))/Candi.target_spd;
  Candi.predictrange_tar = Candi.HostPos_tar.y + Candi.HostVel.y * Candi.TTC_tar;

  bool timeinrange = 0;
  bool hostinrange = 0;
  bool hostmovingin = 0;
  bool hostnotturn = 0;
  //timeinrange = (((Candi.f4_TTC >= Candi.TTC_tar) && (Candi.f4_TTC <= Candi.TTL_tar))||((Candi.f4_TTL >= Candi.TTC_tar) && (Candi.f4_TTL <= Candi.TTL_tar))) ?1:0;

  timeinrange = ((Candi.f4_TTC >= Candi.TTC_tar) && (Candi.f4_TTC <= Candi.TTL_tar)) ?1:0;

  hostnotturn = (fabsf(Candi.obj.motion.GetHeadRate()) < 0.1)?1:0; 

  hostinrange = (Candi.HostPos_tar.y >= HostPosTarThres && Candi.HostPos_tar.y <= -1.0 && Candi.predictrange_tar >= Candi.HostPos_tar.y) ?1:0;
  
  hostmovingin = ((Candi.HostPos_tar.y > 0 && Candi.HostVel.y < 0) || (Candi.HostPos_tar.y <= 0 && Candi.HostVel.y >= 0)) ?1:0;
  
  Candi.u1_inpath_tar = (timeinrange && hostinrange && hostmovingin && hostnotturn);
}

void extract_ftap::DecideFTAPFlag(AEBObjectFTAP &Candi, AEBObjectFTAP &Candi_LF,
                                AEBObjectFTAP &Candi_LF2) {
  float warningTTC = 0.0f;
  float prefillTTC = 0.0f;
  float lowBTTC = 0.0f;
  float highBTTC = 0.0f;

  Candi.highbrake_flag = 0;
  Candi.lowbrake_flag = 0;
  Candi.prefill_flag = 0;
  Candi.warnig_flag = 0;
  Candi.iba_flag = 0;

  warningTTC =
      threshold_CCFTAP_WarningTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  prefillTTC =
      threshold_CCFTAP_PrefillTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  lowBTTC =
      threshold_CCFTAP_LowBrakeTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  highBTTC = threshold_CCFTAP_HighBrakeTTC_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  if (fcw_sensitive == 0) {
    warningTTC = warningTTC + WarnTTCBuffer;
  }
  else if (fcw_sensitive == 2) {
    warningTTC = warningTTC - WarnTTCBuffer;
  }

  uint8_t lastBrakeActive = 0;
  uint8_t lastBrakeActive_2 = 0;
  uint8_t lastIBAActive = 0;
  uint8_t lastIBAActive_2 = 0;

  if (Candi_LF.highbrake_flag > 0 || Candi_LF.lowbrake_flag > 0) {
    lastBrakeActive = Candi_LF.u8_ID;
  }

  if (Candi_LF2.highbrake_flag > 0 || Candi_LF2.lowbrake_flag > 0) {
    lastBrakeActive_2 = Candi_LF2.u8_ID;
  }

  lastIBAActive = (Candi_LF.iba_flag > 0)?1:0;
  lastIBAActive_2 = (Candi_LF2.iba_flag > 0)?1:0;

  if (Candi.u1_Inpath == 1 || Candi.u1_TOI_After == 1) {
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= highBTTC && ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.highbrake_flag &&
           Candi_LF.highbrake_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.highbrake_flag &&
           Candi_LF2.highbrake_flag > 0))) &&
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.highbrake_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= lowBTTC && ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.lowbrake_flag &&
           Candi_LF.lowbrake_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.lowbrake_flag &&
           Candi_LF2.lowbrake_flag > 0)) &&
         (Candi.highbrake_flag != Candi.u8_ID)) &&
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.lowbrake_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck_warn == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= prefillTTC && //AEBSupressReason_SpeedLow == 0 &&
           //AEBSupressReason_CCFTAP == 0x0000
           ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.prefill_flag && Candi_LF.prefill_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.prefill_flag &&
           Candi_LF2.prefill_flag > 0)) &&
         (Candi.highbrake_flag != Candi.u8_ID &&
          Candi.lowbrake_flag != Candi.u8_ID)) &&
        //AEBSupressReason_AfterPref == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.prefill_flag = Candi.u8_ID;
    }

    if (((Candi.u1_inpathagecheck_warn == 1 && Candi.u1_TOI_Before == 1 &&
          Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) &&
         (Candi.f4_TTC <= warningTTC && //AEBSupressReason_SpeedLow == 0 &&
          //AEBSupressReason_CCFTAP == 0x0000
          ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) &&
         (Candi.highbrake_flag != Candi.u8_ID &&
          Candi.lowbrake_flag != Candi.u8_ID &&
          Candi.prefill_flag != Candi.u8_ID)) &&
        //AEBSupressReason == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.warnig_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastIBAActive ||
           Candi.u8_ID == lastIBAActive_2)) &&
         ((Candi.f4_TTC <= highBTTC && //AEBSupressReason_SpeedLow == 0x0000
         ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.iba_flag &&
           Candi_LF.iba_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.iba_flag &&
           Candi_LF2.iba_flag > 0))) &&
        //AEBSupressReason_IBA == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.iba_flag = Candi.u8_ID;
    }
  } else {
    Candi.highbrake_flag = 0;
    Candi.lowbrake_flag = 0;
    Candi.prefill_flag = 0;
    Candi.warnig_flag = 0;
    Candi.iba_flag = 0;
  }
}





}
}