#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aes_extract_ccr.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {

    extract_aesccr aesccr_extraction_;

    void extract_aesccr::MainFunction() {

      UpdateCalibration();

      UpdateLineInfo();

      UpdateLppInfo();

      ExtractAESCCR();
    }

    extract_aesccr::extract_aesccr() {}

    void extract_aesccr::UpdateCalibration() {
        size_t funnelrange =
            sizeof(EAEB_dstFunnelRange_x) / sizeof(EAEB_dstFunnelRange_x[0]);
        threshold_CCR_stationary_inner_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstStatInFunnel_v, funnelrange);
        threshold_CCR_longitude_inner_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstMovInFunnel_v, funnelrange);
        threshold_CCR_longitude_outter_funnel_.init(
            EAEB_dstFunnelRange_x, EAEB_dstMovOutFunnel_v, funnelrange);

        threshold_CCR_LongPos_VFcheck_.init(
            EAEB_dstLongPosCheck_LongPos_x, EAEB_spdLongPosCheck_Rrate_y,
            EAEB_dstLongPosCheck_Poserror_v,
            sizeof(EAEB_dstLongPosCheck_LongPos_x) /
                sizeof(EAEB_dstLongPosCheck_LongPos_x[0]),
            sizeof(EAEB_spdLongPosCheck_Rrate_y) /
                sizeof(EAEB_spdLongPosCheck_Rrate_y[0]));

        size_t norm_egospd_cal =
            sizeof(EAEB_spdCCR_egospd_x) / sizeof(EAEB_spdCCR_egospd_x[0]);
        size_t norm_rangerate_cal =
            sizeof(EAEB_spdCCR_RRate_y) / sizeof(EAEB_spdCCR_RRate_y[0]);
        threshold_CCR_LowB_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCLowB_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_CCR_HighB_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                        EAEB_TTCHighB_norm_v, norm_egospd_cal,
                                        norm_rangerate_cal);
        threshold_CCR_Pref_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCPrefill_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_CCR_Warn_TTC_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y,
                                    EAEB_TTCWarn_norm_v, norm_egospd_cal,
                                    norm_rangerate_cal);
        threshold_ccr_ttb_longsafe_.init(EAEB_spdCCR_egospd_x, EAEB_dstccr_timetobrake_safezone_v, norm_egospd_cal);
        threshold_ccr_ttb_offset_.init(EAEB_spdCCR_egospd_x, EAEB_spdCCR_RRate_y, EAEB_TTB_offset_v, norm_egospd_cal, norm_rangerate_cal);

        size_t decel_range_cal =
            sizeof(EAEB_dstCCRdecl_Range_x) / sizeof(EAEB_dstCCRdecl_Range_x[0]);
        size_t targ_decel_cal = sizeof(EAEB_accCCRdecl_TargDecl_y) /
                                sizeof(EAEB_accCCRdecl_TargDecl_y[0]);
        threshold_CCR_LowB_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y, EAEB_TTCLowB_decel_v,
            decel_range_cal, targ_decel_cal);
        threshold_CCR_HighB_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y,
            EAEB_TTCHighB_decel_v, decel_range_cal, targ_decel_cal);
        threshold_CCR_Pref_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y,
            EAEB_TTCPrefill_decel_v, decel_range_cal, targ_decel_cal);
        threshold_CCR_Warn_decel_TTC_.init(
            EAEB_dstCCRdecl_Range_x, EAEB_accCCRdecl_TargDecl_y, EAEB_TTCWarn_decel_v,
            decel_range_cal, targ_decel_cal);

        size_t inpath_range_cal =
            sizeof(EAEB_dstInPath_Range_x) / sizeof(EAEB_dstInPath_Range_x[0]);
        threshold_CCR_HitDist_Before_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_HitDistBef_v, inpath_range_cal);
        threshold_CCR_HitDist_After_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_HitDistAft_v, inpath_range_cal);
        threshold_CCR_YawDist_Before_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_YawDistBef_v, inpath_range_cal);
        threshold_CCR_YawDist_After_.init(
            EAEB_dstInPath_Range_x, EAEB_dstInPath_YawDistAft_v, inpath_range_cal);
        threshold_CCR_XOLC_Before_.init(EAEB_dstInPath_Range_x,
                                        EAEB_dstInPath_XOLCBef_v, inpath_range_cal);
        threshold_CCR_XOLC_After_.init(EAEB_dstInPath_Range_x,
                                        EAEB_dstInPath_XOLCAft_v, inpath_range_cal);

        size_t ttc_XOLCPer_cal = sizeof(EAEB_perTTCcalc_XOLCperc_x) /
                                sizeof(EAEB_perTTCcalc_XOLCperc_x[0]);
        threshold_CCR_XOLCper_Warn_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perWarn_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Pref_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perPref_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Low_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perLowB_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_High_.init(EAEB_perTTCcalc_XOLCperc_x,
                                        EAEB_perHighB_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Warn_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perWarnMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Pref_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perPrefMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_Low_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perLowBMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_CCR_XOLCper_High_Mout_.init(
            EAEB_perTTCcalc_XOLCperc_x, EAEB_perHighBMO_TTCperc_v, ttc_XOLCPer_cal);
        threshold_movingout_deltayaw_.init(EAEB_perTTCcalc_XOLCperc_x,
                                            EAEB_perdeltayawrate_v, ttc_XOLCPer_cal);
        threshold_ccr_ttt_latsafe_.init(EAEB_perTTCcalc_XOLCperc_x, EAEB_dstccr_timetoturn_safelat_v, ttc_XOLCPer_cal);
        threshold_ccr_ttt_offset_.init(EAEB_perTTCcalc_XOLCperc_x, EAEB_spdCCR_egospd_x, EAEB_TTT_offset_v, ttc_XOLCPer_cal, norm_egospd_cal);

        size_t conf_cal =
        sizeof(EAEB_agecheck_AEBconf_x) / sizeof(EAEB_agecheck_AEBconf_x[0]);

        threshold_AES_InPathAge_.init(EAEB_agecheck_AEBconf_x,
                                        EAES_InPath_age_v, conf_cal);
        
        size_t inpathspd_cal = sizeof(EAES_spdCCR_range_x) / sizeof(EAES_spdCCR_range_x[0]);
        size_t inpathsrrate_cal = sizeof(EAES_spdCCR_RRate_y) / sizeof(EAES_spdCCR_RRate_y[0]);
        threshold_aes_inpath_current_.init(EAES_spdCCR_range_x, EAES_spdCCR_RRate_y, EAES_InPath_current_v, inpathspd_cal, inpathsrrate_cal);
        threshold_aes_inpath_predict_.init(EAES_spdCCR_range_x, EAES_spdCCR_RRate_y, EAES_InPath_predict_v, inpathspd_cal, inpathsrrate_cal);
    }


void extract_aesccr::ExtractAESCCR() {
    aes_candidate.AESCCR1_Candi_LF_ = aes_candidate.AESCCR1_Candi_;
    aes_candidate.AESCCR2_Candi_LF_ = aes_candidate.AESCCR2_Candi_;
    clearCCRCandidate();
    close_aes.f4_range = 1000;
    for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
      if(fused_obj_filtered.at(i).gofcheck.check_valid == true){
        if ((fused_obj_filtered.at(i).raw_data.classification.IsVehicle()) &&
            fused_obj_filtered.at(i).raw_data.IsValid() && fused_obj_filtered.at(i).raw_data.valid_status() == 2 &&
            fused_obj_filtered.at(i).raw_data.motion.GetX() > 0) {
        AESObjectCCR tmp_objCCR;
        
        tmp_objCCR.obj = fused_obj_filtered.at(i).raw_data;
        tmp_objCCR.u8_ID = fused_obj_filtered.at(i).raw_data.GetID();
        tmp_objCCR.u8_IDX = i;
        
        uint8_t vision_ID = MaxVisionIndex;
        vision_ID = VisMatchID_[i].vis_id;
        tmp_objCCR.u8_VID = vision_ID;
        
        if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID &&
            vision_ID != MaxVisionIndex) {
                
            tmp_objCCR.f4_vissup_dx = vis_obj_->at(vision_ID).motion.GetX();
            
        }
        
        tmp_objCCR.objectvalid = fused_obj_filtered.at(i).raw_data.IsValid();
        
        tmp_objCCR.f4_range = sqrtf(
            powf((fused_obj_filtered.at(i).raw_data.motion.GetX() - 3.9), 2) +
            powf(fused_obj_filtered.at(i).raw_data.motion.GetY(), 2));
        tmp_objCCR.f4_rangerate =
            fused_obj_filtered.at(i).raw_data.motion.GetVx() - ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        float ego_ROC;
        ego_ROC = ROC(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                        ego_state_aeb.yawrate);
        tmp_objCCR.f4_XOLC = fused_obj_filtered.at(i).raw_data.motion.GetY() -
                            deltay(ego_ROC, tmp_objCCR.f4_range,
                                    ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);
        
        tmp_objCCR.f4_relatAcc =
            ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2 - fused_obj_filtered.at(i).raw_data.motion.GetAx();
        tmp_objCCR.f4_TTC = CalCCRTTC(
            tmp_objCCR.f4_rangerate, tmp_objCCR.f4_relatAcc, tmp_objCCR.f4_range);
        tmp_objCCR.f4_TTC_new = CalCCRTTC_1(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, tmp_objCCR.obj.motion.GetVx(), ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81, tmp_objCCR.obj.motion.GetAx(), tmp_objCCR.f4_range, tmp_objCCR.obj.motion_status.IsOncoming());
        
        tmp_objCCR.f4_TTCbased =
            CalCCRTTCBased(tmp_objCCR.f4_rangerate, tmp_objCCR.f4_range);

        tmp_objCCR.f4_latest = tmp_objCCR.f4_XOLC + (tmp_objCCR.obj.motion.GetVy() * tmp_objCCR.f4_TTC);

        CalCCRTTB(tmp_objCCR);

        CalCCRTTT_Left(tmp_objCCR);
        CalCCRTTT_Right(tmp_objCCR);

        if (lfbrake_active == 1) {
            tmp_objCCR.f4_TTC = tmp_objCCR.f4_TTCbased;
        }

        tmp_objCCR.u8_AEBconf = DecideCCR_AEBConf(
            tmp_objCCR.obj.IsAllFused(), tmp_objCCR.obj.IsAllFusedHis(),
            tmp_objCCR.obj.IsVisionOnly(), tmp_objCCR.obj.IsRadarOnly(),
            tmp_objCCR.obj.fusion_sup.confidence);
        #if defined(GENESIS_DEBUG)
        // this logic is for resim temporary.
        if (tmp_objCCR.obj.motion_status.IsMoved() == 0 &&
            tmp_objCCR.obj.IsVisionOnly() == 1 &&
            tmp_objCCR.obj.motion.GetX() <= 30.0f) {
            tmp_objCCR.u8_AEBconf = 2;
        }
        //=============================================================================
        #endif
        if (tmp_objCCR.obj.IsRadarOnly() != 1 && tmp_objCCR.obj.IsVisionOnly() != 1) {
            tmp_objCCR.u1_vfplaucheck = CCR_VF_Longpos_check(
                tmp_objCCR.obj.motion.GetX(), tmp_objCCR.f4_vissup_dx,
                tmp_objCCR.f4_rangerate, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2));
        } else {
            tmp_objCCR.u1_vfplaucheck = 1;
        }

        tmp_objCCR.u1_vfplaucheck = 1;

        if (tmp_objCCR.obj.motion.GetVx() < OncVxThres) {
            tmp_objCCR.u1_oncoming = 1;
        } else {
            tmp_objCCR.u1_oncoming = 0;
        }

        tmp_objCCR.u1_ageplaucheck = CCR_Age_check(
            tmp_objCCR.obj.IsAllFused(), tmp_objCCR.obj.IsRadarOnly(),
            tmp_objCCR.obj.IsVisionOnly(),
            sizeof(tmp_objCCR.obj.fusion_sup.radar_list),
            tmp_objCCR.obj.fusion_sup.age);

        if (tmp_objCCR.obj.motion_status.IsMoving() == 0 &&
            tmp_objCCR.obj.IsVisionOnly() == 1 &&
            tmp_objCCR.obj.motion.GetX() <= AgeCheckXThres &&
            tmp_objCCR.obj.fusion_sup.age >= AgeCheckFusAgeThres) {
            tmp_objCCR.u1_ageplaucheck = 1;
        }

        tmp_objCCR.u1_headplaucheck = 0;
        if ((tmp_objCCR.obj.motion.GetHead() >= -HeadCheckThresLow && tmp_objCCR.obj.motion.GetHead() <= HeadCheckThresLow) || 
            (tmp_objCCR.obj.motion.GetHead() >= -HeadCheckThresHigh && tmp_objCCR.obj.motion.GetHead() <= -HeadCheckThresMid) || 
            (tmp_objCCR.obj.motion.GetHead() >= HeadCheckThresMid && tmp_objCCR.obj.motion.GetHead() <= HeadCheckThresHigh)) {
          tmp_objCCR.u1_headplaucheck = 1;
        }
        else {
          tmp_objCCR.u1_headplaucheck = 0;
        }

        tmp_objCCR.u1_movingstate =
            DecideMoveState(tmp_objCCR.f4_XOLC, deltayawrate);

        tmp_objCCR.u1_ismovingout = 0;
        tmp_objCCR.u1_ismovingout =
            DecideMoveOut(tmp_objCCR.f4_XOLC, deltayawrate);

        tmp_objCCR.u1_TOI =
            DecideTOI(tmp_objCCR);

        CalcCenterPoint(tmp_objCCR);
        CalcCornerPoint(tmp_objCCR);
        CalcCurCornerPoint(ego_ROC, tmp_objCCR);
        CalcCornerPointEsti(tmp_objCCR);
        CalcInPathCur(tmp_objCCR);
        CalcInPathPre(tmp_objCCR);

        tmp_objCCR.u1_Inpath = tmp_objCCR.u1_Inpath_Cur && tmp_objCCR.u1_Inpath_Pre;

        if (tmp_objCCR.obj.classification.IsVehicle() == 1) {
          uint8_t isAESX = 0;
          if (tmp_objCCR.u8_AEBconf >= 2 && tmp_objCCR.u1_vfplaucheck == 1 && ((tmp_objCCR.u1_ageplaucheck == 1 && tmp_objCCR.u1_headplaucheck == 1 && tmp_objCCR.u1_TOI == 1) || tmp_objCCR.u8_ID == aes_candidate.AESCCR1_Candi_LF_.u8_ID || tmp_objCCR.u8_ID == aes_candidate.AESCCR2_Candi_LF_.u8_ID)) {
            isAESX = SelectAESCandi(tmp_objCCR);
            if (isAESX == 1) {
              tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
              tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
              aes_candidate.AESCCR1_Candi_ = tmp_objCCR;
            }
            else if (isAESX == 2) {
              tmp_objCCR.f4_minTTC = tmp_objCCR.f4_TTC;
              tmp_objCCR.f4_minRange = tmp_objCCR.f4_range;
              aes_candidate.AESCCR2_Candi_ = tmp_objCCR;
            }
          }
        }

        if (fabsf(tmp_objCCR.obj.motion.GetY())<= 4 &&(tmp_objCCR.obj.IsVisionOnly() == 1 || tmp_objCCR.obj.IsAllFused() == 1) && tmp_objCCR.obj.motion.GetX() >= 3.9 && tmp_objCCR.f4_range < close_aes.f4_range) {
            close_aes = tmp_objCCR;
        }
      }
    }
  }
  DetermineOncomLane();

  CalcCCRInPathAge(aes_candidate.AESCCR1_Candi_, aes_candidate.AESCCR1_Candi_LF_, aes_candidate.AESCCR2_Candi_LF_);

  CalcCCRInPathAge(aes_candidate.AESCCR2_Candi_, aes_candidate.AESCCR2_Candi_LF_, aes_candidate.AESCCR2_Candi_LF_);

  DetermineSteerDirection(aes_candidate.AESCCR1_Candi_, aes_candidate.AESCCR1_Candi_LF_, aes_candidate.AESCCR2_Candi_LF_, host_left, host_right, left_edge, right_edge, host_lane_lpp);

  DetermineSteerDirection(aes_candidate.AESCCR2_Candi_, aes_candidate.AESCCR1_Candi_LF_, aes_candidate.AESCCR2_Candi_LF_, host_left, host_right, left_edge, right_edge, host_lane_lpp);

  DecideCCRAction(aes_candidate.AESCCR1_Candi_,aes_candidate.AESCCR1_Candi_LF_,aes_candidate.AESCCR2_Candi_LF_, FusionCCRFlag_LF, FusionVRUFlag_LF);

  DecideCCRAction(aes_candidate.AESCCR2_Candi_,aes_candidate.AESCCR1_Candi_LF_,aes_candidate.AESCCR2_Candi_LF_, FusionCCRFlag_LF, FusionVRUFlag_LF);

  // clearCCRCandidate_LF();
}

void extract_aesccr::DetermineOncomLane() {
  oncom_lane_pos = 0;

  if ((ego_->ehy_tsi.tsi_obj[18].id > 0 && ego_->ehy_tsi.tsi_obj[18].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[18].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[18].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[18].type == nio::ad::kOBJTYPE_SUV)) || (ego_->ehy_tsi.tsi_obj[19].id > 0 && ego_->ehy_tsi.tsi_obj[19].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[19].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[19].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[19].type == nio::ad::kOBJTYPE_SUV))) {
    oncom_lane_pos = oncom_lane_pos + 0x01;
  }

  if ((ego_->ehy_tsi.tsi_obj[20].id > 0 && ego_->ehy_tsi.tsi_obj[20].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[20].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[20].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[20].type == nio::ad::kOBJTYPE_SUV)) || (ego_->ehy_tsi.tsi_obj[21].id > 0 && ego_->ehy_tsi.tsi_obj[21].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[21].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[21].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[21].type == nio::ad::kOBJTYPE_SUV))) {
    oncom_lane_pos = oncom_lane_pos + 0x02;
  }

  if ((ego_->ehy_tsi.tsi_obj[16].id > 0 && ego_->ehy_tsi.tsi_obj[16].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[16].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[16].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[16].type == nio::ad::kOBJTYPE_SUV)) || (ego_->ehy_tsi.tsi_obj[17].id > 0 && ego_->ehy_tsi.tsi_obj[17].valid == nio::ad::kMature && (ego_->ehy_tsi.tsi_obj[17].type == nio::ad::kOBJTYPE_VEHICLE || ego_->ehy_tsi.tsi_obj[17].type == nio::ad::kOBJTYPE_TRUCK || ego_->ehy_tsi.tsi_obj[17].type == nio::ad::kOBJTYPE_SUV))) {
    oncom_lane_pos = oncom_lane_pos + 0x04;
  }
}

void extract_aesccr::DetermineSteerDirection(AESObjectCCR &ccr_candi, AESObjectCCR &ccr_candi_lf1, AESObjectCCR &ccr_candi_lf2, Line_Poli host_left, Line_Poli host_right, Line_Poli left_edge, Line_Poli right_edge, Lpp_Poli host_lpp) {
  float target_width = 2.4;
  ccr_candi.steer_direction = 0;

  ccr_candi.left_turn_valid = 1;
  ccr_candi.right_turn_valid = 1;

  if (ccr_candi.obj.width() < 1 || ccr_candi.obj.width() > 4) {
    target_width = 2.4;
  }
  else {
    target_width = ccr_candi.obj.width();
  }

  if (ccr_candi.u8_ID > 0) {
    if (ccr_candi_lf1.steer_flag > 0 && ccr_candi_lf1.u8_ID == ccr_candi.u8_ID) {
      ccr_candi.steer_direction = ccr_candi_lf1.steer_direction;
    }
    else if (ccr_candi_lf2.steer_flag > 0 && ccr_candi_lf2.u8_ID == ccr_candi.u8_ID) {
      ccr_candi.steer_direction = ccr_candi_lf2.steer_direction;
    }
    else {
      bool left_turn_valid = 1;
      bool right_turn_valid = 1;

      uint8_t left_lane_valid = (host_left.isvalid == 1)?1:0;
      uint8_t right_lane_valid = (host_right.isvalid == 1)?1:0;
      uint8_t valid_lane_num = left_lane_valid + right_lane_valid;

      if (valid_lane_num == 2) {
        DecideDirectionValid(ccr_candi, host_left, host_right, target_width, left_turn_valid, right_turn_valid);
      }
      else if (valid_lane_num == 1) {
        if (host_left.isvalid == 1) {
          if (right_edge.isvalid == 1) {
            DecideDirectionValid(ccr_candi, host_left, right_edge, target_width, left_turn_valid, right_turn_valid);
          }
          else {
            Line_Poli virtual_line;
            virtual_line = host_left;
            virtual_line.path_c0 = host_left.path_c0 + 3.8;
            virtual_line.path_type = nio::ad::LDType_Unknown;
            virtual_line.character = 3;
            DecideDirectionValid(ccr_candi, host_left, virtual_line, target_width, left_turn_valid, right_turn_valid);
          }
        }
        else if (host_right.isvalid == 1) {
          if (left_edge.isvalid == 1) {
            DecideDirectionValid(ccr_candi, left_edge, host_right, target_width, left_turn_valid, right_turn_valid);
          }
          else {
            Line_Poli virtual_line;
            virtual_line = host_right;
            virtual_line.path_c0 = host_right.path_c0 - 3.8;
            virtual_line.path_type = nio::ad::LDType_Unknown;
            virtual_line.character = 3;
            DecideDirectionValid(ccr_candi, virtual_line, host_right, target_width, left_turn_valid, right_turn_valid);
          }
        }
      }
      else {
        if (left_edge.isvalid == 1 && right_edge.isvalid == 1) {
          DecideDirectionValid(ccr_candi, left_edge, right_edge, target_width, left_turn_valid, right_turn_valid);
        }
        else if (right_edge.isvalid == 1 && fabsf(right_edge.path_c0) < 3.5) {
          Line_Poli virtual_line;
          virtual_line = right_edge;
          virtual_line.path_c0 = right_edge.path_c0 - 3.8;
          virtual_line.path_type = nio::ad::LDType_Unknown;
          virtual_line.character = 3;
          DecideDirectionValid(ccr_candi, virtual_line, right_edge, target_width, left_turn_valid, right_turn_valid);
        }
        else if (left_edge.isvalid == 1 && fabsf(left_edge.path_c0) < 3.5) {
          Line_Poli virtual_line;
          virtual_line = left_edge;
          virtual_line.path_c0 = left_edge.path_c0 + 3.8;
          virtual_line.path_type = nio::ad::LDType_Unknown;
          virtual_line.character = 3;
          DecideDirectionValid(ccr_candi, left_edge, virtual_line, target_width, left_turn_valid, right_turn_valid);
        }
        else {
          left_turn_valid = 0;
          right_turn_valid = 0;
        }
      }

      ccr_candi.left_turn_valid = left_turn_valid;
      ccr_candi.right_turn_valid =  right_turn_valid;

      if ((left_turn_valid == 1 && right_turn_valid == 1) || (left_turn_valid == 0 && right_turn_valid == 0)) {
        if (ccr_candi.f4_latest >= 0) {
          ccr_candi.steer_direction = -1;
        }
        else {
          ccr_candi.steer_direction = 1;
        }
      }
      else if (left_turn_valid == 1 && right_turn_valid == 0) {
        ccr_candi.steer_direction = -1;
      }
      else if (left_turn_valid == 0 && right_turn_valid == 1) {
        ccr_candi.steer_direction = 1;
      }
    }
  }
  else {
    ccr_candi.left_turn_valid = 0;
    ccr_candi.right_turn_valid = 0;
  } 
}

void extract_aesccr::DecideDirectionValid(AESObjectCCR ccr_candi, Line_Poli host_left, Line_Poli host_right, float target_width, bool &left_valid, bool &right_valid) {
    float lane_width = fabsf(host_left.path_c0 - host_right.path_c0);
    if (lane_width <= 2) {
      left_valid = 0;
      right_valid = 0;
    }
    else {
      float target_longpos = ccr_candi.obj.motion.GetX();
      bool bsd_left_warn = (ego_->side_feature_input.bsd_left_warn == 1) ?1:0;
      bool bsd_right_warn = (ego_->side_feature_input.bsd_right_warn == 1) ?1:0;

      float left_lane_to_tar = ccr_candi.obj.motion.GetY() - (host_left.path_c0 + host_left.path_c1 * target_longpos + host_left.path_c2 * target_longpos * target_longpos);
      float right_lane_to_tar = (host_right.path_c0 + host_right.path_c1 * target_longpos + host_right.path_c2 * target_longpos * target_longpos) - ccr_candi.obj.motion.GetY();

      if (ccr_candi.u1_oncoming == 0 || (ccr_candi.u1_oncoming == 1 && left_lane_to_tar > 1.5)) {
        left_valid = ((fabsf(left_lane_to_tar) >= (1.8 + target_width * 0.5)) || (fabsf(left_lane_to_tar) >= (1.5 + target_width * 0.5) && (host_left.path_type == nio::ad::LDType_Dash || host_left.path_type == nio::ad::LDType_Dash_Solid) && bsd_left_warn == 0 && ((oncom_lane_pos & 0x05) == 0)))?1:0;
        right_valid = ((fabsf(right_lane_to_tar) >= (1.8 + target_width * 0.5)) || (fabsf(right_lane_to_tar) >= (1.5 + target_width * 0.5) && (host_right.path_type == nio::ad::LDType_Dash || host_right.path_type == nio::ad::LDType_Dash_Solid) && bsd_right_warn == 0 && ((oncom_lane_pos & 0x06) == 0)))?1:0;
      }
      else if (ccr_candi.u1_oncoming == 1 && left_lane_to_tar <= 1.5){
        if (left_lane_to_tar <= (target_width * 0.5) && (host_left.character == 2 || (host_left.character == 1 && host_left.path_type != LDType_Dash && host_left.path_type != LDType_Dash_Solid) || host_left.character == 3)) {
          left_valid = 0;
        }

        if (!((fabsf(left_lane_to_tar) >= (1.8 + target_width * 0.5)) || (fabsf(left_lane_to_tar) >= (1.5 + target_width * 0.5) && (host_left.path_type == nio::ad::LDType_Dash || host_left.path_type == nio::ad::LDType_Dash_Solid) && bsd_left_warn == 0 && ((oncom_lane_pos & 0x05) == 0)))) {
          left_valid = 0;
        }

        if (!((fabsf(right_lane_to_tar) >= (1.8 + target_width * 0.5)) || (fabsf(right_lane_to_tar) >= (1.5 + target_width * 0.5) && (host_right.path_type == nio::ad::LDType_Dash || host_right.path_type == nio::ad::LDType_Dash_Solid) && bsd_right_warn == 0 && ((oncom_lane_pos & 0x06) == 0)))) {
          right_valid = 0;
        }
      }
    }
}

void extract_aesccr::UpdateLppInfo() {
  host_lane_lpp.isvalid = (ego_->ehy_lpp.trajectory.pt_conf >= 0.3) ? 1: 0;
  host_lane_lpp.path_c0 = ego_->ehy_lpp.trajectory.c0;
  host_lane_lpp.path_c1 = ego_->ehy_lpp.trajectory.c1;
  host_lane_lpp.path_c2 = ego_->ehy_lpp.trajectory.c2;
  host_lane_lpp.path_c3 = ego_->ehy_lpp.trajectory.c3;
  host_lane_lpp.width = ego_->ehy_lpp.trajectory.lm_width;
}

void extract_aesccr::UpdateLineInfo() {
  for (int i = 0; i < 8; i++) {
    if (ego_->vision_road.lane.lines[i].role == 1) {
      if (ego_->vision_road.lane.lines[i].confidence >= 0.6) {
        host_left.isvalid = 1;
        host_left.path_c0 = ego_->vision_road.lane.lines[i].first_line.line.c0;
        host_left.path_c1 = ego_->vision_road.lane.lines[i].first_line.line.c1;
        host_left.path_c2 = ego_->vision_road.lane.lines[i].first_line.line.c2;
        host_left.path_c3 = ego_->vision_road.lane.lines[i].first_line.line.c3;
        host_left.path_type = ego_->vision_road.lane.lines[i].first_line.type;
        host_left.path_color = ego_->vision_road.lane.lines[i].first_line.color;
        host_left.character = 1;
      }
      else {
        host_left.isvalid = 0;
        host_left.path_c0 = 100;
        host_left.path_c1 = 0;
        host_left.path_c2 = 0;
        host_left.path_c3 = 0;
        host_left.path_type = nio::ad::LDType_Unknown;
        host_left.path_color = nio::ad::LDColor_Unknown;
        host_left.character = 0;
      }
    }
    else if (ego_->vision_road.lane.lines[i].role == 2) {
      if (ego_->vision_road.lane.lines[i].confidence >= 0.6) {
        host_right.isvalid = 1;
        host_right.path_c0 = ego_->vision_road.lane.lines[i].first_line.line.c0;
        host_right.path_c1 = ego_->vision_road.lane.lines[i].first_line.line.c1;
        host_right.path_c2 = ego_->vision_road.lane.lines[i].first_line.line.c2;
        host_right.path_c3 = ego_->vision_road.lane.lines[i].first_line.line.c3;
        host_right.path_type = ego_->vision_road.lane.lines[i].first_line.type;
        host_right.path_color = ego_->vision_road.lane.lines[i].first_line.color;
        host_right.character = 1;
      }
      else {
        host_right.isvalid = 0;
        host_right.path_c0 = 100;
        host_right.path_c1 = 0;
        host_right.path_c2 = 0;
        host_right.path_c3 = 0;
        host_right.path_type = nio::ad::LDType_Unknown;
        host_right.path_color = nio::ad::LDColor_Unknown;
        host_right.character = 0;
      }
    }
  }
  for (int i = 0; i < 2; i++) {
    if (ego_->vision_road.road_edge[i].side != nio::ad::RoadEdgeSide_Unkown) {
      if (ego_->vision_road.road_edge[i].side == nio::ad::RoadEdgeSide_Left) {
        left_edge.isvalid = 1;
        left_edge.path_c0 = ego_->vision_road.road_edge[i].line.c0;
        left_edge.path_c1 = ego_->vision_road.road_edge[i].line.c1;
        left_edge.path_c2 = ego_->vision_road.road_edge[i].line.c2;
        left_edge.path_c3 = ego_->vision_road.road_edge[i].line.c3;
        left_edge.path_type = nio::ad::LDType_Unknown;
        left_edge.path_color = nio::ad::LDColor_Unknown;
        left_edge.character = 2;
      }
      else if (ego_->vision_road.road_edge[i].side == nio::ad::RoadEdgeSide_Right) {
        right_edge.isvalid = 1;
        right_edge.path_c0 = ego_->vision_road.road_edge[i].line.c0;
        right_edge.path_c1 = ego_->vision_road.road_edge[i].line.c1;
        right_edge.path_c2 = ego_->vision_road.road_edge[i].line.c2;
        right_edge.path_c3 = ego_->vision_road.road_edge[i].line.c3;
        right_edge.path_type = nio::ad::LDType_Unknown;
        right_edge.path_color = nio::ad::LDColor_Unknown; 
        right_edge.character = 2;
      }
    }
    else {
      left_edge.isvalid = 0;
      left_edge.path_c0 = 100;
      left_edge.path_c1 = 0;
      left_edge.path_c2 = 0;
      left_edge.path_c3 = 0;
      left_edge.path_type = nio::ad::LDType_Unknown;
      left_edge.path_color = nio::ad::LDColor_Unknown;
      left_edge.character = 0;
      right_edge.isvalid = 0;
      right_edge.path_c0 = 100;
      right_edge.path_c1 = 0;
      right_edge.path_c2 = 0;
      right_edge.path_c3 = 0;
      right_edge.path_type = nio::ad::LDType_Unknown;
      right_edge.path_color = nio::ad::LDColor_Unknown; 
      right_edge.character = 0;
    }
  }
}

float extract_aesccr::ROC(float vehspd, float yrate) {
  if (fabsf(vehspd) >= RocVehSpdThres) {
    if (vehspd / yrate >= MaxEgoRoc || yrate == 0.0f) {
      return MaxEgoRoc;
    } else if (vehspd / yrate <= -MaxEgoRoc) {
      return -MaxEgoRoc;
    } else {
      return vehspd / yrate;
    }
  }
  else {
    return MaxEgoRoc;
  }
}

float extract_aesccr::deltay(float ROC, float Distance, float egospd) {
  /*float predict_c2;
  if (fabsf(egospd) <= 1.0f) {
    predict_c2 = 0;
  } else {
    predict_c2 = c2;
  }

  return powf(Distance, 2) * predict_c2;*/
  if (powf(Distance, 2) / (ROC * 2)>= DefaultDeltaAy || (ROC <= RocThres && ROC >= 0.0F)) {
    return DefaultDeltaAy;
  } else if (powf(Distance, 2) / (ROC * 2) <= -DefaultDeltaAy ||
             (ROC >= -RocThres && ROC < 0.0F)) {
    return -DefaultDeltaAy;
  } else {
    return powf(Distance, 2) / (ROC * 2);
  }
}

float extract_aesccr::CalCCRTTC(float rrate, float relatacc, float range) {
  float TTC_final;
  if (fabsf(relatacc) < 0.1f) {
    if (rrate >= 0.0f) {
      TTC_final = MaxTTC;
    } else {
      TTC_final = -(range / rrate);
    }
  } else {
    if (rrate * rrate + 2 * relatacc * range < 0.0f) {
      TTC_final = MaxTTC;
    } else {
      TTC_final =
          (rrate + sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;
    }
  }
  if (TTC_final < 0) {
    return MaxTTC;
  } else if (TTC_final >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_final;
  }
}

float extract_aesccr::CalCCRTTC_1(float vego, float vtar,float aego, float atar, float range, bool isoncoming) {
  float TTC_raw = 25.0;
  float TTC_final = 25.0;
  float rrate = vtar - vego;
  float relatacc = aego - atar;
  bool ttc_solvable = true;
  if (fabsf(relatacc) < 0.1f) {
    if (rrate >= 0.0f) {
      TTC_raw = 25.0f;
      ttc_solvable = true;
    }
    else {
      TTC_raw = range / (vego - vtar);
      ttc_solvable = true;
    }
  }
  else {
    if (rrate * rrate + 2 * relatacc * range < 0.0f) {
      TTC_raw = 25.0f;
      ttc_solvable = false;
    }
    else if (rrate * rrate + 2 * relatacc * range == 0.0f) {
      TTC_raw = rrate / relatacc;
      ttc_solvable = true;
    }
    else {
      float tt1 = 25;
      //float tt2 = 25;
      
      tt1 = (rrate + sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;
      //tt2 = (rrate - sqrtf(rrate * rrate + 2 * relatacc * range)) / relatacc;

      TTC_raw = tt1;
      ttc_solvable = true;
    }
  }

  if (TTC_raw < 0 || (((vtar + atar * TTC_raw) < -1.2) && isoncoming == 0) || (((vtar + atar * TTC_raw) > 1.2) && isoncoming == 1) || ttc_solvable == false) {
    if (isoncoming == 0) {
      if (fabsf(aego) <= 0.2) {
        TTC_final = (range + fabsf((vtar * vtar)/(2 * atar)))/vego;
      }
      else {
        if ((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar)))) == 0) {
          TTC_final = (vego/aego) * (-1);
        }
        else if ((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar)))) > 0) {
          float tt1 = 25;
          //float tt2 = 25;

          tt1 = (vego * (-1) + sqrtf((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar))))))/aego;
          //tt2 = (vego * (-1) - sqrtf((vego * vego + 2 * aego *(range + fabsf((vtar * vtar)/(2 * atar))))))/aego;

          TTC_final = tt1;
        }
        else {
          TTC_final = 25;
        }
      }
    }
    else {
      if (fabsf(aego) <= 0.2) {
        TTC_final = (range - fabsf((vtar * vtar)/(2 * atar)))/vego;
      }
      else {
        if ((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar)))) == 0) {
          TTC_final = (vego/aego) * (-1);
        }
        else if ((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar)))) > 0) {
          float tt1 = 25;
          //float tt2 = 25;
          
          tt1 = (vego * (-1) + sqrtf((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar))))))/aego;
          //tt2 = (vego * (-1) - sqrtf((vego * vego + 2 * aego *(range - fabsf((vtar * vtar)/(2 * atar))))))/aego;

          TTC_final = tt1;
        }
        else {
          TTC_final = 25;
        }
      }
    }
  }
  else {
    TTC_final = TTC_raw;
  }

  if (TTC_final < 0 || TTC_final >= 25) {
    return 25;
  }
  else {
    return TTC_final;
  }
}
void extract_aesccr::CalcCurCornerPoint (float roc, AESObjectCCR &tmpobj) {
  float cl_deltay = 0;
  float cr_deltay = 0;
  float rl_deltay = 0;
  float rr_deltay = 0;
  float egospd = 0;
  egospd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

  cl_deltay = deltay(roc, tmpobj.close_left.range, egospd);
  cr_deltay = deltay(roc, tmpobj.close_right.range, egospd);
  rl_deltay = deltay(roc, tmpobj.remote_left.range, egospd);
  rr_deltay = deltay(roc, tmpobj.remote_right.range, egospd);

  tmpobj.close_left.cur_y = tmpobj.close_left.pos_y - cl_deltay;
  tmpobj.close_right.cur_y = tmpobj.close_right.pos_y - cr_deltay;
  tmpobj.remote_left.cur_y = tmpobj.remote_left.pos_y - rl_deltay;
  tmpobj.remote_right.cur_y = tmpobj.remote_right.pos_y - rr_deltay;
}

void extract_aesccr::CalcCornerPointEsti (AESObjectCCR &tmpobj) {
  CalcLatEsti(tmpobj.close_left, tmpobj.obj.motion.GetVy(), tmpobj.f4_TTC);
  CalcLatEsti(tmpobj.close_right, tmpobj.obj.motion.GetVy(), tmpobj.f4_TTC);
  CalcLatEsti(tmpobj.remote_left, tmpobj.obj.motion.GetVy(), tmpobj.f4_TTC);
  CalcLatEsti(tmpobj.remote_right, tmpobj.obj.motion.GetVy(), tmpobj.f4_TTC);
}

void extract_aesccr::CalcLatEsti (CornerPos &cornerpoint, float latspd, float ttc) {
  cornerpoint.lat_est = cornerpoint.cur_y + latspd * ttc;
}

void extract_aesccr::CalcCornerPoint (AESObjectCCR &tmpobj) {
  float heading = 0;
  float length = tmpobj.obj.length();
  float width = tmpobj.obj.width();
  float centerx = tmpobj.center_point.pos_x;
  float centery = tmpobj.center_point.pos_y;
  float bumptorearaxle = 3.9;

  if (tmpobj.obj.motion.GetHead() >= -Pi/2 && tmpobj.obj.motion.GetHead() <= Pi/2) {
    heading = tmpobj.obj.motion.GetHead();
  }
  else if (tmpobj.obj.motion.GetHead() < -Pi/2 && tmpobj.obj.motion.GetHead() >= -Pi) {
    heading = Pi + tmpobj.obj.motion.GetHead();
  }
  else {
    heading = tmpobj.obj.motion.GetHead() - Pi;
  }

  tmpobj.close_left.pos_x = centerx - (length * cosf(heading))/2 + (width * sinf(heading))/2 - bumptorearaxle;
  tmpobj.close_left.pos_y = centery - (length * sinf(heading))/2 - (width * cosf(heading))/2;
  tmpobj.close_left.range = sqrtf(tmpobj.close_left.pos_x * tmpobj.close_left.pos_x + tmpobj.close_left.pos_y * tmpobj.close_left.pos_y);
  tmpobj.close_left.cur_x = tmpobj.close_left.pos_x;

  tmpobj.close_right.pos_x = centerx - (length * cosf(heading))/2 - (width * sinf(heading))/2 - bumptorearaxle;
  tmpobj.close_right.pos_y = centery - (length * sinf(heading))/2 + (width * cosf(heading))/2;
  tmpobj.close_right.range = sqrtf(tmpobj.close_right.pos_x * tmpobj.close_right.pos_x + tmpobj.close_right.pos_y * tmpobj.close_right.pos_y);
  tmpobj.close_right.cur_x = tmpobj.close_right.pos_x;

  tmpobj.remote_left.pos_x = centerx + (length * cosf(heading))/2 + (width * sinf(heading))/2 - bumptorearaxle;
  tmpobj.remote_left.pos_y = centery + (length * sinf(heading))/2 - (width * cosf(heading))/2;
  tmpobj.remote_left.range = sqrtf(tmpobj.remote_left.pos_x * tmpobj.remote_left.pos_x + tmpobj.remote_left.pos_y * tmpobj.remote_left.pos_y);
  tmpobj.remote_left.cur_x = tmpobj.remote_left.pos_x;

  tmpobj.remote_right.pos_x = centerx + (length * cosf(heading))/2 - (width * sinf(heading))/2 - bumptorearaxle;
  tmpobj.remote_right.pos_y = centery + (length * sinf(heading))/2 + (width * cosf(heading))/2;
  tmpobj.remote_right.range = sqrtf(tmpobj.remote_right.pos_x * tmpobj.remote_right.pos_x + tmpobj.remote_right.pos_y * tmpobj.remote_right.pos_y);
  tmpobj.remote_right.cur_x = tmpobj.remote_right.pos_x;
}

void extract_aesccr::CalcCenterPoint (AESObjectCCR &tmpobj) {
  tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX();
  tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY();
}

void extract_aesccr::CalcInPathPre (AESObjectCCR &tmpobj) {
  float inpath_predict = 0;
  float closest_latest = 0;
  float cl_sign = 0;
  float cr_sign = 0;
  float rl_sign = 0;
  float rr_sign = 0;
  bool cornersigndiff = false;

  inpath_predict = threshold_aes_inpath_predict_.interpolate(tmpobj.f4_range, tmpobj.f4_rangerate);

  if (tmpobj.close_left.lat_est >= 0) {
    cl_sign = 1;
  }
  else {
    cl_sign = -1;
  }

  if (tmpobj.close_right.lat_est >= 0) {
    cr_sign = 1;
  }
  else {
    cr_sign = -1;
  }

  if (tmpobj.remote_left.lat_est >= 0) {
    rl_sign = 1;
  }
  else {
    rl_sign = -1;
  }

  if (tmpobj.remote_right.lat_est >= 0) {
    rr_sign = 1;
  }
  else {
    rr_sign = -1;
  }

  if (fabsf(cl_sign + cr_sign + rl_sign + rr_sign) < 4) {
    cornersigndiff = true;
    tmpobj.u1_Inpath_Pre = true;
    tmpobj.u8_closest_corner_estimate = 5;
  }
  else {
    cornersigndiff = false;

    if (fabsf(tmpobj.close_left.lat_est) <= fabsf(tmpobj.close_right.lat_est) && fabsf(tmpobj.close_left.lat_est) <= fabsf(tmpobj.remote_left.lat_est) && fabsf(tmpobj.close_left.lat_est) <= fabsf(tmpobj.remote_right.lat_est)) {
      tmpobj.u8_closest_corner_estimate = 1;
      closest_latest = tmpobj.close_left.lat_est;
    }
    else if (fabsf(tmpobj.close_right.lat_est) < fabsf(tmpobj.close_left.lat_est) && fabsf(tmpobj.close_right.lat_est) <= fabsf(tmpobj.remote_left.lat_est) && fabsf(tmpobj.close_right.lat_est) <= fabsf(tmpobj.remote_right.lat_est)) {
      tmpobj.u8_closest_corner_estimate = 2;
      closest_latest = tmpobj.close_right.lat_est;
    }
    else if (fabsf(tmpobj.remote_left.lat_est) < fabsf(tmpobj.close_left.lat_est) && fabsf(tmpobj.remote_left.lat_est) < fabsf(tmpobj.close_right.lat_est) && fabsf(tmpobj.remote_left.lat_est) <= fabsf(tmpobj.remote_right.lat_est)) {
      tmpobj.u8_closest_corner_estimate = 3;
      closest_latest = tmpobj.remote_left.lat_est;
    }
    else {
      tmpobj.u8_closest_corner_estimate = 4;
      closest_latest = tmpobj.remote_right.lat_est;
    }

    if (fabsf(closest_latest) <= inpath_predict) {
      tmpobj.u1_Inpath_Pre = true;
    }
    else {
      tmpobj.u1_Inpath_Pre = false;
    }
  }  
}

void extract_aesccr::CalcInPathCur (AESObjectCCR &tmpobj) {
  float cl_sign = 0;
  float cr_sign = 0;
  float rl_sign = 0;
  float rr_sign = 0;
  float closest_y = 0;
  float inpath_current = 0;

  inpath_current = threshold_aes_inpath_current_.interpolate(tmpobj.f4_range, tmpobj.f4_rangerate);

  bool cornersigndiff = false;

  if (tmpobj.close_left.cur_y >= 0) {
    cl_sign = 1;
  }
  else {
    cl_sign = -1;
  }

  if (tmpobj.close_right.cur_y >= 0) {
    cr_sign = 1;
  }
  else {
    cr_sign = -1;
  }

  if (tmpobj.remote_left.cur_y >= 0) {
    rl_sign = 1;
  }
  else {
    rl_sign = -1;
  }

  if (tmpobj.remote_right.cur_y >= 0) {
    rr_sign = 1;
  }
  else {
    rr_sign = -1;
  }

  if (fabsf(cl_sign + cr_sign + rl_sign + rr_sign) < 4) {
    cornersigndiff = true;
    tmpobj.u1_Inpath_Cur = true;
    tmpobj.u8_closest_corner = 5;
  }
  else {
    cornersigndiff = false;
    
    if (fabsf(tmpobj.close_left.cur_y) <= fabsf(tmpobj.close_right.cur_y) && fabsf(tmpobj.close_left.cur_y) <= fabsf(tmpobj.remote_left.cur_y) && fabsf(tmpobj.close_left.cur_y) <= fabsf(tmpobj.remote_right.cur_y)) {
      tmpobj.u8_closest_corner = 1;
      closest_y = tmpobj.close_left.cur_y;
    }
    else if (fabsf(tmpobj.close_right.cur_y) < fabsf(tmpobj.close_left.cur_y) && fabsf(tmpobj.close_right.cur_y) <= fabsf(tmpobj.remote_left.cur_y) && fabsf(tmpobj.close_right.cur_y) <= fabsf(tmpobj.remote_right.cur_y)) {
      tmpobj.u8_closest_corner = 2;
      closest_y = tmpobj.close_right.cur_y;
    }
    else if (fabsf(tmpobj.remote_left.cur_y) < fabsf(tmpobj.close_left.cur_y) && fabsf(tmpobj.remote_left.cur_y) < fabsf(tmpobj.close_right.cur_y) && fabsf(tmpobj.remote_left.cur_y) <= fabsf(tmpobj.remote_right.cur_y)) {
      tmpobj.u8_closest_corner = 3;
      closest_y = tmpobj.remote_left.cur_y;
    }
    else {
      tmpobj.u8_closest_corner = 4;
      closest_y = tmpobj.remote_right.cur_y;
    }

    if (fabsf(closest_y) <= inpath_current) {
      tmpobj.u1_Inpath_Cur = true;
    }
    else {
      tmpobj.u1_Inpath_Cur = false;
    }
  }
}

void extract_aesccr::CalCCRTTT_Left (AESObjectCCR &ccr_tar) {
  float XOLCPercent_;
  XOLCPercent_ = ((2 * fabsf(ccr_tar.f4_XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  float roc_ttt = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float vtar = ccr_tar.obj.motion.GetVx();
  float aego = ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81;
  float atar = ccr_tar.obj.motion.GetAx();
  float range = ccr_tar.f4_range;
  float latest_sign = 1;
  float delta_y = 0;
  float delta_x = 0;
  float delta_r = 0;
  float target_width = 2.4;
  float lateral_safe = threshold_ccr_ttt_latsafe_.interpolate(XOLCPercent_);
  ccr_tar.steer_direction = 0;

  roc_ttt = ((vego * vego)/4);

  if (ccr_tar.obj.width() < 1 || ccr_tar.obj.width() > 4) {
    target_width = 2.4;
  }
  else {
    target_width = ccr_tar.obj.width();
  }
  // calculate TTT_left
  delta_y = ((1.1 + (target_width/2) + lateral_safe) * (-1)) + ccr_tar.f4_XOLC;

  if (fabsf(delta_y) <= roc_ttt) {
    delta_x = sqrtf((roc_ttt * roc_ttt) - ((roc_ttt - fabsf(delta_y)) * (roc_ttt - fabsf(delta_y))));

    delta_r = acosf((roc_ttt- fabsf(delta_y))/roc_ttt) * roc_ttt;

    ccr_tar.TTT_left.tt = delta_r/(vego - vtar);

    ccr_tar.TTT_left.isvalid = true;

    ccr_tar.position_esti.latpos = delta_y;

    ccr_tar.position_esti.longpos = (range * vego)/(vego -vtar);
  }
  else {
    ccr_tar.TTT_left.tt = 0;
    ccr_tar.TTT_left.isvalid = false;
    ccr_tar.position_esti.latpos = 0;
    ccr_tar.position_esti.longpos = 0;
  }

  if (ccr_tar.TTT_left.isvalid == true) {
    if (ccr_tar.TTT_left.tt < 0) {
      ccr_tar.TTT_left.tt = 0;
    }
    else if (ccr_tar.TTT_left.tt > 30){
      ccr_tar.TTT_left.tt = 30;
    }
  }   
}

void extract_aesccr::CalCCRTTT_Right (AESObjectCCR &ccr_tar) {
  float XOLCPercent_;
  XOLCPercent_ = ((2 * fabsf(ccr_tar.f4_XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  float roc_ttt = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float vtar = ccr_tar.obj.motion.GetVx();
  float aego = ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81;
  float atar = ccr_tar.obj.motion.GetAx();
  float range = ccr_tar.f4_range;
  float latest_sign = 1;
  float delta_y = 0;
  float delta_x = 0;
  float delta_r = 0;
  float target_width = 2.4;
  float lateral_safe = threshold_ccr_ttt_latsafe_.interpolate(XOLCPercent_);
  ccr_tar.steer_direction = 0;

  roc_ttt = ((vego * vego)/4);

  if (ccr_tar.obj.width() < 1 || ccr_tar.obj.width() > 4) {
    target_width = 2.4;
  }
  else {
    target_width = ccr_tar.obj.width();
  }
  // calculate TTT_right
  delta_y = ((1.1 + (target_width/2) + lateral_safe)) + ccr_tar.f4_XOLC;

  if (fabsf(delta_y) <= roc_ttt) {
    delta_x = sqrtf((roc_ttt * roc_ttt) - ((roc_ttt - fabsf(delta_y)) * (roc_ttt - fabsf(delta_y))));

    delta_r = acosf((roc_ttt- fabsf(delta_y))/roc_ttt) * roc_ttt;

    ccr_tar.TTT_right.tt = delta_r/(vego - vtar);

    ccr_tar.TTT_right.isvalid = true;

    ccr_tar.position_esti.latpos = delta_y;

    ccr_tar.position_esti.longpos = (range * vego)/(vego -vtar);
  }
  else {
    ccr_tar.TTT_right.tt = 0;
    ccr_tar.TTT_right.isvalid = false;
    ccr_tar.position_esti.latpos = 0;
    ccr_tar.position_esti.longpos = 0;
  }

  if (ccr_tar.TTT_right.isvalid == true) {
    if (ccr_tar.TTT_right.tt < 0) {
      ccr_tar.TTT_right.tt = 0;
    }
    else if (ccr_tar.TTT_right.tt > 30){
      ccr_tar.TTT_right.tt = 30;
    }
  }   
}

void extract_aesccr::CalCCRTTB (AESObjectCCR &ccr_tar) {
  calc_tt ttb_bef;
  float ttb_saferange = 0;
  float ttb_a = 0;
  float ttb_b = 0;
  float ttb_c = 0;
  float ttb_c_new = 0;
  float vego = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

  ttb_saferange = threshold_ccr_ttb_longsafe_.interpolate (vego);

  float vtar = ccr_tar.obj.motion.GetVx();
  float aego = ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.81;
  float atar = ccr_tar.obj.motion.GetAx();
  float range = 0;
  if (ccr_tar.f4_range >= ttb_saferange) {
    range = ccr_tar.f4_range - ttb_saferange;
  }
  else {
    range = ccr_tar.f4_range;
  }

  if (fabsf(aego) <= 0.1 && fabsf(atar) <= 0.1) {
    ccr_tar.TTB.tt = (vego - vtar)/8;
    ccr_tar.TTB.isvalid = true;
  }
  else if (ccr_tar.obj.motion_status.IsOncoming() == false){
    if((vtar + atar * ccr_tar.f4_TTC) > -1.2) {
      ttb_a = (aego * 0.5) + (aego *(aego - atar)/(8 + atar)) - ((4 * (aego - atar) * (aego - atar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (aego + 8) * (aego + 8)) / ((8 + atar) * (8 + atar)));

      ttb_b = (((vego - vtar) * (aego + 8))/(8 + atar)) + ((aego * (vego -vtar))/(8 + atar)) - ((4 * (aego - atar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (aego + 8) * (vego - vtar))/((8 + atar) * (8 + atar)));

      ttb_c = (((vego - vtar) * (vego - vtar))/(8 + atar)) - ((4 * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - range;

      ttb_c_new = (((vego - vtar) * (vego - vtar))/(8 + atar)) - ((4 * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar))) - ((0.5 * atar * (vego -vtar) * (vego - vtar))/((8 + atar) * (8 + atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = (((aego - atar)/(8 + atar)) * ttb_bef.tt) + ((vego - vtar)/(8 + atar));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
    else {
      ttb_a = (aego/2 + (aego*aego)/16);

      ttb_b = (vego + ((3 * vego * aego)/16));

      ttb_c = (((vego * vego)/16) - fabsf((vtar * vtar)/(2 * atar)) - range);

      ttb_c_new = (((vego * vego)/16) - fabsf((vtar * vtar)/(2 * atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    } 
  }
  else {
    if ((vtar + atar * ccr_tar.f4_TTC) < 1.2) {
      ttb_a = ((aego/2) + ((aego * aego)/16) - ((((8 + aego) * (8 + aego)) * atar)/128));

      ttb_b = (vego + ((3 * vego * aego)/16) - vtar - ((vtar * aego)/8) - ((atar * vego * (8 + aego))/128));

      ttb_c = (((vego * vego)/16) - ((vego *vtar)/8) - ((atar * vego * vego)/128) - range);

      ttb_c_new = (((vego * vego)/16) - ((vego *vtar)/8) - ((atar * vego * vego)/128));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
    else {
      ttb_a = ((aego/2) + ((aego * aego)/16));

      ttb_b = (vego + ((3 * vego * aego)/16));

      ttb_c = (((vego * vego)/16) + fabsf((vtar * vtar)/(2 * atar)) - range);

      ttb_c_new = (((vego * vego)/16) + fabsf((vtar * vtar)/(2 * atar)));

      ttb_bef = aeb_calculate_tt_max(ttb_a, ttb_b, ttb_c, ttb_c_new, range);

      if (ttb_bef.isvalid == true) {
        ccr_tar.TTB.tt = ((aego/8) * ttb_bef.tt + (vego/8));
        ccr_tar.TTB.isvalid = true;
      }
      else {
        ccr_tar.TTB.tt = 30;
        ccr_tar.TTB.isvalid = false;
      }
    }
  }

  //ccr_tar.TTB_bf = ttb_bef;

  // if (ccr_tar.TTB.isvalid == true) {
  //   if (ccr_tar.TTB.tt < 0) {
  //     ccr_tar.TTB.tt = 0;
  //   }
  //   else if (ccr_tar.TTB.tt > 30){
  //     ccr_tar.TTB.tt = 30;
  //   }
  // }
}

float extract_aesccr::CalCCRTTCBased(float rrate, float range) {
  float TTC_based = MaxTTC;
  if (rrate >= 0.0f) {
    TTC_based = MaxTTC;
  } else {
    TTC_based = -(range / rrate);
  }

  if (TTC_based < 0) {
    return MaxTTC;
  } else if (TTC_based >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_based;
  }
}

// float extract_aesccr::CalCCRTTT(float vehWidth, float XOLC,
//                             float LataccMax, float ego_spd,
//                             float extendbuffer) {
//   float overlap;
//   float ROCmin;
//   overlap = (0.5 * vehWidth) + extendbuffer - fabsf(XOLC);
//   ROCmin = (ego_spd * ego_spd) / LataccMax;
//   if (fabsf(ego_spd) < 0.1f ||
//       ((0.5 * vehWidth) + extendbuffer - fabsf(XOLC)) < 0) {
//     return 25.0f;
//   } else {
//     return (sqrtf(2 * overlap * ROCmin + overlap * overlap)) / ego_spd;
//   }
// }

// float extract_aesccr::CalCCRTTB(float RangeRate, float targetAcc) {
//   float TTBprim;
//   if (fabsf(targetAcc + 7.84f) < 0.01f) {
//     TTBprim = 25.0f;
//   } else {
//     TTBprim = (RangeRate / (targetAcc + 7.84f)) * (-1.0f);
//   }

//   if (TTBprim >= 25.0f || TTBprim < 0) {
//     return 25.0f;
//   } else {
//     return TTBprim;
//   }
// }

uint8_t extract_aesccr::DecideCCR_AEBConf(bool isfusion, bool isfused,
                                      bool isvision, bool isradar,
                                      float matchconf) {
  if ((isfusion == 1 && matchconf >= MatchConfThres)) {
    return 3;
  } else if ((((isvision == 1 && isfused == 1) /*(||
               (isradar == 1 && isfused == 1)*/) &&
              matchconf >= MatchConfThres) ||
             (isfusion == 1 && matchconf >= MinConfThres && matchconf < MatchConfThres)) {
    return 2;
  } else if (((isvision == 1 || isradar == 1) && isfused == 0 &&
             matchconf >= MatchConfThres) || (isradar == 1 && isfused == 1 && matchconf >= MatchConfThres)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_aesccr::CCR_Age_check(bool isfusion, bool isradar, bool isvision,
                               size_t tracklet_count, uint8_t age) {
  //vis age turn into 20 for tempo test;
  if ((isfusion == 1 && age >= MinFusionObjAge) ||
      (isradar == 1 && tracklet_count >= 2 && age >= MinRadarObjAge) ||
      (isradar == 1 && tracklet_count == 1 && age >= MinRadarObjAge) ||
      (isvision == 1 && age >= MinVisionObjAge)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_aesccr::CCR_VF_Longpos_check(float fusionLongPos,
                                      float visionLongPos,
                                      float Rangerate, float egoacc) {
  float LongPosError;
  LongPosError =
      threshold_CCR_LongPos_VFcheck_.interpolate(fusionLongPos, Rangerate);
  if (fabsf(egoacc) >= MaxCcrVfCheckEgoAcc) {
    return 1;
  } else {
    if (fabsf(fusionLongPos - visionLongPos - (ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - ego_->vehicle_info.arb_vehicle.epm_pos_to_front_bumper)) <= LongPosError) {
      return 1;
    } else {
      return 0;
    }
  }
}

MoveState  extract_aesccr::DecideMoveState(float XOLC, float deltayawrate) {
  if ((fabsf(deltayawrate) <= DeltaYawrateThres) || XOLC == 0) {
    return nio::ad::MoveState::kNueutral ;
  } else if ((XOLC > 0) == (deltayawrate > 0)) {
    return nio::ad::MoveState::kMoving_in;
  } else if ((XOLC > 0 && deltayawrate < 0) || (XOLC < 0 && deltayawrate > 0)) {
    return nio::ad::MoveState::kMoving_out;
  }
  return nio::ad::MoveState::kNueutral;
}

bool extract_aesccr::DecideMoveOut(float XOLC, float deltayawrate) {
  float XOLCPercent_;
  XOLCPercent_ = ((2 * fabsf(XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  float deltayaw_threshold = 0.0f;
  deltayaw_threshold = threshold_movingout_deltayaw_.interpolate(XOLCPercent_);

  if ((fabsf(deltayawrate) <= deltayaw_threshold) || XOLC == 0) {
    return 0;
  } else if ((XOLC > 0) == (deltayawrate > 0)) {
    return 0;
  } else if ((XOLC > 0 && deltayawrate < 0) || (XOLC < 0 && deltayawrate > 0)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_aesccr::DecideTOI(AESObjectCCR &tmpobj) {
  bool rangecheck = 0;
  bool targetspdcheck = 0;
  float targetspd = 0;
  float leftlane_c0 = 100;
  float rightlane_c0 = 100;
  float leftlane_c2 = 100;
  float rightlane_c2 = 100;
  bool leftlanevalid = 0;
  bool rightlanevalid = 0;
  bool hostlanecheck = 0;
  
  if (((tmpobj.obj.motion_status.IsMovable() == 1 && tmpobj.f4_range <= ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * 3.0f) ||
       (tmpobj.obj.motion_status.IsMovable() == 0 && tmpobj.f4_range <= ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * 2.5f)) &&
      tmpobj.obj.motion.GetX() >= 0) {
    rangecheck = 1;
  } else {
    rangecheck = 0;
  }

  targetspd = sqrtf((tmpobj.obj.motion.GetVx() * tmpobj.obj.motion.GetVx()) + (tmpobj.obj.motion.GetVy() * tmpobj.obj.motion.GetVy()));

  if (tmpobj.u1_oncoming == 1 && targetspd <= 13.88) {
    targetspdcheck = 0;
  }
  else {
    targetspdcheck = 1;
  }

  for (size_t lane_i = 0; lane_i < 8; lane_i++) {
    if (ego_->vision_road.lane.lines[lane_i].role == nio::ad::LDRole_Host_Left && ego_->vision_road.lane.lines[lane_i].confidence >= 0.6) {
      leftlane_c0 = ego_->vision_road.lane.lines[lane_i].first_line.line.c0;
      leftlane_c2 = ego_->vision_road.lane.lines[lane_i].first_line.line.c2;
    }

    if (ego_->vision_road.lane.lines[lane_i].role == nio::ad::LDRole_Host_Right && ego_->vision_road.lane.lines[lane_i].confidence >= 0.6) {
      rightlane_c0 = ego_->vision_road.lane.lines[lane_i].first_line.line.c0;
      rightlane_c2 = ego_->vision_road.lane.lines[lane_i].first_line.line.c2;
    }
  }

  leftlanevalid = (fabsf(leftlane_c0) <= 5 && fabsf(leftlane_c2) <= 0.001)?1:0;

  rightlanevalid = (fabsf(rightlane_c0) <= 5 && fabsf(rightlane_c2) <= 0.001)?1:0;

  hostlanecheck = (leftlanevalid == 1 || rightlanevalid == 1) ?1:0;
  
  if (rangecheck == 1 && targetspdcheck == 1 && hostlanecheck == 1) {
    return 1;
  } else {
    return 0;
  }
}

uint8_t extract_aesccr::SelectAESCandi(AESObjectCCR &tmpobj) {
  if (tmpobj.u1_Inpath == 1) {
    if (tmpobj.f4_range < aes_candidate.AESCCR1_Candi_.f4_minRange || (tmpobj.f4_range == aes_candidate.AESCCR1_Candi_.f4_minRange && tmpobj.f4_TTC < aes_candidate.AESCCR1_Candi_.f4_minTTC)) {
      return 1;
    } else if ((tmpobj.f4_range > aes_candidate.AESCCR1_Candi_.f4_minRange || (tmpobj.f4_range = aes_candidate.AESCCR1_Candi_.f4_minRange && tmpobj.f4_TTC >= aes_candidate.AESCCR1_Candi_.f4_minTTC)) && (tmpobj.f4_range < aes_candidate.AESCCR2_Candi_.f4_minRange || (tmpobj.f4_range == aes_candidate.AESCCR2_Candi_.f4_minRange && tmpobj.f4_TTC < aes_candidate.AESCCR2_Candi_.f4_minTTC))) {
      return 2;
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}

void extract_aesccr::CalcCCRInPathAge(AESObjectCCR &ccr_candi, AESObjectCCR &ccr_candi_lf1, AESObjectCCR &ccr_candi_lf2) {
  if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf1.u8_ID) {
    ccr_candi.u8_Inpathage = ccr_candi_lf1.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID == ccr_candi_lf2.u8_ID) {
    ccr_candi.u8_Inpathage = ccr_candi_lf2.u8_Inpathage + 1;
  } else if (ccr_candi.u1_Inpath == 1 && ccr_candi.u8_ID != ccr_candi_lf1.u8_ID &&  ccr_candi.u8_ID != ccr_candi_lf2.u8_ID) {
    ccr_candi.u8_Inpathage = 1;
  } else {
    ccr_candi.u8_Inpathage = 0;
  }
  if (ccr_candi.u8_Inpathage >= MaxInpathAge) {
    ccr_candi.u8_Inpathage = MaxInpathAge;
  }

  uint8_t InPathAge_Threshold = MaxInpathAge;
  if (ccr_candi.obj.classification.IsVehicle() == 1) {
    InPathAge_Threshold = threshold_AES_InPathAge_.interpolate(ccr_candi.u8_AEBconf);
  }

  if (ccr_candi.u8_Inpathage >= InPathAge_Threshold) {
    ccr_candi.u1_inpathagecheck = 1;
  } else {
    ccr_candi.u1_inpathagecheck = 0;
  }
}

void extract_aesccr::DecideCCRAction (AESObjectCCR &Candi, AESObjectCCR &CS_lf1,  AESObjectCCR &CM_lf1, FusionAEBFlag CCR_flag, FusionAEBFlag VRU_flag) {
  bool lf_highbrake = 0;
  float ttt_offset = 0;
  float ttb_offset = 0;
  float egospd = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
  float rangerate = Candi.f4_rangerate;
  float XOLCPercent_;
  calc_tt activate_TTT;

  XOLCPercent_ = ((2 * fabsf(Candi.f4_XOLC)) / ego_->vehicle_info.arb_vehicle.width);
  ttb_offset = threshold_ccr_ttb_offset_.interpolate(egospd, rangerate);
  ttt_offset = threshold_ccr_ttt_offset_.interpolate(XOLCPercent_, egospd);

  if (CCR_flag.highbrake_flag == kAEBAlertActive || VRU_flag.highbrake_flag == kAEBAlertActive) {
    lf_highbrake = 1;
  }
  else {
    lf_highbrake = 0;
  }

  if (Candi.steer_direction == 1) {
    activate_TTT = Candi.TTT_right;
  }
  else if (Candi.steer_direction == -1) {
    activate_TTT = Candi.TTT_left;
  }
  else {
    activate_TTT.isvalid = false;
    activate_TTT.tt = 30;
  }

  if (lf_highbrake == 1) {
    Candi.brake_flag = 1;
    Candi.steer_flag = 0;
  }
  else {
    if (activate_TTT.isvalid == true && ((activate_TTT.tt + ttt_offset) > Candi.f4_TTC) && (Candi.f4_TTC <= 3.0) && (egospd >= 13.88) && Candi.u1_inpathagecheck == 1) {
      Candi.steer_flag = 1;
    }
    else {
      Candi.steer_flag = 0;
    }

    if (Candi.TTB.isvalid == true && ((Candi.TTB.tt + ttb_offset) > Candi.f4_TTC) && (Candi.f4_TTC <= 3.0) && Candi.u1_inpathagecheck == 1) {
      Candi.brake_flag = 1;
    }
    else {
      Candi.brake_flag = 0;
    }    

    // if (Candi.TTT.isvalid == true && Candi.TTB.isvalid == true && egospd >= 13.88) {
    //   if (((Candi.TTT.tt + ttt_offset) > Candi.f4_TTC) && (Candi.TTB.tt > Candi.TTT.tt) && (Candi.f4_TTC <= 3.0)) {
    //     Candi.brake_flag = 0;
    //     Candi.steer_flag = 1;
    //     AEBSupressReason = 1;
    //   }
    //   else if (((Candi.TTB.tt + ttb_offset) > Candi.f4_TTC) && (Candi.TTT.tt >= Candi.TTB.tt) && (Candi.f4_TTC <= 3.0)) {
    //     Candi.brake_flag = 1;
    //     Candi.steer_flag = 0;
    //     AEBSupressReason = 2;
    //   }
    //   else {
    //     Candi.brake_flag = 0;
    //     Candi.steer_flag = 0;
    //     AEBSupressReason = 3;
    //   }
    // }
    // else if ((Candi.TTB.isvalid == true && Candi.TTT.isvalid == false) || (Candi.TTT.isvalid == true && Candi.TTB.isvalid == true && egospd < 13.88)){
    //   if ((Candi.TTB.tt + ttb_offset) > Candi.f4_TTC) {
    //     Candi.brake_flag = 1;
    //     Candi.steer_flag = 0;
    //     AEBSupressReason = 4;
    //   }
    //   else {
    //     Candi.brake_flag = 1;
    //     Candi.steer_flag = 0;
    //     AEBSupressReason = 5;
    //   }
    // }
    // else {
    //   Candi.brake_flag = 0;
    //   Candi.steer_flag = 0;
    //   AEBSupressReason = 6;
    // }
  }

  if (Candi.steer_flag == 1 && (Candi.u1_inpathagecheck == 1 || (fabsf(Candi.f4_XOLC) <= 3)) && Candi.u1_vfplaucheck == 1) {
    Candi.steer_flag = 1;
  }
  else {
    Candi.steer_flag = 0;
  }
}

void extract_aesccr::clearCCRCandidate() {
aes_candidate.AESCCR1_Candi_.obj.clear();
aes_candidate.AESCCR1_Candi_.u8_ID = 0U;
aes_candidate.AESCCR1_Candi_.u8_IDX = MaxVisionIndex;
aes_candidate.AESCCR1_Candi_.u8_VID = 0u;
aes_candidate.AESCCR1_Candi_.objectvalid = 0U;
aes_candidate.AESCCR1_Candi_.f4_range = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_rangerate = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_relatAcc = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_TTC = DefaultTTC;
aes_candidate.AESCCR1_Candi_.f4_XOLC = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_vissup_dx = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_TTEmax = 0.0f;
aes_candidate.AESCCR1_Candi_.f4_TTEmin = 0.0f;
aes_candidate.AESCCR1_Candi_.u8_Inpathage = 0U;
aes_candidate.AESCCR1_Candi_.u1_Inpath_Cur = 0U;
aes_candidate.AESCCR1_Candi_.u1_Inpath_Pre = 0U;
aes_candidate.AESCCR1_Candi_.u1_Inpath = 0U;
aes_candidate.AESCCR1_Candi_.u1_TOI = 0U;
aes_candidate.AESCCR1_Candi_.u1_vfplaucheck = 0U;
aes_candidate.AESCCR1_Candi_.u1_ageplaucheck = 0U;
aes_candidate.AESCCR1_Candi_.u1_inpathagecheck = 0U;
aes_candidate.AESCCR1_Candi_.u1_oncoming = 0U;
aes_candidate.AESCCR1_Candi_.u1_preceding = 0U;
aes_candidate.AESCCR1_Candi_.u1_longmove = 0U;
aes_candidate.AESCCR1_Candi_.u1_latmove = 0U;
aes_candidate.AESCCR1_Candi_.u1_crossing = 0U;
aes_candidate.AESCCR1_Candi_.u8_AEBconf = 0U;
aes_candidate.AESCCR1_Candi_.u8_lostradarage = 0U;
aes_candidate.AESCCR1_Candi_.f4_minTTC = DefaultTTC;
aes_candidate.AESCCR1_Candi_.f4_minRange = 200.0f;
aes_candidate.AESCCR1_Candi_.warnig_flag = 0u;
aes_candidate.AESCCR1_Candi_.prefill_flag = 0u;
aes_candidate.AESCCR1_Candi_.lowbrake_flag = 0u;
aes_candidate.AESCCR1_Candi_.highbrake_flag = 0u;
aes_candidate.AESCCR2_Candi_.obj.clear();
aes_candidate.AESCCR2_Candi_.u8_ID = 0U;
aes_candidate.AESCCR2_Candi_.u8_IDX = MaxVisionIndex;
aes_candidate.AESCCR2_Candi_.u8_VID = 0u;
aes_candidate.AESCCR2_Candi_.objectvalid = 0U;
aes_candidate.AESCCR2_Candi_.f4_range = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_rangerate = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_relatAcc = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_TTC = DefaultTTC;
aes_candidate.AESCCR2_Candi_.f4_XOLC = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_vissup_dx = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_TTEmax = 0.0f;
aes_candidate.AESCCR2_Candi_.f4_TTEmin = 0.0f;
aes_candidate.AESCCR2_Candi_.u8_Inpathage = 0U;
aes_candidate.AESCCR2_Candi_.u1_Inpath_Cur = 0U;
aes_candidate.AESCCR2_Candi_.u1_Inpath_Pre = 0U;
aes_candidate.AESCCR2_Candi_.u1_Inpath = 0U;
aes_candidate.AESCCR2_Candi_.u1_TOI = 0U;
aes_candidate.AESCCR2_Candi_.u1_vfplaucheck = 0U;
aes_candidate.AESCCR2_Candi_.u1_ageplaucheck = 0U;
aes_candidate.AESCCR2_Candi_.u1_inpathagecheck = 0U;
aes_candidate.AESCCR2_Candi_.u1_oncoming = 0U;
aes_candidate.AESCCR2_Candi_.u1_preceding = 0U;
aes_candidate.AESCCR2_Candi_.u1_longmove = 0U;
aes_candidate.AESCCR2_Candi_.u1_latmove = 0U;
aes_candidate.AESCCR2_Candi_.u1_crossing = 0U;
aes_candidate.AESCCR2_Candi_.u8_AEBconf = 0U;
aes_candidate.AESCCR2_Candi_.u8_lostradarage = 0U;
aes_candidate.AESCCR2_Candi_.f4_minTTC = DefaultTTC;
aes_candidate.AESCCR2_Candi_.f4_minRange = 200.0f;
aes_candidate.AESCCR2_Candi_.warnig_flag = 0u;
aes_candidate.AESCCR2_Candi_.prefill_flag = 0u;
aes_candidate.AESCCR2_Candi_.lowbrake_flag = 0u;
aes_candidate.AESCCR2_Candi_.highbrake_flag = 0u;
aes_candidate.AESCCR1_Candi_.u8_closest_corner = 0;
aes_candidate.AESCCR1_Candi_.u8_closest_corner_estimate = 0;
aes_candidate.AESCCR1_Candi_.TTT_left.tt = 0;
aes_candidate.AESCCR1_Candi_.TTT_left.isvalid = false;
aes_candidate.AESCCR1_Candi_.TTT_right.tt = 0;
aes_candidate.AESCCR1_Candi_.TTT_right.isvalid = false;
aes_candidate.AESCCR1_Candi_.TTB.tt = 0;
aes_candidate.AESCCR1_Candi_.TTB.isvalid = false;
aes_candidate.AESCCR2_Candi_.u8_closest_corner = 0;
aes_candidate.AESCCR2_Candi_.u8_closest_corner_estimate = 0;
aes_candidate.AESCCR2_Candi_.TTT_left.tt = 0;
aes_candidate.AESCCR2_Candi_.TTT_left.isvalid = false;
aes_candidate.AESCCR2_Candi_.TTT_right.tt = 0;
aes_candidate.AESCCR2_Candi_.TTT_right.isvalid = false;
aes_candidate.AESCCR2_Candi_.TTB.tt = 0;
aes_candidate.AESCCR2_Candi_.TTB.isvalid = false;
ClearCandiCorner(aes_candidate.AESCCR1_Candi_.center_point);
ClearCandiCorner(aes_candidate.AESCCR1_Candi_.close_left);
ClearCandiCorner(aes_candidate.AESCCR1_Candi_.close_right);
ClearCandiCorner(aes_candidate.AESCCR1_Candi_.remote_left);
ClearCandiCorner(aes_candidate.AESCCR1_Candi_.remote_right);
ClearCandiCorner(aes_candidate.AESCCR2_Candi_.center_point);
ClearCandiCorner(aes_candidate.AESCCR2_Candi_.close_left);
ClearCandiCorner(aes_candidate.AESCCR2_Candi_.close_right);
ClearCandiCorner(aes_candidate.AESCCR2_Candi_.remote_left);
ClearCandiCorner(aes_candidate.AESCCR2_Candi_.remote_right);
aes_candidate.AESCCR1_Candi_.steer_flag = 0;
aes_candidate.AESCCR2_Candi_.steer_flag = 0;

}

void extract_aesccr::ClearCandiCorner (CornerPos &point){
  point.cur_x = 100;
  point.cur_y = 100;
  point.pos_x = 100;
  point.pos_y = 100;
  point.range = 100;
  point.lat_est = 100;
}

void extract_aesccr::clearCCRCandidate_LF() {
    aes_candidate.AESCCR1_Candi_LF_.obj.clear();
    aes_candidate.AESCCR1_Candi_LF_.u8_ID = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u8_IDX = MaxVisionIndex;
    aes_candidate.AESCCR1_Candi_LF_.u8_VID = 0u;
    aes_candidate.AESCCR1_Candi_LF_.objectvalid = 0U;
    aes_candidate.AESCCR1_Candi_LF_.f4_range = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_rangerate = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_relatAcc = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_TTC = DefaultTTC;
    aes_candidate.AESCCR1_Candi_LF_.f4_XOLC = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_vissup_dx = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_TTEmax = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.f4_TTEmin = 0.0f;
    aes_candidate.AESCCR1_Candi_LF_.u8_Inpathage = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_Inpath_Cur = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_Inpath_Pre = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_Inpath = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_TOI = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_vfplaucheck = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_ageplaucheck = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_inpathagecheck = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_oncoming = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_preceding = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_longmove = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_latmove = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u1_crossing = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u8_AEBconf = 0U;
    aes_candidate.AESCCR1_Candi_LF_.u8_lostradarage = 0U;
    aes_candidate.AESCCR1_Candi_LF_.f4_minTTC = DefaultTTC;
    aes_candidate.AESCCR1_Candi_LF_.f4_minRange = 200.0f;
    aes_candidate.AESCCR1_Candi_LF_.warnig_flag = 0u;
    aes_candidate.AESCCR1_Candi_LF_.prefill_flag = 0u;
    aes_candidate.AESCCR1_Candi_LF_.lowbrake_flag = 0u;
    aes_candidate.AESCCR1_Candi_LF_.highbrake_flag = 0u;
    aes_candidate.AESCCR2_Candi_LF_.obj.clear();
    aes_candidate.AESCCR2_Candi_LF_.u8_ID = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u8_IDX = MaxVisionIndex;
    aes_candidate.AESCCR2_Candi_LF_.u8_VID = 0u;
    aes_candidate.AESCCR2_Candi_LF_.objectvalid = 0U;
    aes_candidate.AESCCR2_Candi_LF_.f4_range = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_rangerate = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_relatAcc = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_TTC = DefaultTTC;
    aes_candidate.AESCCR2_Candi_LF_.f4_XOLC = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_vissup_dx = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_TTEmax = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.f4_TTEmin = 0.0f;
    aes_candidate.AESCCR2_Candi_LF_.u8_Inpathage = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_Inpath_Cur = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_Inpath_Pre = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_Inpath = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_TOI = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_vfplaucheck = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_ageplaucheck = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_inpathagecheck = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_oncoming = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_preceding = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_longmove = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_latmove = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u1_crossing = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u8_AEBconf = 0U;
    aes_candidate.AESCCR2_Candi_LF_.u8_lostradarage = 0U;
    aes_candidate.AESCCR2_Candi_LF_.f4_minTTC = DefaultTTC;
    aes_candidate.AESCCR2_Candi_LF_.f4_minRange = 200.0f;
    aes_candidate.AESCCR2_Candi_LF_.warnig_flag = 0u;
    aes_candidate.AESCCR2_Candi_LF_.prefill_flag = 0u;
    aes_candidate.AESCCR2_Candi_LF_.lowbrake_flag = 0u;
    aes_candidate.AESCCR2_Candi_LF_.highbrake_flag = 0u;
}


}
}