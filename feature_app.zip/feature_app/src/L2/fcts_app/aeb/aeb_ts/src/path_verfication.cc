#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "path_verification.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {
    path_verification path_verify_;
    
    path_verification::path_verification() {}

    void path_verification::MainFunction() {
        UpdatePath();
        UpdateLineInfo();

        reservedtime = CalcReserveTime(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ego_->vehicleinfo_in.vehicledynamic.LgtAg * 9.8, aes_ctrl_input.explondst);

        Determine_Path_Target(reservedtime, crash_id, path_targetvalid);
        Determine_Path_Rout(crash_lane, path_routvalid);

        aes_plan_valid = path_targetvalid && path_routvalid;        
    }

    void path_verification::UpdatePath() {
        // aes_path_pnc.path_c0 = Mtn_Plan_LatPathVCSFctA0_mp;
        // aes_path_pnc.path_c1 = Mtn_Plan_LatPathVCSFctA1_mp;
        // aes_path_pnc.path_c2 = Mtn_Plan_LatPathVCSFctA2_mp;
        // aes_path_pnc.path_c3 = Mtn_Plan_LatPathVCSFctA3_mp;
        // aes_path_pnc.path_c4 = Mtn_Plan_LatPathVCSFctA4_mp;
        // aes_path_pnc.path_c5 = Mtn_Plan_LatPathVCSFctA5_mp;
    }

    void path_verification::UpdateLineInfo() {
        for (int i = 0; i < 8; i++) {
            if (ego_->vision_road.lane.lines[i].role == 1) {
                if (ego_->vision_road.lane.lines[i].confidence >= 0.6) {
                    host_left.isvalid = 1;
                    host_left.path_c0 = ego_->vision_road.lane.lines[i].first_line.line.c0;
                    host_left.path_c1 = ego_->vision_road.lane.lines[i].first_line.line.c1;
                    host_left.path_c2 = ego_->vision_road.lane.lines[i].first_line.line.c2;
                    host_left.path_c3 = ego_->vision_road.lane.lines[i].first_line.line.c3;
                }
                else {
                    host_left.isvalid = 0;
                    host_left.path_c0 = 100;
                    host_left.path_c1 = 0;
                    host_left.path_c2 = 0;
                    host_left.path_c3 = 0;
                }
            }
            else if (ego_->vision_road.lane.lines[i].role == 2) {
                if (ego_->vision_road.lane.lines[i].confidence >= 0.6) {
                    host_right.isvalid = 1;
                    host_right.path_c0 = ego_->vision_road.lane.lines[i].first_line.line.c0;
                    host_right.path_c1 = ego_->vision_road.lane.lines[i].first_line.line.c1;
                    host_right.path_c2 = ego_->vision_road.lane.lines[i].first_line.line.c2;
                    host_right.path_c3 = ego_->vision_road.lane.lines[i].first_line.line.c3;
                }
                else {
                    host_right.isvalid = 0;
                    host_right.path_c0 = 100;
                    host_right.path_c1 = 0;
                    host_right.path_c2 = 0;
                    host_right.path_c3 = 0;
                }
            }
        }
        for (int i = 0; i < 2; i++) {
            if (ego_->vision_road.road_edge[i].side != nio::ad::RoadEdgeSide_Unkown) {
                if (ego_->vision_road.road_edge[i].side == nio::ad::RoadEdgeSide_Left) {
                    left_edge.isvalid = 1;
                    left_edge.path_c0 = ego_->vision_road.road_edge[i].line.c0;
                    left_edge.path_c1 = ego_->vision_road.road_edge[i].line.c1;
                    left_edge.path_c2 = ego_->vision_road.road_edge[i].line.c2;
                    left_edge.path_c3 = ego_->vision_road.road_edge[i].line.c3;
                }
                else if (ego_->vision_road.road_edge[i].side == nio::ad::RoadEdgeSide_Right) {
                    right_edge.isvalid = 1;
                    right_edge.path_c0 = ego_->vision_road.road_edge[i].line.c0;
                    right_edge.path_c1 = ego_->vision_road.road_edge[i].line.c1;
                    right_edge.path_c2 = ego_->vision_road.road_edge[i].line.c2;
                    right_edge.path_c3 = ego_->vision_road.road_edge[i].line.c3; 
                }
            }
            else {
                left_edge.isvalid = 0;
                left_edge.path_c0 = 100;
                left_edge.path_c1 = 0;
                left_edge.path_c2 = 0;
                left_edge.path_c3 = 0;
                right_edge.isvalid = 0;
                left_edge.path_c0 = 100;
                left_edge.path_c1 = 0;
                left_edge.path_c2 = 0;
                left_edge.path_c3 = 0;
            }
        }
    }

    void path_verification::Determine_Path_Rout (uint8_t &crashlane, bool &routvalid) {
        bool left_line_valid = false;
        bool right_line_valid = false;
        bool left_edge_valid = false;
        bool right_edge_valid = false;
        left_line_valid = CheckPoliValid(aes_path_pnc, host_left, 1.8, aes_ctrl_input.explondst);
        right_line_valid = CheckPoliValid(aes_path_pnc, host_right, 1.8, aes_ctrl_input.explondst);
        left_edge_valid = CheckPoliValid(aes_path_pnc, left_edge, 1.8, aes_ctrl_input.explondst);
        right_edge_valid = CheckPoliValid(aes_path_pnc, right_edge, 1.8, aes_ctrl_input.explondst);

        crashlane = 0;

        if (left_line_valid == true) {
            crashlane  = crashlane + 0x0001;
        }
        if (right_line_valid == true) {
            crashlane  = crashlane + 0x0002;
        }
        if (left_edge_valid == true) {
            crashlane  = crashlane + 0x0004;
        }
        if (right_edge_valid == true) {
            crashlane  = crashlane + 0x0008;
        }

        routvalid = (left_line_valid && right_line_valid && left_edge_valid && right_edge_valid);
    }

    bool path_verification::CheckPoliValid (AES_Path aes_path, Line_Poli extern_line, float hostwidth, float longposest) {
        float longitude_pos = 0;
        float aes_ypos = 0;
        float aes_y0 = 0;
        float extern_ypos = 0;
        float extern_y0 = 0;
        bool lane_crash = false;
        if (extern_line.isvalid == 0) {
            return true;
        }
        else {
            while (longitude_pos < longposest) {
                longitude_pos = longitude_pos + 1;
                aes_ypos = aes_path_pnc.path_c0 + aes_path_pnc.path_c1 * longitude_pos + aes_path_pnc.path_c2 * longitude_pos * longitude_pos + aes_path_pnc.path_c3 * longitude_pos * longitude_pos * longitude_pos + aes_path_pnc.path_c4 * longitude_pos * longitude_pos * longitude_pos * longitude_pos + aes_path_pnc.path_c5 * longitude_pos * longitude_pos * longitude_pos * longitude_pos * longitude_pos;
                aes_y0 = aes_path_pnc.path_c0;
                extern_ypos = extern_line.path_c0 + extern_line.path_c1 * longitude_pos + extern_line.path_c2 * longitude_pos * longitude_pos + extern_line.path_c3 * longitude_pos * longitude_pos * longitude_pos;
                extern_y0 = extern_line.path_c0;

                if ((aes_ypos > extern_ypos && aes_y0 < extern_y0) || (aes_ypos < extern_ypos && aes_y0 > extern_y0) || (fabsf(aes_ypos - extern_ypos) <= hostwidth * 0.5)) {
                    lane_crash = true;
                }
            }
            return !lane_crash;
        }        
    }

    void path_verification::Determine_Path_Target (float reservedtime, uint8_t &crashid, bool &pathvalid) {
        float remain_time = 0;
        float longitude_pos = 0;
        float delta_y = 0;
        crashid = 0;
        while (remain_time < reservedtime && remain_time < 3) {
            remain_time =  remain_time + 0.5;

            longitude_pos = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * remain_time;

            delta_y = aes_path_pnc.path_c0 + aes_path_pnc.path_c1 * longitude_pos + aes_path_pnc.path_c2 * longitude_pos * longitude_pos + aes_path_pnc.path_c3 * longitude_pos * longitude_pos * longitude_pos + aes_path_pnc.path_c4 * longitude_pos * longitude_pos * longitude_pos * longitude_pos + aes_path_pnc.path_c5 * longitude_pos * longitude_pos * longitude_pos * longitude_pos * longitude_pos;

            for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
                if(fused_obj_filtered.at(i).gofcheck.check_valid == true && (fused_obj_filtered.at(i).raw_data.IsAllFused() || fused_obj_filtered.at(i).raw_data.IsVisionOnly()) && fused_obj_filtered.at(i).raw_data.IsValid()){
                    AESObjectCCR tmp_objAES;

                    tmp_objAES.obj = fused_obj_filtered.at(i).raw_data;

                    CalcCenterPoint(tmp_objAES);

                    CalcCornerPoint(tmp_objAES);

                    CalcCornerPointEsti(tmp_objAES, remain_time);

                    UpdateEgoPos(ego_pos, aes_path_pnc, remain_time);

                    bool targetinpath = 0;

                    targetinpath = DecideCrash(tmp_objAES, ego_pos);

                    if (targetinpath == 1) {
                        crashid = tmp_objAES.obj.ID;
                    }                   
                }
            }
        }
        pathvalid = (crashid > 0)?0:1;       

    }

    bool path_verification::DecideCrash (AESObjectCCR &tmpobj, EgoPos ego_pos) {
        bool cl_crash = 0;
        bool cr_crash = 0;
        bool rl_crash = 0;
        bool rr_crash = 0;
        float width = 0.9;
        float cltof = 100;
        float cltom = 100;
        float cltor = 100;
        float crtof = 100;
        float crtom = 100;
        float crtor = 100;
        float rltof = 100;
        float rltom = 100;
        float rltor = 100;
        float rrtof = 100;
        float rrtom = 100;
        float rrtor = 100;

        cltof = CalCornerDist(tmpobj.close_left, ego_pos.pos_x_f, ego_pos.pos_y_f);
        cltom = CalCornerDist(tmpobj.close_left, ego_pos.pos_x_m, ego_pos.pos_y_m);
        cltor = CalCornerDist(tmpobj.close_left, ego_pos.pos_x_r, ego_pos.pos_y_r);

        crtof = CalCornerDist(tmpobj.close_right, ego_pos.pos_x_f, ego_pos.pos_y_f);
        crtom = CalCornerDist(tmpobj.close_right, ego_pos.pos_x_m, ego_pos.pos_y_m);
        crtor = CalCornerDist(tmpobj.close_right, ego_pos.pos_x_r, ego_pos.pos_y_r);
        
        rltof = CalCornerDist(tmpobj.remote_left, ego_pos.pos_x_f, ego_pos.pos_y_f);
        rltom = CalCornerDist(tmpobj.remote_left, ego_pos.pos_x_m, ego_pos.pos_y_m);
        rltor = CalCornerDist(tmpobj.remote_left, ego_pos.pos_x_r, ego_pos.pos_y_r);

        rrtof = CalCornerDist(tmpobj.remote_right, ego_pos.pos_x_f, ego_pos.pos_y_f);
        rrtom = CalCornerDist(tmpobj.remote_right, ego_pos.pos_x_m, ego_pos.pos_y_m);
        rrtor = CalCornerDist(tmpobj.remote_right, ego_pos.pos_x_r, ego_pos.pos_y_r);

        if (cltof < width || cltom < width || cltor < width) {
            cl_crash = 1;
        }

        if (crtof < width || crtom < width || crtor < width) {
            cr_crash = 1;
        }

        if (rltof < width || rltom < width || rltor < width) {
            rl_crash = 1;
        }

        if (rrtof < width || rrtom < width || rrtor < width) {
            rr_crash = 1;
        }

        return cl_crash || cr_crash || rl_crash || rr_crash;
    }

    float path_verification::CalCornerDist (CornerPos cornerpoint, float x, float y) {
        float range = 100;
        range = sqrtf((cornerpoint.long_est - x) * (cornerpoint.long_est - x) + (cornerpoint.lat_est - y) * (cornerpoint.lat_est - y));
        return range;
    }

    void path_verification::UpdateEgoPos (EgoPos &ego_pos, AES_Path aes_path, float remain_time) {
        float long_pos  = 0;
        long_pos = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * remain_time;

        ego_pos.pos_x_f = long_pos - 0.9;
        ego_pos.pos_x_m = long_pos - 2.1;
        ego_pos.pos_x_r = long_pos - 3.3;

        ego_pos.pos_y_f = aes_path.path_c0 + aes_path.path_c1 * ego_pos.pos_x_f + aes_path.path_c2 * ego_pos.pos_x_f * ego_pos.pos_x_f + aes_path.path_c3 * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f + aes_path.path_c4 * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f + aes_path.path_c5 * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f * ego_pos.pos_x_f;

        ego_pos.pos_y_m = aes_path.path_c0 + aes_path.path_c1 * ego_pos.pos_x_m + aes_path.path_c2 * ego_pos.pos_x_m * ego_pos.pos_x_m + aes_path.path_c3 * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m + aes_path.path_c4 * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m + aes_path.path_c5 * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m * ego_pos.pos_x_m;

        ego_pos.pos_y_r = aes_path.path_c0 + aes_path.path_c1 * ego_pos.pos_x_r + aes_path.path_c2 * ego_pos.pos_x_r * ego_pos.pos_x_r + aes_path.path_c3 * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r + aes_path.path_c4 * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r + aes_path.path_c5 * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r * ego_pos.pos_x_r;
    }

    float path_verification::CalcReserveTime(float vspd, float egoacc, float range) {
        float TTC_final;
        if (fabsf(egoacc) < 0.1f) {
            if (vspd < 0.0f) {
            TTC_final = MaxTTC;
            } else {
            TTC_final = range / vspd;
            }
        } else {
            if (vspd * vspd + 2 * egoacc * range < 0.0f) {
            TTC_final = MaxTTC;
            } else {
            TTC_final =
                (-vspd + sqrtf(vspd * vspd + 2 * egoacc * range)) / egoacc;
            }
        }
        if (TTC_final < 0) {
            return MaxTTC;
        } else if (TTC_final >= MaxTTC) {
            return MaxTTC;
        } else {
            return TTC_final;
        }
    }

    void path_verification::CalcCenterPoint (AESObjectCCR &tmpobj) {
        if (tmpobj.obj.classification.IsVehicle() == 1) {
            if (tmpobj.obj.motion.GetY() <= 0) {
                if (fabsf(tmpobj.obj.motion.GetHead()) <= (Pi/4) || (fabsf(tmpobj.obj.motion.GetHead()) >= (Pi*3/4) && fabsf(tmpobj.obj.motion.GetHead()) <= Pi)) {
                    if (tmpobj.obj.motion.GetX() > 0) {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() + (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() + (0.5 * tmpobj.obj.length() * sinf(tmpobj.obj.motion.GetHead()));
                    }
                    else {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() - (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() - (0.5 * tmpobj.obj.length() * sinf(tmpobj.obj.motion.GetHead()));
                    }
                }
                else if ((tmpobj.obj.motion.GetHead() >= Pi/2 && tmpobj.obj.motion.GetHead() < Pi*3/4) || (tmpobj.obj.motion.GetHead() >= -Pi/2 && tmpobj.obj.motion.GetHead() <= -Pi/4)) {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() + (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() - (0.5 * tmpobj.obj.length() * fabsf(sinf(tmpobj.obj.motion.GetHead())));
                }
                else {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() - (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() - (0.5 * tmpobj.obj.length() * fabsf(sinf(tmpobj.obj.motion.GetHead())));
                }
            }
            else {
                if (fabsf(tmpobj.obj.motion.GetHead()) <= (Pi/4) || (fabsf(tmpobj.obj.motion.GetHead()) >= (Pi*3/4) && fabsf(tmpobj.obj.motion.GetHead()) <= Pi)) {
                    if (tmpobj.obj.motion.GetX() > 0) {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() + (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() + (0.5 * tmpobj.obj.length() * sinf(tmpobj.obj.motion.GetHead()));
                    }
                    else {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() - (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() - (0.5 * tmpobj.obj.length() * sinf(tmpobj.obj.motion.GetHead()));
                    }
                }
                else if ((tmpobj.obj.motion.GetHead() >= Pi/2 && tmpobj.obj.motion.GetHead() < Pi*3/4) || (tmpobj.obj.motion.GetHead() >= -Pi/2 && tmpobj.obj.motion.GetHead() <= -Pi/4)) {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() - (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() + (0.5 * tmpobj.obj.length() * fabsf(sinf(tmpobj.obj.motion.GetHead())));
                }
                else {
                    tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX() + (0.5 * tmpobj.obj.length() * fabsf(cosf(tmpobj.obj.motion.GetHead())));
                    tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY() + (0.5 * tmpobj.obj.length() * fabsf(sinf(tmpobj.obj.motion.GetHead())));
                }
            }
        }
        //hong taowen2021.12.01: hold this spot for motorcycle
        else {
            tmpobj.center_point.pos_x = tmpobj.obj.motion.GetX();
            tmpobj.center_point.pos_y = tmpobj.obj.motion.GetY();
        }
    }  

    void path_verification::CalcCornerPoint (AESObjectCCR &tmpobj) {
        float heading = 0;
        float length = tmpobj.obj.length();
        float width = tmpobj.obj.width();
        float centerx = tmpobj.center_point.pos_x;
        float centery = tmpobj.center_point.pos_y;
        float bumptorearaxle = 3.9;

        if (tmpobj.obj.motion.GetHead() >= -Pi/2 && tmpobj.obj.motion.GetHead() <= Pi/2) {
            heading = tmpobj.obj.motion.GetHead();
        }
        else if (tmpobj.obj.motion.GetHead() < -Pi/2 && tmpobj.obj.motion.GetHead() >= -Pi) {
            heading = Pi + tmpobj.obj.motion.GetHead();
        }
        else {
            heading = tmpobj.obj.motion.GetHead() - Pi;
        }

        tmpobj.close_left.pos_x = centerx - (length * cosf(heading))/2 + (width * sinf(heading))/2 - bumptorearaxle;
        tmpobj.close_left.pos_y = centery - (length * sinf(heading))/2 - (width * cosf(heading))/2;
        tmpobj.close_left.range = sqrtf(tmpobj.close_left.pos_x * tmpobj.close_left.pos_x + tmpobj.close_left.pos_y * tmpobj.close_left.pos_y);
        tmpobj.close_left.cur_x = tmpobj.close_left.pos_x;

        tmpobj.close_right.pos_x = centerx - (length * cosf(heading))/2 - (width * sinf(heading))/2 - bumptorearaxle;
        tmpobj.close_right.pos_y = centery - (length * sinf(heading))/2 + (width * cosf(heading))/2;
        tmpobj.close_right.range = sqrtf(tmpobj.close_right.pos_x * tmpobj.close_right.pos_x + tmpobj.close_right.pos_y * tmpobj.close_right.pos_y);
        tmpobj.close_right.cur_x = tmpobj.close_right.pos_x;

        tmpobj.remote_left.pos_x = centerx + (length * cosf(heading))/2 + (width * sinf(heading))/2 - bumptorearaxle;
        tmpobj.remote_left.pos_y = centery + (length * sinf(heading))/2 - (width * cosf(heading))/2;
        tmpobj.remote_left.range = sqrtf(tmpobj.remote_left.pos_x * tmpobj.remote_left.pos_x + tmpobj.remote_left.pos_y * tmpobj.remote_left.pos_y);
        tmpobj.remote_left.cur_x = tmpobj.remote_left.pos_x;

        tmpobj.remote_right.pos_x = centerx + (length * cosf(heading))/2 - (width * sinf(heading))/2 - bumptorearaxle;
        tmpobj.remote_right.pos_y = centery + (length * sinf(heading))/2 + (width * cosf(heading))/2;
        tmpobj.remote_right.range = sqrtf(tmpobj.remote_right.pos_x * tmpobj.remote_right.pos_x + tmpobj.remote_right.pos_y * tmpobj.remote_right.pos_y);
        tmpobj.remote_right.cur_x = tmpobj.remote_right.pos_x;
    }
    
    void path_verification::CalcLatEsti (CornerPos &cornerpoint, float longspd, float latspd, float remain_time) {
        cornerpoint.long_est = cornerpoint.pos_x + longspd *remain_time;
        cornerpoint.lat_est = cornerpoint.pos_y + latspd * remain_time;
    }

    void path_verification::CalcCornerPointEsti (AESObjectCCR &tmpobj, float remain_time) {
        CalcLatEsti(tmpobj.close_left, tmpobj.obj.motion.GetVx(), tmpobj.obj.motion.GetVy(), remain_time);
        CalcLatEsti(tmpobj.close_right, tmpobj.obj.motion.GetVx(), tmpobj.obj.motion.GetVy(), remain_time);
        CalcLatEsti(tmpobj.remote_left, tmpobj.obj.motion.GetVx(), tmpobj.obj.motion.GetVy(), remain_time);
        CalcLatEsti(tmpobj.remote_right, tmpobj.obj.motion.GetVx(), tmpobj.obj.motion.GetVy(), remain_time);
    }
}
}