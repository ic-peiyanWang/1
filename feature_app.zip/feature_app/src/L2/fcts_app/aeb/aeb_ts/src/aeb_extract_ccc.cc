#include <iostream>
#include "niodds/application/application.h"
#include "fcts_loc_cfg.h"
#include "aeb_extract_ccc.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_calibration.h"
#include "aeb_gof.h"
#include "aeb_dm.h"


namespace nio {
namespace ad {

extract_ccc ccc_extraction_;

void extract_ccc::MainFunction() {
    UpdateCalibration();
    ExtractCCC();
}

extract_ccc::extract_ccc() {}

void extract_ccc::UpdateCalibration() {
    threshold_CCR_LongPos_VFcheck_.init(
      EAEB_dstLongPosCheck_LongPos_x, EAEB_spdLongPosCheck_Rrate_y,
      EAEB_dstLongPosCheck_Poserror_v,
      sizeof(EAEB_dstLongPosCheck_LongPos_x) /
          sizeof(EAEB_dstLongPosCheck_LongPos_x[0]),
      sizeof(EAEB_spdLongPosCheck_Rrate_y) /
          sizeof(EAEB_spdLongPosCheck_Rrate_y[0]));

    size_t distance_targetrange =
            sizeof(EAEB_dstTarget_Range_x) / sizeof(EAEB_dstTarget_Range_x[0]);
    threshold_CCC_OncomingSpd_.init(
            EAEB_dstTarget_Range_x, EAEB_spdOncom_targspd_v, distance_targetrange);

    size_t egospdccc_cal =
            sizeof(EAEB_spdccc_egospd_x) / sizeof(EAEB_spdccc_egospd_x[0]);
    size_t ColRange_cal = sizeof(EAEB_dstCollisionPoint_Range_CCC_y) /
                                sizeof(EAEB_dstCollisionPoint_Range_CCC_y[0]);
    threshold_CCC_predict_.init(
            EAEB_spdccc_egospd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstccc_predictpath_v, egospdccc_cal, ColRange_cal);
    threshold_CCC_current_.init(
            EAEB_spdccc_egospd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstccc_currentpath_v, egospdccc_cal, ColRange_cal);
    threshold_CCC_predict_warn_.init(
            EAEB_spdccc_egospd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstcccwarn_predictpath_v, egospdccc_cal, ColRange_cal);
    threshold_CCC_current_warn_.init(
            EAEB_spdccc_egospd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstcccwarn_currentpath_v, egospdccc_cal, ColRange_cal);

    size_t targspdccc_cal =
            sizeof(EAEB_spdccc_targspd_x) / sizeof(EAEB_spdccc_targspd_x[0]);
    threshold_CCC_expend_predict_.init(
            EAEB_spdccc_targspd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstccc_predictext_v, targspdccc_cal, ColRange_cal);
    threshold_CCC_expend_current_.init(
            EAEB_spdccc_targspd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstccc_currentext_v, targspdccc_cal, ColRange_cal);
    threshold_CCC_expend_predict_warn_.init(
            EAEB_spdccc_targspd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstcccwarn_predictext_v, targspdccc_cal, ColRange_cal);
    threshold_CCC_expend_current_warn_.init(
            EAEB_spdccc_targspd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstcccwarn_currentext_v, targspdccc_cal, ColRange_cal);
    threshold_CCC_expend_predict_after_.init(
            EAEB_spdccc_targspd_x, EAEB_dstCollisionPoint_Range_CCC_y,
            EAEB_dstccc_predictext_after_v, targspdccc_cal, ColRange_cal);

    threshold_CCC_range_.init(EAEB_spdccc_egospd_x, EAEB_dstCCCTOI_Range_v,
                                    egospdccc_cal);

    size_t conf_cal =
            sizeof(EAEB_agecheck_AEBconf_x) / sizeof(EAEB_agecheck_AEBconf_x[0]);

    threshold_CCC_InPathAge_.init(EAEB_agecheck_AEBconf_x,
                                        EAEB_ageCCC_inpathage_v, conf_cal);
    threshold_CCC_InPathAge_warn_.init(EAEB_agecheck_AEBconf_x,
                                                EAEB_ageCCCwarn_inpathage_v, conf_cal);

    threshold_CCC_WarningTTC_.init(EAEB_spdccc_egospd_x,
                                            EAEB_tiCCCwarn_TTC_v, egospdccc_cal);
    threshold_CCC_PrefillTTC_.init(EAEB_spdccc_egospd_x,
                                            EAEB_tiCCCpref_TTC_v, egospdccc_cal);
    threshold_CCC_LowBrakeTTC_.init(EAEB_spdccc_egospd_x,
                                            EAEB_tiCCClowB_TTC_v, egospdccc_cal);
    threshold_CCC_HighBrakeTTC_.init(EAEB_spdccc_egospd_x,
                                            EAEB_tiCCChighB_TTC_v, egospdccc_cal);

}

void extract_ccc::ExtractCCC() {

    ccc_candidate.CCC_Candi_LF_ = ccc_candidate.CCC_Candi_;
    ccc_candidate.CCC_Candi_LF_2_ = ccc_candidate.CCC_Candi_2_;;
    ClearCCCCandi(ccc_candidate.CCC_Candi_);
    ClearCCCCandi(ccc_candidate.CCC_Candi_2_);

    for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
      if(fused_obj_filtered.at(i).gofcheck.check_valid == true){
        if ((fused_obj_filtered.at(i).raw_data.classification.IsVehicle() ||
            fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()) &&
            fused_obj_filtered.at(i).raw_data.motion_status.IsMoved() &&
            fused_obj_filtered.at(i).raw_data.IsValid() && fused_obj_filtered.at(i).raw_data.valid_status() == 2 && fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x > 0) {
            AEBObjectCCC tmp_objCCC;
            tmp_objCCC.obj = fused_obj_filtered.at(i).raw_data;
            tmp_objCCC.ref_pos = fused_obj_filtered.at(i).ref_pos;
            tmp_objCCC.u8_ID = fused_obj_filtered.at(i).raw_data.GetID();
            tmp_objCCC.u8_IDX = i;
            uint32_t vision_ID;
            vision_ID = VisMatchID_[i].vis_id;
            tmp_objCCC.u8_VID = vision_ID;
            if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID &&
                vision_ID != MaxVisionIndex) {
                tmp_objCCC.f4_vissup_dx = vis_obj_->at(vision_ID).motion.GetX();
                tmp_objCCC.f4_vissup_dy = vis_obj_->at(vision_ID).motion.GetY();
                tmp_objCCC.f4_vissup_vx = vis_obj_->at(vision_ID).motion.GetVx();
                tmp_objCCC.f4_vissup_vy = vis_obj_->at(vision_ID).motion.GetVy();
            }
            tmp_objCCC.objectvalid = fused_obj_filtered.at(i).raw_data.IsValid();
            tmp_objCCC.f4_longpos = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x;
            tmp_objCCC.f4_latpos = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y;
            tmp_objCCC.f4_longvel = fused_obj_filtered.at(i).raw_data.motion.GetVx();
            tmp_objCCC.f4_latvel = fused_obj_filtered.at(i).raw_data.motion.GetVy();

            tmp_objCCC.f4_range = sqrtf(
                powf((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle), 2) +
                powf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y, 2));

            tmp_objCCC.f4_rangerate =
                tmp_objCCC.f4_longvel - ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;

            float ego_ROC = MaxEgoRoc;
            float ROC_raw = MaxRocRaw;
            if (fabsf(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps) > 1) {
                if (ego_state_aeb.yawrate != 0.0f) {
                ROC_raw = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps /
                            ego_state_aeb.yawrate;
                } else {
                ROC_raw = MaxRocRaw;
                }
            }
            else {
                ROC_raw = MaxRocRaw;
            }
            
            ego_ROC = ROC_raw;

            if (fabsf(tmp_objCCC.f4_latvel) <= MaxLatVelThres) {
                tmp_objCCC.f4_Heading = MaxCandiHeading;
            } else {
                tmp_objCCC.f4_Heading = tmp_objCCC.f4_longvel / tmp_objCCC.f4_latvel;
            }
            tmp_objCCC.f4_Headangle = 0.0f;
            if (tmp_objCCC.f4_Heading >= 0.0f) {
                tmp_objCCC.f4_Headangle = atanf(tmp_objCCC.f4_Heading);
            } else {
                tmp_objCCC.f4_Headangle = atanf(tmp_objCCC.f4_Heading) + Pi;
            }
            // Heading is not the same as target heading angle, here it shall be equal to ctan(headingangle);
            float deltaR = MaxDeltaR;
            deltaR = tmp_objCCC.f4_longpos -
                    (tmp_objCCC.f4_Heading * tmp_objCCC.f4_latpos);
            float alfa_1 = 0.0;
            alfa_1 = (tmp_objCCC.f4_Heading * tmp_objCCC.f4_Heading + 1) * ego_ROC * ego_ROC - (tmp_objCCC.f4_Heading * ego_ROC + deltaR) * (tmp_objCCC.f4_Heading * ego_ROC + deltaR);

            if (fabsf(tmp_objCCC.f4_latvel) <= MaxLatVelThres) {
                if ((tmp_objCCC.f4_latpos <= 2 * ego_ROC &&
                    tmp_objCCC.f4_latpos >= 0) ||
                    (tmp_objCCC.f4_latpos >= 2 * ego_ROC &&
                    tmp_objCCC.f4_latpos <= 0)) {
                tmp_objCCC.u8_col_pointN = 1;
                tmp_objCCC.f4_collisiony_1 = tmp_objCCC.f4_latpos;
                tmp_objCCC.f4_collisionx_1 =
                    sqrtf(2 * ego_ROC * tmp_objCCC.f4_latpos -
                            tmp_objCCC.f4_latpos * tmp_objCCC.f4_latpos);
                tmp_objCCC.f4_collisionr_1 =
                    CalculateCirRange(tmp_objCCC.f4_collisiony_1, ego_ROC);
                } else {
                tmp_objCCC.u8_col_pointN = 0;
                tmp_objCCC.f4_collisiony_1 = DefaultCollPos;
                tmp_objCCC.f4_collisionx_1 = DefaultCollPos;
                tmp_objCCC.f4_collisionr_1 = DefaultCollPos;
                }
            } else {
                if (alfa_1 == 0) {
                  tmp_objCCC.u8_col_pointN = 1;
                  tmp_objCCC.f4_collisiony_1 =
                      (ego_ROC - tmp_objCCC.f4_Heading * deltaR) /
                      (tmp_objCCC.f4_Heading * tmp_objCCC.f4_Heading + 1);
                  tmp_objCCC.f4_collisionx_1 =
                      CalculateCirX(tmp_objCCC.f4_collisiony_1, tmp_objCCC.f4_longpos, tmp_objCCC.f4_latpos, tmp_objCCC.f4_Heading);
                  tmp_objCCC.f4_collisionr_1 =
                      CalculateCirRange(tmp_objCCC.f4_collisiony_1, ego_ROC);
                } else if (alfa_1 > 0) {
                  float coly1 = DefaultCollPos;
                  float coly2 = DefaultCollPos;
                  float colx1 = DefaultCollPos;
                  float colx2 = DefaultCollPos;
                  float colr1 = DefaultCollPos;
                  float colr2 = DefaultCollPos;

                  coly1 =
                      ((ego_ROC - tmp_objCCC.f4_Heading * deltaR) + sqrtf(alfa_1)) /
                      (tmp_objCCC.f4_Heading * tmp_objCCC.f4_Heading + 1);

                  coly2 =
                      ((ego_ROC - tmp_objCCC.f4_Heading * deltaR) - sqrtf(alfa_1)) /
                      (tmp_objCCC.f4_Heading * tmp_objCCC.f4_Heading + 1);

                  colx1 = CalculateCirX(coly1, tmp_objCCC.f4_longpos,
                                          tmp_objCCC.f4_latpos, tmp_objCCC.f4_Heading);

                  colx2 = CalculateCirX(coly2, tmp_objCCC.f4_longpos,
                                          tmp_objCCC.f4_latpos, tmp_objCCC.f4_Heading);

                  colr1 = CalculateCirRange(coly1, ego_ROC);

                  colr2 = CalculateCirRange(coly2, ego_ROC);

                  if (colx1 >= 0 && colx2 >= 0) {
                      tmp_objCCC.u8_col_pointN = 2;
                      if (fabsf(colr1) >= fabsf(colr2)) {
                      tmp_objCCC.f4_collisiony_1 = coly2;
                      tmp_objCCC.f4_collisionx_1 = colx2;
                      tmp_objCCC.f4_collisionr_1 = colr2;
                      } else {
                      tmp_objCCC.f4_collisiony_1 = coly1;
                      tmp_objCCC.f4_collisionx_1 = colx1;
                      tmp_objCCC.f4_collisionr_1 = colr1;
                      }
                  } else if ((colx1 >= 0 && colx2 < 0)) {
                      tmp_objCCC.u8_col_pointN = 1;
                      tmp_objCCC.f4_collisiony_1 = coly1;
                      tmp_objCCC.f4_collisionx_1 = colx1;
                      tmp_objCCC.f4_collisionr_1 = colr1;
                  } else if ((colx1 < 0 && colx2 >= 0)) {
                      tmp_objCCC.u8_col_pointN = 1;
                      tmp_objCCC.f4_collisiony_1 = coly2;
                      tmp_objCCC.f4_collisionx_1 = colx2;
                      tmp_objCCC.f4_collisionr_1 = colr2;
                  } else {
                      tmp_objCCC.u8_col_pointN = 0;
                      tmp_objCCC.f4_collisiony_1 = DefaultCollPos;
                      tmp_objCCC.f4_collisionx_1 = DefaultCollPos;
                      tmp_objCCC.f4_collisionr_1 = DefaultCollPos;
                  }
                } else {
                tmp_objCCC.u8_col_pointN = 0;
                tmp_objCCC.f4_collisiony_1 = DefaultCollPos;
                tmp_objCCC.f4_collisionx_1 = DefaultCollPos;
                tmp_objCCC.f4_collisionr_1 = DefaultCollPos;
                }
            }

            if (fabsf(ego_ROC) >= MinEgoRocThres) {
              float coly1 = DefaultCollPos;
              float colx1 = DefaultCollPos;
              float colr1 = DefaultCollPos;
              coly1 = 0;
              colx1 = tmp_objCCC.f4_Heading * tmp_objCCC.f4_latpos * (-1) + tmp_objCCC.f4_longpos;
              colr1 = colx1;

              if (colx1 >= 0) {
                tmp_objCCC.u8_col_pointN = 1;
                tmp_objCCC.f4_collisionx_1 = colx1;
                tmp_objCCC.f4_collisiony_1 = coly1;
                tmp_objCCC.f4_collisionr_1 = colr1;
              }
              else {
                tmp_objCCC.u8_col_pointN = 0;
                tmp_objCCC.f4_collisionx_1 = DefaultCollPos;
                tmp_objCCC.f4_collisiony_1 = DefaultCollPos;
                tmp_objCCC.f4_collisionr_1 = DefaultCollPos;
              }
            }

            // int8_t ROC_sign = 0;
            // if (ego_ROC >= 0) {
            //     ROC_sign = 1;
            // } else {
            //     ROC_sign = -1;
            // }

            if (tmp_objCCC.u8_col_pointN > 0 /*&& tmp_objCCC.u8_cornerNum > 0*/) {
                tmp_objCCC.u8_col_pointN = 1;
            } else {
                tmp_objCCC.u8_col_pointN = 0;
            }

            tmp_objCCC.f4_TTC = CalculateCirTTC(
                tmp_objCCC.f4_collisionr_1, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                tmp_objCCC.u8_col_pointN, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2),
                lfbrake_active);

            tmp_objCCC.f4_TTL = CalculateCirTTL(
                tmp_objCCC.f4_collisionr_1, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                tmp_objCCC.u8_col_pointN, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2),
                lfbrake_active);

            tmp_objCCC.f4_currentRange = CalculateCirCurRange(
                tmp_objCCC.f4_longpos, tmp_objCCC.f4_latpos,
                tmp_objCCC.f4_collisionx_1, tmp_objCCC.f4_collisiony_1,
                tmp_objCCC.u8_col_pointN);

            tmp_objCCC.f4_rangeestimation = CalculateCirPreRange(
                tmp_objCCC.f4_longpos, tmp_objCCC.f4_latpos, tmp_objCCC.f4_longvel,
                tmp_objCCC.f4_latvel, tmp_objCCC.f4_TTC,
                tmp_objCCC.f4_collisionx_1, tmp_objCCC.f4_collisiony_1,
                tmp_objCCC.u8_col_pointN, tmp_objCCC.obj.motion.GetAx(),
                tmp_objCCC.obj.motion.GetAy());

            tmp_objCCC.u1_movingstate = DecideMoveState(
                tmp_objCCC.f4_longpos, tmp_objCCC.f4_latpos, tmp_objCCC.f4_longvel,
                tmp_objCCC.f4_latvel, tmp_objCCC.f4_TTC, ego_ROC);
            // 4 is moving cross

            tmp_objCCC.u8_AEBconf = DecideCCR_AEBConf(
                tmp_objCCC.obj.IsAllFused(), tmp_objCCC.obj.IsAllFusedHis(),
                tmp_objCCC.obj.IsVisionOnly(), tmp_objCCC.obj.IsRadarOnly(),
                tmp_objCCC.obj.fusion_sup.confidence);

            if (tmp_objCCC.obj.IsRadarOnly() != 1) {
                tmp_objCCC.u1_vfplaucheck = CCR_VF_Longpos_check(
                    fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x, tmp_objCCC.f4_vissup_dx,
                    tmp_objCCC.f4_rangerate, ego_->vehicleinfo_in.vehicledynamic.LgtAg);
            } else {
                tmp_objCCC.u1_vfplaucheck = 1;
            }

            if (tmp_objCCC.obj.motion.GetVx() < OncVxThres) {
                tmp_objCCC.u1_oncoming = 1;
            } else {
                tmp_objCCC.u1_oncoming = 0;
            }

            tmp_objCCC.u1_ageplaucheck = CCR_Age_check(
                tmp_objCCC.obj.IsAllFused(), tmp_objCCC.obj.IsRadarOnly(),
                tmp_objCCC.obj.IsVisionOnly(),
                sizeof(tmp_objCCC.obj.fusion_sup.radar_list),
                tmp_objCCC.obj.fusion_sup.age);

            if (tmp_objCCC.obj.motion_status.IsMoving() == 0 &&
                tmp_objCCC.obj.IsVisionOnly() == 1 &&
                fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x <= AgeCheckXThres &&
                tmp_objCCC.obj.fusion_sup.age >= AgeCheckFusAgeThres) {
                tmp_objCCC.u1_ageplaucheck = 1;
            }

            tmp_objCCC.u1_oncoming =
                DecideTargetOncoming(tmp_objCCC.f4_longvel, tmp_objCCC.f4_range);

            // 20210226: according to suggestion from Binbin, using coordinate vector
            // to calculate path as reference.=============

            feature::math::Vector2f CollisionP;
            CollisionP.x = tmp_objCCC.f4_collisionx_1;
            CollisionP.y = tmp_objCCC.f4_collisiony_1;

            float coordiangle = 0.0f;
            if (tmp_objCCC.u8_col_pointN >= 1) {
                coordiangle = CalculateCirAngle(tmp_objCCC.f4_collisiony_1, ego_ROC);
            }

            feature::math::Vector2f FutureP;
            FutureP.x =
                tmp_objCCC.f4_longpos + tmp_objCCC.f4_longvel * tmp_objCCC.f4_TTC;
            FutureP.y =
                tmp_objCCC.f4_latpos + tmp_objCCC.f4_latvel * tmp_objCCC.f4_TTC;

            feature::math::Matrix2f rotate_m = feature::math::from_angle(coordiangle * (-1));

            feature::math::Vector2f CurPCol;
            feature::math::Vector2f FutPCol;
            feature::math::Vector2f MidVect;

            MidVect.x = tmp_objCCC.obj.motion.GetPos().x - CollisionP.x;
            MidVect.y = tmp_objCCC.obj.motion.GetPos().y - CollisionP.y;

            // changed_vector = Matrix (-angle) * (changing_vector -
            // newcoordinate_center_vector)
            CurPCol = rotate_m * MidVect;
            FutPCol = rotate_m * (FutureP - CollisionP);

            bool ismovingcross = 0;
            if (tmp_objCCC.u8_col_pointN >= 1) {
                ismovingcross = ((CurPCol.y <= 0 && FutPCol.y >= 0) ||
                                (CurPCol.y >= 0 && FutPCol.y <= 0))
                                    ? 1
                                    : 0;
            }

            if (ismovingcross == 1) {
                tmp_objCCC.u1_movingstate = MoveState::kMoving_through;
            } else {
                tmp_objCCC.u1_movingstate = MoveState::kInit;
            }

            // end coordinate rotation===============================
            tmp_objCCC.f4_angle_tar = 0.0;

            if (tmp_objCCC.obj.motion.GetVx() == 0) {
              if (tmp_objCCC.obj.motion.GetVy() > 0) {
                tmp_objCCC.f4_angle_tar = Degree90ToRad;
              }
              else if (tmp_objCCC.obj.motion.GetVy() < 0) {
                tmp_objCCC.f4_angle_tar = -Degree90ToRad;
              }
              else {
                tmp_objCCC.f4_angle_tar = tmp_objCCC.obj.motion.angle();
              }
            }
            else {
              tmp_objCCC.f4_angle_tar = atanf(tmp_objCCC.obj.motion.GetVy()/tmp_objCCC.obj.motion.GetVx());
            }

            tmp_objCCC.u1_TOI_Before = DecideCCCTOI(
                tmp_objCCC.f4_range, tmp_objCCC.f4_longvel, tmp_objCCC.f4_latvel,
                tmp_objCCC.f4_angle_tar, tmp_objCCC.u1_oncoming,
                ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

            tmp_objCCC.u1_inpathpre = DecideInpathpre(
                tmp_objCCC.f4_range, tmp_objCCC.obj.length(),
                tmp_objCCC.f4_Heading, tmp_objCCC.u1_movingstate,
                tmp_objCCC.f4_rangeestimation, tmp_objCCC.f4_collisionr_1,
                (tmp_objCCC.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

            tmp_objCCC.u1_inpathpre_warn = DecideInpathpre_warn(
                tmp_objCCC.f4_range, tmp_objCCC.obj.length(),
                tmp_objCCC.f4_Heading, tmp_objCCC.u1_movingstate,
                tmp_objCCC.f4_rangeestimation, tmp_objCCC.f4_collisionr_1,
                (tmp_objCCC.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

            tmp_objCCC.u1_inpathcur = DecideInpathcur(
                tmp_objCCC.f4_range, tmp_objCCC.obj.length(),
                tmp_objCCC.f4_Heading, tmp_objCCC.f4_currentRange,
                tmp_objCCC.f4_collisionr_1,
                (tmp_objCCC.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

            tmp_objCCC.u1_inpathcur_warn = DecideInpathcur_warn(
                tmp_objCCC.f4_range, tmp_objCCC.obj.length(),
                tmp_objCCC.f4_Heading, tmp_objCCC.f4_currentRange,
                tmp_objCCC.f4_collisionr_1,
                (tmp_objCCC.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

            bool inpathpre_after = 0;
            inpathpre_after = DecideInpathpre_after(
                tmp_objCCC.f4_range, tmp_objCCC.obj.length(),
                tmp_objCCC.f4_Heading, tmp_objCCC.u1_movingstate,
                tmp_objCCC.f4_rangeestimation, tmp_objCCC.f4_collisionr_1,
                (tmp_objCCC.f4_rangerate + ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps));

            tmp_objCCC.u1_TOI_After =
                (inpathpre_after > 0 && tmp_objCCC.u1_inpathcur > 0) ? 1 : 0;

            tmp_objCCC.u1_Inpath =
                ((tmp_objCCC.u1_inpathcur == 1) && (tmp_objCCC.u1_inpathpre == 1))
                    ? 1
                    : 0;

            tmp_objCCC.u1_Inpath_warn = ((tmp_objCCC.u1_inpathcur_warn == 1) &&
                                            (tmp_objCCC.u1_inpathpre_warn == 1))
                                            ? 1
                                            : 0;

            bool iscandi_1 = 0;
            bool iscandi_2 = 0;

            if (tmp_objCCC.objectvalid == 1 && tmp_objCCC.u1_TOI_Before == 1 &&
                tmp_objCCC.u8_AEBconf >= 2 &&
                ((tmp_objCCC.u8_col_pointN >= 1 &&
                    tmp_objCCC.u1_ageplaucheck == 1 &&
                    (tmp_objCCC.u1_Inpath_warn == 1 || tmp_objCCC.u1_Inpath == 1)) ||
                (ccc_candidate.CCC_Candi_LF_.highbrake_flag == tmp_objCCC.u8_ID ||
                    ccc_candidate.CCC_Candi_LF_.lowbrake_flag == tmp_objCCC.u8_ID ||
                    ccc_candidate.CCC_Candi_LF_2_.highbrake_flag == tmp_objCCC.u8_ID ||
                    ccc_candidate.CCC_Candi_LF_2_.lowbrake_flag == tmp_objCCC.u8_ID))) {
                if ((tmp_objCCC.f4_TTC < ccc_candidate.CCC_Candi_.f4_minTTC) ||
                    (tmp_objCCC.f4_TTC == ccc_candidate.CCC_Candi_.f4_minTTC &&
                    tmp_objCCC.f4_collisionr_1 < ccc_candidate.CCC_Candi_.f4_minRange)) {
                iscandi_1 = 1;
                } else if ((tmp_objCCC.f4_TTC < ccc_candidate.CCC_Candi_2_.f4_minTTC) ||
                        (tmp_objCCC.f4_TTC == ccc_candidate.CCC_Candi_2_.f4_minTTC &&
                            tmp_objCCC.f4_collisionr_1 < ccc_candidate.CCC_Candi_2_.f4_minRange)) {
                iscandi_2 = 1;
                } else {
                iscandi_1 = 0;
                iscandi_2 = 0;
                }
            }

            if (iscandi_1 == 1) {
                ccc_candidate.CCC_Candi_2_ = ccc_candidate.CCC_Candi_;
                ccc_candidate.CCC_Candi_ = tmp_objCCC;
                ccc_candidate.CCC_Candi_.f4_minTTC = tmp_objCCC.f4_TTC;
                ccc_candidate.CCC_Candi_.f4_minRange = tmp_objCCC.f4_collisionr_1;
            }

            if (iscandi_2 == 1) {
                ccc_candidate.CCC_Candi_2_ = tmp_objCCC;
                ccc_candidate.CCC_Candi_2_.f4_minTTC = tmp_objCCC.f4_TTC;
                ccc_candidate.CCC_Candi_2_.f4_minRange = tmp_objCCC.f4_collisionr_1;
            }
        }   
    }
    }
    ccc_candidate.CCC_Candi_.u8_Inpathage =
        CalculateInPathAge(ccc_candidate.CCC_Candi_.u1_Inpath, ccc_candidate.CCC_Candi_LF_.u8_Inpathage,
                            ccc_candidate.CCC_Candi_LF_2_.u8_Inpathage, ccc_candidate.CCC_Candi_.u8_ID,
                            ccc_candidate.CCC_Candi_LF_.u8_ID, ccc_candidate.CCC_Candi_LF_2_.u8_ID);

    ccc_candidate.CCC_Candi_.u8_Inpathage_warn = CalculateInPathAge(
        ccc_candidate.CCC_Candi_.u1_Inpath_warn, ccc_candidate.CCC_Candi_LF_.u8_Inpathage_warn,
        ccc_candidate.CCC_Candi_LF_2_.u8_Inpathage_warn, ccc_candidate.CCC_Candi_.u8_ID,
        ccc_candidate.CCC_Candi_LF_.u8_ID, ccc_candidate.CCC_Candi_LF_2_.u8_ID);

    ccc_candidate.CCC_Candi_.u1_inpathagecheck =
        DecideInPathAgeCheck(ccc_candidate.CCC_Candi_.u8_Inpathage, ccc_candidate.CCC_Candi_.u8_AEBconf);

    ccc_candidate.CCC_Candi_.u1_inpathagecheck_warn = DecideInPathAgeCheck_warn(
        ccc_candidate.CCC_Candi_.u8_Inpathage_warn, ccc_candidate.CCC_Candi_.u8_AEBconf);

    ccc_candidate.CCC_Candi_2_.u8_Inpathage =
        CalculateInPathAge(ccc_candidate.CCC_Candi_2_.u1_Inpath, ccc_candidate.CCC_Candi_LF_.u8_Inpathage,
                            ccc_candidate.CCC_Candi_LF_2_.u8_Inpathage, ccc_candidate.CCC_Candi_2_.u8_ID,
                            ccc_candidate.CCC_Candi_LF_.u8_ID, ccc_candidate.CCC_Candi_LF_2_.u8_ID);

    ccc_candidate.CCC_Candi_2_.u8_Inpathage_warn = CalculateInPathAge(
        ccc_candidate.CCC_Candi_2_.u1_Inpath_warn, ccc_candidate.CCC_Candi_LF_.u8_Inpathage_warn,
        ccc_candidate.CCC_Candi_LF_2_.u8_Inpathage_warn, ccc_candidate.CCC_Candi_2_.u8_ID,
        ccc_candidate.CCC_Candi_LF_.u8_ID, ccc_candidate.CCC_Candi_LF_2_.u8_ID);

    ccc_candidate.CCC_Candi_2_.u1_inpathagecheck = DecideInPathAgeCheck(
        ccc_candidate.CCC_Candi_2_.u8_Inpathage, ccc_candidate.CCC_Candi_2_.u8_AEBconf);

    ccc_candidate.CCC_Candi_2_.u1_inpathagecheck_warn = DecideInPathAgeCheck_warn(
        ccc_candidate.CCC_Candi_2_.u8_Inpathage_warn, ccc_candidate.CCC_Candi_2_.u8_AEBconf);

    DecideInpathTar(ccc_candidate.CCC_Candi_, ccc_candidate.CCC_Candi_LF_, ccc_candidate.CCC_Candi_LF_2_);
    DecideInpathTar(ccc_candidate.CCC_Candi_2_, ccc_candidate.CCC_Candi_LF_, ccc_candidate.CCC_Candi_LF_2_);
    
    DecideFTAPFlag(ccc_candidate.CCC_Candi_, ccc_candidate.CCC_Candi_LF_, ccc_candidate.CCC_Candi_LF_2_);
    DecideFTAPFlag(ccc_candidate.CCC_Candi_2_, ccc_candidate.CCC_Candi_LF_, ccc_candidate.CCC_Candi_LF_2_);
}

void extract_ccc::ClearCCCCandi(nio::ad::AEBObjectCCC &ccc_candi) {
    ccc_candi.obj.clear();
    ccc_candi.u8_ID = 0;
    ccc_candi.u8_IDX = MaxVisionIndex;
    ccc_candi.u8_VID = 0;
    ccc_candi.objectvalid = 0;
    ccc_candi.f4_TTC = DefaultTTC;
    ccc_candi.f4_TTL = DefaultTTL;
    ccc_candi.TTC_tar = DefaultTTC;
    ccc_candi.TTL_tar = DefaultTTL;
    ccc_candi.f4_range = DefaultRange;
    ccc_candi.f4_rangerate = 0;
    ccc_candi.f4_vissup_dx = 0;
    ccc_candi.f4_vissup_dy = 0;
    ccc_candi.f4_vissup_vx = 0;
    ccc_candi.f4_vissup_vy = 0;
    ccc_candi.u8_col_pointN = 0;
    ccc_candi.f4_collisionx_1 = DefaultCollPos;
    ccc_candi.f4_collisiony_1 = DefaultCollPos;
    ccc_candi.f4_collisionr_1 = DefaultCollPos;
    ccc_candi.f4_longpos = DefaultRange;
    ccc_candi.f4_latpos = DefaultRange;
    ccc_candi.f4_longvel = 0;
    ccc_candi.f4_latvel = 0;
    ccc_candi.f4_Heading = 0;
    ccc_candi.f4_Headangle = 0;
    ccc_candi.f4_currentRange = DefaultRange;
    ccc_candi.f4_rangeestimation = DefaultRange;
    ccc_candi.u1_inpathcur = 0;
    ccc_candi.u1_inpathpre = 0;
    ccc_candi.u1_Inpath = 0;
    ccc_candi.u1_inpathcur_warn = 0;
    ccc_candi.u1_inpathpre_warn = 0;
    ccc_candi.u1_Inpath_warn = 0;
    ccc_candi.u1_inpath_tar = 0;
    ccc_candi.u1_TOI_Before = 0;
    ccc_candi.u1_TOI_After = 0;
    ccc_candi.u1_vfplaucheck = 0;
    ccc_candi.u1_ageplaucheck = 0;
    ccc_candi.u1_inpathagecheck = 0;
    ccc_candi.u1_inpathagecheck_warn = 0;
    ccc_candi.u1_oncoming = 0;
    ccc_candi.u8_AEBconf = 0;
    ccc_candi.f4_minTTC = 0;
    ccc_candi.f4_minRange = 0;
    ccc_candi.u1_movingstate = MoveState::kInit;
    ccc_candi.warnig_flag = 0;
    ccc_candi.prefill_flag = 0;
    ccc_candi.lowbrake_flag = 0;
    ccc_candi.highbrake_flag = 0;
    ccc_candi.iba_flag = 0;
    ccc_candi.turnangle = 0;
    ccc_candi.target_spd = 0;
    ccc_candi.predictrange_tar = 0;
}

float extract_ccc::CalculateCirRange(float col_y, float ego_roc) {
  float col_r = DefaultCollPos;
  float theta_1 = 0.0f;
  if (fabsf(col_y) >= fabsf(ego_roc) && fabsf(col_y) <= 2 * fabsf(ego_roc)) {
    theta_1 = Pi - acosf((fabsf(col_y - ego_roc)) / fabsf(ego_roc));
    col_r = theta_1 * fabsf(ego_roc);
  } else if (fabsf(col_y) < fabsf(ego_roc)) {
    theta_1 = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
    col_r = theta_1 * fabsf(ego_roc);
  } else {
    col_r = DefaultCollPos;
  }
  return col_r;
}

float extract_ccc::CalculateCirX(float col_y, float longpos,
                                float latpos, float heading) {
  float col_x = DefaultCollPos;
  col_x = heading * (col_y - latpos) + longpos;
  return col_x;
}

float extract_ccc::CalculateCirTTC(float col_r1, float egospd,
                                  uint8_t col_N, float egoacc,
                                  bool AEBactive) {
  float Col_TTC = DefaultTTC;
  float Col_TTC_based = DefaultTTC;
  if (col_N >= 1) {
    Col_TTC_based = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth) / egospd;

    if (fabsf(egoacc) <= MaxEgoAccThres) {
      Col_TTC = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth) / egospd;
    } else {
      if ((egospd * egospd + 2 * egoacc * col_r1) >= 0) {
        Col_TTC =
            ((-1) * egospd +
             sqrtf(egospd * egospd +
                   2 * egoacc *
                       (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - HalfWidth))) /
            egoacc;
      } else {
        Col_TTC = DefaultTTC;
      }
    }
  } else {
    Col_TTC = DefaultTTC;
  }

  if (AEBactive == 1) {
    Col_TTC = Col_TTC_based;
  }

  return Col_TTC;
}

float extract_ccc::CalculateCirTTL(float col_r1, float egospd,
                                  uint8_t col_N, float egoacc,
                                  bool AEBactive) {
  float Col_TTC = DefaultTTC;
  float Col_TTC_based = DefaultTTC;
  if (col_N >= 1) {
    Col_TTC_based = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + RearAxleToBack) / egospd;

    if (fabsf(egoacc) <= MaxEgoAccThres) {
      Col_TTC = (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + RearAxleToBack) / egospd;
    } else {
      if ((egospd * egospd + 2 * egoacc * col_r1) >= 0) {
        Col_TTC =
            ((-1) * egospd +
             sqrtf(egospd * egospd +
                   2 * egoacc *
                       (col_r1 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + FrontSafeZone))) /
            egoacc;
      } else {
        Col_TTC = DefaultTTC;
      }
    }
  } else {
    Col_TTC = DefaultTTC;
  }

  if (AEBactive == 1) {
    Col_TTC = Col_TTC_based;
  }

  return Col_TTC;
}

float extract_ccc::CalculateCirCurRange(float longpos, float latpos,
                                       float colx, float coly,
                                       uint8_t col_N) {
  float currentrange = DefaultRange;
  if (col_N >= 1) {
    currentrange = sqrtf((longpos - colx) * (longpos - colx) +
                         (latpos - coly) * (latpos - coly));
  } else {
    currentrange = DefaultRange;
  }

  return currentrange;
}

float extract_ccc::CalculateCirPreRange(float longpos, float latpos,
                                       float longspd, float latspd,
                                       float TTC, float colx,
                                       float coly, uint8_t col_N,
                                       float longacc, float latacc) {
  float predx = DefaultPos;
  float predy = DefaultPos;
  float predr = DefaultPos;
  predx = longpos + longspd * TTC + 0.5 * longacc * TTC * TTC;
  predy = latpos + latspd * TTC + 0.5 * latacc * TTC * TTC;
  if (col_N >= 1) {
    predr = sqrtf((predx - colx) * (predx - colx) +
                  (predy - coly) * (predy - coly));
  } else {
    predr = DefaultPos;
  }
  return predr;
}

MoveState extract_ccc::DecideMoveState(float longpos, float latpos,
                                    float longspd, float latspd,
                                    float TTC, float ROC) {
  float predx = DefaultPos;
  float predy = DefaultPos;
  predx = longpos + longspd * TTC;
  predy = latpos + latspd * TTC;
  float rangeroc = DefaultRangeRoc;
  float predroc = DefaultPredRoc;

  rangeroc = longpos * longpos + (latpos - ROC) * (latpos - ROC);
  predroc = predx * predx + (predy - ROC) * (predy - ROC);

  if (((rangeroc >= ROC * ROC) && (predroc <= ROC * ROC)) ||
      ((rangeroc <= ROC * ROC) && (predroc >= ROC * ROC))) {
    return MoveState::kMoving_through ;
  }
  return MoveState::kInit;
}

bool extract_ccc::CCR_VF_Longpos_check(float fusionLongPos,
                                      float visionLongPos,
                                      float Rangerate, float egoacc) {
  float LongPosError;
  LongPosError =
      threshold_CCR_LongPos_VFcheck_.interpolate(fusionLongPos, Rangerate);
  if (fabsf(egoacc) >= MaxCcrVfCheckEgoAcc) {
    return 1;
  } else {
    if (fabsf(fusionLongPos - visionLongPos - (ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle - ego_->vehicle_info.arb_vehicle.epm_pos_to_front_bumper)) <= LongPosError) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ccc::CCR_Age_check(bool isfusion, bool isradar, bool isvision,
                               size_t tracklet_count, uint8_t age) {
  //vis age turn into 20 for tempo test;
  if ((isfusion == 1 && age >= MinFusionObjAge) ||
      (isradar == 1 && tracklet_count >= 2 && age >= MinRadarObjAge) ||
      (isradar == 1 && tracklet_count == 1 && age >= MinRadarObjAge) ||
      (isvision == 1 && age >= MinVisionObjAge)) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccc::DecideTargetOncoming(float longvel, float range) {
  bool isoncoming = 0;
  float oncomingspdthreshold = -1000.0f;
  oncomingspdthreshold = threshold_CCC_OncomingSpd_.interpolate(range);
  if (longvel <= oncomingspdthreshold) {
    isoncoming = 1;
  } else {
    isoncoming = 0;
  }
  return isoncoming;
}

float extract_ccc::CalculateCirAngle(float col_y, float ego_roc) {
  float CirAngle = 0.0;

  if (col_y < 0 && col_y > ego_roc) {
    CirAngle = (acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc))) * (-1);
  } else if (col_y < 0 && col_y <= ego_roc && col_y >= (ego_roc)*2) {
    CirAngle = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc)) - Pi;
  } else if (col_y >= 0 && col_y < ego_roc) {
    CirAngle = acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
  } else if (col_y >= 0 && col_y >= ego_roc && col_y <= (ego_roc)*2) {
    CirAngle = Pi - acosf(fabsf(col_y - ego_roc) / fabsf(ego_roc));
  } else {
    CirAngle = 0;
  }

  return CirAngle;
}

uint8_t extract_ccc::DecideCCR_AEBConf(bool isfusion, bool isfused,
                                      bool isvision, bool isradar,
                                      float matchconf) {
  if ((isfusion == 1 && matchconf >= MatchConfThres)) {
    return 3;
  } else if ((((isvision == 1 && isfused == 1) /*(||
               (isradar == 1 && isfused == 1)*/) &&
              matchconf >= MatchConfThres) ||
             (isfusion == 1 && matchconf >= MinConfThres && matchconf < MatchConfThres)) {
    return 2;
  } else if (((isvision == 1 || isradar == 1) && isfused == 0 &&
             matchconf >= MatchConfThres) || (isradar == 1 && isfused == 1 && matchconf >= MatchConfThres)) {
    return 1;
  } else {
    return 0;
  }
}

uint8_t extract_ccc::DecideCCCTOI(float range, float longvel,
                                  float latvel, float targetangle,
                                  bool isoncoming, float egospd) {
  float FTAPRangeThres = 0.0f;
  bool isinrange = 0;
  bool spdinrange = 0;
  bool anginrange = 0;
  bool isinTOI = 0;

  float targetspd = 0.0f;

  FTAPRangeThres = threshold_CCC_range_.interpolate(egospd);
  targetspd = sqrtf(longvel * longvel + latvel * latvel);

  isinrange = (range <= FTAPRangeThres) ? 1 : 0;

  spdinrange = (targetspd >= ToiTargetSpdThrs) ? 1 : 0;

  anginrange = (fabsf(targetangle) <= MaxToiTargetAngle && fabsf(targetangle) >= MinToiTargetAngle) ? 1 : 0;

  isinTOI = (isinrange && spdinrange && anginrange) ? 1 : 0;

  return isinTOI;
}

bool extract_ccc::DecideInpathpre(float range, float targetlength,
                                 float headingangle, MoveState movestate,
                                 float rangeestimate, float ColRange,
                                 float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_CCC_predict_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_CCC_expend_predict_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((rangeestimate <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (rangeestimate <= predictside) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ccc::DecideInpathpre_warn(float range, float targetlength,
                                      float headingangle, MoveState movestate,
                                      float rangeestimate, float ColRange,
                                      float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_CCC_predict_warn_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_CCC_expend_predict_warn_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((rangeestimate <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (rangeestimate <= predictside) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_ccc::DecideInpathcur(float range, float targetlength,
                                 float headingangle, float rangecur,
                                 float ColRange, float targetspd) {
  float currentrange = 0.0f;
  currentrange = threshold_CCC_current_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float currentexpandrange = 0.0f;
  currentexpandrange =
      threshold_CCC_expend_current_.interpolate(targetspd, ColRange);

  float currentside = 0.0f;
  currentside = currentrange + currentexpandrange;

  if (rangecur <= currentside) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccc::DecideInpathcur_warn(float range, float targetlength,
                                      float headingangle, float rangecur,
                                      float ColRange, float targetspd) {
  float currentrange = 0.0f;
  currentrange = threshold_CCC_current_warn_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float currentexpandrange = 0.0f;
  currentexpandrange =
      threshold_CCC_expend_current_warn_.interpolate(targetspd, ColRange);

  float currentside = 0.0f;
  currentside = currentrange + currentexpandrange;

  if (rangecur <= currentside) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_ccc::DecideInpathpre_after(float range, float targetlength,
                                       float headingangle, MoveState movestate,
                                       float rangeestimate,
                                       float ColRange, float targetspd) {
  float predictrange = 0.0f;
  predictrange = threshold_CCC_predict_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, ColRange);

  float predictexpandrange = 0.0f;
  predictexpandrange =
      threshold_CCC_expend_predict_.interpolate(targetspd, ColRange);

  float predictexpand_after = 0.0f;
  predictexpand_after =
      threshold_CCC_expend_predict_after_.interpolate(targetspd, ColRange);

  float predictside = 0.0f;
  predictside = predictrange + predictexpandrange;

  float targetlength_filtered = 0.0f;
  if (targetlength >= TargetLengthThres) {
    targetlength_filtered = targetlength;
  }
  else {
    targetlength_filtered = TargetLengthThres;
  }

  if (movestate == MoveState::kMoving_through) {
    if ((rangeestimate <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= predictside) ||
        ((rangeestimate - targetlength_filtered - ego_->vehicle_info.arb_vehicle.width * 0.5) <= 0.0f)) {
      return 1;
    } else {
      return 0;
    }
  } else {
    if (rangeestimate <= predictside + predictexpand_after) {
      return 1;
    } else {
      return 0;
    }
  }
}

uint8_t extract_ccc::CalculateInPathAge(bool inpath, uint8_t inpathage_1,
                                       uint8_t inpathage_2, uint8_t ID,
                                       uint8_t ID_1, uint8_t ID_2) {
  uint8_t inpathage = 0;

  if (ID == ID_1) {
    inpathage = inpathage_1;
  } else if (ID == ID_2) {
    inpathage = inpathage_2;
  } else {
    inpathage = 0;
  }

  if (inpath == 1) {
    inpathage++;
  } else {
    if (inpathage >= InPathAgeStep) {
      inpathage = inpathage - InPathAgeStep;
    } else {
      inpathage = 0;
    }
  }
  if (inpathage >= MaxInpathAge) {
    inpathage = MaxInpathAge;
  }
  return inpathage;
}

bool extract_ccc::DecideInPathAgeCheck(uint8_t inpathage, uint8_t AEBconf) {
  uint8_t inpathage_threshold = 0;
  inpathage_threshold = threshold_CCC_InPathAge_.interpolate(AEBconf);

  bool inpathage_check = 0;
  inpathage_check = (inpathage >= inpathage_threshold) ? 1 : 0;

  return inpathage_check;
}

bool extract_ccc::DecideInPathAgeCheck_warn(uint8_t inpathage, uint8_t AEBconf) {
  uint8_t inpathage_threshold = 0;
  inpathage_threshold = threshold_CCC_InPathAge_warn_.interpolate(AEBconf);

  bool inpathage_check = 0;
  inpathage_check = (inpathage >= inpathage_threshold) ? 1 : 0;

  return inpathage_check;
}

void extract_ccc::DecideInpathTar(AEBObjectCCC &Candi, AEBObjectCCC &Candi_LF, AEBObjectCCC &Candi_LF2) {
  float targetlength = 0;
  if (Candi.obj.length() > TargetLengthThres) {
    targetlength = Candi.obj.length();
  }
  else {
    targetlength = TargetLengthThres;
  }
  
  feature::math::Vector2f MidVect;
  Candi.HostPos_tar.x = 0;
  Candi.HostPos_tar.y = 0;
  Candi.HostPos.x = ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle;
  Candi.HostPos.y = 0;
  Candi.turnangle = 0;
  Candi.turnangle = Degree90ToRad + Candi.f4_Headangle;
  feature::math::Matrix2f rotate_m = feature::math::from_angle(Candi.turnangle);
  
  MidVect.x = Candi.HostPos.x - Candi.obj.motion.GetPos().x;
  MidVect.y = Candi.HostPos.y - Candi.obj.motion.GetPos().y;

  Candi.HostPos_tar = rotate_m * MidVect;
  Candi.HostVel.x = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * sinf(Candi.turnangle + Degree90ToRad);
  Candi.HostVel.y = ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * cosf(Candi.turnangle + Degree90ToRad) * (-1);
  Candi.target_spd = sqrtf(Candi.obj.motion.GetVx() * Candi.obj.motion.GetVx() + Candi.obj.motion.GetVy() * Candi.obj.motion.GetVy());
  Candi.TTC_tar = (Candi.f4_currentRange - ego_->vehicle_info.arb_vehicle.width*(0.5) - 1)/Candi.target_spd;
  Candi.TTL_tar = (Candi.f4_currentRange + targetlength + ego_->vehicle_info.arb_vehicle.width*(0.5) + 1)/Candi.target_spd;
  Candi.predictrange_tar = Candi.HostPos_tar.y + Candi.HostVel.y * Candi.TTC_tar;

  bool timeinrange = 0;
  // bool hostinrange = 0;
  // bool hostmovingin = 0;
  timeinrange = (((Candi.f4_TTC >= Candi.TTC_tar) && (Candi.f4_TTC <= Candi.TTL_tar))||((Candi.f4_TTL >= Candi.TTC_tar) && (Candi.f4_TTL <= Candi.TTL_tar))) ?1:0;

  // hostinrange = (Candi.HostPos_tar.y >= -3.8 && Candi.HostPos_tar.y <= -1.0 && Candi.predictrange_tar >= Candi.HostPos_tar.y) ?1:0;
  
  // hostmovingin = ((Candi.HostPos_tar.y > 0 && Candi.HostVel.y < 0) || (Candi.HostPos_tar.y <= 0 && Candi.HostVel.y >= 0)) ?1:0;
  
  Candi.u1_inpath_tar = (timeinrange /*&& hostinrange && hostmovingin*/);
}

void extract_ccc::DecideFTAPFlag(AEBObjectCCC &Candi, AEBObjectCCC &Candi_LF, AEBObjectCCC &Candi_LF2) {
  float warningTTC = 0.0f;
  float prefillTTC = 0.0f;
  float lowBTTC = 0.0f;
  float highBTTC = 0.0f;

  Candi.highbrake_flag = 0;
  Candi.lowbrake_flag = 0;
  Candi.prefill_flag = 0;
  Candi.warnig_flag = 0;
  Candi.iba_flag = 0;

  warningTTC =
      threshold_CCC_WarningTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  prefillTTC =
      threshold_CCC_PrefillTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  lowBTTC =
      threshold_CCC_LowBrakeTTC_.interpolate(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  highBTTC = threshold_CCC_HighBrakeTTC_.interpolate(
      ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

  if (fcw_sensitive == 0) {
    warningTTC = warningTTC + WarnTTCBuffer;
  }
  else if (fcw_sensitive == 2) {
    warningTTC = warningTTC - WarnTTCBuffer;
  }

  uint8_t lastBrakeActive = 0;
  uint8_t lastBrakeActive_2 = 0;
  uint8_t lastIBAActive = 0;
  uint8_t lastIBAActive_2 = 0;

  if (Candi_LF.highbrake_flag > 0 || Candi_LF.lowbrake_flag > 0) {
    lastBrakeActive = Candi_LF.u8_ID;
  }

  if (Candi_LF2.highbrake_flag > 0 || Candi_LF2.lowbrake_flag > 0) {
    lastBrakeActive_2 = Candi_LF2.u8_ID;
  }

  lastIBAActive = (Candi_LF.iba_flag > 0)?1:0;
  lastIBAActive_2 = (Candi_LF2.iba_flag > 0)?1:0;

  if (Candi.u1_Inpath == 1 || Candi.u1_TOI_After == 1) {
    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= highBTTC && //AEBSupressReason_SpeedLow == 0 &&
           //AEBSupressReason_CCFTAP == 0x0000
           ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000) ) ||
          (Candi.u8_ID == Candi_LF.highbrake_flag &&
           Candi_LF.highbrake_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.highbrake_flag &&
           Candi_LF2.highbrake_flag > 0))) &&
        //AEBSupressReason_AfterHighB == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.highbrake_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= lowBTTC && //AEBSupressReason_SpeedLow == 0 &&
           //AEBSupressReason_CCFTAP == 0x0000
           ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.lowbrake_flag &&
           Candi_LF.lowbrake_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.lowbrake_flag &&
           Candi_LF2.lowbrake_flag > 0)) &&
         (Candi.highbrake_flag != Candi.u8_ID)) &&
        //AEBSupressReason_AfterLowB == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.lowbrake_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck_warn == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastBrakeActive ||
           Candi.u8_ID == lastBrakeActive_2)) &&
         ((Candi.f4_TTC <= prefillTTC && //AEBSupressReason_SpeedLow == 0 &&
           //AEBSupressReason_CCFTAP == 0x0000
           ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) ||
          (Candi.u8_ID == Candi_LF.prefill_flag && Candi_LF.prefill_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.prefill_flag &&
           Candi_LF2.prefill_flag > 0)) &&
         (Candi.highbrake_flag != Candi.u8_ID &&
          Candi.lowbrake_flag != Candi.u8_ID)) &&
        //AEBSupressReason_AfterPref == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.prefill_flag = Candi.u8_ID;
    }

    if (((Candi.u1_inpathagecheck_warn == 1 && Candi.u1_TOI_Before == 1 &&
          Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) &&
         (Candi.f4_TTC <= warningTTC && //AEBSupressReason_SpeedLow == 0 &&
          //AEBSupressReason_CCFTAP == 0x0000
          ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000)) &&
         (Candi.highbrake_flag != Candi.u8_ID &&
          Candi.lowbrake_flag != Candi.u8_ID &&
          Candi.prefill_flag != Candi.u8_ID)) &&
        //AEBSupressReason == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.warnig_flag = Candi.u8_ID;
    }

    if ((((Candi.u1_inpathagecheck == 1 && Candi.u1_TOI_Before == 1 &&
           Candi.u1_ageplaucheck == 1 && Candi.u1_inpath_tar == 1) ||
          (Candi.u8_ID == lastIBAActive ||
           Candi.u8_ID == lastIBAActive_2)) &&
         ((Candi.f4_TTC <= prefillTTC && //AEBSupressReason_SpeedLow == 0x0000
         ((drimonitor.output_.suppressbit & 0x00400000) == 0x00000000) ) ||
          (Candi.u8_ID == Candi_LF.iba_flag &&
           Candi_LF.iba_flag > 0) ||
          (Candi.u8_ID == Candi_LF2.iba_flag &&
           Candi_LF2.iba_flag > 0))) &&
        //AEBSupressReason_IBA == 0x0000
        ((drimonitor.output_.abortbit & 0x00400000) == 0x00000000)) {
      Candi.iba_flag = Candi.u8_ID;
    }
  } else {
    Candi.highbrake_flag = 0;
    Candi.lowbrake_flag = 0;
    Candi.prefill_flag = 0;
    Candi.warnig_flag = 0;
    Candi.iba_flag = 0;
  }
}

}
}