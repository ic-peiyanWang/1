#include <iostream>
#include "aeb_extract_vru.h"
#include "aeb_calibration.h"
#include "aeb_dm.h"
#include "aeb_gof.h"
#include "ehy_math/nio_vmath.h"
#include "fcts_loc_cfg.h"
#include "niodds/application/application.h"

namespace nio {
namespace ad {

extract_vru vru_extraction_;

void extract_vru::MainFunction() {
  UpdateCalibration();
  ExtractPed();
}

extract_vru::extract_vru() {}

void extract_vru::UpdateCalibration() {
  size_t longpos_cal = sizeof(EAEB_dstVFcheck_LongPos_x) / sizeof(EAEB_dstVFcheck_LongPos_x[0]);
  threshold_visionfusion_vel_plaus_.init(EAEB_dstVFcheck_LongPos_x, EAEB_dstVFcheck_LatPos_v, longpos_cal);
  threshold_visionfusion_pos_plaus_.init(EAEB_dstVFcheck_LongPos_x, EAEB_spdVFcheck_LatVel_v, longpos_cal);
  threshold_longmove_decide_.init(EAEB_dstVFcheck_LongPos_x, EAEB_spdLongMove_LongVel_v, longpos_cal);
  threshold_latmove_decide_.init(EAEB_dstVFcheck_LongPos_x, EAEB_spdLatMove_LatVel_v, longpos_cal);

  size_t conf_cal = sizeof(EAEB_agecheck_AEBconf_x) / sizeof(EAEB_agecheck_AEBconf_x[0]);
  threshold_crossageplau_.init(EAEB_agecheck_AEBconf_x, EAEB_agecross_ageplau_v, conf_cal);
  threshold_longageplau_.init(EAEB_agecheck_AEBconf_x, EAEB_agelongmove_ageplau_v, conf_cal);
  threshold_crossage_.init(EAEB_agecheck_AEBconf_x, EAEB_agecross_age_v, conf_cal);
  threshold_crossage_turn_.init(EAEB_agecheck_AEBconf_x, EAEB_agecross_age_turn_v, conf_cal);
  threshold_longage_.init(EAEB_agecheck_AEBconf_x, EAEB_agelongmove_age_v, conf_cal);
  threshold_crossage_warn_.init(EAEB_agecheck_AEBconf_x, EAEB_agecross_age_warn_v, conf_cal);
  threshold_crossage_turn_warn_.init(EAEB_agecheck_AEBconf_x, EAEB_agecross_age_turn_warn_v, conf_cal);
  threshold_longage_warn_.init(EAEB_agecheck_AEBconf_x, EAEB_agelongmove_age_warn_v, conf_cal);

  size_t hostspd_cal = sizeof(EAEB_spdSide_hostspd_x) / sizeof(EAEB_spdSide_hostspd_x[0]);
  size_t range_cal   = sizeof(EAEB_disSide_range_y) / sizeof(EAEB_disSide_range_y[0]);
  threshold_longmove_predict_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredLongPedBik_v, hostspd_cal,
                                   range_cal);
  threshold_cross_predict_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredCrossPedBik_v, hostspd_cal,
                                range_cal);
  threshold_stationary_predict_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredStatPedBik_v,
                                     hostspd_cal, range_cal);
  threshold_longmove_current_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrLongPedBik_v, hostspd_cal,
                                   range_cal);
  threshold_cross_current_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrCrossPedBik_v, hostspd_cal,
                                range_cal);
  threshold_stationary_current_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrStatPedBik_v,
                                     hostspd_cal, range_cal);

  threshold_longmove_predict_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredLongPedBik_warn_v,
                                        hostspd_cal, range_cal);
  threshold_cross_predict_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredCrossPedBik_warn_v,
                                     hostspd_cal, range_cal);
  threshold_stationary_predict_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstPredStatPedBik_warn_v,
                                          hostspd_cal, range_cal);
  threshold_longmove_current_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrLongPedBik_warn_v,
                                        hostspd_cal, range_cal);
  threshold_cross_current_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrCrossPedBik_warn_v,
                                     hostspd_cal, range_cal);
  threshold_stationary_current_warn_.init(EAEB_spdSide_hostspd_x, EAEB_disSide_range_y, EAEB_dstCurrStatPedBik_warn_v,
                                          hostspd_cal, range_cal);

  size_t latspd_cal = sizeof(EAEB_spdExpand_Latvel_x) / sizeof(EAEB_spdExpand_Latvel_x[0]);
  threshold_cross_expend_predict.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y, EAEB_dstPredExpandSide_v,
                                      latspd_cal, range_cal);
  threshold_cross_expend_current.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y, EAEB_dstCurrExpandSide_v,
                                      latspd_cal, range_cal);
  threshold_cross_expend_predict_warn_.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y,
                                            EAEB_dstPredExpandSide_warn_v, latspd_cal, range_cal);
  threshold_cross_expend_current_warn_.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y,
                                            EAEB_dstCurrExpandSide_warn_v, latspd_cal, range_cal);
  threshold_cross_expend_predict_Bik.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y, EAEB_dstPredExpandSide_Bik_v,
                                          latspd_cal, range_cal);
  threshold_cross_expend_current_Bik.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y, EAEB_dstCurrExpandSide_Bik_v,
                                          latspd_cal, range_cal);
  threshold_cross_expend_predict_warn_Bik.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y,
                                               EAEB_dstPredExpandSide_Bik_warn_v, latspd_cal, range_cal);
  threshold_cross_expend_current_warn_Bik.init(EAEB_spdExpand_Latvel_x, EAEB_disSide_range_y,
                                               EAEB_dstCurrExpandSide_Bik_warn_v, latspd_cal, range_cal);

  size_t ttcEgoSpd_cal = sizeof(EAEB_TTCPedBik_Egospd_x) / sizeof(EAEB_TTCPedBik_Egospd_x[0]);
  threshold_prefill_crossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossPed_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_rearcrossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCRearCrossPed_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_crossbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossBik_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_precedped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedPed_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_precedbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedBik_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_oncomped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomPed_Pref_v, ttcEgoSpd_cal);
  threshold_prefill_oncombik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomBik_Pref_v, ttcEgoSpd_cal);
  threshold_warn_crossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossPed_Warn_v, ttcEgoSpd_cal);
  threshold_warn_rearcrossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCRearCrossPed_Warn_v, ttcEgoSpd_cal);
  threshold_warn_crossbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossBik_Warn_v, ttcEgoSpd_cal);
  threshold_warn_precedped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedPed_Warn_v, ttcEgoSpd_cal);
  threshold_warn_precedbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedBik_Warn_v, ttcEgoSpd_cal);
  threshold_warn_oncomped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomPed_Warn_v, ttcEgoSpd_cal);
  threshold_warn_oncombik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomBik_Warn_v, ttcEgoSpd_cal);
  threshold_lowbrake_crossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossPed_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_rearcrossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCRearCrossPed_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_crossbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossBik_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_precedped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedPed_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_precedbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedBik_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_oncomped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomPed_LowB_v, ttcEgoSpd_cal);
  threshold_lowbrake_oncombik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomBik_LowB_v, ttcEgoSpd_cal);
  threshold_highbrake_crossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossPed_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_rearcrossped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCRearCrossPed_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_crossbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCCrossBik_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_precedped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedPed_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_precedbik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCPrecedBik_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_oncomped.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomPed_HigB_v, ttcEgoSpd_cal);
  threshold_highbrake_oncombik.init(EAEB_TTCPedBik_Egospd_x, EAEB_TTCOncomBik_HigB_v, ttcEgoSpd_cal);
}

void extract_vru::ExtractPed() {
  // std::cout << "extractped start"<<std::endl;
  // auto ts = Time::Now();
  vru_candidate.pedestrian_cross_Candidate_.u8_lastselectID = vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID;
  vru_candidate.bicycle_cross_Candidate_.u8_lastselectID    = vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID;
  vru_candidate.pedestrian_oncom_Candidate_.u8_lastselectID = vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID;
  vru_candidate.bicycle_oncom_Candidate_.u8_lastselectID    = vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_lastselectID =
    vru_candidate.pedestrian_rearcross_Candidate_.u8_Candi_ID;
  vru_candidate.bicycle_rearcross_Candidate_.u8_lastselectID = vru_candidate.bicycle_rearcross_Candidate_.u8_Candi_ID;

  vru_candidate.pedestrian_cross_Candidate_LF_     = vru_candidate.pedestrian_cross_Candidate_;
  vru_candidate.bicycle_cross_Candidate_LF_        = vru_candidate.bicycle_cross_Candidate_;
  vru_candidate.pedestrian_oncom_Candidate_LF_     = vru_candidate.pedestrian_oncom_Candidate_;
  vru_candidate.bicycle_oncom_Candidate_LF_        = vru_candidate.bicycle_oncom_Candidate_;
  vru_candidate.pedestrian_rearcross_Candidate_LF_ = vru_candidate.pedestrian_rearcross_Candidate_;
  vru_candidate.bicycle_rearcross_Candidate_LF_    = vru_candidate.bicycle_rearcross_Candidate_;

  clearCandidate();
  pedestrian_LF_ = pedestrian_;
  pedestrian_.clear();
  for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
    if (fused_obj_filtered.at(i).gofcheck.check_valid == true) {
      if ((fused_obj_filtered.at(i).raw_data.classification.IsVRU()
           || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike())
          && fused_obj_filtered.at(i).raw_data.IsValid()) {
        AEBObject tmp_obj;
        tmp_obj.obj     = fused_obj_filtered.at(i).raw_data;
        tmp_obj.ref_pos = fused_obj_filtered.at(i).ref_pos;
        tmp_obj.u8_ID   = fused_obj_filtered.at(i).raw_data.GetID();
        uint32_t vision_ID;
        vision_ID      = VisMatchID_[i].vis_id;
        tmp_obj.u8_VID = fused_obj_filtered.at(i).raw_data.fusion_sup.vision.ID;
        if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID && vision_ID != MaxVisionIndex) {
          tmp_obj.u8_VID = vis_obj_->at(vision_ID).ID;
        } else {
          tmp_obj.u8_VID = 0;
        }
        tmp_obj.lastcyclesize = 0;
        for (size_t j = 0; j < pedestrian_LF_.size(); j++) {
          if (pedestrian_LF_[j].u8_ID == tmp_obj.u8_ID
              || (pedestrian_LF_[j].obj.fusion_sup.vision.ID == tmp_obj.u8_VID && kVisionIDCheckEnable == 1)) {
            tmp_obj.lastcyclesize = j;
            break;
          } else {
            tmp_obj.lastcyclesize = MaxFusedObjIndex;
            continue;
          }
        }
        tmp_obj.objectvalid = fused_obj_filtered.at(i).raw_data.IsValid();
        tmp_obj.f4_range    = sqrtf(powf((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                       - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                      2)
                                 + powf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y, 2));

        tmp_obj.f4_range_rear = 0;
        tmp_obj.f4_range_rear = sqrtf(powf((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + LengthBuffer1), 2)
                                      + powf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y, 2));

        tmp_obj.f4_rangerate =
          fused_obj_filtered.at(i).raw_data.motion.GetVx() - ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        float ego_ROC   = 0;
        ego_ROC         = ROC(fabsf(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps), ego_state_aeb.yawrate);
        tmp_obj.f4_XOLC = fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y
                          - deltay(ego_ROC, tmp_obj.f4_range, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps);

        float Target_Angle = 0.0f;
        if ((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
             - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + LengthBuffer2)
            == 0.0f) {
          if (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y > 0) {
            Target_Angle = Degree90ToRad;
          } else if (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y < 0) {
            Target_Angle = -Degree90ToRad;
          } else {
            Target_Angle = 0.0;
          }
        } else {
          Target_Angle = atanf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y
                               / (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                  - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle + LengthBuffer2));
        }

        float Target_Angle_rear = 0.0f;
        if ((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + LengthBuffer1) == 0.0f) {
          if (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y > 0) {
            Target_Angle_rear = Degree90ToRad;
          } else if (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y < 0) {
            Target_Angle_rear = -Degree90ToRad;
          } else {
            Target_Angle_rear = 0.0;
          }
        } else {
          Target_Angle_rear = atanf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y
                                    / ((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + LengthBuffer1) * -1));
        }

        tmp_obj.f4_targetangle = Target_Angle;

        tmp_obj.f4_targetangle_rear = Target_Angle_rear;

        tmp_obj.f4_TTC =
          CalPedTTC(tmp_obj.f4_rangerate, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2), tmp_obj.f4_range,
                    ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, lfbrake_active);

        tmp_obj.f4_TTC_rear = DefaultTTC;
        tmp_obj.f4_TTC_rear =
          CalPedTTC_rear(tmp_obj.f4_rangerate, (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2),
                         tmp_obj.f4_range_rear, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, lfbrake_active);

        tmp_obj.u1_TOI = (fabsf(tmp_obj.f4_XOLC) <= VruToiXolcThres
                          && fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()) <= VruToiVyThres
                          && (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                              - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle)
                               <= VruToiDistThres
                          && fabsf(tmp_obj.f4_targetangle) <= Degree40ToRad
                          && (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                              - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle)
                               >= 0.0f)
                           ? 1
                           : 0;

        tmp_obj.u1_TOI_rear = 0;
        tmp_obj.u1_TOI_rear =
          (fabsf(tmp_obj.f4_XOLC) <= VruToiRearXolcThres
           && fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()) <= VruToiRearVyThres
           && (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + LengthBuffer1) >= VruToiRearDistThres
           && (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + LengthBuffer1) <= 0.0F
           && fabsf(tmp_obj.f4_targetangle) <= Degree45ToRad)
            ? 1
            : 0;

        if ((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
             - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle)
              <= ToiRangeThres
            && fabsf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y) >= ToiYThres) {
          tmp_obj.u1_TOI = 0;
        }

        if ((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x + ToiYThres) >= -ToiRangeThres
            && fabsf(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y) >= ToiYThres) {
          tmp_obj.u1_TOI_rear = 0;
        }

        if (vis_obj_->size() != 0 && vis_obj_->size() >= vision_ID && vision_ID != MaxVisionIndex) {
          tmp_obj.f4_vissup_dy = vis_obj_->at(vision_ID).motion.GetY();
          tmp_obj.f4_vissup_vy = vis_obj_->at(vision_ID).motion.GetVy();
        }

        tmp_obj.u8_AEBconf = decidePedAEBConf(tmp_obj);
        tmp_obj.u1_vfplaucheck = visionfusioncheck(fused_obj_filtered.at(i).ref_pos.referencepoint.pos_y,
                                                   fused_obj_filtered.at(i).raw_data.motion.GetVy(),
                                                   tmp_obj.f4_vissup_dy, tmp_obj.f4_vissup_vy,
                                                   (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                                    - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                                   (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2));

        tmp_obj.u1_vfplaucheck = 1;

        if (pedestrian_LF_.size() == 0 || tmp_obj.lastcyclesize == MaxFusedObjIndex) {
          tmp_obj.u1_lfplaucheck = 0;
          tmp_obj.u1_longmove    = DecideLongMoveNew((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                                   - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                                  fused_obj_filtered.at(i).raw_data.motion.GetVx());
          tmp_obj.u1_latmove     = DecideLatMoveNew((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                                 - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                                fused_obj_filtered.at(i).raw_data.motion.GetVy());
        } else {
          tmp_obj.u1_lfplaucheck = lastframecheck(fused_obj_filtered.at(i).raw_data.motion.GetY(),
                                                  fused_obj_filtered.at(i).raw_data.motion.GetVy(),
                                                  pedestrian_LF_[tmp_obj.lastcyclesize].obj.motion.GetY(),
                                                  pedestrian_LF_[tmp_obj.lastcyclesize].obj.motion.GetVy(),
                                                  (fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                                   - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                                  (ego_->vehicleinfo_in.vehicledynamic.LgtAg * G_ms2));
          tmp_obj.u1_longmove    = DecideLongMove((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                                - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                               fused_obj_filtered.at(i).raw_data.motion.GetVx(),
                                               pedestrian_LF_[tmp_obj.lastcyclesize].u1_longmove);
          tmp_obj.u1_latmove     = DecideLatMove((fused_obj_filtered.at(i).ref_pos.referencepoint.pos_x
                                              - ego_->vehicle_info.arb_vehicle.front_bumper_to_rear_axle),
                                             fused_obj_filtered.at(i).raw_data.motion.GetVy(),
                                             pedestrian_LF_[tmp_obj.lastcyclesize].u1_latmove);
        }

        float target_head = tmp_obj.obj.motion.GetHead();
        bool targetheadcross = ((target_head > 1.046 && target_head < 2.093) || (target_head < -1.046 && target_head > -2.093)) ?1:0;

        tmp_obj.u1_crossing = ((fused_obj_filtered.at(i).raw_data.motion_status.IsMovable()
                                || fused_obj_filtered.at(i).raw_data.motion_status.IsMoving())
                               && tmp_obj.u1_latmove == 1 && targetheadcross == 1)
                                ? 1
                                : 0;
        tmp_obj.u1_oncoming =
          ((fused_obj_filtered.at(i).raw_data.motion_status.IsMovable()
            || fused_obj_filtered.at(i).raw_data.motion_status.IsMoving())
           && tmp_obj.u1_longmove == 1
           && ((fused_obj_filtered.at(i).raw_data.motion.GetVx() < OncVxThres && hostReverse == 0)
               || (fused_obj_filtered.at(i).raw_data.motion.GetVx() > OncVxRearThres && hostReverse == 1)))
            ? 1
            : 0;
        tmp_obj.u1_preceding =
          ((fused_obj_filtered.at(i).raw_data.motion_status.IsMovable()
            || fused_obj_filtered.at(i).raw_data.motion_status.IsMoving())
           && ((tmp_obj.u1_longmove == 1
           && ((fused_obj_filtered.at(i).raw_data.motion.GetVx() > PrecVxThres && hostReverse == 0)
               || (fused_obj_filtered.at(i).raw_data.motion.GetVx() < PrecVxRearThres && hostReverse == 1))) || (tmp_obj.u1_latmove == 1 && targetheadcross == 0)))
            ? 1
            : 0;
        // temporary solution for fusion target ismoving character issue for
        // stationary target --> Hong Taowen 20210207
        bool targetisMoving = 0;
        if (tmp_obj.u1_crossing == 0 && tmp_obj.u1_oncoming == 0 && tmp_obj.u1_preceding == 0) {
          targetisMoving = 0;
        } else {
          targetisMoving = 1;
        }

        tmp_obj.u1_stationary = 0;
        if (targetisMoving == 0) {
          tmp_obj.u1_stationary = 1;
        }

        //======================================================
        tmp_obj.u1_ageplaucheck = agecheck(
          fused_obj_filtered.at(i).raw_data.fusion_sup.age, tmp_obj.u1_crossing, tmp_obj.u1_oncoming,
          tmp_obj.u1_preceding, fused_obj_filtered.at(i).raw_data.motion_status.IsMovable(), tmp_obj.u8_AEBconf);

        if (hostReverse == 0) {
          tmp_obj.f4_latpos_est =
            CalLatPosEst(tmp_obj.f4_XOLC, fused_obj_filtered.at(i).raw_data.motion.GetVy(), tmp_obj.f4_TTC);
        } else {
          tmp_obj.f4_latpos_est =
            CalLatPosEst(tmp_obj.f4_XOLC, fused_obj_filtered.at(i).raw_data.motion.GetVy(), tmp_obj.f4_TTC_rear);
        }

        //======================================================
        // patch for bicycle target in ME, may not be needed in Orin
        //======================================================
        float headangle = 0.0f;
        if (fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVx()) < 0.1f) {
          if (fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()) < ToiLatVelThres) {
            headangle = fused_obj_filtered.at(i).raw_data.motion.GetHead();
          } else {
            if (fused_obj_filtered.at(i).raw_data.motion.GetVy() > 0) {
              headangle = Degree90ToRad;
            } else {
              headangle = -Degree90ToRad;
            }
          }
        } else {
          if (fused_obj_filtered.at(i).raw_data.motion.GetVx() >= 0) {
            headangle = atanf(fused_obj_filtered.at(i).raw_data.motion.GetVy()
                              / fused_obj_filtered.at(i).raw_data.motion.GetVx());
          } else {
            if (fused_obj_filtered.at(i).raw_data.motion.GetVy() >= 0) {
              headangle = Pi
                          + atanf(fused_obj_filtered.at(i).raw_data.motion.GetVy()
                                  / fused_obj_filtered.at(i).raw_data.motion.GetVx());
            } else {
              headangle = atanf(fused_obj_filtered.at(i).raw_data.motion.GetVy()
                                / fused_obj_filtered.at(i).raw_data.motion.GetVx())
                          - Pi;
            }
          }
        }

        float targetlength = 0.0f;
        if (fabsf(headangle - fused_obj_filtered.at(i).raw_data.motion.GetHead()) <= TargetHeadThres) {
          targetlength = fused_obj_filtered.at(i).raw_data.length();
        } else {
          targetlength = fused_obj_filtered.at(i).raw_data.width();
        }

        CalcPedCirRoot(tmp_obj, ego_ROC);

        if (hostReverse == 0) {
          tmp_obj.u1_Inpath =
            InPathCheck(tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming, tmp_obj.u1_crossing,
                        fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                        (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                         || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                        tmp_obj.f4_range, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                        fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()), tmp_obj.f4_XOLC, tmp_obj.f4_latpos_est,
                        headangle, targetlength, tmp_obj);
          tmp_obj.u1_Inpath_warn =
            InPathCheck_warn(tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming, tmp_obj.u1_crossing,
                             fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                             (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                              || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                             tmp_obj.f4_range, ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                             fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()), tmp_obj.f4_XOLC,
                             tmp_obj.f4_latpos_est, tmp_obj.obj.motion_status.IsMovable(), headangle, targetlength, tmp_obj);
        } else {
          tmp_obj.u1_Inpath =
            InPathCheck(tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming, tmp_obj.u1_crossing,
                        fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                        (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                         || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                        tmp_obj.f4_range_rear, (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * -1),
                        fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()), tmp_obj.f4_XOLC, tmp_obj.f4_latpos_est,
                        headangle, targetlength, tmp_obj);
          tmp_obj.u1_Inpath_warn =
            InPathCheck_warn(tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming, tmp_obj.u1_crossing,
                             fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                             (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                              || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                             tmp_obj.f4_range_rear, (ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * -1),
                             fabsf(fused_obj_filtered.at(i).raw_data.motion.GetVy()), tmp_obj.f4_XOLC,
                             tmp_obj.f4_latpos_est, tmp_obj.obj.motion_status.IsMovable(), headangle, targetlength, tmp_obj);
        }

        if (pedestrian_LF_.size() == 0 || tmp_obj.lastcyclesize == MaxFusedObjIndex) {
          tmp_obj.u8_Inpathage      = CalcInpathAge(tmp_obj.u1_Inpath, tmp_obj.u8_Inpathage);
          tmp_obj.u8_Inpathage_warn = CalcInpathAge(tmp_obj.u1_Inpath_warn, tmp_obj.u8_Inpathage_warn);
        } else {
          tmp_obj.u8_Inpathage = CalcInpathAge(tmp_obj.u1_Inpath, pedestrian_LF_[tmp_obj.lastcyclesize].u8_Inpathage);
          tmp_obj.u8_Inpathage_warn =
            CalcInpathAge(tmp_obj.u1_Inpath_warn, pedestrian_LF_[tmp_obj.lastcyclesize].u8_Inpathage_warn);
        }

        tmp_obj.u1_inpathagecheck = InPathAgeCheck(tmp_obj.u8_Inpathage, tmp_obj.u1_crossing, tmp_obj.u1_oncoming,
                                                   tmp_obj.u1_preceding, targetisMoving, tmp_obj.u8_AEBconf);
        tmp_obj.u1_inpathagecheck_warn =
          InPathAgeCheck_warn(tmp_obj.u8_Inpathage_warn, tmp_obj.u1_crossing, tmp_obj.u1_oncoming, tmp_obj.u1_preceding,
                              targetisMoving, tmp_obj.u8_AEBconf);

        // select AEB_VRU candidate
        if (hostReverse == 0) {
          decideTTCThreshold(ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps,
                             fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                             (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                              || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                             tmp_obj.u1_crossing, tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming);
        } else {
          decideTTCThreshold((ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps * -1),
                             fused_obj_filtered.at(i).raw_data.classification.IsPedestrian(),
                             (fused_obj_filtered.at(i).raw_data.classification.IsBicycle()
                              || fused_obj_filtered.at(i).raw_data.classification.IsMotorbike()),
                             tmp_obj.u1_crossing, tmp_obj.u1_preceding, targetisMoving, tmp_obj.u1_oncoming);
        }

        SelectAEBCandidate(tmp_obj, targetisMoving);

        SelectAEBCandidate_rear(
          tmp_obj, vru_candidate.pedestrian_rearcross_Candidate_, vru_candidate.bicycle_rearcross_Candidate_,
          vru_candidate.pedestrian_rearcross_Candidate_LF_, vru_candidate.bicycle_rearcross_Candidate_LF_);

        pedestrian_.push_back(tmp_obj);

        if (tmp_obj.u8_ID == vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID) {
          vru_candidate.pedestrian_cross_Candidate_.obj = tmp_obj;
        }

        if (tmp_obj.u8_ID == vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID) {
          vru_candidate.bicycle_cross_Candidate_.obj = tmp_obj;
        }

        if (tmp_obj.u8_ID == vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID) {
          vru_candidate.pedestrian_oncom_Candidate_.obj = tmp_obj;
        }

        if (tmp_obj.u8_ID == vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID) {
          vru_candidate.bicycle_oncom_Candidate_.obj = tmp_obj;
        }

        if (tmp_obj.u8_ID == vru_candidate.pedestrian_rearcross_Candidate_.u8_Candi_ID) {
          vru_candidate.pedestrian_rearcross_Candidate_.obj = tmp_obj;
        }

        if (tmp_obj.u8_ID == vru_candidate.bicycle_rearcross_Candidate_.u8_Candi_ID) {
          vru_candidate.bicycle_rearcross_Candidate_.obj = tmp_obj;
        }

      } else {
        if (fused_obj_filtered.at(i).raw_data.IsValid() == 0) {
          size_t x;
          if (pedestrian_LF_.size() != 0) {
            for (x = 0; x < pedestrian_LF_.size(); x++) {
              if (pedestrian_LF_[x].u8_ID == fused_obj_filtered.at(i).raw_data.GetID()) {
                if (pedestrian_LF_[x].objectvalid == 1 && pedestrian_LF_[x].u1_lfplaucheck == 1
                    && pedestrian_LF_[x].u1_vfplaucheck == 1 && pedestrian_LF_[x].u1_ageplaucheck == 1
                    && pedestrian_LF_[x].u1_inpathagecheck == 1 && pedestrian_LF_[x].f4_range <= VruCloseObjRangeThres
                    && fabsf(pedestrian_LF_[x].obj.motion.GetY()) <= VruCloseObjYThres) {
                  CloseLostTarget.LF_ID                = pedestrian_LF_[i].u8_ID;
                  CloseLostTarget.TargetLostCloseRange = 1;
                } else {
                  CloseLostTarget.LF_ID                = 0;
                  CloseLostTarget.TargetLostCloseRange = 0;
                }
                break;
              } else {
                continue;
              }
            }
          }
        }
      }
    }
  }
  pedestrian_LF_.clear();
  clearCandidate_LF();
  // auto dur = Time::Now() - ts;
  // std::cout << "extractped complete,cost time"<<dur<<"ms"<<std::endl;
}

void extract_vru::clearCandidate_LF() {
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_Candi_ID      = 0;
  vru_candidate.pedestrian_cross_Candidate_LF_.f4_minrange      = 100.0f;
  vru_candidate.pedestrian_cross_Candidate_LF_.f4_minTTC        = DefaultTTC;
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_prefill       = 0;
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_warning       = 0;
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_lowBrake      = 0;
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_highBrake     = 0;
  vru_candidate.pedestrian_cross_Candidate_LF_.u8_VisID         = MaxVisionIndex;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_Candi_ID         = 0;
  vru_candidate.bicycle_cross_Candidate_LF_.f4_minrange         = 100.0f;
  vru_candidate.bicycle_cross_Candidate_LF_.f4_minTTC           = DefaultTTC;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_prefill          = 0;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_warning          = 0;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_lowBrake         = 0;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_highBrake        = 0;
  vru_candidate.bicycle_cross_Candidate_LF_.u8_VisID            = MaxVisionIndex;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_Candi_ID      = 0;
  vru_candidate.pedestrian_oncom_Candidate_LF_.f4_minrange      = 100.0f;
  vru_candidate.pedestrian_oncom_Candidate_LF_.f4_minTTC        = DefaultTTC;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_prefill       = 0;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_warning       = 0;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_lowBrake      = 0;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_highBrake     = 0;
  vru_candidate.pedestrian_oncom_Candidate_LF_.u8_VisID         = MaxVisionIndex;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_Candi_ID         = 0;
  vru_candidate.bicycle_oncom_Candidate_LF_.f4_minrange         = 100.0f;
  vru_candidate.bicycle_oncom_Candidate_LF_.f4_minTTC           = DefaultTTC;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_prefill          = 0;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_warning          = 0;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_lowBrake         = 0;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_highBrake        = 0;
  vru_candidate.bicycle_oncom_Candidate_LF_.u8_VisID            = MaxVisionIndex;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_Candi_ID  = 0;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.f4_minrange  = 100.0f;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.f4_minTTC    = DefaultTTC;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_prefill   = 0;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_warning   = 0;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_lowBrake  = 0;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_highBrake = 0;
  vru_candidate.pedestrian_rearcross_Candidate_LF_.u8_VisID     = MaxVisionIndex;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_Candi_ID     = 0;
  vru_candidate.bicycle_rearcross_Candidate_LF_.f4_minrange     = 100.0f;
  vru_candidate.bicycle_rearcross_Candidate_LF_.f4_minTTC       = DefaultTTC;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_prefill      = 0;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_warning      = 0;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_lowBrake     = 0;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_highBrake    = 0;
  vru_candidate.bicycle_rearcross_Candidate_LF_.u8_VisID        = MaxVisionIndex;
}

void extract_vru::CalcPedCirRoot(AEBObject &tmp_obj, float ego_ROC) {
  tmp_obj.xpos_cir = 0;
  tmp_obj.ypos_cir = 0;
  tmp_obj.roc_tar = 0;
  tmp_obj.mindist = 200;
  tmp_obj.xpos_col = 10000;
  tmp_obj.ypos_col = 10000;
  tmp_obj.range_col = 10000;
  tmp_obj.range_col_tar = 10000;
  tmp_obj.colposs = 1;
  tmp_obj.col_num = 0;
  tmp_obj.TTC_cir = 25.5;
  tmp_obj.TTL_cir = 25.5;
  tmp_obj.TTC_tar = 25.5;
  tmp_obj.TTL_tar = 25.5;
  tmp_obj.yawrate = tmp_obj.obj.motion.GetHeadRate();
  tmp_obj.heading = tmp_obj.obj.motion.GetHead();
  tmp_obj.roc_tar = (sqrtf(tmp_obj.obj.motion.GetVx() * tmp_obj.obj.motion.GetVx() + tmp_obj.obj.motion.GetVy() * tmp_obj.obj.motion.GetVy()))/(tmp_obj.yawrate);
  tmp_obj.xpos_cir = tmp_obj.obj.motion.GetX() - tmp_obj.roc_tar * sinf(tmp_obj.heading);
  tmp_obj.ypos_cir = tmp_obj.obj.motion.GetY() + tmp_obj.roc_tar * cosf(tmp_obj.heading);
  tmp_obj.mindist = sqrtf((0 - tmp_obj.xpos_cir) * (0 - tmp_obj.xpos_cir) + (ego_ROC - tmp_obj.ypos_cir) * (ego_ROC - tmp_obj.ypos_cir)) - fabsf(ego_ROC) - fabsf(tmp_obj.roc_tar);
  if (fabsf(tmp_obj.yawrate) <= 0.03) {
    tmp_obj.colposs = 1;
  } 
  else {
    float c1 = 0;
    float c2 = 0;
    float delta = -1000000;
    if (tmp_obj.mindist <= 0) {
      c1 = tmp_obj.xpos_cir/(ego_ROC - tmp_obj.ypos_cir);
      c2 = ((tmp_obj.roc_tar * tmp_obj.roc_tar) - (tmp_obj.xpos_cir * tmp_obj.xpos_cir) - (tmp_obj.ypos_cir * tmp_obj.ypos_cir))/(2 * (ego_ROC - tmp_obj.ypos_cir));
      delta = 4 * (powf((ego_ROC * c1), 2) - powf(c2, 2) + 2 * ego_ROC * c2);
    }
    else if (tmp_obj.mindist <= 1.0) {
      float roc_new = 100000;
      if (tmp_obj.ypos_cir >= 0) {
        roc_new = ego_ROC - 1.0;
      }
      else {
        roc_new = ego_ROC + 1.0;
      }
      c1 = tmp_obj.xpos_cir/(ego_ROC - tmp_obj.ypos_cir);
      c2 = ((tmp_obj.roc_tar * tmp_obj.roc_tar) + powf(ego_ROC,2) - powf(roc_new,2) - (tmp_obj.xpos_cir * tmp_obj.xpos_cir) - (tmp_obj.ypos_cir * tmp_obj.ypos_cir))/(2 * (ego_ROC - tmp_obj.ypos_cir));
      delta = powf(2 * c1 * (c2 - ego_ROC), 2) - (4 * (1 + powf(c1, 2)) * (powf((ego_ROC - c2),2) - powf(roc_new,2)));
    }
    
    if (delta > 0) {
      float x1 = (2 * c1 * (ego_ROC -  c2) + sqrtf(delta))/(2 * (1 + c1 * c1));
      float x2 = (2 * c1 * (ego_ROC -  c2) - sqrtf(delta))/(2 * (1 + c1 * c1));
      if (x2 >= 0 && x1 >= 0) {
        tmp_obj.col_num = 2;
        if (x1 <= x2){
          tmp_obj.xpos_col = x1;
        }
        else {
          tmp_obj.xpos_col = x2;
        }
        tmp_obj.ypos_col = c1 * tmp_obj.xpos_col + c2;
      }
      else if (x2 <0 && x1 >=0) {
        tmp_obj.col_num = 1;
        tmp_obj.xpos_col = x1;
        tmp_obj.ypos_col = c1 * tmp_obj.xpos_col + c2;
      }
      else if (x1 <0 && x2 >=0) {
        tmp_obj.col_num = 1;
        tmp_obj.xpos_col = x2;
        tmp_obj.ypos_col = c1 * tmp_obj.xpos_col + c2;
      }
      else {
        tmp_obj.col_num = 0;
      }
    }
    else if (delta = 0) {
      float x1 = (2 * c1 * (ego_ROC -  c2) + sqrtf(delta))/(2 * (1 + c1 * c1));
      if (x1 >= 0) {
        tmp_obj.col_num = 1;
        tmp_obj.xpos_col = x1;
        tmp_obj.ypos_col = c1 * tmp_obj.xpos_col + c2;
      }
      else {
        tmp_obj.col_num = 0;
      }
    }
    else {
      tmp_obj.col_num = 0;
    }

    if (tmp_obj.col_num == 0) {
      tmp_obj.colposs = 0;
    }
    else {
      if ((tmp_obj.ypos_col < tmp_obj.obj.motion.GetY() && tmp_obj.obj.motion.GetVy() > 0) || (tmp_obj.ypos_col > tmp_obj.obj.motion.GetY() && tmp_obj.obj.motion.GetVy() < 0) || (tmp_obj.xpos_col < tmp_obj.obj.motion.GetX() && tmp_obj.obj.motion.GetVx() > 0) || (tmp_obj.xpos_col > tmp_obj.obj.motion.GetX() && tmp_obj.obj.motion.GetVx() < 0)) {
        tmp_obj.colposs = 0;
      }
      else {
        tmp_obj.range_col = sqrtf(powf(tmp_obj.xpos_col,2) + powf(tmp_obj.ypos_col,2));
        tmp_obj.range_col_tar = sqrt(powf(tmp_obj.xpos_col - tmp_obj.obj.motion.GetX(), 2) + powf(tmp_obj.ypos_col - tmp_obj.obj.motion.GetY(), 2));
        tmp_obj.TTC_cir = (tmp_obj.range_col - 3.9)/ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps;
        float tarspd = sqrtf(powf(tmp_obj.obj.motion.GetVx(),2) + powf(tmp_obj.obj.motion.GetVy(),2));
        tmp_obj.TTC_tar = (tmp_obj.range_col_tar - tmp_obj.obj.length() * 0.5)/tarspd;
        tmp_obj.TTL_tar = (tmp_obj.range_col_tar + tmp_obj.obj.length() * 0.5)/tarspd;
        if (tmp_obj.TTC_cir <= tmp_obj.TTL_tar && tmp_obj.TTC_cir >= tmp_obj.TTC_tar) {
          tmp_obj.colposs = 1;
        }
        else {
          tmp_obj.colposs = 0;
        }
      }
    }
  }
  if (fabsf(tmp_obj.yawrate) <= 0.05) {
    tmp_obj.colposs = 1;
  }
  //20220420 hongtaowen disable this algo due to heading rate issue
  //tmp_obj.colposs = 1;
}

void extract_vru::SelectAEBCandidate_rear(AEBObject& tmp_obj, AEBCandidate& ped_rear, AEBCandidate& bik_rear,
                                          AEBCandidate& ped_rear_lf, AEBCandidate& bik_rear_lf) {
  bool ped_brake_lf = 0;
  bool bik_brake_lf = 0;
  if ((ped_rear_lf.u8_highBrake > 0 || ped_rear_lf.u8_lowBrake > 0)
      && (tmp_obj.u8_ID == ped_rear_lf.u8_Candi_ID
          || (tmp_obj.u8_VID == ped_rear_lf.u8_VisID && ped_rear_lf.u8_VisID != MaxVisionIndex))) {
    ped_brake_lf = 1;
  }
  if ((bik_rear_lf.u8_highBrake > 0 || bik_rear_lf.u8_lowBrake > 0)
      && (tmp_obj.u8_ID == bik_rear_lf.u8_Candi_ID
          || (tmp_obj.u8_VID == bik_rear_lf.u8_VisID && bik_rear_lf.u8_VisID != MaxVisionIndex))) {
    bik_brake_lf = 1;
  }

  if (tmp_obj.obj.classification.IsPedestrian() == 1
      && (tmp_obj.u1_crossing == 1 || tmp_obj.u1_preceding == 1 || tmp_obj.u1_stationary == 1) && hostReverse == 1
      && ((drimonitor.output_.suppressbit & 0x00200000) == 0x00000000)) {
    DecideCandi_rear(tmp_obj, ped_rear, ped_rear_lf, ped_brake_lf);
  }

  if ((tmp_obj.obj.classification.IsBicycle() || tmp_obj.obj.classification.IsMotorbike()) == 1
      && (tmp_obj.u1_crossing == 1 || tmp_obj.u1_preceding == 1 || tmp_obj.u1_stationary == 1) && hostReverse == 1
      && ((drimonitor.output_.suppressbit & 0x00200000) == 0x00000000)) {
    DecideCandi_rear(tmp_obj, bik_rear, bik_rear_lf, bik_brake_lf);
  }
}

void extract_vru::DecideCandi_rear(AEBObject& tmp_obj, AEBCandidate& vru_rear, AEBCandidate& vru_rear_lf,
                                   bool brake_lf) {
  if (tmp_obj.obj.IsValid()) {
    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
          && tmp_obj.u1_inpathagecheck == 1 && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps < -CandiSpdThres
          && tmp_obj.u8_AEBconf >= 2 && tmp_obj.u1_TOI_rear == 1)
         || brake_lf == 1)) {
      if (tmp_obj.f4_TTC_rear < vru_rear.f4_minTTC
          || (tmp_obj.f4_TTC_rear == vru_rear.f4_minTTC && tmp_obj.f4_range_rear < vru_rear.f4_minrange)) {
        vru_rear.u8_Candi_ID = tmp_obj.u8_ID;
        vru_rear.u8_VisID    = tmp_obj.u8_VID;
        vru_rear.f4_minTTC   = tmp_obj.f4_TTC_rear;
        vru_rear.f4_minrange = tmp_obj.f4_range_rear;
        if (tmp_obj.f4_TTC_rear <= highbrake_TTC_rear) {
          vru_rear.u8_highBrake = tmp_obj.u8_ID;
        }
        if (tmp_obj.f4_TTC_rear <= lowbrake_TTC_rear) {
          vru_rear.u8_lowBrake = tmp_obj.u8_ID;
        }
      }
    }

    if ((tmp_obj.u1_Inpath == 1
         || (fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres && tmp_obj.f4_range_rear <= CandiRangeRearThres
             && tmp_obj.f4_rangerate >= CandiRangeRateThres))
        && (vru_rear_lf.u8_highBrake == tmp_obj.u8_ID && vru_rear.u8_highBrake == 0)) {
      vru_rear.u8_Candi_ID  = tmp_obj.u8_ID;
      vru_rear.u8_VisID     = tmp_obj.u8_VID;
      vru_rear.f4_minTTC    = tmp_obj.f4_TTC_rear;
      vru_rear.f4_minrange  = tmp_obj.f4_range_rear;
      vru_rear.u8_highBrake = tmp_obj.u8_ID;
    }

    if ((tmp_obj.u1_Inpath == 1
         || (fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres && tmp_obj.f4_range_rear <= CandiRangeRearThres
             && tmp_obj.f4_rangerate >= CandiRangeRateThres))
        && (vru_rear_lf.u8_lowBrake == tmp_obj.u8_ID && vru_rear.u8_highBrake == 0 && vru_rear.u8_lowBrake == 0)) {
      vru_rear.u8_Candi_ID = tmp_obj.u8_ID;
      vru_rear.u8_VisID    = tmp_obj.u8_VID;
      vru_rear.f4_minTTC   = tmp_obj.f4_TTC_rear;
      vru_rear.f4_minrange = tmp_obj.f4_range_rear;
      vru_rear.u8_lowBrake = tmp_obj.u8_ID;
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.u1_inpathagecheck_warn == 1 && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps < -CandiSpdThres
         && tmp_obj.u8_AEBconf >= 2 && tmp_obj.u1_TOI_rear == 1)) {
      if (tmp_obj.f4_TTC_rear < vru_rear.f4_minTTC
          || (tmp_obj.f4_TTC_rear == vru_rear.f4_minTTC && tmp_obj.f4_range_rear < vru_rear.f4_minrange)) {
        vru_rear.u8_Candi_ID = tmp_obj.u8_ID;
        vru_rear.u8_VisID    = tmp_obj.u8_VID;
        vru_rear.f4_minTTC   = tmp_obj.f4_TTC_rear;
        vru_rear.f4_minrange = tmp_obj.f4_range_rear;
        if (tmp_obj.f4_TTC_rear <= prefill_TTC_rear) {
          vru_rear.u8_prefill = tmp_obj.u8_ID;
        }
        if (tmp_obj.f4_TTC_rear <= warning_TTC_rear) {
          vru_rear.u8_warning = tmp_obj.u8_ID;
        }
      }
    }
  }
}

void extract_vru::SelectAEBCandidate(AEBObject& tmp_obj, bool ismoving) {
  if (tmp_obj.obj.classification.IsPedestrian() == 1
      && (tmp_obj.u1_crossing == 1 || tmp_obj.u1_preceding == 1 || ismoving == 0) && hostReverse == 0) {
    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
          && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
          && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
         || (vru_candidate.pedestrian_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID))
        &&
        // vru high brake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      decidePedHighflag(tmp_obj, vru_candidate.pedestrian_cross_Candidate_);
    }

    if (((tmp_obj.u1_Inpath == 1
          || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres) && (tmp_obj.f4_range <= CandiMaxRange)
              && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
         && (vru_candidate.pedestrian_cross_Candidate_LF_.u8_highBrake == tmp_obj.u8_ID
             || (vru_candidate.pedestrian_cross_Candidate_LF_.u8_VisID == tmp_obj.u8_VID
                 && tmp_obj.u8_VID != MaxVisionIndex && kVisionIDCheckEnable == 1))
         && (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake == 0))
        &&
        // vru high brake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      vru_candidate.pedestrian_cross_Candidate_.u8_highBrake = tmp_obj.u8_ID;
      vru_candidate.pedestrian_cross_Candidate_.f4_minrange  = tmp_obj.f4_range;
      vru_candidate.pedestrian_cross_Candidate_.f4_minTTC    = tmp_obj.f4_TTC;
      vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID  = tmp_obj.u8_ID;
      vru_candidate.pedestrian_cross_Candidate_.u8_VisID     = tmp_obj.u8_VID;
    }

    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
          && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
          && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
         || (vru_candidate.pedestrian_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID))
        &&
        // vru low brake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      decidePedLowflag(tmp_obj, vru_candidate.pedestrian_cross_Candidate_);
    }

    if (((tmp_obj.u1_Inpath == 1
          || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres) && (tmp_obj.f4_range <= CandiMaxRange)
              && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
         && (vru_candidate.pedestrian_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
         && (vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake == 0)
         && (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake == 0))
        &&
        // vru low brake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake = tmp_obj.u8_ID;
      vru_candidate.pedestrian_cross_Candidate_.f4_minrange = tmp_obj.f4_range;
      vru_candidate.pedestrian_cross_Candidate_.f4_minTTC   = tmp_obj.f4_TTC;
      vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID = tmp_obj.u8_ID;
      vru_candidate.pedestrian_cross_Candidate_.u8_VisID    = tmp_obj.u8_VID;
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        &&
        // vru prefill
        ((drimonitor.output_.suppressbit & 0x04000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x04000000) == (0x00000000))) {
      decidePedPrefflag(tmp_obj, vru_candidate.pedestrian_cross_Candidate_);
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        &&
        // vru fcw
        ((drimonitor.output_.suppressbit & 0x20000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x20000000) == (0x00000000))) {
      decidePedWarnflag(tmp_obj, vru_candidate.pedestrian_cross_Candidate_);
    }
  } else if ((tmp_obj.obj.classification.IsBicycle() || tmp_obj.obj.classification.IsMotorbike()) == 1
             && (tmp_obj.u1_crossing == 1 || tmp_obj.u1_preceding == 1 || ismoving == 0) && hostReverse == 0) {
    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
          && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
          && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
         || vru_candidate.bicycle_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
        &&
        // vru highbrake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      decidePedHighflag(tmp_obj, vru_candidate.bicycle_cross_Candidate_);
    }
    if (((tmp_obj.u1_Inpath == 1
          || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiBicYThres) && (tmp_obj.f4_range <= CandiBicMaxRange)
              && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
         && (vru_candidate.bicycle_cross_Candidate_LF_.u8_highBrake == tmp_obj.u8_ID
             || (vru_candidate.bicycle_cross_Candidate_LF_.u8_VisID == tmp_obj.u8_VID
                 && tmp_obj.u8_VID != MaxVisionIndex && kVisionIDCheckEnable == 1))
         && (vru_candidate.bicycle_cross_Candidate_.u8_highBrake == 0))
        &&
        // vru highbrake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      vru_candidate.bicycle_cross_Candidate_.u8_highBrake = tmp_obj.u8_ID;
      vru_candidate.bicycle_cross_Candidate_.f4_minrange  = tmp_obj.f4_range;
      vru_candidate.bicycle_cross_Candidate_.f4_minTTC    = tmp_obj.f4_TTC;
      vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID  = tmp_obj.u8_ID;
      vru_candidate.bicycle_cross_Candidate_.u8_VisID     = tmp_obj.u8_VID;
    }

    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
          && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
          && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
         || vru_candidate.bicycle_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
        &&
        // vru lowbrake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      decidePedLowflag(tmp_obj, vru_candidate.bicycle_cross_Candidate_);
    }

    if (((tmp_obj.u1_Inpath == 1
          || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiBicYThres) && (tmp_obj.f4_range <= CandiBicMaxRange)
              && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
         && (vru_candidate.bicycle_cross_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
         && (vru_candidate.bicycle_cross_Candidate_.u8_lowBrake == 0)
         && (vru_candidate.bicycle_cross_Candidate_.u8_highBrake == 0))
        &&
        // vru lowbrake
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000))) {
      vru_candidate.bicycle_cross_Candidate_.u8_lowBrake = tmp_obj.u8_ID;
      vru_candidate.bicycle_cross_Candidate_.f4_minrange = tmp_obj.f4_range;
      vru_candidate.bicycle_cross_Candidate_.f4_minTTC   = tmp_obj.f4_TTC;
      vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID = tmp_obj.u8_ID;
      vru_candidate.bicycle_cross_Candidate_.u8_VisID    = tmp_obj.u8_VID;
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        &&
        // vru prefill
        ((drimonitor.output_.suppressbit & 0x04000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x04000000) == (0x00000000))) {
      decidePedPrefflag(tmp_obj, vru_candidate.bicycle_cross_Candidate_);
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        &&
        // vru fcw
        ((drimonitor.output_.suppressbit & 0x20000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x20000000) == (0x00000000))) {
      decidePedWarnflag(tmp_obj, vru_candidate.bicycle_cross_Candidate_);
    }
  } else if (tmp_obj.obj.classification.IsPedestrian() == 1 && tmp_obj.u1_oncoming == 1 && hostReverse == 0) {
    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        || vru_candidate.pedestrian_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      decidePedHighflag(tmp_obj, vru_candidate.pedestrian_oncom_Candidate_);
    }
    if ((tmp_obj.u1_Inpath == 1
         || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiOncYThres) && (tmp_obj.f4_range <= CandiMaxRange)
             && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
        && (vru_candidate.pedestrian_oncom_Candidate_LF_.u8_highBrake == tmp_obj.u8_ID
            || (vru_candidate.pedestrian_oncom_Candidate_LF_.u8_VisID == tmp_obj.u8_VID
                && tmp_obj.u8_VID != MaxVisionIndex && kVisionIDCheckEnable == 1))
        && (vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake == 0) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake = tmp_obj.u8_ID;
      vru_candidate.pedestrian_oncom_Candidate_.f4_minrange  = tmp_obj.f4_range;
      vru_candidate.pedestrian_oncom_Candidate_.f4_minTTC    = tmp_obj.f4_TTC;
      vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID  = tmp_obj.u8_ID;
      vru_candidate.pedestrian_oncom_Candidate_.u8_VisID     = tmp_obj.u8_VID;
    }

    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        || vru_candidate.pedestrian_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID) && 
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      decidePedLowflag(tmp_obj, vru_candidate.pedestrian_oncom_Candidate_);
    }

    if (((tmp_obj.u1_Inpath == 1
         || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiOncYThres) && (tmp_obj.f4_range <= CandiMaxRange)
             && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
        && (vru_candidate.pedestrian_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
        && (vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake == 0)
        && (vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake == 0)) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake = tmp_obj.u8_ID;
      vru_candidate.pedestrian_oncom_Candidate_.f4_minrange = tmp_obj.f4_range;
      vru_candidate.pedestrian_oncom_Candidate_.f4_minTTC   = tmp_obj.f4_TTC;
      vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID = tmp_obj.u8_ID;
      vru_candidate.pedestrian_oncom_Candidate_.u8_VisID    = tmp_obj.u8_VID;
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
        && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
        && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1) &&
        ((drimonitor.output_.suppressbit & 0x04000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x04000000) == (0x00000000)))
    {
      decidePedPrefflag(tmp_obj, vru_candidate.pedestrian_oncom_Candidate_);
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
        && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
        && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1) &&
        ((drimonitor.output_.suppressbit & 0x20000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x20000000) == (0x00000000)))
    {
      decidePedWarnflag(tmp_obj, vru_candidate.pedestrian_oncom_Candidate_);
    }
  } else if ((tmp_obj.obj.classification.IsBicycle() || tmp_obj.obj.classification.IsMotorbike()) == 1
             && tmp_obj.u1_oncoming == 1 && hostReverse == 0) {
    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        || vru_candidate.bicycle_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      decidePedHighflag(tmp_obj, vru_candidate.bicycle_oncom_Candidate_);
    }
    if (((tmp_obj.u1_Inpath == 1
         || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres) && (tmp_obj.f4_range <= CandiMaxRange)
             && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
        && (vru_candidate.bicycle_oncom_Candidate_LF_.u8_highBrake == tmp_obj.u8_ID
            || (vru_candidate.bicycle_oncom_Candidate_LF_.u8_VisID == tmp_obj.u8_VID && tmp_obj.u8_VID != MaxVisionIndex
                && kVisionIDCheckEnable == 1))
        && (vru_candidate.bicycle_oncom_Candidate_.u8_highBrake == 0)) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      vru_candidate.bicycle_oncom_Candidate_.u8_highBrake = tmp_obj.u8_ID;
      vru_candidate.bicycle_oncom_Candidate_.f4_minrange  = tmp_obj.f4_range;
      vru_candidate.bicycle_oncom_Candidate_.f4_minTTC    = tmp_obj.f4_TTC;
      vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID  = tmp_obj.u8_ID;
      vru_candidate.bicycle_oncom_Candidate_.u8_VisID     = tmp_obj.u8_VID;
    }

    if (((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
         && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck == 1
         && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1)
        || vru_candidate.bicycle_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      decidePedLowflag(tmp_obj, vru_candidate.bicycle_oncom_Candidate_);
    }

    if (((tmp_obj.u1_Inpath == 1
         || ((fabsf(tmp_obj.ref_pos.referencepoint.pos_y) < CandiYThres) && (tmp_obj.f4_range <= CandiMaxRange)
             && (tmp_obj.f4_rangerate <= CandiMaxRangeRate)))
        && (vru_candidate.bicycle_oncom_Candidate_LF_.u8_lowBrake == tmp_obj.u8_ID)
        && (vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake == 0)
        && (vru_candidate.bicycle_oncom_Candidate_.u8_highBrake == 0)) &&
        ((drimonitor.output_.suppressbit & 0x01000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x01000000) == (0x00000000)))
    {
      vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake = tmp_obj.u8_ID;
      vru_candidate.bicycle_oncom_Candidate_.f4_minrange = tmp_obj.f4_range;
      vru_candidate.bicycle_oncom_Candidate_.f4_minTTC   = tmp_obj.f4_TTC;
      vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID = tmp_obj.u8_ID;
      vru_candidate.bicycle_oncom_Candidate_.u8_VisID    = tmp_obj.u8_VID;
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
        && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
        && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1) &&
        ((drimonitor.output_.suppressbit & 0x04000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x04000000) == (0x00000000)))
    {
      decidePedPrefflag(tmp_obj, vru_candidate.bicycle_oncom_Candidate_);
    }

    if ((tmp_obj.u1_vfplaucheck == 1 && tmp_obj.u1_lfplaucheck == 1 && tmp_obj.u1_ageplaucheck == 1
        && tmp_obj.obj.IsValid() == 1 && tmp_obj.u1_inpathagecheck_warn == 1
        && ego_->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps > CandiMinSpd && tmp_obj.u1_TOI == 1 && tmp_obj.colposs == 1) &&
        ((drimonitor.output_.suppressbit & 0x20000000) == (0x00000000) &&
        (drimonitor.output_.abortbit & 0x20000000) == (0x00000000)))
    {
      decidePedWarnflag(tmp_obj, vru_candidate.bicycle_oncom_Candidate_);
    }
  }

  // AEBconf: 0= not_defined; 1 = low; 2 = med; 3 = high;
}

void extract_vru::decidePedHighflag(AEBObject& tmp_obj, AEBCandidate& vru_candi) {
  if (tmp_obj.f4_TTC <= highbrake_TTC && tmp_obj.u8_AEBconf >= 2
      && ((tmp_obj.f4_TTC < vru_candi.f4_minTTC)
          || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range < vru_candi.f4_minrange)))) {
    vru_candi.u8_highBrake = tmp_obj.u8_ID;
    vru_candi.u8_Candi_ID  = tmp_obj.u8_ID;
    vru_candi.f4_minTTC    = tmp_obj.f4_TTC;
    vru_candi.f4_minrange  = tmp_obj.f4_range;
    vru_candi.u8_VisID     = tmp_obj.u8_VID;
  } else if (tmp_obj.f4_TTC <= highbrake_TTC && tmp_obj.u8_AEBconf >= 2
             && ((tmp_obj.f4_TTC > vru_candi.f4_minTTC)
                 || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range >= vru_candi.f4_minrange)))) {
    // do nothing;
  }
}

void extract_vru::decidePedLowflag(AEBObject& tmp_obj, AEBCandidate& vru_candi) {
  if (tmp_obj.f4_TTC <= lowbrake_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
      && ((tmp_obj.f4_TTC < vru_candi.f4_minTTC)
          || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range < vru_candi.f4_minrange)))) {
    vru_candi.u8_lowBrake = tmp_obj.u8_ID;
    vru_candi.u8_Candi_ID = tmp_obj.u8_ID;
    vru_candi.f4_minTTC   = tmp_obj.f4_TTC;
    vru_candi.f4_minrange = tmp_obj.f4_range;
  } else if (tmp_obj.f4_TTC <= lowbrake_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
             && ((tmp_obj.f4_TTC > vru_candi.f4_minTTC)
                 || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range >= vru_candi.f4_minrange)))) {
    // do nothing;
  }
}

void extract_vru::decidePedPrefflag(AEBObject& tmp_obj, AEBCandidate& vru_candi) {
  if (tmp_obj.f4_TTC <= prefill_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
      && ((tmp_obj.f4_TTC < vru_candi.f4_minTTC)
          || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range < vru_candi.f4_minrange)))) {
    vru_candi.u8_prefill  = tmp_obj.u8_ID;
    vru_candi.u8_Candi_ID = tmp_obj.u8_ID;
    vru_candi.f4_minTTC   = tmp_obj.f4_TTC;
    vru_candi.f4_minrange = tmp_obj.f4_range;
  } else if (tmp_obj.f4_TTC <= lowbrake_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
             && ((tmp_obj.f4_TTC > vru_candi.f4_minTTC)
                 || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range >= vru_candi.f4_minrange)))) {
    // do nothing;
  }
}

void extract_vru::decidePedWarnflag(AEBObject& tmp_obj, AEBCandidate& vru_candi) {
  if (tmp_obj.f4_TTC <= warning_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
      && ((tmp_obj.f4_TTC < vru_candi.f4_minTTC)
          || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range < vru_candi.f4_minrange)))) {
    vru_candi.u8_warning  = tmp_obj.u8_ID;
    vru_candi.u8_Candi_ID = tmp_obj.u8_ID;
    vru_candi.f4_minTTC   = tmp_obj.f4_TTC;
    vru_candi.f4_minrange = tmp_obj.f4_range;
  } else if (tmp_obj.f4_TTC <= lowbrake_TTC && tmp_obj.u8_AEBconf >= 2 && vru_candi.u8_highBrake == 0
             && ((tmp_obj.f4_TTC > vru_candi.f4_minTTC)
                 || ((tmp_obj.f4_TTC == vru_candi.f4_minTTC) && (tmp_obj.f4_range >= vru_candi.f4_minrange)))) {
    // do nothing;
  }
}

void extract_vru::decideTTCThreshold(float egospd, bool ispedestrian, bool isbicycle, bool crossing, bool preceding,
                                     bool ismoving, bool oncoming) {
  if (ispedestrian == 1 && (crossing == 1 || ismoving == 0)) {
    prefill_TTC   = threshold_prefill_crossped.interpolate(egospd);
    warning_TTC   = threshold_warn_crossped.interpolate(egospd);
    lowbrake_TTC  = threshold_lowbrake_crossped.interpolate(egospd);
    highbrake_TTC = threshold_highbrake_crossped.interpolate(egospd);

    prefill_TTC_rear   = threshold_prefill_rearcrossped.interpolate(egospd);
    warning_TTC_rear   = threshold_warn_rearcrossped.interpolate(egospd);
    lowbrake_TTC_rear  = threshold_lowbrake_rearcrossped.interpolate(egospd);
    highbrake_TTC_rear = threshold_highbrake_rearcrossped.interpolate(egospd);

    // add cross vru ttc delay
    prefill_TTC *= drimonitor.output_.dampfactor[5];
    warning_TTC *= drimonitor.output_.dampfactor[2];
    lowbrake_TTC *= drimonitor.output_.dampfactor[7];
    highbrake_TTC *= drimonitor.output_.dampfactor[7];

    // rearcross vru ttc delay
    prefill_TTC_rear *= drimonitor.output_.dampfactor[10];
    warning_TTC_rear *= drimonitor.output_.dampfactor[10];
    lowbrake_TTC_rear *= drimonitor.output_.dampfactor[10];
    highbrake_TTC_rear *= drimonitor.output_.dampfactor[10];

  } else if (ispedestrian == 1 && preceding == 1) {
    prefill_TTC   = threshold_prefill_precedped.interpolate(egospd);
    warning_TTC   = threshold_warn_precedped.interpolate(egospd);
    lowbrake_TTC  = threshold_lowbrake_precedped.interpolate(egospd);
    highbrake_TTC = threshold_highbrake_precedped.interpolate(egospd);

    // add long vru ttc delay
    prefill_TTC *= drimonitor.output_.dampfactor[5];
    warning_TTC *= drimonitor.output_.dampfactor[2];
    lowbrake_TTC *= drimonitor.output_.dampfactor[7];
    highbrake_TTC *= drimonitor.output_.dampfactor[7];

  } else if (isbicycle == 1 && (crossing == 1 || ismoving == 0)) {
    if (kAEBBicycleEnable == 1) {
      prefill_TTC   = threshold_prefill_crossbik.interpolate(egospd);
      warning_TTC   = threshold_warn_crossbik.interpolate(egospd);
      lowbrake_TTC  = threshold_lowbrake_crossbik.interpolate(egospd);
      highbrake_TTC = threshold_highbrake_crossbik.interpolate(egospd);

      // add cross vru ttc delay
      prefill_TTC *= drimonitor.output_.dampfactor[5];
      warning_TTC *= drimonitor.output_.dampfactor[2];
      lowbrake_TTC *= drimonitor.output_.dampfactor[7];
      highbrake_TTC *= drimonitor.output_.dampfactor[7];

    } else {
      prefill_TTC   = -1.0f;
      warning_TTC   = -1.0f;
      lowbrake_TTC  = -1.0f;
      highbrake_TTC = -1.0f;
    }
  } else if (isbicycle == 1 && preceding == 1) {
    if (kAEBBicycleEnable == 1) {
      prefill_TTC   = threshold_prefill_precedbik.interpolate(egospd);
      warning_TTC   = threshold_warn_precedbik.interpolate(egospd);
      lowbrake_TTC  = threshold_lowbrake_precedbik.interpolate(egospd);
      highbrake_TTC = threshold_highbrake_precedbik.interpolate(egospd);

      // add long vru ttc delay
      prefill_TTC *= drimonitor.output_.dampfactor[5];
      warning_TTC *= drimonitor.output_.dampfactor[2];
      lowbrake_TTC *= drimonitor.output_.dampfactor[7];
      highbrake_TTC *= drimonitor.output_.dampfactor[7];

    } else {
      prefill_TTC   = -1.0f;
      warning_TTC   = -1.0f;
      lowbrake_TTC  = -1.0f;
      highbrake_TTC = -1.0f;
    }
  }

  else if (ispedestrian == 1 && oncoming == 1) {
    if (kAEBOncomingEnable == 1) {
      prefill_TTC   = threshold_prefill_oncomped.interpolate(egospd);
      warning_TTC   = threshold_warn_oncomped.interpolate(egospd);
      lowbrake_TTC  = threshold_lowbrake_oncomped.interpolate(egospd);
      highbrake_TTC = threshold_highbrake_oncomped.interpolate(egospd);
    } else {
      prefill_TTC   = -1.0f;
      warning_TTC   = -1.0f;
      lowbrake_TTC  = -1.0f;
      highbrake_TTC = -1.0f;
    }
  } else if (isbicycle == 1 && oncoming == 1) {
    if (kAEBOncomingEnable == 1 && kAEBBicycleEnable == 1) {
      prefill_TTC   = threshold_prefill_oncombik.interpolate(egospd);
      warning_TTC   = threshold_warn_oncombik.interpolate(egospd);
      lowbrake_TTC  = threshold_lowbrake_oncombik.interpolate(egospd);
      highbrake_TTC = threshold_highbrake_oncombik.interpolate(egospd);
    } else {
      prefill_TTC   = -1.0f;
      warning_TTC   = -1.0f;
      lowbrake_TTC  = -1.0f;
      highbrake_TTC = -1.0f;
    }
  } else {
    prefill_TTC   = -1.0f;
    warning_TTC   = -1.0f;
    lowbrake_TTC  = -1.0f;
    highbrake_TTC = -1.0f;
  }

  if (ego_turning == 1) {
    warning_TTC = lowbrake_TTC + 0.1;
    prefill_TTC = lowbrake_TTC + 0.1;
  }

  if (fcw_sensitive == 0) {
    warning_TTC = warning_TTC + WarnTTCBuffer;
  } else if (fcw_sensitive == 2) {
    warning_TTC = warning_TTC - WarnTTCBuffer;
  }
}

bool extract_vru::InPathAgeCheck(uint8_t inpathage, bool iscrossing, bool isoncoming, bool ispreceding, bool ismoving,
                                 uint8_t AEBconf) {
  uint8_t agethreshold;
  if (kinpathageplauscheckenable == 0) {
    return 1;
  } else {
    if (iscrossing == 1 || ismoving == 0) {
      if (ego_turning == 1) {
        agethreshold = threshold_crossage_turn_.interpolate(AEBconf);
      }
      else {
        agethreshold = threshold_crossage_.interpolate(AEBconf);
      }
    } else if (isoncoming == 1 || ispreceding == 1) {
      agethreshold = threshold_longage_.interpolate(AEBconf);
    } else {
      agethreshold = threshold_longage_.interpolate(AEBconf);
    }

    if (inpathage >= agethreshold) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_vru::InPathAgeCheck_warn(uint8_t inpathage, bool iscrossing, bool isoncoming, bool ispreceding,
                                      bool ismoving, uint8_t AEBconf) {
  uint8_t agethreshold;
  if (kinpathageplauscheckenable == 0) {
    return 1;
  } else {
    if (iscrossing == 1 || ismoving == 0) {
      if (ego_turning == 1) {
        agethreshold = threshold_crossage_turn_warn_.interpolate(AEBconf);
      }
      else {
        agethreshold = threshold_crossage_warn_.interpolate(AEBconf);
      }
    } else if (isoncoming == 1 || ispreceding == 1) {
      agethreshold = threshold_longage_warn_.interpolate(AEBconf);
    } else {
      agethreshold = threshold_longage_warn_.interpolate(AEBconf);
    }

    if (inpathage >= agethreshold) {
      return 1;
    } else {
      return 0;
    }
  }
}

uint8_t extract_vru::CalcInpathAge(bool inpath, uint8_t in_path_age) {
  if (inpath == 1) {
    in_path_age++;
    if (in_path_age >= MaxInpathAge) {
      in_path_age = MaxInpathAge;
    }

  } else {
    if (in_path_age >= InPathAgeStep) {
      in_path_age = 2;
    } else {
      in_path_age = 0;
    }
  }
  return in_path_age;
}

bool extract_vru::InPathCheck(bool preciding, bool ismoving, bool oncoming, bool crossing, bool ispedestrian,
                              bool isbicycle, float range, float egospd, float latspd, float XOLC, float latposest,
                              float heading, float length, AEBObject &tmp_obj) {
  float predict_side;
  float current_side;
  float pass_through_factor = 0;

  if (crossing == 1 && ispedestrian == 1) {
    predict_side =
      threshold_cross_predict_.interpolate(egospd, range) + threshold_cross_expend_predict.interpolate(latspd, range);
    current_side =
      threshold_cross_current_.interpolate(egospd, range) + threshold_cross_expend_current.interpolate(latspd, range);
  } else if (crossing == 1 && isbicycle == 1) {
    predict_side = threshold_cross_predict_.interpolate(egospd, range)
                   + threshold_cross_expend_predict_Bik.interpolate(latspd, range);
    current_side = threshold_cross_current_.interpolate(egospd, range)
                   + threshold_cross_expend_current_Bik.interpolate(latspd, range);
  } else if (preciding == 1 && (ispedestrian == 1 || isbicycle == 1)) {
    predict_side = threshold_longmove_predict_.interpolate(egospd, range);
    current_side = threshold_longmove_current_.interpolate(egospd, range);
  } else if (ismoving == 0 && (ispedestrian == 1 || isbicycle == 1)) {
    predict_side = threshold_stationary_predict_.interpolate(egospd, range);
    current_side = threshold_stationary_current_.interpolate(egospd, range);
  } else {
    predict_side = 0;
    current_side = 0;
  }

  if (tmp_obj.ref_pos.ref_character == 1) {
    pass_through_factor = 1;
  }
  else if (tmp_obj.ref_pos.ref_character == 3 || tmp_obj.ref_pos.ref_character == 4 || tmp_obj.ref_pos.ref_character == 0) {
    pass_through_factor = 0.5;
  }
  else {
    pass_through_factor = 0;
  }

  if (isbicycle == 1 && crossing == 1) {
    if (XOLC > 0.0f && latposest < 0.0f) {
      // float lengthpos = 0.0f;
      // lengthpos = fabsf(latposest + length * sinf(heading));
      if (fabsf(XOLC) <= current_side
          && (fabsf(latposest) <= predict_side || fabsf(latposest - (length * sinf(heading) * pass_through_factor)) <= predict_side)) {
        return 1;
      } else {
        return 0;
      }
    } else if (XOLC < 0.0f && latposest > 0.0f) {
      if (fabsf(XOLC) <= current_side
          && (fabsf(latposest) <= predict_side || fabsf(latposest - (length * sinf(heading) * pass_through_factor)) <= predict_side)) {
        return 1;
      } else {
        return 0;
      }
    } else {
      if (fabsf(XOLC) <= current_side && fabsf(latposest) <= predict_side) {
        return 1;
      } else {
        return 0;
      }
    }
  } else {
    if (fabsf(XOLC) <= current_side && fabsf(latposest) <= predict_side) {
      return 1;
    } else {
      return 0;
    }
  }
}

bool extract_vru::InPathCheck_warn(bool preciding, bool ismoving, bool oncoming, bool crossing, bool ispedestrian,
                                   bool isbicycle, float range, float egospd, float latspd, float XOLC, float latposest,
                                   bool ismovable, float heading, float length, AEBObject &tmp_obj) {
  float predict_side;
  float current_side;
  float pass_through_factor = 0;

  if ((crossing == 1 || ismoving == 0) && ispedestrian == 1 && ismovable == 1) {
    predict_side = threshold_cross_predict_warn_.interpolate(egospd, range)
                   + threshold_cross_expend_predict_warn_.interpolate(latspd, range);
    current_side = threshold_cross_current_warn_.interpolate(egospd, range)
                   + threshold_cross_expend_current_warn_.interpolate(latspd, range);
  } else if (crossing == 1 && isbicycle == 1) {
    predict_side = threshold_cross_predict_warn_.interpolate(egospd, range)
                   + threshold_cross_expend_predict_warn_Bik.interpolate(latspd, range);
    current_side = threshold_cross_current_warn_.interpolate(egospd, range)
                   + threshold_cross_expend_current_warn_Bik.interpolate(latspd, range);
  } else if (preciding == 1 && (ispedestrian == 1 || isbicycle == 1)) {
    predict_side = threshold_longmove_predict_warn_.interpolate(egospd, range);
    current_side = threshold_longmove_current_warn_.interpolate(egospd, range);
  } else if (ismovable == 0 && (ispedestrian == 1 || isbicycle == 1)) {
    predict_side = threshold_stationary_predict_warn_.interpolate(egospd, range);
    current_side = threshold_stationary_current_warn_.interpolate(egospd, range);
  } else {
    predict_side = 0;
    current_side = 0;
  }

  if (tmp_obj.ref_pos.ref_character == 1) {
    pass_through_factor = 1;
  }
  else if (tmp_obj.ref_pos.ref_character == 3 || tmp_obj.ref_pos.ref_character == 4 || tmp_obj.ref_pos.ref_character == 0) {
    pass_through_factor = 0.5;
  }
  else {
    pass_through_factor = 0;
  }

  if (isbicycle == 1 && crossing == 1) {
    if (XOLC > 0.0f && latposest < 0.0f) {
      if (fabsf(XOLC) <= current_side
          && (fabsf(latposest) <= predict_side || fabsf(latposest - (length * sinf(heading) * pass_through_factor)) <= predict_side)) {
        return 1;
      } else {
        return 0;
      }
    } else if (XOLC < 0.0f && latposest > 0.0f) {
      if (fabsf(XOLC) <= current_side
          && (fabsf(latposest) <= predict_side || fabsf(latposest - (length * sinf(heading) * pass_through_factor)) <= predict_side)) {
        return 1;
      } else {
        return 0;
      }
    } else {
      if (fabsf(XOLC) <= current_side && fabsf(latposest) <= predict_side) {
        return 1;
      } else {
        return 0;
      }
    }
  } else {
    if (fabsf(XOLC) <= current_side && fabsf(latposest) <= predict_side) {
      return 1;
    } else {
      return 0;
    }
  }
}

float extract_vru::CalLatPosEst(float pedXOLC, float pedlatvel, float pedTTC) {
  return pedXOLC + pedlatvel * pedTTC;
}

bool extract_vru::agecheck(uint8_t age, bool iscrossing, bool isoncoming, bool ispreceding, bool ismovable,
                           uint8_t AEBconf) {
  uint8_t agethreshold;
  if (kageplauscheckenable == 0) {
    return 1;
  } else {
    if (iscrossing == 1 || ismovable == 0) {
      agethreshold = threshold_crossageplau_.interpolate(AEBconf);
      if (age >= agethreshold) {
        return 1;
      } else {
        return 0;
      }
    } else if (isoncoming == 1 || ispreceding == 1) {
      agethreshold = threshold_longageplau_.interpolate(AEBconf);
      if (age >= agethreshold) {
        return 1;
      } else {
        return 0;
      }
    } else {
      agethreshold = threshold_longageplau_.interpolate(AEBconf);
      if (age >= agethreshold) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}

bool extract_vru::DecideLatMove(float longpos, float latvel, bool lfst) {
  float latvel_threshold;
  latvel_threshold = threshold_latmove_decide_.interpolate(longpos);
  if (fabsf(latvel) > (latvel_threshold - ToiLatVelThres) && lfst == 1) {
    return 1;
  } else if (fabsf(latvel) > latvel_threshold && lfst == 0) {
    return 1;
  } else if (fabsf(latvel) <= latvel_threshold && lfst == 0) {
    return 0;
  } else {
    return 0;
  }
}

bool extract_vru::DecideLongMove(float longpos, float longvel, bool lfst) {
  float longvel_threshold;
  longvel_threshold = threshold_longmove_decide_.interpolate(longpos);
  if (fabsf(longvel) > (longvel_threshold - LongVelBuffer) && lfst == 1) {
    return 1;
  } else if (fabsf(longvel) > longvel_threshold && lfst == 0) {
    return 1;
  } else if (fabsf(longvel) <= longvel_threshold && lfst == 0) {
    return 0;
  } else {
    return 0;
  }
}

bool extract_vru::lastframecheck(float cur_dy, float cur_vy, float lf_dy, float lf_vy, float longpos, float hostacc) {
  if (kLFplauscheckenable == 0) {
    return 1;
  } else {
    if (fabsf(hostacc) >= CheckHostAccThres) {
      return 1;
    } else {
      float latposthres = threshold_visionfusion_pos_plaus_.interpolate(longpos);
      float latvelthres = threshold_visionfusion_vel_plaus_.interpolate(longpos);
      if ((fabsf((lf_dy + lf_vy * time_interval) - cur_dy) > latposthres)
          && (fabsf(((cur_dy - lf_dy) / time_interval) - cur_vy) > latvelthres)) {
        return 0;  // for vision only test, this logic has been modified to and,
                   // otherwise it shall be or;
      } else {
        return 1;
      }
    }
  }
}

bool extract_vru::DecideLatMoveNew(float longpos, float latvel) {
  float latvel_threshold;
  latvel_threshold = threshold_latmove_decide_.interpolate(longpos);
  if (fabsf(latvel) > latvel_threshold) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_vru::DecideLongMoveNew(float longpos, float longvel) {
  float longvel_threshold;
  longvel_threshold = threshold_longmove_decide_.interpolate(longpos);
  if (fabsf(longvel) > longvel_threshold) {
    return 1;
  } else {
    return 0;
  }
}

bool extract_vru::visionfusioncheck(float cur_dy, float cur_vy, float vis_dy, float vis_vy, float longpos,
                                    float hostacc) {
  if (kVnFplauscheckenable == 0) {
    return 1;
  } else {
    if (fabsf(hostacc) >= CheckHostAccThres) {
      return 1;
    } else {
      float latvelthres = threshold_visionfusion_vel_plaus_.interpolate(longpos);
      float latposthres = threshold_visionfusion_pos_plaus_.interpolate(longpos);
      if ((fabsf(cur_vy - vis_vy) > latvelthres)
          && (fabsf(cur_dy - vis_dy) > latposthres))  // change the condition to &&
                                                      // from || for function engage
      {
        return 0;
      } else {
        return 1;
      }
    }
  }
}

uint8_t extract_vru::decidePedAEBConf(AEBObject& tmp_obj) {
  uint8_t ret = 0;
  if (tmp_obj.obj.IsAllFused() == 1 && tmp_obj.obj.valid_status() == 2U && tmp_obj.obj.fusion_sup.confidence >= MatchConfThres) {
    // AEBconf: 0= not_defined; 1 = low; 2 = med; 3 = high;
    if (tmp_obj.obj.HasVisionFused() == 1 && tmp_obj.obj.HasRadarFused()) {
      ret = 3;
    }
    else if (tmp_obj.obj.HasRadarFused() == 0 ) {
      ret = 2;
    }
    else {
      ret = 0;
    }
  } else if (tmp_obj.obj.IsVisionOnly() == 1 && tmp_obj.obj.IsAllFusedHis() == 1 && tmp_obj.obj.valid_status() == 2 && tmp_obj.obj.fusion_sup.confidence >= MatchConfThres) {
    ret = 2;
  }else {
    ret = 0;
  }
  return ret;
}

float extract_vru::CalPedTTC(float rrate, float egoacc, float range, float ego_spd, bool aebactive) {
  float TTC_final = DefaultTTC;
  float TTC_basic = DefaultTTC;
  float TTC_accel = DefaultTTC;

  TTC_basic = -(range / rrate);

  if (fabsf(egoacc) < 0.1f) {
    if (rrate >= 0.0f) {
      TTC_accel = MaxTTC;
    } else {
      TTC_accel = -(range / rrate);
    }
  } else {
    if (rrate * rrate + 2 * egoacc * range < 0.0f) {
      TTC_accel = MaxTTC;
    } else {
      TTC_accel = (rrate + sqrtf(rrate * rrate + 2 * egoacc * range)) / egoacc;
    }
  }

  if (aebactive == 0) {
    TTC_final = TTC_accel;
  } else {
    TTC_final = TTC_basic;
  }

  if (TTC_final < 0) {
    return MaxTTC;
  } else if (TTC_final >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_final;
  }
}

float extract_vru::CalPedTTC_rear(float rrate, float egoacc, float range, float ego_spd, bool aebactive) {
  float TTC_final = DefaultTTC;
  float TTC_basic = DefaultTTC;
  float TTC_accel = DefaultTTC;

  TTC_basic = range / rrate;

  if (fabsf(egoacc) < 0.1f) {
    if (rrate <= 0.0f) {
      TTC_accel = MaxTTC;
    } else {
      TTC_accel = range / rrate;
    }
  } else {
    if (rrate * rrate - 2 * egoacc * range < 0.0f) {
      TTC_accel = MaxTTC;
    } else {
      TTC_accel = ((rrate * -1) + sqrtf(rrate * rrate - 2 * egoacc * range)) / (egoacc * -1);
    }
  }

  if (aebactive == 0) {
    TTC_final = TTC_accel;
  } else {
    TTC_final = TTC_basic;
  }

  if (TTC_final < 0) {
    return MaxTTC;
  } else if (TTC_final >= MaxTTC) {
    return MaxTTC;
  } else {
    return TTC_final;
  }
}

float extract_vru::deltay(float ROC, float Distance, float egospd) {
  /*float predict_c2;
  if (fabsf(egospd) <= 1.0f) {
      predict_c2 = 0;
  } else {
      predict_c2 = c2;
  }

  return powf(Distance, 2) * predict_c2;*/
  if (powf(Distance, 2) / (ROC * 2) >= DefaultDeltaAy || (ROC <= RocThres && ROC >= 0.0F)) {
    return DefaultDeltaAy;
  } else if (powf(Distance, 2) / (ROC * 2) <= -DefaultDeltaAy || (ROC >= -RocThres && ROC < 0.0F)) {
    return -DefaultDeltaAy;
  } else {
    return powf(Distance, 2) / (ROC * 2);
  }
}

float extract_vru::ROC(float vehspd, float yrate) {
  if (fabsf(vehspd) >= 1.0) {
    if (vehspd / yrate >= MaxRocRaw || yrate == 0.0f) {
      return MaxRocRaw;
    } else if (vehspd / yrate <= -MaxRocRaw) {
      return -MaxRocRaw;
    } else {
      return vehspd / yrate;
    }
  } else {
    return MaxRocRaw;
  }
}

void extract_vru::clearobj(AEBCandidate& candi) {
  candi.obj.u8_ID                  = 0U;
  candi.obj.u8_VID                 = 0u;
  candi.obj.objectvalid            = 0U;
  candi.obj.f4_range               = 0.0f;
  candi.obj.f4_rangerate           = 0.0f;
  candi.obj.f4_TTC                 = DefaultTTC;
  candi.obj.f4_XOLC                = 0.0f;
  candi.obj.f4_latpos_est          = 0.0f;
  candi.obj.f4_vissup_dy           = 0.0f;
  candi.obj.f4_vissup_vy           = 0.0f;
  candi.obj.u8_Inpathage           = 0U;
  candi.obj.u8_Inpathage_warn      = 0U;
  candi.obj.u1_Inpath              = 0U;
  candi.obj.u1_Inpath_warn         = 0U;
  candi.obj.u1_TOI                 = 0U;
  candi.obj.u1_vfplaucheck         = 0U;
  candi.obj.u1_lfplaucheck         = 0U;
  candi.obj.u1_ageplaucheck        = 0U;
  candi.obj.u1_inpathagecheck      = 0U;
  candi.obj.u1_inpathagecheck_warn = 0U;
  candi.obj.u1_oncoming            = 0U;
  candi.obj.u1_preceding           = 0U;
  candi.obj.u1_longmove            = 0U;
  candi.obj.u1_latmove             = 0U;
  candi.obj.u1_crossing            = 0U;
  candi.obj.u8_AEBconf             = 0U;
  candi.obj.u8_lostradarage        = 0U;
  candi.obj.lastcyclesize          = 0;
}

void extract_vru::ClearRefPos(targetpos& ref_pos) {
  ref_pos.ref_character        = 0;
  ref_pos.centerpoint.pos_x    = 0;
  ref_pos.centerpoint.pos_y    = 0;
  ref_pos.centerpoint.range    = 0;
  ref_pos.frontcenter.pos_x    = 0;
  ref_pos.frontcenter.pos_y    = 0;
  ref_pos.frontcenter.range    = 0;
  ref_pos.rearcenter.pos_x     = 0;
  ref_pos.rearcenter.pos_y     = 0;
  ref_pos.rearcenter.range     = 0;
  ref_pos.leftcenter.pos_x     = 0;
  ref_pos.leftcenter.pos_y     = 0;
  ref_pos.leftcenter.range     = 0;
  ref_pos.rightcenter.pos_x    = 0;
  ref_pos.rightcenter.pos_y    = 0;
  ref_pos.rightcenter.range    = 0;
  ref_pos.referencepoint.pos_x = 0;
  ref_pos.referencepoint.pos_y = 0;
  ref_pos.referencepoint.range = 0;
  ref_pos.heading              = 0;
}

void extract_vru::clearCandidate() {
  clearobj(vru_candidate.pedestrian_cross_Candidate_);
  clearobj(vru_candidate.bicycle_cross_Candidate_);
  clearobj(vru_candidate.pedestrian_oncom_Candidate_);
  clearobj(vru_candidate.bicycle_oncom_Candidate_);
  clearobj(vru_candidate.pedestrian_rearcross_Candidate_);
  clearobj(vru_candidate.bicycle_rearcross_Candidate_);
  ClearRefPos(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos);
  ClearRefPos(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos);
  ClearRefPos(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos);
  ClearRefPos(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos);
  ClearRefPos(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos);
  ClearRefPos(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos);
  vru_candidate.pedestrian_cross_Candidate_.u8_Candi_ID      = 0;
  vru_candidate.pedestrian_cross_Candidate_.f4_minrange      = 100.0f;
  vru_candidate.pedestrian_cross_Candidate_.f4_minTTC        = DefaultTTC;
  vru_candidate.pedestrian_cross_Candidate_.u8_prefill       = 0;
  vru_candidate.pedestrian_cross_Candidate_.u8_warning       = 0;
  vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake      = 0;
  vru_candidate.pedestrian_cross_Candidate_.u8_highBrake     = 0;
  vru_candidate.pedestrian_cross_Candidate_.u8_VisID         = MaxVisionIndex;
  vru_candidate.bicycle_cross_Candidate_.u8_Candi_ID         = 0;
  vru_candidate.bicycle_cross_Candidate_.f4_minrange         = 100.0f;
  vru_candidate.bicycle_cross_Candidate_.f4_minTTC           = DefaultTTC;
  vru_candidate.bicycle_cross_Candidate_.u8_prefill          = 0;
  vru_candidate.bicycle_cross_Candidate_.u8_warning          = 0;
  vru_candidate.bicycle_cross_Candidate_.u8_lowBrake         = 0;
  vru_candidate.bicycle_cross_Candidate_.u8_highBrake        = 0;
  vru_candidate.bicycle_cross_Candidate_.u8_VisID            = MaxVisionIndex;
  vru_candidate.pedestrian_oncom_Candidate_.u8_Candi_ID      = 0;
  vru_candidate.pedestrian_oncom_Candidate_.f4_minrange      = 100.0f;
  vru_candidate.pedestrian_oncom_Candidate_.f4_minTTC        = DefaultTTC;
  vru_candidate.pedestrian_oncom_Candidate_.u8_prefill       = 0;
  vru_candidate.pedestrian_oncom_Candidate_.u8_warning       = 0;
  vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake      = 0;
  vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake     = 0;
  vru_candidate.pedestrian_oncom_Candidate_.u8_VisID         = MaxVisionIndex;
  vru_candidate.bicycle_oncom_Candidate_.u8_Candi_ID         = 0;
  vru_candidate.bicycle_oncom_Candidate_.f4_minrange         = 100.0f;
  vru_candidate.bicycle_oncom_Candidate_.f4_minTTC           = DefaultTTC;
  vru_candidate.bicycle_oncom_Candidate_.u8_prefill          = 0;
  vru_candidate.bicycle_oncom_Candidate_.u8_warning          = 0;
  vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake         = 0;
  vru_candidate.bicycle_oncom_Candidate_.u8_highBrake        = 0;
  vru_candidate.bicycle_oncom_Candidate_.u8_VisID            = MaxVisionIndex;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_Candi_ID  = 0;
  vru_candidate.pedestrian_rearcross_Candidate_.f4_minrange  = 100.0f;
  vru_candidate.pedestrian_rearcross_Candidate_.f4_minTTC    = DefaultTTC;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill   = 0;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_warning   = 0;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake  = 0;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake = 0;
  vru_candidate.pedestrian_rearcross_Candidate_.u8_VisID     = MaxVisionIndex;
  vru_candidate.bicycle_rearcross_Candidate_.u8_Candi_ID     = 0;
  vru_candidate.bicycle_rearcross_Candidate_.f4_minrange     = 100.0f;
  vru_candidate.bicycle_rearcross_Candidate_.f4_minTTC       = DefaultTTC;
  vru_candidate.bicycle_rearcross_Candidate_.u8_prefill      = 0;
  vru_candidate.bicycle_rearcross_Candidate_.u8_warning      = 0;
  vru_candidate.bicycle_rearcross_Candidate_.u8_lowBrake     = 0;
  vru_candidate.bicycle_rearcross_Candidate_.u8_highBrake    = 0;
  vru_candidate.bicycle_rearcross_Candidate_.u8_VisID        = MaxVisionIndex;
}

}  // namespace ad
}  // namespace nio
