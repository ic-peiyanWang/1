#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"
  

#ifndef AEB_EXTRACT_CCR_H_
#define AEB_EXTRACT_CCR_H_

namespace nio {
namespace ad {

    class extract_ccr {
        public: 
        extract_ccr();

        void MainFunction();

        private:

        void UpdateCalibration();

        void ExtractCCR();

        void clearCCRCandidate();

        void clearCCRCandidate_LF();

        float ROC(float vehspd, float yrate);

        float deltay(float ROC, float Distance, float egospd);

        float CalCCRTTC(float rrate, float relatacc, float range);

        float CalCCRTTC_1(float vego, float vtar,float aego, float atar, float range, bool isoncoming);

        void CalCCRTTB (AEBObjectCCR &ccr_tar);

        void CalCCRTTT (AEBObjectCCR &ccr_tar);

        float CalCCRTTCBased(float rrate, float range);

        float CalcHeadingEst (float Longvel, float Latvel, float heading, float headingrate, float TTC);

        // float CalCCRTTT(float vehWidth, float XOLC, float LataccMax,
        //           float ego_spd, float extendbuffer);

        // float CalCCRTTB(float RangeRate, float targetAcc);

        uint8_t DecideCCR_AEBConf(AEBObjectCCR &tmpobj);

        bool CCR_VF_Longpos_check(float fusionLongPos, float visionLongPos, float Rangerate, float egoacc);

        bool CCR_Age_check(bool isfusion, bool isradar, bool isvision, size_t tracklet_count, uint8_t age);

        MoveState DecideMoveState (float XOLC, float deltayawrate);

        bool DecideMoveOut (float XOLC, float deltayawrate);

        bool DecideTOI (float Range, float XOLC, float latvel, float rangerate, bool ismovable, float vehicle_width, targetpos position);

        float CalcYawDist(float EgoYawrate, float TTC, float Range, float targetmotion, float XOLC);

        float CalcHitDist (float XOLC, float latvel, float TTC);

        uint8_t SelectCCRSCandi(float Range, float XOLC, float TTC, float minTTC, float minRange);

        uint8_t SelectCCRMCandi(float Range, float XOLC, float TTC, float minTTC, float minRange, uint8_t ID, float ego_yawrate);

        void DecideCCRInPath (AEBObjectCCR &ccr_candi);

        void CalcCCRInPathAge(AEBObjectCCR &ccr_candi, AEBObjectCCR &ccr_candi_lf1, AEBObjectCCR &ccr_candi_lf2, AEBObjectCCR &ccr_candi_lf3, AEBObjectCCR &ccr_candi_lf4);

        void DecideCCRBrakeFlag (AEBObjectCCR &Candi, AEBObjectCCR &CS_lf1, AEBObjectCCR &CS_lf2, AEBObjectCCR &CM_lf1, AEBObjectCCR &CM_lf2); 

        void ClearRefPos(targetpos &ref_pos);

        void DecideOvertake(AEBObjectCCR &Candi, AEBObjectCCR &CS_lf1, AEBObjectCCR &CS_lf2, AEBObjectCCR &CM_lf1, AEBObjectCCR &CM_lf2);

        void CalculateMotion(AEBObjectCCR &Candi, AEBObjectCCR &Candi_lf);

        feature::math::LinearInterpolator<float> threshold_CCR_stationary_inner_funnel_;
        feature::math::LinearInterpolator<float> threshold_CCR_longitude_inner_funnel_;
        feature::math::LinearInterpolator<float> threshold_CCR_longitude_outter_funnel_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LongPos_VFcheck_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LowB_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_HighB_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_TTC_Addin_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Pref_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LowB_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_HighB_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_decel_TTC_Addin_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Pref_decel_TTC_;
        feature::math::LinearInterpolator<float> threshold_CCR_HitDist_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_YawDist_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_HitDist_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_YawDist_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLC_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLC_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Warn_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Pref_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Low_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_High_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Warn_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Pref_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Low_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_High_Mout_;
        feature::math::LinearInterpolator<uint8_t> threshold_CCR_InPathAge_;
        feature::math::LinearInterpolator<uint8_t> threshold_Undef_InPathAge_;
        feature::math::LinearInterpolator<float> threshold_movingout_deltayaw_;
        feature::math::LinearInterpolator<float> threshold_CCR_takeover_steerangle_;
        feature::math::LinearInterpolator<float> threshold_CCR_takeover_gasped_;
        feature::math::LinearInterpolator<float> threshold_ccr_ttt_latsafe_;
        feature::math::LinearInterpolator<float> threshold_ccr_ttb_longsafe_;
        feature::math::LinearInterpolator2D<float> threshold_ccr_ttt_offset_;
        feature::math::LinearInterpolator2D<float> threshold_ccr_ttb_offset_;
    };

    extern extract_ccr ccr_extraction_;

}
}
#endif