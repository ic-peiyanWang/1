#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"
//#include "AesPNC.h"


#ifndef PATH_VERIFICATION_H_
#define PATH_VERIFICATION_H_

namespace nio {
namespace ad {
    class path_verification {
        public:
        path_verification();

        void MainFunction();

        float reservedtime = 0;

        bool path_targetvalid = 0;

        bool path_routvalid = 0;

        uint8_t crash_id = 0;

        uint8_t crash_lane = 0;

        private:

        void UpdatePath();

        void UpdateLineInfo();

        void Determine_Path_Target (float reservedtime, uint8_t &crashid, bool &pathvalid);

        void Determine_Path_Rout (uint8_t &crashlane, bool &routvalid);

        bool CheckPoliValid (AES_Path aes_path, Line_Poli extern_line, float hostwidth, float longposest);

        void CalcCenterPoint (AESObjectCCR &tmpobj);

        void CalcCornerPoint (AESObjectCCR &tmpobj);

        void CalcCornerPointEsti (AESObjectCCR &tmpobj, float remain_time);

        void CalcLatEsti (CornerPos &cornerpoint, float longspd, float latspd, float remain_time);

        float CalcReserveTime(float vspd, float egoacc, float range);

        void UpdateEgoPos (EgoPos &ego_pos, AES_Path aes_path, float remain_time);

        bool DecideCrash (AESObjectCCR &tmpobj, EgoPos ego_pos);

        float CalCornerDist (CornerPos cornerpoint, float x, float y);
    };
    
    extern path_verification path_verify_;
}
}
#endif