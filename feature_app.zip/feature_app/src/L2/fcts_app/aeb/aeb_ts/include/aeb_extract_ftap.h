#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"

#ifndef AEB_EXTRACT_FTAP_H_
#define AEB_EXTRACT_FTAP_H_

namespace nio {
namespace ad {

class extract_ftap {

    public: 
        extract_ftap();

        void MainFunction();

        private:

        void UpdateCalibration();

        void ExtractBrakePoint();

        void ClearFTAPCandi();

        void UpdateRefPos(targetpos &ref_pos);

        float CalculateCirRange(float col_y, float ego_roc);

        float CalculateCirX (float col_y, float longpos, float latpos, float heading);

        float CalculateCornerRange(float col_y, float ego_roc);

        float CalculateCirTTC (float col_r, float egospd, uint8_t col_N, float egoacc, bool AEBactive);

        float CalculateCirTTL (float col_r, float egospd, uint8_t col_N, float egoacc, bool AEBactive);

        float CalculateCirCurRange(float longpos, float latpos, float colx, float coly, uint8_t col_N, float longspd);

        float CalculateCirPreRange(float longpos, float latpos, float longspd, float latspd, float TTC, float colx, float coly, uint8_t col_N, float longacc, float latacc);

        MoveState DecideMoveState(float longpos, float latpos, float longspd, float latspd, float TTC, float ROC);

        uint8_t DecideCCR_AEBConf(AEBObjectFTAP &tmpobj);

        bool CCR_VF_Longpos_check(float fusionLongPos, float visionLongPos, float Rangerate, float egoacc);

        bool CCR_Age_check(bool isfusion, bool isradar, bool isvision, size_t tracklet_count, uint8_t age);

        bool DecideTargetOncoming (float longvel, float range);

        float CalculateCirAngle(float col_y, float ego_roc);

        uint8_t DecideFTAPTOI (float range, float longvel, float latvel, float targetangle, bool isoncoming, float egospd, bool notmoveout);

        bool DecideInpathpre(float range, float targetlength, float headingangle, MoveState movestate, float rangeestimate, float ColRange, float targetspd);

        bool DecideInpathpre_warn(float range, float targetlength, float headingangle, MoveState movestate, float rangeestimate, float ColRange, float targetspd);

        bool DecideInpathcur(float range, float targetlength, float headingangle, float rangecur, float ColRange, float targetspd);

        bool DecideInpathcur_warn(float range, float targetlength, float headingangle, float currentrange, float ColRange, float targetspd);

        bool DecideInpathpre_after(float range, float targetlength, float headingangle, MoveState movestate, float rangeestimate, float ColRange, float targetspd);

        uint8_t CalculateInPathAge(bool inpath, uint8_t inpathage_1, uint8_t inpathage_2, uint8_t ID, uint8_t ID_1, uint8_t ID_2);

        bool DecideInPathAgeCheck (uint8_t inpathage, uint8_t AEBconf);

        bool DecideInPathAgeCheck_warn (uint8_t inpathage, uint8_t AEBconf);

        void DecideInpathTar(AEBObjectFTAP &Candi, AEBObjectFTAP &Candi_LF, AEBObjectFTAP &Candi_LF2);

        void DecideFTAPFlag(AEBObjectFTAP &Candi, AEBObjectFTAP &Candi_LF, AEBObjectFTAP &Candi_LF2);

        void ClearRefPos(targetpos &ref_pos);

        feature::math::LinearInterpolator2D<float> threshold_CCR_LongPos_VFcheck_;
        feature::math::LinearInterpolator<float> threshold_FTAP_OncomingSpd_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_predict_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_current_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_expend_predict_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_expend_current_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_predict_warn_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_current_warn_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_expend_predict_warn_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_expend_current_warn_;
        feature::math::LinearInterpolator<float> threshold_FTAP_range_;
        //feature::math::LinearInterpolator<float> threshold_movingout_deltayaw_;
        feature::math::LinearInterpolator<uint8_t> threshold_CCFTAP_InPathAge_;
        feature::math::LinearInterpolator<uint8_t> threshold_CCFTAP_InPathAge_warn_;
        feature::math::LinearInterpolator<float> threshold_CCFTAP_WarningTTC_;
        feature::math::LinearInterpolator<float> threshold_CCFTAP_PrefillTTC_;
        feature::math::LinearInterpolator<float> threshold_CCFTAP_LowBrakeTTC_;
        feature::math::LinearInterpolator<float> threshold_CCFTAP_HighBrakeTTC_;
        feature::math::LinearInterpolator2D<float> threshold_FTAP_expend_predict_after_;


};

extern extract_ftap ftap_extraction_;

}
}
#endif