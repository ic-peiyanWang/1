#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"
  

#ifndef AES_EXTRACT_CCR_H_
#define AES_EXTRACT_CCR_H_

namespace nio {
namespace ad {

    class extract_aesccr {
        public: 
        extract_aesccr();

        void MainFunction();

        private:

        void UpdateCalibration();

        void ExtractAESCCR();

        void clearCCRCandidate();

        void clearCCRCandidate_LF();

        float ROC(float vehspd, float yrate);

        float deltay(float ROC, float Distance, float egospd);

        float CalCCRTTC(float rrate, float relatacc, float range);

        float CalCCRTTC_1(float vego, float vtar,float aego, float atar, float range, bool isoncoming);

        void CalCCRTTB (AESObjectCCR &ccr_tar);

        void CalCCRTTT_Left (AESObjectCCR &ccr_tar);
        void CalCCRTTT_Right (AESObjectCCR &ccr_tar);

        float CalCCRTTCBased(float rrate, float range);

        float CalcHeadingEst (float Longvel, float Latvel, float heading, float headingrate, float TTC);

        // float CalCCRTTT(float vehWidth, float XOLC, float LataccMax,
        //           float ego_spd, float extendbuffer);

        // float CalCCRTTB(float RangeRate, float targetAcc);

        uint8_t DecideCCR_AEBConf(bool isfusion, bool isfused, bool isvision, bool isradar, float matchconf);

        bool CCR_VF_Longpos_check(float fusionLongPos, float visionLongPos, float Rangerate, float egoacc);

        bool CCR_Age_check(bool isfusion, bool isradar, bool isvision, size_t tracklet_count, uint8_t age);

        MoveState DecideMoveState (float XOLC, float deltayawrate);

        bool DecideMoveOut (float XOLC, float deltayawrate);

        bool DecideTOI (AESObjectCCR &tmpobj);

        uint8_t SelectAESCandi(AESObjectCCR &tmpobj);

        void CalcCCRInPathAge(AESObjectCCR &ccr_candi, AESObjectCCR &ccr_candi_lf1, AESObjectCCR &ccr_candi_lf2);

        void DecideCCRAction (AESObjectCCR &Candi, AESObjectCCR &CS_lf1,  AESObjectCCR &CM_lf1, FusionAEBFlag CCR_flag, FusionAEBFlag VRU_flag);

        void ClearCandiCorner (CornerPos &point);

        void CalcCenterPoint (AESObjectCCR &tmpobj);

        void CalcCornerPoint (AESObjectCCR &tmpobj);

        void CalcCurCornerPoint (float roc, AESObjectCCR &tmpobj);

        void CalcCornerPointEsti (AESObjectCCR &tmpobj);

        void CalcLatEsti (CornerPos &cornerpoint, float latspd, float ttc);

        void CalcInPathCur (AESObjectCCR &tmpobj);

        void CalcInPathPre (AESObjectCCR &tmpobj);

        void UpdateLineInfo();

        void UpdateLppInfo();

        void DetermineSteerDirection(AESObjectCCR &ccr_candi, AESObjectCCR &ccr_candi_lf1, AESObjectCCR &ccr_candi_lf2, Line_Poli host_left, Line_Poli host_right, Line_Poli left_edge, Line_Poli right_edge, Lpp_Poli host_lpp);

        void DecideDirectionValid(AESObjectCCR ccr_candi, Line_Poli host_left, Line_Poli host_right, float target_width, bool &left_valid, bool &right_valid);

        void DetermineOncomLane();

        feature::math::LinearInterpolator<float> threshold_CCR_stationary_inner_funnel_;
        feature::math::LinearInterpolator<float> threshold_CCR_longitude_inner_funnel_;
        feature::math::LinearInterpolator<float> threshold_CCR_longitude_outter_funnel_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LongPos_VFcheck_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LowB_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_HighB_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Pref_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_LowB_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_HighB_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Warn_decel_TTC_;
        feature::math::LinearInterpolator2D<float> threshold_CCR_Pref_decel_TTC_;
        feature::math::LinearInterpolator<float> threshold_CCR_HitDist_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_YawDist_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_HitDist_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_YawDist_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLC_Before_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLC_After_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Warn_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Pref_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Low_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_High_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Warn_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Pref_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_Low_Mout_;
        feature::math::LinearInterpolator<float> threshold_CCR_XOLCper_High_Mout_;
        feature::math::LinearInterpolator<uint8_t> threshold_AES_InPathAge_;
        feature::math::LinearInterpolator<float> threshold_movingout_deltayaw_;
        feature::math::LinearInterpolator<float> threshold_ccr_ttt_latsafe_;
        feature::math::LinearInterpolator<float> threshold_ccr_ttb_longsafe_;
        feature::math::LinearInterpolator2D<float> threshold_ccr_ttt_offset_;
        feature::math::LinearInterpolator2D<float> threshold_ccr_ttb_offset_;
        feature::math::LinearInterpolator2D<float> threshold_aes_inpath_current_;
        feature::math::LinearInterpolator2D<float> threshold_aes_inpath_predict_;

        uint8_t oncom_lane_pos = 0; //0: no oncoming, bit0: left lane, bit 1: right lane, bit2: host lane.
        
    };

    extern extract_aesccr aesccr_extraction_;

}
}
#endif