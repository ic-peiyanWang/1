#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "fcts_input_adapter.h"
#include "ehy_math/nio_vmath.h"
#include "aeb_strategy_type.h"


#ifndef AEB_EXTRACT_VRU_H_
#define AEB_EXTRACT_VRU_H_

namespace nio {
namespace ad {

class extract_vru {
    public:
    extract_vru();

    void MainFunction();

    private:

    float prefill_TTC = 0.0f;
    float warning_TTC = 0.0f;
    float lowbrake_TTC = 0.0f;
    float highbrake_TTC = 0.0f;

    float prefill_TTC_rear = 0.0f;
    float warning_TTC_rear = 0.0f;
    float lowbrake_TTC_rear = 0.0f;
    float highbrake_TTC_rear = 0.0f;


    void ExtractPed();

    void UpdateCalibration ();

    void clearCandidate();

    void clearobj(AEBCandidate &candi);

    void clearCandidate_LF();

    float ROC(float vehspd, float yrate);

    float deltay(float ROC, float Distance, float egospd);

    float CalPedTTC(float rrate, float egoacc, float range, float egospd, bool aebactive);

    float CalPedTTC_rear(float rrate, float egoacc, float range, float egospd, bool aebactive);

    uint8_t decidePedAEBConf(AEBObject& tmp_obj);

    bool visionfusioncheck(float cur_dy, float cur_vy, float vis_dy,
                         float vis_vy, float longpos, float hostacc);

    bool DecideLongMoveNew(float longpos, float longvel);

    bool DecideLatMoveNew(float longpos, float latvel);

    bool lastframecheck(float cur_dy, float cur_vy, float lf_dy,
                      float lf_vy, float longpos, float hostacc);
    
    bool DecideLongMove(float longpos, float longvel, bool lfst);

    bool DecideLatMove(float longpos, float latvel, bool lfst);

    bool agecheck(uint8_t age, bool iscrossing, bool isoncoming, bool ispreceding, bool ismovable, uint8_t AEBconf);

    float CalLatPosEst(float pedXOLC, float pedlatvel, float pedTTC);

    bool InPathCheck(bool preciding, bool ismoving, bool oncoming, bool crossing, bool ispedestrian, bool isbicycle, float range, float egospd, float latspd, float XOLC, float latposest, float heading, float length, AEBObject &tmp_obj);

    bool InPathCheck_warn(bool preciding, bool ismoving, bool oncoming, bool crossing, bool ispedestrian, bool isbicycle, float range, float egospd, float latspd, float XOLC, float latposest, bool ismovable, float heading, float length, AEBObject &tmp_obj);

    uint8_t CalcInpathAge(bool inpath, uint8_t in_path_age);

    bool InPathAgeCheck(uint8_t inpathage, bool iscrossing, bool isoncoming,
                        bool ispreceding, bool ismoving, uint8_t AEBconf);

    bool InPathAgeCheck_warn(uint8_t inpathage, bool iscrossing, bool isoncoming, bool ispreceding, bool ismoving, uint8_t AEBconf);

    void decideTTCThreshold(float egospd, bool ispedestrian, bool isbicycle, bool crossing, bool preceding, bool ismoving, bool oncoming);

    void SelectAEBCandidate_rear(AEBObject &tmp_obj, AEBCandidate &ped_rear, AEBCandidate &bik_rear, AEBCandidate &ped_rear_lf, AEBCandidate &bik_rear_lf);

    void DecideCandi_rear(AEBObject &tmp_obj, AEBCandidate &vru_rear, AEBCandidate &vru_rear_lf, bool brake_lf);

    void SelectAEBCandidate(AEBObject &tmp_obj, bool ismoving);

    void CalcPedCirRoot(AEBObject &tmp_obj, float ego_ROC);

    void decidePedHighflag(AEBObject &tmp_obj, AEBCandidate &vru_candi);
    void decidePedLowflag(AEBObject &tmp_obj, AEBCandidate &vru_candi);
    void decidePedPrefflag(AEBObject &tmp_obj, AEBCandidate &vru_candi);
    void decidePedWarnflag(AEBObject &tmp_obj, AEBCandidate &vru_candi);
    void ClearRefPos(targetpos &ref_pos);

    feature::math::LinearInterpolator<float> threshold_visionfusion_vel_plaus_;
    feature::math::LinearInterpolator<float> threshold_visionfusion_pos_plaus_;
    feature::math::LinearInterpolator<float> threshold_longmove_decide_;
    feature::math::LinearInterpolator<float> threshold_latmove_decide_;
    feature::math::LinearInterpolator<uint8_t> threshold_crossageplau_;
    feature::math::LinearInterpolator<uint8_t> threshold_longageplau_;
    feature::math::LinearInterpolator<uint8_t> threshold_crossage_;
    feature::math::LinearInterpolator<uint8_t> threshold_crossage_turn_;
    feature::math::LinearInterpolator<uint8_t> threshold_longage_;
    feature::math::LinearInterpolator2D<float> threshold_stationary_predict_;
    feature::math::LinearInterpolator2D<float> threshold_stationary_current_;
    feature::math::LinearInterpolator2D<float> threshold_longmove_predict_;
    feature::math::LinearInterpolator2D<float> threshold_longmove_current_;
    feature::math::LinearInterpolator2D<float> threshold_cross_predict_;
    feature::math::LinearInterpolator2D<float> threshold_cross_current_;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_predict;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_current;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_predict_Bik;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_current_Bik;
    feature::math::LinearInterpolator<float> threshold_prefill_crossped;
    feature::math::LinearInterpolator<float> threshold_prefill_rearcrossped;
    feature::math::LinearInterpolator<float> threshold_prefill_crossbik;
    feature::math::LinearInterpolator<float> threshold_prefill_precedped;
    feature::math::LinearInterpolator<float> threshold_prefill_precedbik;
    feature::math::LinearInterpolator<float> threshold_prefill_oncomped;
    feature::math::LinearInterpolator<float> threshold_prefill_oncombik;
    feature::math::LinearInterpolator<float> threshold_warn_crossped;
    feature::math::LinearInterpolator<float> threshold_warn_rearcrossped;
    feature::math::LinearInterpolator<float> threshold_warn_crossbik;
    feature::math::LinearInterpolator<float> threshold_warn_precedped;
    feature::math::LinearInterpolator<float> threshold_warn_precedbik;
    feature::math::LinearInterpolator<float> threshold_warn_oncomped;
    feature::math::LinearInterpolator<float> threshold_warn_oncombik;
    feature::math::LinearInterpolator<float> threshold_lowbrake_crossped;
    feature::math::LinearInterpolator<float> threshold_lowbrake_rearcrossped;
    feature::math::LinearInterpolator<float> threshold_lowbrake_crossbik;
    feature::math::LinearInterpolator<float> threshold_lowbrake_precedped;
    feature::math::LinearInterpolator<float> threshold_lowbrake_precedbik;
    feature::math::LinearInterpolator<float> threshold_lowbrake_oncomped;
    feature::math::LinearInterpolator<float> threshold_lowbrake_oncombik;
    feature::math::LinearInterpolator<float> threshold_highbrake_crossped;
    feature::math::LinearInterpolator<float> threshold_highbrake_rearcrossped;
    feature::math::LinearInterpolator<float> threshold_highbrake_crossbik;
    feature::math::LinearInterpolator<float> threshold_highbrake_precedped;
    feature::math::LinearInterpolator<float> threshold_highbrake_precedbik;
    feature::math::LinearInterpolator<float> threshold_highbrake_oncomped;
    feature::math::LinearInterpolator<float> threshold_highbrake_oncombik;

    feature::math::LinearInterpolator2D<float> threshold_stationary_predict_warn_;
    feature::math::LinearInterpolator2D<float> threshold_stationary_current_warn_;
    feature::math::LinearInterpolator2D<float> threshold_longmove_predict_warn_;
    feature::math::LinearInterpolator2D<float> threshold_longmove_current_warn_;
    feature::math::LinearInterpolator2D<float> threshold_cross_predict_warn_;
    feature::math::LinearInterpolator2D<float> threshold_cross_current_warn_;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_predict_warn_;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_current_warn_;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_predict_warn_Bik;
    feature::math::LinearInterpolator2D<float> threshold_cross_expend_current_warn_Bik;
    feature::math::LinearInterpolator<uint8_t> threshold_crossage_warn_;
    feature::math::LinearInterpolator<uint8_t> threshold_crossage_turn_warn_;
    feature::math::LinearInterpolator<uint8_t> threshold_longage_warn_;

};

extern extract_vru vru_extraction_;

}
}
#endif