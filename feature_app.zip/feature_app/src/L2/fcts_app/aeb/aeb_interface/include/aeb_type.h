//#pragma once
#ifndef AEB_TYPE_H
#define AEB_TYPE_H

#include <cstdint>

namespace nio {
    namespace ad {

        enum class aebst_e{
            off = 0,
            passive = 1,
            standby = 2,
            factive = 3,
            ractive = 4,
            tmperr  = 5,
            prmnterr = 6,
        };

        enum class aebsysst_e{
            init = 0,
            standby = 1,
            active = 2,
            inhibit = 3,
            off = 4,
        };

        enum class aebmsg_e {
            off       = 0,
            temp_fail = 1,
            perm_fail = 2,
            snsr_blk  = 12,
        };

        enum class RearSmSt{
            kOff        = 0, //Off
            kStandby    = 1, //On
            kPassive    = 2, //On
            kFail       = 3, //Inhibit
            kActive     = 4, //On
            kReserved   = 5, //Reserved
        };

        class RearSm{
        private:
            bool            off_cdn_;
            bool            stdby_cdn_;
            bool            psv_cdn_;
            uint32_t        psv_cdn_bit_;
            bool            fail_cdn_;
            bool            active_cdn_;

            RearSmSt        sm_state_;

            virtual void    UpdateOffCondition();
            void            UpdateStandbyCondition();
            void            UpdatePassiveCondition();
            void            UpdateFailCondition();
            virtual void    UpdateActiveCondition();
            void            UpdateState();

        public:
            RearSm();
            ~RearSm();
            void            set_off_cdn(bool cdn){off_cdn_ = cdn;};
            void            set_stdby_cdn(bool cdn){stdby_cdn_ = cdn;};
            void            set_psv_cdn(bool cdn){psv_cdn_ = cdn;};
            void            set_psv_cdn_bit(uint32_t value){psv_cdn_bit_ = value;};
            void            set_fail_cdn(bool cdn){fail_cdn_ = cdn;};
            void            set_act_cdn(bool cdn){active_cdn_ = cdn;};
            void            set_sm_state(RearSmSt state){sm_state_ = state;};

            bool            get_off_cdn(){return off_cdn_;};
            bool            get_stdby_cdn(){return stdby_cdn_;};
            bool            get_psv_cdn(){return psv_cdn_;};
            uint32_t        get_psv_cdn_bit(){return psv_cdn_bit_;};
            bool            get_fail_cdn(){return fail_cdn_;};
            
            bool            get_act_cdn(){return active_cdn_;};

            RearSmSt        get_state(){return sm_state_;};
            void            Main();
        };

        class AebRearSm : public RearSm{
            private:
                void UpdateOffCondition();
                void UpdateActiveCondition();

            public:
                AebRearSm();
                ~AebRearSm();
        };


        class AEBSM
        {
        private:
            bool m_psvcdn;
            bool m_tmpfail;
            bool m_permfail;
            bool m_snsrblk;
            bool m_frwrdactv;
            bool m_bckwrdactv;
            bool m_isAEBOn;
            bool m_stdby;
            /* data */
            bool    m_ABPReq;   //Automatic Brake Prefill (EBP) Request
            int     m_ABAReq;
            int     m_EBADecReq;
            int     m_ABASenLvl;// adaptive brake assist sensitivity level
            bool    m_AEBDecReq;
            bool    m_AWBReq;
            int     m_AWBSenLvl;//Automatic Warning Brake (AEB) request. (Brake Jerk Warning)
            double  AEBTarDec;
            aebst_e m_AebSt;
            aebsysst_e m_AebSysSt;
        public:
            AEBSM(/* args */);
            ~AEBSM();
            void set_snsrblk_cdn(bool);
            void set_tmpfail_cdn(bool);
            void set_permfail_cdn(bool);
            void set_psv_cdn(bool);
            void set_aebonff_cdn(bool);
            void set_frwrdactv_cdn(bool);
            void set_bckwrdactv_cdn(bool);
            void set_stdby_cdn(bool);
            bool get_snsrblk_cdn(void);
            bool get_tmpfail_cdn(void);
            bool get_permfail_cdn(void);
            bool get_psv_cdn(void);
            bool get_aebOnff_cdn(void);
            bool get_frwrdactv_cdn(void);
            bool get_bckwrdactv_cdn(void);
            bool get_stdby_cdn(void);
            aebst_e get_aeb_st(void);
            aebsysst_e get_aeb_sys_st(void);

            void update_AEB_State(void);
        };

        struct AEBTRGETFLG{
            bool prewarn;
            bool prewarn_lf;
            bool latentwarn;
            bool prefill;
            bool warnbrk;
            bool warnbrk_lf;
            bool softbrk;
            bool hardbrk;
            bool iba_req;
            int warntype;
            bool hold_req;
        };

        struct AEBFLG{
            AEBTRGETFLG ped; 
            AEBTRGETFLG cyclist; 
            AEBTRGETFLG car; 
            AEBTRGETFLG pedrear;
        };
        class AEBREQ
        {
        private:
            /* data */
            double m_decreq;
            bool m_ebareq;
            bool m_abareq;
            unsigned char m_abalvl;
            bool m_aebreq;
            bool m_abpreq;
            aebmsg_e  m_txtinfo;
            double m_txttime;
            double m_txttithr;
            bool m_snsblk_displayed;
            bool m_tmpfail_displayed;
            bool m_prmfail_displayed;
        public:
            AEBREQ(/* args */);
            ~AEBREQ();
            void set_eba_req(bool);
            void set_aba_req(bool);
            void set_aeb_req(bool);
            void set_dec_req(double);
            void set_abalvl_req(unsigned char);
            void set_abp_req(bool);
            bool get_eba_req(void);
            bool get_aba_req(void);
            bool  get_aeb_req(void);
            double get_dec_req(void);
            unsigned char get_abalvl_req(void);
            bool get_abp_req(void);
            void set_aeb_txt_info(bool,bool,bool);
        };

        class AEB
        {
        private:
            /* data */
        public:
            AEB(/* args */);
            ~AEB();
        };

    }

}

#endif