#pragma once
#include "aeb_type.h"
#include <stdint.h>

namespace nio{
    namespace ad{

        enum class fcwst_e{
            off = 0,
            passive = 1,
            standby = 2,
            factive = 3,
            ractive = 4,
            tmperr  = 5,
            prmnterr = 6,
        };

        enum class fcwsysst_e{
            init = 0,
            standby = 1,
            active = 2,
            inhibit = 3,
            off = 4,
        };

        enum class fcwsetst_e{
            early = 0,
            normal = 1,
            late = 2,
            off = 3,
        };

        extern unsigned char fcwsetst;
        extern uint8_t awbcycle;

        class FcwRearSm : public RearSm{
            private:
                void UpdateOffCondition();
                void UpdateActiveCondition();

            public:
                FcwRearSm();
                ~FcwRearSm();
        };

        class FCWSM:public AEBSM
        {
        private:
            /* data */
            bool m_prevwarnswt;
            bool m_latentwarnswt;
            unsigned char m_fcwsetst;
            bool m_awbreq;
            unsigned char m_awblvl;
            fcwst_e m_fcwst;
            fcwsysst_e m_fcwsysst; 
        public:
            FCWSM(/* args */);
            ~FCWSM();
            fcwsysst_e get_fcw_sys_st();
            void update_FCW_State(void);
        };



        class FCWREQ
        {
        private:
            /* data */
            bool m_latentwarn;
            int m_prewarn;
            bool m_awbreq;
            unsigned char m_awblvl;
        public:
            FCWREQ(/* args */);
            ~FCWREQ();
            void set_pre_warn(int);
            void set_latent_warn(bool);
            void set_awb_req(bool);
            void set_awb_lvl(unsigned char);
            int  get_pre_warn(void);
            bool get_latent_warn(void);
            bool get_awb_req(void);
            unsigned char get_awb_lvl(void);
        };

    }

}
