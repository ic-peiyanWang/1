#ifndef FEATURE_AEB_OUTPUT_PUBLISHER_H_
#define FEATURE_AEB_OUTPUT_PUBLISHER_H_

#include "niodds/application/application.h"
#include "np/apps/arb_out.pb.h"
#include "np/apps/fcts_out.pb.h"
#include "np/debug/dgb_aebstrategy.pb.h"
//#include "aeb_in_house.h"
#include "aeb_dm.h"
#include "aeb_gof.h"
#include "aeb_state.h"
#include "aeb_strategy_type.h"
#include "fcts_input_adapter.h"
#include "fcw_state.h"

using nio::ad::messages::FctsOut;

namespace nio {
namespace ad {
// extern std::shared_ptr<nio::ad::messages::ARBOut>             arb_out_data;
// extern std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_debug_data;

class AEBOutputPublisher {
 private:
  // std::shared_ptr<Publisher<nio::ad::messages::ARBOut>> m_pub_arbout_;
  // std::shared_ptr<Publisher<nio::ad::messages::debug::AEBDebugOut>> m_pub_aebdebugout_;
  // std::unique_ptr<Node> m_node_;

 public:
  AEBOutputPublisher();

  bool MainFcn();
  bool fill_in_ARBflag_outputs(std::shared_ptr<nio::ad::messages::ARBOut> arb_out);
  bool fill_in_AEBdebug_outputs(std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_out);
};
}  // namespace ad
}  // namespace nio

#endif
