#pragma once

#include <array>
#include "fcts_input_adapter.h"
#include "aeb_const_par.h"


#ifndef FEATURE_ARB_AEB_Strategy_
#define FEATURE_ARB_AEB_Strategy_

namespace nio {
namespace ad {

    enum AEBAlertSt : uint16_t {
        kAEBAlertNoActive = 0x9966,
        kAEBAlertActive = 0xAA55
    };

    enum MoveState : uint8_t {
        kInit = 0U,
        kNueutral = 1U,
        kMoving_in = 2U,
        kMoving_out = 3U,
        kMoving_through = 4U
    };

    struct calc_tt {
        float tt = 25.5;
        bool isvalid = false;
    };

    struct tarpos_estimate {
        float longpos = 1000;
        float latpos = 0;
    };

    struct AES_Control_Input {
        float explatdst = 0;
        float explondst = 0;
        uint8_t aesplanactv = 0;
        float ltrldstlacntr = 0;
        float egolawdth = 0;
        float agvehlanecntr = 0;
        float lacurv = 0;
        float ladcurv = 0;
        float vehspdkph = 0;
        float dispvehspdkph = 0;
        float steering_direction = 0;
    };

    struct AES_Plan_Group {
        float cos_a = 0;
        float cos_b = 0;
        float cos_phi = 0;
        float cos_n = 0;
        float curv = 0;
        float dcurv = 0;
        float explat = 0;
        float explon = 0;
        bool isvalid = 0;
        float rout_cost = 100;
        float max_ay = 0;
    };

    struct LastFrameIndex {
        uint8_t pedcross_idx = 255;
        uint8_t pedoncom_idx = 255;
        uint8_t bikcross_idx = 255;
        uint8_t bikoncom_idx = 255;
        uint8_t ccrs1_idx = 255;
        uint8_t ccrm1_idx = 255;
        uint8_t ccftap_idx = 255;
    };

    struct linepoint {
        float pos_x = 0;
        float pos_y = 0;
        float range = 0;
    };

    struct targetpos {
        uint8_t ref_character = 0; //0: center point; 1: front center; 2: rear center; 3: left center; 4: right center;
        linepoint centerpoint;
        linepoint frontcenter;
        linepoint rearcenter;
        linepoint leftcenter;
        linepoint rightcenter;
        linepoint referencepoint;
        float heading;
    };

    struct CornerPos {
        float pos_x = 100;
        float pos_y = 100;
        float range = 100;
        float cur_x = 100;
        float cur_y = 100;
        float long_est = 100;
        float lat_est = 100;
    };

    struct EgoPos {
        float pos_x_f = 100;
        float pos_y_f = 100;
        float pos_x_m = 100;
        float pos_y_m = 100;
        float pos_x_r = 100;
        float pos_y_r = 100;
    };

    struct AEBObjectCCR {
        feature::ehy::Object obj;
        targetpos ref_pos;
        uint8_t u8_ID = 0U;
        size_t u8_IDX = MaxVisionIndex;
        uint32_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_range = 0.0f;
        float f4_rangerate = 0.0f;
        float f4_relatAcc = 0.0f;
        float f4_TTC = DefaultTTC;
        float f4_TTCbased = DefaultTTC;
        float f4_TTC_new = DefaultTTC;
        calc_tt TTB;
        calc_tt TTB_bf;
        calc_tt TTT;
        float f4_XOLC = 0.0f;
        float f4_latest = 0.0f;
        float f4_vissup_dx = 0.0f;
        float f4_TrackHeadingEst = 0.0f;
        float f4_TTEmax = 0.0f;
        float f4_TTEmin = 0.0f;
        float yawdist = 0.0f;
        float hitdist = 0.0f;
        uint8_t u8_Inpathage = 0U;
        bool u1_Inpath_Before = 0U;
        bool u1_Inpath_After = 0U;
        bool u1_Inpath = 0;
        uint8_t u1_TOI = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_headplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_oncoming = 0U;
        bool u1_preceding = 0U;
        bool u1_longmove = 0U;
        bool u1_latmove = 0U;
        bool u1_crossing = 0U;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        float f4_minTTC = DefaultTTC;
        float f4_minRange = 200.0f;
        MoveState u1_movingstate = MoveState::kInit;
        bool u1_ismovingout = 0;
        bool warnig_flag = 0U;
        bool prefill_flag = 0U;
        bool lowbrake_flag = 0U;
        bool highbrake_flag = 0U;
        bool iba_flag = 0U;
        bool driverovertake = 0U;
        bool driverovertake_warn = 0U;
        uint8_t movingleftcount = 0U;
        uint8_t movingrightcount = 0U;
        bool steer_flag = 0U;
        bool brake_flag = 0U;
        float steer_direction = 0;
        tarpos_estimate position_esti;
    };
    
    struct AEBObjectCCC {
        feature::ehy::Object obj;
        targetpos ref_pos;
        uint8_t u8_ID = 0U;
        size_t u8_IDX = MaxVisionIndex;
        uint32_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_TTC = DefaultTTC;
        float f4_TTL = DefaultTTL;
        float TTC_tar = DefaultTTC;
        float TTL_tar = DefaultTTL;
        float f4_range = 1000.0f;
        float f4_rangerate = 0.0f;
        float f4_vissup_dx = 0.0f;
        float f4_vissup_dy = 0.0f;
        float f4_vissup_vx = 0.0f;
        float f4_vissup_vy = 0.0f;
        uint8_t u8_col_pointN = 0u;
        float f4_collisionx_1 = 1000.0f;
        float f4_collisiony_1 = 1000.0f;
        float f4_collisionr_1 = 1000.0f;
        float f4_longpos = 1000.0f;
        float f4_latpos = 1000.0f;
        float f4_longvel = 0.0f;
        float f4_latvel = 0.0f;
        float f4_Heading = 0.0f;
        float f4_Headangle = 0.0f;
        float f4_angle_tar = 0.0;
        float f4_currentRange = 1000.0f;
        float f4_rangeestimation = 1000.0f;
        uint8_t u8_Inpathage = 0U;
        uint8_t u8_Inpathage_warn = 0u;
        bool u1_inpathcur = 0;
        bool u1_inpathpre = 0;
        bool u1_Inpath = 0;
        bool u1_inpathcur_warn = 0;
        bool u1_inpathpre_warn = 0;
        bool u1_Inpath_warn = 0;
        bool u1_inpath_tar = 0;
        uint8_t u1_TOI_Before = 0U;
        uint8_t u1_TOI_After = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_inpathagecheck_warn = 0U;
        bool u1_oncoming = 0U;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        float f4_minTTC = DefaultTTC;
        float f4_minRange = 200.0f;
        MoveState u1_movingstate = MoveState::kInit;
        uint8_t warnig_flag = 0U;
        uint8_t prefill_flag = 0U;
        uint8_t lowbrake_flag = 0U;
        uint8_t highbrake_flag = 0U;
        uint8_t iba_flag = 0U;
        feature::math::Vector2f HostPos_tar;
        feature::math::Vector2f HostPos;
        feature::math::Vector2f HostVel;
        float turnangle = 0;
        float target_spd = 0; 
        float predictrange_tar = 0; 
    };

    struct AEBObjectFTAP {
        feature::ehy::Object obj;
        targetpos ref_pos;
        uint8_t u8_ID = 0U;
        size_t u8_IDX = MaxVisionIndex;
        uint32_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_TTC = DefaultTTC;
        float f4_TTL = DefaultTTL;
        float f4_range = 1000.0f;
        float f4_rangerate = 0.0f;
        float f4_vissup_dx = 0.0f;
        float f4_vissup_dy = 0.0f;
        float f4_vissup_vx = 0.0f;
        float f4_vissup_vy = 0.0f;
        uint8_t u8_col_pointN = 0u;
        float f4_collisionx_1 = 1000.0f;
        float f4_collisiony_1 = 1000.0f;
        float f4_collisionr_1 = 1000.0f;
        float f4_collisionx_2 = 1000.0f;
        float f4_collisiony_2 = 1000.0f;
        float f4_collisionr_2 = 1000.0f;
        uint8_t u8_cornerNum = 0u;
        float f4_cornerx = 1000.0f;
        float f4_cornery = 1000.0f;
        float f4_cornerr = 1000.0f;
        float f4_longpos = 1000.0f;
        float f4_latpos = 1000.0f;
        float f4_longvel = 0.0f;
        float f4_latvel = 0.0f;
        float f4_Heading = 0.0f;
        float f4_Headangle = 0.0f;
        float f4_currentRange = 1000.0f;
        float f4_rangeestimation = 1000.0f;
        uint8_t u8_Inpathage = 0U;
        uint8_t u8_Inpathage_warn = 0u;
        bool u1_inpathcur = 0;
        bool u1_inpathpre = 0;
        bool u1_Inpath = 0;
        bool u1_inpathcur_warn = 0;
        bool u1_inpathpre_warn = 0;
        bool u1_Inpath_warn = 0;
        bool u1_inpath_tar = 0;
        uint8_t u1_TOI_Before = 0U;
        uint8_t u1_TOI_After = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_headplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_inpathagecheck_warn = 0U;
        bool u1_oncoming = 0U;
        bool ismovingcross = 0;
        bool notmovingout = 0;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        float f4_minTTC = DefaultTTC;
        float f4_minRange = 200.0f;
        MoveState u1_movingstate = MoveState::kInit;
        uint8_t warnig_flag = 0U;
        uint8_t prefill_flag = 0U;
        uint8_t lowbrake_flag = 0U;
        uint8_t highbrake_flag = 0U;
        uint8_t iba_flag = 0U;
        feature::math::Vector2f HostPos_tar;
        feature::math::Vector2f HostPos;
        feature::math::Vector2f HostVel;
        float turnangle = 0;
        float TTC_tar = DefaultTTC;
        float TTL_tar = DefaultTTL;
        float target_spd = 0; 
        float predictrange_tar = 0; 
    };

    struct AEBObject {
        feature::ehy::Object obj;
        targetpos ref_pos;
        uint8_t u8_ID = 0U;
        uint32_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_range = 0.0f;
        float f4_range_rear = 0.0f;
        float f4_rangerate = 0.0f;
        float f4_TTC = DefaultTTC;
        float f4_TTC_rear = DefaultTTC;
        float f4_XOLC = 0.0f;
        float f4_latpos_est = 0.0f;
        float f4_vissup_dy = 0.0f;
        float f4_vissup_vy = 0.0f;
        float f4_targetangle = 0.0f;
        float f4_targetangle_rear = 0.0f;
        uint8_t u8_Inpathage = 0U;
        uint8_t u8_Inpathage_warn = 0U;
        bool u1_Inpath = 0U;
        bool u1_Inpath_warn = 0U;
        uint8_t u1_TOI = 0U;
        uint8_t u1_TOI_rear = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_lfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_inpathagecheck_warn = 0U;
        bool u1_oncoming = 0U;
        bool u1_preceding = 0U;
        bool u1_longmove = 0U;
        bool u1_latmove = 0U;
        bool u1_crossing = 0U;
        bool u1_stationary = 0U;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        size_t lastcyclesize = 0;
        float xpos_cir = 0;
        float ypos_cir = 0;
        float roc_tar = 0;
        float mindist = 0;
        float xpos_col = 0;
        float ypos_col = 0;
        float range_col = 0;
        float range_col_tar = 0;
        float yawrate = 0;
        float heading = 0;
        bool colposs = 0;
        uint8_t col_num = 0;
        float TTC_cir = 25.5;
        float TTL_cir = 25.5;
        float TTC_tar = 25.5;
        float TTL_tar = 25.5;
    };


    struct AEBCandidate {
        AEBObject obj;
        uint8_t u8_Candi_ID = 0u;
        uint8_t u8_lastselectID = 0u;
        float f4_minrange = 0.0f;
        float f4_minTTC = DefaultTTC;
        uint8_t u8_prefill = 0U;
        uint8_t u8_warning = 0U;
        uint8_t u8_lowBrake = 0U;
        uint8_t u8_highBrake = 0U;
        uint8_t u8_VisID = MaxVisionIndex;
    };

    struct AESObjectCCR {
        feature::ehy::Object obj;
        uint8_t u8_ID = 0U;
        size_t u8_IDX = MaxVisionIndex;
        uint16_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_range = 0.0f;
        float f4_rangerate = 0.0f;
        float f4_relatAcc = 0.0f;
        float f4_TTC = DefaultTTC;
        float f4_TTCbased = DefaultTTC;
        float f4_TTC_new = DefaultTTC;
        calc_tt TTB;
        calc_tt TTB_bf;
        calc_tt TTT_left;
        calc_tt TTT_right;
        CornerPos close_left;
        CornerPos close_right;
        CornerPos remote_left;
        CornerPos remote_right;
        CornerPos center_point;
        uint8_t u8_closest_corner = 0; //1 = close_left; 2 = close_right; 3 = remote_left; 4 = remote_right; 5 =  reference point;
        uint8_t u8_closest_corner_estimate = 0; //1 = close_left; 2 = close_right; 3 = remote_left; 4 = remote_right; 5 =  reference point;
        float f4_XOLC = 0.0f;
        float f4_latest = 0.0f;
        float f4_vissup_dx = 0.0f;
        float f4_TTEmax = 0.0f;
        float f4_TTEmin = 0.0f;
        float yawdist = 0.0f;
        float hitdist = 0.0f;
        uint8_t u8_Inpathage = 0U;
        bool u1_Inpath_Cur = 0U;
        bool u1_Inpath_Pre = 0U;
        bool u1_Inpath = 0;
        uint8_t u1_TOI = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_headplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_oncoming = 0U;
        bool u1_preceding = 0U;
        bool u1_longmove = 0U;
        bool u1_latmove = 0U;
        bool u1_crossing = 0U;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        float f4_minTTC = DefaultTTC;
        float f4_minRange = 200.0f;
        MoveState u1_movingstate = MoveState::kInit;
        bool u1_ismovingout = 0;
        bool warnig_flag = 0U;
        bool prefill_flag = 0U;
        bool lowbrake_flag = 0U;
        bool highbrake_flag = 0U;
        bool iba_flag = 0U;
        bool steer_flag = 0U;
        bool brake_flag = 0U;
        float steer_direction = 0; //-1: left; 1: right;
        tarpos_estimate position_esti;
        bool left_turn_valid = 1;
        bool right_turn_valid = 1;
    };

    struct AESObjectVRU {
        feature::ehy::Object obj;
        uint8_t u8_ID = 0U;
        uint16_t u8_VID = 0u;
        bool objectvalid = 0U;
        float f4_range = 0.0f;
        float f4_range_rear = 0.0f;
        float f4_rangerate = 0.0f;
        float f4_TTC = DefaultTTC;
        float f4_TTC_rear = DefaultTTC;
        float f4_XOLC = 0.0f;
        float f4_latpos_est = 0.0f;
        float f4_vissup_dy = 0.0f;
        float f4_vissup_vy = 0.0f;
        float f4_targetangle = 0.0f;
        float f4_targetangle_rear = 0.0f;
        uint8_t u8_Inpathage = 0U;
        uint8_t u8_Inpathage_warn = 0U;
        bool u1_Inpath = 0U;
        bool u1_Inpath_warn = 0U;
        uint8_t u1_TOI = 0U;
        uint8_t u1_TOI_rear = 0U;
        bool u1_vfplaucheck = 0U;
        bool u1_lfplaucheck = 0U;
        bool u1_ageplaucheck = 0U;
        bool u1_inpathagecheck = 0U;
        bool u1_inpathagecheck_warn = 0U;
        bool u1_oncoming = 0U;
        bool u1_preceding = 0U;
        bool u1_longmove = 0U;
        bool u1_latmove = 0U;
        bool u1_crossing = 0U;
        bool u1_stationary = 0U;
        uint8_t u8_AEBconf = 0U;
        uint8_t u8_lostradarage = 0U;
        size_t lastcyclesize = 0;
    };

    struct AESCandidate {
        AESObjectCCR AESCCR1_Candi_;
        AESObjectCCR AESCCR2_Candi_;
        AESObjectVRU AESVRU_Candi_;
        AESObjectCCR AESCCR1_Candi_LF_;
        AESObjectCCR AESCCR2_Candi_LF_;
        AESObjectVRU AESVRU_Candi_LF_;
    };

    struct VRUCandidate {
        AEBCandidate pedestrian_cross_Candidate_;
        AEBCandidate bicycle_cross_Candidate_;
        AEBCandidate pedestrian_oncom_Candidate_;
        AEBCandidate bicycle_oncom_Candidate_;
        AEBCandidate pedestrian_rearcross_Candidate_;
        AEBCandidate bicycle_rearcross_Candidate_;
        AEBCandidate pedestrian_cross_Candidate_LF_;
        AEBCandidate bicycle_cross_Candidate_LF_;
        AEBCandidate pedestrian_oncom_Candidate_LF_;
        AEBCandidate bicycle_oncom_Candidate_LF_;
        AEBCandidate pedestrian_rearcross_Candidate_LF_;
        AEBCandidate bicycle_rearcross_Candidate_LF_;
        AEBCandidate pedestrian_cross_NS_;
        AEBCandidate bicycle_cross_NS_;
        AEBCandidate pedestrian_oncom_NS_;
        AEBCandidate bicycle_oncom_NS_;
    };

    struct CCRCandidate {
        AEBObjectCCR CCRS_Candi_;
        AEBObjectCCR CCRS_Candi_2_;
        AEBObjectCCR CCRS_Candi_LF_;
        AEBObjectCCR CCRS_Candi_LF_2_;
        AEBObjectCCR CCRM_Candi_;
        AEBObjectCCR CCRM_Candi_2_;
        AEBObjectCCR CCRM_Candi_LF_;
        AEBObjectCCR CCRM_Candi_LF_2_;
    };

    struct FTAPCandidate {
        AEBObjectFTAP FTAP_Candi_;
        AEBObjectFTAP FTAP_Candi_2_;
        AEBObjectFTAP FTAP_Candi_LF_;
        AEBObjectFTAP FTAP_Candi_LF_2_;
        AEBObjectFTAP FTAP_NS_;
    };

    struct CCCCandidate {
        AEBObjectCCC CCC_Candi_;
        AEBObjectCCC CCC_Candi_2_;
        AEBObjectCCC CCC_Candi_LF_;
        AEBObjectCCC CCC_Candi_LF_2_;
    };

    struct VisMatchInfo {
        uint32_t vis_id = 255;
    };

    struct NotSelectReason {
        uint8_t ID = 0;
        uint16_t NS_Ped_Reason = 0;
        uint16_t NS_CCR_Reason = 0;
        uint16_t NS_FTAP_Reason = 0;
    };

    struct FusionAEBFlag {
        uint16_t Warning_flag = kAEBAlertNoActive;
        uint16_t prefill_flag = kAEBAlertNoActive;
        uint16_t lowbrake_flag = kAEBAlertNoActive;
        uint16_t highbrake_flag = kAEBAlertNoActive;
        uint16_t unconfirmed_flag = kAEBAlertNoActive;
        uint16_t hold_flag = kAEBAlertNoActive;
        uint8_t lowbrake_age = 0U;
        uint8_t highbrake_hold_age = 0U;
        uint16_t warnbrake_flag = kAEBAlertNoActive;
        bool readyforIBA = 0;
    };

    struct LostTarget {
        uint8_t LF_ID = 0U;
        bool TargetLostCloseRange = 0U;
    };

    struct GofCheck {
        uint32_t    checkID         = 0;
        bool        check_valid     = false;
        bool        classcheck      = false;
        bool        fustcheck       = false;
        bool        agecheck        = false;
        bool        predcheck       = false;
        bool        freespacecheck  = false;
    };

    struct FusedObjFiltered {
        feature::ehy::Object    raw_data;
        GofCheck                gofcheck;
        targetpos               ref_pos;
    };

    struct EgoState_filter {
        float vehspd = 0;
        float yawrate = 0;
        float strwhlangle = 0;
        bool hostreverse = 0;
        float brakepos = 0;
        float brakeposrate = 0;
        uint8_t driverpress = 0;
        float maincypress = 0;
        float maincypressrate = 0;
        bool driverintention = 0;
        bool drivereba = 0;
        float roc = 0;
        float steerrate = 0;
        float accpos = 0;
        float accposrate = 0;
    };

    struct AES_Path {
        float path_c0 = 0;
        float path_c1 = 0;
        float path_c2 = 0;
        float path_c3 = 0;
        float path_c4 = 0;
        float path_c5 = 0;
    };

    struct Line_Poli {
        float path_c0 = 0;
        float path_c1 = 0;
        float path_c2 = 0;
        float path_c3 = 0;
        bool isvalid = 0;
        LDType path_type = LDType_Unknown;
        LDColor path_color = LDColor_Unknown;
        uint8_t character = 0; //1: line; 2: edge; 3: virtual;
    };

    struct Lpp_Poli {
        float path_c0 = 0;
        float path_c1 = 0;
        float path_c2 = 0;
        float path_c3 = 0;
        float width = 0;
        bool isvalid = 0;
    };

    extern ARBSIN g_ego_;

    extern const ARBSIN *ego_;
    
    extern std::vector<feature::ehy::Object> g_vis_obj_;

    extern const std::vector<feature::ehy::Object> *fused_obj_;

    extern feature::ehy::Object fuseobj_lastframe_[MaxFusedObjIndex];

    extern std::vector<FusedObjFiltered> fused_obj_filtered;

    extern const std::vector<feature::ehy::Object> *vis_obj_;
    
    extern  VRUCandidate vru_candidate;

    extern  CCRCandidate ccr_candidate;

    extern  FTAPCandidate ftap_candidate;

    extern  CCCCandidate ccc_candidate;

    extern  AESCandidate aes_candidate;

    extern  std::vector<AEBObject> pedestrian_;
    extern  std::vector<AEBObject> pedestrian_LF_;

    extern  VisMatchInfo VisMatchID_[MaxFusedObjIndex];

    extern  LostTarget CloseLostTarget;

    extern  LastFrameIndex fus_lf_idx;

    extern  NotSelectReason FusObjNs_[MaxFusedObjIndex];

    extern  FusionAEBFlag FusionVRUFlag_;
    extern  FusionAEBFlag FusionVRUFlag_LF;

    extern FusionAEBFlag FusionVRURearFlag_;
    extern FusionAEBFlag FusionVRURearFlag_LF;

    extern  FusionAEBFlag FusionCCRFlag_;
    extern  FusionAEBFlag FusionCCRFlag_LF;

    extern  uint16_t AEBSupressReason;
    extern  uint16_t AEBSupressReason_AfterPref;
    extern  uint16_t AEBSupressReason_AfterLowB;
    extern  uint16_t AEBSupressReason_AfterHighB;
    extern  uint16_t AEBSupressReason_CCFTAP;
    extern  uint16_t AEBSupressReason_IBA;
    extern  bool AEBSupressReason_SpeedLow;
    extern  bool driverBrake_intention;
    extern  bool driverenableIBA;
    extern  uint8_t IBAcount;
    extern  bool driverpress;
    extern  float time_interval;
    extern  uint8_t debug_loop;
    extern  bool hostReverse;
    extern  float deltayawrate;

    extern  bool lfbrake_active;

    extern  uint8_t fcw_sensitive;

    extern  EgoState_filter ego_state_aeb;

    extern  AEBObjectCCR close_CCR;

    extern  float ego_turning;

    extern  uint16_t ego_turn_filter;

    extern  int16_t turn_suppress_cycle;

    extern  float single_target_scene;

    extern  bool drivingstraight;

    extern  int16_t drivingstraight_filter;

    extern  uint8_t vehicle_count;

    extern  float ego_steady_vehspd[5];

    extern  float averagespd_100ms;

    extern  bool drivingsteady;

    extern  int16_t drivingsteadycnt;

    extern  uint8_t AEBDecelReq_Dummy;

    extern  uint8_t AEBDumpSuppress;

    extern  uint16_t aeb_fault_age;
    
    extern  uint16_t aebrear_fault_age;

    extern  AESObjectCCR close_aes;

    extern AES_Control_Input aes_ctrl_input;

    extern AES_Control_Input aes_ctrl_input_lf;

    extern AES_Path aes_path_pnc;

    extern AES_Plan_Group aes_path_group[6];

    extern AES_Plan_Group aes_path_group_lf[6];

    extern EgoPos ego_pos;

    extern Line_Poli host_left;

    extern Line_Poli host_right;

    extern Line_Poli left_edge;

    extern Line_Poli right_edge;

    extern Lpp_Poli host_lane_lpp;

    extern bool aes_plan_valid;

    extern calc_tt aeb_calculate_tt_max(float a, float b, float c, float c_new, float range);

    // void updateAebObject(const ARBSIN *aeb_sin, const std::vector<feature::ehy::Object> *fused_obj, const std::vector<feature::ehy::Object> *vis_obj);

}
}
#endif