#ifndef FEATURE_SIN_STRUCT_H_
#define FEATURE_SIN_STRUCT_H_

#include <stdint.h>
#include "ehy_obf/object.h"
#include "ehy_math/nio_vmath.h"
#include "veh_in_type.h"


namespace nio
{
    namespace ad
    {
            constexpr int kNumRdrAptiv = 5;
            constexpr int kNumRdrDetectionAptiv = 640;
            constexpr int kNumRdrObjectsAptiv = 96;
            constexpr int kNumRdrACCIDAptiv = 6;
            constexpr int kNumVisionDynmicObjects = 40;
            constexpr int kNumVisionStaticObjects = 20;
            constexpr int kNumVisionLaneMarkerPoint = 300;
            constexpr int kNumVisionZebraLine = 4;
            constexpr int kNumVisionStopLine = 4;
            constexpr int kNumVisionIntPoint = 10;
            constexpr int kNumVisionRoadEdge = 4;
            constexpr int kNumVisionLaneMarker = 8;
            constexpr int kNumVisionFSPPoint = 96;
            constexpr int kNumVisionSemanticLane = 10;
            constexpr int kNumVisionNoParkZone = 4;
            constexpr int kNumVisionTrafficSign = 20;
            constexpr int kNumVisionTrafficLight = 10;
            constexpr int kNumVisionVehicleLight = 16;
            constexpr int kNumFusionObject = 128;

            //================EHYEVD====================
            enum EvdLaneChangeReason : uint8_t
            {
                kEVD_LCReason_NONE = 0,
                kEVD_LCReason_NAVI = 1,
                kEVD_LCReason_RECL = 2,
                kEVD_LCReason_AVOID = 3,
            };

            enum EvdDcsDir : uint8_t 
            {
                kEVD_DIR_ST = 0,
                kEVD_DIR_LEFT = 1,
                kEVD_DIR_RIGHT = 2,
                kEVD_DIR_INVALID = 127,
            };

            struct EvdParamLaneChange {
                EvdDcsDir change_dir;
                EvdLaneChangeReason lane_change_reason;
            };

            struct EvdParamPathSelect {
                EvdDcsDir path_dir;
            };

            struct EvdParamLeading {
                EvdDcsDir leading_dir;
            };

            struct EvdParamTakeover {
                uint32_t takeover_src;
                //Takeover source 0: VD_TAKEOVER_INFO_NONE; 2:NOMOSTRI_SPLIT,   NOLANECHANGE_RI_BRANCH,NOLANECHANGE_RI_SOLIDLINE,BADLATLOC_RI_BRANCH
                //3:NOMOSTLE_SPLIT,NOLANECHANGE_LE_BRANCH,NOLANECHANGE_LE_SOLIDLINE,BADLATLOC_LE_BRANCH 4:NOLEADING_SPLIT, BADLATLOC_LE_OFFRAMP,BADLATLOC_RI_OFFRAMP
                //5:NOLANECHANGE_LE_MERGE, BADLATLOC_LE_MERGE 6:NOLANECHANGE_RI_MERGE, BADLATLOC_RI_MERGE 7:GEOFENCE  1: Default
            };

            struct EvdParamHW2Ramp {
                EvdDcsDir ramp_dir;
                float dst2leading;
            };

            struct EvdParam {
                EvdParamLaneChange lane_change;
                EvdParamPathSelect path_select;
                EvdParamLeading leading;
                EvdParamTakeover takeover;
                EvdParamHW2Ramp hw2ramp;
            };

            enum CurrSpdLmtSrc : uint8_t
            {
                kEVD_CurrSpdLmtSrc_None = 0,
                kEVD_CurrSpdLmtSrc_Curv = 1,
                kEVD_CurrSpdLmtSrc_TraffFlow = 2,
                kEVD_CurrSpdLmtSrc_FusSt = 3,
                kEVD_CurrSpdLmtSrc_FreeSpace = 4,
                kEVD_CurrSpdLmtSrc_Cone = 5,
            };

            struct EvdGLimit 
            {
                uint32_t spd;
                float dist;
                uint32_t valid;
                CurrSpdLmtSrc source;
                uint32_t regulation;
            };

            struct EvdDecsLimit {
                bool spd_valid;
                uint32_t spd;
                uint32_t distance_valid;
                float distance;
                uint32_t deadline_valid;
                float deadline;
                EvdGLimit curr_limit;
                EvdGLimit tar_limit;
            };

            enum GFPDirClass : uint8_t
            {
                kEVD_GFP_Class_NONE = 0,
                kEVD_GFP_Class_IN = 1,
                kEVD_GFP_Class_OUT = 2,
            };
            
            struct EvdGeofence {
                uint32_t valid;
                GFPDirClass classification;
                float distance;
                uint32_t type;
            };

            enum EvdDecisionName : uint8_t
            {
                EVD_DECISION_NONE = 0,
                EVD_DECISION_PILOT = 1,
                EVD_DECISION_RAMP2HW = 2,
                EVD_DECISION_HW2RAMP = 3,
                EVD_DECISION_LANECHANGE = 4,
                EVD_DECISION_PATHSELECT = 5,
                EVD_DECISION_TAKEOVER = 6,
                EVD_DECISION_ALTERNATEPASS = 7,  // close cut-in;
                EVD_DECISION_PILOT2SPEC = 8,
                EVD_DECISION_LEADING = 9,
                EVD_DECISION_MERG2MAINRD = 10,// merging to main road
            };

            struct EHYEvdOutputs {
                EvdDecisionName decision;
                EvdParam parameters;
                EvdDecsLimit limitations;
                EvdGeofence gfp_info;
            };

            //================================================================
            //==============EHYHA===================================

            enum HaTextInfo : uint8_t
            {
                kHA_TextInfo_Default = 1,
                kHA_TextInfo_Construction = 2,
                kHA_TextInfo_Tunnel = 3,
                kHA_TextInfo_SharpTurn = 4,
                kHA_TextInfo_BadWeature = 5,
                kHA_TextInfo_LowLaneConf = 6,
                kHA_TextInfo_LaneLineChg = 7,
            };

            struct EHYHaOutputs{
                uint32_t icon_info;
                HaTextInfo text_info;
                uint32_t sound_info;
                uint32_t hmi_highlight_obj_id;
                bool left_lane_flash;
                bool right_lane_flash;
            };

            //================================================================
            //==============EHYLppRme===============================

            enum LMLaneMarkClass : uint8_t
            {
                kLMLC_UNDECIDED = 0,
                kLMLC_SOLID = 1,
                kLMLC_DASHED = 2,
                kLMLC_DOUBLELANECROSSABLE = 3,
                kLMLC_DOUBLELANEUNCROSSABLE = 4,
                kLMLC_MULTIPLELANECROSSABLE = 5,
                kLMLC_MULTIPLELANEUNCROSSABLE = 6,
                kLMLC_BOTTDOTS = 7,
                kLMLC_CURB = 8,
                kLMLC_SNOWEDGE = 9,
                kLMLC_ROADEDGE = 10,
                kLMLC_VIRTUAL = 11,
                kLMLC_BARRIER = 12,
                kLMLC_CONES = 13,
                kLMLC_DECEL = 14,
                kLMLC_INVALID = 15,
                kLMLC_DOUBLELANESOLIDSOLID = 16,
                kLMLC_DOUBLELANEDASHEDDASHED = 17,
                kLMLC_HOVLANE = 18,
            };

            enum LMColor : uint8_t
            {
                kLMColor_White =0,
                kLMColor_Yellow =1,
                kLMColor_Blue =2,
                kLMColor_Invalid =3,
            };

            enum LMSource : uint8_t
            {
                kLMSource_NONE = 0,
                kLMSource_CLM = 1,
                kLMSource_LVLM = 2,
                kLMSource_RLM = 4,
                kLMSource_TF = 8,
                kLMSource_HPP = 16,
                kLMSource_ESTIMATE = 32,
                kLMSource_HDMAP = 64,
                kLMSource_FREESPACE = 128,
            };

            enum LMLaneType : uint8_t
            {
                kLMLT_UNDECIDED = 0,
                kLMLT_REGULAR = 1,
                kLMLT_SHOULDER = 2,
                kLMLT_OPENING = 3,
                kLMLT_CLOSING = 4,
                kLMLT_BICYCLE = 5,
                kLMLT_RAMP = 6,
                kLMLT_CARPOOL = 7,
                kLMLT_RESERVED = 8,
                kLMLT_BUS = 9,
                kLMLT_NONE = 10,
                kLMLT_ACCELERATION = 11,
                kLMLT_DECELERATION = 12,
                kLMLT_TEMP_SHOULDER_OPEN = 13,
                kLMLT_TEMP_SHOULDER_CLOSED = 14,
                kLMLT_DIRECT_EXIT = 15,
            };

            enum LMLaneDir : uint8_t
            {
                kLMLaneDir_UNDECIDED = 0,
                kLMLaneDir_DIRECTE = 1,
                kLMLaneDir_LEFTTURN = 2,
                kLMLaneDir_RIGHTTURN = 4,
                kLMLaneDir_LEFTCHANGE = 8,
                kLMLaneDir_RIGHCHANGE = 16,
            };

            struct RmeLine{
                float pt_conf;
                float c0 ;
                float c1;
                float c2 ;
                float c3 ;
                float lrange_start;
                float lrange_end;
                float lm_width;
                LMColor line_color;
                LMLaneMarkClass line_type;
                LMSource line_src;
            };

            struct RmeLane{
                RmeLine left_line;
                RmeLine right_line;
                LMLaneType lane_type[2]; //2
                float lane_start;
                float lane_end;
                float map_spd_limit;
                float lane_width;
                float ca_lon_dst;  //construction area lon_distance
                float cur_point[10]; //10
                float cur_value[10]; //10
                LMLaneDir lane_dir;
                bool ca_valid;
                uint32_t lane_id;
            };

            struct RmePoint{
                float conf;
                float x ;
                float y;
                float z;
                float w ;
                float d;
                float s;
            };

            struct EHYLppOutputs{
                RmeLine trajectory ;//need check
                float latctrl_pt ;
                float lonctrl_pt;
                float shitf_offset;
                uint32_t act_shift_status ;
            };

            enum LMRole : uint8_t
            {
                kLMRole_NONE = 0,
                kLMRole_HOST_LANE = 16,
                kLMRole_HOST_LANE_LEFT = 17,
                kLMRole_HOST_LANE_RIGHT = 18,
                kLMRole_LE_LANE = 32,
                kLMRole_LE_LANE_LEFT = 33,
                kLMRole_LE_LANE_RIGHT = 34,
                kLMRole_RI_LANE = 48,
                kLMRole_RI_LANE_LEFT = 49,
                kLMRole_RI_LANE_RIGHT = 50,
            };

            enum LMIntPClass : uint8_t
            {
                kLMIntPClass_UNDECIDED = 0,
                kLMIntPClass_SPLIT = 1,
                kLMIntPClass_MERGE = 2,
                kLMIntPClass_SPD = 3,
                kLMIntPClass_MARKCLASS = 4,
                kLMIntPClass_COLOR = 5,
            };

            struct RmeMapGP{
                float gp_distance;
                uint32_t gp_type;
                float recom_speed;
                float link_length;
                uint32_t recom_lane_idx;
                uint32_t recom_speed_id;
                uint32_t recom_speed_src;
                uint32_t recom_speed_conf;
                bool spd_unit;
                int32_t sup_sign_typ;
                int32_t sup_sign_attr;
            };

            struct RmeHDMap{
                RmeMapGP ngp_list[20];
            };

            struct RmeSpdLmt{
                uint32_t spd_lmt_value;
                int32_t spd_lmt_attr;
                int32_t sup_sign_type3;
                int32_t sup_sign_attr;
                bool spd_uint;
            };

            struct RmeIntp{
                RmePoint point;
                int32_t id;
                LMIntPClass intp_class;
                LMSource source;
                LMRole role;
                LMLaneMarkClass far_markclass;
                LMColor far_color;
                uint32_t far_spd;
            };

            struct EHYRmeOutputs{
                RmeLine road_edge_left;
                RmeLine road_edge_right;
                RmeLane host_lane;
                RmeLane left_lane;
                RmeLane right_lane;
                RmeHDMap hdmap_info;
                RmeIntp interest_point[20];
                float road_start;
                float road_end;
                uint32_t total_lane_num;
                uint32_t num_lane_id;
                uint32_t road_type;
                uint32_t status;
            };

            //================================================================
            //=============EHYTpp==========================

            struct EHYTppOutputs{
                RmeLine tpp_trajectory;
                float latctrl_pt;
                float longctrl_pt;
                float shift_offset;
                uint32_t act_shift_status;
            };

            //================================================================
            //===============EHYTse==========================

            enum TgtObjMotionStatus : uint8_t
            {
                kOBJ_STATUS_UNDEFINED = 0,  // Default value
                kOBJ_STATUS_STANDING = 1,
                kOBJ_STATUS_STOPPED = 2,
                kOBJ_STATUS_MOVING = 3,
                kOBJ_STATUS_ONCOMING = 4,
                kOBJ_STATUS_PARKED = 5,
            };


            enum TgtObjType : uint8_t
            {
                kOBJTYPE_VEHICLE = 0,  // Default value
                kOBJTYPE_TRUCK = 1,
                kOBJTYPE_BIKE = 2,
                kOBJTYPE_PEDESTRAIN = 3,
                kOBJTYPE_BICYCLE = 4,
                kOBJTYPE_GENERALOBJECT = 5,
                kOBJTYPE_TRAIL = 6,
                kOBJTYPE_UNDEFINED = 7,
                kOBJTYPE_GUARDRAIL = 8,
                kOBJTYPE_WALL = 9,
                kOBJTYPE_PASSBY = 10,
                kOBJTYPE_OBSTACLE = 11,
                kOBJTYPE_ANIMAL = 12,
                kOBJTYPE_SUV = 13,
            };

            enum TgtObjValidStatus : uint8_t
            {
                kInvalid = 0,
                kNew = 1,
                kMature = 2,
                kCoast = 3,
            };

            enum BlinkerType : uint8_t
            {
                kOFF = 0,
                kTURNLEFT = 1,
                kTURNRIGHT = 2,
                kDOUBLEFLASH = 3,
            };

            enum TgtLaneChangeDir : uint8_t
            {
                kTgtLaneChangeDirDefault = 0,
                kTgtLaneChangeDirLeft = 1,
                kTgtLaneChangeDirRight = 2,
            };

            enum TgtFusionSrc : uint8_t
            {
                kDefault = 0,
                kRadarOnly = 1,
                kVisionOnly = 2,
                kRadarVison = 3,
            };

            struct TgtObj{
                uint32_t id;
                uint32_t obj_index;
                uint32_t confidence;
                float lon_pos_ccs;  //position in frenet coordinate system
                float lon_pos_vcs;  //vehicle coordinate system position
                float lon_pos_vcs_std; //add
                float lon_vel;
                float lon_vel_std ; //add
                float lon_acc;
                float lat_pos_ccs;
                float lat_pos_vcs;
                float lat_pos_vcs_std; //add
                float lat_vel;
                float lat_vel_std; //add
                float lat_acc;
                TgtObjMotionStatus status; //
                TgtObjType type;
                TgtObjValidStatus valid;
                uint32_t age;
                float width;
                float length;
                float height; //add
                float phi_angle;
                float dphi_angle_rate;
                TgtFusionSrc fusion_source;
                float ttc;
                BlinkerType blinker_info;
                uint32_t brake_lights; // need to find information. Could be not 0 is brake light ON.
                float prob_lane_change;
                TgtLaneChangeDir dirLaneChange;
            };

            struct EHYTseOutputs{
                TgtObj tse_obj[4]; //4
                bool tsi_flg_cipv_lost;
            };

            struct TcaTarget{
                TgtObj tca_obj[15];
                uint32_t valid_tgt_num;
            };

            struct EHYTsiOutputs{
                TgtObj tsi_obj[35];//35
                TgtObj rm_tsi_out[32];//32
                TcaTarget tca_out; //15
                uint32_t tsi_status; //
                bool tsi_flg_cipvlost;
                bool tsi_ego_lane_changed;
                uint32_t svc_frnt_obstacle_status;
            };

            //================================================================
            //================EHYTsr============================

            struct EHYTsrOutputs{
                uint32_t idx_spd_lmt = 1;
                uint32_t st_op_sts = 2;
                uint32_t idx_spd_lmt_unit = 3;
            };

            //================================================================

            enum VisionStaticObsType : uint8_t
            {
                VisionStaticObsType_Invalid = 0,
                VisionStaticObsType_Barrier = 1,
                VisionStaticObsType_Cone = 2,
                VisionStaticObsType_ShortPole = 3,
                VisionStaticObsType_ObstructionBW = 4,
                VisionStaticObsType_ObstructionUP = 5,
                VisionStaticObsType_ObstructionLeft = 6,
                VisionStaticObsType_ObstructionRight = 7,
                VisionStaticObsType_RedWarningSign = 8,
                VisionStaticObsType_FishboneLeft = 9,
                VisionStaticObsType_FishboneRight = 10,
                VisionStaticObsType_OverheadObject = 11
            };

            enum VisionObjIndicatorArrowMotionStatus : uint8_t
            {
                VisionObjIndArrowMotSt_Stationary = 0,
                VisionObjIndArrowMotSt_Stop = 1,
                VisionObjIndArrowMotSt_Moving = 2,
                VisionObjIndArrowMotSt_MovingSlow = 3
            };

            enum VisionObjIndicatorArrowStatus : uint8_t
            {
                VisionObjIndArrowSt_Off = 0,
                VisionObjIndArrowSt_On = 1,
                VisionObjIndArrowSt_Blink = 2
            };

            enum VisionObjIndicatorArrowDir : uint8_t
            {
                VisionObjIndArrowDir_Double = 0,
                VisionObjIndArrowDir_Left = 1,
                VisionObjIndArrowDir_Right = 2,
                VisionObjIndArrowDir_LeftDown = 3,
                VisionObjIndArrowDir_RightDown = 4
            };

            enum LaneSemanDir : uint8_t
            {
                LaneSemanDir_Unknown = 0
            };

            enum LaneSemanOrientation : uint8_t
            {
                LaneSemanOrientation_Unknown = 0
            };

            enum LaneSemanRole : uint8_t
            {
                LaneSemanRole_Unknown = 0
            };

            enum LaneSemanType : uint8_t
            {
                LaneSemanType_Unknown = 0
            };

            enum LaneSemanRoadSt : uint8_t
            {
                LaneSemanRoadSt_Unknown = 0
            };

            enum ObjClass : uint8_t
            {
                ObjClass_Undefined = 0,
                ObjClass_SmallVehicle = 1,
                ObjClass_BigVehicle = 2,
                ObjClass_Bike = 3,
                ObjClass_Pedestrian = 4,
                ObjClass_Animal = 5,
                ObjClass_GeneralObject = 6
            };

            enum ClassSmallVehicle : uint8_t
            {
                SubClass_SVUndefined = 0,
                SubClass_SVCar = 1,
                SubClass_SVSuv = 2
            };

            enum ClassBigVehicle : uint8_t
            {
                SubClass_BVUndefined = 0,
                SubClass_BVBus = 1,
                SubClass_BVTruck = 2
            };

            enum ClassBike : uint8_t
            {
                SubClass_BkUndefined = 0,
                SubClass_BkMotorbike = 1,
                SubClass_BkBicycle = 2
            };

            enum ClassPed : uint8_t
            {
                SubClass_PdUndefined = 0,
                SubClass_PdChild = 1,
                SubClass_PdAdult = 2
            };

            enum ClassGeneral : uint8_t
            {
                SubClass_GOUndefined = 0,
                SubClass_GOGuardrail = 1,
                SubClass_GOCone = 2,
                SubClass_GOBillboard = 3,
                SubClass_GOManholeCover = 4,
                SubClass_GOBarrier = 5,
                SubClass_GOObstLeft = 6,       //obstruction left
                SubClass_GOObstRight = 7,      //obstruction right
                SubClass_GOObstUP = 8,         //obstruction up
                SubClass_GOObstDown = 9,       //obstruction down
                SubClass_GOFishBoneLeft = 10,  //fish bone left
                SubClass_GOFishBoneRight = 11, //fish bone right
                SubClass_GOObstInvalid = 12,
                SubClass_GOShortPole = 13, //short pole
            };

            enum VisionDynObjClass : uint8_t
            {
                VisionDynObjClass_Unknown = 0
            };

            enum VisionDynObjColor : uint8_t
            {
                VisionDynObjColor_Unknown = 0
            };

            enum VisionDynObjLaneAssign : uint8_t
            {
                VisionDynObjLaneAssign_Unknown = 0
            };

            enum VisionDynObjMeasureSt : uint8_t
            {
                VisionDynObjMeasureSt_Unknown = 0
            };

            enum VisionDynObjMotionSt : uint8_t
            {
                VisionDynObjMotionSt_Unknown = 0
            };

            enum VisionDynObjMotionCategory : uint8_t
            {
                VisionDynObjMotionCategory_Unknown = 0
            };

            enum VisionDynObjBrakeLight : uint8_t
            {
                VisionDynObjBrakeLight_Invalid = 0,
                VisionDynObjBrakeLight_On = 1,
                VisionDynObjBrakeLight_Off = 2
            };

            enum VisionDynObjTurnIndicator : uint8_t
            {
                VisionDynObjTurnIndicator_Off = 0,
                VisionDynObjTurnIndicator_Left = 1,
                VisionDynObjTurnIndicator_Right = 2,
                VisionDynObjTurnIndicator_Both = 3
            };

            enum VisionDynObjHBSt : uint8_t
            {
                VisionDynObjHBSt_Off = 0,
                VisionDynObjHBSt_On = 1,
                VisionDynObjHBSt_Blink = 2
            };

            enum VisionObjPlateColor : uint8_t
            {
                VisionObjPlateColor_Unknown = 0
            };

            enum LDRole : uint8_t
            {
                LDRole_Unknown = 0,
                LDRole_Host_Left = 1,
                LDRole_Host_Right = 2,
                LDRole_Adjacent_Left_Left = 3,
                LDRole_Adjacent_Left_Right = 4,
                LDRole_Adjacent_Right_Left = 5,
                LDRole_Adjacent_Right_Right = 6
            };

            enum LDType : uint8_t
            {
                LDType_Unknown = 0,
                LDType_Solid = 1,
                LDType_Dash = 2,
                LDType_Solid_Dash = 3,
                LDType_Dash_Solid = 4,
                LDType_Solid_Solid = 5,
                LDType_Deceleration_Dash = 6,
                LDType_Deceleration_Solid = 7
            };

            enum LDColor : uint8_t
            {
                LDColor_Unknown = 0,
                LDColor_White = 1,
                LDColor_Yellow = 2,
                LDColor_Orange = 3,
                LDColor_Blue = 4,
                LDColor_Others = 5
            };

            enum LDEndReason : uint8_t
            {
                LDEndReason_Unknown = 0
            };

            enum LDSpecialPointType : uint8_t
            {
                LDSpecialPointType_Unknown = 0
            };

            enum LDCameraSource : uint8_t
            {
                LDCameraSource_Unknown = 0
            };

            enum LDMeasureStatus : uint8_t
            {
                LDMeasureStatus_Unknown = 0
            };

            enum LDPredictReason : uint8_t
            {
                LDPredictReason_Unknown = 0
            };

            enum LDQuality : uint8_t
            {
                LDQuality_Unknown = 0
            };

            enum ObjCCISide : uint8_t
            {
                ObjCCISide_Unknown = 0,
                ObjCCISide_Left = 1,
                ObjCCISide_Right = 2
            };

            enum LPPSource : uint8_t
            {
                LPPSource_Unknown = 0
            };

            enum RoadEdgeType : uint8_t
            {
                RoadEdgeType_Unkown = 0,
                RoadEdgeType_Crossable = 1,
                RoadEdgeType_Uncrossable = 2,
                RoadEdgeType_RoadEdge = 3,
                RoadEdgeType_Road_Fence = 4,
                RoadEdgeType_Cone = 5,
                RoadEdgeType_Barrier = 6,
                RoadEdgeType_Parked_Vehicle = 7,
                RoadEdgeType_Grass = 8
            };

            enum RoadEdgeSide : uint8_t
            {
                RoadEdgeSide_Unkown = 0,
                RoadEdgeSide_Left = 1,
                RoadEdgeSide_Right
            };

            enum RoadEdgeFromHostIndex : uint8_t
            {
                RoadEdgeFromHostIndex_Unkown = 0
            };

            enum SLType : uint8_t
            {
                SLType_Unknown = 0
            };

            enum SLDetectCamera : uint8_t
            {
                SLDetectCamera_Unknown = 0
            };

            enum SLMeasureSt : uint8_t
            {
                SLMeasureSt_Unknown = 0
            };

            enum SLLaneAssessment : uint8_t
            {
                SLLaneAssessment_Unknown = 0
            };

            enum IntPtType : uint8_t
            {
                IntPtType_Unknown = 0
            };

            enum IntPtLineRole : uint8_t
            {
                IntPtLineRole_Unknown = 0
            };

            enum ReferPoint : uint8_t
            {
                ReferPoint_Undefined = 0,
                ReferPoint_FrontCenter = 1,
                ReferPoint_Center = 2,
                ReferPoint_RearCenter = 3
            };

            enum RadarDetectionSource : uint8_t
            {
                ObjSource_Invalid = 0,
                ObjSource_FCRadar = 1,
                ObjSource_FLRadar = 2,
                ObjSource_FRRadar = 3,
                ObjSource_RLRadar = 4,
                ObjSource_RRRadar = 5
            };

            enum FSPLaneAssginment : uint8_t
            {
                FSPLaneAssginment_Unknown = 0
            };

            enum FSPClassType : uint8_t
            {
                FSPClassType_Unknown = 0
            };

            enum FSPMobilityStatus : uint8_t
            {
                FSPMobilityStatus_Unknown = 0
            };

            enum VisionTSRName : uint8_t
            {
                VisionTSRName_Unknown = 0
            };

            enum VisionTSRShape : uint8_t
            {
                VisionTSRShape_Unknown = 0
            };

            enum VisionTSRFilterType : uint8_t
            {
                VisionTSRFilterType_Unknown = 0
            };

            enum VisionTSRRelevancy : uint8_t
            {
                VisionTSRRelevancy_Unknown = 0
            };

            enum VisionTSRStructure : uint8_t
            {
                VisionTSRStructure_Unknown = 0
            };

            enum VisionTFLColor : uint8_t
            {
                VisionTFLColor_Unknown = 0
            };

            enum VisionTFLMode : uint8_t
            {
                VisionTFLMode_Unknown = 0
            };

            enum VisionTFLShape : uint8_t
            {
                VisionTFLShape_Unknown = 0
            };

            enum VisionTFLStructOrientation : uint8_t
            {
                VisionTFLStructOrientation_Unknown = 0
            };

            enum VisionVehicleLightType : uint8_t
            {
                VisionVehicleLightType_Unknown = 0
            };

            enum VehicleProjectType : uint8_t
            {
                VehicleProjectType_Invalid = 0,
                VehicleProjectType_Force = 1,
                VehicleProjectType_Gemini = 2,
                VehicleProjectType_Pegasus = 3,
                VehicleProjectType_Aries = 4,
                VehicleProjectType_Sirius = 5,
                VehicleProjectType_Libra = 6,
                VehicleProjectType_Orion = 7,
                VehicleProjectType_Lyra = 8
            };

            struct VisionObjAngle
            {
                float angle_left;
                float angle_right;
                float angle_middle;
                float angle_side;
            };

            struct VisionObjAngleSTD
            {
                float angle_left_std;
                float angle_right_std;
                float angle_middle_std;
                float angle_side_std;
            };

            struct ObjPos
            {
                float x; // unit:m
                float y;
                float z;
            };

            struct ObjPosSTD
            {
                float x_std; // unit:m
                float y_std;
                float z_std;
            };

            struct ObjVel
            {
                float vx; // unit:m/s
                float vy;
                float vz;
            };

            struct ObjVelSTD
            {
                float vx_std; // unit:m/s
                float vy_std;
                float vz_std;
            };

            struct ObjAcc
            {
                float ax; // unit:m/s^2
                float ay;
                float az;
            };

            struct ObjAccSTD
            {
                float ax_std; // unit:m/s^2
                float ay_std;
                float az_std;
            };

            struct ObjSize
            {
                float length; // unit:m
                float width;
                float height;
            };

            struct ObjSizeSTD
            {
                float length_std; // unit:m
                float width_std;
                float height_std;
            };

            struct ObjMotion
            {
                ObjPos pos;
                ObjPosSTD pos_std;
                ObjVel vel;
                ObjVelSTD vel_std;
                ObjAcc acc;
                ObjAccSTD acc_std;
                ObjSize size;
                ObjSizeSTD size_std;
                float heading;        // unit :rad
                float heading_std;    // unit :rad
                float angle_rate;     // unit :rad/s
                float angle_rate_std; // unit :rad/s
            };

            struct ObjMotionStatus
            {
                bool is_valid;
                bool is_moving;
                bool is_movable;
                bool direction; //0:positive ,1:negativa
                bool was_moved;
            };

            struct VisionStaticObject
            {
                uint32_t age;
                uint32_t ID;
                VisionStaticObsType type;
                float type_prob;
                ObjMotion motion;
                // bool indicator_arrow_valid;
                // ObjPos indicator_arrow_pos;
                // VisionObjIndicatorArrowStatus indicator_arrow_st;
                // VisionObjIndicatorArrowMotionStatus indicator_arrow_mot_st;
                // VisionObjIndicatorArrowDir indicator_arrow_dir;
            };

            struct VisionObjPixel
            {
                uint32_t left_bottom_x;
                uint32_t left_bottom_y;
                uint32_t left_top_x;
                uint32_t left_top_y;
                uint32_t right_bottom_x;
                uint32_t right_bottom_y;
                uint32_t right_top_x;
                uint32_t right_top_y;
                uint32_t side_bottom_x;
                uint32_t side_bottom_y;
                uint32_t side_top_x;
                uint32_t side_top_y;
            };

            struct VisionObjPlate
            {
                uint32_t number;
                float dst;
                float dst_std;
                VisionObjPlateColor color;
            };

            struct VisionDynamicObject
            {
                uint32_t age_frame; 
                uint32_t ID;
                float exist_prob;
                bool is_very_close;
                //float ttc;
                ObjMotion motion;
                // VisionObjAngle angle;
                // VisionObjAngleSTD angle_std;
                uint32_t is_blocked_parts; // ?
                VisionDynObjClass classification;
                VisionDynObjColor color;
                VisionDynObjLaneAssign lane_assign;
                VisionDynObjMeasureSt mesure_st;
                VisionDynObjMotionSt motion_st;
                VisionDynObjMotionCategory motion_category;
                VisionDynObjBrakeLight brake_light;
                VisionDynObjTurnIndicator turn_indicator;
                VisionDynObjHBSt hb_st;
                // float cut_angle;
                // float cut_dst;
                float dst_left_line;
                float dst_right_line;
                bool is_blocked_left;
                bool is_blocked_right;
                // VisionObjPixel pixel_pos;
                // VisionObjPlate plate_info;
            };

            struct EHYVisionObjects
            {
                uint64_t timestamp;
                uint32_t obj_cnt;
                uint32_t vru_cnt;
                uint32_t vd_cnt;
                uint32_t cipv_id;
                bool cipv_lost;
                bool is_cci;
                ObjCCISide cci_side;
                uint32_t cci_id;
                // ObjPos cci_pos;
                // ObjPosSTD cci_pos_std;
                // float cci_angle;
                // float cci_angle_std;
                VisionDynamicObject dynamic_obj[kNumVisionDynmicObjects];
                VisionStaticObject static_obj[kNumVisionStaticObjects];
            };

            struct PolyLine
            {
                float c0;
                float c1;
                float c2;
                float c3;
            };

            struct LineProperty
            {
                LDType type;
                LDColor color;
                PolyLine line;
                float start;
                float end;
                LDEndReason end_reason;
            };

            struct VisionPoint
            {
                float lat; // Lateral distance of the point in the world or x_pixel in the picture. maximum 300 point
                float lon; //Longitudinal distance of the point in the world or y_pixel in the picture. maximum 300 point
            };

            struct LaneLine
            {
                LDRole role; //本车道左/本车道右/左左/左右/右右/右左, maximum 5 lanes and 8 lane lines
                LineProperty first_line;
                bool is_multi_clothoid; // Whether it is multi-polynomials
                LineProperty second_line;
                bool special_point_is_detected;        //Whether the special point is detected
                LDSpecialPointType special_point_type; // 0:Type 1:Color 2:Merge 3:Split
                VisionPoint special_point;
                VisionPoint point[kNumVisionLaneMarkerPoint];
                VisionPoint pixel_point[kNumVisionLaneMarkerPoint];
                LDCameraSource source;
                float dash_average_gap;
                float dash_average_length;
                bool crossing;
                uint32_t crossing_ID;
                LDMeasureStatus measure_status;
                LDPredictReason predict_reason;
                uint32_t track_ID;
                uint32_t track_age;
                LDQuality quality;
                float confidence;
                float marker_width;
            };

            struct Lane
            {
                float host_lane_width;
                bool crossing_flag; // The flag of  ego vehicle crosses the lane line
                LaneLine lines[kNumVisionLaneMarker];
            };

            struct RoadSlop
            {
                bool vertical_surface_available; //road vertical_surface
                float vertical_surface_start;
                float vertical_surface_end;
                PolyLine vertical_surface;
            };

            struct LaneLPP
            {
                bool available;
                LPPSource source;
                VisionPoint lpp_ctrl_point;
                float confidence;
                bool first_valid;
                float first_vr_end;
                PolyLine first_line;
                bool second_valid;
                float second_vr_end;
                PolyLine second_line;
            };

            struct RoadEdge
            {
                RoadEdgeType type;
                RoadEdgeSide side;
                RoadEdgeFromHostIndex host_index;
                uint32_t ID;
                uint32_t age;
                float height;
                float start;
                float end;
                PolyLine line;
            };

            struct StopLine
            {
                bool zebra_is_detected;
                VisionPoint zebra_point[kNumVisionZebraLine];
                bool SL_is_detected; //stop line
                uint32_t SL_ID;
                SLType SL_type;
                SLDetectCamera SL_detect_camera;
                SLMeasureSt SL_measure_st;
                float SL_width;
                float SL_prob;
                VisionPoint SL_left;
                VisionPoint SL_right;
                SLLaneAssessment SL_lane_assessment;
            };

            struct InterestPoint
            {
                IntPtType type;
                uint32_t ID;
                uint32_t age;
                IntPtLineRole line_role;
                VisionPoint int_point;
                float exist_prob;
            };

            struct GuidePoint
            {
                bool intp_is_highway_merge_left;
                bool intp_is_highway_merge_right;
                bool intp_is_highway_exit_left;
                bool intp_is_highway_exit_right;
                InterestPoint intp_point[kNumVisionIntPoint];
            };

            struct LaneSemantic
            {
                LaneSemanDir dir;
                float dir_prob;
                uint32_t ID;
                uint32_t cnt;
                VisionPoint point;
                LaneSemanOrientation orientation;
                float orientation_prob;
                LaneSemanRole role;
                LaneSemanType type;
                VisionPoint no_park_zone[kNumVisionNoParkZone];
                LaneSemanRoadSt road_st;
            };

            struct EHYVisionRoad
            {
                uint64_t timestamp; //Timestamp_Receive_Image
                Lane lane;
                RoadSlop slop;
                LaneLPP lpp;
                RoadEdge road_edge[kNumVisionRoadEdge];
                StopLine stop_line[kNumVisionStopLine];
                GuidePoint guide_point;
                LaneSemantic lane_semantic[kNumVisionSemanticLane];
            };

            struct VisionFSPPoint
            {
                uint32_t id;
                float exist_prob;
                float range;
                float range_std;
                float azimuth_angle;
                float azimuth_angle_std;
                float height;
                float height_std;
                float elevation_angle;
                float elevation_angle_std;
                FSPLaneAssginment lane_assginment;
                FSPClassType class_type;
                FSPMobilityStatus mobility_st;
            };

            struct VisionFreespace
            {
                uint64_t timestamp;
                VisionFSPPoint fsp_point[kNumVisionFSPPoint];
            };

            struct VisionTrafficSign
            {
                uint32_t id;
                uint32_t age;
                float confidence;
                float height;
                VisionPoint dst;
                float panel_width;
                float panel_height;
                VisionTSRName name;
                VisionTSRShape shape;
                VisionTSRFilterType filter_type;
                VisionTSRRelevancy relevancy;
                VisionTSRStructure structure;
            };

            struct VisionTSR
            {
                uint64_t timestamp;
                VisionTrafficSign traffic_sign[kNumVisionTrafficSign];
            };

            struct VisionTrafficLight
            {
                uint32_t object_id;
                uint32_t lightbox_id;
                VisionPoint dst;
                float height;
                uint32_t timer;
                VisionTFLColor color;
                VisionTFLMode mode;
                VisionTFLShape shape;
                VisionTFLStructOrientation struct_orientation;
            };

            struct VisionTLR
            {
                uint64_t timestamp;
                VisionTrafficLight traffic_light[kNumVisionTrafficLight];
            };

            struct VisionVehicleLight
            {
                uint32_t id;
                uint32_t num_of_vehicles;
                uint32_t brightness;
                float width;
                float width_std;
                float height;
                float height_std;
                float top_angle;
                float bottom_angle;
                float right_angle;
                float left_angle;
                float top_angle_vel;
                float bottom_angle_vel;
                float right_angle_vel;
                float left_angle_vel;
                float confidence;
                bool is_single_bar;
                bool is_new;
                VisionVehicleLightType type;
            };

            struct VisionVehicleLightDetection
            {
                uint64_t timestamp;
                VisionVehicleLight vehicle_light[kNumVisionVehicleLight];
            };

            struct VisionFailSafeDetection
            {
                uint64_t timestamp;
                uint32_t fs_rain;
                uint32_t fs_fog;
                uint32_t fs_snow;
                uint32_t fs_full_blockage;
                uint32_t fs_partial_blockage;
                uint32_t fs_lowsun;
                uint32_t fs_sunray;
                uint32_t fs_splash;
                uint32_t fs_windshield_frozen;
                uint32_t fs_out_of_calibration;
                uint32_t fs_out_of_focus;
                uint32_t fs_blur;
            };

            struct RadarObjValidSt
            {
                bool flag_valid;
                bool flag_measured;
                bool flag_hist;
            };

            struct RadarObject
            {
                RadarObjValidSt valid_st;
                uint32_t source; //bitwise signal:0x0:None, 0x1:MRR, 0x2:SRR_FL, 0x4:SRR_FR, 0x8:SRR_RL,
                                 // 0x10:SRR_RR, 0x3:MRR+SRR_FL, 0x5:MRR+SRR_FR, ...

                float confidence; //object confidence ; range 0~1
                uint32_t age;
                ReferPoint ref_point;
                ObjMotion motion;          // contain position/velocity/acceleration/size
                ObjMotionStatus motion_st; // record the moving/movable/direction information of object
                ObjClass classification;
                uint32_t sub_class; //sub_class probability ; range 0~1
                float class_prob;
                float obstacle_prob; //the probability that the object is obstacle ; range 0~1
            };

            struct RadarDetPoint
            {
                uint32_t ID;
                RadarDetectionSource source;
                float range;               // unit:m
                float range_rate;          // unit:m/s
                float azimuth;             // unit:rad
                float elevation_angle;     // unit:rad
                float radar_cross_section; // radar cross section
                float azimuth_conf;        // detection azimuth confidence 0-1
                float elevation_conf;      // detection elevation confidence 0-1
                float exist_prob;          // detection existence probability confidence 0-1
            };

            struct RadarTracker
            {
                uint64_t timestamp; // the time that aptiv sends radar trackers to us
                RadarObject objects[kNumRdrObjectsAptiv];
            };

            struct RadarDetection
            {
                uint64_t timestamp[kNumRdrAptiv];               // the time that aptiv sends radar detection points to us
                RadarDetPoint det_point[kNumRdrDetectionAptiv]; //detection points for radar
            };

            struct RadarStatus
            {
                bool flg_blindness;
                bool flg_failure;
                bool flg_loss_comm_fault;
                bool flg_timestamp_invalid;
            };

            struct RadarFeature
            {
                uint32_t acc_target_id[kNumRdrACCIDAptiv]; //6
                uint32_t aeb_target_id;

                uint8_t bsd_req_le;
                uint8_t bsd_req_ri;
            };

            struct EHYRadarSensor
            {
                float ego_spd_ms;  // unit :m/s
                float ego_acc;     // unit :m/s^2
                float ego_yawrate; // unit :rad/s

                RadarStatus radar_st[kNumRdrAptiv];
                RadarTracker tracker;
                RadarDetection detection;

                RadarFeature radar_feature;
            };

            struct APSideFeature
            {
                uint32_t fcta_onoff_sts = 0;
                uint32_t bsd_haptic_req = 0;
                uint32_t bsd_haptic_valid = 0;

                uint32_t rctb_brk_sts = 0;
                uint32_t rctb_decel_to_stop = 0;
                uint32_t rctb_drv_off_req = 0;
                float rctb_max_jerk = 0;
                float rctb_min_jerk = 0;
                uint32_t rctb_acc_mode = 0;
                uint32_t rctb_shutdown_req = 0;
                float rctb_tar_accel = 0;
                uint32_t rctb_vlc_req = 0;

                uint32_t fcta_left_sts = 0;
                uint32_t fcta_left_warn = 0;
                uint32_t fcta_left_fail = 0;
                uint32_t fcta_right_sts = 0;
                uint32_t fcta_right_warn = 0;
                uint32_t fcta_right_fail = 0;

                uint32_t bsd_onoff_sts = 0;
                uint32_t bsd_left_sts = 0;
                uint32_t bsd_right_sts = 0;
                uint32_t bsd_left_warn = 0;
                uint32_t bsd_right_warn = 0;
                uint32_t bsd_hapic_onoff_sts = 0;
                uint32_t extern_req = 0;

                uint32_t dow_onoff_sts = 0;
                uint32_t dow_left_sts = 0;
                uint32_t dow_right_sts = 0;
                uint32_t dow_left_warn = 0;
                uint32_t dow_right_warn = 0;

                uint32_t rcta_onoff_sts = 0;
                uint32_t rcta_left_sts = 0;
                uint32_t rcta_right_sts = 0;
                uint32_t rcta_left_warn = 0;
                uint32_t rcta_right_warn = 0;

                uint32_t mirror_light_left = 0;
                uint32_t mirror_light_right = 0;
                uint32_t rear_radar_fail = 0;

            };

            struct ARBOBFTarget
            {
                //reserve for common lib;
            };

            struct ARBVehicle
            {
                float wheel_base = 2.8;
                float length = 5.2;
                float width = 2.2;
                float height = 1.8;
                float front_bumper_to_rear_axle = 3.9;
                float epm_pos_to_front_bumper = 1.8;
                float pp_c2 = 0;
            };

            struct ARBVehicleSensorMountPos
            {
                float height;
                float lat_dist_to_rearaxel_certer;
                float lon_dst_to_rearaxel_certer;
            };

            struct ARBVehicleSenor
            {
                ARBVehicleSensorMountPos radar_fc;
                ARBVehicleSensorMountPos radar_fl;
                ARBVehicleSensorMountPos radar_fr;
                ARBVehicleSensorMountPos radar_rl;
                ARBVehicleSensorMountPos radar_rr;
                ARBVehicleSensorMountPos camera_ref_point; // struct to be modified
            };

            struct ARBBCM
            {
                bool ExtLiLgtErrIndcn; //0: no error; 1: error.
                bool LgtErrBrkLiReLeMid;
                bool LgtErrBrkLiReLeSide;
                bool LgtErrBrkLiReRiMid;
                bool LgtErrBrkLiReRiSide;
                bool LgtErrBrkLiTop;
                bool LgtErrDayTiRunngLiFrntLe;
                bool LgtErrDayTiRunngLiFrntRi;
                bool LgtErrFogLiFrntLe;
                bool LgtErrFogLiFrntRi;
                bool LgtErrFogLiReLeMid;
                bool LgtErrFogLiReLeSide;
                bool LgtErrFogLiReRiMid;
                bool LgtErrFogLiReRiSide;
                bool LgtErrReFog;
                bool LgtErrHiBeamLe;
                bool LgtErrHiBeamRi;
                bool LgtErrLicensePlate;
                bool LgtErrLoBeamLe;
                bool LgtErrLoBeamRi;
                bool LgtErrPosnFrntLe;
                bool LgtErrPosnFrntRi;
                bool LgtErrPosnReLeMid;
                bool LgtErrPosnReLeSide;
                bool LgtErrPosnReRiMid;
                bool LgtErrPosnReRiSide;
                bool LgtErrTurnIndcnFrntLe;
                bool LgtErrTurnIndcnFrntRi;
                bool LgtErrTurnIndcnReLeMid;
                bool LgtErrTurnIndcnReLeSide;
                bool LgtErrTurnIndcnReRiMid;
                bool LgtErrTurnIndcnReRiSide;

                uint8_t ComfEna; // 0:not enable; 1:enable; 2:reserved; 3:invalid.
                uint8_t FOTAHvPwrMgnt; //0:disable; 1: enable; 2:reserved; 3:invalid.
                uint8_t ImobEnaReq; //0: disable; 1: enable AID1; 2: enable AID2; 3: invalid.
                uint8_t ImobSts; //0: no error; 1: no key; 2: no authorization; 3: immo failure.
                uint8_t KeyAuthSts; //0: idel; 1: pass; 2: fail; 3: reserved.
                uint8_t KeyPrsntSts; //0: no key; 1: key valid; 2: reserved; 3: invalid.
                uint8_t VehState; //0: Park(off); 1: On; 2: Driving; 3: software update; f: invalid.

                uint8_t ComfEna_ASIL; // 0:not enable; 1:enable; 2:reserved; 3:invalid.
                uint8_t DrvState; //0: unknown; 1: none; 2: MD; 3: RD; 4: AD; 7: Invalid.
                uint8_t ImmoKeyPassSrc; //0: no key; 1: rf key; 2: bluetooth; 3: nfc; 4: remote; 5: cdc; 6: ad; 7: reserved.
                uint8_t NBSMovReq; // 0: no request; 1: move forward; 2: move backward; 3: invalid.
                uint8_t NBSReq; // 0: no request; 1: request; 2: reserved; 3: invalid.
                uint8_t NBSSideDetectionReq; //0: on; 1: off; 2: reserved; 3: invalid.
                uint8_t NfcTrunkReq; //0: no request; 1: open; 2: close; 3: invalid.
                uint8_t TrunkPosnSet; //0: no request; 1: open; 2: close; 3: invalid.
                uint8_t VehMode; //0: not used; 1: production; 2: transport; 3: showroom; 4: regular; 5: driverless; f: invalid.
                uint8_t VehState_ASIL; //0: Park(off); 1: On; 2: Driving; 3: software update; f: invalid.

                uint8_t BulbOutWarnReq; //0: no warning; 1: warning; 2: reserved; 3: invalid.
                uint8_t ChrgSyncIndcnSts; //0: waiting; 1: restart; 2: reserved; 3: invalid.
                uint8_t CornrgLiFrntLeCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t CornrgLiFrntRiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t DayTiRunngLiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t DayTiRunngLiFctActvSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FogLiFrntFctActvSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FogLiFrntLeCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FogLiFrntRiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FogLiReCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FogLiReFctActvSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FolwMeHomeSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t FolwMeHomeTiSetSts; //0: 15s; 1: 30s; 2: 60s; 3: reserved; 7: invalid.
                uint8_t HiBeamCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t HiBeamFctActSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t HndlLiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t LeTurnIndcrLiReq; //0: No request; 1: off; 2: on; 3: reserved.
                uint8_t RiTurnIndcrLiReq; //0: No request; 1: off; 2: on; 3: reserved.
                uint8_t LiLanguageMod; //0: Normal; 1: Welcome1; 2: Welcome2; 3: Sleep1; 4: Sleep2; 5: Charging; 6: Rest Mode; F: invalid.
                uint8_t LoBeamCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t LoBeamFctActSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t LgtPwrSplyEna; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t MailiSetSts; //0: off; 1: Postion light; 2: Low Beam; 3: Automatic; 7: invalid.
                uint8_t PosnLiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t PosnLiFctActSts; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t PosnLiRmn; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t TrLiCmd; //0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t WelcomeLiSts; //0: off; 1: on; 2: reserved; 3: invalid.

                float Yr;
                float Mth;
                float Day;
                float Hr;
                float Min;
                float Sec;

                uint8_t FrntWiprReq; //0: off; 1: low speed; 2: high speed; 3: invalid.
                uint8_t FrntWipMod; //0: Manual; 1: Automatic; 2: reserved; 3: invalid.
                uint8_t ReWiprReq; //0: off; 1: low speed; 2: high speed; 3: invalid.
                uint8_t WiprSrvCmd; //0: not request; 1: request; 2: reserved; 3: invalid.
                uint8_t WshrCmd; //0: no washer; 1: front washer on; 2: rear washer on; 3: invalid.
                uint8_t WshrLvlWarnReq; //0: No warning; 1: level low; 2: reserved; 3: invalid.
                uint8_t ReWiprOnRmd; //0: no reminder; 1: reminder; 2: reserved; 3: invalid.
                uint8_t FrntWiprRetryReq; // 0: no retry; 1: retry; 2: reserved; 3: invalid.
                uint8_t ExtraWiprModOnOffSts; // 0: off; 1: on; 2: reserved; 3: invalid.
                uint8_t ReWiprRetryReq; // 0: no retry; 1: retry; 2: reserved; 3: invalid.
                uint8_t ReWiprAutoSetOnOffSts; //0: off; 1: on; 2: reserved; 3: Invalid.
                uint8_t ReWinDefrstCmd; // 0: off; 1: on; 2: reserved; 3: invalid.

                uint8_t left_turn_indicator_light_st;
                uint8_t right_turn_indicator_light_st;

                uint8_t AntiTheftWarnSts; //0:disarmed; 1: partial armed; 2: armed; 3: prearmed; 4: alarm.
                uint8_t CooltLvlHiWarnReq; //0: not high; 1:high.
                uint8_t CooltLvlLowWarnReq; //0; not low; 1; low.
                uint8_t DoorAjarFrntLeSts; //0: open; 1: close; 2: reserve; 3: invalid.
                uint8_t DoorAjarFrntRiSts; //0: open; 1: close; 2: reserve; 3: invalid.
                uint8_t DoorAjarReLeSts; //0: open; 1: close; 2: reserve; 3: invalid.
                uint8_t DoorAjarReRiSts; //0: open; 1: close; 2: reserve; 3: invalid.
                uint8_t HoodAjarSts; //0: open; 1: close; 2: reserve; 3: invalid.
                uint8_t TrAjarSts; //0: open; 1: close; 2: reserve; 3: invalid.

                uint8_t HornWorkModSts; //0: idle; 1: manual on; 2: lock; 3: anti theft; 4: anti lock out; 5: key inside; 6: lock fail; 7: find me; f: invalid.

                uint8_t SeatOccpFrntLeFail; //0: normal; 1: failure; 2:reserved; 3: invalid.
                uint8_t SeatOccupFrntLeSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccuptFrntRiSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccpt2ndLeSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccpt2ndMidSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccpt2ndRiSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccpt3rdLeSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.
                uint8_t SeatOccpt3rdRiSts; //0: not occupy; 1:occupy; 2: reserved; 3: invalid.

                uint8_t AntiTheftWarnReq; //0: no request; 1: request; 2: reserved; 3: invalid.

                uint8_t CenLockReq; //0: no request; 1: passive entry; 2: RKE; 3: center lock switch; 4: remote; 5: speed lock; 6: mechanic lock; 7: walk away; 8: thermal out of control; 9: auto relock; f: invalid.
                uint8_t CenLockUnlockSts; //0: vehicle unlock; 1: fully locked; 2: drive door unlocked only; 7: invalid.
                uint8_t CenLockUnlockIndcn; //0: no request; 1: external unlock request; 2: external lock request; 3: internal unlock request; 4: internal lock request; 7: invalid.
                uint8_t CentUnlockReq; //0: no request; 1: passive entry; 2: RKE; 3: Center lock switch; 4: remote; 5: crash detection; 6: approach unlock; 6: approach unlock; 7: gear P; 8: mechanical lock; 9: key in reminder unlock; a: ADC request; b: thermal out of control; c: NBS summon; f: invalid.
                uint8_t DoorHndlFrntLeReq; //0: no request; 1: deploy; 2: retract.
                uint8_t DoorHndlFrntRiReq; //0: no request; 1: deploy; 2: retract.
                uint8_t DoorHndlReLeReq; //0: no request; 1: deploy; 2: retract.
                uint8_t DoorHndlReRiReq; //0: no request; 1: deploy; 2: retract.
                uint8_t DoorLockFrntLeReq; //0: reserved; 1: lock; 2: unlock; 3: no request.
                uint8_t DoorLockFrntRiReq; //0: reserved; 1: lock; 2: unlock; 3: no request.
                uint8_t DoorLockReLeReq; //0: reserved; 1: lock; 2: unlock; 3: no request.
                uint8_t DoorLockReRiReq; //0: reserved; 1: lock; 2: unlock; 3: no request.
                uint8_t DoorLockTurnLigReq;
                uint8_t LockIndcnHornReq; //0: off; 1: on; 2: reserve; 3: invalid.
                uint8_t PlgExtSwtSts;  //0: off; 1: on; 2: reserve; 3: invalid.
                uint8_t QuickAcsBtn; //0: not pressed; 1: pressed; 2: reserved; 3: invalid.

                uint8_t BrkFldLvl; //0: normal; 1: low; 2: reserve; 3: invalid.
                uint8_t BrkFldWarnReq; //0: no warning; 1: warning; 2: reserved; 3: invalid.
                uint8_t BrkPadWearSts; //0: normal; 1: pad worn; 2: reserve; 3: invalid.
                uint8_t BrkPadWearWarnReq; //0: no warning; 1: warning; 2: reserved; 3: invalid.
                uint8_t LockFailSrc; //0: no failure; 1: vehicle state; 2: one door or trunk open; 7: invalid.
                uint8_t LockFailWarnReq; //0: warn; 1: no warn.
                bool PEPS_ECUFailWarning; //0: no warn; 1: warn.
                bool PEPS_FOBLowBATWarning; //0: no warn; 1: warn.

                float TpmsFrntLeWhlPress;
                float TpmsFrntRiWhlPress;
                float TpmsReLeWhlPress;
                float TpmsReRiWhlPress;
                float TpmsFrntLeWhlTemp;
                float TpmsFrntRiWhlTemp;
                float TpmsReLeWhlTemp;
                float TpmsReRiWhlTemp;

                uint8_t TpmsFrntLeWhlPressSts; //0: normal; 1: reserve; 2: low pressure.
                uint8_t TpmsFrntRiWhlPressSts; 
                uint8_t TpmsReLeWhlPressSts; 
                uint8_t TpmsReRiWhlPressSts;
                bool TpmsFrntLeWhlTempSts; // 0 normal; 1: high temperature.
                bool TpmsFrntRiWhlTempSts;
                bool TpmsReLeWhlTempSts;
                bool TpmsReRiWhlTempSts;
                bool TpmsFrntLeWhlDeltaPressSts; //0: not change fast; 1: change fast. detection of fast leak.
                bool TpmsFrntRiWhlDeltaPressSts;
                bool TpmsReLeWhlDeltaPressSts;
                bool TpmsReRiWhlDeltaPressSts;
                bool TpmsFrntLeBatSts; //0: normal voltage; 1: low voltage.
                bool TpmsFrntRiBatSts;
                bool TpmsReLeBatSts;
                bool TpmsReRiBatSts;
                bool TpmsFrntLeSnsrFailSts; //0: no failure; 1: failure.
                bool TpmsFrntRiSnsrFailSts;
                bool TpmsReLeSnsrFailSts;
                bool TpmsReRiSnsrFailSts;
                bool TpmsSts; //0: system ok; 1: system not ok; 2: pressure abnormal; 3: reserved.

            };

            struct ARBCGW
            {
                float deg_amb_tmp;
                uint8_t st_veh_st;
            };

            struct ARBCDC
            {
                uint8_t st_set_tsr;
                uint8_t st_svc_detn_status;
                uint8_t st_svc_available;
            };

            struct ARBFCM
            {
                uint8_t flg_tsr;
            };

            struct ARBACM
            {
                uint8_t dphi_yawrate_st;
                uint8_t lon_acc_st;
                uint8_t lat_acc_st;

                float dphi_yawrate;
                float lon_acc;
                float lat_acc;
                float lon_acc_mpss;
                float lat_acc_mpss;

                uint8_t acm_calst; //0: not calibrated; 1: calibrated; 2: reserved; 3: not available.

                bool CrashDetd;
                uint8_t AirbWarnReq; //0: off; 1: on; 2: blinking; 3: initializing.
                uint8_t PassAirbgInhbnLampReq; //0: off; 1: on; 2: blinking; 3: initializing.
                bool SeatOccupFrntRiSts_Resd;
                bool SeatBltFrntLeSts; //0: loose; 1: Fasen.
                bool SeatBltFrntRiSts; //0: loose; 1: Fasen.
                bool SeatBltMidRowLeSts; //0: loose; 1: Fasen.
                bool SeatBltMidRowMidSts; //0: loose; 1: Fasen.
                bool SeatBltMidRowRiSts; //0: loose; 1: Fasen.
                bool SeatBltReRowLeSts; //0: loose; 1: Fasen.
                bool SeatBltReRowRiSts; //0: loose; 1: Fasen.
                float LatA;
                uint8_t LatAValSts; //0: Normal; 1: Invalid; 2: Reserved; 3: Initializing.
                float YawRate;
                uint8_t YawRateValSts; //0: Normal; 1: Invalid; 2: Reserved; 3: Initializing.
                uint8_t AxAyYrsCalSts; //0: Not Calibrated; 1: Calibrated; 2: Reserved; 3: Signal not available.
                float LgtA;
                uint8_t LgtAValSts; //0: Normal; 1: Invalid; 2: Reserved; 3: Initializing.

            };

            struct ARBASDM
            {
                float FrntLeLvl;
                float FrntRiLvl;
                float ReLeLvl;
                float ReRiLvl;

                bool FrntLeLvlAdjm; // 0: no adjustment; 1: adjustment.
                bool FrntRiLvlAdjm;
                bool RearLeLvlAdjm;
                bool RearRiLvlAdjm;

                bool LvlCalCmptl; //0: not complete; 1: completed.

                bool CargoActv; //0: not active; 1:active;
                uint8_t Current_Lvl; //0: low5; 1:low4; 2:low3; 3:low2; 4:low1; 5:normal; 6:high1; 7:high2; 8:high3; 9:high4; A:high5; E:init; F:invalid.
                bool ExtraHiPosn; //0:not extreme low; 1:extreme low.
                bool ExtraLoPosn; //0:not extreme high; 1:extreme high.
                bool LC_Deactivation_RequestSts; // 0:not allow; 1: allow.
                bool LC_EasyEntryEnaSts; //0:disable; 1:enable;
                uint8_t LvlAdj_Restriction; //bit0: voltage low; bit1: temperature not meet; bit2: incorrect mode.
                uint8_t LvlAdjDrvgMod; //0: standard; 1: comfort; 2: sport.
                uint8_t LvlAdjLampReq; //0: no request; 1: request level1 (orange); 2: request level2 (red); 3:invalid.
                bool LvlAdjLimpHome; //0: normal; 1: limphome.
                uint8_t LvlAdjMod; //0: init; 1: normal; 2: service; 3: transport.
                uint8_t LvlAdjSts; //0: static pos; 1: raising to next target level; 2: lowering to next target level; 3: pending for target change; 4: raising for level adjust; 5: lowering for level adjust; 6: pending for level adjust.
                uint8_t TarLvl; //0: low5; 1:low4; 2:low3; 3:low2; 4:low1; 5:normal; 6:high1; 7:high2; 8:high3; 9:high4; A:high5; E:init; F:invalid.

                uint8_t DampgCtrlMod; //0: init; 1: normal; 2: service; 3: transport.
                bool DampgCtrlLimpHome; //0:normal; 1: limphome.
                uint8_t DampgDrvgMod; //0: standard; 1: comfort; 2: sport.
                uint8_t DampgCtrlampReq; //0: no request; 1: request level1 (orange); 2: request level2 (red); 3:invalid.

                float DamprCurrentFrntLe;
                float DamprCurrentFrntRi;
                float DamprCurrentReLe;
                float DamprCurrentReRi;
            };

            struct ARBIMU
            {
                float yaw_rate; //dphi
                float roll_rate;
                float pitch_rate;

                float lon_acc;
                float lat_acc;
                float hgth_acc;

                float longitude;
                float latitude;
            };

            struct ARBBCU
            {
                float veh_sped_kph;
                float veh_sped_mps;
                float pp_c2;
                uint8_t veh_mov_dir;

                uint8_t flg_veh_spd_valid;

                uint8_t whl_spd_fl_dir;
                float whl_spd_fl;
                uint8_t whl_spd_fr_dir;
                float whl_spd_fr;
                uint8_t whl_spd_rl_dir;
                float whl_spd_rl;
                uint8_t whl_spd_rr_dir;
                float whl_spd_rr;

                bool whl_pls_fl_valid;
                bool whl_pls_fr_valid;
                bool whl_pls_rl_valid;
                bool whl_pls_rr_valid;

                float cnt_whl_pls_fl;
                float cnt_whl_pls_fr;
                float cnt_whl_pls_rl;
                float cnt_whl_pls_rr;

                uint8_t brk_swt;
                float brk_pres;

                float WhlSpdFrntLe;
                float WhlSpdFrntRi;
                uint8_t WhlSpdFrntLeMovgDir; //0: Standstill; 1: Forward; 2: Backward; 3: Invalid.
                uint8_t WhlSpdFrntRiMovgDir; //0: Standstill; 1: Forward; 2: Backward; 3: Invalid.
                uint8_t WhlSpdFrntLeSts; //0: valid; 1: invalid; 2: Initialization; 3: reserved.
                uint8_t WhlSpdFrntRiSts; //0: valid; 1: invalid; 2: Initialization; 3: reserved.

                float WhlSpdReLe;
                float WhlSpdReRi;
                uint8_t WhlSpdReLeMovgDir; //0: Standstill; 1: Forward; 2: Backward; 3: Invalid.
                uint8_t WhlSpdReRiMovgDir; //0: Standstill; 1: Forward; 2: Backward; 3: Invalid.
                uint8_t WhlSpdReLeSts; //0: valid; 1: invalid; 2: Initialization; 3: reserved.
                uint8_t WhlSpdReRiSts; //0: valid; 1: invalid; 2: Initialization; 3: reserved.

                uint8_t BCU_NoBrkF; //0: Not applied; 1: Applied.
                uint8_t BCU_SupInfo; //0: BEG; 1: CC; 2: Mando; 3: unknown.
                uint8_t BCUBrkLiReq; //0: Not req; 1: request; 2: Reserved; 3: Invalid.
                uint8_t BrkOverHeat; //0: not high; 1: high.
                uint8_t BrkPedlSts; //0: not pressed; 1: pressed; 2: reserved; 3: invalid.
                float BrkPedlTrvl; 
                uint8_t BrkPedlTrvlCalSts; //0: Not calibrated; 1: calibrated; 2: reserved; 3: not available.
                float BrkPress;
                float BrkPressOffset;
                bool BrkPressOffsetValid; //0: valid; 1: invalid.
                bool BrkPressValid; //0: valid; 1: invalid.
                bool HAZReq; //0: not request; 1: request.
                float VehSpd;
                uint8_t VehMovgDir; //0: Standstill; 1: Forward; 2: Backward; 3: Invalid.
                bool VehSpdSts; //0: Valid; 1: invalid.

                bool ABAActv; //0: not active; 1: active.
                bool ABAAvl; //0: not available; 1: available.
                bool ABPActv;
                bool ABPAvl;
                bool ABSActv;
                bool ARPActv;
                bool ARPCfgSts; //0: enable; 1: disable.
                bool AUTOBrkActv;
                bool AUTOBrkAvl;
                bool AVHCfgSts; //0: enable; 1: disable.
                uint8_t AVHSts; //0: Failure; 1: standby; 2: Active; 3: off.
                bool AWBActv; 


            };

            struct ARBFIM
            {
                bool FIM_flgEQ4LossCommFault;
                bool FIM_flgEQ4NonRecoverableFault;
                bool FIM_flgEQ4RecoverableFault;
                bool FIM_flgSelfGlare;
                bool FIM_flgCamBlock;
                bool FIM_flgEQ4Coredump;
                bool FIM_flgFS_partialBlockage_1;
                bool FIM_flgFS_partialBlockage_2;
                bool FIM_flgFS_partialBlockage_3;
                bool FIM_flgFS_fullBlockage_1;
                bool FIM_flgFS_fullBlockage_2;
                bool FIM_flgFS_fullBlockage_3;
                bool FIM_flgFS_autofixOutOfCalibHorizon;
                bool FIM_flgFS_autofixOutOfCalibYAW;
                bool FIM_flgFS_TSR_outOfCalib_mode;
                bool FIM_flgFS_blurredImage_1;
                bool FIM_flgFS_blurredImage_2;
                bool FIM_flgFS_blurredImage_3;
                bool FIM_flgFS_lowSun_1;
                bool FIM_flgFS_lowSun_2;
                bool FIM_flgFS_lowSun_3;
                bool FIM_flgFS_splashes_1;
                bool FIM_flgFS_splashes_2;
                bool FIM_flgFS_sunRay_1;
                bool FIM_flgFS_sunRay_2;
                bool FIM_flgFS_rain_1;
                bool FIM_flgFS_rain_2;
                bool FIM_flgFS_rain_3;
                bool FIM_flgFS_fog_1;
                bool FIM_flgFS_fog_2;
                bool FIM_flgFS_fog_3;
                bool FIM_flgFS_out_of_focus_1;
                bool FIM_flgFS_out_of_focus_2;
                bool FIM_flgFS_out_of_focus_3;
                bool FIM_flgFS_frozenWindshield;

                bool FIM_flgRADFC_Blindness;
                bool FIM_flgRADFC_Failure;
                bool FIM_flgRADFCLossCommFault;
                bool FIM_flgRADFC_TiStampInvld;

                bool FIM_flgRADFLLossCommFault;
                bool FIM_flgRADFL_Blindness;
                bool FIM_flgRADFL_Failure;
                bool FIM_flgRADFL_TiStampInvld;
                bool FIM_flgRadFLLooseDiagFail;

                bool FIM_flgRADFRLossCommFault;
                bool FIM_flgRADFR_Blindness;
                bool FIM_flgRADFR_Failure;
                bool FIM_flgRADFR_TiStampInvld;
                bool FIM_flgRadFRLooseDiagFail;

                bool FIM_flgRADRLLossCommFault;
                bool FIM_flgRADRL_Blindness;
                bool FIM_flgRADRL_Failure;
                bool FIM_flgRADRL_TiStampInvld;
                bool FIM_flgRadRLLooseDiagFail;

                bool FIM_flgRADRRLossCommFault;
                bool FIM_flgRADRR_Blindness;
                bool FIM_flgRADRR_Failure;
                bool FIM_flgRADRR_TiStampInvld;
                bool FIM_flgRadRRLooseDiagFail;

                bool FIM_flgMapDataOutdated;

                bool flgVehStInld;
                bool flgHMIFail ;
                bool flgADCInternalFault;
                bool flgLatAccValInvld;
                bool flgYawrateInvld;
                bool flgLonAccValInvld;
                bool flgSeatOccpFrntLeInvld;
                bool flgSeatOccpFrntLeFailure;
                bool flgBrkPrsOfsInvld;
                bool flgVehSpdInvld ;
                bool flgWhlSpdInvld ;
                bool flgWhlPulCntInvld;
                bool flgBrkPrssInvld ;
                bool flgBrkPdlInvld ;
                bool flgStrngWhlAgSnsrFail;
                bool flgStrngWhlAgSpdInvld ;
                bool flgStrngWhlAgSnsrNotCal  ;
                bool flgAccPdlActPosnInvld ;
                bool flgGearInvld ;
                bool flgSCMLossCommFault;
                bool flgBCMLossCommFault ;
                bool flgVCULossCommFault ;
                bool flgBCULossCommFault   ;
                bool flgACMLossCommFault  ;
                bool flgCGWLossCommFault  ;
                bool flgCDCLossCommADAS_Fault ;
                bool flgSCMFail;

                bool FIM_flgADCInternalFault;
            };

            struct ARBSCM
            {
                uint8_t flg_strng_whl_agle_spd_valid;
                float strng_whl_agle;
                uint8_t flg_strng_whl_agle_dir;

                float strng_whl_agle_spd;
                uint8_t flg_strng_whl_agle_spd_dir;

                uint8_t turn_indicator_switch_st;
            };

            struct ARBVCU
            {
                uint8_t act_gear;
            };

            struct ARBFeature
            {
                uint8_t nop_st;
                uint8_t acc_np_status;
                uint8_t nop_lane_change_req;
                uint8_t lca_st_maneuver;

                uint8_t lat_ctrl_st_le_line_type;
                uint8_t lat_ctrl_st_ri_line_type;
            };

            struct EHYEgo
            {
                float yawrate_filtered;
                float pp_c2;
            };

            struct VehicleIn
            {
                ARBFIM arb_fim;
                //ARBBCU arb_bcu
                //ARBBCM arb_bcm
                ARBVehicle arb_vehicle;
                ARBVehicleSenor arb_seneor;
                //ARBCGW arb_cgw
                //ARBCDC arb_cdc
                //ARBFCM arb_fcm
                //ARBACM arb_acm
                //ARBIMU arb_imu
                //ARBSCM arb_scm
                //ARBVCU arb_vcu
                //ARBASDM arb_asdm
            };

            struct ARBSIN
            {
                EHYRadarSensor radar_info;
                APSideFeature side_feature_input;
                EHYVisionObjects vision_objects;
                EHYVisionRoad vision_road;
                VehicleIn vehicle_info;
                VisionFreespace vision_fsp;
                VisionFailSafeDetection vision_failsafe;
                VisionVehicleLightDetection vision_vehicle_light;
                VisionTSR vision_tsr;
                VisionTLR vision_tlr;
                VehicleInfo_In vehicleinfo_in;
                EHYEgo ehy_ego;
                EHYEvdOutputs ehy_evd;
                EHYHaOutputs ehy_ha;
                EHYLppOutputs ehy_lpp;
                EHYRmeOutputs ehy_rme;
                EHYTppOutputs ehy_tpp;
                EHYTsiOutputs ehy_tsi;
                EHYTseOutputs ehy_tse;
                EHYTsrOutputs ehy_tsr;
                std::vector<feature::ehy::Object> fused_obj = std::vector<feature::ehy::Object>(128, feature::ehy::Object());
                std::vector<feature::ehy::Object> vis_obj = std::vector<feature::ehy::Object>(55, feature::ehy::Object());
                VehicleProjectType vehicle_type = nio::ad::VehicleProjectType_Invalid;
            };

        
    }     // namespace ad
} // namespace nio

#endif //FEATURE_SIN_STRUCT_H_