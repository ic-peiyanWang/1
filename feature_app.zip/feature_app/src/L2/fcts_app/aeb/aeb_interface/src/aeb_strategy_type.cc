#include <array>
//#include "fcts_input_adapter.h"
#include "aeb_strategy_type.h"

namespace nio {
namespace ad {

    ARBSIN g_ego_;

    const ARBSIN *ego_ = &g_ego_;
    
    std::vector<feature::ehy::Object> g_vis_obj_;

    const std::vector<feature::ehy::Object> *fused_obj_ = nullptr;

    feature::ehy::Object fuseobj_lastframe_[MaxFusedObjIndex];

    std::vector<FusedObjFiltered> fused_obj_filtered;

    const std::vector<feature::ehy::Object> *vis_obj_ = nullptr;
    
    VRUCandidate vru_candidate;

    CCRCandidate ccr_candidate;

    FTAPCandidate ftap_candidate;

    CCCCandidate ccc_candidate;

    AESCandidate aes_candidate;

    std::vector<AEBObject> pedestrian_;
    std::vector<AEBObject> pedestrian_LF_ = std::vector<AEBObject>(40, AEBObject());

    VisMatchInfo VisMatchID_[MaxFusedObjIndex];

    LostTarget CloseLostTarget;

    LastFrameIndex fus_lf_idx;

    NotSelectReason FusObjNs_[MaxFusedObjIndex];

    FusionAEBFlag FusionVRUFlag_;
    FusionAEBFlag FusionVRUFlag_LF;

    FusionAEBFlag FusionVRURearFlag_;
    FusionAEBFlag FusionVRURearFlag_LF;

    FusionAEBFlag FusionCCRFlag_;
    FusionAEBFlag FusionCCRFlag_LF;

    uint16_t AEBSupressReason = 0x0000;
    uint16_t AEBSupressReason_AfterPref = 0x0000;
    uint16_t AEBSupressReason_AfterLowB = 0x0000;
    uint16_t AEBSupressReason_AfterHighB = 0x0000;
    uint16_t AEBSupressReason_CCFTAP = 0x0000;
    uint16_t AEBSupressReason_IBA = 0x0000;
    bool AEBSupressReason_SpeedLow = 0;
    bool driverBrake_intention = 0;
    bool driverenableIBA = 0;
    uint8_t IBAcount = 0;
    bool driverpress = 0;
    float time_interval = 0.02;
    uint8_t debug_loop = 0;
    bool hostReverse = 0;
    float deltayawrate = 0.0f;

    bool lfbrake_active = 0.0f;

    uint8_t fcw_sensitive = 1;

    EgoState_filter ego_state_aeb;

    AEBObjectCCR close_CCR;

    float ego_turning = 0;

    uint16_t ego_turn_filter = 0;
    
    int16_t turn_suppress_cycle = 0;

    float single_target_scene = 0;

    int16_t drivingstraight_filter = 0;

    bool drivingstraight = 0;

    uint8_t vehicle_count = 0;

    float ego_steady_vehspd[5] = {0,0,0,0,0}; 

    float averagespd_100ms = 0;

    bool drivingsteady = 0;

    int16_t drivingsteadycnt = 0;

    uint8_t AEBDecelReq_Dummy;

    uint8_t AEBDumpSuppress = 0;

    uint16_t aeb_fault_age     = 0;
    
    uint16_t aebrear_fault_age = 0;

    AESObjectCCR close_aes;

    AES_Control_Input aes_ctrl_input;

    AES_Control_Input aes_ctrl_input_lf;

    AES_Path aes_path_pnc;

    AES_Plan_Group aes_path_group[6];

    AES_Plan_Group aes_path_group_lf[6];

    AES_Plan_Group aes_path_group_filtered[6];

    EgoPos ego_pos;

    Line_Poli host_left;

    Line_Poli host_right;

    Line_Poli left_edge;

    Line_Poli right_edge;

    Lpp_Poli host_lane_lpp;

    bool aes_plan_valid = 0;

    // void updateAebObject(ARBSIN *aeb_sin, std::vector<feature::ehy::Object> *fused_obj, std::vector<feature::ehy::Object> *vis_obj) {
    //     ego_ = aeb_sin;
    //     //sensor_ = sensor;
    //     fused_obj_ = fused_obj;
    //     vis_obj_ = vis_obj;
    // }
    
    calc_tt aeb_calculate_tt_max(float a, float b, float c, float c_new, float range) {
        calc_tt tt_calc;
        float tt = 0;
        float tt_1 = 0;
        //float tt_2 = 0;
        float range_max = 0;
        bool valid = 0; 
        if (fabsf(a) <= 0.1) {
            tt = c * (-1)/b;
            valid = true;
        }
        else if ((b*b - 4*a*c) == 0) {
            tt = b/(2*a) * (-1);
            valid = true;
        }
        else if ((b*b - 4*a*c) > 0) {
            tt_1 = (b * (-1) + sqrtf(b * b - 4 * a *c))/(a*2);
            //tt_2 = (b * (-1) - sqrtf(b * b + 4 * a *c))/(a*2);

            tt = tt_1;
            valid = true;
        }
        else {
            range_max = (4 * a * c_new - b * b)/(4 * a);
            if (a < 0) {
                if (range_max <= range) {
                    tt = (b * (-1))/(2 * a);
                    valid = true;
                }
                else {
                    tt = 0;
                    valid = false;
                }
            }
            else {
                tt = 0;
                valid = false;
            }
        }
        
        tt_calc.tt = tt;
        tt_calc.isvalid = valid;
        return tt_calc;
    }


}
}
