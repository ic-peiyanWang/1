#include <iostream>
#include "aeb_output_publisher.h"
#include "aeb_calibration.h"
#include "aeb_condition_proc.h"
#include "fcts_diag.h"
#include "fcts_main.h"
#include "fcw_condition_proc.h"
#include "niodds/application/application.h"

namespace nio {
namespace ad {
// extern AEBInHouse aeb_;

// AEBOutputPublisher                                     aeb_output_pub_;
// std::shared_ptr<nio::ad::messages::ARBOut>             arb_out_data = std::make_shared<nio::ad::messages::ARBOut>();
// std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_debug_data =
//   std::make_shared<nio::ad::messages::debug::AEBDebugOut>();

AEBOutputPublisher::AEBOutputPublisher() {
  // m_node_ = Node::CreateNode("ARBOutputNode");
  // m_pub_arbout_ = m_node_->CreatePublisher<nio::ad::messages::ARBOut>("apps/arb_out");
  // m_pub_aebdebugout_ = m_node_->CreatePublisher<nio::ad::messages::debug::AEBDebugOut>("apps/aeb_debug_outputs");
}

bool AEBOutputPublisher::MainFcn() {
  // std::cout << "fctout_arb start"<<std::endl;
  // auto ts = Time::Now();
  // auto arb_out_data = std::make_shared<nio::ad::messages::ARBOut>();
  // auto aeb_debug_data = std::make_shared<nio::ad::messages::debug::AEBDebugOut>();

  // fill_in_ARBflag_outputs(arb_out_data);
  // // m_pub_arbout_->Publish(arb_out_data);

  // fill_in_AEBdebug_outputs(aeb_debug_data);
  // m_pub_aebdebugout_->Publish(aeb_debug_data);
  // auto dur = Time::Now() - ts;
  // std::cout << "fctout_arb complete,cost time"<<dur<<"ms"<<std::endl;
  return true;
}

bool AEBOutputPublisher::fill_in_ARBflag_outputs(std::shared_ptr<nio::ad::messages::ARBOut> arb_out) {

  arb_out->mutable_aebflag()->set_vd_pattern_seta(0);
  arb_out->mutable_aebflag()->set_vd_pattern_setb((uint32_t)FusionCCRFlag_.Warning_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_vd_pattern_setc((uint32_t)FusionCCRFlag_.lowbrake_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_vd_pattern_setd((uint32_t)FusionCCRFlag_.highbrake_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_vd_pattern_sete(0);
  arb_out->mutable_aebflag()->set_vd_pattern_setf(0);
  arb_out->mutable_aebflag()->set_vd_pattern_setg(0);

  uint32_t ped_class = 0;
  if (vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0 || vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0
      || vru_candidate.bicycle_cross_Candidate_.u8_prefill > 0 || vru_candidate.bicycle_cross_Candidate_.u8_warning > 0
      || vru_candidate.bicycle_rearcross_Candidate_.u8_highBrake > 0
      || vru_candidate.bicycle_rearcross_Candidate_.u8_lowBrake > 0
      || vru_candidate.bicycle_rearcross_Candidate_.u8_prefill > 0
      || vru_candidate.bicycle_rearcross_Candidate_.u8_warning > 0) {
    ped_class = 2;
  } else if (vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0
             || vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0
             || vru_candidate.pedestrian_cross_Candidate_.u8_prefill > 0
             || vru_candidate.pedestrian_cross_Candidate_.u8_warning > 0
             || vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0
             || vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0
             || vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill > 0
             || vru_candidate.pedestrian_rearcross_Candidate_.u8_warning > 0) {
    ped_class = 1;
  }

  arb_out->mutable_aebflag()->set_pd_pattern_seta(ped_class);
  arb_out->mutable_aebflag()->set_pd_pattern_setb((uint32_t)FusionVRUFlag_.Warning_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_pd_pattern_setc((uint32_t)FusionVRUFlag_.lowbrake_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_pd_pattern_setd((uint32_t)FusionVRUFlag_.highbrake_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_pd_pattern_sete((uint32_t)FusionVRURearFlag_.Warning_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_pd_pattern_setf((uint32_t)FusionVRURearFlag_.lowbrake_flag == kAEBAlertActive);
  arb_out->mutable_aebflag()->set_pd_pattern_setg((uint32_t)FusionVRURearFlag_.highbrake_flag == kAEBAlertActive);

  return true;
}

bool AEBOutputPublisher::fill_in_AEBdebug_outputs(std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_out) {
  aeb_out->Clear();
  aeb_out->clear_pedestrians();
  aeb_out->mutable_pedcross()->set_id(vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID);
  aeb_out->mutable_pedcross()->set_vid(vru_candidate.pedestrian_cross_Candidate_.obj.u8_VID);
  aeb_out->mutable_pedcross()->set_longpos(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_pedcross()->set_latpos(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_pedcross()->set_longspd(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_pedcross()->set_latspd(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_pedcross()->set_longacc(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_pedcross()->set_latacc(vru_candidate.pedestrian_cross_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_pedcross()->set_range(vru_candidate.pedestrian_cross_Candidate_.obj.f4_range);
  aeb_out->mutable_pedcross()->set_rangerate(vru_candidate.pedestrian_cross_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_pedcross()->set_ttc(vru_candidate.pedestrian_cross_Candidate_.obj.f4_TTC);
  aeb_out->mutable_pedcross()->set_xolc(vru_candidate.pedestrian_cross_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_pedcross()->set_latest(vru_candidate.pedestrian_cross_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_pedcross()->set_oncoming(vru_candidate.pedestrian_cross_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_pedcross()->set_preceding(vru_candidate.pedestrian_cross_Candidate_.obj.u1_preceding);
  aeb_out->mutable_pedcross()->set_crossing(vru_candidate.pedestrian_cross_Candidate_.obj.u1_crossing);
  aeb_out->mutable_pedcross()->set_aebconf(vru_candidate.pedestrian_cross_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_pedcross()->set_inpath(vru_candidate.pedestrian_cross_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_pedcross()->set_vfcheck(vru_candidate.pedestrian_cross_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_pedcross()->set_lfcheck(vru_candidate.pedestrian_cross_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_pedcross()->set_age(vru_candidate.pedestrian_cross_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_pedcross()->set_agecheck(vru_candidate.pedestrian_cross_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_pedcross()->set_inpathage(vru_candidate.pedestrian_cross_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_pedcross()->set_inpathcheck(vru_candidate.pedestrian_cross_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_pedcross()->set_toi(vru_candidate.pedestrian_cross_Candidate_.obj.u1_TOI);
  aeb_out->mutable_pedcross()->set_warn(vru_candidate.pedestrian_cross_Candidate_.u8_warning);
  aeb_out->mutable_pedcross()->set_prefill(vru_candidate.pedestrian_cross_Candidate_.u8_prefill);
  aeb_out->mutable_pedcross()->set_lowbrake(vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake);
  aeb_out->mutable_pedcross()->set_highbrake(vru_candidate.pedestrian_cross_Candidate_.u8_highBrake);
  aeb_out->mutable_pedcross()->set_isvision(vru_candidate.pedestrian_cross_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_pedcross()->set_isfusion(vru_candidate.pedestrian_cross_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_pedcross()->set_isradar(vru_candidate.pedestrian_cross_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_pedcross()->set_rangerear(vru_candidate.pedestrian_cross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_pedcross()->set_ttcrear(vru_candidate.pedestrian_cross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_pedcross()->set_timetoturn(0);
  aeb_out->mutable_pedcross()->set_timetobrake(0);
  aeb_out->mutable_pedcross()->set_steerflag(0);
  aeb_out->mutable_pedcross()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_pedcross()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_pedcross()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_pedcross()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_pedcross()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.pedestrian_cross_Candidate_.obj.ref_pos.heading));
    aeb_out->mutable_pedcross()->set_xpos_cir(vru_candidate.pedestrian_cross_Candidate_.obj.xpos_cir);
    aeb_out->mutable_pedcross()->set_ypos_cir(vru_candidate.pedestrian_cross_Candidate_.obj.ypos_cir);
    aeb_out->mutable_pedcross()->set_roc_tar(vru_candidate.pedestrian_cross_Candidate_.obj.roc_tar);
    aeb_out->mutable_pedcross()->set_mindist(vru_candidate.pedestrian_cross_Candidate_.obj.mindist);
    aeb_out->mutable_pedcross()->set_xpos_col(vru_candidate.pedestrian_cross_Candidate_.obj.xpos_col);
    aeb_out->mutable_pedcross()->set_ypos_col(vru_candidate.pedestrian_cross_Candidate_.obj.ypos_col);
    aeb_out->mutable_pedcross()->set_range_col(vru_candidate.pedestrian_cross_Candidate_.obj.range_col);
    aeb_out->mutable_pedcross()->set_range_col_tar(vru_candidate.pedestrian_cross_Candidate_.obj.range_col_tar);
    aeb_out->mutable_pedcross()->set_yawrate(vru_candidate.pedestrian_cross_Candidate_.obj.yawrate);
    aeb_out->mutable_pedcross()->set_heading(vru_candidate.pedestrian_cross_Candidate_.obj.heading);
    aeb_out->mutable_pedcross()->set_colposs(vru_candidate.pedestrian_cross_Candidate_.obj.colposs);
    aeb_out->mutable_pedcross()->set_col_num(vru_candidate.pedestrian_cross_Candidate_.obj.col_num);
    aeb_out->mutable_pedcross()->set_ttc_cir(vru_candidate.pedestrian_cross_Candidate_.obj.TTC_cir);
    aeb_out->mutable_pedcross()->set_ttc_tar(vru_candidate.pedestrian_cross_Candidate_.obj.TTC_tar);
    aeb_out->mutable_pedcross()->set_ttl_cir(vru_candidate.pedestrian_cross_Candidate_.obj.TTL_cir);
    aeb_out->mutable_pedcross()->set_ttl_tar(vru_candidate.pedestrian_cross_Candidate_.obj.TTL_tar);

  aeb_out->mutable_pedoncom()->set_id(vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID);
  aeb_out->mutable_pedoncom()->set_vid(vru_candidate.pedestrian_oncom_Candidate_.obj.u8_VID);
  aeb_out->mutable_pedoncom()->set_longpos(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_pedoncom()->set_latpos(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_pedoncom()->set_longspd(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_pedoncom()->set_latspd(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_pedoncom()->set_longacc(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_pedoncom()->set_latacc(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_pedoncom()->set_range(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_range);
  aeb_out->mutable_pedoncom()->set_rangerate(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_pedoncom()->set_ttc(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_TTC);
  aeb_out->mutable_pedoncom()->set_xolc(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_pedoncom()->set_latest(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_pedoncom()->set_oncoming(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_pedoncom()->set_preceding(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_preceding);
  aeb_out->mutable_pedoncom()->set_crossing(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_crossing);
  aeb_out->mutable_pedoncom()->set_aebconf(vru_candidate.pedestrian_oncom_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_pedoncom()->set_inpath(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_pedoncom()->set_vfcheck(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_pedoncom()->set_lfcheck(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_pedoncom()->set_age(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_pedoncom()->set_agecheck(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_pedoncom()->set_inpathage(vru_candidate.pedestrian_oncom_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_pedoncom()->set_inpathcheck(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_pedoncom()->set_toi(vru_candidate.pedestrian_oncom_Candidate_.obj.u1_TOI);
  aeb_out->mutable_pedoncom()->set_warn(vru_candidate.pedestrian_oncom_Candidate_.u8_warning);
  aeb_out->mutable_pedoncom()->set_prefill(vru_candidate.pedestrian_oncom_Candidate_.u8_prefill);
  aeb_out->mutable_pedoncom()->set_lowbrake(vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake);
  aeb_out->mutable_pedoncom()->set_highbrake(vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake);
  aeb_out->mutable_pedoncom()->set_isvision(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_pedoncom()->set_isfusion(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_pedoncom()->set_isradar(vru_candidate.pedestrian_oncom_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_pedoncom()->set_rangerear(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_pedoncom()->set_ttcrear(vru_candidate.pedestrian_oncom_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_pedoncom()->set_timetoturn(0);
  aeb_out->mutable_pedoncom()->set_timetobrake(0);
  aeb_out->mutable_pedoncom()->set_steerflag(0);
  aeb_out->mutable_pedoncom()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_pedoncom()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_pedoncom()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_pedoncom()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_pedoncom()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.pedestrian_oncom_Candidate_.obj.ref_pos.heading));
  aeb_out->mutable_pedoncom()->set_xpos_cir(vru_candidate.pedestrian_oncom_Candidate_.obj.xpos_cir);
  aeb_out->mutable_pedoncom()->set_ypos_cir(vru_candidate.pedestrian_oncom_Candidate_.obj.ypos_cir);
  aeb_out->mutable_pedoncom()->set_roc_tar(vru_candidate.pedestrian_oncom_Candidate_.obj.roc_tar);
  aeb_out->mutable_pedoncom()->set_mindist(vru_candidate.pedestrian_oncom_Candidate_.obj.mindist);
  aeb_out->mutable_pedoncom()->set_xpos_col(vru_candidate.pedestrian_oncom_Candidate_.obj.xpos_col);
  aeb_out->mutable_pedoncom()->set_ypos_col(vru_candidate.pedestrian_oncom_Candidate_.obj.ypos_col);
  aeb_out->mutable_pedoncom()->set_range_col(vru_candidate.pedestrian_oncom_Candidate_.obj.range_col);
  aeb_out->mutable_pedoncom()->set_range_col_tar(vru_candidate.pedestrian_oncom_Candidate_.obj.range_col_tar);
  aeb_out->mutable_pedoncom()->set_yawrate(vru_candidate.pedestrian_oncom_Candidate_.obj.yawrate);
  aeb_out->mutable_pedoncom()->set_heading(vru_candidate.pedestrian_oncom_Candidate_.obj.heading);
  aeb_out->mutable_pedoncom()->set_colposs(vru_candidate.pedestrian_oncom_Candidate_.obj.colposs);
  aeb_out->mutable_pedoncom()->set_col_num(vru_candidate.pedestrian_oncom_Candidate_.obj.col_num);
  aeb_out->mutable_pedoncom()->set_ttc_cir(vru_candidate.pedestrian_oncom_Candidate_.obj.TTC_cir);
  aeb_out->mutable_pedoncom()->set_ttc_tar(vru_candidate.pedestrian_oncom_Candidate_.obj.TTC_tar);
  aeb_out->mutable_pedoncom()->set_ttl_cir(vru_candidate.pedestrian_oncom_Candidate_.obj.TTL_cir);
  aeb_out->mutable_pedoncom()->set_ttl_tar(vru_candidate.pedestrian_oncom_Candidate_.obj.TTL_tar);

  aeb_out->mutable_bikcross()->set_id(vru_candidate.bicycle_cross_Candidate_.obj.u8_ID);
  aeb_out->mutable_bikcross()->set_vid(vru_candidate.bicycle_cross_Candidate_.obj.u8_VID);
  aeb_out->mutable_bikcross()->set_longpos(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_bikcross()->set_latpos(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_bikcross()->set_longspd(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_bikcross()->set_latspd(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_bikcross()->set_longacc(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_bikcross()->set_latacc(vru_candidate.bicycle_cross_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_bikcross()->set_range(vru_candidate.bicycle_cross_Candidate_.obj.f4_range);
  aeb_out->mutable_bikcross()->set_rangerate(vru_candidate.bicycle_cross_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_bikcross()->set_ttc(vru_candidate.bicycle_cross_Candidate_.obj.f4_TTC);
  aeb_out->mutable_bikcross()->set_xolc(vru_candidate.bicycle_cross_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_bikcross()->set_latest(vru_candidate.bicycle_cross_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_bikcross()->set_oncoming(vru_candidate.bicycle_cross_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_bikcross()->set_preceding(vru_candidate.bicycle_cross_Candidate_.obj.u1_preceding);
  aeb_out->mutable_bikcross()->set_crossing(vru_candidate.bicycle_cross_Candidate_.obj.u1_crossing);
  aeb_out->mutable_bikcross()->set_aebconf(vru_candidate.bicycle_cross_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_bikcross()->set_inpath(vru_candidate.bicycle_cross_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_bikcross()->set_vfcheck(vru_candidate.bicycle_cross_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_bikcross()->set_lfcheck(vru_candidate.bicycle_cross_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_bikcross()->set_age(vru_candidate.bicycle_cross_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_bikcross()->set_agecheck(vru_candidate.bicycle_cross_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_bikcross()->set_inpathage(vru_candidate.bicycle_cross_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_bikcross()->set_inpathcheck(vru_candidate.bicycle_cross_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_bikcross()->set_toi(vru_candidate.bicycle_cross_Candidate_.obj.u1_TOI);
  aeb_out->mutable_bikcross()->set_warn(vru_candidate.bicycle_cross_Candidate_.u8_warning);
  aeb_out->mutable_bikcross()->set_prefill(vru_candidate.bicycle_cross_Candidate_.u8_prefill);
  aeb_out->mutable_bikcross()->set_lowbrake(vru_candidate.bicycle_cross_Candidate_.u8_lowBrake);
  aeb_out->mutable_bikcross()->set_highbrake(vru_candidate.bicycle_cross_Candidate_.u8_highBrake);
  aeb_out->mutable_bikcross()->set_isvision(vru_candidate.bicycle_cross_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_bikcross()->set_isfusion(vru_candidate.bicycle_cross_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_bikcross()->set_isradar(vru_candidate.bicycle_cross_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_bikcross()->set_rangerear(vru_candidate.bicycle_cross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_bikcross()->set_ttcrear(vru_candidate.bicycle_cross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_bikcross()->set_timetoturn(0);
  aeb_out->mutable_bikcross()->set_timetobrake(0);
  aeb_out->mutable_bikcross()->set_steerflag(0);
  aeb_out->mutable_bikcross()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_bikcross()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_bikcross()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_bikcross()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_bikcross()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.bicycle_cross_Candidate_.obj.ref_pos.heading));
  aeb_out->mutable_bikcross()->set_xpos_cir(vru_candidate.bicycle_cross_Candidate_.obj.xpos_cir);
  aeb_out->mutable_bikcross()->set_ypos_cir(vru_candidate.bicycle_cross_Candidate_.obj.ypos_cir);
  aeb_out->mutable_bikcross()->set_roc_tar(vru_candidate.bicycle_cross_Candidate_.obj.roc_tar);
  aeb_out->mutable_bikcross()->set_mindist(vru_candidate.bicycle_cross_Candidate_.obj.mindist);
  aeb_out->mutable_bikcross()->set_xpos_col(vru_candidate.bicycle_cross_Candidate_.obj.xpos_col);
  aeb_out->mutable_bikcross()->set_ypos_col(vru_candidate.bicycle_cross_Candidate_.obj.ypos_col);
  aeb_out->mutable_bikcross()->set_range_col(vru_candidate.bicycle_cross_Candidate_.obj.range_col);
  aeb_out->mutable_bikcross()->set_range_col_tar(vru_candidate.bicycle_cross_Candidate_.obj.range_col_tar);
  aeb_out->mutable_bikcross()->set_yawrate(vru_candidate.bicycle_cross_Candidate_.obj.yawrate);
  aeb_out->mutable_bikcross()->set_heading(vru_candidate.bicycle_cross_Candidate_.obj.heading);
  aeb_out->mutable_bikcross()->set_colposs(vru_candidate.bicycle_cross_Candidate_.obj.colposs);
  aeb_out->mutable_bikcross()->set_col_num(vru_candidate.bicycle_cross_Candidate_.obj.col_num);
  aeb_out->mutable_bikcross()->set_ttc_cir(vru_candidate.bicycle_cross_Candidate_.obj.TTC_cir);
  aeb_out->mutable_bikcross()->set_ttc_tar(vru_candidate.bicycle_cross_Candidate_.obj.TTC_tar);
  aeb_out->mutable_bikcross()->set_ttl_cir(vru_candidate.bicycle_cross_Candidate_.obj.TTL_cir);
  aeb_out->mutable_bikcross()->set_ttl_tar(vru_candidate.bicycle_cross_Candidate_.obj.TTL_tar);

  aeb_out->mutable_bikoncom()->set_id(vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID);
  aeb_out->mutable_bikoncom()->set_vid(vru_candidate.bicycle_oncom_Candidate_.obj.u8_VID);
  aeb_out->mutable_bikoncom()->set_longpos(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_bikoncom()->set_latpos(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_bikoncom()->set_longspd(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_bikoncom()->set_latspd(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_bikoncom()->set_longacc(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_bikoncom()->set_latacc(vru_candidate.bicycle_oncom_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_bikoncom()->set_range(vru_candidate.bicycle_oncom_Candidate_.obj.f4_range);
  aeb_out->mutable_bikoncom()->set_rangerate(vru_candidate.bicycle_oncom_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_bikoncom()->set_ttc(vru_candidate.bicycle_oncom_Candidate_.obj.f4_TTC);
  aeb_out->mutable_bikoncom()->set_xolc(vru_candidate.bicycle_oncom_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_bikoncom()->set_latest(vru_candidate.bicycle_oncom_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_bikoncom()->set_oncoming(vru_candidate.bicycle_oncom_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_bikoncom()->set_preceding(vru_candidate.bicycle_oncom_Candidate_.obj.u1_preceding);
  aeb_out->mutable_bikoncom()->set_crossing(vru_candidate.bicycle_oncom_Candidate_.obj.u1_crossing);
  aeb_out->mutable_bikoncom()->set_aebconf(vru_candidate.bicycle_oncom_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_bikoncom()->set_inpath(vru_candidate.bicycle_oncom_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_bikoncom()->set_vfcheck(vru_candidate.bicycle_oncom_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_bikoncom()->set_lfcheck(vru_candidate.bicycle_oncom_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_bikoncom()->set_age(vru_candidate.bicycle_oncom_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_bikoncom()->set_agecheck(vru_candidate.bicycle_oncom_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_bikoncom()->set_inpathage(vru_candidate.bicycle_oncom_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_bikoncom()->set_inpathcheck(vru_candidate.bicycle_oncom_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_bikoncom()->set_toi(vru_candidate.bicycle_oncom_Candidate_.obj.u1_TOI);
  aeb_out->mutable_bikoncom()->set_warn(vru_candidate.bicycle_oncom_Candidate_.u8_warning);
  aeb_out->mutable_bikoncom()->set_prefill(vru_candidate.bicycle_oncom_Candidate_.u8_prefill);
  aeb_out->mutable_bikoncom()->set_lowbrake(vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake);
  aeb_out->mutable_bikoncom()->set_highbrake(vru_candidate.bicycle_oncom_Candidate_.u8_highBrake);
  aeb_out->mutable_bikoncom()->set_isvision(vru_candidate.bicycle_oncom_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_bikoncom()->set_isfusion(vru_candidate.bicycle_oncom_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_bikoncom()->set_isradar(vru_candidate.bicycle_oncom_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_bikoncom()->set_rangerear(vru_candidate.bicycle_oncom_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_bikoncom()->set_ttcrear(vru_candidate.bicycle_oncom_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_bikoncom()->set_timetoturn(0);
  aeb_out->mutable_bikoncom()->set_timetobrake(0);
  aeb_out->mutable_bikoncom()->set_steerflag(0);
  aeb_out->mutable_bikoncom()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_bikoncom()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_bikoncom()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_bikoncom()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_bikoncom()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.bicycle_oncom_Candidate_.obj.ref_pos.heading));
  aeb_out->mutable_bikoncom()->set_xpos_cir(vru_candidate.bicycle_oncom_Candidate_.obj.xpos_cir);
  aeb_out->mutable_bikoncom()->set_ypos_cir(vru_candidate.bicycle_oncom_Candidate_.obj.ypos_cir);
  aeb_out->mutable_bikoncom()->set_roc_tar(vru_candidate.bicycle_oncom_Candidate_.obj.roc_tar);
  aeb_out->mutable_bikoncom()->set_mindist(vru_candidate.bicycle_oncom_Candidate_.obj.mindist);
  aeb_out->mutable_bikoncom()->set_xpos_col(vru_candidate.bicycle_oncom_Candidate_.obj.xpos_col);
  aeb_out->mutable_bikoncom()->set_ypos_col(vru_candidate.bicycle_oncom_Candidate_.obj.ypos_col);
  aeb_out->mutable_bikoncom()->set_range_col(vru_candidate.bicycle_oncom_Candidate_.obj.range_col);
  aeb_out->mutable_bikoncom()->set_range_col_tar(vru_candidate.bicycle_oncom_Candidate_.obj.range_col_tar);
  aeb_out->mutable_bikoncom()->set_yawrate(vru_candidate.bicycle_oncom_Candidate_.obj.yawrate);
  aeb_out->mutable_bikoncom()->set_heading(vru_candidate.bicycle_oncom_Candidate_.obj.heading);
  aeb_out->mutable_bikoncom()->set_colposs(vru_candidate.bicycle_oncom_Candidate_.obj.colposs);
  aeb_out->mutable_bikoncom()->set_col_num(vru_candidate.bicycle_oncom_Candidate_.obj.col_num);
  aeb_out->mutable_bikoncom()->set_ttc_cir(vru_candidate.bicycle_oncom_Candidate_.obj.TTC_cir);
  aeb_out->mutable_bikoncom()->set_ttc_tar(vru_candidate.bicycle_oncom_Candidate_.obj.TTC_tar);
  aeb_out->mutable_bikoncom()->set_ttl_cir(vru_candidate.bicycle_oncom_Candidate_.obj.TTL_cir);
  aeb_out->mutable_bikoncom()->set_ttl_tar(vru_candidate.bicycle_oncom_Candidate_.obj.TTL_tar);

  aeb_out->mutable_ccrscandi()->set_id(ccr_candidate.CCRS_Candi_.u8_ID);
  aeb_out->mutable_ccrscandi()->set_vid(ccr_candidate.CCRS_Candi_.u8_VID);
  aeb_out->mutable_ccrscandi()->set_longpos(ccr_candidate.CCRS_Candi_.obj.motion.GetX());
  aeb_out->mutable_ccrscandi()->set_latpos(ccr_candidate.CCRS_Candi_.obj.motion.GetY());
  aeb_out->mutable_ccrscandi()->set_longspd(ccr_candidate.CCRS_Candi_.obj.motion.GetVx());
  aeb_out->mutable_ccrscandi()->set_latspd(ccr_candidate.CCRS_Candi_.obj.motion.GetVy());
  aeb_out->mutable_ccrscandi()->set_longacc(ccr_candidate.CCRS_Candi_.obj.motion.GetAx());
  aeb_out->mutable_ccrscandi()->set_latacc(ccr_candidate.CCRS_Candi_.obj.motion.GetAy());
  aeb_out->mutable_ccrscandi()->set_range(ccr_candidate.CCRS_Candi_.f4_range);
  aeb_out->mutable_ccrscandi()->set_rangerate(ccr_candidate.CCRS_Candi_.f4_rangerate);
  aeb_out->mutable_ccrscandi()->set_ttc(ccr_candidate.CCRS_Candi_.f4_TTC);
  aeb_out->mutable_ccrscandi()->set_xolc(ccr_candidate.CCRS_Candi_.f4_XOLC);
  aeb_out->mutable_ccrscandi()->set_movestate(static_cast<uint32_t>(ccr_candidate.CCRS_Candi_.u1_movingstate));
  aeb_out->mutable_ccrscandi()->set_moveout(0);
  aeb_out->mutable_ccrscandi()->set_inpath_before(ccr_candidate.CCRS_Candi_.u1_Inpath_Before);
  aeb_out->mutable_ccrscandi()->set_inpath_after(ccr_candidate.CCRS_Candi_.u1_Inpath_After);
  aeb_out->mutable_ccrscandi()->set_aebconf(ccr_candidate.CCRS_Candi_.u8_AEBconf);
  aeb_out->mutable_ccrscandi()->set_inpath(ccr_candidate.CCRS_Candi_.u1_Inpath);
  aeb_out->mutable_ccrscandi()->set_vfcheck(ccr_candidate.CCRS_Candi_.u1_vfplaucheck);
  aeb_out->mutable_ccrscandi()->set_lfcheck(1);
  aeb_out->mutable_ccrscandi()->set_age(ccr_candidate.CCRS_Candi_.obj.fusion_sup.age);
  aeb_out->mutable_ccrscandi()->set_agecheck(ccr_candidate.CCRS_Candi_.u1_ageplaucheck);
  aeb_out->mutable_ccrscandi()->set_inpathage(ccr_candidate.CCRS_Candi_.u8_Inpathage);
  aeb_out->mutable_ccrscandi()->set_inpathcheck(ccr_candidate.CCRS_Candi_.u1_inpathagecheck);
  aeb_out->mutable_ccrscandi()->set_toi(ccr_candidate.CCRS_Candi_.u1_TOI);
  aeb_out->mutable_ccrscandi()->set_warn(ccr_candidate.CCRS_Candi_.warnig_flag);
  aeb_out->mutable_ccrscandi()->set_prefill(ccr_candidate.CCRS_Candi_.prefill_flag);
  aeb_out->mutable_ccrscandi()->set_lowbrake(ccr_candidate.CCRS_Candi_.lowbrake_flag);
  aeb_out->mutable_ccrscandi()->set_highbrake(ccr_candidate.CCRS_Candi_.highbrake_flag);
  aeb_out->mutable_ccrscandi()->set_isvision(ccr_candidate.CCRS_Candi_.obj.IsVisionOnly());
  aeb_out->mutable_ccrscandi()->set_isfusion(ccr_candidate.CCRS_Candi_.obj.IsAllFused());
  aeb_out->mutable_ccrscandi()->set_isradar(ccr_candidate.CCRS_Candi_.obj.IsRadarOnly());
  aeb_out->mutable_ccrscandi()->set_timetoturn(0);
  aeb_out->mutable_ccrscandi()->set_timetobrake(0);
  aeb_out->mutable_ccrscandi()->set_steerflag(0);
  aeb_out->mutable_ccrscandi()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(ccr_candidate.CCRS_Candi_.ref_pos.ref_character));
  aeb_out->mutable_ccrscandi()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(ccr_candidate.CCRS_Candi_.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_ccrscandi()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(ccr_candidate.CCRS_Candi_.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_ccrscandi()->mutable_ref_pos()->set_range(
    static_cast<double>(ccr_candidate.CCRS_Candi_.ref_pos.referencepoint.range));
  aeb_out->mutable_ccrscandi()->mutable_ref_pos()->set_heading(
    static_cast<double>(ccr_candidate.CCRS_Candi_.ref_pos.heading));
  aeb_out->mutable_ccrscandi()->set_iba_flag(ccr_candidate.CCRS_Candi_.iba_flag);
  aeb_out->mutable_ccrscandi()->set_hitdist(ccr_candidate.CCRS_Candi_.hitdist);
  aeb_out->mutable_ccrscandi()->set_yawdist(ccr_candidate.CCRS_Candi_.yawdist);
  aeb_out->mutable_ccrscandi()->set_driverovertake(ccr_candidate.CCRS_Candi_.driverovertake);
  aeb_out->mutable_ccrscandi()->set_driverovertake_warn(ccr_candidate.CCRS_Candi_.driverovertake_warn);
  aeb_out->mutable_ccrscandi()->set_movingleftcount(static_cast<uint32_t>(ccr_candidate.CCRS_Candi_.movingleftcount));
  aeb_out->mutable_ccrscandi()->set_movingrightcount(static_cast<uint32_t>(ccr_candidate.CCRS_Candi_.movingrightcount));


  aeb_out->mutable_ccrmcandi()->set_id(ccr_candidate.CCRM_Candi_.u8_ID);
  aeb_out->mutable_ccrmcandi()->set_vid(ccr_candidate.CCRM_Candi_.u8_VID);
  aeb_out->mutable_ccrmcandi()->set_longpos(ccr_candidate.CCRM_Candi_.obj.motion.GetX());
  aeb_out->mutable_ccrmcandi()->set_latpos(ccr_candidate.CCRM_Candi_.obj.motion.GetY());
  aeb_out->mutable_ccrmcandi()->set_longspd(ccr_candidate.CCRM_Candi_.obj.motion.GetVx());
  aeb_out->mutable_ccrmcandi()->set_latspd(ccr_candidate.CCRM_Candi_.obj.motion.GetVy());
  aeb_out->mutable_ccrmcandi()->set_longacc(ccr_candidate.CCRM_Candi_.obj.motion.GetAx());
  aeb_out->mutable_ccrmcandi()->set_latacc(ccr_candidate.CCRM_Candi_.obj.motion.GetAy());
  aeb_out->mutable_ccrmcandi()->set_range(ccr_candidate.CCRM_Candi_.f4_range);
  aeb_out->mutable_ccrmcandi()->set_rangerate(ccr_candidate.CCRM_Candi_.f4_rangerate);
  aeb_out->mutable_ccrmcandi()->set_ttc(ccr_candidate.CCRM_Candi_.f4_TTC);
  aeb_out->mutable_ccrmcandi()->set_xolc(ccr_candidate.CCRM_Candi_.f4_XOLC);
  aeb_out->mutable_ccrmcandi()->set_movestate(static_cast<uint32_t>(ccr_candidate.CCRM_Candi_.u1_movingstate));
  aeb_out->mutable_ccrmcandi()->set_moveout(0);
  aeb_out->mutable_ccrmcandi()->set_inpath_before(ccr_candidate.CCRM_Candi_.u1_Inpath_Before);
  aeb_out->mutable_ccrmcandi()->set_inpath_after(ccr_candidate.CCRM_Candi_.u1_Inpath_After);
  aeb_out->mutable_ccrmcandi()->set_aebconf(ccr_candidate.CCRM_Candi_.u8_AEBconf);
  aeb_out->mutable_ccrmcandi()->set_inpath(ccr_candidate.CCRM_Candi_.u1_Inpath);
  aeb_out->mutable_ccrmcandi()->set_vfcheck(ccr_candidate.CCRM_Candi_.u1_vfplaucheck);
  aeb_out->mutable_ccrmcandi()->set_lfcheck(1);
  aeb_out->mutable_ccrmcandi()->set_age(ccr_candidate.CCRM_Candi_.obj.fusion_sup.age);
  aeb_out->mutable_ccrmcandi()->set_agecheck(ccr_candidate.CCRM_Candi_.u1_ageplaucheck);
  aeb_out->mutable_ccrmcandi()->set_inpathage(ccr_candidate.CCRM_Candi_.u8_Inpathage);
  aeb_out->mutable_ccrmcandi()->set_inpathcheck(ccr_candidate.CCRM_Candi_.u1_inpathagecheck);
  aeb_out->mutable_ccrmcandi()->set_toi(ccr_candidate.CCRM_Candi_.u1_TOI);
  aeb_out->mutable_ccrmcandi()->set_warn(ccr_candidate.CCRM_Candi_.warnig_flag);
  aeb_out->mutable_ccrmcandi()->set_prefill(ccr_candidate.CCRM_Candi_.prefill_flag);
  aeb_out->mutable_ccrmcandi()->set_lowbrake(ccr_candidate.CCRM_Candi_.lowbrake_flag);
  aeb_out->mutable_ccrmcandi()->set_highbrake(ccr_candidate.CCRM_Candi_.highbrake_flag);
  aeb_out->mutable_ccrmcandi()->set_isvision(ccr_candidate.CCRM_Candi_.obj.IsVisionOnly());
  aeb_out->mutable_ccrmcandi()->set_isfusion(ccr_candidate.CCRM_Candi_.obj.IsAllFused());
  aeb_out->mutable_ccrmcandi()->set_isradar(ccr_candidate.CCRM_Candi_.obj.IsRadarOnly());
  aeb_out->mutable_ccrmcandi()->set_timetoturn(0);
  aeb_out->mutable_ccrmcandi()->set_timetobrake(0);
  aeb_out->mutable_ccrmcandi()->set_steerflag(0);
  aeb_out->mutable_ccrmcandi()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(ccr_candidate.CCRM_Candi_.ref_pos.ref_character));
  aeb_out->mutable_ccrmcandi()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(ccr_candidate.CCRM_Candi_.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_ccrmcandi()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(ccr_candidate.CCRM_Candi_.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_ccrmcandi()->mutable_ref_pos()->set_range(
    static_cast<double>(ccr_candidate.CCRM_Candi_.ref_pos.referencepoint.range));
  aeb_out->mutable_ccrmcandi()->mutable_ref_pos()->set_heading(
    static_cast<double>(ccr_candidate.CCRM_Candi_.ref_pos.heading));
  aeb_out->mutable_ccrmcandi()->set_iba_flag(ccr_candidate.CCRM_Candi_.iba_flag);
  aeb_out->mutable_ccrmcandi()->set_hitdist(ccr_candidate.CCRM_Candi_.hitdist);
  aeb_out->mutable_ccrmcandi()->set_yawdist(ccr_candidate.CCRM_Candi_.yawdist);
  aeb_out->mutable_ccrmcandi()->set_driverovertake(ccr_candidate.CCRM_Candi_.driverovertake);
  aeb_out->mutable_ccrmcandi()->set_driverovertake_warn(ccr_candidate.CCRM_Candi_.driverovertake_warn);
  aeb_out->mutable_ccrmcandi()->set_movingleftcount(static_cast<uint32_t>(ccr_candidate.CCRM_Candi_.movingleftcount));
  aeb_out->mutable_ccrmcandi()->set_movingrightcount(static_cast<uint32_t>(ccr_candidate.CCRM_Candi_.movingrightcount));


  aeb_out->mutable_ftapcandi()->set_id(ftap_candidate.FTAP_Candi_.u8_ID);
  aeb_out->mutable_ftapcandi()->set_vid(ftap_candidate.FTAP_Candi_.u8_VID);
  aeb_out->mutable_ftapcandi()->set_longpos(ftap_candidate.FTAP_Candi_.obj.motion.GetX());
  aeb_out->mutable_ftapcandi()->set_latpos(ftap_candidate.FTAP_Candi_.obj.motion.GetY());
  aeb_out->mutable_ftapcandi()->set_longspd(ftap_candidate.FTAP_Candi_.obj.motion.GetVx());
  aeb_out->mutable_ftapcandi()->set_latspd(ftap_candidate.FTAP_Candi_.obj.motion.GetVy());
  aeb_out->mutable_ftapcandi()->set_longacc(ftap_candidate.FTAP_Candi_.obj.motion.GetAx());
  aeb_out->mutable_ftapcandi()->set_latacc(ftap_candidate.FTAP_Candi_.obj.motion.GetAy());
  aeb_out->mutable_ftapcandi()->set_range(ftap_candidate.FTAP_Candi_.f4_range);
  aeb_out->mutable_ftapcandi()->set_rangerate(ftap_candidate.FTAP_Candi_.f4_rangerate);
  aeb_out->mutable_ftapcandi()->set_ttc(ftap_candidate.FTAP_Candi_.f4_TTC);
  aeb_out->mutable_ftapcandi()->set_ttl(ftap_candidate.FTAP_Candi_.f4_TTL);
  aeb_out->mutable_ftapcandi()->set_colnum(ftap_candidate.FTAP_Candi_.u8_col_pointN);
  aeb_out->mutable_ftapcandi()->set_colx(ftap_candidate.FTAP_Candi_.f4_collisionx_1);
  aeb_out->mutable_ftapcandi()->set_coly(ftap_candidate.FTAP_Candi_.f4_collisiony_1);
  aeb_out->mutable_ftapcandi()->set_colr(ftap_candidate.FTAP_Candi_.f4_collisionr_1);
  aeb_out->mutable_ftapcandi()->set_heading(ftap_candidate.FTAP_Candi_.f4_Heading);
  aeb_out->mutable_ftapcandi()->set_currange(ftap_candidate.FTAP_Candi_.f4_currentRange);
  aeb_out->mutable_ftapcandi()->set_estrange(ftap_candidate.FTAP_Candi_.f4_rangeestimation);
  aeb_out->mutable_ftapcandi()->set_ttc_tar(ftap_candidate.FTAP_Candi_.TTC_tar);
  aeb_out->mutable_ftapcandi()->set_ttl_tar(ftap_candidate.FTAP_Candi_.TTL_tar);
  aeb_out->mutable_ftapcandi()->set_toi_before(ftap_candidate.FTAP_Candi_.u1_TOI_Before);
  aeb_out->mutable_ftapcandi()->set_toi_after(ftap_candidate.FTAP_Candi_.u1_TOI_After);
  aeb_out->mutable_ftapcandi()->set_inpathcur(ftap_candidate.FTAP_Candi_.u1_inpathcur);
  aeb_out->mutable_ftapcandi()->set_inpathpre(ftap_candidate.FTAP_Candi_.u1_inpathpre);
  aeb_out->mutable_ftapcandi()->set_inpath(ftap_candidate.FTAP_Candi_.u1_Inpath);
  aeb_out->mutable_ftapcandi()->set_aebconf(ftap_candidate.FTAP_Candi_.u8_AEBconf);
  aeb_out->mutable_ftapcandi()->set_warn(ftap_candidate.FTAP_Candi_.warnig_flag);
  aeb_out->mutable_ftapcandi()->set_prefill(ftap_candidate.FTAP_Candi_.prefill_flag);
  aeb_out->mutable_ftapcandi()->set_lowbrake(ftap_candidate.FTAP_Candi_.lowbrake_flag);
  aeb_out->mutable_ftapcandi()->set_highbrake(ftap_candidate.FTAP_Candi_.highbrake_flag);
  aeb_out->mutable_ftapcandi()->set_isvision(ftap_candidate.FTAP_Candi_.obj.IsVisionOnly());
  aeb_out->mutable_ftapcandi()->set_isfusion(ftap_candidate.FTAP_Candi_.obj.IsAllFused());
  aeb_out->mutable_ftapcandi()->set_isradar(ftap_candidate.FTAP_Candi_.obj.IsRadarOnly());
  aeb_out->mutable_ftapcandi()->set_timetoturn(0);
  aeb_out->mutable_ftapcandi()->set_timetobrake(0);
  aeb_out->mutable_ftapcandi()->set_steerflag(0);
  aeb_out->mutable_ftapcandi()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(ftap_candidate.FTAP_Candi_.ref_pos.ref_character));
  aeb_out->mutable_ftapcandi()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(ftap_candidate.FTAP_Candi_.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_ftapcandi()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(ftap_candidate.FTAP_Candi_.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_ftapcandi()->mutable_ref_pos()->set_range(
    static_cast<double>(ftap_candidate.FTAP_Candi_.ref_pos.referencepoint.range));
  aeb_out->mutable_ftapcandi()->mutable_ref_pos()->set_heading(
    static_cast<double>(ftap_candidate.FTAP_Candi_.ref_pos.heading));
  aeb_out->mutable_ftapcandi()->set_iba_flag(static_cast<uint32_t>(ftap_candidate.FTAP_Candi_.iba_flag));

  aeb_out->mutable_pedrear()->set_id(vru_candidate.pedestrian_rearcross_Candidate_.obj.u8_ID);
  aeb_out->mutable_pedrear()->set_vid(vru_candidate.pedestrian_rearcross_Candidate_.obj.u8_VID);
  aeb_out->mutable_pedrear()->set_longpos(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_pedrear()->set_latpos(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_pedrear()->set_longspd(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_pedrear()->set_latspd(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_pedrear()->set_longacc(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_pedrear()->set_latacc(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_pedrear()->set_range(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_pedrear()->set_rangerate(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_pedrear()->set_ttc(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_pedrear()->set_xolc(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_pedrear()->set_latest(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_pedrear()->set_oncoming(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_pedrear()->set_preceding(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_preceding);
  aeb_out->mutable_pedrear()->set_crossing(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_crossing);
  aeb_out->mutable_pedrear()->set_aebconf(vru_candidate.pedestrian_rearcross_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_pedrear()->set_inpath(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_pedrear()->set_vfcheck(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_pedrear()->set_lfcheck(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_pedrear()->set_age(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_pedrear()->set_agecheck(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_pedrear()->set_inpathage(vru_candidate.pedestrian_rearcross_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_pedrear()->set_inpathcheck(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_pedrear()->set_toirear(vru_candidate.pedestrian_rearcross_Candidate_.obj.u1_TOI_rear);
  aeb_out->mutable_pedrear()->set_warn(vru_candidate.pedestrian_rearcross_Candidate_.u8_warning);
  aeb_out->mutable_pedrear()->set_prefill(vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill);
  aeb_out->mutable_pedrear()->set_lowbrake(vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake);
  aeb_out->mutable_pedrear()->set_highbrake(vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake);
  aeb_out->mutable_pedrear()->set_isvision(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_pedrear()->set_isfusion(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_pedrear()->set_isradar(vru_candidate.pedestrian_rearcross_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_pedrear()->set_rangerear(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_pedrear()->set_ttcrear(vru_candidate.pedestrian_rearcross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_pedrear()->set_timetoturn(0);
  aeb_out->mutable_pedrear()->set_timetobrake(0);
  aeb_out->mutable_pedrear()->set_steerflag(0);
  aeb_out->mutable_pedrear()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_pedrear()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_pedrear()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_pedrear()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_pedrear()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.pedestrian_rearcross_Candidate_.obj.ref_pos.heading));
  aeb_out->mutable_pedrear()->set_xpos_cir(vru_candidate.pedestrian_rearcross_Candidate_.obj.xpos_cir);
  aeb_out->mutable_pedrear()->set_ypos_cir(vru_candidate.pedestrian_rearcross_Candidate_.obj.ypos_cir);
  aeb_out->mutable_pedrear()->set_roc_tar(vru_candidate.pedestrian_rearcross_Candidate_.obj.roc_tar);
  aeb_out->mutable_pedrear()->set_mindist(vru_candidate.pedestrian_rearcross_Candidate_.obj.mindist);
  aeb_out->mutable_pedrear()->set_xpos_col(vru_candidate.pedestrian_rearcross_Candidate_.obj.xpos_col);
  aeb_out->mutable_pedrear()->set_ypos_col(vru_candidate.pedestrian_rearcross_Candidate_.obj.ypos_col);
  aeb_out->mutable_pedrear()->set_range_col(vru_candidate.pedestrian_rearcross_Candidate_.obj.range_col);
  aeb_out->mutable_pedrear()->set_range_col_tar(vru_candidate.pedestrian_rearcross_Candidate_.obj.range_col_tar);
  aeb_out->mutable_pedrear()->set_yawrate(vru_candidate.pedestrian_rearcross_Candidate_.obj.yawrate);
  aeb_out->mutable_pedrear()->set_heading(vru_candidate.pedestrian_rearcross_Candidate_.obj.heading);
  aeb_out->mutable_pedrear()->set_colposs(vru_candidate.pedestrian_rearcross_Candidate_.obj.colposs);
  aeb_out->mutable_pedrear()->set_col_num(vru_candidate.pedestrian_rearcross_Candidate_.obj.col_num);
  aeb_out->mutable_pedrear()->set_ttc_cir(vru_candidate.pedestrian_rearcross_Candidate_.obj.TTC_cir);
  aeb_out->mutable_pedrear()->set_ttc_tar(vru_candidate.pedestrian_rearcross_Candidate_.obj.TTC_tar);
  aeb_out->mutable_pedrear()->set_ttl_cir(vru_candidate.pedestrian_rearcross_Candidate_.obj.TTL_cir);
  aeb_out->mutable_pedrear()->set_ttl_tar(vru_candidate.pedestrian_rearcross_Candidate_.obj.TTL_tar);

  aeb_out->mutable_bikrear()->set_id(vru_candidate.bicycle_rearcross_Candidate_.obj.u8_ID);
  aeb_out->mutable_bikrear()->set_vid(vru_candidate.bicycle_rearcross_Candidate_.obj.u8_VID);
  aeb_out->mutable_bikrear()->set_longpos(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetX());
  aeb_out->mutable_bikrear()->set_latpos(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetY());
  aeb_out->mutable_bikrear()->set_longspd(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetVx());
  aeb_out->mutable_bikrear()->set_latspd(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetVy());
  aeb_out->mutable_bikrear()->set_longacc(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetAx());
  aeb_out->mutable_bikrear()->set_latacc(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.motion.GetAy());
  aeb_out->mutable_bikrear()->set_range(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_bikrear()->set_rangerate(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_rangerate);
  aeb_out->mutable_bikrear()->set_ttc(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_bikrear()->set_xolc(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_XOLC);
  aeb_out->mutable_bikrear()->set_latest(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_latpos_est);
  aeb_out->mutable_bikrear()->set_oncoming(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_oncoming);
  aeb_out->mutable_bikrear()->set_preceding(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_preceding);
  aeb_out->mutable_bikrear()->set_crossing(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_crossing);
  aeb_out->mutable_bikrear()->set_aebconf(vru_candidate.bicycle_rearcross_Candidate_.obj.u8_AEBconf);
  aeb_out->mutable_bikrear()->set_inpath(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_Inpath);
  aeb_out->mutable_bikrear()->set_vfcheck(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_vfplaucheck);
  aeb_out->mutable_bikrear()->set_lfcheck(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_lfplaucheck);
  aeb_out->mutable_bikrear()->set_age(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.fusion_sup.age);
  aeb_out->mutable_bikrear()->set_agecheck(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_ageplaucheck);
  aeb_out->mutable_bikrear()->set_inpathage(vru_candidate.bicycle_rearcross_Candidate_.obj.u8_Inpathage);
  aeb_out->mutable_bikrear()->set_inpathcheck(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_inpathagecheck);
  aeb_out->mutable_bikrear()->set_toirear(vru_candidate.bicycle_rearcross_Candidate_.obj.u1_TOI_rear);
  aeb_out->mutable_bikrear()->set_warn(vru_candidate.bicycle_rearcross_Candidate_.u8_warning);
  aeb_out->mutable_bikrear()->set_prefill(vru_candidate.bicycle_rearcross_Candidate_.u8_prefill);
  aeb_out->mutable_bikrear()->set_lowbrake(vru_candidate.bicycle_rearcross_Candidate_.u8_lowBrake);
  aeb_out->mutable_bikrear()->set_highbrake(vru_candidate.bicycle_rearcross_Candidate_.u8_highBrake);
  aeb_out->mutable_bikrear()->set_isvision(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.IsVisionOnly());
  aeb_out->mutable_bikrear()->set_isfusion(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.IsAllFused());
  aeb_out->mutable_bikrear()->set_isradar(vru_candidate.bicycle_rearcross_Candidate_.obj.obj.IsRadarOnly());
  aeb_out->mutable_bikrear()->set_rangerear(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_range_rear);
  aeb_out->mutable_bikrear()->set_ttcrear(vru_candidate.bicycle_rearcross_Candidate_.obj.f4_TTC_rear);
  aeb_out->mutable_bikrear()->set_timetoturn(0);
  aeb_out->mutable_bikrear()->set_timetobrake(0);
  aeb_out->mutable_bikrear()->set_steerflag(0);
  aeb_out->mutable_bikrear()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos.ref_character));
  aeb_out->mutable_bikrear()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_bikrear()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_bikrear()->mutable_ref_pos()->set_range(
    static_cast<double>(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos.referencepoint.range));
  aeb_out->mutable_bikrear()->mutable_ref_pos()->set_heading(
    static_cast<double>(vru_candidate.bicycle_rearcross_Candidate_.obj.ref_pos.heading));
  aeb_out->mutable_bikrear()->set_xpos_cir(vru_candidate.bicycle_rearcross_Candidate_.obj.xpos_cir);
  aeb_out->mutable_bikrear()->set_ypos_cir(vru_candidate.bicycle_rearcross_Candidate_.obj.ypos_cir);
  aeb_out->mutable_bikrear()->set_roc_tar(vru_candidate.bicycle_rearcross_Candidate_.obj.roc_tar);
  aeb_out->mutable_bikrear()->set_mindist(vru_candidate.bicycle_rearcross_Candidate_.obj.mindist);
  aeb_out->mutable_bikrear()->set_xpos_col(vru_candidate.bicycle_rearcross_Candidate_.obj.xpos_col);
  aeb_out->mutable_bikrear()->set_ypos_col(vru_candidate.bicycle_rearcross_Candidate_.obj.ypos_col);
  aeb_out->mutable_bikrear()->set_range_col(vru_candidate.bicycle_rearcross_Candidate_.obj.range_col);
  aeb_out->mutable_bikrear()->set_range_col_tar(vru_candidate.bicycle_rearcross_Candidate_.obj.range_col_tar);
  aeb_out->mutable_bikrear()->set_yawrate(vru_candidate.bicycle_rearcross_Candidate_.obj.yawrate);
  aeb_out->mutable_bikrear()->set_heading(vru_candidate.bicycle_rearcross_Candidate_.obj.heading);
  aeb_out->mutable_bikrear()->set_colposs(vru_candidate.bicycle_rearcross_Candidate_.obj.colposs);
  aeb_out->mutable_bikrear()->set_col_num(vru_candidate.bicycle_rearcross_Candidate_.obj.col_num);
  aeb_out->mutable_bikrear()->set_ttc_cir(vru_candidate.bicycle_rearcross_Candidate_.obj.TTC_cir);
  aeb_out->mutable_bikrear()->set_ttc_tar(vru_candidate.bicycle_rearcross_Candidate_.obj.TTC_tar);
  aeb_out->mutable_bikrear()->set_ttl_cir(vru_candidate.bicycle_rearcross_Candidate_.obj.TTL_cir);
  aeb_out->mutable_bikrear()->set_ttl_tar(vru_candidate.bicycle_rearcross_Candidate_.obj.TTL_tar);

  aeb_out->mutable_hoststate()->set_vehspd(ego_state_aeb.vehspd);
  aeb_out->mutable_hoststate()->set_yawrate(ego_state_aeb.yawrate);
  aeb_out->mutable_hoststate()->set_steerangle(ego_state_aeb.strwhlangle);
  aeb_out->mutable_hoststate()->set_steerrate(ego_state_aeb.steerrate);
  aeb_out->mutable_hoststate()->set_hostreverse(hostReverse);
  aeb_out->mutable_hoststate()->set_brakepos(ego_state_aeb.brakepos);
  aeb_out->mutable_hoststate()->set_brakeposrate(ego_state_aeb.brakeposrate);
  aeb_out->mutable_hoststate()->set_driverpressed(ego_state_aeb.driverpress);
  aeb_out->mutable_hoststate()->set_maincypress(ego_state_aeb.maincypress);
  aeb_out->mutable_hoststate()->set_maincyprsrate(ego_state_aeb.maincypressrate);
  aeb_out->mutable_hoststate()->set_driverintention(ego_state_aeb.driverintention);
  aeb_out->mutable_hoststate()->set_drivereba(ego_state_aeb.drivereba);
  aeb_out->mutable_hoststate()->set_roc(ego_state_aeb.roc);
  aeb_out->mutable_hoststate()->set_accpos(ego_state_aeb.accpos);
  aeb_out->mutable_hoststate()->set_accposrate(ego_state_aeb.accposrate);

  for (int pedi = 0; pedi < (int)pedestrian_.size(); pedi++) {
    nio::ad::messages::debug::VRUCandiOut* pedout_ = aeb_out->add_pedestrians();

    pedout_->set_id(pedestrian_.at(pedi).u8_ID);
    pedout_->set_vid(pedestrian_.at(pedi).u8_VID);
    pedout_->set_longpos(pedestrian_.at(pedi).obj.motion.GetX());
    pedout_->set_latpos(pedestrian_.at(pedi).obj.motion.GetY());
    pedout_->set_longspd(pedestrian_.at(pedi).obj.motion.GetVx());
    pedout_->set_latspd(pedestrian_.at(pedi).obj.motion.GetVy());
    pedout_->set_longacc(pedestrian_.at(pedi).obj.motion.GetAx());
    pedout_->set_latacc(pedestrian_.at(pedi).obj.motion.GetAy());
    pedout_->set_range(pedestrian_.at(pedi).f4_range);
    pedout_->set_rangerate(pedestrian_.at(pedi).f4_rangerate);
    pedout_->set_ttc(pedestrian_.at(pedi).f4_TTC);
    pedout_->set_xolc(pedestrian_.at(pedi).f4_XOLC);
    pedout_->set_latest(pedestrian_.at(pedi).f4_latpos_est);
    pedout_->set_oncoming(pedestrian_.at(pedi).u1_oncoming);
    pedout_->set_preceding(pedestrian_.at(pedi).u1_preceding);
    pedout_->set_crossing(pedestrian_.at(pedi).u1_crossing);
    pedout_->set_stationary(pedestrian_.at(pedi).u1_stationary);
    pedout_->set_aebconf(pedestrian_.at(pedi).u8_AEBconf);
    pedout_->set_inpath(pedestrian_.at(pedi).u1_Inpath);
    pedout_->set_vfcheck(pedestrian_.at(pedi).u1_vfplaucheck);
    pedout_->set_lfcheck(pedestrian_.at(pedi).u1_lfplaucheck);
    pedout_->set_age(pedestrian_.at(pedi).obj.fusion_sup.age);
    pedout_->set_agecheck(pedestrian_.at(pedi).u1_ageplaucheck);
    pedout_->set_inpathage(pedestrian_.at(pedi).u8_Inpathage);
    pedout_->set_inpathcheck(pedestrian_.at(pedi).u1_inpathagecheck);
    pedout_->set_toi(pedestrian_.at(pedi).u1_TOI);
    pedout_->set_toirear(pedestrian_.at(pedi).u1_TOI_rear);
    pedout_->set_warn(0);
    pedout_->set_prefill(0);
    pedout_->set_lowbrake(0);
    pedout_->set_highbrake(0);
    pedout_->set_isvision(pedestrian_.at(pedi).obj.IsVisionOnly());
    pedout_->set_isfusion(pedestrian_.at(pedi).obj.IsAllFused());
    pedout_->set_isradar(pedestrian_.at(pedi).obj.IsRadarOnly());
    pedout_->set_rangerear(pedestrian_.at(pedi).f4_range_rear);
    pedout_->set_ttcrear(pedestrian_.at(pedi).f4_TTC_rear);
    pedout_->set_timetoturn(0);
    pedout_->set_timetobrake(0);
    pedout_->set_steerflag(0);
    pedout_->mutable_ref_pos()->set_ref_character(static_cast<uint32_t>(pedestrian_.at(pedi).ref_pos.ref_character));
    pedout_->mutable_ref_pos()->set_pos_x(static_cast<double>(pedestrian_.at(pedi).ref_pos.referencepoint.pos_x));
    pedout_->mutable_ref_pos()->set_pos_y(static_cast<double>(pedestrian_.at(pedi).ref_pos.referencepoint.pos_y));
    pedout_->mutable_ref_pos()->set_range(static_cast<double>(pedestrian_.at(pedi).ref_pos.referencepoint.range));
    pedout_->mutable_ref_pos()->set_heading(static_cast<double>(pedestrian_.at(pedi).ref_pos.heading));
    pedout_->set_xpos_cir(pedestrian_.at(pedi).xpos_cir);
    pedout_->set_ypos_cir(pedestrian_.at(pedi).ypos_cir);
    pedout_->set_roc_tar(pedestrian_.at(pedi).roc_tar);
    pedout_->set_mindist(pedestrian_.at(pedi).mindist);
    pedout_->set_xpos_col(pedestrian_.at(pedi).xpos_col);
    pedout_->set_ypos_col(pedestrian_.at(pedi).ypos_col);
    pedout_->set_range_col(pedestrian_.at(pedi).range_col);
    pedout_->set_range_col_tar(pedestrian_.at(pedi).range_col_tar);
    pedout_->set_yawrate(pedestrian_.at(pedi).yawrate);
    pedout_->set_heading(pedestrian_.at(pedi).heading);
    pedout_->set_colposs(pedestrian_.at(pedi).colposs);
    pedout_->set_col_num(pedestrian_.at(pedi).col_num);
    pedout_->set_ttc_cir(pedestrian_.at(pedi).TTC_cir);
    pedout_->set_ttc_tar(pedestrian_.at(pedi).TTC_tar);
    pedout_->set_ttl_cir(pedestrian_.at(pedi).TTL_cir);
    pedout_->set_ttl_tar(pedestrian_.at(pedi).TTL_tar);
  }

  // std::cout<< "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" <<std::endl;
  // std::cout<< "the size of the pedestrian is " << (int)aeb_out->pedestrians_size() << std::endl;

  aeb_out->mutable_closetarget()->set_id(close_CCR.u8_ID);
  aeb_out->mutable_closetarget()->set_vid(close_CCR.u8_VID);
  aeb_out->mutable_closetarget()->set_longpos(close_CCR.obj.motion.GetX());
  aeb_out->mutable_closetarget()->set_latpos(close_CCR.obj.motion.GetY());
  aeb_out->mutable_closetarget()->set_longspd(close_CCR.obj.motion.GetVx());
  aeb_out->mutable_closetarget()->set_latspd(close_CCR.obj.motion.GetVy());
  aeb_out->mutable_closetarget()->set_longacc(close_CCR.obj.motion.GetAx());
  aeb_out->mutable_closetarget()->set_latacc(close_CCR.obj.motion.GetAy());
  aeb_out->mutable_closetarget()->set_range(close_CCR.f4_range);
  aeb_out->mutable_closetarget()->set_rangerate(close_CCR.f4_rangerate);
  aeb_out->mutable_closetarget()->set_ttc(close_CCR.f4_TTC);
  aeb_out->mutable_closetarget()->set_xolc(close_CCR.f4_XOLC);
  aeb_out->mutable_closetarget()->set_movestate(static_cast<uint32_t>(close_CCR.u1_movingstate));
  aeb_out->mutable_closetarget()->set_moveout(0);
  aeb_out->mutable_closetarget()->set_inpath_before(close_CCR.u1_Inpath_Before);
  aeb_out->mutable_closetarget()->set_inpath_after(close_CCR.u1_Inpath_After);
  aeb_out->mutable_closetarget()->set_aebconf(close_CCR.u8_AEBconf);
  aeb_out->mutable_closetarget()->set_inpath(close_CCR.u1_Inpath);
  aeb_out->mutable_closetarget()->set_vfcheck(close_CCR.u1_vfplaucheck);
  aeb_out->mutable_closetarget()->set_lfcheck(1);
  aeb_out->mutable_closetarget()->set_age(close_CCR.obj.fusion_sup.age);
  aeb_out->mutable_closetarget()->set_agecheck(close_CCR.u1_ageplaucheck);
  aeb_out->mutable_closetarget()->set_inpathage(close_CCR.u8_Inpathage);
  aeb_out->mutable_closetarget()->set_inpathcheck(close_CCR.u1_inpathagecheck);
  aeb_out->mutable_closetarget()->set_toi(close_CCR.u1_TOI);
  aeb_out->mutable_closetarget()->set_warn(close_CCR.warnig_flag);
  aeb_out->mutable_closetarget()->set_prefill(close_CCR.prefill_flag);
  aeb_out->mutable_closetarget()->set_lowbrake(close_CCR.lowbrake_flag);
  aeb_out->mutable_closetarget()->set_highbrake(close_CCR.highbrake_flag);
  aeb_out->mutable_closetarget()->set_isvision(close_CCR.obj.IsVisionOnly());
  aeb_out->mutable_closetarget()->set_isfusion(close_CCR.obj.IsAllFused());
  aeb_out->mutable_closetarget()->set_isradar(close_CCR.obj.IsRadarOnly());
  aeb_out->mutable_closetarget()->set_timetoturn(0);
  aeb_out->mutable_closetarget()->set_timetobrake(0);
  aeb_out->mutable_closetarget()->set_steerflag(0);
  aeb_out->mutable_closetarget()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(close_CCR.ref_pos.ref_character));
  aeb_out->mutable_closetarget()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(close_CCR.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_closetarget()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(close_CCR.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_closetarget()->mutable_ref_pos()->set_range(
    static_cast<double>(close_CCR.ref_pos.referencepoint.range));
  aeb_out->mutable_closetarget()->mutable_ref_pos()->set_heading(static_cast<double>(close_CCR.ref_pos.heading));
  aeb_out->mutable_closetarget()->set_iba_flag(close_CCR.iba_flag);

  aeb_out->mutable_drivermonitor()->set_gaspedpos(drimonitor.input_.gaspedpos);
  aeb_out->mutable_drivermonitor()->set_gaspedgrad(drimonitor.input_.gaspedgrad);
  aeb_out->mutable_drivermonitor()->set_driverbrake(drimonitor.input_.driverbraking);
  aeb_out->mutable_drivermonitor()->set_brkpedpos(drimonitor.input_.brkpedpos);
  aeb_out->mutable_drivermonitor()->set_steerwhlang(drimonitor.input_.steerwhlang);
  aeb_out->mutable_drivermonitor()->set_steerwhlgrad(drimonitor.input_.steerwhlgrad);
  aeb_out->mutable_drivermonitor()->set_egospd(drimonitor.input_.ego_velx);
  aeb_out->mutable_drivermonitor()->set_egoaccel(drimonitor.input_.ego_ax);
  aeb_out->mutable_drivermonitor()->set_egoyawrate(drimonitor.input_.ego_yawrate);
  aeb_out->mutable_drivermonitor()->set_turnlighton(drimonitor.input_.turnlight_on);
  aeb_out->mutable_drivermonitor()->set_egogear(drimonitor.input_.ego_gear);
  aeb_out->mutable_drivermonitor()->set_feedbackstate(drimonitor.output_.feedbackstate);
  aeb_out->mutable_drivermonitor()->set_activitystate(drimonitor.output_.activitystate);
  aeb_out->mutable_drivermonitor()->set_focusstate(drimonitor.output_.focusstate);
  aeb_out->mutable_drivermonitor()->set_suppressbit(drimonitor.output_.suppressbit);
  aeb_out->mutable_drivermonitor()->set_abortbit(drimonitor.output_.abortbit);
  aeb_out->mutable_drivermonitor()->set_vel_std_dev(drimonitor.output_.vel_std_dev);
  aeb_out->mutable_drivermonitor()->set_sdytimer(drimonitor.output_.sdytimer);
  aeb_out->mutable_drivermonitor()->set_ramptimer(drimonitor.output_.ramptimer);
  aeb_out->mutable_drivermonitor()->set_dampsuppress(drimonitor.output_.dampsuppressed);
  //aeb_out->mutable_drivermonitor()->set_drive_mode(drimonitor.input_.drive_mode);

  aeb_out->mutable_drivermonitor()->clear_dampfactor();
  for (size_t i = 0; i < 16; i++) {
    aeb_out->mutable_drivermonitor()->add_dampfactor(drimonitor.output_.dampfactor[i]);
  }

  aeb_out->clear_genobjfilter();
  for (size_t i = 0; i < fused_obj_filtered.size(); i++) {
    nio::ad::messages::debug::GOFOut* gofout_ = aeb_out->add_genobjfilter();

    gofout_->set_checkid(fused_obj_filtered.at(i).gofcheck.checkID);
    gofout_->set_checkvalid(fused_obj_filtered.at(i).gofcheck.check_valid);
    gofout_->set_classcheck(fused_obj_filtered.at(i).gofcheck.classcheck);
    gofout_->set_fustcheck(fused_obj_filtered.at(i).gofcheck.fustcheck);
    gofout_->set_agecheck(fused_obj_filtered.at(i).gofcheck.agecheck);
    gofout_->set_predcheck(fused_obj_filtered.at(i).gofcheck.predcheck);
    gofout_->set_frespacheck(fused_obj_filtered.at(i).gofcheck.freespacecheck);
  }

  aeb_out->mutable_fusionccrflag()->set_warning_flag(FusionCCRFlag_.Warning_flag);
  aeb_out->mutable_fusionccrflag()->set_prefill_flage(FusionCCRFlag_.prefill_flag);
  aeb_out->mutable_fusionccrflag()->set_lowbrake_flag(FusionCCRFlag_.lowbrake_flag);
  aeb_out->mutable_fusionccrflag()->set_highbrake_flag(FusionCCRFlag_.highbrake_flag);
  aeb_out->mutable_fusionccrflag()->set_unconfirmed_flag(FusionCCRFlag_.unconfirmed_flag);
  aeb_out->mutable_fusionccrflag()->set_hold_flag(FusionCCRFlag_.hold_flag);
  aeb_out->mutable_fusionccrflag()->set_lowbrake_age(FusionCCRFlag_.lowbrake_age);
  aeb_out->mutable_fusionccrflag()->set_highbrake_hold_age(FusionCCRFlag_.highbrake_hold_age);
  aeb_out->mutable_fusionccrflag()->set_warnbrake_flag(FusionCCRFlag_.warnbrake_flag);
  aeb_out->mutable_fusionccrflag()->set_readyforiba(FusionCCRFlag_.readyforIBA);

  aeb_out->mutable_fusionvruflag()->set_warning_flag(FusionVRUFlag_.Warning_flag);
  aeb_out->mutable_fusionvruflag()->set_prefill_flage(FusionVRUFlag_.prefill_flag);
  aeb_out->mutable_fusionvruflag()->set_lowbrake_flag(FusionVRUFlag_.lowbrake_flag);
  aeb_out->mutable_fusionvruflag()->set_highbrake_flag(FusionVRUFlag_.highbrake_flag);
  aeb_out->mutable_fusionvruflag()->set_unconfirmed_flag(FusionVRUFlag_.unconfirmed_flag);
  aeb_out->mutable_fusionvruflag()->set_hold_flag(FusionVRUFlag_.hold_flag);
  aeb_out->mutable_fusionvruflag()->set_lowbrake_age(FusionVRUFlag_.lowbrake_age);
  aeb_out->mutable_fusionvruflag()->set_highbrake_hold_age(FusionVRUFlag_.highbrake_hold_age);
  aeb_out->mutable_fusionvruflag()->set_warnbrake_flag(FusionVRUFlag_.warnbrake_flag);
  aeb_out->mutable_fusionvruflag()->set_readyforiba(FusionVRUFlag_.readyforIBA);

  aeb_out->mutable_fusionvrurearflag()->set_warning_flag(FusionVRURearFlag_.Warning_flag);
  aeb_out->mutable_fusionvrurearflag()->set_prefill_flage(FusionVRURearFlag_.prefill_flag);
  aeb_out->mutable_fusionvrurearflag()->set_lowbrake_flag(FusionVRURearFlag_.lowbrake_flag);
  aeb_out->mutable_fusionvrurearflag()->set_lowbrake_age(FusionVRURearFlag_.lowbrake_age);
  aeb_out->mutable_fusionvrurearflag()->set_highbrake_flag(FusionVRURearFlag_.highbrake_flag);
  aeb_out->mutable_fusionvrurearflag()->set_hold_flag(FusionVRURearFlag_.hold_flag);
  aeb_out->mutable_fusionvrurearflag()->set_highbrake_hold_age(FusionVRURearFlag_.highbrake_hold_age);

  aeb_out->mutable_aebactuflg()->set_prewarn(AEBActuFlg.prewarn);
  aeb_out->mutable_aebactuflg()->set_latentwarn(AEBActuFlg.latentwarn);
  aeb_out->mutable_aebactuflg()->set_prefill(AEBActuFlg.prefill);
  aeb_out->mutable_aebactuflg()->set_warnbrk(AEBActuFlg.warnbrk);
  aeb_out->mutable_aebactuflg()->set_softbrk(AEBActuFlg.softbrk);
  aeb_out->mutable_aebactuflg()->set_hardbrk(AEBActuFlg.hardbrk);
  aeb_out->mutable_aebactuflg()->set_iba_req(AEBActuFlg.iba_req);
  aeb_out->mutable_aebactuflg()->set_warntype(static_cast<uint32_t>(AEBActuFlg.warntype));
  aeb_out->mutable_aebactuflg()->set_hold_req(AEBActuFlg.hold_req);

  aeb_out->mutable_ccfocandi()->set_id(0);
  aeb_out->mutable_ccfocandi()->set_vid(0);
  aeb_out->mutable_ccfocandi()->set_longpos(0);
  aeb_out->mutable_ccfocandi()->set_latpos(0);
  aeb_out->mutable_ccfocandi()->set_longspd(0);
  aeb_out->mutable_ccfocandi()->set_latspd(0);
  aeb_out->mutable_ccfocandi()->set_longacc(0);
  aeb_out->mutable_ccfocandi()->set_latacc(0);
  aeb_out->mutable_ccfocandi()->set_range(0);
  aeb_out->mutable_ccfocandi()->set_rangerate(0);
  aeb_out->mutable_ccfocandi()->set_ttc(0);
  aeb_out->mutable_ccfocandi()->set_xolc(0);
  aeb_out->mutable_ccfocandi()->set_movestate(0);
  aeb_out->mutable_ccfocandi()->set_moveout(0);
  aeb_out->mutable_ccfocandi()->set_inpath_before(0);
  aeb_out->mutable_ccfocandi()->set_inpath_after(0);
  aeb_out->mutable_ccfocandi()->set_aebconf(0);
  aeb_out->mutable_ccfocandi()->set_inpath(0);
  aeb_out->mutable_ccfocandi()->set_vfcheck(0);
  aeb_out->mutable_ccfocandi()->set_lfcheck(0);
  aeb_out->mutable_ccfocandi()->set_age(0);
  aeb_out->mutable_ccfocandi()->set_agecheck(0);
  aeb_out->mutable_ccfocandi()->set_inpathage(0);
  aeb_out->mutable_ccfocandi()->set_inpathcheck(0);
  aeb_out->mutable_ccfocandi()->set_toi(0);
  aeb_out->mutable_ccfocandi()->set_warn(0);
  aeb_out->mutable_ccfocandi()->set_prefill(0);
  aeb_out->mutable_ccfocandi()->set_lowbrake(0);
  aeb_out->mutable_closetarget()->set_highbrake(0);
  aeb_out->mutable_ccfocandi()->set_isvision(0);
  aeb_out->mutable_ccfocandi()->set_isfusion(0);
  aeb_out->mutable_ccfocandi()->set_isradar(0);
  aeb_out->mutable_ccfocandi()->set_timetoturn(0);
  aeb_out->mutable_ccfocandi()->set_timetobrake(0);
  aeb_out->mutable_ccfocandi()->set_steerflag(0);
  aeb_out->mutable_ccfocandi()->set_iba_flag(0);

  aeb_out->mutable_ccccandi()->set_id(ccc_candidate.CCC_Candi_.u8_ID);
  aeb_out->mutable_ccccandi()->set_vid(ccc_candidate.CCC_Candi_.u8_VID);
  aeb_out->mutable_ccccandi()->set_longpos(ccc_candidate.CCC_Candi_.f4_longpos);
  aeb_out->mutable_ccccandi()->set_latpos(ccc_candidate.CCC_Candi_.f4_latpos);
  aeb_out->mutable_ccccandi()->set_longspd(ccc_candidate.CCC_Candi_.f4_longvel);
  aeb_out->mutable_ccccandi()->set_latspd(ccc_candidate.CCC_Candi_.f4_latvel);
  aeb_out->mutable_ccccandi()->set_longacc(ccc_candidate.CCC_Candi_.obj.motion.GetAx());
  aeb_out->mutable_ccccandi()->set_latacc(ccc_candidate.CCC_Candi_.obj.motion.GetAy());
  aeb_out->mutable_ccccandi()->set_range(ccc_candidate.CCC_Candi_.f4_range);
  aeb_out->mutable_ccccandi()->set_rangerate(ccc_candidate.CCC_Candi_.f4_rangerate);
  aeb_out->mutable_ccccandi()->set_ttc(ccc_candidate.CCC_Candi_.f4_TTC);
  aeb_out->mutable_ccccandi()->set_ttl(ccc_candidate.CCC_Candi_.f4_TTL);
  aeb_out->mutable_ccccandi()->set_colnum(ccc_candidate.CCC_Candi_.u8_col_pointN);
  aeb_out->mutable_ccccandi()->set_colx(ccc_candidate.CCC_Candi_.f4_collisionx_1);
  aeb_out->mutable_ccccandi()->set_coly(ccc_candidate.CCC_Candi_.f4_collisiony_1);
  aeb_out->mutable_ccccandi()->set_colr(ccc_candidate.CCC_Candi_.f4_collisionr_1);
  aeb_out->mutable_ccccandi()->set_heading(ccc_candidate.CCC_Candi_.f4_Heading);
  aeb_out->mutable_ccccandi()->set_currange(ccc_candidate.CCC_Candi_.f4_currentRange);
  aeb_out->mutable_ccccandi()->set_estrange(ccc_candidate.CCC_Candi_.f4_rangeestimation);
  aeb_out->mutable_ccccandi()->set_ttc_tar(ccc_candidate.CCC_Candi_.TTC_tar);
  aeb_out->mutable_ccccandi()->set_ttl_tar(ccc_candidate.CCC_Candi_.TTL_tar);
  aeb_out->mutable_ccccandi()->set_toi_before(ccc_candidate.CCC_Candi_.u1_TOI_Before);
  aeb_out->mutable_ccccandi()->set_toi_after(ccc_candidate.CCC_Candi_.u1_TOI_After);
  aeb_out->mutable_ccccandi()->set_inpathcur(ccc_candidate.CCC_Candi_.u1_inpathcur);
  aeb_out->mutable_ccccandi()->set_inpathpre(ccc_candidate.CCC_Candi_.u1_inpathpre);
  aeb_out->mutable_ccccandi()->set_inpath(ccc_candidate.CCC_Candi_.u1_Inpath);
  aeb_out->mutable_ccccandi()->set_aebconf(ccc_candidate.CCC_Candi_.u8_AEBconf);
  aeb_out->mutable_ccccandi()->set_warn(ccc_candidate.CCC_Candi_.warnig_flag);
  aeb_out->mutable_ccccandi()->set_prefill(ccc_candidate.CCC_Candi_.prefill_flag);
  aeb_out->mutable_ccccandi()->set_lowbrake(ccc_candidate.CCC_Candi_.lowbrake_flag);
  aeb_out->mutable_ccccandi()->set_highbrake(ccc_candidate.CCC_Candi_.highbrake_flag);
  aeb_out->mutable_ccccandi()->set_isvision(ccc_candidate.CCC_Candi_.obj.IsVisionOnly());
  aeb_out->mutable_ccccandi()->set_isfusion(ccc_candidate.CCC_Candi_.obj.IsAllFused());
  aeb_out->mutable_ccccandi()->set_isradar(ccc_candidate.CCC_Candi_.obj.IsRadarOnly());
  aeb_out->mutable_ccccandi()->set_timetoturn(0);
  aeb_out->mutable_ccccandi()->set_timetobrake(0);
  aeb_out->mutable_ccccandi()->set_steerflag(0);
  aeb_out->mutable_ccccandi()->mutable_ref_pos()->set_ref_character(
    static_cast<uint32_t>(ccc_candidate.CCC_Candi_.ref_pos.ref_character));
  aeb_out->mutable_ccccandi()->mutable_ref_pos()->set_pos_x(
    static_cast<double>(ccc_candidate.CCC_Candi_.ref_pos.referencepoint.pos_x));
  aeb_out->mutable_ccccandi()->mutable_ref_pos()->set_pos_y(
    static_cast<double>(ccc_candidate.CCC_Candi_.ref_pos.referencepoint.pos_y));
  aeb_out->mutable_ccccandi()->mutable_ref_pos()->set_range(
    static_cast<double>(ccc_candidate.CCC_Candi_.ref_pos.referencepoint.range));
  aeb_out->mutable_ccccandi()->mutable_ref_pos()->set_heading(
    static_cast<double>(ccc_candidate.CCC_Candi_.ref_pos.heading));
  aeb_out->mutable_ccccandi()->set_iba_flag(static_cast<uint32_t>(ccc_candidate.CCC_Candi_.iba_flag));

  aeb_out->mutable_aebsm()->set_aebonff_cdn(AEBSm.get_aebOnff_cdn());
  aeb_out->mutable_aebsm()->set_psv_cdn(AEBSm.get_psv_cdn());
  aeb_out->mutable_aebsm()->set_tmpfail_cdn(AEBSm.get_tmpfail_cdn());
  aeb_out->mutable_aebsm()->set_factive_cdn(AEBSm.get_frwrdactv_cdn());
  aeb_out->mutable_aebsm()->set_bactive_cdn(AEBSm.get_bckwrdactv_cdn());
  aeb_out->mutable_aebsm()->set_stdby_cdn(AEBSm.get_stdby_cdn());
  aeb_out->mutable_aebsm()->set_st(static_cast<uint32_t>(AEBSm.get_aeb_st()));
  aeb_out->mutable_aebsm()->set_sys_st(static_cast<uint32_t>(AEBSm.get_aeb_sys_st()));

  aeb_out->mutable_fcwsm()->set_aebonff_cdn(FCWSm.get_aebOnff_cdn());
  aeb_out->mutable_fcwsm()->set_psv_cdn(FCWSm.get_psv_cdn());
  aeb_out->mutable_fcwsm()->set_tmpfail_cdn(FCWSm.get_tmpfail_cdn());
  aeb_out->mutable_fcwsm()->set_factive_cdn(FCWSm.get_frwrdactv_cdn());
  aeb_out->mutable_fcwsm()->set_bactive_cdn(FCWSm.get_bckwrdactv_cdn());
  aeb_out->mutable_fcwsm()->set_stdby_cdn(FCWSm.get_stdby_cdn());
  aeb_out->mutable_fcwsm()->set_st(static_cast<uint32_t>(FCWSm.get_aeb_st()));
  aeb_out->mutable_fcwsm()->set_sys_st(static_cast<uint32_t>(FCWSm.get_fcw_sys_st()));

  aeb_out->mutable_aebrearsm()->set_off_cdn(aebrearsm.get_off_cdn());
  aeb_out->mutable_aebrearsm()->set_stdby_cdn(aebrearsm.get_stdby_cdn());
  aeb_out->mutable_aebrearsm()->set_psv_cdn(aebrearsm.get_psv_cdn());
  aeb_out->mutable_aebrearsm()->set_psv_cdn_bit(aebrearsm.get_psv_cdn_bit());
  aeb_out->mutable_aebrearsm()->set_fail_cdn(aebrearsm.get_fail_cdn());
  aeb_out->mutable_aebrearsm()->set_active_cdn(aebrearsm.get_act_cdn());
  aeb_out->mutable_aebrearsm()->set_sm_state(static_cast<uint32_t>(aebrearsm.get_state()));

  aeb_out->mutable_funcsuppress()->set_aeb_suppress(aeb_suppress);
  aeb_out->mutable_funcsuppress()->set_fcw_suppress(fcw_suppress);
  aeb_out->mutable_funcsuppress()->set_aebrear_suppress(aebrear_suppress);
  aeb_out->mutable_funcsuppress()->set_fcwrear_suppress(fcwrear_suppress);

  aeb_out->mutable_aebdiag()->set_fctstopicstate(static_cast<uint32_t>(ArbState));
  aeb_out->mutable_aebdiag()->set_aebtopicstate(static_cast<uint32_t>(AebState));
  aeb_out->mutable_aebdiag()->set_fcwtopicstate(static_cast<uint32_t>(FcwState));
  aeb_out->mutable_aebdiag()->set_topicloss(Arb_TopicLoss & 0x003FF85D);
  aeb_out->mutable_aebdiag()->set_topicnoinit(Arb_TopicNoInit & 0x003FF85D);
  aeb_out->mutable_aebdiag()->set_aebfaultst(static_cast<uint32_t>(gAEBFaultSt));
  aeb_out->mutable_aebdiag()->set_fcwfaultst(static_cast<uint32_t>(gFCWFaultSt));
  aeb_out->mutable_aebdiag()->set_aebfimindex(static_cast<uint32_t>(AEB_FIMnum));
  aeb_out->mutable_aebdiag()->set_fcwfimindex(static_cast<uint32_t>(FCW_FIMnum));

  aeb_out->mutable_aebdiag()->set_aebrearfaultst(static_cast<uint32_t>(gRearAEBFaultSt));
  aeb_out->mutable_aebdiag()->set_aebrearfimindex(static_cast<uint32_t>(RearAEB_FIMnum));

  aeb_out->mutable_aebdiag()->clear_aebfault();
  aeb_out->mutable_aebdiag()->clear_fcwfault();
  aeb_out->mutable_aebdiag()->clear_aebrearfault();
  for (size_t i = 0; i < DIAG_FIM_MAX_MASK_NUM; i++) {
    aeb_out->mutable_aebdiag()->add_aebfault(static_cast<uint32_t>(gAEBFimByte[i]));
    aeb_out->mutable_aebdiag()->add_fcwfault(static_cast<uint32_t>(gFCWFimByte[i]));
    aeb_out->mutable_aebdiag()->add_aebrearfault(static_cast<uint32_t>(gRearAEBFimByte[i]));
  }

  aeb_out->mutable_aebdiag()->set_fwfailsafe(static_cast<uint32_t>(gFWfailsafe.high));
  aeb_out->mutable_aebdiag()->set_fnfailsafe(static_cast<uint32_t>(gFNfailsafe.high));
  aeb_out->mutable_aebdiag()->set_lidarfailsafe(static_cast<uint32_t>(gLidarfailsafe.high));
  aeb_out->mutable_aebdiag()->set_rearfailsafe(static_cast<uint32_t>(gRearfailsafe.high));
/*   aeb_out->mutable_aebdiag()->set_aebfaultage(aeb_fault_age);
  aeb_out->mutable_aebdiag()->set_aebrearfaultage(aebrear_fault_age);
  aeb_out->mutable_aebdiag()->clear_topiclosscnt();
  for(size_t i = 0; i < Topic_MaxNum; i++){
    aeb_out->mutable_aebdiag()->add_topiclosscnt(static_cast<uint32_t>(Topic[i].FltCntr));
  } */

  aeb_out->mutable_aebmode()->set_rearenable(kAebRearEnable);
  aeb_out->mutable_aebmode()->set_shadowmode(k_AEBShadowMode_active);
  aeb_out->mutable_aebmode()->set_shadowmodesoft(kAebShadowModeSoft);
  aeb_out->mutable_aebmode()->set_hilmode(kAebHilMode);

	aeb_out->mutable_aesccrcandi()->set_id(aes_candidate.AESCCR1_Candi_.u8_ID);
	aeb_out->mutable_aesccrcandi()->set_vid(aes_candidate.AESCCR1_Candi_.u8_VID);
	aeb_out->mutable_aesccrcandi()->set_range(aes_candidate.AESCCR1_Candi_.f4_range);
	aeb_out->mutable_aesccrcandi()->set_rangerate(aes_candidate.AESCCR1_Candi_.f4_rangerate);
	aeb_out->mutable_aesccrcandi()->set_ttc(aes_candidate.AESCCR1_Candi_.f4_TTC);
	aeb_out->mutable_aesccrcandi()->set_ttb_tt(aes_candidate.AESCCR1_Candi_.TTB.tt);
	aeb_out->mutable_aesccrcandi()->set_ttb_valid(aes_candidate.AESCCR1_Candi_.TTB.isvalid);
	aeb_out->mutable_aesccrcandi()->set_ttt_left_tt(aes_candidate.AESCCR1_Candi_.TTT_left.tt);
	aeb_out->mutable_aesccrcandi()->set_ttt_left_valid(aes_candidate.AESCCR1_Candi_.TTT_left.isvalid);
	aeb_out->mutable_aesccrcandi()->set_ttt_right_tt(aes_candidate.AESCCR1_Candi_.TTT_right.tt);
	aeb_out->mutable_aesccrcandi()->set_ttt_right_valid(aes_candidate.AESCCR1_Candi_.TTT_right.isvalid);
	aeb_out->mutable_aesccrcandi()->set_closeleft_posx(aes_candidate.AESCCR1_Candi_.close_left.pos_x);
	aeb_out->mutable_aesccrcandi()->set_closeleft_posy(aes_candidate.AESCCR1_Candi_.close_left.pos_y);
	aeb_out->mutable_aesccrcandi()->set_closeleft_curx(aes_candidate.AESCCR1_Candi_.close_left.cur_x);
	aeb_out->mutable_aesccrcandi()->set_closeleft_cury(aes_candidate.AESCCR1_Candi_.close_left.cur_y);
	aeb_out->mutable_aesccrcandi()->set_closeleft_latest(aes_candidate.AESCCR1_Candi_.close_left.lat_est);
	aeb_out->mutable_aesccrcandi()->set_closeright_posx(aes_candidate.AESCCR1_Candi_.close_right.pos_x);
	aeb_out->mutable_aesccrcandi()->set_closeright_posy(aes_candidate.AESCCR1_Candi_.close_right.pos_y);
	aeb_out->mutable_aesccrcandi()->set_closeright_curx(aes_candidate.AESCCR1_Candi_.close_right.cur_x);
	aeb_out->mutable_aesccrcandi()->set_closeright_cury(aes_candidate.AESCCR1_Candi_.close_right.cur_y);
	aeb_out->mutable_aesccrcandi()->set_closeright_latest(aes_candidate.AESCCR1_Candi_.close_right.lat_est);
	aeb_out->mutable_aesccrcandi()->set_remoteleft_posx(aes_candidate.AESCCR1_Candi_.remote_left.pos_x);
	aeb_out->mutable_aesccrcandi()->set_remoteleft_posy(aes_candidate.AESCCR1_Candi_.remote_left.pos_y);
	aeb_out->mutable_aesccrcandi()->set_remoteleft_curx(aes_candidate.AESCCR1_Candi_.remote_left.cur_x);
	aeb_out->mutable_aesccrcandi()->set_remoteleft_cury(aes_candidate.AESCCR1_Candi_.remote_left.cur_y);
	aeb_out->mutable_aesccrcandi()->set_remoteleft_latest(aes_candidate.AESCCR1_Candi_.remote_left.lat_est);
	aeb_out->mutable_aesccrcandi()->set_remoteright_posx(aes_candidate.AESCCR1_Candi_.remote_right.pos_x);
	aeb_out->mutable_aesccrcandi()->set_remoteright_posy(aes_candidate.AESCCR1_Candi_.remote_right.pos_y);
	aeb_out->mutable_aesccrcandi()->set_remoteright_curx(aes_candidate.AESCCR1_Candi_.remote_right.cur_x);
	aeb_out->mutable_aesccrcandi()->set_remoteright_cury(aes_candidate.AESCCR1_Candi_.remote_right.cur_y);
	aeb_out->mutable_aesccrcandi()->set_remoteright_latest(aes_candidate.AESCCR1_Candi_.remote_right.lat_est);
	aeb_out->mutable_aesccrcandi()->set_center_posx(aes_candidate.AESCCR1_Candi_.center_point.pos_x);
	aeb_out->mutable_aesccrcandi()->set_center_posy(aes_candidate.AESCCR1_Candi_.center_point.pos_y);
	aeb_out->mutable_aesccrcandi()->set_center_curx(aes_candidate.AESCCR1_Candi_.center_point.cur_x);
	aeb_out->mutable_aesccrcandi()->set_center_cury(aes_candidate.AESCCR1_Candi_.center_point.cur_y);
	aeb_out->mutable_aesccrcandi()->set_center_latest(aes_candidate.AESCCR1_Candi_.center_point.lat_est);
	aeb_out->mutable_aesccrcandi()->set_longpos(aes_candidate.AESCCR1_Candi_.obj.motion.GetX());
	aeb_out->mutable_aesccrcandi()->set_latpos(aes_candidate.AESCCR1_Candi_.obj.motion.GetY());
	aeb_out->mutable_aesccrcandi()->set_xolc(aes_candidate.AESCCR1_Candi_.f4_XOLC);
	aeb_out->mutable_aesccrcandi()->set_xolc(aes_candidate.AESCCR1_Candi_.f4_latest);
	aeb_out->mutable_aesccrcandi()->set_closest_corner(aes_candidate.AESCCR1_Candi_.u8_closest_corner);
	aeb_out->mutable_aesccrcandi()->set_close_corner_est(aes_candidate.AESCCR1_Candi_.u8_closest_corner_estimate); 
	aeb_out->mutable_aesccrcandi()->set_inpath(aes_candidate.AESCCR1_Candi_.u1_Inpath); 
	aeb_out->mutable_aesccrcandi()->set_inpathcur(aes_candidate.AESCCR1_Candi_.u1_Inpath_Cur); 
	aeb_out->mutable_aesccrcandi()->set_inpathpre(aes_candidate.AESCCR1_Candi_.u1_Inpath_Pre); 
	aeb_out->mutable_aesccrcandi()->set_inpathage(aes_candidate.AESCCR1_Candi_.u8_Inpathage); 
	aeb_out->mutable_aesccrcandi()->set_inpathcheck(aes_candidate.AESCCR1_Candi_.u1_inpathagecheck); 
	aeb_out->mutable_aesccrcandi()->set_isfusion(aes_candidate.AESCCR1_Candi_.obj.IsAllFused()); 
	aeb_out->mutable_aesccrcandi()->set_isvision(aes_candidate.AESCCR1_Candi_.obj.IsVisionOnly()); 
	aeb_out->mutable_aesccrcandi()->set_isradar(aes_candidate.AESCCR1_Candi_.obj.IsRadarOnly()); 
	aeb_out->mutable_aesccrcandi()->set_toi(aes_candidate.AESCCR1_Candi_.u1_TOI); 
	aeb_out->mutable_aesccrcandi()->set_isoncoming(aes_candidate.AESCCR1_Candi_.u1_oncoming); 
	aeb_out->mutable_aesccrcandi()->set_aebconf(aes_candidate.AESCCR1_Candi_.u8_AEBconf); 
	aeb_out->mutable_aesccrcandi()->set_steerflag(aes_candidate.AESCCR1_Candi_.steer_flag); 
	aeb_out->mutable_aesccrcandi()->set_steerdirection(aes_candidate.AESCCR1_Candi_.steer_direction); 
	aeb_out->mutable_aesccrcandi()->mutable_ref_pos()->set_pos_x(0); 
	aeb_out->mutable_aesccrcandi()->mutable_ref_pos()->set_pos_y(0); 
	aeb_out->mutable_aesccrcandi()->mutable_ref_pos()->set_ref_character(0); 
	aeb_out->mutable_aesccrcandi()->mutable_ref_pos()->set_range(0); 
	aeb_out->mutable_aesccrcandi()->mutable_ref_pos()->set_heading(aes_candidate.AESCCR1_Candi_.obj.motion.GetHead()); 

	aeb_out->mutable_closeaestarget()->set_id(close_aes.u8_ID);
	aeb_out->mutable_closeaestarget()->set_vid(close_aes.u8_VID);
	aeb_out->mutable_closeaestarget()->set_range(close_aes.f4_range);
	aeb_out->mutable_closeaestarget()->set_rangerate(close_aes.f4_rangerate);
	aeb_out->mutable_closeaestarget()->set_ttc(close_aes.f4_TTC);
	aeb_out->mutable_closeaestarget()->set_ttb_tt(close_aes.TTB.tt);
	aeb_out->mutable_closeaestarget()->set_ttb_valid(close_aes.TTB.isvalid);
	aeb_out->mutable_closeaestarget()->set_ttt_left_tt(close_aes.TTT_left.tt);
	aeb_out->mutable_closeaestarget()->set_ttt_left_valid(close_aes.TTT_left.isvalid);
	aeb_out->mutable_closeaestarget()->set_ttt_right_tt(close_aes.TTT_right.tt);
	aeb_out->mutable_closeaestarget()->set_ttt_right_valid(close_aes.TTT_right.isvalid);
	aeb_out->mutable_closeaestarget()->set_closeleft_posx(close_aes.close_left.pos_x);
	aeb_out->mutable_closeaestarget()->set_closeleft_posy(close_aes.close_left.pos_y);
	aeb_out->mutable_closeaestarget()->set_closeleft_curx(close_aes.close_left.cur_x);
	aeb_out->mutable_closeaestarget()->set_closeleft_cury(close_aes.close_left.cur_y);
	aeb_out->mutable_closeaestarget()->set_closeleft_latest(close_aes.close_left.lat_est);
	aeb_out->mutable_closeaestarget()->set_closeright_posx(close_aes.close_right.pos_x);
	aeb_out->mutable_closeaestarget()->set_closeright_posy(close_aes.close_right.pos_y);
	aeb_out->mutable_closeaestarget()->set_closeright_curx(close_aes.close_right.cur_x);
	aeb_out->mutable_closeaestarget()->set_closeright_cury(close_aes.close_right.cur_y);
	aeb_out->mutable_closeaestarget()->set_closeright_latest(close_aes.close_right.lat_est);
	aeb_out->mutable_closeaestarget()->set_remoteleft_posx(close_aes.remote_left.pos_x);
	aeb_out->mutable_closeaestarget()->set_remoteleft_posy(close_aes.remote_left.pos_y);
	aeb_out->mutable_closeaestarget()->set_remoteleft_curx(close_aes.remote_left.cur_x);
	aeb_out->mutable_closeaestarget()->set_remoteleft_cury(close_aes.remote_left.cur_y);
	aeb_out->mutable_closeaestarget()->set_remoteleft_latest(close_aes.remote_left.lat_est);
	aeb_out->mutable_closeaestarget()->set_remoteright_posx(close_aes.remote_right.pos_x);
	aeb_out->mutable_closeaestarget()->set_remoteright_posy(close_aes.remote_right.pos_y);
	aeb_out->mutable_closeaestarget()->set_remoteright_curx(close_aes.remote_right.cur_x);
	aeb_out->mutable_closeaestarget()->set_remoteright_cury(close_aes.remote_right.cur_y);
	aeb_out->mutable_closeaestarget()->set_remoteright_latest(close_aes.remote_right.lat_est);
	aeb_out->mutable_closeaestarget()->set_center_posx(close_aes.center_point.pos_x);
	aeb_out->mutable_closeaestarget()->set_center_posy(close_aes.center_point.pos_y);
	aeb_out->mutable_closeaestarget()->set_center_curx(close_aes.center_point.cur_x);
	aeb_out->mutable_closeaestarget()->set_center_cury(close_aes.center_point.cur_y);
	aeb_out->mutable_closeaestarget()->set_center_latest(close_aes.center_point.lat_est);
	aeb_out->mutable_closeaestarget()->set_longpos(close_aes.obj.motion.GetX());
	aeb_out->mutable_closeaestarget()->set_latpos(close_aes.obj.motion.GetY());
	aeb_out->mutable_closeaestarget()->set_xolc(close_aes.f4_XOLC);
	aeb_out->mutable_closeaestarget()->set_xolc(close_aes.f4_latest);
	aeb_out->mutable_closeaestarget()->set_closest_corner(close_aes.u8_closest_corner);
	aeb_out->mutable_closeaestarget()->set_close_corner_est(close_aes.u8_closest_corner_estimate); 
	aeb_out->mutable_closeaestarget()->set_inpath(close_aes.u1_Inpath); 
	aeb_out->mutable_closeaestarget()->set_inpathcur(close_aes.u1_Inpath_Cur); 
	aeb_out->mutable_closeaestarget()->set_inpathpre(close_aes.u1_Inpath_Pre); 
	aeb_out->mutable_closeaestarget()->set_inpathage(close_aes.u8_Inpathage); 
	aeb_out->mutable_closeaestarget()->set_inpathcheck(close_aes.u1_inpathagecheck); 
	aeb_out->mutable_closeaestarget()->set_isfusion(close_aes.obj.IsAllFused()); 
	aeb_out->mutable_closeaestarget()->set_isvision(close_aes.obj.IsVisionOnly()); 
	aeb_out->mutable_closeaestarget()->set_isradar(close_aes.obj.IsRadarOnly()); 
	aeb_out->mutable_closeaestarget()->set_toi(close_aes.u1_TOI); 
	aeb_out->mutable_closeaestarget()->set_isoncoming(close_aes.u1_oncoming); 
	aeb_out->mutable_closeaestarget()->set_aebconf(close_aes.u8_AEBconf); 
	aeb_out->mutable_closeaestarget()->set_steerflag(close_aes.steer_flag); 
	aeb_out->mutable_closeaestarget()->set_steerdirection(close_aes.steer_direction); 
	aeb_out->mutable_closeaestarget()->mutable_ref_pos()->set_pos_x(0); 
	aeb_out->mutable_closeaestarget()->mutable_ref_pos()->set_pos_y(0); 
	aeb_out->mutable_closeaestarget()->mutable_ref_pos()->set_ref_character(0); 
	aeb_out->mutable_closeaestarget()->mutable_ref_pos()->set_range(0); 
	aeb_out->mutable_closeaestarget()->mutable_ref_pos()->set_heading(close_aes.obj.motion.GetHead()); 

  aeb_out->mutable_aebreserved()->set_aeb_reserved_1(static_cast<double>(drimonitor.input_.drive_mode));

  return true;
}

}  // namespace ad
}  // namespace nio
