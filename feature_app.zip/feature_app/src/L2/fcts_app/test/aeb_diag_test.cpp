#include <gtest/gtest.h>
#include <iostream>
#include "aeb_main.h"
#include "failsafe_encoder.h"
#include "fcts_diag.h"
#include "fcts_input_adapter.h"
#include "fcts_main.h"
#include "fim_encoder.h"

namespace nio {
namespace ad {

extern std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>       arb_radar_data_;
extern std::vector<std::shared_ptr<nio::ad::messages::ForceSideFeatures>> arb_side_feature_;
extern std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>  arb_vision_objects_;
extern std::vector<std::shared_ptr<nio::ad::messages::VEH10ms>>           arb_vehicle_input_10_;
extern std::vector<std::shared_ptr<nio::ad::messages::VEH50ms>>           arb_vehicle_input_50_;
extern std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>     arb_road_detection_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYObfOutputs>>     arb_fusion_object_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEgoOutputs>>     arb_ehy_ego_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>     arb_ehy_evd_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>      arb_ehy_ha_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>     arb_ehy_lpp_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>     arb_ehy_rme_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>>     arb_ehy_tpp_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>>     arb_ehy_tsi_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>     arb_ehy_tse_;
extern std::vector<std::shared_ptr<nio::ad::messages::EHYTsrOutputs>>     arb_ehy_tsr_;
extern std::vector<std::shared_ptr<nio::ad::messages::FctOut>>            m_fctOut;
// extern std::vector<std::shared_ptr<nio::ad::messages::ParkingOut>>        m_parking_;

extern std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>     arb_fim_camera_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>        arb_fim_can_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>   arb_fim_sw_info;
extern std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>> arb_fim_can_fea_info;
extern std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>      arb_fim_power_info;
extern std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>> arb_fim_mcu_soc_info;
extern std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>      arb_fim_lidar_info;

extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_info;
extern std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> arb_failsafe_lidar_info;
extern std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_calib;

// fusion
class AEBdiagTest : public testing::Test {
 public:
  nio::ad::messages::VEH10ms veh10ms_tmp;
  nio::ad::messages::VEH50ms veh50ms_tmp;
  nio::ad::messages::FctOut  fct_out_tmp;
  // nio::ad::messages::ParkingOut               parking_data_tmp;
  nio::ad::messages::ADS                      ads_out_tmp;
  nio::ad::messages::ARBOut                   arb_out_tmp;
  nio::ad::messages::debug::AEBDebugOut       aeb_debug_out_tmp;
  std::shared_ptr<nio::ad::messages::VEH10ms> veh10ms_tmp_ptr =
    std::make_shared<nio::ad::messages::VEH10ms>(veh10ms_tmp);
  std::shared_ptr<nio::ad::messages::VEH50ms> veh50ms_tmp_ptr =
    std::make_shared<nio::ad::messages::VEH50ms>(veh50ms_tmp);
  std::shared_ptr<nio::ad::messages::FctOut> fct_out_tmp_ptr = std::make_shared<nio::ad::messages::FctOut>(fct_out_tmp);
  std::shared_ptr<nio::ad::messages::ADS>    ads_out_tmp_ptr = std::make_shared<nio::ad::messages::ADS>(ads_out_tmp);
  std::shared_ptr<nio::ad::messages::ARBOut> arb_out_tmp_ptr = std::make_shared<nio::ad::messages::ARBOut>(arb_out_tmp);
  std::shared_ptr<nio::ad::messages::debug::AEBDebugOut> aeb_debug_out_tmp_ptr =
    std::make_shared<nio::ad::messages::debug::AEBDebugOut>(aeb_debug_out_tmp);

  nio::ad::messages::CameraFimInfo           camera_fim_info_tmp;
  nio::ad::messages::FimCanInfo              can_fim_info_tmp;
  nio::ad::messages::FimSoftwareInfo         sw_fim_info_tmp;
  nio::ad::messages::CanFeatureFimInfo       fim_can_fea_info_tmp;
  nio::ad::messages::PowerFimInfo            fim_power_info_tmp;
  nio::ad::messages::McuSystemFimInfo        fim_mcu_sys_info_tmp;
  nio::ad::messages::MCUWithSOCFimInfo       fim_mcu_soc_info_tmp;
  nio::ad::messages::LidarFimInfo            fim_lidar_info_tmp;
  nio::ad::messages::PerceptionFimInfo       fim_perception_info_tmp;
  nio::ad::messages::FailSafeDetection       failsafe_vision_info_tmp;
  nio::ad::messages::Lidar_FailSafeDetection failsafe_lidar_info_tmp;

  std::shared_ptr<nio::ad::messages::CameraFimInfo> camera_fim_info_ptr =
    std::make_shared<nio::ad::messages::CameraFimInfo>(camera_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimCanInfo> can_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimCanInfo>(can_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::FimSoftwareInfo> sw_fim_info_ptr =
    std::make_shared<nio::ad::messages::FimSoftwareInfo>(sw_fim_info_tmp);
  std::shared_ptr<nio::ad::messages::CanFeatureFimInfo> fim_can_fea_info_ptr =
    std::make_shared<nio::ad::messages::CanFeatureFimInfo>(fim_can_fea_info_tmp);
  std::shared_ptr<nio::ad::messages::PowerFimInfo> fim_power_info_ptr =
    std::make_shared<nio::ad::messages::PowerFimInfo>(fim_power_info_tmp);
  std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo> fim_mcu_soc_info_ptr =
    std::make_shared<nio::ad::messages::MCUWithSOCFimInfo>(fim_mcu_soc_info_tmp);
  std::shared_ptr<nio::ad::messages::LidarFimInfo> fim_lidar_info_ptr =
    std::make_shared<nio::ad::messages::LidarFimInfo>(fim_lidar_info_tmp);
  std::shared_ptr<nio::ad::messages::McuSystemFimInfo> fim_mcu_sys_info_ptr =
    std::make_shared<nio::ad::messages::McuSystemFimInfo>(fim_mcu_sys_info_tmp);
  std::shared_ptr<nio::ad::messages::PerceptionFimInfo> fim_perception_info_ptr =
    std::make_shared<nio::ad::messages::PerceptionFimInfo>(fim_perception_info_tmp);
  std::shared_ptr<nio::ad::messages::FailSafeDetection> failsafe_vision_info_ptr =
    std::make_shared<nio::ad::messages::FailSafeDetection>(failsafe_vision_info_tmp);
  std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection> failsafe_lidar_info_ptr =
    std::make_shared<nio::ad::messages::Lidar_FailSafeDetection>(failsafe_lidar_info_tmp);

  void gTest_main() {
    arb_vehicle_input_10_.push_back(veh10ms_tmp_ptr);
    arb_vehicle_input_50_.push_back(veh50ms_tmp_ptr);
    m_fctOut.push_back(fct_out_tmp_ptr);
    arb_diag_main(camera_fim_info_ptr, can_fim_info_ptr, sw_fim_info_ptr, fim_can_fea_info_ptr, fim_power_info_ptr,
                  fim_mcu_sys_info_ptr, fim_mcu_soc_info_ptr, fim_lidar_info_ptr, fim_perception_info_ptr,
                  failsafe_vision_info_ptr, failsafe_lidar_info_ptr);
    aeb_main();
    // arb_main(*m_latestVeh10ms, *m_latestVeh50ms, *m_latestFctOut, m_parking_data_, *ads, arb_sin,
    // &arb_input_adapter_,
    //            &aeb_output_pub_, Arb_TopicNoInit, Arb_TopicLoss);
  }

 protected:
  virtual void SetUp() {

    // Set init state
    veh10ms_tmp.Clear();
    veh50ms_tmp.Clear();
    fct_out_tmp.Clear();
    ads_out_tmp.Clear();
    arb_out_tmp.Clear();
    aeb_debug_out_tmp.Clear();
    // parking_data_tmp.Clear();

    camera_fim_info_tmp.Clear();
    can_fim_info_tmp.Clear();
    sw_fim_info_tmp.Clear();
    fim_can_fea_info_tmp.Clear();
    fim_power_info_tmp.Clear();
    fim_mcu_soc_info_tmp.Clear();
    fim_lidar_info_tmp.Clear();
  }

  virtual void TearDown() {
    //
  }
};

TEST_F(AEBdiagTest, failsafe) {
  failsafe_vision_info_ptr->mutable_failsafe_fw()->set_fs_rain(3);
  arb_failsafe_vision_info.push_back(failsafe_vision_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFWfailsafe.high is : " << (int)gFWfailsafe.high << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  failsafe_vision_info_ptr->mutable_failsafe_fw()->set_fs_rain(0);
  arb_failsafe_vision_info.push_back(failsafe_vision_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFWfailsafe.high is : " << (int)gFWfailsafe.high << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  failsafe_vision_info_ptr->mutable_failsafe_fn()->set_fs_snow(3);
  arb_failsafe_vision_info.push_back(failsafe_vision_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFNfailsafe.high is : " << (int)gFNfailsafe.high << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  failsafe_vision_info_ptr->mutable_failsafe_fn()->set_fs_snow(1);
  arb_failsafe_vision_info.push_back(failsafe_vision_info_ptr);
  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrfailsts_error(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFNfailsafe.none is : " << (int)gFNfailsafe.none << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  failsafe_vision_info_ptr->mutable_failsafe_fn()->set_fs_snow(0);
  arb_failsafe_vision_info.push_back(failsafe_vision_info_ptr);
  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrfailsts_error(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gFNfailsafe.none is : " << (int)gFNfailsafe.none << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  failsafe_lidar_info_ptr->mutable_failsafe()->set_fs_rain_snow(3);
  arb_failsafe_lidar_info.push_back(failsafe_lidar_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gLidarfailsafe.high is : " << (int)gLidarfailsafe.high << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  failsafe_lidar_info_ptr->mutable_failsafe()->set_fs_rain_snow(0);
  arb_failsafe_lidar_info.push_back(failsafe_lidar_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "gLidarfailsafe.high is : " << (int)gLidarfailsafe.high << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, SCMFault) {
  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrfailsts_error(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrfailsts_error(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrcalsts_notcalibrated(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steeragsnsrcalsts_notcalibrated(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steerwhlagandspdvalid_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_scm_feature_fim_info()->set_fim_chs1_scm_steerwhlagandspdvalid_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  can_fim_info_ptr->mutable_scm_fim_info()->set_fim_chs1_scm_can_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  can_fim_info_ptr->mutable_scm_fim_info()->set_fim_chs1_scm_can_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, RADFault) {
  can_fim_info_ptr->mutable_radfc_fim_info()->set_fim_rad_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  can_fim_info_ptr->mutable_radfc_fim_info()->set_fim_rad_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, BCUFault) {
  can_fim_info_ptr->mutable_bcu_fim_info()->set_fim_chs1_bcu_can_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  can_fim_info_ptr->mutable_bcu_fim_info()->set_fim_chs1_bcu_can_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  can_fim_info_ptr->mutable_bcu_fim_info()->set_fim_chs2_bcu_can_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  can_fim_info_ptr->mutable_bcu_fim_info()->set_fim_chs2_bcu_can_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_vehspdsts_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_vehspdsts_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_brkpressvalid_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_brkpressvalid_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_brkpedlsts_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcu_feature_fim_info()->set_fim_chs1_bcu_brkpedlsts_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, BCMFault) {
  fim_can_fea_info_ptr->mutable_bcm_feature_fim_info()->set_fim_chs1_bcm_seatoccpfrntlests_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcm_feature_fim_info()->set_fim_chs1_bcm_seatoccpfrntlests_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  can_fim_info_ptr->mutable_bcm_fim_info()->set_fim_chs1_bcm_can_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  can_fim_info_ptr->mutable_bcm_fim_info()->set_fim_chs1_bcm_can_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcm_feature_fim_info()->set_fim_chs1_bcm_seatoccpfrntlefail_failure(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_bcm_feature_fim_info()->set_fim_chs1_bcm_seatoccpfrntlefail_failure(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, ACMFault) {
  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_yawratevalsts_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  std::cout << "........................................................" << std::endl;
  std::cout << "fim_encoder_byte is : " << (int)Arb_fim_diag.fim_encoder_byte[1] << std::endl;
  std::cout << "gAEBFaultSt is : " << (int)gAEBFaultSt << std::endl;
  std::cout << "gAEBFimByte is : " << (int)gAEBFimByte[1] << std::endl;
  std::cout << "........................................................" << std::endl;
  std::cout << "........................................................" << std::endl;
  std::cout << "AEB_FIMnum is : " << (int)AEB_FIMnum << std::endl;
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_yawratevalsts_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_latavalsts_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_latavalsts_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_lgtavalsts_invalid(true);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  fim_can_fea_info_ptr->mutable_acm_feature_fim_info()->set_fim_chs1_acm_lgtavalsts_invalid(false);
  arb_fim_can_fea_info.push_back(fim_can_fea_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  can_fim_info_ptr->mutable_acm_fim_info()->set_fim_chs1_acm_can_error(true);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  can_fim_info_ptr->mutable_acm_fim_info()->set_fim_chs1_acm_can_error(false);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}

TEST_F(AEBdiagTest, CameraFault) {

  // f120 physical linkage error
  camera_fim_info_ptr->mutable_fw_adc_fim_info()->set_fim_fwphysicallinkage_error(true);
  arb_fim_camera_info.push_back(camera_fim_info_ptr);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  arb_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  camera_fim_info_ptr->mutable_fw_adc_fim_info()->set_fim_fwphysicallinkage_error(false);
  arb_fim_camera_info.push_back(camera_fim_info_ptr);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  arb_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);

  // f30 physical linkage error
  camera_fim_info_ptr->mutable_fn_adc_fim_info()->set_fim_fnphysicallinkage_error(true);
  arb_fim_camera_info.push_back(camera_fim_info_ptr);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  arb_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt != FimFault_e::NoFault);

  camera_fim_info_ptr->mutable_fn_adc_fim_info()->set_fim_fnphysicallinkage_error(false);
  arb_fim_camera_info.push_back(camera_fim_info_ptr);
  arb_fim_can_info.push_back(can_fim_info_ptr);
  arb_fim_sw_info.push_back(sw_fim_info_ptr);
  gTest_main();
  EXPECT_TRUE(gAEBFaultSt == FimFault_e::NoFault);
}
}  // namespace ad
}  // namespace nio
