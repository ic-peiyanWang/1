#include <gtest/gtest.h>
#include "aeb_gof.h"

namespace nio{
namespace ad{

//fusion
class GofFusionTest : public testing::Test{
    protected:
        GofFusionTest(){}
        ~GofFusionTest(){}
        virtual void SetUp(){ 
            temp_vel.x = 8.0;
            temp_vel.y = 0.0;
            temp_vel.z = 0.0;
            arb_sin->fused_obj.at(0).classification.SetClass(feature::ehy::ClassEnum::kClassPedestrian);
            arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
            arb_sin->fused_obj.at(0).fusion_sup.fusion = feature::ehy::kFusionRadarVision;
            arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kMature);
            arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8;
            arb_sin->fused_obj.at(0).fusion_sup.age = 10;
        }
        virtual void TearDown(){
            arb_sin->fused_obj.at(0).clear();
        }
        GenObjectFilter UnitTest_Gof;
        feature::math::Vector3f temp_vel;
};

TEST_F(GofFusionTest, SmokeTest){
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == true);
    EXPECT_TRUE(fused_obj_filtered.at(1).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.classification.IsPedestrian() == true);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 8.0);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.fusion_sup.fusion == 3);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.valid_status() == 2);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.age == 10);
}

TEST_F(GofFusionTest, VelTest){
    temp_vel.x = 18.0;
    arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 18.0);
}

TEST_F(GofFusionTest, ValidTest){
    arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kInvalid);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

TEST_F(GofFusionTest, ConfiTest){
    arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.4;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

TEST_F(GofFusionTest, AgeTest){
    arb_sin->fused_obj.at(0).fusion_sup.age = 1;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

//vison only
class GofVisionTest : public testing::Test{
    protected:
        GofVisionTest(){}
        ~GofVisionTest(){}
        virtual void SetUp(){ 
            temp_vel.x = 8.0;
            temp_vel.y = 0.0;
            temp_vel.z = 0.0;
            arb_sin->fused_obj.at(0).classification.SetClass(feature::ehy::ClassEnum::kClassPedestrian);
            arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
            arb_sin->fused_obj.at(0).fusion_sup.fusion = feature::ehy::kFusionMaskVision;
            arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kMature);
            arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 3;
            arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8;
            arb_sin->fused_obj.at(0).fusion_sup.age = 10;
        }
        virtual void TearDown(){
            arb_sin->fused_obj.at(0).clear();
        }
        GenObjectFilter UnitTest_Gof;
        feature::math::Vector3f temp_vel;
};

TEST_F(GofVisionTest, SmokeTest){
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == true);
    EXPECT_TRUE(fused_obj_filtered.at(1).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.classification.IsPedestrian() == true);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 8.0);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.fusion_sup.fusion == 2);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.valid_status() == 2);
    //EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 3);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.age = 10);
}

TEST_F(GofVisionTest, VelTest){
    temp_vel.x = 18.0;
    arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 18.0);
}

TEST_F(GofVisionTest, ValidTest){
    arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kInvalid);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

/* TEST_F(GofVisionTest, FusedHisTest)
{
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 1);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).check_valid == false);
} */

TEST_F(GofVisionTest, ConfiTest){
    arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.4;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

TEST_F(GofVisionTest, AgeTest){
    arb_sin->fused_obj.at(0).fusion_sup.age = 1;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

//radar only
class GofRadarTest : public testing::Test{
    protected:
        GofRadarTest(){}
        ~GofRadarTest(){}
        virtual void SetUp(){
            temp_vel.x = 8.0;
            temp_vel.y = 0.0;
            temp_vel.z = 0.0;
            arb_sin->fused_obj.at(0).classification.SetClass(feature::ehy::ClassEnum::kClassPedestrian);
            arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
            arb_sin->fused_obj.at(0).fusion_sup.fusion = feature::ehy::kFusionMaskRadar;
            arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kMature);
            arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 3;
            arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8;
            arb_sin->fused_obj.at(0).fusion_sup.age = 10;
        }
        virtual void TearDown(){
            arb_sin->fused_obj.at(0).clear();
        }
        GenObjectFilter UnitTest_Gof;
        feature::math::Vector3f temp_vel;
};

TEST_F(GofRadarTest, SmokeTest){
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == true);
    EXPECT_TRUE(fused_obj_filtered.at(1).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.classification.IsPedestrian() == true);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 8.0);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.fusion_sup.fusion == 1);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.valid_status() == 2);
    //EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 3);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.8);
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.age = 10);
}

TEST_F(GofRadarTest, VelTest){
    temp_vel.x = 18.0;
    arb_sin->fused_obj.at(0).motion.SetVel(temp_vel);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
    EXPECT_TRUE(fused_obj_filtered.at(0).raw_data.motion.GetVx() == 18.0);
}

TEST_F(GofRadarTest, ValidTest){
    arb_sin->fused_obj.at(0).set_valid_status(feature::ehy::ObjValidStatus::kInvalid);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

/* TEST_F(GofRadarTest, FusedHisTest){
    EXPECT_TRUE(arb_sin->fused_obj.at(0).fusion_sup.fusion_hist = 1);
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).check_valid == false);
} */

TEST_F(GofRadarTest, ConfiTest){
    arb_sin->fused_obj.at(0).fusion_sup.confidence = 0.4;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

TEST_F(GofRadarTest, AgeTest){
    arb_sin->fused_obj.at(0).fusion_sup.age = 1;
    UnitTest_Gof.MainFunction();
    EXPECT_TRUE(fused_obj_filtered.at(0).gofcheck.check_valid == false);
}

} //namespace ad
} //namespace nio