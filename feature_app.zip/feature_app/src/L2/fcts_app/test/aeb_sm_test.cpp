#include <gtest/gtest.h>
// #define private   public
// #define protected public
#include "aeb_type.h"

namespace nio{
namespace ad{

class RearSmTest : public testing::Test{

	protected:
        RearSmTest() {}
        ~RearSmTest() {}
        virtual void SetUp() {}

        virtual void TearDown(){
			rearsm_test_.set_off_cdn(false);
			rearsm_test_.set_stdby_cdn(false);
			rearsm_test_.set_psv_cdn(false);
			rearsm_test_.set_fail_cdn(false);
			rearsm_test_.set_act_cdn(false);
			rearsm_test_.set_sm_state(RearSmSt::kOff);
		}

        RearSm rearsm_test_;
};

TEST_F(RearSmTest, Init){
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest, Off2Off){
	rearsm_test_.set_sm_state(RearSmSt::kOff);
	rearsm_test_.set_off_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest, Off2Fail){
	rearsm_test_.set_sm_state(RearSmSt::kOff);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kFail);
}

TEST_F(RearSmTest, Off2Stdby){
	rearsm_test_.set_sm_state(RearSmSt::kOff);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kStandby);
}

TEST_F(RearSmTest, Stdby2Off){
	rearsm_test_.set_sm_state(RearSmSt::kOff);
	rearsm_test_.set_off_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest,Stdby2Fail){
	rearsm_test_.set_sm_state(RearSmSt::kStandby);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kFail);
}

TEST_F(RearSmTest, Stdby2Psv){
	rearsm_test_.set_sm_state(RearSmSt::kStandby);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kPassive);
}

TEST_F(RearSmTest, Stdby2Stdby){
	rearsm_test_.set_sm_state(RearSmSt::kStandby);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kStandby);
}

TEST_F(RearSmTest, Psv2Off){
	rearsm_test_.set_sm_state(RearSmSt::kPassive);
	rearsm_test_.set_off_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest, Psv2Fail){
	rearsm_test_.set_sm_state(RearSmSt::kPassive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kFail);
}

TEST_F(RearSmTest, Psv2Stdby){
	rearsm_test_.set_sm_state(RearSmSt::kPassive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kStandby);
}

TEST_F(RearSmTest, Psv2Act){
	rearsm_test_.set_sm_state(RearSmSt::kPassive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.set_act_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kActive);
}

TEST_F(RearSmTest, Psv2Psv){
	rearsm_test_.set_sm_state(RearSmSt::kPassive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.set_act_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kPassive);
}

TEST_F(RearSmTest, Fail2Off){
	rearsm_test_.set_sm_state(RearSmSt::kFail);
	rearsm_test_.set_off_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest, Fail2Fail){
	rearsm_test_.set_sm_state(RearSmSt::kFail);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kFail);
}

TEST_F(RearSmTest, Fail2Psv){
	rearsm_test_.set_sm_state(RearSmSt::kFail);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kPassive);
}

TEST_F(RearSmTest, Fail2Stdby){
	rearsm_test_.set_sm_state(RearSmSt::kFail);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kStandby);
}

TEST_F(RearSmTest, Act2Off){
	rearsm_test_.set_sm_state(RearSmSt::kActive);
	rearsm_test_.set_off_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kOff);
}

TEST_F(RearSmTest, Act2Fail){
	rearsm_test_.set_sm_state(RearSmSt::kActive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kFail);
}

TEST_F(RearSmTest, Act2Stdby){
	rearsm_test_.set_sm_state(RearSmSt::kActive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kStandby);
}

TEST_F(RearSmTest, Act2Act){
	rearsm_test_.set_sm_state(RearSmSt::kActive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.set_act_cdn(true);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kActive);
}

TEST_F(RearSmTest, Act2Psv){
	rearsm_test_.set_sm_state(RearSmSt::kActive);
	rearsm_test_.set_off_cdn(false);
	rearsm_test_.set_fail_cdn(false);
	rearsm_test_.set_psv_cdn(true);
	rearsm_test_.set_act_cdn(false);
	rearsm_test_.UpdateState();
	EXPECT_TRUE(rearsm_test_.get_state() == RearSmSt::kPassive);
}


#undef private
#undef protected

} //namespace ad
} //namespace nio