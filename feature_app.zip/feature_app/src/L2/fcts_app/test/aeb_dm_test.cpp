#include <gtest/gtest.h>
#include "aeb_dm.h"

namespace nio{
namespace ad{

class DmTest : public testing::Test{
    protected:
        DmTest(){}
        ~DmTest(){}
        virtual void SetUp(){}
        virtual void TearDown(){
            arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts      = BrkPdlSts_e::NotPrssd; //brake pedal
            arb_sin->vehicleinfo_in.brakesys.BrkPdl.Trvl            = 0.0; //brake pedal pos
            arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn     = 0.0; //gas pedal
            arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate = 0.0; //gas pedal grad

            arb_sin->vehicleinfo_in.steersys.StrWhlAg               = 0.0; //steer angle
            arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd            = 0.0; //steer grad

            arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps = 0.0; //ego v
            arb_sin->vehicleinfo_in.vehicledynamic.LgtAmpss         = 0.0; //ego a
            arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps       = 0.0; //ego yawrate

            arb_sin->vehicleinfo_in.vehicledrive.TurnIndcrSwtSts    = TrnIndcrSwSt_e::Default; //turn light */

            arb_sin->vehicleinfo_in.vehiclept.Gear.ActGear          = 1; //1: Drive 2:Reverse 3:Parking
        }
        DriverMonitor UnitTest_Dm;
};

template<typename T1, typename T2>
static void SetValue(T1 &a, const T2 b){
    a = b;
}

TEST_F(DmTest, FdbSt5){
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd); //brake ped
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 5);
}

TEST_F(DmTest, FdbSt4){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 0.8); //gas pedal
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, -6.0); //gas grad
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 4);
}

TEST_F(DmTest, FdbSt3){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 2.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, -300.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 3);
}

TEST_F(DmTest, FdbSt2_1){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 92.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 2);
}

TEST_F(DmTest, FdbSt2_2){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 10.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, 300.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 2);
}

TEST_F(DmTest, FdbSt1_1){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 100.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 1);
}

TEST_F(DmTest, FdbSt1_2){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, 1200.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.feedbackstate, 1);
}

TEST_F(DmTest, ActSt3){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 7.5); //ego vx
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd, 800.0); //steer grad
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.activitystate, 3);
}

TEST_F(DmTest, ActSt2_1){
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAg, 200.0); //steer ang
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.activitystate, 2);
}

TEST_F(DmTest, ActSt2_2){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 10.0);
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd, 150.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.activitystate, 2);
}

TEST_F(DmTest, ActSt1){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 9.0);
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd, 40.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.activitystate, 1);
}

TEST_F(DmTest, FocSt4){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 23.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.LgtAmpss, 4.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 4);
}

/* TEST_F(DmTest, FocSt3){
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd);
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.Trvl, 55.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 7.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.LgtAmpss, -5.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 3);
} */

/* TEST_F(DmTest, FocSt2_1){
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd);
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.Trvl, 55.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 2);
} */

TEST_F(DmTest, FocSt2_2){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 35.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 80.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 2);
}

TEST_F(DmTest, FocSt2_3){
    SetValue(arb_sin->vehicleinfo_in.vehicledrive.TurnIndcrSwtSts, TrnIndcrSwSt_e::Left);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 20.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 2);
}

TEST_F(DmTest, FocSt1_1){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, 160.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 1);
}

TEST_F(DmTest, FocSt1_2){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, -200.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 1);
}

TEST_F(DmTest, FocSt1_3){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 0.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, -10.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 1);
}

TEST_F(DmTest, FocSt1_4){
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd, -120.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.focusstate, 1);
}

TEST_F(DmTest, SupZero){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 1.5);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0x00200000);
}

TEST_F(DmTest, AbortZero){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 0.3);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0x00200000);
}

TEST_F(DmTest, SupAct2){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 5.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAg, 200.0);//set act state 2
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0xFFA00000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0xFFA00000);
}

TEST_F(DmTest, SupAct3){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 7.5); //set act state 3
    SetValue(arb_sin->vehicleinfo_in.steersys.StrWhlAgSpd, 800.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0xFFA00000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0xFFA00000);
}

TEST_F(DmTest, SupFdb2){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 5.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 92.0); //set fdb state 2
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0xFF200000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0x1F200000);
}

TEST_F(DmTest, SupFdb1){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 5.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosn, 100.0); //set fdb state 1
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0xFF200000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0x1F200000);
}

TEST_F(DmTest, SupFdb5){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 5.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 1.0);
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd);//set fdb state 5
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit, 0x1C200000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit, 0x1C200000);
}

TEST_F(DmTest, SupCcftapVel){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 15.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0x00400000, 0x00400000);
}

TEST_F(DmTest, SupCcftapYawrate){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.YawRateRps, 0.05);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0x00400000, 0x00400000);
}

TEST_F(DmTest, SupBwdMinVel){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, -5.0);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0xFFE00000, 0xFFE00000);
}

TEST_F(DmTest, SupBwdMaxVel){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, -0.5);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0xFFE00000, 0xFFE00000);
}

TEST_F(DmTest, SupFwdMinVel){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 0.9);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0xFFE00000, 0xFFE00000);
}

TEST_F(DmTest, SupFwdMaxVel){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 45);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0x9FE00000, 0x9FE00000);
}

TEST_F(DmTest, SupGearR){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 1.5);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.Gear.ActGear, 2);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0xFFC00000, 0xFFC00000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit & 0xFFC00000, 0xFFC00000);
}

TEST_F(DmTest, SupGearN){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 1.5);
    SetValue(arb_sin->vehicleinfo_in.vehiclept.Gear.ActGear, 3);
    UnitTest_Dm.MainFunction();
    EXPECT_EQ(UnitTest_Dm.output_.suppressbit & 0xFFE00000, 0xFFE00000);
    EXPECT_EQ(UnitTest_Dm.output_.abortbit & 0xFFE00000, 0xFFE00000);
}

TEST_F(DmTest, Damp0){
    UnitTest_Dm.MainFunction();
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[1], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[2], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[3], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[4], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[5], 1.0);
}

TEST_F(DmTest,Damp1){
    SetValue(arb_sin->vehicleinfo_in.vehiclept.AccrPedal.ActPosnRate, 160.0); //set focus state 1
    UnitTest_Dm.MainFunction();
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[0], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[1], 0.85);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[2], 0.9);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[3], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[4], 0.9);
}

/* TEST_F(DmTest,Damp2){
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd); //set fo state 2
    UnitTest_Dm.MainFunction();
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[0], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[1], 0.5);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[2], 0.75);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[3], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[4], 0.8);
}

TEST_F(DmTest,Damp3){
    SetValue(arb_sin->vehicleinfo_in.brakesys.BrkPdl.BrkPedlSts, BrkPdlSts_e::Prssd);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 7.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.LgtAmpss, -5.0); //set focus state 3
    UnitTest_Dm.MainFunction();
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[0], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[1], 0.4);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[2], 0.65);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[3], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[4], 0.8);
} */

TEST_F(DmTest,Damp4){
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, 23.0);
    SetValue(arb_sin->vehicleinfo_in.vehicledynamic.LgtAmpss, 4.0); //set fo state 4
    UnitTest_Dm.MainFunction();
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[0], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[1], 0.4);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[2], 0.65);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[3], 1.0);
    EXPECT_FLOAT_EQ(UnitTest_Dm.output_.dampfactor[4], 0.6);
}

}// namespace ad
}// namespace nio




