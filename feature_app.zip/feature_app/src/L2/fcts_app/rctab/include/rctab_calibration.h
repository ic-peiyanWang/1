#ifndef RCTAB_CALIBRATION_H_
#define RCTAB_CALIBRATION_H_
#include <stdint.h>
//#include "ids_mil.h"
#include "asimov_compiler.h"

#ifndef CAL_VAR
#define CAL_VAR
#endif

extern CAL_VAR float EAEB_dstccc_predictext_after_v[64];
extern CAL_VAR float EARB_rctb_taraccel_accped_x[7];
extern CAL_VAR float EARB_rctb_taraccel_vehspd_y[5];
extern CAL_VAR float EARB_rctb_acctara_v[35];
extern CAL_VAR float EARB_rctb_timeduration_v[35];

#endif // RCTAB_CALIBRATION_H_