#ifndef RCTAB_TYPE_H_
#define RCTAB_TYPE_H_
#include <stdint.h>
#include "ehy_obf/object.h"
#include "ehy_math/nio_vmath.h"
#include "veh_in_type.h"


namespace nio
{
    namespace ad
    {
        struct RctabOutput {
            uint32_t RCTABrkSts = 0;
            uint32_t VLC_DriveOffReq = 0;
            float VLC_MaxJerkA = 0;
            float VLC_MinJerkA = 0;
            uint32_t VLC_Mode = 0;
            uint32_t VLC_ReqFct = 0;
            uint32_t VLC_ShutdownModReq = 0;
            float VLC_TarA = 0;
            uint32_t VLC_DecelToStopReq = 0;
            uint32_t BSD_hviReq = 0;
        };
    }     // namespace ad
} // namespace nio

#endif //RCTAB_TYPE_H_