#include <iostream>
#include <memory>
#include <array>
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "ehy_math/nio_vmath.h"
#include "fcts_input_adapter.h"
#include "rctab_type.h"

#ifndef RCTAB_TRANSLATION_
#define RCTAB_TRANSLATION_

namespace nio {
    namespace ad {
        

        class RCTAB_TRANS {
            public: 
            RCTAB_TRANS();

            void mainfunction(ARBSIN& arbsin);

            RctabOutput rcta_output;

            private:
            void updatecalibration();

            void translate_flag(ARBSIN& arbsin);

            bool hostReverse = 0;

            uint8_t rctb_vlc_req_lf = 0;
            uint8_t rctb_vlc_req = 0;
            float rctb_req_timer = 0;
            uint8_t rctb_active_loop = 0;

            feature::math::LinearInterpolator2D<float> threshold_rctb_acctara_;
            feature::math::LinearInterpolator2D<float> threshold_rctb_timedur_;
        };

        extern RCTAB_TRANS rctab_trans;
    }
}

#endif