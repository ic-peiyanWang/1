#include "rctab_calibration.h"
CAL_VAR float EARB_rctb_taraccel_accped_x[7] = {
0.0F, 0.5F, 1.0F, 2.0F, 5.0F, 10.0F, 15.0F
};
CAL_VAR float EARB_rctb_taraccel_vehspd_y[5] = {
1.33F, 2.22F, 2.78F, 3.33F, 4.17
};
CAL_VAR float EARB_rctb_acctara_v[35] = {
-1.5F, -1.5F, -1.0F, -0.5F, -0.3F, -0.3F, -0.3F,
-1.5F, -1.5F, -1.0F, -0.5F, -0.3F, -0.3F, -0.3F,
-1.5F, -1.5F, -1.0F, -0.5F, -0.3F, -0.3F, -0.3F,
-1.5F, -1.5F, -1.0F, -0.5F, -0.3F, -0.3F, -0.3F,
-1.5F, -1.5F, -1.0F, -0.5F, -0.3F, -0.3F, -0.3F
};
CAL_VAR float EARB_rctb_timeduration_v[35] = {
1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F,
1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F,
1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F,
1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F,
1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F
};