#include "rctab_translation.h"
#include "rctab_calibration.h"
#include "aeb_sin_struct.h"
#include "fcts_type.h"
#include "ehy_math/nio_vmath.h"
#include <iostream>

namespace nio {
namespace ad {
RCTAB_TRANS rctab_trans;

RCTAB_TRANS::RCTAB_TRANS() {}

void RCTAB_TRANS::updatecalibration() {
    size_t accelped_cal = sizeof(EARB_rctb_taraccel_accped_x) / sizeof(EARB_rctb_taraccel_accped_x[0]);

    size_t vehspd_cal = sizeof(EARB_rctb_taraccel_vehspd_y) / sizeof(EARB_rctb_taraccel_vehspd_y[0]);

    threshold_rctb_acctara_.init(EARB_rctb_taraccel_vehspd_y, EARB_rctb_taraccel_accped_x, EARB_rctb_acctara_v, vehspd_cal, accelped_cal);

    threshold_rctb_timedur_.init(EARB_rctb_taraccel_vehspd_y, EARB_rctb_taraccel_accped_x, EARB_rctb_timeduration_v, vehspd_cal, accelped_cal);
}

void RCTAB_TRANS::mainfunction(ARBSIN& arbsin) {
    updatecalibration();

    translate_flag(arbsin);
}

void RCTAB_TRANS::translate_flag(ARBSIN& arbsin) {
    hostReverse = ((arbsin.vehicleinfo_in.vehiclept.Gear.ActGear == 2) || (arbsin.vehicleinfo_in.vehiclept.Gear.ActGear == 0 && arbsin.vehicleinfo_in.vehicledynamic.VehSpd.VehMovgDir == VehMovDir_e::BackWard));

    rcta_output.BSD_hviReq = arb_sin->side_feature_input.bsd_haptic_req;

    rctb_vlc_req = arbsin.side_feature_input.rctb_vlc_req;

    if (rctb_vlc_req == 3 && rctb_vlc_req_lf != 3) {
      rctb_req_timer = threshold_rctb_timedur_.interpolate(arbsin.vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, arbsin.vehicleinfo_in.vehiclept.AccrPedal.ActPosn);

      rctb_active_loop = static_cast<uint8_t>(rctb_req_timer / 0.02);
    }

    if (rctb_active_loop > 0) {
      rcta_output.VLC_DriveOffReq    = 0;
      rcta_output.VLC_MaxJerkA       = 16;
      rcta_output.VLC_MinJerkA       = -16;
      rcta_output.VLC_Mode           = 3;
      rcta_output.VLC_ReqFct         = 3;
      rcta_output.VLC_ShutdownModReq = 0;
      rcta_output.VLC_TarA           = threshold_rctb_acctara_.interpolate(
        arbsin.vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps, arbsin.vehicleinfo_in.vehiclept.AccrPedal.ActPosn);
      if (arbsin.vehicleinfo_in.vehicledynamic.VehSpd.VehSpdmps <= 0.33) {
        rcta_output.VLC_DecelToStopReq = 1;
      } else {
        rcta_output.VLC_DecelToStopReq = 0;
      }
      rcta_output.RCTABrkSts = 2;
      rctb_active_loop                  = rctb_active_loop - 1;
    } else {
      rcta_output.VLC_DriveOffReq    = 0;
      rcta_output.VLC_MaxJerkA       = 0;
      rcta_output.VLC_MinJerkA       = 0;
      rcta_output.VLC_Mode           = 0;
      rcta_output.VLC_ReqFct         = 0;
      rcta_output.VLC_ShutdownModReq = 0;
      rcta_output.VLC_TarA           = 0;
      rcta_output.VLC_DecelToStopReq = 0;
      if (arbsin.vehicleinfo_in.vehicledrive.AdFunCfg.RCTABReq == static_cast<AdFunOnOff_e>(0)) {
        rcta_output.RCTABrkSts = 0;
      } else if (arbsin.vehicleinfo_in.vehicledrive.AdFunCfg.RCTABReq == static_cast<AdFunOnOff_e>(1)) {
        rcta_output.RCTABrkSts = 1;
      }

      rctb_active_loop = 0;
    }

    rctb_vlc_req_lf = arbsin.side_feature_input.rctb_vlc_req;
}

}
}