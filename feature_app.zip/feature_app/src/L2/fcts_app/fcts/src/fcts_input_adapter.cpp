#include "fcts_input_adapter.h"
#include <iostream>
#include "niodds/application/application.h"

namespace nio {
namespace ad {
ARBSIN  g_arb_sin;
ARBSIN* arb_sin = &g_arb_sin;

ARBInputAdapter arb_input_adapter_;

std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>>       arb_radar_data_;
std::vector<std::shared_ptr<nio::ad::messages::ForceSideFeatures>> arb_side_feature_;
std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>>  arb_vision_objects_;
std::vector<std::shared_ptr<nio::ad::messages::VEH10ms>>           arb_vehicle_input_10_;
std::vector<std::shared_ptr<nio::ad::messages::VEH50ms>>           arb_vehicle_input_50_;
std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>>     arb_road_detection_;
std::vector<std::shared_ptr<nio::ad::messages::EHYObfOutputs>>     arb_fusion_object_;
std::vector<std::shared_ptr<nio::ad::messages::EHYEgoOutputs>>     arb_ehy_ego_;
std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>>     arb_ehy_evd_;
std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>>      arb_ehy_ha_;
std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>>     arb_ehy_lpp_;
std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>>     arb_ehy_rme_;
std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>>     arb_ehy_tpp_;
std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>>     arb_ehy_tsi_;
std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>>     arb_ehy_tse_;
std::vector<std::shared_ptr<nio::ad::messages::EHYTsrOutputs>>     arb_ehy_tsr_;
std::vector<std::shared_ptr<nio::ad::messages::FctOut>>            m_fctOut;
std::vector<std::shared_ptr<nio::ad::messages::ParkingOut>>        m_parking_;

std::vector<std::shared_ptr<nio::ad::messages::CameraFimInfo>>     arb_fim_camera_info;
std::vector<std::shared_ptr<nio::ad::messages::FimCanInfo>>        arb_fim_can_info;
std::vector<std::shared_ptr<nio::ad::messages::FimSoftwareInfo>>   arb_fim_sw_info;
std::vector<std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>> arb_fim_can_fea_info;
std::vector<std::shared_ptr<nio::ad::messages::PowerFimInfo>>      arb_fim_power_info;
std::vector<std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>> arb_fim_mcu_soc_info;
std::vector<std::shared_ptr<nio::ad::messages::LidarFimInfo>>      arb_fim_lidar_info;
std::vector<std::shared_ptr<nio::ad::messages::McuSystemFimInfo>>  arb_fim_mcu_sys_info;
std::vector<std::shared_ptr<nio::ad::messages::PerceptionFimInfo>> arb_fim_perception_info;

std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_info;
std::vector<std::shared_ptr<nio::ad::messages::FailSafeDetection>>       arb_failsafe_vision_calib;
std::vector<std::shared_ptr<nio::ad::messages::Lidar_FailSafeDetection>> arb_failsafe_lidar_info;
std::vector<std::shared_ptr<nio::ad::messages::VehVariantCode>> arb_vehicle_variant_info;

ARBInputAdapter::ARBInputAdapter() {
  /*m_node_ = Node::CreateNode("ARBIANode");
  m_sub_vision_object_ = m_node_->CreateSubscriber<nio::ad::messages::ObjectsDetection>("perception/vision_objects");
  m_sub_radar_object_ = m_node_->CreateSubscriber<nio::ad::messages::RadarSensor>("perception/radar_object");
  m_sub_vehicle_10_ = m_node_->CreateSubscriber<nio::ad::messages::VEH10ms>("vehicle_in/vehicle_10ms");
  m_sub_vehicle_50_ = m_node_->CreateSubscriber<nio::ad::messages::VEH50ms>("vehicle_in/vehicle_50ms");
  m_sub_road_detection_ =
  m_node_->CreateSubscriber<nio::ad::messages::RoadDetection>("perception/vision_road_detection"); m_sub_fusion_object_
  = m_node_->CreateSubscriber<nio::ad::messages::EHYObfOutputs>("apps/ehy_obf_outputs"); m_sub_ehy_ego_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYEgoOutputs>("apps/ehy_ego_outputs");
  m_sub_ehy_evd_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYEvdOutputs>("apps/ehy_evd_outputs");
  m_sub_ehy_ha_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYHaOutputs>("apps/ehy_ha_outputs");
  m_sub_ehy_lpp_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYLppOutputs>("apps/ehy_lpp_outputs");
  m_sub_ehy_rme_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYRmeOutputs>("apps/ehy_rme_outputs");
  m_sub_ehy_tpp_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYTppOutputs>("apps/ehy_tpp_outputs");
  m_sub_ehy_tsi_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYTsiOutputs>("apps/ehy_tsi_outputs");
  m_sub_ehy_tse_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYTseOutputs>("apps/ehy_tse_outputs");
  m_sub_ehy_tsr_ =
  m_node_->CreateSubscriber<nio::ad::messages::EHYTsrOutputs>("apps/ehy_tsr_outputs");*/
}

ARBInputAdapter::~ARBInputAdapter() {}

void ARBInputAdapter::receive_update() {
  // std::cout << "ARBInputAdapter_receiveupdate start"<<std::endl;
  /*if (m_sub_vision_object_->HasReceived())
  {
      //update the object list
      m_sub_vision_object_->ReadReceived(vision_objects_);
  }

  if (m_sub_radar_object_->HasReceived())
  {
      //update the radar object list
      m_sub_radar_object_->ReadReceived(radar_data_);
  }

  if (m_sub_vehicle_10_->HasReceived())
  {
      //update the vehicle list
      m_sub_vehicle_10_->ReadReceived(vehicle_input_10_);
  }

  if (m_sub_vehicle_50_->HasReceived())
  {
      //update the vehicle list
      m_sub_vehicle_50_->ReadReceived(vehicle_input_50_);
  }

  if (m_sub_road_detection_->HasReceived())
  {
      //Update road info
      m_sub_road_detection_->ReadReceived(road_detection_);
  }

  if (m_sub_fusion_object_->HasReceived())
  {
      //update obf
      m_sub_fusion_object_->ReadReceived(fusion_object_);
  }

  if (m_sub_ehy_ego_->HasReceived())
  {
      //update ego
      m_sub_ehy_ego_->ReadReceived(ehy_ego_);
  }

  if (m_sub_ehy_evd_->HasReceived())
  {
      //update evd
      m_sub_ehy_evd_->ReadReceived(ehy_evd_);
  }

  if (m_sub_ehy_ha_->HasReceived())
  {
      //update ha
      m_sub_ehy_ha_->ReadReceived(ehy_ha_);
  }

  if (m_sub_ehy_lpp_->HasReceived())
  {
      //update lpp
      m_sub_ehy_lpp_->ReadReceived(ehy_lpp_);
  }

  if (m_sub_ehy_rme_->HasReceived())
  {
      //update rme
      m_sub_ehy_rme_->ReadReceived(ehy_rme_);
  }

  if (m_sub_ehy_tpp_->HasReceived())
  {
      //update tpp
      m_sub_ehy_tpp_->ReadReceived(ehy_tpp_);
  }

  if (m_sub_ehy_tsi_->HasReceived())
  {
      //update tsi
      m_sub_ehy_tsi_->ReadReceived(ehy_tsi_);
  }

  if (m_sub_ehy_tse_->HasReceived())
  {
      //update tse
      m_sub_ehy_tse_->ReadReceived(ehy_tse_);
  }

  if (m_sub_ehy_tsr_->HasReceived())
  {
      //update ego
      m_sub_ehy_tsr_->ReadReceived(ehy_tsr_);
  }*/

  // std::cout << "ARBInputAdapter_receiveupdate complete"<<std::endl;
}

bool ARBInputAdapter::fill_side_feature(const std::shared_ptr<nio::ad::messages::ForceSideFeatures> side_feature_info,
                                        APSideFeature* aptiv_side_feature) {
  aptiv_side_feature->fcta_onoff_sts = side_feature_info->cam_fc_03().fcta_onoff_sts();

  aptiv_side_feature->bsd_haptic_req   = side_feature_info->adc_eps_02().adc1_eps_hvi_req();
  aptiv_side_feature->bsd_haptic_valid = side_feature_info->adc_eps_02().adc1_eps_hvi_req_val();

  aptiv_side_feature->rctb_brk_sts = side_feature_info->rad_fc_03().rcta_brk_sts();

  aptiv_side_feature->rctb_decel_to_stop = side_feature_info->rad_fc_01().acc_decel_stop_req();
  aptiv_side_feature->rctb_drv_off_req   = side_feature_info->rad_fc_01().drv_off_req();
  aptiv_side_feature->rctb_max_jerk      = side_feature_info->rad_fc_01().acc_max_jerk_accel();
  aptiv_side_feature->rctb_min_jerk      = side_feature_info->rad_fc_01().acc_min_jerk_accel();
  aptiv_side_feature->rctb_acc_mode      = side_feature_info->rad_fc_01().acc_mode();
  aptiv_side_feature->rctb_shutdown_req  = side_feature_info->rad_fc_01().acc_shutdown_req();
  aptiv_side_feature->rctb_tar_accel     = side_feature_info->rad_fc_01().acc_tar_accel();
  aptiv_side_feature->rctb_vlc_req       = side_feature_info->rad_fc_01().vlc_func_req();

  aptiv_side_feature->fcta_left_sts  = side_feature_info->rad_fl_01().fcta_left_sts();
  aptiv_side_feature->fcta_left_warn = side_feature_info->rad_fl_01().fcta_left_warn_req();
  aptiv_side_feature->fcta_left_fail = side_feature_info->rad_fl_01().front_left_rad_fault_disp();

  aptiv_side_feature->fcta_right_sts  = side_feature_info->rad_fr_01().fcta_right_sts();
  aptiv_side_feature->fcta_right_warn = side_feature_info->rad_fr_01().fcta_right_warn_req();
  aptiv_side_feature->fcta_right_fail = side_feature_info->rad_fr_01().front_right_rad_fault_disp();

  aptiv_side_feature->bsd_onoff_sts       = side_feature_info->rad_rr_01().bsdlca_onoff_sts();
  aptiv_side_feature->bsd_left_sts        = side_feature_info->rad_rr_01().bsdlca_left_sts();
  aptiv_side_feature->bsd_right_sts       = side_feature_info->rad_rr_01().bsdlca_right_sts();
  aptiv_side_feature->bsd_left_warn       = side_feature_info->rad_rr_01().bsdlca_right_warn_req();
  aptiv_side_feature->bsd_right_warn      = side_feature_info->rad_rr_01().bsdlca_right_warn_req();
  aptiv_side_feature->bsd_hapic_onoff_sts = side_feature_info->rad_rr_01().bsdlca_haptic_onoff_sts();
  aptiv_side_feature->extern_req          = side_feature_info->rad_rr_01().ext_req();
  aptiv_side_feature->dow_onoff_sts       = side_feature_info->rad_rr_01().sdow_onoff_sts();
  aptiv_side_feature->dow_left_sts        = side_feature_info->rad_rr_01().sdow_left_sts();
  aptiv_side_feature->dow_right_sts       = side_feature_info->rad_rr_01().sdow_right_sts();
  aptiv_side_feature->dow_left_warn       = side_feature_info->rad_rr_01().sdow_left_warn_req();
  aptiv_side_feature->dow_right_warn      = side_feature_info->rad_rr_01().sdow_right_warn_req();
  aptiv_side_feature->rcta_onoff_sts      = side_feature_info->rad_rr_01().rcta_onoff_sts();
  aptiv_side_feature->rcta_left_sts       = side_feature_info->rad_rr_01().rcta_left_sts();
  aptiv_side_feature->rcta_right_sts      = side_feature_info->rad_rr_01().rcta_right_sts();
  aptiv_side_feature->rcta_left_warn      = side_feature_info->rad_rr_01().rcta_left_warn_req();
  aptiv_side_feature->rcta_right_warn     = side_feature_info->rad_rr_01().rcta_right_warn_req();
  aptiv_side_feature->mirror_light_left   = side_feature_info->rad_rr_01().mirr_light_left_req();
  aptiv_side_feature->mirror_light_right  = side_feature_info->rad_rr_01().mirr_light_right_req();
  aptiv_side_feature->rear_radar_fail     = side_feature_info->rad_rr_01().rear_rad_fault_disp();

  return true;
}

bool ARBInputAdapter::fill_ehy_ego_input(const std::shared_ptr<nio::ad::messages::EHYEgoOutputs> ehy_ego,
                                         EHYEgo*                                                 ehyego_output) {
  ehyego_output->yawrate_filtered = ehy_ego->yawrate_filtered();
  ehyego_output->pp_c2            = ehy_ego->pp_c2();

  return true;
}

bool ARBInputAdapter::fill_ehy_evd_input(const std::shared_ptr<nio::ad::messages::EHYEvdOutputs> ehy_evd_info,
                                         EHYEvdOutputs*                                          ehyevd_output) {
  ehyevd_output->decision = static_cast<nio::ad::EvdDecisionName>(static_cast<int>(ehy_evd_info->decision()));

  ehyevd_output->parameters.lane_change.change_dir =
    static_cast<nio::ad::EvdDcsDir>(static_cast<int>(ehy_evd_info->parameters().lane_change().change_dir()));

  ehyevd_output->parameters.lane_change.lane_change_reason = static_cast<nio::ad::EvdLaneChangeReason>(
    static_cast<int>(ehy_evd_info->parameters().lane_change().lane_change_reason()));

  ehyevd_output->parameters.path_select.path_dir =
    static_cast<nio::ad::EvdDcsDir>(static_cast<int>(ehy_evd_info->parameters().path_select().path_dir()));

  ehyevd_output->parameters.leading.leading_dir =
    static_cast<nio::ad::EvdDcsDir>(static_cast<int>(ehy_evd_info->parameters().leading().leading_dir()));

  ehyevd_output->parameters.takeover.takeover_src =
    static_cast<uint32_t>(ehy_evd_info->parameters().takeover().takeover_src());

  ehyevd_output->parameters.hw2ramp.ramp_dir =
    static_cast<nio::ad::EvdDcsDir>(static_cast<int>(ehy_evd_info->parameters().hw2ramp().ramp_dir()));

  ehyevd_output->parameters.hw2ramp.dst2leading =
    static_cast<float>(ehy_evd_info->parameters().hw2ramp().dst2leading());

  ehyevd_output->limitations.spd_valid = static_cast<bool>(ehy_evd_info->limitations().spd_valid());

  ehyevd_output->limitations.spd = static_cast<float>(ehy_evd_info->limitations().spd());

  ehyevd_output->limitations.distance_valid = static_cast<bool>(ehy_evd_info->limitations().distance_valid());

  ehyevd_output->limitations.distance = static_cast<float>(ehy_evd_info->limitations().distance());

  ehyevd_output->limitations.deadline_valid = static_cast<uint32_t>(ehy_evd_info->limitations().deadline_valid());

  ehyevd_output->limitations.deadline = static_cast<float>(ehy_evd_info->limitations().deadline());

  ehyevd_output->limitations.curr_limit.spd = static_cast<uint32_t>(ehy_evd_info->limitations().curr_limit().spd());

  ehyevd_output->limitations.curr_limit.dist = static_cast<float>(ehy_evd_info->limitations().curr_limit().dist());

  ehyevd_output->limitations.curr_limit.valid = static_cast<uint32_t>(ehy_evd_info->limitations().curr_limit().valid());

  ehyevd_output->limitations.curr_limit.source =
    static_cast<nio::ad::CurrSpdLmtSrc>(static_cast<int>(ehy_evd_info->limitations().curr_limit().source()));

  ehyevd_output->limitations.curr_limit.regulation =
    static_cast<uint32_t>(ehy_evd_info->limitations().curr_limit().regulation());

  ehyevd_output->gfp_info.valid = static_cast<uint32_t>(ehy_evd_info->gfp_info().valid());

  ehyevd_output->gfp_info.classification =
    static_cast<nio::ad::GFPDirClass>(static_cast<int>(ehy_evd_info->gfp_info().classification()));

  ehyevd_output->gfp_info.distance = static_cast<float>(ehy_evd_info->gfp_info().distance());

  ehyevd_output->gfp_info.type = static_cast<uint32_t>(ehy_evd_info->gfp_info().type());

  return true;
}

bool ARBInputAdapter::fill_ehy_ha_input(const std::shared_ptr<nio::ad::messages::EHYHaOutputs> ehy_ha_info,
                                        EHYHaOutputs*                                          ehyha_output) {
  ehyha_output->icon_info = static_cast<uint32_t>(ehy_ha_info->icon_info());

  ehyha_output->text_info = static_cast<nio::ad::HaTextInfo>(static_cast<int>(ehy_ha_info->icon_info()));

  ehyha_output->sound_info = static_cast<uint32_t>(ehy_ha_info->sound_info());

  ehyha_output->left_lane_flash = static_cast<bool>(ehy_ha_info->left_lane_flash());

  ehyha_output->right_lane_flash = static_cast<bool>(ehy_ha_info->right_lane_flash());

  return true;
}

bool ARBInputAdapter::fill_ehy_lpp_input(const std::shared_ptr<nio::ad::messages::EHYLppOutputs> ehy_lpp_info,
                                         EHYLppOutputs*                                          ehylpp_output) {
  ehylpp_output->trajectory.pt_conf = static_cast<float>(ehy_lpp_info->trajectory().pt_conf());

  ehylpp_output->trajectory.c0 = static_cast<float>(ehy_lpp_info->trajectory().c0());

  ehylpp_output->trajectory.c1 = static_cast<float>(ehy_lpp_info->trajectory().c1());

  ehylpp_output->trajectory.c2 = static_cast<float>(ehy_lpp_info->trajectory().c2());

  ehylpp_output->trajectory.c3 = static_cast<float>(ehy_lpp_info->trajectory().c3());

  ehylpp_output->trajectory.lrange_start = static_cast<float>(ehy_lpp_info->trajectory().lrange_start());

  ehylpp_output->trajectory.lrange_end = static_cast<float>(ehy_lpp_info->trajectory().lrange_end());

  ehylpp_output->trajectory.lm_width = static_cast<float>(ehy_lpp_info->trajectory().lm_width());

  ehylpp_output->trajectory.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_lpp_info->trajectory().line_color()));

  ehylpp_output->trajectory.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_lpp_info->trajectory().line_type()));

  ehylpp_output->trajectory.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_lpp_info->trajectory().line_src()));

  ehylpp_output->latctrl_pt = static_cast<float>(ehy_lpp_info->latctrl_pt());

  ehylpp_output->lonctrl_pt = static_cast<float>(ehy_lpp_info->lonctrl_pt());

  ehylpp_output->shitf_offset = static_cast<float>(ehy_lpp_info->shift_offset());

  ehylpp_output->act_shift_status = static_cast<uint32_t>(ehy_lpp_info->act_shift_status());

  return true;
}

bool ARBInputAdapter::fill_ehy_rme_input(const std::shared_ptr<nio::ad::messages::EHYRmeOutputs> ehy_rme_info,
                                         EHYRmeOutputs*                                          ehyrme_output) {
  ehyrme_output->road_edge_left.pt_conf = static_cast<float>(ehy_rme_info->road_edge_left().pt_conf());

  ehyrme_output->road_edge_left.c0 = static_cast<float>(ehy_rme_info->road_edge_left().c0());

  ehyrme_output->road_edge_left.c1 = static_cast<float>(ehy_rme_info->road_edge_left().c1());

  ehyrme_output->road_edge_left.c2 = static_cast<float>(ehy_rme_info->road_edge_left().c2());

  ehyrme_output->road_edge_left.c3 = static_cast<float>(ehy_rme_info->road_edge_left().c3());

  ehyrme_output->road_edge_left.lrange_start = static_cast<float>(ehy_rme_info->road_edge_left().lrange_start());

  ehyrme_output->road_edge_left.lrange_end = static_cast<float>(ehy_rme_info->road_edge_left().lrange_end());

  ehyrme_output->road_edge_left.lm_width = static_cast<float>(ehy_rme_info->road_edge_left().lm_width());

  ehyrme_output->road_edge_left.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->road_edge_left().line_color()));

  ehyrme_output->road_edge_left.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->road_edge_left().line_type()));

  ehyrme_output->road_edge_left.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->road_edge_left().line_src()));

  ehyrme_output->road_edge_right.pt_conf = static_cast<float>(ehy_rme_info->road_edge_right().pt_conf());

  ehyrme_output->road_edge_right.c0 = static_cast<float>(ehy_rme_info->road_edge_right().c0());

  ehyrme_output->road_edge_right.c1 = static_cast<float>(ehy_rme_info->road_edge_right().c1());

  ehyrme_output->road_edge_right.c2 = static_cast<float>(ehy_rme_info->road_edge_right().c2());

  ehyrme_output->road_edge_right.c3 = static_cast<float>(ehy_rme_info->road_edge_right().c3());

  ehyrme_output->road_edge_right.lrange_start = static_cast<float>(ehy_rme_info->road_edge_right().lrange_start());

  ehyrme_output->road_edge_right.lrange_end = static_cast<float>(ehy_rme_info->road_edge_right().lrange_end());

  ehyrme_output->road_edge_right.lm_width = static_cast<float>(ehy_rme_info->road_edge_right().lm_width());

  ehyrme_output->road_edge_right.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->road_edge_right().line_color()));

  ehyrme_output->road_edge_right.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->road_edge_right().line_type()));

  ehyrme_output->road_edge_right.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->road_edge_right().line_src()));

  ehyrme_output->host_lane.left_line.pt_conf = static_cast<float>(ehy_rme_info->host_lane().left_line().pt_conf());

  ehyrme_output->host_lane.left_line.c0 = static_cast<float>(ehy_rme_info->host_lane().left_line().c0());

  ehyrme_output->host_lane.left_line.c1 = static_cast<float>(ehy_rme_info->host_lane().left_line().c1());

  ehyrme_output->host_lane.left_line.c2 = static_cast<float>(ehy_rme_info->host_lane().left_line().c2());

  ehyrme_output->host_lane.left_line.c3 = static_cast<float>(ehy_rme_info->host_lane().left_line().c3());

  ehyrme_output->host_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_info->host_lane().left_line().lrange_start());

  ehyrme_output->host_lane.left_line.lrange_end =
    static_cast<float>(ehy_rme_info->host_lane().left_line().lrange_end());

  ehyrme_output->host_lane.left_line.lm_width = static_cast<float>(ehy_rme_info->host_lane().left_line().lm_width());

  ehyrme_output->host_lane.left_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->host_lane().left_line().line_color()));

  ehyrme_output->host_lane.left_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->host_lane().left_line().line_type()));

  ehyrme_output->host_lane.left_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->host_lane().left_line().line_src()));

  ehyrme_output->host_lane.right_line.pt_conf = static_cast<float>(ehy_rme_info->host_lane().right_line().pt_conf());

  ehyrme_output->host_lane.right_line.c0 = static_cast<float>(ehy_rme_info->host_lane().right_line().c0());

  ehyrme_output->host_lane.right_line.c1 = static_cast<float>(ehy_rme_info->host_lane().right_line().c1());

  ehyrme_output->host_lane.right_line.c2 = static_cast<float>(ehy_rme_info->host_lane().right_line().c2());

  ehyrme_output->host_lane.right_line.c3 = static_cast<float>(ehy_rme_info->host_lane().right_line().c3());

  ehyrme_output->host_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_info->host_lane().right_line().lrange_start());

  ehyrme_output->host_lane.right_line.lrange_end =
    static_cast<float>(ehy_rme_info->host_lane().right_line().lrange_end());

  ehyrme_output->host_lane.right_line.lm_width = static_cast<float>(ehy_rme_info->host_lane().right_line().lm_width());

  ehyrme_output->host_lane.right_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->host_lane().right_line().line_color()));

  ehyrme_output->host_lane.right_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->host_lane().right_line().line_type()));

  ehyrme_output->host_lane.right_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->host_lane().right_line().line_src()));

  int min_hslantype_size = ehy_rme_info->host_lane().lane_type().size();

  for (int hostlanei = 0; hostlanei < min_hslantype_size; hostlanei++) {
    ehyrme_output->host_lane.lane_type[hostlanei] =
      static_cast<nio::ad::LMLaneType>(static_cast<int>(ehy_rme_info->host_lane().lane_type(hostlanei)));
  }

  ehyrme_output->host_lane.lane_start = static_cast<float>(ehy_rme_info->host_lane().lane_start());

  ehyrme_output->host_lane.lane_end = static_cast<float>(ehy_rme_info->host_lane().lane_end());

  ehyrme_output->host_lane.map_spd_limit = static_cast<float>(ehy_rme_info->host_lane().map_spd_limit());

  ehyrme_output->host_lane.lane_width = static_cast<float>(ehy_rme_info->host_lane().lane_width());

  ehyrme_output->host_lane.ca_lon_dst = static_cast<float>(ehy_rme_info->host_lane().ca_lon_dst());

  int host_cp_size = MIN(ehy_rme_info->host_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < host_cp_size; cpi++) {
    ehyrme_output->host_lane.cur_point[cpi] = static_cast<float>(ehy_rme_info->host_lane().cur_point(cpi));
  }

  int host_cv_size = MIN(ehy_rme_info->host_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < host_cv_size; cvi++) {
    ehyrme_output->host_lane.cur_value[cvi] = static_cast<float>(ehy_rme_info->host_lane().cur_value(cvi));
  }

  ehyrme_output->host_lane.lane_dir =
    static_cast<nio::ad::LMLaneDir>(static_cast<int>(ehy_rme_info->host_lane().lane_dir()));

  ehyrme_output->host_lane.ca_valid = static_cast<bool>(ehy_rme_info->host_lane().ca_valid());

  ehyrme_output->host_lane.lane_id = static_cast<uint32_t>(ehy_rme_info->host_lane().lane_id());

  ehyrme_output->left_lane.left_line.pt_conf = static_cast<float>(ehy_rme_info->left_lane().left_line().pt_conf());

  ehyrme_output->left_lane.left_line.c0 = static_cast<float>(ehy_rme_info->left_lane().left_line().c0());

  ehyrme_output->left_lane.left_line.c1 = static_cast<float>(ehy_rme_info->left_lane().left_line().c1());

  ehyrme_output->left_lane.left_line.c2 = static_cast<float>(ehy_rme_info->left_lane().left_line().c2());

  ehyrme_output->left_lane.left_line.c3 = static_cast<float>(ehy_rme_info->left_lane().left_line().c3());

  ehyrme_output->left_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_info->left_lane().left_line().lrange_start());

  ehyrme_output->left_lane.left_line.lrange_end =
    static_cast<float>(ehy_rme_info->left_lane().left_line().lrange_end());

  ehyrme_output->left_lane.left_line.lm_width = static_cast<float>(ehy_rme_info->left_lane().left_line().lm_width());

  ehyrme_output->left_lane.left_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->left_lane().left_line().line_color()));

  ehyrme_output->left_lane.left_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->left_lane().left_line().line_type()));

  ehyrme_output->left_lane.left_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->left_lane().left_line().line_src()));

  ehyrme_output->left_lane.right_line.pt_conf = static_cast<float>(ehy_rme_info->left_lane().right_line().pt_conf());

  ehyrme_output->left_lane.right_line.c0 = static_cast<float>(ehy_rme_info->left_lane().right_line().c0());

  ehyrme_output->left_lane.right_line.c1 = static_cast<float>(ehy_rme_info->left_lane().right_line().c1());

  ehyrme_output->left_lane.right_line.c2 = static_cast<float>(ehy_rme_info->left_lane().right_line().c2());

  ehyrme_output->left_lane.right_line.c3 = static_cast<float>(ehy_rme_info->left_lane().right_line().c3());

  ehyrme_output->left_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_info->left_lane().right_line().lrange_start());

  ehyrme_output->left_lane.right_line.lrange_end =
    static_cast<float>(ehy_rme_info->left_lane().right_line().lrange_end());

  ehyrme_output->left_lane.right_line.lm_width = static_cast<float>(ehy_rme_info->left_lane().right_line().lm_width());

  ehyrme_output->left_lane.right_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->left_lane().right_line().line_color()));

  ehyrme_output->left_lane.right_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->left_lane().right_line().line_type()));

  ehyrme_output->left_lane.right_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->left_lane().right_line().line_src()));

  int min_lflantype_size = ehy_rme_info->left_lane().lane_type().size();

  for (int lflanei = 0; lflanei < min_lflantype_size; lflanei++) {
    ehyrme_output->left_lane.lane_type[lflanei] =
      static_cast<nio::ad::LMLaneType>(static_cast<int>(ehy_rme_info->left_lane().lane_type(lflanei)));
  }

  ehyrme_output->left_lane.lane_start = static_cast<float>(ehy_rme_info->left_lane().lane_start());

  ehyrme_output->left_lane.lane_end = static_cast<float>(ehy_rme_info->left_lane().lane_end());

  ehyrme_output->left_lane.map_spd_limit = static_cast<float>(ehy_rme_info->left_lane().map_spd_limit());

  ehyrme_output->left_lane.lane_width = static_cast<float>(ehy_rme_info->left_lane().lane_width());

  ehyrme_output->left_lane.ca_lon_dst = static_cast<float>(ehy_rme_info->left_lane().ca_lon_dst());

  int left_cp_size = MIN(ehy_rme_info->left_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < left_cp_size; cpi++) {
    ehyrme_output->left_lane.cur_point[cpi] = static_cast<float>(ehy_rme_info->left_lane().cur_point(cpi));
  }

  int left_cv_size = MIN(ehy_rme_info->left_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < left_cv_size; cvi++) {
    ehyrme_output->left_lane.cur_value[cvi] = static_cast<float>(ehy_rme_info->left_lane().cur_value(cvi));
  }

  ehyrme_output->left_lane.lane_dir =
    static_cast<nio::ad::LMLaneDir>(static_cast<int>(ehy_rme_info->left_lane().lane_dir()));

  ehyrme_output->left_lane.ca_valid = static_cast<bool>(ehy_rme_info->left_lane().ca_valid());

  ehyrme_output->left_lane.lane_id = static_cast<uint32_t>(ehy_rme_info->left_lane().lane_id());

  ehyrme_output->right_lane.left_line.pt_conf = static_cast<float>(ehy_rme_info->right_lane().left_line().pt_conf());

  ehyrme_output->right_lane.left_line.c0 = static_cast<float>(ehy_rme_info->right_lane().left_line().c0());

  ehyrme_output->right_lane.left_line.c1 = static_cast<float>(ehy_rme_info->right_lane().left_line().c1());

  ehyrme_output->right_lane.left_line.c2 = static_cast<float>(ehy_rme_info->right_lane().left_line().c2());

  ehyrme_output->right_lane.left_line.c3 = static_cast<float>(ehy_rme_info->right_lane().left_line().c3());

  ehyrme_output->right_lane.left_line.lrange_start =
    static_cast<float>(ehy_rme_info->right_lane().left_line().lrange_start());

  ehyrme_output->right_lane.left_line.lrange_end =
    static_cast<float>(ehy_rme_info->right_lane().left_line().lrange_end());

  ehyrme_output->right_lane.left_line.lm_width = static_cast<float>(ehy_rme_info->right_lane().left_line().lm_width());

  ehyrme_output->right_lane.left_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->right_lane().left_line().line_color()));

  ehyrme_output->right_lane.left_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->right_lane().left_line().line_type()));

  ehyrme_output->right_lane.left_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->right_lane().left_line().line_src()));

  ehyrme_output->right_lane.right_line.pt_conf = static_cast<float>(ehy_rme_info->right_lane().right_line().pt_conf());

  ehyrme_output->right_lane.right_line.c0 = static_cast<float>(ehy_rme_info->right_lane().right_line().c0());

  ehyrme_output->right_lane.right_line.c1 = static_cast<float>(ehy_rme_info->right_lane().right_line().c1());

  ehyrme_output->right_lane.right_line.c2 = static_cast<float>(ehy_rme_info->right_lane().right_line().c2());

  ehyrme_output->right_lane.right_line.c3 = static_cast<float>(ehy_rme_info->right_lane().right_line().c3());

  ehyrme_output->right_lane.right_line.lrange_start =
    static_cast<float>(ehy_rme_info->right_lane().right_line().lrange_start());

  ehyrme_output->right_lane.right_line.lrange_end =
    static_cast<float>(ehy_rme_info->right_lane().right_line().lrange_end());

  ehyrme_output->right_lane.right_line.lm_width =
    static_cast<float>(ehy_rme_info->right_lane().right_line().lm_width());

  ehyrme_output->right_lane.right_line.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->right_lane().right_line().line_color()));

  ehyrme_output->right_lane.right_line.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->right_lane().right_line().line_type()));

  ehyrme_output->right_lane.right_line.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->right_lane().right_line().line_src()));

  int min_rglantype_size = ehy_rme_info->right_lane().lane_type().size();

  for (int rglanei = 0; rglanei < min_rglantype_size; rglanei++) {
    ehyrme_output->right_lane.lane_type[rglanei] =
      static_cast<nio::ad::LMLaneType>(static_cast<int>(ehy_rme_info->right_lane().lane_type(rglanei)));
  }

  ehyrme_output->right_lane.lane_start = static_cast<float>(ehy_rme_info->right_lane().lane_start());

  ehyrme_output->right_lane.lane_end = static_cast<float>(ehy_rme_info->right_lane().lane_end());

  ehyrme_output->right_lane.map_spd_limit = static_cast<float>(ehy_rme_info->right_lane().map_spd_limit());

  ehyrme_output->right_lane.lane_width = static_cast<float>(ehy_rme_info->right_lane().lane_width());

  ehyrme_output->right_lane.ca_lon_dst = static_cast<float>(ehy_rme_info->right_lane().ca_lon_dst());

  int right_cp_size = MIN(ehy_rme_info->right_lane().cur_point().size(), 10);

  for (int cpi = 0; cpi < right_cp_size; cpi++) {
    ehyrme_output->right_lane.cur_point[cpi] = static_cast<float>(ehy_rme_info->right_lane().cur_point(cpi));
  }

  int right_cv_size = MIN(ehy_rme_info->right_lane().cur_value().size(), 10);

  for (int cvi = 0; cvi < right_cv_size; cvi++) {
    ehyrme_output->right_lane.cur_value[cvi] = static_cast<float>(ehy_rme_info->right_lane().cur_value(cvi));
  }

  ehyrme_output->right_lane.lane_dir =
    static_cast<nio::ad::LMLaneDir>(static_cast<int>(ehy_rme_info->right_lane().lane_dir()));

  ehyrme_output->right_lane.ca_valid = static_cast<bool>(ehy_rme_info->right_lane().ca_valid());

  ehyrme_output->right_lane.lane_id = static_cast<uint32_t>(ehy_rme_info->right_lane().lane_id());

  int ngpl_size = MIN(ehy_rme_info->hdmap_info().ngp_list().size(), 20);

  for (int ngpi = 0; ngpi < ngpl_size; ngpi++) {
    ehyrme_output->hdmap_info.ngp_list[ngpi].gp_distance =
      static_cast<float>(ehy_rme_info->hdmap_info().ngp_list(ngpi).gp_distance());

    ehyrme_output->hdmap_info.ngp_list[ngpi].gp_type =
      static_cast<uint32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).gp_type());

    ehyrme_output->hdmap_info.ngp_list[ngpi].recom_speed =
      static_cast<float>(ehy_rme_info->hdmap_info().ngp_list(ngpi).recom_speed());

    ehyrme_output->hdmap_info.ngp_list[ngpi].link_length =
      static_cast<float>(ehy_rme_info->hdmap_info().ngp_list(ngpi).link_length());

    ehyrme_output->hdmap_info.ngp_list[ngpi].recom_lane_idx =
      static_cast<uint32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).recom_lane_idx());

    ehyrme_output->hdmap_info.ngp_list[ngpi].recom_speed =
      static_cast<uint32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).recom_speed());

    ehyrme_output->hdmap_info.ngp_list[ngpi].recom_speed_src =
      static_cast<uint32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).recom_speed_src());

    ehyrme_output->hdmap_info.ngp_list[ngpi].recom_speed_conf =
      static_cast<uint32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).recom_speed_conf());

    ehyrme_output->hdmap_info.ngp_list[ngpi].spd_unit =
      static_cast<bool>(ehy_rme_info->hdmap_info().ngp_list(ngpi).spd_unit());

    ehyrme_output->hdmap_info.ngp_list[ngpi].sup_sign_typ =
      static_cast<int32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).sup_sign_typ());

    ehyrme_output->hdmap_info.ngp_list[ngpi].sup_sign_attr =
      static_cast<int32_t>(ehy_rme_info->hdmap_info().ngp_list(ngpi).sup_sign_attr());
  }

  int intp_size = MIN(ehy_rme_info->interest_point().size(), 20);

  for (int intpi = 0; intpi < intp_size; intpi++) {
    ehyrme_output->interest_point[intpi].point.conf =
      static_cast<float>(ehy_rme_info->interest_point(intpi).point().conf());

    ehyrme_output->interest_point[intpi].point.x = static_cast<float>(ehy_rme_info->interest_point(intpi).point().x());

    ehyrme_output->interest_point[intpi].point.y = static_cast<float>(ehy_rme_info->interest_point(intpi).point().y());

    ehyrme_output->interest_point[intpi].point.z = static_cast<float>(ehy_rme_info->interest_point(intpi).point().z());

    ehyrme_output->interest_point[intpi].point.w = static_cast<float>(ehy_rme_info->interest_point(intpi).point().w());

    ehyrme_output->interest_point[intpi].point.d = static_cast<float>(ehy_rme_info->interest_point(intpi).point().d());

    ehyrme_output->interest_point[intpi].point.s = static_cast<float>(ehy_rme_info->interest_point(intpi).point().s());

    ehyrme_output->interest_point[intpi].id = static_cast<int32_t>(ehy_rme_info->interest_point(intpi).id());

    ehyrme_output->interest_point[intpi].intp_class =
      static_cast<nio::ad::LMIntPClass>(static_cast<int>(ehy_rme_info->interest_point(intpi).intp_class()));

    ehyrme_output->interest_point[intpi].source =
      static_cast<nio::ad::LMSource>(static_cast<int>(ehy_rme_info->interest_point(intpi).source()));

    ehyrme_output->interest_point[intpi].role =
      static_cast<nio::ad::LMRole>(static_cast<int>(ehy_rme_info->interest_point(intpi).role()));

    ehyrme_output->interest_point[intpi].far_markclass =
      static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_rme_info->interest_point(intpi).far_markclass()));

    ehyrme_output->interest_point[intpi].far_color =
      static_cast<nio::ad::LMColor>(static_cast<int>(ehy_rme_info->interest_point(intpi).far_color()));

    ehyrme_output->interest_point[intpi].far_spd =
      static_cast<uint32_t>(ehy_rme_info->interest_point(intpi).intp_class());
  }

  ehyrme_output->road_start = static_cast<float>(ehy_rme_info->road_start());

  ehyrme_output->road_end = static_cast<float>(ehy_rme_info->road_end());

  ehyrme_output->total_lane_num = static_cast<uint32_t>(ehy_rme_info->total_lane_num());

  ehyrme_output->num_lane_id = static_cast<uint32_t>(ehy_rme_info->num_lane_id());

  ehyrme_output->road_type = static_cast<uint32_t>(ehy_rme_info->road_type());

  ehyrme_output->status = static_cast<uint32_t>(ehy_rme_info->status());

  return true;
}

bool ARBInputAdapter::fill_ehy_tpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_info,
                                         EHYTppOutputs*                                          ehytpp_output) {
  ehytpp_output->tpp_trajectory.pt_conf = static_cast<float>(ehy_tpp_info->tpp_trajectory().pt_conf());

  ehytpp_output->tpp_trajectory.c0 = static_cast<float>(ehy_tpp_info->tpp_trajectory().c0());

  ehytpp_output->tpp_trajectory.c1 = static_cast<float>(ehy_tpp_info->tpp_trajectory().c1());

  ehytpp_output->tpp_trajectory.c2 = static_cast<float>(ehy_tpp_info->tpp_trajectory().c2());

  ehytpp_output->tpp_trajectory.c3 = static_cast<float>(ehy_tpp_info->tpp_trajectory().c3());

  ehytpp_output->tpp_trajectory.lrange_start = static_cast<float>(ehy_tpp_info->tpp_trajectory().lrange_start());

  ehytpp_output->tpp_trajectory.lrange_end = static_cast<float>(ehy_tpp_info->tpp_trajectory().lrange_end());

  ehytpp_output->tpp_trajectory.lm_width = static_cast<float>(ehy_tpp_info->tpp_trajectory().lm_width());

  ehytpp_output->tpp_trajectory.line_color =
    static_cast<nio::ad::LMColor>(static_cast<int>(ehy_tpp_info->tpp_trajectory().line_color()));

  ehytpp_output->tpp_trajectory.line_type =
    static_cast<nio::ad::LMLaneMarkClass>(static_cast<int>(ehy_tpp_info->tpp_trajectory().line_type()));

  ehytpp_output->tpp_trajectory.line_src =
    static_cast<nio::ad::LMSource>(static_cast<int>(ehy_tpp_info->tpp_trajectory().line_src()));

  ehytpp_output->latctrl_pt = static_cast<float>(ehy_tpp_info->latctrl_pt());

  ehytpp_output->longctrl_pt = static_cast<float>(ehy_tpp_info->longctrl_pt());

  ehytpp_output->shift_offset = static_cast<float>(ehy_tpp_info->shift_offset());

  ehytpp_output->act_shift_status = static_cast<uint32_t>(ehy_tpp_info->act_shift_status());

  return true;
}

bool ARBInputAdapter::fill_ehy_tsi_input(const std::shared_ptr<nio::ad::messages::EHYTsiOutputs> ehy_tsi_info,
                                         EHYTsiOutputs*                                          ehytsi_output) {
  int tsi_size = MIN(ehy_tsi_info->tsi_obj().size(), 35);

  for (int tsii = 0; tsii < tsi_size; tsii++) {
    ehytsi_output->tsi_obj[tsii].id = static_cast<uint32_t>(ehy_tsi_info->tsi_obj(tsii).id());

    ehytsi_output->tsi_obj[tsii].obj_index = static_cast<uint32_t>(ehy_tsi_info->tsi_obj(tsii).obj_index());

    ehytsi_output->tsi_obj[tsii].confidence = static_cast<uint32_t>(ehy_tsi_info->tsi_obj(tsii).confidence());

    ehytsi_output->tsi_obj[tsii].lon_pos_ccs = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_pos_ccs());

    ehytsi_output->tsi_obj[tsii].lon_pos_vcs = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_pos_vcs());

    ehytsi_output->tsi_obj[tsii].lon_pos_vcs_std = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_pos_vcs_std());

    ehytsi_output->tsi_obj[tsii].lon_vel = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_vel());

    ehytsi_output->tsi_obj[tsii].lon_vel_std = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_vel());

    ehytsi_output->tsi_obj[tsii].lon_acc = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lon_acc());

    ehytsi_output->tsi_obj[tsii].lat_pos_ccs = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_pos_ccs());

    ehytsi_output->tsi_obj[tsii].lat_pos_vcs = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_pos_vcs());

    ehytsi_output->tsi_obj[tsii].lat_pos_vcs_std = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_pos_vcs_std());

    ehytsi_output->tsi_obj[tsii].lat_vel = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_vel());

    ehytsi_output->tsi_obj[tsii].lat_vel_std = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_vel_std());

    ehytsi_output->tsi_obj[tsii].lat_acc = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).lat_acc());

    ehytsi_output->tsi_obj[tsii].status =
      static_cast<nio::ad::TgtObjMotionStatus>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).status()));

    ehytsi_output->tsi_obj[tsii].type =
      static_cast<nio::ad::TgtObjType>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).type()));

    ehytsi_output->tsi_obj[tsii].valid =
      static_cast<nio::ad::TgtObjValidStatus>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).valid()));

    ehytsi_output->tsi_obj[tsii].age = static_cast<uint32_t>(ehy_tsi_info->tsi_obj(tsii).age());

    ehytsi_output->tsi_obj[tsii].width = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).width());

    ehytsi_output->tsi_obj[tsii].length = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).length());

    ehytsi_output->tsi_obj[tsii].height = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).height());

    ehytsi_output->tsi_obj[tsii].phi_angle = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).phi_angle());

    ehytsi_output->tsi_obj[tsii].dphi_angle_rate = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).dphi_angle_rate());

    ehytsi_output->tsi_obj[tsii].fusion_source =
      static_cast<nio::ad::TgtFusionSrc>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).fusion_source()));

    ehytsi_output->tsi_obj[tsii].ttc = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).ttc());

    ehytsi_output->tsi_obj[tsii].blinker_info =
      static_cast<nio::ad::BlinkerType>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).blinker_info()));

    ehytsi_output->tsi_obj[tsii].brake_lights = static_cast<uint32_t>(ehy_tsi_info->tsi_obj(tsii).brake_lights());

    ehytsi_output->tsi_obj[tsii].prob_lane_change = static_cast<float>(ehy_tsi_info->tsi_obj(tsii).prob_lane_change());

    ehytsi_output->tsi_obj[tsii].dirLaneChange =
      static_cast<nio::ad::TgtLaneChangeDir>(static_cast<int>(ehy_tsi_info->tsi_obj(tsii).dirlanechange()));
  }

  int rmtsi_size = MIN(ehy_tsi_info->rm_tsi_out().size(), 32);

  for (int rm_tsii = 0; rm_tsii < rmtsi_size; rm_tsii++) {
    ehytsi_output->rm_tsi_out[rm_tsii].id = static_cast<uint32_t>(ehy_tsi_info->rm_tsi_out(rm_tsii).id());

    ehytsi_output->rm_tsi_out[rm_tsii].obj_index = static_cast<uint32_t>(ehy_tsi_info->rm_tsi_out(rm_tsii).obj_index());

    ehytsi_output->rm_tsi_out[rm_tsii].confidence =
      static_cast<uint32_t>(ehy_tsi_info->rm_tsi_out(rm_tsii).confidence());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_pos_ccs =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_pos_ccs());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_pos_vcs =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_pos_vcs());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_pos_vcs_std =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_pos_vcs_std());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_vel = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_vel());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_vel_std = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_vel());

    ehytsi_output->rm_tsi_out[rm_tsii].lon_acc = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lon_acc());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_pos_ccs =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_pos_ccs());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_pos_vcs =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_pos_vcs());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_pos_vcs_std =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_pos_vcs_std());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_vel = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_vel());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_vel_std =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_vel_std());

    ehytsi_output->rm_tsi_out[rm_tsii].lat_acc = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).lat_acc());

    ehytsi_output->rm_tsi_out[rm_tsii].status =
      static_cast<nio::ad::TgtObjMotionStatus>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).status()));

    ehytsi_output->rm_tsi_out[rm_tsii].type =
      static_cast<nio::ad::TgtObjType>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).type()));

    ehytsi_output->rm_tsi_out[rm_tsii].valid =
      static_cast<nio::ad::TgtObjValidStatus>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).valid()));

    ehytsi_output->rm_tsi_out[rm_tsii].age = static_cast<uint32_t>(ehy_tsi_info->rm_tsi_out(rm_tsii).age());

    ehytsi_output->rm_tsi_out[rm_tsii].width = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).width());

    ehytsi_output->rm_tsi_out[rm_tsii].length = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).length());

    ehytsi_output->rm_tsi_out[rm_tsii].height = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).height());

    ehytsi_output->rm_tsi_out[rm_tsii].phi_angle = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).phi_angle());

    ehytsi_output->rm_tsi_out[rm_tsii].dphi_angle_rate =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).dphi_angle_rate());

    ehytsi_output->rm_tsi_out[rm_tsii].fusion_source =
      static_cast<nio::ad::TgtFusionSrc>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).fusion_source()));

    ehytsi_output->rm_tsi_out[rm_tsii].ttc = static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).ttc());

    ehytsi_output->rm_tsi_out[rm_tsii].blinker_info =
      static_cast<nio::ad::BlinkerType>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).blinker_info()));

    ehytsi_output->rm_tsi_out[rm_tsii].brake_lights =
      static_cast<uint32_t>(ehy_tsi_info->rm_tsi_out(rm_tsii).brake_lights());

    ehytsi_output->rm_tsi_out[rm_tsii].prob_lane_change =
      static_cast<float>(ehy_tsi_info->rm_tsi_out(rm_tsii).prob_lane_change());

    ehytsi_output->rm_tsi_out[rm_tsii].dirLaneChange =
      static_cast<nio::ad::TgtLaneChangeDir>(static_cast<int>(ehy_tsi_info->rm_tsi_out(rm_tsii).dirlanechange()));
  }

  int tca_size = MIN(ehy_tsi_info->tca_out().tca_obj().size(), 15);

  for (int tcai = 0; tcai < tca_size; tcai++) {
    ehytsi_output->tca_out.tca_obj[tcai].id = static_cast<uint32_t>(ehy_tsi_info->tca_out().tca_obj(tcai).id());

    ehytsi_output->tca_out.tca_obj[tcai].obj_index =
      static_cast<uint32_t>(ehy_tsi_info->tca_out().tca_obj(tcai).obj_index());

    ehytsi_output->tca_out.tca_obj[tcai].confidence =
      static_cast<uint32_t>(ehy_tsi_info->tca_out().tca_obj(tcai).confidence());

    ehytsi_output->tca_out.tca_obj[tcai].lon_pos_ccs =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_pos_ccs());

    ehytsi_output->tca_out.tca_obj[tcai].lon_pos_vcs =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_pos_vcs());

    ehytsi_output->tca_out.tca_obj[tcai].lon_pos_vcs_std =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_pos_vcs_std());

    ehytsi_output->tca_out.tca_obj[tcai].lon_vel = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_vel());

    ehytsi_output->tca_out.tca_obj[tcai].lon_vel_std =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_vel());

    ehytsi_output->tca_out.tca_obj[tcai].lon_acc = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lon_acc());

    ehytsi_output->tca_out.tca_obj[tcai].lat_pos_ccs =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_pos_ccs());

    ehytsi_output->tca_out.tca_obj[tcai].lat_pos_vcs =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_pos_vcs());

    ehytsi_output->tca_out.tca_obj[tcai].lat_pos_vcs_std =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_pos_vcs_std());

    ehytsi_output->tca_out.tca_obj[tcai].lat_vel = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_vel());

    ehytsi_output->tca_out.tca_obj[tcai].lat_vel_std =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_vel_std());

    ehytsi_output->tca_out.tca_obj[tcai].lat_acc = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).lat_acc());

    ehytsi_output->tca_out.tca_obj[tcai].status =
      static_cast<nio::ad::TgtObjMotionStatus>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).status()));

    ehytsi_output->tca_out.tca_obj[tcai].type =
      static_cast<nio::ad::TgtObjType>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).type()));

    ehytsi_output->tca_out.tca_obj[tcai].valid =
      static_cast<nio::ad::TgtObjValidStatus>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).valid()));

    ehytsi_output->tca_out.tca_obj[tcai].age = static_cast<uint32_t>(ehy_tsi_info->tca_out().tca_obj(tcai).age());

    ehytsi_output->tca_out.tca_obj[tcai].width = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).width());

    ehytsi_output->tca_out.tca_obj[tcai].length = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).length());

    ehytsi_output->tca_out.tca_obj[tcai].height = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).height());

    ehytsi_output->tca_out.tca_obj[tcai].phi_angle =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).phi_angle());

    ehytsi_output->tca_out.tca_obj[tcai].dphi_angle_rate =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).dphi_angle_rate());

    ehytsi_output->tca_out.tca_obj[tcai].fusion_source =
      static_cast<nio::ad::TgtFusionSrc>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).fusion_source()));

    ehytsi_output->tca_out.tca_obj[tcai].ttc = static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).ttc());

    ehytsi_output->tca_out.tca_obj[tcai].blinker_info =
      static_cast<nio::ad::BlinkerType>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).blinker_info()));

    ehytsi_output->tca_out.tca_obj[tcai].brake_lights =
      static_cast<uint32_t>(ehy_tsi_info->tca_out().tca_obj(tcai).brake_lights());

    ehytsi_output->tca_out.tca_obj[tcai].prob_lane_change =
      static_cast<float>(ehy_tsi_info->tca_out().tca_obj(tcai).prob_lane_change());

    ehytsi_output->tca_out.tca_obj[tcai].dirLaneChange =
      static_cast<nio::ad::TgtLaneChangeDir>(static_cast<int>(ehy_tsi_info->tca_out().tca_obj(tcai).dirlanechange()));
  }

  ehytsi_output->tca_out.valid_tgt_num = static_cast<uint32_t>(ehy_tsi_info->tca_out().valid_tgt_num());

  ehytsi_output->tsi_status = static_cast<uint32_t>(ehy_tsi_info->tsi_status());

  ehytsi_output->tsi_flg_cipvlost = static_cast<bool>(ehy_tsi_info->tsi_flg_cipvlost());

  ehytsi_output->tsi_ego_lane_changed = static_cast<bool>(ehy_tsi_info->tsi_ego_lane_changed());

  ehytsi_output->svc_frnt_obstacle_status = static_cast<uint32_t>(ehy_tsi_info->svc_frnt_obstacle_status());

  return true;
}

bool ARBInputAdapter::fill_ehy_tse_input(const std::shared_ptr<nio::ad::messages::EHYTseOutputs> ehy_tse_info,
                                         EHYTseOutputs*                                          ehytse_output) {
  int tse_size = MIN(ehy_tse_info->tse_obj().size(), 4);

  for (int tsei = 0; tsei < tse_size; tsei++) {
    ehytse_output->tse_obj[tsei].id = static_cast<uint32_t>(ehy_tse_info->tse_obj(tsei).id());

    ehytse_output->tse_obj[tsei].obj_index = static_cast<uint32_t>(ehy_tse_info->tse_obj(tsei).obj_index());

    ehytse_output->tse_obj[tsei].confidence = static_cast<uint32_t>(ehy_tse_info->tse_obj(tsei).confidence());

    ehytse_output->tse_obj[tsei].lon_pos_ccs = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_pos_ccs());

    ehytse_output->tse_obj[tsei].lon_pos_vcs = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_pos_vcs());

    ehytse_output->tse_obj[tsei].lon_pos_vcs_std = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_pos_vcs_std());

    ehytse_output->tse_obj[tsei].lon_vel = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_vel());

    ehytse_output->tse_obj[tsei].lon_vel_std = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_vel());

    ehytse_output->tse_obj[tsei].lon_acc = static_cast<float>(ehy_tse_info->tse_obj(tsei).lon_acc());

    ehytse_output->tse_obj[tsei].lat_pos_ccs = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_pos_ccs());

    ehytse_output->tse_obj[tsei].lat_pos_vcs = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_pos_vcs());

    ehytse_output->tse_obj[tsei].lat_pos_vcs_std = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_pos_vcs_std());

    ehytse_output->tse_obj[tsei].lat_vel = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_vel());

    ehytse_output->tse_obj[tsei].lat_vel_std = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_vel_std());

    ehytse_output->tse_obj[tsei].lat_acc = static_cast<float>(ehy_tse_info->tse_obj(tsei).lat_acc());

    ehytse_output->tse_obj[tsei].status =
      static_cast<nio::ad::TgtObjMotionStatus>(static_cast<int>(ehy_tse_info->tse_obj(tsei).status()));

    ehytse_output->tse_obj[tsei].type =
      static_cast<nio::ad::TgtObjType>(static_cast<int>(ehy_tse_info->tse_obj(tsei).type()));

    ehytse_output->tse_obj[tsei].valid =
      static_cast<nio::ad::TgtObjValidStatus>(static_cast<int>(ehy_tse_info->tse_obj(tsei).valid()));

    ehytse_output->tse_obj[tsei].age = static_cast<uint32_t>(ehy_tse_info->tse_obj(tsei).age());

    ehytse_output->tse_obj[tsei].width = static_cast<float>(ehy_tse_info->tse_obj(tsei).width());

    ehytse_output->tse_obj[tsei].length = static_cast<float>(ehy_tse_info->tse_obj(tsei).length());

    ehytse_output->tse_obj[tsei].height = static_cast<float>(ehy_tse_info->tse_obj(tsei).height());

    ehytse_output->tse_obj[tsei].phi_angle = static_cast<float>(ehy_tse_info->tse_obj(tsei).phi_angle());

    ehytse_output->tse_obj[tsei].dphi_angle_rate = static_cast<float>(ehy_tse_info->tse_obj(tsei).dphi_angle_rate());

    ehytse_output->tse_obj[tsei].fusion_source =
      static_cast<nio::ad::TgtFusionSrc>(static_cast<int>(ehy_tse_info->tse_obj(tsei).fusion_source()));

    ehytse_output->tse_obj[tsei].ttc = static_cast<float>(ehy_tse_info->tse_obj(tsei).ttc());

    ehytse_output->tse_obj[tsei].blinker_info =
      static_cast<nio::ad::BlinkerType>(static_cast<int>(ehy_tse_info->tse_obj(tsei).blinker_info()));

    ehytse_output->tse_obj[tsei].brake_lights = static_cast<uint32_t>(ehy_tse_info->tse_obj(tsei).brake_lights());

    ehytse_output->tse_obj[tsei].prob_lane_change = static_cast<float>(ehy_tse_info->tse_obj(tsei).prob_lane_change());

    ehytse_output->tse_obj[tsei].dirLaneChange =
      static_cast<nio::ad::TgtLaneChangeDir>(static_cast<int>(ehy_tse_info->tse_obj(tsei).dirlanechange()));
  }

  ehytse_output->tsi_flg_cipv_lost = static_cast<bool>(ehy_tse_info->tsi_flg_cipv_lost());

  return true;
}

bool ARBInputAdapter::fill_ehy_tsr_input(const std::shared_ptr<nio::ad::messages::EHYTsrOutputs> ehy_tsr_info,
                                         EHYTsrOutputs*                                          ehytsr_output) {
  ehytsr_output->idx_spd_lmt = static_cast<uint32_t>(ehy_tsr_info->idx_spd_lmt());

  ehytsr_output->st_op_sts = static_cast<uint32_t>(ehy_tsr_info->st_op_sts());

  ehytsr_output->idx_spd_lmt_unit = static_cast<uint32_t>(ehy_tsr_info->idx_spd_lmt_unit());
  return true;
}

bool ARBInputAdapter::fill_vis_obj_input(const std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs,
                                         EHYVisionObjects*                                          ehy_vis_obj) {
  // std::cout << "ARBInputAdapter_visobjupdate start"<<std::endl;
  ehy_vis_obj->timestamp = vis_obs->timestamp();

  ehy_vis_obj->obj_cnt   = vis_obs->dynamicobj().obj_info().obj_object_count();
  ehy_vis_obj->vru_cnt   = vis_obs->dynamicobj().obj_info().obj_vru_count();
  ehy_vis_obj->vd_cnt    = vis_obs->dynamicobj().obj_info().obj_vd_count();
  ehy_vis_obj->cipv_id   = vis_obs->dynamicobj().obj_info().obj_cipv_id();
  ehy_vis_obj->cipv_lost = vis_obs->dynamicobj().obj_info().obj_cipv_lost();
  ehy_vis_obj->is_cci    = vis_obs->dynamicobj().obj_info().obj_is_cci();
  ehy_vis_obj->cci_side  = (ObjCCISide)vis_obs->dynamicobj().obj_info().obj_cci_side();
  ehy_vis_obj->cci_id    = vis_obs->dynamicobj().obj_info().obj_cci_id();
  // ehy_vis_obj->cci_pos.x = vis_obs->dynamicobj().obj_info().obj_cut_in_long_distance();
  // ehy_vis_obj->cci_pos.y = vis_obs->dynamicobj().obj_info().obj_cut_in_lat_distance() * coordidirection;
  // ehy_vis_obj->cci_pos_std.x_std = vis_obs->dynamicobj().obj_info().obj_cut_in_long_distance_std();
  // ehy_vis_obj->cci_pos_std.y_std = vis_obs->dynamicobj().obj_info().obj_cut_in_lat_distance_std() * coordidirection;
  // ehy_vis_obj->cci_angle = vis_obs->dynamicobj().obj_info().obj_cut_in_angle() * coordidirection;
  // ehy_vis_obj->cci_angle_std = vis_obs->dynamicobj().obj_info().obj_cut_in_angle_std();

  int min_size = MIN(kNumVisionDynmicObjects, vis_obs->dynamicobj().obj_size());
  for (int v_i = 0; v_i < min_size; v_i++) {
    ehy_vis_obj->dynamic_obj[v_i].classification = (VisionDynObjClass)vis_obs->dynamicobj().obj(v_i).obj_object_class();
    ehy_vis_obj->dynamic_obj[v_i].age_frame      = vis_obs->dynamicobj().obj(v_i).obj_age_frame();
    ehy_vis_obj->dynamic_obj[v_i].ID             = vis_obs->dynamicobj().obj(v_i).obj_object_id();
    ehy_vis_obj->dynamic_obj[v_i].color          = (VisionDynObjColor)vis_obs->dynamicobj().obj(v_i).obj_color();
    ehy_vis_obj->dynamic_obj[v_i].exist_prob     = vis_obs->dynamicobj().obj(v_i).obj_existence_probability();
    ehy_vis_obj->dynamic_obj[v_i].is_very_close  = vis_obs->dynamicobj().obj(v_i).obj_is_very_close();
    // ehy_vis_obj->dynamic_obj[v_i].ttc = vis_obs->dynamicobj().obj(v_i).obj_inv_ttc();
    ehy_vis_obj->dynamic_obj[v_i].lane_assign =
      (VisionDynObjLaneAssign)vis_obs->dynamicobj().obj(v_i).obj_lane_assignment();
    ehy_vis_obj->dynamic_obj[v_i].mesure_st =
      (VisionDynObjMeasureSt)vis_obs->dynamicobj().obj(v_i).obj_measuring_status();
    ehy_vis_obj->dynamic_obj[v_i].motion_st = (VisionDynObjMotionSt)vis_obs->dynamicobj().obj(v_i).obj_motion_status();
    ehy_vis_obj->dynamic_obj[v_i].motion_category =
      (VisionDynObjMotionCategory)vis_obs->dynamicobj().obj(v_i).obj_motion_category();
    ehy_vis_obj->dynamic_obj[v_i].is_blocked_parts = vis_obs->dynamicobj().obj(v_i).obj_is_blocked_parts();
    ehy_vis_obj->dynamic_obj[v_i].brake_light =
      (VisionDynObjBrakeLight)vis_obs->dynamicobj().obj(v_i).obj_brake_light();
    ehy_vis_obj->dynamic_obj[v_i].turn_indicator =
      (VisionDynObjTurnIndicator)vis_obs->dynamicobj().obj(v_i).obj_turn_indicator();
    ehy_vis_obj->dynamic_obj[v_i].hb_st = (VisionDynObjHBSt)vis_obs->dynamicobj().obj(v_i).obj_hb_status();
    // ehy_vis_obj->dynamic_obj[v_i].cut_angle = vis_obs->dynamicobj().obj(v_i).obj_cut_angle() * coordidirection;
    // ehy_vis_obj->dynamic_obj[v_i].cut_dst = vis_obs->dynamicobj().obj(v_i).obj_cut_distance();

    ehy_vis_obj->dynamic_obj[v_i].dst_left_line    = vis_obs->dynamicobj().obj(v_i).obj_dst_left_line();
    ehy_vis_obj->dynamic_obj[v_i].dst_right_line   = vis_obs->dynamicobj().obj(v_i).obj_dst_right_line();
    ehy_vis_obj->dynamic_obj[v_i].is_blocked_left  = vis_obs->dynamicobj().obj(v_i).obj_is_blocked_left();
    ehy_vis_obj->dynamic_obj[v_i].is_blocked_right = vis_obs->dynamicobj().obj(v_i).obj_is_blocked_right();

    // ehy_vis_obj->dynamic_obj[v_i].angle.angle_left = vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_left() *
    // coordidirection; ehy_vis_obj->dynamic_obj[v_i].angle.angle_right =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_right() * coordidirection;
    // ehy_vis_obj->dynamic_obj[v_i].angle.angle_middle = vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_middle()
    // * coordidirection; ehy_vis_obj->dynamic_obj[v_i].angle.angle_side =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_side() * coordidirection;

    // ehy_vis_obj->dynamic_obj[v_i].angle_std.angle_left_std =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_left_std() * coordidirection;
    // ehy_vis_obj->dynamic_obj[v_i].angle_std.angle_right_std =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_right_std() * coordidirection;
    // ehy_vis_obj->dynamic_obj[v_i].angle_std.angle_middle_std =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_middle_std() * coordidirection;
    // ehy_vis_obj->dynamic_obj[v_i].angle_std.angle_side_std =
    // vis_obs->dynamicobj().obj(v_i).obj_angle().obj_angle_side_std() * coordidirection;

    ehy_vis_obj->dynamic_obj[v_i].motion.pos.x = vis_obs->dynamicobj().obj(v_i).obj_distance().long_position();
    ehy_vis_obj->dynamic_obj[v_i].motion.pos.y =
      vis_obs->dynamicobj().obj(v_i).obj_distance().lat_position() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.vel.vx = vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().long_velocity();
    ehy_vis_obj->dynamic_obj[v_i].motion.vel.vy =
      vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().lat_velocity() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.vel.vz = vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().up_velocity();
    ehy_vis_obj->dynamic_obj[v_i].motion.acc.ax = vis_obs->dynamicobj().obj(v_i).obj_abs_acc().long_acc();
    ehy_vis_obj->dynamic_obj[v_i].motion.acc.ay =
      vis_obs->dynamicobj().obj(v_i).obj_abs_acc().lat_acc() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.acc.az     = vis_obs->dynamicobj().obj(v_i).obj_abs_acc().up_acc();
    ehy_vis_obj->dynamic_obj[v_i].motion.heading    = vis_obs->dynamicobj().obj(v_i).obj_heading() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.angle_rate = vis_obs->dynamicobj().obj(v_i).obj_angle_rate() * coordidirection;

    ehy_vis_obj->dynamic_obj[v_i].motion.pos_std.x_std =
      vis_obs->dynamicobj().obj(v_i).obj_distance().long_position_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.pos_std.y_std =
      vis_obs->dynamicobj().obj(v_i).obj_distance().lat_position_std() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.vel_std.vx_std =
      vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().long_velocity_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.vel_std.vy_std =
      vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().lat_velocity_std() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.vel_std.vz_std =
      vis_obs->dynamicobj().obj(v_i).obj_abs_velocity().up_velocity_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.acc_std.ax_std = vis_obs->dynamicobj().obj(v_i).obj_abs_acc().long_acc_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.acc_std.ay_std =
      vis_obs->dynamicobj().obj(v_i).obj_abs_acc().lat_acc_std() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.acc_std.az_std = vis_obs->dynamicobj().obj(v_i).obj_abs_acc().up_acc_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.heading_std =
      vis_obs->dynamicobj().obj(v_i).obj_heading_std() * coordidirection;
    ehy_vis_obj->dynamic_obj[v_i].motion.angle_rate_std =
      vis_obs->dynamicobj().obj(v_i).obj_angle_rate_std() * coordidirection;

    ehy_vis_obj->dynamic_obj[v_i].motion.size.length = vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_length();
    ehy_vis_obj->dynamic_obj[v_i].motion.size.width  = vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_width();
    ehy_vis_obj->dynamic_obj[v_i].motion.size.height = vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_height();

    ehy_vis_obj->dynamic_obj[v_i].motion.size_std.length_std =
      vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_length_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.size_std.width_std =
      vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_width_std();
    ehy_vis_obj->dynamic_obj[v_i].motion.size_std.height_std =
      vis_obs->dynamicobj().obj(v_i).obj_dimension().obj_height_std();

    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.left_bottom_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_left_bottom_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.left_bottom_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_left_bottom_pixel_y();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.left_top_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_left_top_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.left_top_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_left_top_pixel_y();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.right_bottom_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_right_bottom_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.right_bottom_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_right_bottom_pixel_y();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.right_top_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_right_top_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.right_top_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_right_top_pixel_y();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.side_bottom_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_side_bottom_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.side_bottom_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_side_bottom_pixel_y();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.side_top_x =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_side_top_pixel_x();
    // ehy_vis_obj->dynamic_obj[v_i].pixel_pos.side_top_y =
    // vis_obs->dynamicobj().obj(v_i).obj_pixel().obj_side_top_pixel_y();

    // ehy_vis_obj->dynamic_obj[v_i].plate_info.color =
    // (VisionObjPlateColor)vis_obs->dynamicobj().obj(v_i).obj_plate().obj_plate_color();
    // ehy_vis_obj->dynamic_obj[v_i].plate_info.number = vis_obs->dynamicobj().obj(v_i).obj_plate().obj_plate_number();
    // ehy_vis_obj->dynamic_obj[v_i].plate_info.dst = vis_obs->dynamicobj().obj(v_i).obj_plate().obj_plate_distance();
    // ehy_vis_obj->dynamic_obj[v_i].plate_info.dst_std =
    // vis_obs->dynamicobj().obj(v_i).obj_plate().obj_plate_distance_std();
  }
  min_size = MIN(kNumVisionStaticObjects, vis_obs->staticobj_size());
  for (int v_i = 0; v_i < min_size; v_i++) {
    ehy_vis_obj->static_obj[v_i].age                  = vis_obs->staticobj(v_i).obs_age();
    ehy_vis_obj->static_obj[v_i].ID                   = vis_obs->staticobj(v_i).obs_id();
    ehy_vis_obj->static_obj[v_i].type                 = (VisionStaticObsType)vis_obs->staticobj(v_i).obs_type();
    ehy_vis_obj->static_obj[v_i].type_prob            = vis_obs->staticobj(v_i).obs_type_probability();
    ehy_vis_obj->static_obj[v_i].motion.pos.x         = vis_obs->staticobj(v_i).obs_long_distance();
    ehy_vis_obj->static_obj[v_i].motion.pos.y         = vis_obs->staticobj(v_i).obs_lat_distance() * coordidirection;
    ehy_vis_obj->static_obj[v_i].motion.pos_std.x_std = vis_obs->staticobj(v_i).obs_long_distance_std();
    ehy_vis_obj->static_obj[v_i].motion.pos_std.y_std =
      vis_obs->staticobj(v_i).obs_lat_distance_std() * coordidirection;
    ehy_vis_obj->static_obj[v_i].motion.size.length         = vis_obs->staticobj(v_i).obs_object_length();
    ehy_vis_obj->static_obj[v_i].motion.size.width          = vis_obs->staticobj(v_i).obs_object_width();
    ehy_vis_obj->static_obj[v_i].motion.size.height         = vis_obs->staticobj(v_i).obs_object_height();
    ehy_vis_obj->static_obj[v_i].motion.size_std.length_std = vis_obs->staticobj(v_i).obs_object_length_std();
    ehy_vis_obj->static_obj[v_i].motion.size_std.width_std  = vis_obs->staticobj(v_i).obs_object_width_std();
    ehy_vis_obj->static_obj[v_i].motion.size_std.height_std = vis_obs->staticobj(v_i).obs_object_height_std();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_valid = vis_obs->staticobj(v_i).obs_indicator_arrow_detected();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_pos.x = vis_obs->staticobj(v_i).obs_indicator_arrow_long_dist();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_pos.y = vis_obs->staticobj(v_i).obs_indicator_arrow_lat_dist();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_mot_st =
    // (VisionObjIndicatorArrowMotionStatus)vis_obs->staticobj(v_i).obs_indicator_arrow_motion_status();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_st =
    // (VisionObjIndicatorArrowStatus)vis_obs->staticobj(v_i).obs_indicator_arrow_status();
    // ehy_vis_obj->static_obj[v_i].indicator_arrow_dir =
    // (VisionObjIndicatorArrowDir)vis_obs->staticobj(v_i).obs_indicator_arrow_direction();
  }
  // std::cout << "ARBInputAdapter_visobj start"<<std::endl;

  return true;
}

bool ARBInputAdapter::fill_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> vis_road,
                                          EHYVisionRoad*                                          ehy_vis_road) {
  // std::cout << "ARBInputAdapter_roadinput start"<<std::endl;

  // Guide point info fill in
  ehy_vis_road->guide_point.intp_is_highway_merge_left  = vis_road->guidepoint().intp_is_highway_merge_left();
  ehy_vis_road->guide_point.intp_is_highway_merge_right = vis_road->guidepoint().intp_is_highway_merge_right();
  ehy_vis_road->guide_point.intp_is_highway_exit_left   = vis_road->guidepoint().intp_is_highway_exit_left();
  ehy_vis_road->guide_point.intp_is_highway_exit_right  = vis_road->guidepoint().intp_is_highway_exit_right();
  for (int i_pt = 0; i_pt < vis_road->guidepoint().intp_point_size(); ++i_pt) {
    // ehy input struct predefined with max 10 intersting points
    if (i_pt < kNumVisionIntPoint) {
      ehy_vis_road->guide_point.intp_point[i_pt].type = (IntPtType)vis_road->guidepoint().intp_point(i_pt).intp_type();
      ehy_vis_road->guide_point.intp_point[i_pt].age  = vis_road->guidepoint().intp_point(i_pt).intp_age();
      ehy_vis_road->guide_point.intp_point[i_pt].exist_prob =
        vis_road->guidepoint().intp_point(i_pt).intp_exist_probability();
      ehy_vis_road->guide_point.intp_point[i_pt].ID = vis_road->guidepoint().intp_point(i_pt).intp_id();
      ehy_vis_road->guide_point.intp_point[i_pt].int_point.lat =
        vis_road->guidepoint().intp_point(i_pt).intp_lat_distance();
      ehy_vis_road->guide_point.intp_point[i_pt].int_point.lon =
        vis_road->guidepoint().intp_point(i_pt).intp_long_distance();
      ehy_vis_road->guide_point.intp_point[i_pt].line_role =
        (IntPtLineRole)vis_road->guidepoint().intp_point(i_pt).intp_line_role();
    }
  }

  // Lane info fill in
  ehy_vis_road->lane.crossing_flag   = vis_road->laneline().ld_crossing_flag();
  ehy_vis_road->lane.host_lane_width = vis_road->laneline().ld_lane_width();
  for (int i_line = 0; i_line < vis_road->laneline().line_size(); ++i_line) {
    // ehy input struct predefined with max 8 lines
    if (i_line < kNumVisionLaneMarker) {
      ehy_vis_road->lane.lines[i_line].confidence          = vis_road->laneline().line(i_line).ld_confidence();
      ehy_vis_road->lane.lines[i_line].crossing            = vis_road->laneline().line(i_line).ld_crossing();
      ehy_vis_road->lane.lines[i_line].crossing_ID         = vis_road->laneline().line(i_line).ld_crossing_id();
      ehy_vis_road->lane.lines[i_line].dash_average_gap    = vis_road->laneline().line(i_line).ld_dash_average_gap();
      ehy_vis_road->lane.lines[i_line].dash_average_length = vis_road->laneline().line(i_line).ld_dash_average_length();
      ehy_vis_road->lane.lines[i_line].first_line.color =
        (LDColor)vis_road->laneline().line(i_line).ld_first_line().ld_color();
      ehy_vis_road->lane.lines[i_line].first_line.type =
        (LDType)vis_road->laneline().line(i_line).ld_first_line().ld_type();
      ehy_vis_road->lane.lines[i_line].first_line.start = vis_road->laneline().line(i_line).ld_first_line().ld_start();
      ehy_vis_road->lane.lines[i_line].first_line.end   = vis_road->laneline().line(i_line).ld_first_line().ld_end();
      ehy_vis_road->lane.lines[i_line].first_line.end_reason =
        (LDEndReason)vis_road->laneline().line(i_line).ld_first_line().ld_end_reason();
      ehy_vis_road->lane.lines[i_line].first_line.line.c0 =
        vis_road->laneline().line(i_line).ld_first_line().ld_line().line_c0() * coordidirection;
      ehy_vis_road->lane.lines[i_line].first_line.line.c1 =
        vis_road->laneline().line(i_line).ld_first_line().ld_line().line_c1() * coordidirection;
      ehy_vis_road->lane.lines[i_line].first_line.line.c2 =
        vis_road->laneline().line(i_line).ld_first_line().ld_line().line_c2() * coordidirection;
      ehy_vis_road->lane.lines[i_line].first_line.line.c3 =
        vis_road->laneline().line(i_line).ld_first_line().ld_line().line_c3() * coordidirection;
      ehy_vis_road->lane.lines[i_line].second_line.color =
        (LDColor)vis_road->laneline().line(i_line).ld_second_line().ld_color();
      ehy_vis_road->lane.lines[i_line].second_line.type =
        (LDType)vis_road->laneline().line(i_line).ld_second_line().ld_type();
      ehy_vis_road->lane.lines[i_line].second_line.start =
        vis_road->laneline().line(i_line).ld_second_line().ld_start();
      ehy_vis_road->lane.lines[i_line].second_line.end = vis_road->laneline().line(i_line).ld_second_line().ld_end();
      ehy_vis_road->lane.lines[i_line].second_line.end_reason =
        (LDEndReason)vis_road->laneline().line(i_line).ld_second_line().ld_end_reason();
      ehy_vis_road->lane.lines[i_line].second_line.line.c0 =
        vis_road->laneline().line(i_line).ld_second_line().ld_line().line_c0() * coordidirection;
      ehy_vis_road->lane.lines[i_line].second_line.line.c1 =
        vis_road->laneline().line(i_line).ld_second_line().ld_line().line_c1() * coordidirection;
      ehy_vis_road->lane.lines[i_line].second_line.line.c2 =
        vis_road->laneline().line(i_line).ld_second_line().ld_line().line_c2() * coordidirection;
      ehy_vis_road->lane.lines[i_line].second_line.line.c3 =
        vis_road->laneline().line(i_line).ld_second_line().ld_line().line_c3() * coordidirection;
      ehy_vis_road->lane.lines[i_line].is_multi_clothoid = vis_road->laneline().line(i_line).ld_is_multi_clothoid();
      ehy_vis_road->lane.lines[i_line].marker_width      = vis_road->laneline().line(i_line).ld_marker_width();
      ehy_vis_road->lane.lines[i_line].measure_status =
        (LDMeasureStatus)vis_road->laneline().line(i_line).ld_measuring_status();
      ehy_vis_road->lane.lines[i_line].is_multi_clothoid = vis_road->laneline().line(i_line).ld_is_multi_clothoid();
      // for (int i_pix_pt = 0; i_pix_pt < vis_road->laneline().line(i_line).ld_pixel_point_size(); ++i_pix_pt)
      // {
      //     // ehy input struct predefined pixel point size is 300
      //     if (i_pix_pt < kNumVisionLaneMarkerPoint)
      //     {
      //         ehy_vis_road->lane.lines[i_line].pixel_point[i_pix_pt].lat =
      //         vis_road->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_lat();
      //         ehy_vis_road->lane.lines[i_line].pixel_point[i_pix_pt].lon =
      //         vis_road->laneline().line(i_line).ld_pixel_point(i_pix_pt).ld_point_long();
      //     }
      // }
      for (int i_line_pt = 0; i_line_pt < vis_road->laneline().line(i_line).ld_point_size(); ++i_line_pt) {
        // ehy input struct predefined point size is 300
        if (i_line_pt < kNumVisionLaneMarkerPoint) {
          ehy_vis_road->lane.lines[i_line].point[i_line_pt].lat =
            vis_road->laneline().line(i_line).ld_point(i_line_pt).ld_point_lat();
          ehy_vis_road->lane.lines[i_line].point[i_line_pt].lon =
            vis_road->laneline().line(i_line).ld_point(i_line_pt).ld_point_long();
        }
      }
      ehy_vis_road->lane.lines[i_line].predict_reason =
        (LDPredictReason)vis_road->laneline().line(i_line).ld_prediction_reason();
      ehy_vis_road->lane.lines[i_line].quality = (LDQuality)vis_road->laneline().line(i_line).ld_quality();
      ehy_vis_road->lane.lines[i_line].role    = (LDRole)vis_road->laneline().line(i_line).ld_role();

      // ehy_vis_road->lane.lines[i_line].source = (LDCameraSource)vis_road->laneline().line(i_line).ld_camera_source();
      ehy_vis_road->lane.lines[i_line].special_point.lat =
        vis_road->laneline().line(i_line).ld_special_point().ld_point_lat();
      ehy_vis_road->lane.lines[i_line].special_point.lon =
        vis_road->laneline().line(i_line).ld_special_point().ld_point_long();
      ehy_vis_road->lane.lines[i_line].special_point_is_detected =
        vis_road->laneline().line(i_line).ld_special_point_is_detected();
      ehy_vis_road->lane.lines[i_line].special_point_type =
        (LDSpecialPointType)vis_road->laneline().line(i_line).ld_special_point_type();
      ehy_vis_road->lane.lines[i_line].track_age = vis_road->laneline().line(i_line).ld_track_age();
      ehy_vis_road->lane.lines[i_line].track_ID  = vis_road->laneline().line(i_line).ld_track_id();
    }
  }

  // Semantic lane info fill in
  for (int i_semantic = 0; i_semantic < vis_road->lanesemantic_size(); ++i_semantic) {
    if (i_semantic < kNumVisionSemanticLane) {
      ehy_vis_road->lane_semantic[i_semantic].ID  = vis_road->lanesemantic(i_semantic).sld_id();
      ehy_vis_road->lane_semantic[i_semantic].cnt = vis_road->lanesemantic(i_semantic).sld_count();
      ehy_vis_road->lane_semantic[i_semantic].dir = (LaneSemanDir)vis_road->lanesemantic(i_semantic).sld_direction();
      ehy_vis_road->lane_semantic[i_semantic].point.lat =
        vis_road->lanesemantic(i_semantic).sld_lat() * coordidirection;
      ehy_vis_road->lane_semantic[i_semantic].point.lon = vis_road->lanesemantic(i_semantic).sld_long();
      ehy_vis_road->lane_semantic[i_semantic].dir_prob = vis_road->lanesemantic(i_semantic).sld_direction_probability();
      ehy_vis_road->lane_semantic[i_semantic].orientation =
        (LaneSemanOrientation)vis_road->lanesemantic(i_semantic).sld_orientation();
      ehy_vis_road->lane_semantic[i_semantic].orientation_prob =
        vis_road->lanesemantic(i_semantic).sld_orientation_probability();
      ehy_vis_road->lane_semantic[i_semantic].road_st =
        (LaneSemanRoadSt)vis_road->lanesemantic(i_semantic).sld_road_status();
      ehy_vis_road->lane_semantic[i_semantic].role = (LaneSemanRole)vis_road->lanesemantic(i_semantic).sld_role();
      ehy_vis_road->lane_semantic[i_semantic].type = (LaneSemanType)vis_road->lanesemantic(i_semantic).sld_type();
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[0].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_lat_0() * coordidirection;
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[0].lon =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_long_0();
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[1].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_lat_1() * coordidirection;
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[1].lon =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_long_1();
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[2].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_lat_2() * coordidirection;
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[2].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_long_2();
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[3].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_lat_3() * coordidirection;
      ehy_vis_road->lane_semantic[i_semantic].no_park_zone[3].lat =
        vis_road->lanesemantic(i_semantic).sld_no_park_zone_long_3();
    }
  }

  // LPP infor fill in
  ehy_vis_road->lpp.source             = (LPPSource)vis_road->lpp().lpp_source();
  ehy_vis_road->lpp.available          = vis_road->lpp().lpp_available();
  ehy_vis_road->lpp.confidence         = vis_road->lpp().lpp_confidence();
  ehy_vis_road->lpp.first_line.c0      = vis_road->lpp().lpp_first().line_c0() * coordidirection;
  ehy_vis_road->lpp.first_line.c1      = vis_road->lpp().lpp_first().line_c1() * coordidirection;
  ehy_vis_road->lpp.first_line.c2      = vis_road->lpp().lpp_first().line_c2() * coordidirection;
  ehy_vis_road->lpp.first_line.c3      = vis_road->lpp().lpp_first().line_c3() * coordidirection;
  ehy_vis_road->lpp.first_valid        = vis_road->lpp().lpp_first_valid();
  ehy_vis_road->lpp.first_vr_end       = vis_road->lpp().lpp_first_vr_end();
  ehy_vis_road->lpp.lpp_ctrl_point.lat = vis_road->lpp().lpp_ctrl_point_lat() * coordidirection;
  ehy_vis_road->lpp.lpp_ctrl_point.lon = vis_road->lpp().lpp_ctrl_point_long();
  ehy_vis_road->lpp.second_line.c0     = vis_road->lpp().lpp_second().line_c0() * coordidirection;
  ehy_vis_road->lpp.second_line.c1     = vis_road->lpp().lpp_second().line_c1() * coordidirection;
  ehy_vis_road->lpp.second_line.c2     = vis_road->lpp().lpp_second().line_c2() * coordidirection;
  ehy_vis_road->lpp.second_line.c3     = vis_road->lpp().lpp_second().line_c3() * coordidirection;
  ehy_vis_road->lpp.second_valid       = vis_road->lpp().lpp_second_valid();
  ehy_vis_road->lpp.second_vr_end      = vis_road->lpp().lpp_second_vr_end();

  // Road edge infor fill in
  for (int i_road_edg = 0; i_road_edg < vis_road->roadedge_size(); ++i_road_edg) {
    if (i_road_edg < kNumVisionRoadEdge) {
      ehy_vis_road->road_edge[i_road_edg].ID     = vis_road->roadedge(i_road_edg).ld_re_id();
      ehy_vis_road->road_edge[i_road_edg].age    = vis_road->roadedge(i_road_edg).ld_re_age();
      ehy_vis_road->road_edge[i_road_edg].type   = (RoadEdgeType)vis_road->roadedge(i_road_edg).ld_re_type();
      ehy_vis_road->road_edge[i_road_edg].height = vis_road->roadedge(i_road_edg).ld_re_height();
      ehy_vis_road->road_edge[i_road_edg].host_index =
        (RoadEdgeFromHostIndex)vis_road->roadedge(i_road_edg).ld_re_from_host_index();
      ehy_vis_road->road_edge[i_road_edg].side  = (RoadEdgeSide)vis_road->roadedge(i_road_edg).ld_re_side();
      ehy_vis_road->road_edge[i_road_edg].start = vis_road->roadedge(i_road_edg).ld_re_vr_start();
      ehy_vis_road->road_edge[i_road_edg].end   = vis_road->roadedge(i_road_edg).ld_re_vr_end();
      ehy_vis_road->road_edge[i_road_edg].line.c0 =
        vis_road->roadedge(i_road_edg).ld_re_line().line_c0() * coordidirection;
      ehy_vis_road->road_edge[i_road_edg].line.c1 =
        vis_road->roadedge(i_road_edg).ld_re_line().line_c1() * coordidirection;
      ehy_vis_road->road_edge[i_road_edg].line.c2 =
        vis_road->roadedge(i_road_edg).ld_re_line().line_c2() * coordidirection;
      ehy_vis_road->road_edge[i_road_edg].line.c3 =
        vis_road->roadedge(i_road_edg).ld_re_line().line_c3() * coordidirection;
    }
  }

  // Slop info fill in
  ehy_vis_road->slop.vertical_surface_available = vis_road->slop().ld_road_vertical_surface_available();
  ehy_vis_road->slop.vertical_surface.c0    = vis_road->slop().ld_road_vertical_surface().line_c0() * coordidirection;
  ehy_vis_road->slop.vertical_surface.c1    = vis_road->slop().ld_road_vertical_surface().line_c1() * coordidirection;
  ehy_vis_road->slop.vertical_surface.c2    = vis_road->slop().ld_road_vertical_surface().line_c2() * coordidirection;
  ehy_vis_road->slop.vertical_surface.c3    = vis_road->slop().ld_road_vertical_surface().line_c3() * coordidirection;
  ehy_vis_road->slop.vertical_surface_start = vis_road->slop().ld_road_vertical_surface_start();
  ehy_vis_road->slop.vertical_surface_end   = vis_road->slop().ld_road_vertical_surface_end();

  // Stop line info fill in
  for (int i_stop_line = 0; i_stop_line < vis_road->stopline_size(); ++i_stop_line) {
    if (i_stop_line < kNumVisionStopLine) {
      ehy_vis_road->stop_line[i_stop_line].SL_ID = vis_road->stopline(i_stop_line).sl_id();
      // ehy_vis_road->stop_line[i_stop_line].SL_detect_camera =
      // (SLDetectCamera)vis_road->stopline(i_stop_line).sl_detecting_camera();
      ehy_vis_road->stop_line[i_stop_line].SL_is_detected = vis_road->stopline(i_stop_line).sl_is_detected();
      ehy_vis_road->stop_line[i_stop_line].SL_lane_assessment =
        (SLLaneAssessment)vis_road->stopline(i_stop_line).sl_lane_assessment();
      ehy_vis_road->stop_line[i_stop_line].SL_left.lat =
        vis_road->stopline(i_stop_line).sl_lat_dist_l() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].SL_left.lon = vis_road->stopline(i_stop_line).sl_long_dist_l();
      ehy_vis_road->stop_line[i_stop_line].SL_right.lat =
        vis_road->stopline(i_stop_line).sl_lat_dist_r() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].SL_right.lon = vis_road->stopline(i_stop_line).sl_long_dist_r();
      ehy_vis_road->stop_line[i_stop_line].SL_measure_st =
        (SLMeasureSt)vis_road->stopline(i_stop_line).sl_measure_status();
      ehy_vis_road->stop_line[i_stop_line].SL_prob = vis_road->stopline(i_stop_line).sl_probability();
      ehy_vis_road->stop_line[i_stop_line].SL_type = (SLType)vis_road->stopline(i_stop_line).sl_type();
      // ehy_vis_road->stop_line[i_stop_line].SL_width = vis_road->stopline(i_stop_line).sl_width();
      ehy_vis_road->stop_line[i_stop_line].zebra_is_detected = vis_road->stopline(i_stop_line).sl_zebra_is_detected();
      ehy_vis_road->stop_line[i_stop_line].zebra_point[0].lat =
        vis_road->stopline(i_stop_line).sl_zebra_lat_0() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].zebra_point[0].lon = vis_road->stopline(i_stop_line).sl_zebra_long_0();
      ehy_vis_road->stop_line[i_stop_line].zebra_point[1].lat =
        vis_road->stopline(i_stop_line).sl_zebra_lat_1() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].zebra_point[1].lon = vis_road->stopline(i_stop_line).sl_zebra_long_1();
      ehy_vis_road->stop_line[i_stop_line].zebra_point[2].lat =
        vis_road->stopline(i_stop_line).sl_zebra_lat_2() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].zebra_point[2].lon = vis_road->stopline(i_stop_line).sl_zebra_long_2();
      ehy_vis_road->stop_line[i_stop_line].zebra_point[3].lat =
        vis_road->stopline(i_stop_line).sl_zebra_lat_3() * coordidirection;
      ehy_vis_road->stop_line[i_stop_line].zebra_point[3].lon = vis_road->stopline(i_stop_line).sl_zebra_long_3();
    }
  }

  ehy_vis_road->timestamp = vis_road->timestamp();
  // std::cout << "ARBInputAdapter_roadinput complete"<<std::endl;
  return true;
}

bool ARBInputAdapter::fill_rdr_input(const std::shared_ptr<nio::ad::messages::RadarSensor> rdr_info,
                                     EHYRadarSensor*                                       ehy_rdr_sensor) {
  // std::cout << "ARBInputAdapter_rdrinput start"<<std::endl;

  // Update host information
  ehy_rdr_sensor->ego_spd_ms  = rdr_info->ego_speed();
  ehy_rdr_sensor->ego_yawrate = rdr_info->ego_yawrate();
  ehy_rdr_sensor->ego_acc     = rdr_info->ego_acc();

  // Update radar status info
  for (int i_rdr = 0; i_rdr < rdr_info->status_size(); ++i_rdr) {
    // currently there are 5 radars defined in the radar sensor array
    if (i_rdr < kNumRdrAptiv) {
      ehy_rdr_sensor->radar_st[i_rdr].flg_blindness         = rdr_info->status(i_rdr).flg_blindness();
      ehy_rdr_sensor->radar_st[i_rdr].flg_failure           = rdr_info->status(i_rdr).flg_failure();
      ehy_rdr_sensor->radar_st[i_rdr].flg_loss_comm_fault   = rdr_info->status(i_rdr).flg_loss_comm_fault();
      ehy_rdr_sensor->radar_st[i_rdr].flg_timestamp_invalid = rdr_info->status(i_rdr).flg_time_stamp_invalid();
    }
  }

  // Update radar detection information
  int number_of_sensor = rdr_info->detection_points_size();
  int total_det_cnt    = 0;

  for (int i_sensors = 0; i_sensors < number_of_sensor; ++i_sensors) {
    int number_of_det = rdr_info->detection_points(i_sensors).detection_size();
    total_det_cnt += number_of_det;
    for (int j_det = 0; j_det < number_of_det; ++j_det) {
      int det_idx = total_det_cnt - number_of_det + j_det;
      if (total_det_cnt < kNumRdrDetectionAptiv) {
        ehy_rdr_sensor->detection.det_point[det_idx].azimuth =
          rdr_info->detection_points(i_sensors).detection(j_det).azimuth();
        ehy_rdr_sensor->detection.det_point[det_idx].azimuth_conf =
          rdr_info->detection_points(i_sensors).detection(j_det).azimuth_conf();
        ehy_rdr_sensor->detection.det_point[det_idx].range =
          rdr_info->detection_points(i_sensors).detection(j_det).range();
        ehy_rdr_sensor->detection.det_point[det_idx].range_rate =
          rdr_info->detection_points(i_sensors).detection(j_det).range_rate();
        ehy_rdr_sensor->detection.det_point[det_idx].elevation_angle =
          rdr_info->detection_points(i_sensors).detection(j_det).elevation_angle();
        ehy_rdr_sensor->detection.det_point[det_idx].elevation_conf =
          rdr_info->detection_points(i_sensors).detection(j_det).elevation_conf();
        ehy_rdr_sensor->detection.det_point[det_idx].radar_cross_section =
          rdr_info->detection_points(i_sensors).detection(j_det).radar_cross_section();
        ehy_rdr_sensor->detection.det_point[det_idx].exist_prob =
          rdr_info->detection_points(i_sensors).detection(j_det).exist_prob();
      }
    }
    ehy_rdr_sensor->detection.timestamp[i_sensors] = rdr_info->detection_points(i_sensors).timestamp();
  }
  // Update radar object information

  // int number_of_tracker_sources = rdr_info->trackers_size();
  // Current aptiv report all radar sensor objects at once , no need to loop number_of_tracker_sources
  // std::cout << " in proto, radar obj size is " << (int)rdr_info->trackers(0).objects_size() << std::endl;

  for (int i_obj = 0; i_obj < kNumRdrObjectsAptiv; ++i_obj) {
    if (i_obj < rdr_info->trackers(0).objects_size()) {
      ehy_rdr_sensor->tracker.objects[i_obj].age          = rdr_info->trackers(0).objects(i_obj).age();
      ehy_rdr_sensor->tracker.objects[i_obj].source       = rdr_info->trackers(0).objects(i_obj).source();
      ehy_rdr_sensor->tracker.objects[i_obj].confidence   = rdr_info->trackers(0).objects(i_obj).conf();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos.x = rdr_info->trackers(0).objects(i_obj).motion().pos().x();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos.y = rdr_info->trackers(0).objects(i_obj).motion().pos().y();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos.z = rdr_info->trackers(0).objects(i_obj).motion().pos().z();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos_std.x_std =
        rdr_info->trackers(0).objects(i_obj).motion().pos_std().x_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos_std.y_std =
        rdr_info->trackers(0).objects(i_obj).motion().pos_std().y_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.pos_std.z_std =
        rdr_info->trackers(0).objects(i_obj).motion().pos_std().z_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel.vx = rdr_info->trackers(0).objects(i_obj).motion().vel().vx();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel.vy = rdr_info->trackers(0).objects(i_obj).motion().vel().vy();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel.vz = rdr_info->trackers(0).objects(i_obj).motion().vel().vz();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel_std.vx_std =
        rdr_info->trackers(0).objects(i_obj).motion().vel_std().vx_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel_std.vy_std =
        rdr_info->trackers(0).objects(i_obj).motion().vel_std().vy_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.vel_std.vz_std =
        rdr_info->trackers(0).objects(i_obj).motion().vel_std().vz_std();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.acc.ax = rdr_info->trackers(0).objects(i_obj).motion().acc().ax();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.acc.ay = rdr_info->trackers(0).objects(i_obj).motion().acc().ay();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.acc.az = rdr_info->trackers(0).objects(i_obj).motion().acc().az();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.size.length =
        rdr_info->trackers(0).objects(i_obj).motion().size().length();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.size.width =
        rdr_info->trackers(0).objects(i_obj).motion().size().width();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.size.height =
        rdr_info->trackers(0).objects(i_obj).motion().size().height();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.heading = rdr_info->trackers(0).objects(i_obj).motion().heading();
      ehy_rdr_sensor->tracker.objects[i_obj].motion.angle_rate     = 0;
      ehy_rdr_sensor->tracker.objects[i_obj].motion.heading_std    = 0;
      ehy_rdr_sensor->tracker.objects[i_obj].motion.angle_rate_std = 0;
      ehy_rdr_sensor->tracker.objects[i_obj].ref_point =
        (ReferPoint)rdr_info->trackers(0).objects(i_obj).motion().ref_point();
      ehy_rdr_sensor->tracker.objects[i_obj].motion_st.is_valid =
        rdr_info->trackers(0).objects(i_obj).motion_state().is_valid();
      ehy_rdr_sensor->tracker.objects[i_obj].motion_st.is_moving =
        rdr_info->trackers(0).objects(i_obj).motion_state().is_moving();
      ehy_rdr_sensor->tracker.objects[i_obj].motion_st.is_movable =
        rdr_info->trackers(0).objects(i_obj).motion_state().is_movable();
      ehy_rdr_sensor->tracker.objects[i_obj].motion_st.direction =
        rdr_info->trackers(0).objects(i_obj).motion_state().direction();
      ehy_rdr_sensor->tracker.objects[i_obj].motion_st.was_moved =
        rdr_info->trackers(0).objects(i_obj).motion_state().was_moved();
      ehy_rdr_sensor->tracker.objects[i_obj].classification =
        (ObjClass)rdr_info->trackers(0).objects(i_obj).classification();
      ehy_rdr_sensor->tracker.objects[i_obj].sub_class     = rdr_info->trackers(0).objects(i_obj).sub_class();
      ehy_rdr_sensor->tracker.objects[i_obj].class_prob    = rdr_info->trackers(0).objects(i_obj).class_prob();
      ehy_rdr_sensor->tracker.objects[i_obj].obstacle_prob = rdr_info->trackers(0).objects(i_obj).obstacle_prob();
    }
  }
  ehy_rdr_sensor->tracker.timestamp = rdr_info->trackers(0).timestamp();

  // Update radar failure info
  for (int i_acc_tar = 0; i_acc_tar < rdr_info->radar_feature().acc_tar_size(); ++i_acc_tar) {
    // aptiv acc target size is 6
    if (i_acc_tar < kNumRdrACCIDAptiv) {
      ehy_rdr_sensor->radar_feature.acc_target_id[i_acc_tar] = rdr_info->radar_feature().acc_tar(i_acc_tar);
    }
  }
  ehy_rdr_sensor->radar_feature.aeb_target_id = rdr_info->radar_feature().aeb_tar();

  // std::cout << "ARBInputAdapter_rdrinput complete"<<std::endl;

  return true;
}

bool ARBInputAdapter::fill_veh_input(const std::shared_ptr<nio::ad::messages::VEH50ms> vehicle_info_50ms,
                                     const std::shared_ptr<nio::ad::messages::VEH10ms> vehicle_info, ARBSIN* arb_sin) {
  // std::cout << "ARBInputAdapter_vehinput start"<<std::endl;
  // acm===========================================================
  // arb_sin->vehicleinfo_in.vehicledynamic.LgtAg = vehicle_info->vehdyn().lgtsaeag();
  // def refs
  VEHDYN&  tmp_vl_dynamic = arb_sin->vehicleinfo_in.vehicledynamic;
  VEHDRVR& tmp_vl_drive   = arb_sin->vehicleinfo_in.vehicledrive;
  VEHWHL&  tmp_vl_wheel   = arb_sin->vehicleinfo_in.vehiclewheel;
  // VEHUPA &tmp_vl_upa = arb_sin->vehicleinfo_in.vehicleupa;
  // VEHSUSPN &tmp_vl_suspension = arb_sin->vehicleinfo_in.vehiclesuspension;
  VEHPT&   tmp_vl_pt      = arb_sin->vehicleinfo_in.vehiclept;
  VEHCTRL& tmp_vl_control = arb_sin->vehicleinfo_in.vehiclecontrol;
  VEHBODY& tmp_vl_body    = arb_sin->vehicleinfo_in.vehiclebody;
  STRSYS&  tmp_steersys   = arb_sin->vehicleinfo_in.steersys;
  BRKSYS&  tmp_brakesys   = arb_sin->vehicleinfo_in.brakesys;

  /*assignment*/

  // vehicledynamic
  // float
  tmp_vl_dynamic.dYawRateDpss = vehicle_info->vehdyn().yawratests();
  tmp_vl_dynamic.LatAg        = vehicle_info->vehdyn().latsaeag();
  tmp_vl_dynamic.LatAmpss     = vehicle_info->vehdyn().latsaeampss();
  tmp_vl_dynamic.LgtAg        = vehicle_info->vehdyn().lgtsaeag();
  tmp_vl_dynamic.LgtAmpss     = vehicle_info->vehdyn().lgtsaeampss();
  tmp_vl_dynamic.VehOdom      = vehicle_info->vehdyn().vehodom();
  tmp_vl_dynamic.YawRateDps   = vehicle_info->vehdyn().yawratesaedps();
  tmp_vl_dynamic.YawRateRps   = vehicle_info->vehdyn().yawratesaerps();
  // struct
  tmp_vl_dynamic.AxAyYrsCalSts = static_cast<ImuCalSt_e>(static_cast<int>(vehicle_info->vehdyn().axayyrscalsts()));
  tmp_vl_dynamic.LatASts       = static_cast<ImuSigalSt_e>(static_cast<int>(vehicle_info->vehdyn().latasts()));
  tmp_vl_dynamic.LgtASts       = static_cast<ImuSigalSt_e>(static_cast<int>(vehicle_info->vehdyn().lgtasts()));

  tmp_vl_dynamic.VehSpd.VehSpdASILD = vehicle_info->vehdyn().vehspd().vehspdasild();
  tmp_vl_dynamic.VehSpd.VehDispSpd  = vehicle_info->vehdyn().vehspd().vehdispspd();
  tmp_vl_dynamic.VehSpd.VehSpdSts =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->vehdyn().vehspd().vehspdsts()));
  tmp_vl_dynamic.VehSpd.VehSpdASILDSts =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->vehdyn().vehspd().vehspdasildsts()));
  tmp_vl_dynamic.VehSpd.VehMovgDir =
    static_cast<VehMovDir_e>(static_cast<int>(vehicle_info->vehdyn().vehspd().vehmovgdir()));

  tmp_vl_dynamic.VehSpd.VehSpdkph = vehicle_info->vehdyn().vehspd().vehspdkph();

  if (tmp_vl_dynamic.VehSpd.VehMovgDir == VehMovDir_e::ForWard) {
    tmp_vl_dynamic.VehSpd.VehSpdmps = vehicle_info->vehdyn().vehspd().vehspdkph() / 3.6;
  } else if (tmp_vl_dynamic.VehSpd.VehMovgDir == VehMovDir_e::BackWard) {
    tmp_vl_dynamic.VehSpd.VehSpdmps = vehicle_info->vehdyn().vehspd().vehspdkph() / 3.6 * -1;
  } else {
    tmp_vl_dynamic.VehSpd.VehSpdmps = vehicle_info->vehdyn().vehspd().vehspdkph() / 3.6;
  }

  // tmp_vl_dynamic.VehSpd.VehSpdmps = vehicle_info->vehdyn().vehspd().vehspdkph()/3.6;
  tmp_vl_dynamic.VehSpd.VehFiltLngAcc = vehicle_info->vehdyn().vehspd().vehfiltlngacc();

  // tmp_vl_dynamic.VehSpd.VehSpdmps = vehicle_info->vehdyn().vehspd().vehspdkph()/3.6;
  tmp_vl_dynamic.VehSpd.VehFiltLngAcc = vehicle_info->vehdyn().vehspd().vehfiltlngacc();

  tmp_vl_dynamic.YawRateSts = static_cast<ImuSigalSt_e>(static_cast<int>(vehicle_info->vehdyn().yawratests()));

  // vehicledrive
  tmp_vl_drive.AdFunCfg.AEBOnOffReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().aebonoffreq()));
  tmp_vl_drive.AdFunCfg.CDCFailSts =
    static_cast<CdcFailSt_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().cdcfailsts()));
  tmp_vl_drive.AdFunCfg.DASTactileOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().dastactileonoff()));
  tmp_vl_drive.AdFunCfg.DrvAlertSysOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().drvalertsysonoff()));
  tmp_vl_drive.AdFunCfg.FCTAOnOffCmd =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().fctaonoffcmd()));
  tmp_vl_drive.AdFunCfg.FCWSetReq =
    static_cast<FcwSet_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().fcwsetreq()));
  tmp_vl_drive.AdFunCfg.GoNotifierOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().gonotifieronoff()));
  // struct

  tmp_vl_drive.AdFunCfg.LCAOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lcaonoff()));
  tmp_vl_drive.AdFunCfg.LCATctlWarnOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lcatctlwarnonoff()));
  tmp_vl_drive.AdFunCfg.LKAStrSprtLvlSet =
    static_cast<LkaStrSprtLvl_e>(static_cast<int>(0));
  tmp_vl_drive.AdFunCfg.LnAssistTctlOnOff =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().lnassisttctlonoff()));
  tmp_vl_drive.AdFunCfg.RCTABReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().rctabreq()));
  tmp_vl_drive.AdFunCfg.RCTAReq =
    static_cast<AdFunOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().rctareq()));
  tmp_vl_drive.AdFunCfg.SAPAPrkgModReq =
    static_cast<SapaPrkMod_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().sapaprkgmodreq()));
  tmp_vl_drive.AdFunCfg.SetHMA =
    static_cast<HmaOnOff_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().sethma()));
  tmp_vl_drive.AdFunCfg.SetLaneAssiSnvty =
    static_cast<LnAssistSnvty_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().setlaneassisnvty()));
  tmp_vl_drive.AdFunCfg.SetLnAssiAidTyp =
    static_cast<LnAssistAid_e>(static_cast<int>(vehicle_info_50ms->drvin().adfuncfg().setlnassiaidtyp()));

  tmp_vl_drive.FogLiPushSwtSts =
    static_cast<FogLiSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().foglipushswtsts()));
  tmp_vl_drive.FogLiSCMCmd = static_cast<FogLiCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().fogliscmcmd()));
  tmp_vl_drive.FrntWiprInterSpd =
    static_cast<WiprSpdSet_e>(static_cast<int>(vehicle_info_50ms->drvin().frntwiprinterspd()));
  tmp_vl_drive.FrntWiprSwtSts = static_cast<WiprSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().frntwiprswtsts()));
  tmp_vl_drive.HiBeamSCMCmd   = static_cast<HiBmCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().hibeamscmcmd()));
  tmp_vl_drive.HiBeamSwtSts   = static_cast<HiBeamSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().hibeamswtsts()));
  tmp_vl_drive.NavCtryCod     = vehicle_info_50ms->drvin().navctrycod();
  tmp_vl_drive.NaviCurrentRoadTyp =
    static_cast<NaviCrrntRd_e>(static_cast<int>(vehicle_info_50ms->drvin().navicurrentroadtyp()));
  tmp_vl_drive.NaviSpdLim = vehicle_info_50ms->drvin().navispdlim();
  tmp_vl_drive.NaviSpdLimSts =
    static_cast<NaviSpdLimSt_e>(static_cast<int>(vehicle_info_50ms->drvin().navispdlimsts()));
  tmp_vl_drive.NaviSpdUnit  = static_cast<NaviSpdUnit_e>(static_cast<int>(vehicle_info_50ms->drvin().navispdunit()));
  tmp_vl_drive.ReWiprSCMCmd = static_cast<ReWiprCmd_e>(static_cast<int>(vehicle_info_50ms->drvin().rewiprscmcmd()));
  tmp_vl_drive.SCMFailSts   = static_cast<ScmFailSt_e>(static_cast<int>(vehicle_info_50ms->drvin().scmfailsts()));

  tmp_vl_drive.VehAccrMod   = static_cast<VehAccrMod_e>(static_cast<int>(vehicle_info_50ms->drvin().vehaccrmodreq()));

  for (int i = 0; i < vehicle_info_50ms->drvin().strwhlswtch().adupswtsts().size(); i++) {
    tmp_vl_drive.StrWhlSwtch.AdUpSwtSts[i] =
      static_cast<SwcSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().strwhlswtch().adupswtsts()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->drvin().strwhlswtch().enupswtsts().size(); i++) {
    tmp_vl_drive.StrWhlSwtch.EnUpSwtSts[i] =
      static_cast<SwcSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().strwhlswtch().enupswtsts()[i]));
  }

  tmp_vl_drive.SVCAvl = static_cast<SvcAvl_e>(static_cast<int>(vehicle_info_50ms->drvin().svcavl()));
  tmp_vl_drive.TurnIndcrSwtSts =
    static_cast<TrnIndcrSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().turnindcrswtsts()));
  tmp_vl_drive.WiprAutoSwtSts =
    static_cast<WiprAutoSwSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wiprautoswtsts()));
  tmp_vl_drive.WshrReWiprSwtSts =
    static_cast<WshrReWiprSwtSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wshrrewiprswtsts()));
  tmp_vl_drive.WTIDispSt = static_cast<WtiDispSt_e>(static_cast<int>(vehicle_info_50ms->drvin().wtidispst()));

  // vehiclewheel
  for (int i = 0; i < vehicle_info->whl().whldyn().size(); i++) {
    tmp_vl_wheel.WhlDyn[i].WhlPlsCntr = vehicle_info->whl().whldyn()[i].whlplscntr();
    tmp_vl_wheel.WhlDyn[i].WhlSpd     = vehicle_info->whl().whldyn()[i].whlspd();
    tmp_vl_wheel.WhlDyn[i].WhlPlsCntrVld =
      static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->whl().whldyn()[i].whlplscntrvld()));
    tmp_vl_wheel.WhlDyn[i].WhlSpdMovgDir =
      static_cast<WhlSpdDir_e>(static_cast<int>(vehicle_info->whl().whldyn()[i].whlspdmovgdir()));
    tmp_vl_wheel.WhlDyn[i].WhlSpdSts =
      static_cast<WhlSpdSts_e>(static_cast<int>(vehicle_info->whl().whldyn()[i].whlspdsts()));
  }

  for (int i = 0; i < vehicle_info->whl().whltpms().size(); i++) {
    tmp_vl_wheel.WHlTpms[i].BatSts        = vehicle_info->whl().whltpms()[i].batsts();
    tmp_vl_wheel.WHlTpms[i].DeltaPressSts = vehicle_info->whl().whltpms()[i].deltapresssts();
    tmp_vl_wheel.WHlTpms[i].Press         = vehicle_info->whl().whltpms()[i].press();
    tmp_vl_wheel.WHlTpms[i].PressSts =
      static_cast<WhlTp_e>(static_cast<int>(vehicle_info->whl().whltpms()[i].presssts()));
    tmp_vl_wheel.WHlTpms[i].SnsrFailSts = vehicle_info->whl().whltpms()[i].snsrfailsts();
    tmp_vl_wheel.WHlTpms[i].Temp        = vehicle_info->whl().whltpms()[i].temp();
    tmp_vl_wheel.WHlTpms[i].TempSts     = vehicle_info->whl().whltpms()[i].tempsts();
  }

  // vehicleupa

  // vehiclesuspension

  // vehiclept
  tmp_vl_pt.AccrPedal.EfcPosnVld =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().accrpedal().efcposnvld()));
  tmp_vl_pt.AccrPedal.EfcPosn = vehicle_info->pt().accrpedal().efcposn();
  tmp_vl_pt.AccrPedal.ActPosnVld =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().accrpedal().actposnvld()));
  tmp_vl_pt.AccrPedal.ActPosn     = vehicle_info->pt().accrpedal().actposn();
  tmp_vl_pt.AccrPedal.ActPosnRate = 0;  // not found

  tmp_vl_pt.AccrPedal.PedlOvrd = vehicle_info->pt().accrpedal().pedlovrd();

  tmp_vl_pt.CruiseStatus      = static_cast<VcuCruiseSt_e>(static_cast<int>(vehicle_info->pt().cruisestatus()));
  tmp_vl_pt.CruiseStoredSpeed = vehicle_info->pt().cruisestoredspeed();
  // tmp_vl_pt.CTABrkAvl = vehicle_info->pt().ctabrkavl();

  tmp_vl_pt.Gear.ActGear      = vehicle_info->pt().gear().actgear();
  tmp_vl_pt.Gear.SlctrPosn    = vehicle_info->pt().gear().slctrposn();
  tmp_vl_pt.Gear.TrgtGear     = vehicle_info->pt().gear().trgtgear();
  tmp_vl_pt.Gear.ActGearVld   = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().gear().actgearvld()));
  tmp_vl_pt.Gear.SlctrPosnVld = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().gear().slctrposnvld()));
  tmp_vl_pt.Gear.TrgtGearVld  = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().gear().trgtgearvld()));

  for (int i = 0; i < vehicle_info->pt().motor().size(); i++) {
    tmp_vl_pt.Motor[i].ActMotTq = vehicle_info->pt().motor()[i].actmottq();
    tmp_vl_pt.Motor[i].ActMotTqVld =
      static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().motor()[i].actmottqvld()));
    tmp_vl_pt.Motor[i].IntdMotTq = vehicle_info->pt().motor()[i].intdmottq();
    tmp_vl_pt.Motor[i].IntdMotTqVld =
      static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().motor()[i].intdmottqvld()));
    tmp_vl_pt.Motor[i].MotSpd = vehicle_info->pt().motor()[i].motspd();
    tmp_vl_pt.Motor[i].MotSpdVld =
      static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->pt().motor()[i].motspdvld()));
  }

  tmp_vl_pt.VCUBrkLampReq  = vehicle_info->pt().vcubrklampreq();
  tmp_vl_pt.VCUEPBReq      = static_cast<VcuEpbReq_e>(static_cast<int>(vehicle_info->pt().vcuepbreq()));
  tmp_vl_pt.VCUPtWakeupReq = vehicle_info->pt().vcuptwakeupreq();
  tmp_vl_pt.VCURvsLampReq  = vehicle_info->pt().vcurvslampreq();
  // tmp_vl_pt.VCUTqAvl = vehicle_info->pt().vcutqavl();

  // vehiclecontrol
  tmp_vl_control.LatCtrlIf.DAIAvl = vehicle_info->vehctrlif().latctrlif().daiavl();
  tmp_vl_control.LatCtrlIf.HIAvl  = vehicle_info->vehctrlif().latctrlif().hiavl();
  tmp_vl_control.LatCtrlIf.PAIAvl = vehicle_info->vehctrlif().latctrlif().paiavl();
  tmp_vl_control.LatCtrlIf.TOIAvl = vehicle_info->vehctrlif().latctrlif().toiavl();
  tmp_vl_control.LatCtrlIf.ActvExtIf =
    static_cast<StrActvIf_e>(static_cast<int>(vehicle_info->vehctrlif().latctrlif().actvextif()));

  tmp_vl_control.LngCtrlIf.VLCActv      = vehicle_info->vehctrlif().lngctrlif().vlcactv();
  tmp_vl_control.LngCtrlIf.VLCAvl       = vehicle_info->vehctrlif().lngctrlif().vlcavl();
  tmp_vl_control.LngCtrlIf.VLCTarDecel  = vehicle_info->vehctrlif().lngctrlif().vlctardecel();
  tmp_vl_control.LngCtrlIf.AutoBrkgActv = vehicle_info->vehctrlif().lngctrlif().autobrkgactv();
  tmp_vl_control.LngCtrlIf.AutoBrkgAvl  = vehicle_info->vehctrlif().lngctrlif().autobrkgavl();
  tmp_vl_control.LngCtrlIf.LLCFctSt =
    static_cast<LlcFctSt_e>(static_cast<int>(vehicle_info->vehctrlif().lngctrlif().llcfctst()));
  tmp_vl_control.LngCtrlIf.LLCIntrrptErrTyp =
    static_cast<LlcIntrptErr_e>(static_cast<int>(vehicle_info->vehctrlif().lngctrlif().llcintrrpterrtyp()));
  tmp_vl_control.LngCtrlIf.ADTSts =
    static_cast<AdtSt_e>(static_cast<int>(vehicle_info->vehctrlif().lngctrlif().adtsts()));
  tmp_vl_control.LngCtrlIf.HldLampReq =
    static_cast<HldLampReq_e>(static_cast<int>(vehicle_info->vehctrlif().lngctrlif().hldlampreq()));

  // vehiclebody
  tmp_vl_body.AdsLampReq   = vehicle_info_50ms->vehbody().adslampreq();
  tmp_vl_body.AmbTemp      = vehicle_info_50ms->vehbody().ambtemp();
  tmp_vl_body.AmbTempValid = vehicle_info_50ms->vehbody().ambtempvalid();
  tmp_vl_body.CenLockSts   = static_cast<CenLockSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().cenlocksts()));
  tmp_vl_body.CrashDetd    = vehicle_info_50ms->vehbody().crashdetd();

  for (int i = 0; i < vehicle_info_50ms->vehbody().door().doorajarsts().size(); i++) {
    tmp_vl_body.Door.DoorAjarSts[i] =
      static_cast<DoorAjarSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().door().doorajarsts()[i]));
  }
  tmp_vl_body.Door.HoodAjarSts = vehicle_info_50ms->vehbody().door().hoodajarsts();
  tmp_vl_body.Door.TrAjarSts   = vehicle_info_50ms->vehbody().door().trajarsts();

  tmp_vl_body.DrvState    = static_cast<DrvSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().drvstate()));
  tmp_vl_body.IntrTemp    = vehicle_info_50ms->vehbody().intrtemp();
  tmp_vl_body.IntrTempVld = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info_50ms->vehbody().intrtempvld()));

  tmp_vl_body.LightSts.HzrdWarnSts =
    static_cast<HzrdLiSts_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().hzrdwarnsts()));
  tmp_vl_body.LightSts.LiSnsrData    = vehicle_info_50ms->vehbody().lightsts().lisnsrdata();
  tmp_vl_body.LightSts.LiSnsrFailSts = vehicle_info_50ms->vehbody().lightsts().lisnsrfailsts();
  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().foglists().size(); i++) {
    tmp_vl_body.LightSts.FogLiSts[i] =
      static_cast<FogLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().foglists()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().beamsts().size(); i++) {
    tmp_vl_body.LightSts.BeamSts[i] =
      static_cast<BeamSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().beamsts()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().turnindcrlists().size(); i++) {
    tmp_vl_body.LightSts.TurnIndcrLiSts[i] =
      static_cast<TurnLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().turnindcrlists()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().mirrligtsts().size(); i++) {
    tmp_vl_body.LightSts.MirrLigtSts[i] =
      static_cast<MirrLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().mirrligtsts()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().foglifctactvsts().size(); i++) {
    tmp_vl_body.LightSts.FogLiFctActvSts[i] =
      static_cast<FogLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().lightsts().foglifctactvsts()[i]));
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().dowwarnamblests().size(); i++) {
    tmp_vl_body.LightSts.DowWarnAmbLeSts[i] = vehicle_info_50ms->vehbody().lightsts().dowwarnamblests()[i];
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().lgterrbrkli().size(); i++) {
    tmp_vl_body.LightSts.LgtErrBrkLi[i] = vehicle_info_50ms->vehbody().lightsts().lgterrbrkli()[i];
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().lightsts().lgterrturnindcn().size(); i++) {
    tmp_vl_body.LightSts.LgtErrTurnIndcn[i] = vehicle_info_50ms->vehbody().lightsts().lgterrturnindcn()[i];
  }

  tmp_vl_body.MaiLiSet   = static_cast<MnLiSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().mailiset()));
  tmp_vl_body.NBSDrvrSts = static_cast<NbsDrvSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsdrvrsts()));
  // tmp_vl_body.NBSMovReq = static_cast<NbsMov_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsmovreq()));
  // tmp_vl_body.NBSReq = static_cast<NbsReq_e>(static_cast<int>(vehicle_info_50ms->vehbody().nbsreq()));
  tmp_vl_body.PrkgTyp = static_cast<PrkSys_e>(static_cast<int>(vehicle_info_50ms->vehbody().prkgtyp()));
  tmp_vl_body.SDWReq  = static_cast<ReqZeroAsOn_e>(static_cast<int>(vehicle_info_50ms->vehbody().sdwreq()));
  for (int i = 0; i < vehicle_info_50ms->vehbody().seatbltsts().size(); i++) {
    tmp_vl_body.SeatBltSts[i] = vehicle_info_50ms->vehbody().seatbltsts()[i];
  }

  for (int i = 0; i < vehicle_info_50ms->vehbody().seatoccpsts().size(); i++) {
    tmp_vl_body.SeatOccpSts[i] =
      static_cast<SeatOcupSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().seatoccpsts()[i]));
  }

  tmp_vl_body.SWCAdjModReq = static_cast<SwcAdjMod_e>(static_cast<int>(vehicle_info_50ms->vehbody().swcadjmodreq()));
  tmp_vl_body.Time.Day     = vehicle_info_50ms->vehbody().time().day();
  tmp_vl_body.Time.Hr      = vehicle_info_50ms->vehbody().time().hr();
  tmp_vl_body.Time.Min     = vehicle_info_50ms->vehbody().time().min();
  tmp_vl_body.Time.Mth     = vehicle_info_50ms->vehbody().time().mth();
  tmp_vl_body.Time.Sec     = vehicle_info_50ms->vehbody().time().sec();
  tmp_vl_body.Time.Yr      = vehicle_info_50ms->vehbody().time().yr();

  tmp_vl_body.TpmsSts       = static_cast<TpmsSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().tpmssts()));
  tmp_vl_body.TrailerModReq = static_cast<TrlrMod_e>(static_cast<int>(vehicle_info_50ms->vehbody().trailermodreq()));
  tmp_vl_body.UPAReq        = static_cast<ReqZeroAsOn_e>(static_cast<int>(vehicle_info_50ms->vehbody().upareq()));

  tmp_vl_body.VehStatus.VehMode =
    static_cast<VehMode_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehmode()));
  tmp_vl_body.VehStatus.VehState =
    static_cast<VehSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehstate()));
  tmp_vl_body.VehStatus.VehStateASIL =
    static_cast<VehSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().vehstatus().vehstateasil()));

  tmp_vl_body.WipperSts.FrntWiperParkSts =
    static_cast<WiprPrkSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().wippersts().frntwiperparksts()));
  tmp_vl_body.WipperSts.FrntWiprSts =
    static_cast<WiprSt_e>(static_cast<int>(vehicle_info_50ms->vehbody().wippersts().frntwiprsts()));

  // steersys
  tmp_steersys.ACIMtrTq      = vehicle_info->strsys().acimtrtqsae();  // lrpq
  tmp_steersys.ACIMtrTqVld   = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->strsys().acimtrtqvld()));
  tmp_steersys.DrvngMod      = static_cast<EpsDrvMod_e>(static_cast<int>(vehicle_info->strsys().drvngmod()));
  tmp_steersys.EPSSts        = static_cast<EPSSts_e>(static_cast<int>(vehicle_info->strsys().epssts()));
  tmp_steersys.EstRackFrc    = vehicle_info->strsys().estrackfrcsae();  // lrpq
  tmp_steersys.EstRackFrcVld = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->strsys().estrackfrcvld()));
  tmp_steersys.MtrTq         = vehicle_info->strsys().mtrtqsae();
  tmp_steersys.MtrTqVld      = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->strsys().mtrtqvld()));
  tmp_steersys.OverRideDetn  = vehicle_info->strsys().overridedetn();
  tmp_steersys.PnnAg         = vehicle_info->strsys().pnnagsae();
  tmp_steersys.PnnAgOffset   = vehicle_info->strsys().pnnagoffsetsae();
  tmp_steersys.PnnAgVld      = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->strsys().pnnagvld()));
  tmp_steersys.RampSts       = vehicle_info->strsys().rampsts();
  tmp_steersys.StrAgCalSts   = static_cast<StrAgCalSts_e>(static_cast<int>(vehicle_info->strsys().stragcalsts()));
  tmp_steersys.StrAgFailSts  = static_cast<StrAgFailSts_e>(static_cast<int>(vehicle_info->strsys().stragfailsts()));
  tmp_steersys.StrWhlAg      = vehicle_info->strsys().strwhlagsae();
  tmp_steersys.StrWhlAgSpd   = vehicle_info->strsys().strwhlagspdsae();
  tmp_steersys.SupInfo       = vehicle_info->strsys().supinfo();
  tmp_steersys.Temperature   = vehicle_info->strsys().temperature();
  tmp_steersys.TorsBarTq     = vehicle_info->strsys().torsbartqsae();
  tmp_steersys.TorsBarTqVld  = static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->strsys().torsbartqvld()));

  // brakesys
  tmp_brakesys.BCUBrkLiReq = static_cast<BcuBrkLiReq_e>(static_cast<int>(vehicle_info->brksys().bcubrklireq()));
  tmp_brakesys.BrkFldLvl   = static_cast<BrkFldLvl_e>(static_cast<int>(vehicle_info->brksys().brkfldlvl()));

  tmp_brakesys.BrkFunSt.ABAActv        = vehicle_info->brksys().brkfunst().abaactv();  // todo
  tmp_brakesys.BrkFunSt.ABAAvl         = vehicle_info->brksys().brkfunst().abaavl();
  tmp_brakesys.BrkFunSt.ABPActv        = vehicle_info->brksys().brkfunst().abpactv();
  tmp_brakesys.BrkFunSt.ABPAvl         = vehicle_info->brksys().brkfunst().abpavl();
  tmp_brakesys.BrkFunSt.ABSActv        = vehicle_info->brksys().brkfunst().absactv();
  tmp_brakesys.BrkFunSt.ABSFailLampReq = vehicle_info->brksys().brkfunst().absfaillampreq();
  tmp_brakesys.BrkFunSt.AVHSts  = static_cast<AvhSts_e>(static_cast<int>(vehicle_info->brksys().brkfunst().avhsts()));
  tmp_brakesys.BrkFunSt.BDWActv = vehicle_info->brksys().brkfunst().bdwactv();
  tmp_brakesys.BrkFunSt.DTCActv = vehicle_info->brksys().brkfunst().dtcactv();
  tmp_brakesys.BrkFunSt.DWTActv = vehicle_info->brksys().brkfunst().dwtactv();
  tmp_brakesys.BrkFunSt.EBAActv = vehicle_info->brksys().brkfunst().ebaactv();
  tmp_brakesys.BrkFunSt.EBAAvl  = vehicle_info->brksys().brkfunst().ebaavl();
  tmp_brakesys.BrkFunSt.EBDActv = vehicle_info->brksys().brkfunst().ebdactv();
  tmp_brakesys.BrkFunSt.EBDFailLampReq = vehicle_info->brksys().brkfunst().ebdfaillampreq();
  tmp_brakesys.BrkFunSt.HBAActv        = vehicle_info->brksys().brkfunst().hbaactv();
  tmp_brakesys.BrkFunSt.HDCSts    = static_cast<HdcSts_e>(static_cast<int>(vehicle_info->brksys().brkfunst().hdcsts()));
  tmp_brakesys.BrkFunSt.HHCActv   = vehicle_info->brksys().brkfunst().hhcactv();
  tmp_brakesys.BrkFunSt.HHCAvl    = vehicle_info->brksys().brkfunst().hhcavl();
  tmp_brakesys.BrkFunSt.TCSActv   = vehicle_info->brksys().brkfunst().tcsactv();
  tmp_brakesys.BrkFunSt.TCSDeactv = vehicle_info->brksys().brkfunst().tcsdeactv();
  // std::cout << "in proto, TCS deactive is "<<(int) vehicle_info->brksys().brkfunst().tcsdeactv() << std::endl;
  tmp_brakesys.BrkFunSt.VDCActv            = vehicle_info->brksys().brkfunst().vdcactv();
  tmp_brakesys.BrkFunSt.VDCDeactv          = vehicle_info->brksys().brkfunst().vdcdeactv();
  tmp_brakesys.BrkFunSt.VDCTCSFailLampReq  = vehicle_info->brksys().brkfunst().vdctcsfaillampreq();
  tmp_brakesys.BrkFunSt.VDCTCSLampInfo     = vehicle_info->brksys().brkfunst().vdctcslampinfo();
  tmp_brakesys.BrkFunSt.VDCTCSOnOfflampReq = vehicle_info->brksys().brkfunst().vdctcsonofflampreq();

  tmp_brakesys.BrkHAZReq     = static_cast<BrkHazReq_e>(static_cast<int>(vehicle_info->brksys().brkhazreq()));
  tmp_brakesys.BrkOverHeat   = static_cast<BrkOvrHt_e>(static_cast<int>(vehicle_info->brksys().brkoverheat()));
  tmp_brakesys.BrkPadWearSts = static_cast<BrkPdWrSts_e>(static_cast<int>(vehicle_info->brksys().brkpadwearsts()));

  tmp_brakesys.BrkPdl.BrkPedlSts =
    static_cast<BrkPdlSts_e>(static_cast<int>(vehicle_info->brksys().brkpdl().brkpedlsts()));
  tmp_brakesys.BrkPdl.Trvl = vehicle_info->brksys().brkpdl().trvl();
  tmp_brakesys.BrkPdl.TrvlCalSts =
    static_cast<BrkPdlCalSts_e>(static_cast<int>(vehicle_info->brksys().brkpdl().trvlcalsts()));

  tmp_brakesys.BrkPrs.BrkPrs       = vehicle_info->brksys().brkprsinfo().brkprs();
  tmp_brakesys.BrkPrs.BrkPrsOffset = vehicle_info->brksys().brkprsinfo().brkprsoffset();
  tmp_brakesys.BrkPrs.BrkPrsOffsetVld =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->brksys().brkprsinfo().brkprsoffsetvld()));
  tmp_brakesys.BrkPrs.BrkPrsVld =
    static_cast<QfZeroVld_e>(static_cast<int>(vehicle_info->brksys().brkprsinfo().brkprsvld()));

  tmp_brakesys.NoBrkF = static_cast<BcuBrkF_e>(static_cast<int>(vehicle_info->brksys().nobrkf()));

  tmp_brakesys.PrkBrk.EPBMod = static_cast<EpbMod_e>(static_cast<int>(vehicle_info->brksys().prkbrk().epbmod()));
  tmp_brakesys.PrkBrk.EPBSts = static_cast<EpbSts_e>(static_cast<int>(vehicle_info->brksys().prkbrk().epbsts()));
  tmp_brakesys.PrkBrk.EPBSwtSts =
    static_cast<EpbSwtSt_e>(static_cast<int>(vehicle_info->brksys().prkbrk().epbswtsts()));

  tmp_brakesys.SupInfo = static_cast<BcuSupInfo_e>(static_cast<int>(vehicle_info->brksys().supinfo()));
  // std::cout << "ARBInputAdapter_vehinput complete"<<std::endl;

  return true;
}

bool ARBInputAdapter::fill_vehstate(ARBVehicle* vehicle_input) {
  vehicle_input->wheel_base                = 2.8;
  vehicle_input->length                    = 5.2;
  vehicle_input->width                     = 2.2;
  vehicle_input->height                    = 1.8;
  vehicle_input->front_bumper_to_rear_axle = 3.9;
  vehicle_input->epm_pos_to_front_bumper   = 1.8;
  vehicle_input->pp_c2                     = 0;

  return true;
}

bool ARBInputAdapter::fill_obf_input(const std::shared_ptr<nio::ad::messages::EHYObfOutputs> obf_info,
                                     std::vector<feature::ehy::Object>*                      fusion_object_) {
  // std::cout << "ARBInputAdapter_obfinput start"<<std::endl;
  fusion_object_->clear();
  int min_size = MIN(kNumFusionObject, obf_info->obf_objects_size());
  // std::cout << "from proto the obf size is" << (int)obf_info->obf_objects_size() << std::endl;
  for (int obf_i = 0; obf_i < min_size; obf_i++) {
    // std::cout<<"the obj information from
    // EHY====================================================================================================================="<<std::endl;

    // std::cout<<"target id is"<< (int)obf_info->obf_objects(obf_i).fuseobj().id() <<std::endl;

    // std::cout<<"target pos_vcs is"<<obf_info->obf_objects(obf_i).fuseobj().pos_vcs().x()<<",
    // "<<obf_info->obf_objects(obf_i).fuseobj().pos_vcs().y()<<",
    // "<<obf_info->obf_objects(obf_i).fuseobj().pos_vcs().z() <<std::endl;

    //  std::cout<<"target pos_ccs is"<<obf_info->obf_objects(obf_i).fuseobj().pos_ccs().x()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().pos_ccs().y()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().pos_ccs().z() <<std::endl;

    //  std::cout<<"target vel_vcs is"<<obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vx()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vy()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vz() <<std::endl;

    //  std::cout<<"target vel_ccs is"<<obf_info->obf_objects(obf_i).fuseobj().vel_ccs().vx()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().vel_ccs().vy()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().vel_ccs().vz() <<std::endl;

    //  std::cout<<"target acc is"<<obf_info->obf_objects(obf_i).fuseobj().acc().ax()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().acc().ay()<<", "<<obf_info->obf_objects(obf_i).fuseobj().acc().az()
    //  <<std::endl;

    //  std::cout<<"target valid status is"<< (int)obf_info->obf_objects(obf_i).fuseobj().valid_status() <<std::endl;

    //  std::cout<<"target classification is"<< (int)obf_info->obf_objects(obf_i).fuseobj().type().obj_main_class()<<",
    //  "<< (int)obf_info->obf_objects(obf_i).fuseobj().type().obj_sub_class() <<std::endl;

    //  std::cout<<"target age is"<< (int)obf_info->obf_objects(obf_i).fuseobj().age()<<std::endl;

    //  std::cout<<"target size is"<<obf_info->obf_objects(obf_i).fuseobj().size().length()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().size().width()<<",
    //  "<<obf_info->obf_objects(obf_i).fuseobj().size().height() <<std::endl;

    //  std::cout<<"target heading is"<<obf_info->obf_objects(obf_i).fuseobj().heading()<<std::endl;

    //  std::cout<<"target age is"<< (int)obf_info->obf_objects(obf_i).fuseobj().vision_match_id()<<std::endl;

    //  std::cout<<"target fusion source is"<< (int)obf_info->obf_objects(obf_i).fuseobj().fusion_source()<<std::endl;

    //  std::cout<<"target angle is"<< obf_info->obf_objects(obf_i).fuseobj().angle()<<std::endl;

    //  std::cout<<"target move status is"<< (int)obf_info->obf_objects(obf_i).fuseobj().move_status()<<std::endl;

    //  std::cout<<"target confidence is"<< (int)obf_info->obf_objects(obf_i).fuseobj().confidence()<<std::endl;

    //  std::cout<<"================================================================================================================================================"<<std::endl;

    if (obf_i <= obf_info->obf_objects_size()) {
      feature::ehy::Object tmp_obf;
      // obf_classification cannot work
      // obf longitude position is shifted to front bumper,
      // obf motion status is not mapped,

      switch (obf_info->obf_objects(obf_i).fuseobj().valid_status()) {
      case nio::ad::messages::FusObject_ObjValidStatus::FusObject_ObjValidStatus_kObjValidStatus_Invalid:
        tmp_obf.set_valid_status(feature::ehy::ObjValidStatus::kInvalid);
        break;
      case nio::ad::messages::FusObject_ObjValidStatus::FusObject_ObjValidStatus_kObjValidStatus_New:
        tmp_obf.set_valid_status(feature::ehy::ObjValidStatus::kNew);
        break;
      case nio::ad::messages::FusObject_ObjValidStatus::FusObject_ObjValidStatus_kObjValidStatus_Mature:
        tmp_obf.set_valid_status(feature::ehy::ObjValidStatus::kMature);
        break;
      case nio::ad::messages::FusObject_ObjValidStatus::FusObject_ObjValidStatus_kObjValidStatus_Coast:
        tmp_obf.set_valid_status(feature::ehy::ObjValidStatus::kCoast);
        break;
      default:
        tmp_obf.set_valid_status(feature::ehy::ObjValidStatus::kInvalid);
        break;
      }

      tmp_obf.ID = obf_info->obf_objects(obf_i).fuseobj().id();

      // switch (obf_info->obf_objects(obf_i).fuseobj().fusion_source()) {
      // case -1:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScDefault;
      //   break;
      // case 0:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScRadar;
      //   break;
      // case 1:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScMEVision;
      //   break;
      // case 2:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScFusion;
      //   break;
      // case 3:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScLidar;
      //   break;
      // default:
      //   tmp_obf.source = feature::ehy::ObjectSource::kScDefault;
      //   break;
      // }
      tmp_obf.source = feature::ehy::ObjectSource::kScDefault;

      feature::ehy::ClassEnum obj_class;
      uint32_t                obj_subclass;

      switch (obf_info->obf_objects(obf_i).fuseobj().type().obj_main_class()) {
      case nio::ad::messages::ObjClass::ObjClass_Undefined:
        obj_class = feature::ehy::ClassEnum::kClassUndefined;
        break;
      case nio::ad::messages::ObjClass::ObjClass_SmallVehicle:
        obj_class = feature::ehy::ClassEnum::kClassSmallVehicle;
        break;
      case nio::ad::messages::ObjClass::ObjClass_Pedestrian:
        obj_class = feature::ehy::ClassEnum::kClassPedestrian;
        break;
      case nio::ad::messages::ObjClass::ObjClass_Bike:
        obj_class = feature::ehy::ClassEnum::kClassBike;
        break;
      case nio::ad::messages::ObjClass::ObjClass_BigVehicle:
        obj_class = feature::ehy::ClassEnum::kClassBigVehicle;
        break;
      case nio::ad::messages::ObjClass::ObjClass_Animal:
        obj_class = feature::ehy::ClassEnum::kClassAnimal;
        break;
      case nio::ad::messages::ObjClass::ObjClass_GeneralObject:
        obj_class = feature::ehy::ClassEnum::kClassGeneralObject;
        break;
      default:
        obj_class = feature::ehy::ClassEnum::kClassUndefined;
        break;
      }

      obj_subclass = obf_info->obf_objects(obf_i).fuseobj().type().obj_sub_class();

      tmp_obf.classification.SetClass(obj_class, obj_subclass);

      tmp_obf.classification.SetSubClass(obj_class, obj_subclass, true);

      bool isvalid;
      bool ismoving;
      bool ismovable;
      bool isoncoming;
      bool hasmoved;

      isvalid = (obf_info->obf_objects(obf_i).fuseobj().object_status()
                 != nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Undefined)
                  ? 1
                  : 0;

      ismoving = (obf_info->obf_objects(obf_i).fuseobj().object_status()
                  == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Moving)
                   ? 1
                   : 0;

      ismovable = (obf_info->obf_objects(obf_i).fuseobj().object_status()
                     == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Moving
                   || obf_info->obf_objects(obf_i).fuseobj().object_status()
                        == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Stopped
                   || obf_info->obf_objects(obf_i).fuseobj().object_status()
                        == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Oncoming
                   || obf_info->obf_objects(obf_i).fuseobj().object_status()
                        == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Parked)
                    ? 1
                    : 0;

      isoncoming = (obf_info->obf_objects(obf_i).fuseobj().object_status()
                    == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Oncoming)
                     ? 1
                     : 0;

      hasmoved = (obf_info->obf_objects(obf_i).fuseobj().object_status()
                    == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Moving
                  || obf_info->obf_objects(obf_i).fuseobj().object_status()
                       == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Stopped
                  || obf_info->obf_objects(obf_i).fuseobj().object_status()
                       == nio::ad::messages::FusObject_ObjStatus::FusObject_ObjStatus_kObjStatus_Oncoming)
                   ? 1
                   : 0;

      tmp_obf.motion_status.SetValid(isvalid);

      tmp_obf.motion_status.SetMovable(ismovable);

      tmp_obf.motion_status.SetMoving(ismoving);

      tmp_obf.motion_status.SetMoveDir(isoncoming);

      tmp_obf.motion_status.SetMoveHis(hasmoved);

      tmp_obf.motion.SetHead(obf_info->obf_objects(obf_i).fuseobj().heading(),
                             obf_info->obf_objects(obf_i).fuseobj().heading_rate());

      float target_heading = obf_info->obf_objects(obf_i).fuseobj().heading();

      // std::cout <<"obf id is " << (int)obf_i << " and his heading is " <<
      // obf_info->obf_objects(obf_i).fuseobj().heading() << std::endl;

      feature::math::Vector3f Obj_Size;
      Obj_Size.x = obf_info->obf_objects(obf_i).fuseobj().size().length();
      Obj_Size.y = obf_info->obf_objects(obf_i).fuseobj().size().width();
      Obj_Size.z = obf_info->obf_objects(obf_i).fuseobj().size().height();
      tmp_obf.motion.SetSize(Obj_Size);

      feature::math::Vector3f Obj_Pos_Center;
      feature::math::Vector3f Obj_Pos;
      Obj_Pos_Center.x = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().x();
      Obj_Pos_Center.y = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().y();
      Obj_Pos_Center.z = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().z();

      /*if (obj_class == feature::ehy::ClassEnum::kClassSmallVehicle
          || obj_class == feature::ehy::ClassEnum::kClassBigVehicle) {
        if (Obj_Pos_Center.y <= 0) {
          if (fabsf(target_heading) <= 0.785 || (fabsf(target_heading) >= 2.355 && fabsf(target_heading) <= 3.15)) {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            }
          } else if ((target_heading >= 1.57 && target_heading < 2.355)
                     || (target_heading >= -1.57 && target_heading < -0.785)) {
            Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

            Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * fabsf(sinf(target_heading)));
          } else {
            Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

            Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * fabsf(sinf(target_heading)));
          }
        } else {
          if (fabsf(target_heading) <= 0.785 || (fabsf(target_heading) >= 2.355 && fabsf(target_heading) <= 3.15)) {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            }
          } else if ((target_heading >= 1.57 && target_heading < 2.355)
                     || (target_heading >= -1.57 && target_heading < -0.785)) {
            Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

            Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * fabsf(sinf(target_heading)));
          } else {
            Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

            Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * fabsf(sinf(target_heading)));
          }
        }
      } else if (obj_class == feature::ehy::ClassEnum::kClassPedestrian) {
        Obj_Pos.x = Obj_Pos_Center.x;
        Obj_Pos.y = Obj_Pos_Center.y;
      } else if (obj_class == feature::ehy::ClassEnum::kClassBike) {
        if (Obj_Pos_Center.y >= 0) {
          if (target_heading >= 1.047 && target_heading <= 2.093) {
            Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * cosf(target_heading));

            Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
          } else if (target_heading >= -2.093 && target_heading <= -1.047) {
            Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * cosf(target_heading));

            Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
          } else if (target_heading > -1.047 && target_heading < 1.047) {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * cosf(target_heading));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            }
          } else {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * cosf(target_heading));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            }
          }
        } else {
          if (target_heading >= 1.047 && target_heading <= 2.093) {
            Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * cosf(target_heading));

            Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
          } else if (target_heading >= -2.093 && target_heading <= -1.047) {
            Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * cosf(target_heading));

            Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
          } else if (target_heading > -1.047 && target_heading < 1.047) {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * cosf(target_heading));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            }
          } else {
            if (Obj_Pos_Center.x > 0) {
              Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * cosf(target_heading));

              Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));
            } else {
              Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * fabsf(cosf(target_heading)));

              Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));
            }
          }
        }
        if ((Obj_Pos.y > 0 && Obj_Pos_Center.y <= 0) || (Obj_Pos.y < 0 && Obj_Pos_Center.y >= 0)) {
          Obj_Pos.y = 0;
        }
      } else {
        Obj_Pos.x = Obj_Pos_Center.x;
        Obj_Pos.y = Obj_Pos_Center.y;
      } */

      Obj_Pos.x = Obj_Pos_Center.x;
      Obj_Pos.y = Obj_Pos_Center.y;
      Obj_Pos.z = Obj_Pos_Center.z;

      //==============Homo Temperary Solution==============
      // if ((fabsf(target_heading)<= 1.57 && Obj_Pos_Center.x >=0)||(fabsf(target_heading)> 1.57 && Obj_Pos_Center.x <
      // 0)) {
      //     Obj_Pos.x = Obj_Pos_Center.x - (0.5 * Obj_Size.x * cosf(target_heading));

      //     Obj_Pos.y = Obj_Pos_Center.y - (0.5 * Obj_Size.x * sinf(target_heading));

      //     Obj_Pos.z = Obj_Pos_Center.z;
      // }
      // else {
      //     Obj_Pos.x = Obj_Pos_Center.x + (0.5 * Obj_Size.x * cosf(target_heading));

      //     Obj_Pos.y = Obj_Pos_Center.y + (0.5 * Obj_Size.x * sinf(target_heading));

      //     Obj_Pos.z = Obj_Pos_Center.z;
      // }
      //====================================================

      // Obj_Pos.x = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().x();
      // Obj_Pos.y = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().y();
      // Obj_Pos.z = obf_info->obf_objects(obf_i).fuseobj().pos_vcs().z();
      tmp_obf.motion.SetPos(Obj_Pos);

      // std::cout << "target posx is " << Obj_Pos.x << std::endl;
      // std::cout << "target posy is " << Obj_Pos.y << std::endl;

      feature::math::Vector3f Obj_Pos_2D;
      Obj_Pos_2D.x = Obj_Pos.x;
      Obj_Pos_2D.y = Obj_Pos.y;
      tmp_obf.motion.SetPos(Obj_Pos_2D);

      // taowen20210706:update due to perception error
      feature::math::Vector3f Obj_Vel;
      Obj_Vel.x = obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vx();
      // Obj_Vel.x = 0;
      Obj_Vel.y = obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vy();
      Obj_Vel.z = obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vz();
      tmp_obf.motion.SetVel(Obj_Vel);

      feature::math::Vector3f Obj_Vel_2D;
      Obj_Vel_2D.x = obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vx();
      // Obj_Vel_2D.x = 0;
      Obj_Vel_2D.y = obf_info->obf_objects(obf_i).fuseobj().vel_vcs().vy();
      tmp_obf.motion.SetVel(Obj_Vel_2D);

      feature::math::Vector3f Obj_Acc;
      Obj_Acc.x = obf_info->obf_objects(obf_i).fuseobj().acc().ax();
      // Obj_Acc.x = 0;
      Obj_Acc.y = obf_info->obf_objects(obf_i).fuseobj().acc().ay();
      Obj_Acc.z = obf_info->obf_objects(obf_i).fuseobj().acc().az();
      tmp_obf.motion.SetAcc(Obj_Acc);

      tmp_obf.fusion_sup.confidence = 0.8;

      // tmp_obf.fusion_sup.confidence = obf_info->obf_objects(obf_i).fuseobj().confidence();

      tmp_obf.fusion_sup.age = obf_info->obf_objects(obf_i).fuseobj().age();

      tmp_obf.fusion_sup.fusion = obf_info->obf_objects(obf_i).fuseobj().fusion_source();

      // std::cout<<"in arb input adapter, at obj id = " <<(int)obf_i << " the fusion source is " <<
      // (int)obf_info->obf_objects(obf_i).fuseobj().fusion_source() << std::endl;

      //======================================================
      // tmp_obf.fusion_sup.fusion = obf_info->obf_objects(obf_i).fuseobj().valid_status();
      //======================================================

      tmp_obf.fusion_sup.fusion_hist = obf_info->obf_objects(obf_i).fuseobj().fusion_source_his();

      tmp_obf.fusion_sup.vision.ID = obf_info->obf_objects(obf_i).fus_sup_info().vision_match().id();

      tmp_obf.fusion_sup.vision.idx = obf_info->obf_objects(obf_i).fus_sup_info().vision_match().idx();

      tmp_obf.fusion_sup.vision.loss_match_cnt =
        obf_info->obf_objects(obf_i).fus_sup_info().vision_match().loose_match_cnt();

      tmp_obf.fusion_sup.loss_cnt = obf_info->obf_objects(obf_i).fuseobj().lost_cnt();
      fusion_object_->push_back(tmp_obf);
    }
  }
  // std::cout << "ARBInputAdapter_obfinput complete"<<std::endl;
  return true;
}

bool ARBInputAdapter::fill_arb_vis_obj_input(const std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs,
                                             std::vector<feature::ehy::Object>* vision_object_) {
  // std::cout << "ARBInputAdapter_obfvisobj start"<<std::endl;
  vision_object_->clear();
  for (int vis_i = 0; vis_i < vis_obs->dynamicobj().obj_size(); vis_i++) {
    if (vis_i <= vis_obs->dynamicobj().obj_size()) {
      feature::ehy::Object tmp_obj;
      tmp_obj.ID = vis_obs->dynamicobj().obj(vis_i).obj_object_id();

      feature::math::Vector3f Vis_Pos;
      Vis_Pos.x = vis_obs->dynamicobj().obj(vis_i).obj_distance().long_position();
      Vis_Pos.y = vis_obs->dynamicobj().obj(vis_i).obj_distance().lat_position() * coordidirection;
      Vis_Pos.z = 0;
      tmp_obj.motion.SetPos(Vis_Pos);

      feature::math::Vector3f Vis_Vel;
      Vis_Vel.x = vis_obs->dynamicobj().obj(vis_i).obj_abs_velocity().long_velocity();
      Vis_Vel.y = vis_obs->dynamicobj().obj(vis_i).obj_abs_velocity().lat_velocity() * coordidirection;
      Vis_Vel.z = 0;
      tmp_obj.motion.SetVel(Vis_Vel);

      feature::math::Vector3f Vis_Acc;
      Vis_Acc.x = vis_obs->dynamicobj().obj(vis_i).obj_abs_acc().long_acc();
      Vis_Acc.y = vis_obs->dynamicobj().obj(vis_i).obj_abs_acc().lat_acc() * coordidirection;
      Vis_Acc.z = 0;
      tmp_obj.motion.SetAcc(Vis_Acc);

      tmp_obj.motion.SetHead(vis_obs->dynamicobj().obj(vis_i).obj_heading(), 0);

      feature::math::Vector3f Vis_Size;
      Vis_Size.x = vis_obs->dynamicobj().obj(vis_i).obj_dimension().obj_length();
      Vis_Size.y = vis_obs->dynamicobj().obj(vis_i).obj_dimension().obj_width();
      Vis_Size.z = vis_obs->dynamicobj().obj(vis_i).obj_dimension().obj_height();
      tmp_obj.motion.SetSize(Vis_Size);
      tmp_obj.lane_location.lane_index        = 0;
      tmp_obj.lane_location.lane_id           = feature::ehy::ObjLaneNO::LaneNO_DEFAULT;
      tmp_obj.lane_location.lane_id_debounced = feature::ehy::ObjLaneNO::LaneNO_DEFAULT;
      tmp_obj.lane_location.debounced_cnt     = 0;
      tmp_obj.lane_location.vx_ccs            = 0.0f;
      tmp_obj.lane_location.vy_ccs            = 0.0f;
      tmp_obj.lane_location.dy_ccs            = 0.0f;
      tmp_obj.lane_location.hd_angle_2_lane   = 0.0f;
      tmp_obj.lane_location.dy_min            = 0.0f;
      tmp_obj.lane_location.dy_max            = 0.0f;
      vision_object_->push_back(tmp_obj);

      // if(vis_i == 0 || vis_i == 1 || vis_i == 2) {
      //     std::cout<<"======================visout===================="<<std::endl;
      //     std::cout<<"vis id" <<tmp_obj.ID<<std::endl;
      //     std::cout<<"vis posx" <<Vis_Pos.x<<std::endl;
      //     std::cout<<"vis posy" <<Vis_Pos.y<<std::endl;
      //     std::cout<<"vis velx" <<Vis_Vel.x<<std::endl;
      //     std::cout<<"vis vely" <<Vis_Vel.y<<std::endl;
      // }
    }
  }
  for (int vis_i = 0; vis_i < vis_obs->staticobj_size(); vis_i++) {
    if (vis_i <= (vis_obs->staticobj_size())) {
      feature::ehy::Object tmp_obj;
      tmp_obj.ID = vis_obs->staticobj(vis_i).obs_id();

      feature::math::Vector3f Vis_Pos;
      Vis_Pos.x = vis_obs->staticobj(vis_i).obs_long_distance();
      Vis_Pos.y = vis_obs->staticobj(vis_i).obs_lat_distance() * coordidirection;
      Vis_Pos.z = 0;
      tmp_obj.motion.SetPos(Vis_Pos);

      feature::math::Vector3f Vis_Vel;
      Vis_Vel.x = 0;
      Vis_Vel.y = 0 * coordidirection;
      Vis_Vel.z = 0;
      tmp_obj.motion.SetVel(Vis_Vel);

      feature::math::Vector3f Vis_Acc;
      Vis_Acc.x = 0;
      Vis_Acc.y = 0 * coordidirection;
      Vis_Acc.z = 0;
      tmp_obj.motion.SetAcc(Vis_Acc);

      tmp_obj.motion.SetHead(0, 0);

      feature::math::Vector3f Vis_Size;
      Vis_Size.x = vis_obs->staticobj(vis_i).obs_object_length();
      Vis_Size.y = vis_obs->staticobj(vis_i).obs_object_width();
      Vis_Size.z = vis_obs->staticobj(vis_i).obs_object_height();
      tmp_obj.motion.SetSize(Vis_Size);
      vision_object_->push_back(tmp_obj);
    }
  }
  // std::cout << "ARBInputAdapter_obfvisobj complete"<<std::endl;
  return true;
}

bool ARBInputAdapter::fill_ehy_tsr_input(const std::shared_ptr<nio::ad::messages::VehVariantCode> vehicle_variant_info, VehicleProjectType& vehicle_type) {
  switch (vehicle_variant_info->variant_code_info().vehicle_project()) {
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_INVALID_VEH_PROJECT:
      vehicle_type = nio::ad::VehicleProjectType_Invalid;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_FORCE:
      vehicle_type = nio::ad::VehicleProjectType_Force;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_GEMINI:
      vehicle_type = nio::ad::VehicleProjectType_Gemini;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_PEGASUS:
      vehicle_type = nio::ad::VehicleProjectType_Pegasus;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_ARIES:
      vehicle_type = nio::ad::VehicleProjectType_Aries;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_SIRIUS:
      vehicle_type = nio::ad::VehicleProjectType_Sirius;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_LIBRA:
      vehicle_type = nio::ad::VehicleProjectType_Libra;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_ORION:
      vehicle_type = nio::ad::VehicleProjectType_Orion;
      break;
    case nio::ad::messages::VariantCodeInfo_VehProjectTyp_LYRA:
      vehicle_type = nio::ad::VehicleProjectType_Libra;
      break;
    default:
      vehicle_type = nio::ad::VehicleProjectType_Invalid;
      break;
  }
  return true;
}

bool ARBInputAdapter::MainFcn(EHYRadarSensor* ehy_rdr_sensor, APSideFeature* aptiv_side_feature,
                              EHYVisionObjects* ehy_vis_obj, EHYVisionRoad* ehy_vis_road, EHYEgo* ehy_ego_input,
                              EHYEvdOutputs* ehy_evd_input, EHYHaOutputs* ehy_ha_input, EHYLppOutputs* ehy_lpp_input,
                              EHYRmeOutputs* ehy_rme_input, EHYTppOutputs* ehy_tpp_input, EHYTsiOutputs* ehy_tsi_input,
                              EHYTseOutputs* ehy_tse_input, EHYTsrOutputs* ehy_tsr_input,
                              std::vector<feature::ehy::Object>* fused_obj, std::vector<feature::ehy::Object>* vis_obj,
                              ARBSIN* arb_sin) {
  // std::cout << "ARBInputAdapter_main start"<<std::endl;
  // auto ts = Time::Now();
  receive_update();

  if (arb_radar_data_.size() > 0) {
    fill_rdr_input(arb_radar_data_.back(), ehy_rdr_sensor);
  }

  if (arb_side_feature_.size() > 0) {
    fill_side_feature(arb_side_feature_.back(), aptiv_side_feature);
  }

  if (arb_vision_objects_.size() > 0) {
    fill_vis_obj_input(arb_vision_objects_.back(), ehy_vis_obj);
    fill_arb_vis_obj_input(arb_vision_objects_.back(), vis_obj);
  }

  if (arb_road_detection_.size() > 0) {
    fill_vis_road_input(arb_road_detection_.back(), ehy_vis_road);
  }

  if (arb_vehicle_input_10_.size() > 0) {
    fill_veh_input(arb_vehicle_input_50_.back(), arb_vehicle_input_10_.back(), arb_sin);
  }

  if (arb_fusion_object_.size() > 0) {
    fill_obf_input(arb_fusion_object_.back(), fused_obj);
  }

  if (arb_ehy_ego_.size() > 0) {
    fill_ehy_ego_input(arb_ehy_ego_.back(), ehy_ego_input);
  }

  if (arb_ehy_evd_.size() > 0) {
    fill_ehy_evd_input(arb_ehy_evd_.back(), ehy_evd_input);
  }

  if (arb_ehy_ha_.size() > 0) {
    fill_ehy_ha_input(arb_ehy_ha_.back(), ehy_ha_input);
  }

  if (arb_ehy_lpp_.size() > 0) {
    fill_ehy_lpp_input(arb_ehy_lpp_.back(), ehy_lpp_input);
  }

  if (arb_ehy_rme_.size() > 0) {
    fill_ehy_rme_input(arb_ehy_rme_.back(), ehy_rme_input);
  }

  if (arb_ehy_tpp_.size() > 0) {
    fill_ehy_tpp_input(arb_ehy_tpp_.back(), ehy_tpp_input);
  }

  if (arb_ehy_tsi_.size() > 0) {
    fill_ehy_tsi_input(arb_ehy_tsi_.back(), ehy_tsi_input);
  }

  if (arb_ehy_tse_.size() > 0) {
    fill_ehy_tse_input(arb_ehy_tse_.back(), ehy_tse_input);
  }

  if (arb_ehy_tsr_.size() > 0) {
    fill_ehy_tsr_input(arb_ehy_tsr_.back(), ehy_tsr_input);
  }
  
  if (arb_vehicle_variant_info.size() > 0) {
    fill_ehy_tsr_input(arb_vehicle_variant_info.back(), arb_sin->vehicle_type);
  }

  // auto dur = Time::Now()- ts;

  // std::cout << "ARBInputAdapter_main complete, cost time"<<dur<<"ms"<<std::endl;

  return true;
}

}  // namespace ad
}  // namespace nio
