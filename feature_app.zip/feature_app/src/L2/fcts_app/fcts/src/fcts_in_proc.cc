#include "veh_in_type.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "niodds/application/application.h"
using nio::ad::messages::VEH10ms;
using nio::ad::messages::VEH50ms;
#include <iostream>

namespace nio {
    namespace ad {
        BRKSYS BrkSys;
        STRSYS StrSys;
        VEHBODY VehBody;
        VEHCTRL VehCtrl;
        VEHDRVR VehDrvr;
        VEHDYN VehDyn;
        VEHPT VehPt;
        VEHSUSPN VehSuspn;
        VEHWHL VehWhl;

        void veh_brk_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
            BrkSys.BrkPdl.BrkPedlSts = static_cast<BrkPdlSts_e>(veh10ms.brksys().brkpdl().brkpedlsts());
            BrkSys.BrkPdl.Trvl = veh10ms.brksys().brkpdl().trvl();
            BrkSys.BrkPdl.TrvlCalSts = static_cast<BrkPdlCalSts_e>(veh10ms.brksys().brkpdl().trvlcalsts());

            BrkSys.BrkPrs.BrkPrsVld = static_cast<QfZeroVld_e>(veh10ms.brksys().brkprsinfo().brkprsvld());
            BrkSys.BrkPrs.BrkPrs = veh10ms.brksys().brkprsinfo().brkprs();
            BrkSys.BrkPrs.BrkPrsOffsetVld = static_cast<QfZeroVld_e>(veh10ms.brksys().brkprsinfo().brkprsoffsetvld());
            BrkSys.BrkPrs.BrkPrsOffset = veh10ms.brksys().brkprsinfo().brkprsoffsetvld();

            if (veh10ms.brksys().prkbrk().has_epbswtsts())
            BrkSys.PrkBrk.EPBSwtSts = static_cast<EpbSwtSt_e>(veh10ms.brksys().prkbrk().epbswtsts());

            BrkSys.PrkBrk.EPBSts = static_cast<EpbSts_e>(veh10ms.brksys().prkbrk().epbsts());
            if (veh10ms.brksys().prkbrk().has_epbmod())
            BrkSys.PrkBrk.EPBMod = static_cast<EpbMod_e>(veh10ms.brksys().prkbrk().epbmod());

            BrkSys.BrkOverHeat = static_cast<BrkOvrHt_e>(veh10ms.brksys().brkoverheat());
            BrkSys.BrkHAZReq = static_cast<BrkHazReq_e>(veh10ms.brksys().brkhazreq());
            BrkSys.BCUBrkLiReq = static_cast<BcuBrkLiReq_e>(veh10ms.brksys().bcubrklireq());
            if(veh10ms.brksys().has_nobrkf()){
            BrkSys.NoBrkF = static_cast<BcuBrkF_e>(veh10ms.brksys().nobrkf());
            }

            BrkSys.BrkFldLvl = static_cast<BrkFldLvl_e>(veh10ms.brksys().brkfldlvl());
            //BrkSys.SupInfo
            //BrkSys.BrkPadWearSts
            BrkSys.BrkFunSt.BDWActv = veh10ms.brksys().brkfunst().bdwactv();
            BrkSys.BrkFunSt.ABAAvl = veh10ms.brksys().brkfunst().abaavl();
            BrkSys.BrkFunSt.ABAActv = veh10ms.brksys().brkfunst().abaactv();
            BrkSys.BrkFunSt.ABPAvl = veh10ms.brksys().brkfunst().abpavl();
            BrkSys.BrkFunSt.ABPActv = veh10ms.brksys().brkfunst().abpactv();
            BrkSys.BrkFunSt.ABSActv = veh10ms.brksys().brkfunst().absactv();
            BrkSys.BrkFunSt.AVHSts = static_cast<AvhSts_e>(veh10ms.brksys().brkfunst().avhsts());
            BrkSys.BrkFunSt.DTCActv = veh10ms.brksys().brkfunst().dtcactv();
            BrkSys.BrkFunSt.DWTActv = veh10ms.brksys().brkfunst().dwtactv();
            BrkSys.BrkFunSt.EBAAvl = veh10ms.brksys().brkfunst().ebaavl();
            BrkSys.BrkFunSt.EBAActv = veh10ms.brksys().brkfunst().ebaactv();
            BrkSys.BrkFunSt.EBDActv = veh10ms.brksys().brkfunst().ebdactv();
            BrkSys.BrkFunSt.HBAActv = veh10ms.brksys().brkfunst().hbaactv();
            BrkSys.BrkFunSt.HDCSts = static_cast<HdcSts_e>(veh10ms.brksys().brkfunst().hdcsts());
            BrkSys.BrkFunSt.HHCAvl = veh10ms.brksys().brkfunst().hhcavl();
            BrkSys.BrkFunSt.HHCActv = veh10ms.brksys().brkfunst().hhcactv();
            BrkSys.BrkFunSt.TCSActv = veh10ms.brksys().brkfunst().tcsactv();
            BrkSys.BrkFunSt.TCSDeactv = veh10ms.brksys().brkfunst().tcsdeactv();
            BrkSys.BrkFunSt.VDCActv = veh10ms.brksys().brkfunst().vdcactv();
            BrkSys.BrkFunSt.VDCDeactv = veh10ms.brksys().brkfunst().vdcdeactv();
            BrkSys.BrkFunSt.EBDFailLampReq = veh10ms.brksys().brkfunst().ebdfaillampreq();
            BrkSys.BrkFunSt.VDCTCSLampInfo = veh10ms.brksys().brkfunst().vdctcsfaillampreq();
            BrkSys.BrkFunSt.VDCTCSFailLampReq = veh10ms.brksys().brkfunst().vdctcsfaillampreq();
            BrkSys.BrkFunSt.ABSFailLampReq = veh10ms.brksys().brkfunst().absfaillampreq();
            BrkSys.BrkFunSt.VDCTCSOnOfflampReq = veh10ms.brksys().brkfunst().vdctcsonofflampreq();

        }
        void veh_str_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
            StrSys.StrAgFailSts = static_cast<StrAgFailSts_e>(veh10ms.strsys().stragfailsts());
            StrSys.StrAgCalSts = static_cast<StrAgCalSts_e>(veh10ms.strsys().stragcalsts());
            StrSys.StrWhlAg = veh10ms.strsys().strwhlagsae()*-1;
            StrSys.StrWhlAgSpd = veh10ms.strsys().strwhlagspdsae()*-1;
            StrSys.PnnAgVld = static_cast<QfZeroVld_e>(veh10ms.strsys().pnnagvld());
            StrSys.PnnAg = veh10ms.strsys().pnnagsae()*-1;
            StrSys.PnnAgOffset = veh10ms.strsys().pnnagoffsetsae()*-1;
            StrSys.OverRideDetn = veh10ms.strsys().overridedetn();

            StrSys.EstRackFrcVld = static_cast<QfZeroVld_e>(veh10ms.strsys().estrackfrcvld());
            StrSys.EstRackFrc = veh10ms.strsys().estrackfrcsae()*-1;
            StrSys.MtrTqVld = static_cast<QfZeroVld_e>(veh10ms.strsys().mtrtqvld());
            StrSys.MtrTq = veh10ms.strsys().mtrtqsae()*-1;
            StrSys.TorsBarTqVld = static_cast<QfZeroVld_e>(veh10ms.strsys().torsbartqvld());
            StrSys.TorsBarTq = veh10ms.strsys().torsbartqsae()*-1;
            StrSys.DrvngMod = static_cast<EpsDrvMod_e>(veh10ms.strsys().drvngmod());
            StrSys.RampSts = veh10ms.strsys().rampsts();
            StrSys.ACIMtrTqVld = static_cast<QfZeroVld_e>(veh10ms.strsys().acimtrtqvld());
            StrSys.ACIMtrTq = veh10ms.strsys().acimtrtqsae()*-1;
            StrSys.Temperature = veh10ms.strsys().temperature();
            StrSys.SupInfo = veh10ms.strsys().supinfo();

        }

        void veh_body_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms){
            VehBody.VehStatus.VehState = static_cast<VehSt_e>(veh50ms.vehbody().vehstatus().vehstate());
            VehBody.VehStatus.VehStateASIL = static_cast<VehSt_e>(veh50ms.vehbody().vehstatus().vehstateasil());;
            VehBody.VehStatus.VehMode = static_cast<VehMode_e>(veh50ms.vehbody().vehstatus().vehmode());

            for(int i=0; i<veh50ms.vehbody().door().doorajarsts().size();i++){
            VehBody.Door.DoorAjarSts[i] = static_cast<DoorAjarSts_e>(veh50ms.vehbody().door().doorajarsts(i));
            }
            VehBody.Door.HoodAjarSts = veh50ms.vehbody().door().hoodajarsts();
            VehBody.Door.TrAjarSts = veh50ms.vehbody().door().trajarsts();

            for(int i=0; i<veh50ms.vehbody().seatoccpsts().size(); i++){
            VehBody.SeatOccpSts[i] = static_cast<SeatOcupSt_e>(veh50ms.vehbody().seatoccpsts(i));
            }

            for(int i=0; i<veh50ms.vehbody().seatbltsts().size(); i++){
            VehBody.SeatBltSts[i] = (veh50ms.vehbody().seatbltsts(i));
            }

            VehBody.LightSts.HzrdWarnSts =static_cast<HzrdLiSts_e>(veh50ms.vehbody().lightsts().hzrdwarnsts());

            for(int i=0; i<veh50ms.vehbody().lightsts().foglists().size(); i++){
                VehBody.LightSts.FogLiSts[i] =static_cast<FogLiSt_e>(veh50ms.vehbody().lightsts().foglists(i));
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().beamsts().size(); i++){
                VehBody.LightSts.BeamSts[i] =static_cast<BeamSt_e>(veh50ms.vehbody().lightsts().beamsts(i));
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().turnindcrlists().size(); i++){
                VehBody.LightSts.TurnIndcrLiSts[i] =static_cast<TurnLiSt_e>(veh50ms.vehbody().lightsts().turnindcrlists(i));
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().mirrligtsts().size(); i++){
                VehBody.LightSts.MirrLigtSts[i] =static_cast<MirrLiSt_e>(veh50ms.vehbody().lightsts().mirrligtsts(i));
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().foglifctactvsts().size(); i++){
                VehBody.LightSts.FogLiFctActvSts[i] =static_cast<FogLiSt_e>(veh50ms.vehbody().lightsts().foglifctactvsts(i));
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().dowwarnamblests().size(); i++){
                VehBody.LightSts.DowWarnAmbLeSts[i] = veh50ms.vehbody().lightsts().dowwarnamblests(i);
            }

            for(int i=0; i<veh50ms.vehbody().lightsts().lgterrbrkli().size(); i++){
            VehBody.LightSts.LgtErrBrkLi[i] = veh50ms.vehbody().lightsts().lgterrbrkli(i);
            }
            for(int i=0; i<veh50ms.vehbody().lightsts().lgterrturnindcn().size(); i++){
            VehBody.LightSts.LgtErrTurnIndcn[i] = veh50ms.vehbody().lightsts().lgterrturnindcn(i);
            }
            VehBody.LightSts.LiSnsrData = veh50ms.vehbody().lightsts().lisnsrdata();
            VehBody.LightSts.LiSnsrFailSts = veh50ms.vehbody().lightsts().lisnsrfailsts();


            VehBody.WipperSts.FrntWiprSts = static_cast<WiprSt_e>(veh50ms.vehbody().wippersts().frntwiprsts());
            VehBody.WipperSts.FrntWiperParkSts = static_cast<WiprPrkSt_e>(veh50ms.vehbody().wippersts().frntwiperparksts());

            VehBody.Time.Yr = veh50ms.vehbody().time().yr();
            VehBody.Time.Mth = veh50ms.vehbody().time().mth();
            VehBody.Time.Day = veh50ms.vehbody().time().day();
            VehBody.Time.Hr = veh50ms.vehbody().time().day();
            VehBody.Time.Min = veh50ms.vehbody().time().min();
            VehBody.Time.Sec = veh50ms.vehbody().time().sec();

            VehBody.CenLockSts = static_cast<CenLockSts_e>(veh50ms.vehbody().cenlocksts());
            VehBody.TpmsSts = static_cast<TpmsSt_e>(veh50ms.vehbody().tpmssts());
            VehBody.DrvState = static_cast<DrvSt_e>(veh50ms.vehbody().drvstate());
            //VehBody.NBSMovReq = static_cast<NbsMov_e>(veh50ms.vehbody().nbsmovreq());
            //VehBody.NBSReq = static_cast<NbsReq_e>(veh50ms.vehbody().nbsreq());
            VehBody.AmbTempValid = veh50ms.vehbody().ambtempvalid();
            VehBody.AmbTemp = veh50ms.vehbody().ambtemp();
            VehBody.TrailerModReq = static_cast<TrlrMod_e>(veh50ms.vehbody().trailermodreq());
            VehBody.SWCAdjModReq = static_cast<SwcAdjMod_e>(veh50ms.vehbody().swcadjmodreq());
            VehBody.NBSDrvrSts = static_cast<NbsDrvSt_e>(veh50ms.vehbody().nbsdrvrsts());
            VehBody.PrkgTyp = static_cast<PrkSys_e>(veh50ms.vehbody().prkgtyp());
            VehBody.CrashDetd = veh50ms.vehbody().crashdetd();
            VehBody.AdsLampReq = veh50ms.vehbody().adslampreq();
            VehBody.IntrTemp = veh50ms.vehbody().intrtemp();
            VehBody.IntrTempVld = static_cast<QfZeroVld_e>(veh50ms.vehbody().intrtempvld());
            VehBody.MaiLiSet = static_cast<MnLiSt_e>(veh50ms.vehbody().mailiset());
            VehBody.SDWReq = static_cast<ReqZeroAsOn_e>(veh50ms.vehbody().sdwreq());
            VehBody.UPAReq = static_cast<ReqZeroAsOn_e>(veh50ms.vehbody().upareq());

        }

        void veh_ctrl_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
            VehCtrl.LngCtrlIf.VLCAvl = veh10ms.vehctrlif().lngctrlif().vlcavl();
            VehCtrl.LngCtrlIf.VLCActv = veh10ms.vehctrlif().lngctrlif().vlcactv();
            VehCtrl.LngCtrlIf.VLCTarDecel = veh10ms.vehctrlif().lngctrlif().vlctardecel();
            VehCtrl.LngCtrlIf.LLCFctSt = static_cast<LlcFctSt_e>(veh10ms.vehctrlif().lngctrlif().llcfctst());
            VehCtrl.LngCtrlIf.LLCIntrrptErrTyp = static_cast<LlcIntrptErr_e>(veh10ms.vehctrlif().lngctrlif().llcintrrpterrtyp());
            VehCtrl.LngCtrlIf.AutoBrkgAvl = (veh10ms.vehctrlif().lngctrlif().autobrkgavl());
            VehCtrl.LngCtrlIf.AutoBrkgActv = (veh10ms.vehctrlif().lngctrlif().autobrkgactv());
            VehCtrl.LngCtrlIf.ADTSts = static_cast<AdtSt_e>(veh10ms.vehctrlif().lngctrlif().adtsts());
            VehCtrl.LngCtrlIf.HldLampReq = static_cast<HldLampReq_e>(veh10ms.vehctrlif().lngctrlif().hldlampreq());

            VehCtrl.LatCtrlIf.ActvExtIf = static_cast<StrActvIf_e>(veh10ms.vehctrlif().latctrlif().actvextif());
            VehCtrl.LatCtrlIf.HIAvl = veh10ms.vehctrlif().latctrlif().hiavl();
            VehCtrl.LatCtrlIf.TOIAvl= veh10ms.vehctrlif().latctrlif().toiavl();
            VehCtrl.LatCtrlIf.DAIAvl= veh10ms.vehctrlif().latctrlif().daiavl();
            VehCtrl.LatCtrlIf.PAIAvl= veh10ms.vehctrlif().latctrlif().paiavl();
        }
        void veh_drvr_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms){
            for(int i = 0; i<veh50ms.drvin().strwhlswtch().adupswtsts().size();i++){
                VehDrvr.StrWhlSwtch.AdUpSwtSts[i] = static_cast<SwcSwSt_e>(veh50ms.drvin().strwhlswtch().adupswtsts(i));
            }

            for(int i = 0; i<veh50ms.drvin().strwhlswtch().enupswtsts().size();i++){
                VehDrvr.StrWhlSwtch.EnUpSwtSts[i] = static_cast<SwcSwSt_e>(veh50ms.drvin().strwhlswtch().enupswtsts(i));
            }
            VehDrvr.AdFunCfg.AEBOnOffReq = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().aebonoffreq());
            VehDrvr.AdFunCfg.DASTactileOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().dastactileonoff());
            VehDrvr.AdFunCfg.DrvAlertSysOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().drvalertsysonoff());
            VehDrvr.AdFunCfg.FCTAOnOffCmd = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().fctaonoffcmd());
            VehDrvr.AdFunCfg.FCWSetReq = static_cast<FcwSet_e>(veh50ms.drvin().adfuncfg().fcwsetreq());
            VehDrvr.AdFunCfg.GoNotifierOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().gonotifieronoff());
            VehDrvr.AdFunCfg.LnAssistTctlOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().lnassisttctlonoff());
            VehDrvr.AdFunCfg.LCAOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().lcaonoff());
            VehDrvr.AdFunCfg.LCATctlWarnOnOff = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().lcatctlwarnonoff());
            VehDrvr.AdFunCfg.RCTAReq = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().rctareq());
            VehDrvr.AdFunCfg.SetHMA = static_cast<HmaOnOff_e>(veh50ms.drvin().adfuncfg().sethma());
            VehDrvr.AdFunCfg.SetLnAssiAidTyp = static_cast<LnAssistAid_e>(veh50ms.drvin().adfuncfg().setlnassiaidtyp());
            VehDrvr.AdFunCfg.SetLaneAssiSnvty = static_cast<LnAssistSnvty_e>(veh50ms.drvin().adfuncfg().setlaneassisnvty());
            VehDrvr.AdFunCfg.LKAStrSprtLvlSet = static_cast<LkaStrSprtLvl_e>(0);
            VehDrvr.AdFunCfg.RCTABReq = static_cast<AdFunOnOff_e>(veh50ms.drvin().adfuncfg().rctabreq());
            VehDrvr.AdFunCfg.SAPAPrkgModReq = static_cast<SapaPrkMod_e>(veh50ms.drvin().adfuncfg().sapaprkgmodreq());
            VehDrvr.AdFunCfg.CDCFailSts = static_cast<CdcFailSt_e>(veh50ms.drvin().adfuncfg().cdcfailsts());

            VehDrvr.FogLiPushSwtSts = static_cast<FogLiSwtSt_e>(veh50ms.drvin().foglipushswtsts());
            VehDrvr.FrntWiprInterSpd = static_cast<WiprSpdSet_e>(veh50ms.drvin().frntwiprinterspd());
            VehDrvr.FrntWiprSwtSts = static_cast<WiprSwtSt_e>(veh50ms.drvin().frntwiprswtsts());
            VehDrvr.HiBeamSwtSts = static_cast<HiBeamSwtSt_e>(veh50ms.drvin().hibeamswtsts());
            VehDrvr.TurnIndcrSwtSts = static_cast<TrnIndcrSwSt_e>(veh50ms.drvin().turnindcrswtsts());
            VehDrvr.WiprAutoSwtSts = static_cast<WiprAutoSwSt_e>(veh50ms.drvin().wiprautoswtsts());
            VehDrvr.WshrReWiprSwtSts = static_cast<WshrReWiprSwtSt_e>(veh50ms.drvin().wiprautoswtsts());
            VehDrvr.SCMFailSts = static_cast<ScmFailSt_e>(veh50ms.drvin().scmfailsts());
            VehDrvr.FogLiSCMCmd = static_cast<FogLiCmd_e>(veh50ms.drvin().fogliscmcmd());
            VehDrvr.HiBeamSCMCmd = static_cast<HiBmCmd_e>(veh50ms.drvin().hibeamscmcmd());
            VehDrvr.ReWiprSCMCmd = static_cast<ReWiprCmd_e>(veh50ms.drvin().rewiprscmcmd());
            VehDrvr.SVCAvl = static_cast<SvcAvl_e>(veh50ms.drvin().svcavl());
            VehDrvr.NaviSpdLim = (veh50ms.drvin().navispdlim());
            VehDrvr.WTIDispSt = static_cast<WtiDispSt_e>(veh50ms.drvin().wtidispst());
            VehDrvr.NaviSpdUnit = static_cast<NaviSpdUnit_e>(veh50ms.drvin().navispdunit());
            VehDrvr.NaviSpdLimSts = static_cast<NaviSpdLimSt_e>(veh50ms.drvin().navispdlimsts());
            VehDrvr.NaviCurrentRoadTyp = static_cast<NaviCrrntRd_e>(veh50ms.drvin().navicurrentroadtyp());
            VehDrvr.NavCtryCod = (veh50ms.drvin().navctrycod());

        }

        void veh_dyn_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
            VehDyn.VehSpd.VehSpdSts = static_cast<QfZeroVld_e>(veh10ms.vehdyn().vehspd().vehspdsts());
            VehDyn.VehSpd.VehMovgDir= static_cast<VehMovDir_e>(veh10ms.vehdyn().vehspd().vehmovgdir());
            VehDyn.VehSpd.VehSpdkph = veh10ms.vehdyn().vehspd().vehspdkph();
            VehDyn.VehSpd.VehSpdmps = veh10ms.vehdyn().vehspd().vehspdmps();
            VehDyn.VehSpd.VehFiltLngAcc = veh10ms.vehdyn().vehspd().vehfiltlngacc();
            VehDyn.VehSpd.VehSpdASILDSts = static_cast<QfZeroVld_e>(veh10ms.vehdyn().vehspd().vehspdasildsts());
            VehDyn.VehSpd.VehSpdASILD = veh10ms.vehdyn().vehspd().vehspdasild();
            VehDyn.VehSpd.VehDispSpd = veh10ms.vehdyn().vehspd().vehdispspd();

            VehDyn.AxAyYrsCalSts = static_cast<ImuCalSt_e>(veh10ms.vehdyn().axayyrscalsts());
            VehDyn.LgtASts = static_cast<ImuSigalSt_e>(veh10ms.vehdyn().lgtasts());
            VehDyn.LgtAg = veh10ms.vehdyn().lgtsaeag()*-1;
            VehDyn.LgtAmpss = VehDyn.LgtAg*9.81;
            VehDyn.LatASts = static_cast<ImuSigalSt_e>(veh10ms.vehdyn().latasts());
            VehDyn.LatAg = veh10ms.vehdyn().latsaeag()*-1;
            VehDyn.LatAmpss = VehDyn.LatAg*9.81;
            VehDyn.YawRateSts =static_cast<ImuSigalSt_e>(veh10ms.vehdyn().yawratests());
            VehDyn.YawRateRps = veh10ms.vehdyn().yawratesaerps()*-1;
            VehDyn.YawRateDps = veh10ms.vehdyn().yawratesaedps()*-1;
            VehDyn.VehOdom = veh10ms.vehdyn().vehodom();
        }

        void veh_pt_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms){
            VehPt.AccrPedal.EfcPosnVld = static_cast<QfZeroVld_e>(veh10ms.pt().accrpedal().efcposnvld());
            VehPt.AccrPedal.EfcPosn = veh10ms.pt().accrpedal().efcposn();
            VehPt.AccrPedal.ActPosnVld = static_cast<QfZeroVld_e>(veh10ms.pt().accrpedal().actposnvld());;
            VehPt.AccrPedal.ActPosn = veh10ms.pt().accrpedal().actposn();
            VehPt.AccrPedal.PedlOvrd = veh10ms.pt().accrpedal().pedlovrd();

            VehPt.Gear.SlctrPosnVld = static_cast<QfZeroVld_e>(veh10ms.pt().gear().slctrposnvld());;
            VehPt.Gear.SlctrPosn = veh10ms.pt().gear().slctrposn();
            VehPt.Gear.TrgtGearVld = static_cast<QfZeroVld_e>(veh10ms.pt().gear().trgtgearvld());;
            VehPt.Gear.TrgtGear = veh10ms.pt().gear().trgtgear();
            VehPt.Gear.ActGearVld = static_cast<QfZeroVld_e>(veh10ms.pt().gear().actgearvld());;
            VehPt.Gear.ActGear = veh10ms.pt().gear().actgear();

            for(int i = 0; i<veh10ms.pt().motor().size() ;i++){
            VehPt.Motor[i].IntdMotTqVld = static_cast<QfZeroVld_e>(veh10ms.pt().motor(i).intdmottqvld());;
            VehPt.Motor[i].IntdMotTq = veh10ms.pt().motor(i).intdmottq();
            VehPt.Motor[i].ActMotTqVld = static_cast<QfZeroVld_e>(veh10ms.pt().motor(i).actmottqvld());;
            VehPt.Motor[i].ActMotTq = veh10ms.pt().motor(i).actmottq();
            VehPt.Motor[i].MotSpdVld = static_cast<QfZeroVld_e>(veh10ms.pt().motor(i).motspdvld());;
            VehPt.Motor[i].MotSpd = veh10ms.pt().motor(i).motspd();
            }

            //VehPt.VCUTqAvl = veh10ms.pt().vcutqavl();
            //VehPt.CTABrkAvl = veh10ms.pt().ctabrkavl();
            VehPt.VCURvsLampReq = veh10ms.pt().vcurvslampreq();
            VehPt.VCUBrkLampReq = veh10ms.pt().vcubrklampreq();
            VehPt.CruiseStatus = static_cast<VcuCruiseSt_e>(veh10ms.pt().cruisestatus());
            VehPt.VCUEPBReq = static_cast<VcuEpbReq_e>(veh10ms.pt().vcuepbreq());
            VehPt.CruiseStoredSpeed = veh10ms.pt().cruisestoredspeed();
            VehPt.VCUPtWakeupReq = veh10ms.pt().vcuptwakeupreq();

        }
        void veh_suspn_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
        }
        void veh_upa_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
        }
        void veh_whl_sys_in(const VEH10ms& veh10ms,const VEH50ms& VEH50ms){
            for(int i = 1; i<veh10ms.whl().whldyn().size(); i++){
                VehWhl.WhlDyn[i].WhlSpdSts = static_cast<WhlSpdSts_e>(veh10ms.whl().whldyn(i).whlspd());
                VehWhl.WhlDyn[i].WhlSpdMovgDir = static_cast<WhlSpdDir_e>(veh10ms.whl().whldyn(i).whlspdmovgdir());
                VehWhl.WhlDyn[i].WhlSpd = veh10ms.whl().whldyn(i).whlspd();
                VehWhl.WhlDyn[i].WhlPlsCntrVld =static_cast<QfZeroVld_e>(veh10ms.whl().whldyn(i).whlplscntrvld());
                VehWhl.WhlDyn[i].WhlPlsCntr = veh10ms.whl().whldyn(i).whlplscntr();
            }

            for(int i = 1; i<veh10ms.whl().whltpms().size(); i++){
                VehWhl.WHlTpms[i].Press = veh10ms.whl().whltpms(i).press();
                VehWhl.WHlTpms[i].Temp = veh10ms.whl().whltpms(i).temp();
                VehWhl.WHlTpms[i].SnsrFailSts = veh10ms.whl().whltpms(i).snsrfailsts();
                VehWhl.WHlTpms[i].BatSts = veh10ms.whl().whltpms(i).batsts();
                VehWhl.WHlTpms[i].PressSts =static_cast<WhlTp_e>(veh10ms.whl().whltpms(i).presssts());
                VehWhl.WHlTpms[i].DeltaPressSts = veh10ms.whl().whltpms(i).deltapresssts();
                VehWhl.WHlTpms[i].TempSts = veh10ms.whl().whltpms(i).tempsts();
            }
        }
        void veh_in_proc(const VEH10ms& veh10ms,const VEH50ms& veh50ms){
            //std::cout << "veh_in_proc_arb start"<<std::endl;
            //auto ts = Time::Now();
            veh_brk_sys_in(veh10ms,veh50ms);
            veh_str_sys_in(veh10ms,veh50ms);
            veh_body_sys_in(veh10ms,veh50ms);
            veh_ctrl_sys_in(veh10ms,veh50ms);
            veh_drvr_in(veh10ms,veh50ms);
            veh_dyn_sys_in(veh10ms,veh50ms);
            veh_pt_sys_in(veh10ms,veh50ms);
            veh_suspn_sys_in(veh10ms,veh50ms);
            veh_upa_sys_in(veh10ms,veh50ms);
            veh_whl_sys_in(veh10ms,veh50ms);
            //auto dur = Time::Now() - ts;
            //std::cout << "veh_in_proc_arb complete, cost time"<<dur<<"ms"<<std::endl;
        }
    }
}
