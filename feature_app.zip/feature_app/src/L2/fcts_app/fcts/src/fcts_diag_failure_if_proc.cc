#include <iostream>
#include "fcts_diag_failure_if_proc.h"
#include "common/vehicle_out/ads.pb.h"
#include "fcts_loc_cfg.h"
#include "np/apps/fct_out.pb.h"

using nio::ad::messages::FctOut;

using nio::ad::messages::ADS;

namespace nio {
namespace ad {

void arb_diag_failure_fill(ADS& adsout, uint32_t TopicNoInit, uint32_t TopicLoss) {
  // if ((TopicNoInit | TopicLoss) & (1 << arb_Parking_ID)) {
  //   DEBUG_LOG << "APA timeout";
  //   APA_diag_failure_fill(adsout);
  // }
  // if ((TopicNoInit | TopicLoss) & (1 << arb_FctOut_ID)) {
  //   DEBUG_LOG << "FCT timeout";
  //   ISA_diag_failure_fill(adsout);
  //   Pilot_diag_failure_fill(adsout);
  //   LKA_diag_failure_fill(adsout);
  //   ALC_diag_failure_fill(adsout);
  // }
  // if ((TopicNoInit | TopicLoss) & (1 << arb_side_feature_ID)) {
  //   DEBUG_LOG << "BSD timeout";
  //   BSD_diag_failure_fill(adsout);
  // }
  // AHC_diag_failure_fill(adsout);
}  // namespace ad

void APA_diag_failure_fill(ADS& adsout) {
  // adsout.mutable_lowspdfun()->mutable_parkst()->set_sapastatus(nio::ad::messages::ParkStInfo_SapaStType_e_SapaSt_Fault);
}
void ISA_diag_failure_fill(ADS& adsout) {
  // adsout.mutable_drvrif()->mutable_spddispandcfg()->set_isamodests(
  //   nio::ad::messages::SpdDispAndCfgInfo_IsaModType_e::SpdDispAndCfgInfo_IsaModType_e_IsaMod_Fault);
}
void Pilot_diag_failure_fill(ADS& adsout) {
  // TODO
}
void LKA_diag_failure_fill(ADS& adsout) {
  // adsout.mutable_drvrif()->mutable_npdrvif()->set_lnassiststs(nio::ad::messages::LnAsstStType_e::LnAstSt_Fail);
}
void ALC_diag_failure_fill(ADS& adsout) {
  // TODO
}
void BSD_diag_failure_fill(ADS& adsout) {
  // adsout.mutable_drvrif()->mutable_sdowbsd()->add_sdowwarnsts(
  //   nio::ad::messages::SdowBsdIfInfo_SdowWarnStType_e::SdowBsdIfInfo_SdowWarnStType_e_SDOWSt_Fail);
  // adsout.mutable_drvrif()->mutable_sdowbsd()->add_bsdlcasts(
  //   nio::ad::messages::SdowBsdIfInfo_BsdLcaWarnStType_e::SdowBsdIfInfo_BsdLcaWarnStType_e_BSDlCA_Fail);
  // adsout.mutable_drvrif()->mutable_sdowbsd()->add_frntrsdsdisp(
  //   nio::ad::messages::SdowBsdIfInfo_RsdsDispType_e::SdowBsdIfInfo_RsdsDispType_e_RSDS_Error);
  // adsout.mutable_drvrif()->mutable_sdowbsd()->set_rerirsdsdisp(
  //   nio::ad::messages::SdowBsdIfInfo_RsdsDispType_e::SdowBsdIfInfo_RsdsDispType_e_RSDS_Error);
}
void AHC_diag_failure_fill(ADS& adsout) {
  // TODO
}
}  // namespace ad
}  // namespace nio
