#include "fcts_esd_out.h"

namespace nio {
namespace ad {

void fcts_esd_init_output(FctsOut& fcts_esd){
  fcts_esd.mutable_esd_aeb()->Clear();

  auto aeb_esd  = fcts_esd.mutable_esd_aeb()->Add();
  aeb_esd->set_esd_aeb_obj_id(0);
  aeb_esd->set_esd_aeb_obj_func(0);

/*   aeb_esd       = fcts_esd.mutable_esd_aeb_obj()->Add();
  aeb_esd->set_esd_aeb_obj_id(0);
  aeb_esd->set_esd_aeb_obj_func(0); */
}

void fcts_esd_fail_output(FctsOut& fcts_esd){
  fcts_esd.mutable_esd_aeb()->Clear();

  auto aeb_esd  = fcts_esd.mutable_esd_aeb()->Add();
  aeb_esd->set_esd_aeb_obj_id(0);
  aeb_esd->set_esd_aeb_obj_func(0);

/*   aeb_esd       = fcts_esd.mutable_esd_aeb_obj()->Add();
  aeb_esd->set_esd_aeb_obj_id(0);
  aeb_esd->set_esd_aeb_obj_func(0); */
}

void fcts_esd_fill_output(FctsOut& fcts_esd){
  fcts_esd.mutable_esd_aeb()->Clear();

  auto aeb_esd  = fcts_esd.mutable_esd_aeb()->Add();

  if(FCWReq.get_pre_warn() != 0){
    aeb_esd->set_esd_aeb_obj_func(1);

    if(FusionCCRFlag_.Warning_flag == kAEBAlertActive){
      if(ccr_candidate.CCRS_Candi_.warnig_flag == 1 ||  
          ccr_candidate.CCRS_Candi_.prefill_flag == 1 || 
          ccr_candidate.CCRS_Candi_.lowbrake_flag == 1 ||
          ccr_candidate.CCRS_Candi_.highbrake_flag == 1){
            aeb_esd->set_esd_aeb_obj_id(ccr_candidate.CCRS_Candi_.u8_ID);
      }
      else if(ccr_candidate.CCRM_Candi_.warnig_flag == 1 ||  
              ccr_candidate.CCRM_Candi_.prefill_flag == 1 || 
              ccr_candidate.CCRM_Candi_.lowbrake_flag == 1 ||
              ccr_candidate.CCRM_Candi_.highbrake_flag == 1){
                aeb_esd->set_esd_aeb_obj_id(ccr_candidate.CCRM_Candi_.u8_ID);
      }
      else if(ftap_candidate.FTAP_Candi_.warnig_flag > 0 ||  
              ftap_candidate.FTAP_Candi_.prefill_flag > 0 || 
              ftap_candidate.FTAP_Candi_.lowbrake_flag > 0 ||
              ftap_candidate.FTAP_Candi_.highbrake_flag > 0){
                aeb_esd->set_esd_aeb_obj_id(ftap_candidate.FTAP_Candi_.u8_ID);
      }
    }
    else if(FusionVRUFlag_.Warning_flag == kAEBAlertActive){
      if(vru_candidate.pedestrian_cross_Candidate_.u8_warning > 0 ||  
          vru_candidate.pedestrian_cross_Candidate_.u8_prefill > 0 || 
          vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0 ||
          vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0){
            aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_cross_Candidate_.obj.u8_ID);
      }
      else if(vru_candidate.bicycle_cross_Candidate_.u8_warning > 0 ||  
              vru_candidate.bicycle_cross_Candidate_.u8_prefill > 0 || 
              vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0 ||
              vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0){
                aeb_esd->set_esd_aeb_obj_id(vru_candidate.bicycle_cross_Candidate_.obj.u8_ID);
      }
      else if(vru_candidate.pedestrian_oncom_Candidate_.u8_warning > 0 ||  
              vru_candidate.pedestrian_oncom_Candidate_.u8_prefill > 0 || 
              vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0 ||
              vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0){
                aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_oncom_Candidate_.obj.u8_ID);
      }
      else if(vru_candidate.bicycle_oncom_Candidate_.u8_warning > 0 ||  
              vru_candidate.bicycle_oncom_Candidate_.u8_prefill > 0 || 
              vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0 ||
              vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0){
                aeb_esd->set_esd_aeb_obj_id(vru_candidate.bicycle_oncom_Candidate_.obj.u8_ID);
      }
    }
    else if(FusionVRURearFlag_.Warning_flag == kAEBAlertActive){
      if(vru_candidate.pedestrian_rearcross_Candidate_.u8_warning > 0 ||  
          vru_candidate.pedestrian_rearcross_Candidate_.u8_prefill > 0 || 
          vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0 ||
          vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0){
            aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_rearcross_Candidate_.obj.u8_ID);
      }
    }
  }
  else{
    aeb_esd->set_esd_aeb_obj_id(0);
    aeb_esd->set_esd_aeb_obj_func(0);
  }

/* aeb_esd = fcts_esd.mutable_esd_aeb_obj()->Add();

  if(AEBReq.get_aeb_req() == true){
    aeb_esd->set_esd_aeb_obj_func(2);

    if(FusionCCRFlag_.lowbrake_flag == kAEBAlertActive || FusionCCRFlag_.highbrake_flag == kAEBAlertActive){
      if(ccr_candidate.CCRS_Candi_.lowbrake_flag == 1 || ccr_candidate.CCRS_Candi_.highbrake_flag == 1){
        aeb_esd->set_esd_aeb_obj_id(ccr_candidate.CCRS_Candi_.u8_VID);
      }
      else if(ccr_candidate.CCRM_Candi_.lowbrake_flag == 1 || ccr_candidate.CCRM_Candi_.highbrake_flag == 1){
        aeb_esd->set_esd_aeb_obj_id(ccr_candidate.CCRM_Candi_.u8_VID);
      }
      else if(ftap_candidate.FTAP_Candi_.lowbrake_flag > 0 || ftap_candidate.FTAP_Candi_.highbrake_flag > 0){
        aeb_esd->set_esd_aeb_obj_id(ftap_candidate.FTAP_Candi_.u8_VID);
      }
    }

    else if(FusionVRUFlag_.lowbrake_flag == kAEBAlertActive || FusionVRUFlag_.highbrake_flag == kAEBAlertActive){
      if(vru_candidate.pedestrian_cross_Candidate_.u8_lowBrake > 0 || vru_candidate.pedestrian_cross_Candidate_.u8_highBrake > 0){
        aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_cross_Candidate_.u8_VisID);
      }
      else if(vru_candidate.bicycle_cross_Candidate_.u8_lowBrake > 0 || vru_candidate.bicycle_cross_Candidate_.u8_highBrake > 0){
        aeb_esd->set_esd_aeb_obj_id(vru_candidate.bicycle_cross_Candidate_.u8_VisID);
      }
      else if(vru_candidate.pedestrian_oncom_Candidate_.u8_lowBrake > 0 || vru_candidate.pedestrian_oncom_Candidate_.u8_highBrake > 0){
        aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_oncom_Candidate_.u8_VisID);
      }
      else if(vru_candidate.bicycle_oncom_Candidate_.u8_lowBrake > 0 || vru_candidate.bicycle_oncom_Candidate_.u8_highBrake > 0){
        aeb_esd->set_esd_aeb_obj_id(vru_candidate.bicycle_oncom_Candidate_.u8_VisID);
      }
    }

    else if(FusionVRURearFlag_.lowbrake_flag == kAEBAlertActive || FusionVRURearFlag_.highbrake_flag == kAEBAlertActive){
      if(vru_candidate.pedestrian_rearcross_Candidate_.u8_lowBrake > 0 || vru_candidate.pedestrian_rearcross_Candidate_.u8_highBrake > 0){
        aeb_esd->set_esd_aeb_obj_id(vru_candidate.pedestrian_rearcross_Candidate_.u8_VisID);
      }
    }
  }
  else{
    aeb_esd->set_esd_aeb_obj_id(0);
    aeb_esd->set_esd_aeb_obj_func(0);
  } */
  
}


}  // namespace ad
}  // namespace nio