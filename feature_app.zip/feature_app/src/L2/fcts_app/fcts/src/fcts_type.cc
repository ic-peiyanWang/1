#include <iostream>
#include "fcts_type.h"

namespace nio {
    namespace ad {
        Feature_Arbitration feature_arbi;
    }
}