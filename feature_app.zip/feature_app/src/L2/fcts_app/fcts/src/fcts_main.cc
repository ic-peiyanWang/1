#include <iostream>
#include "fcts_main.h"
#include "aeb_condition_proc.h"
#include "aeb_in_house.h"
#include "aeb_main.h"
#include "aeb_output_publisher.h"
#include "aeb_state.h"
#include "common/vehicle_out/ads.pb.h"
#include "fcts_actuif_proc.h"
#include "fcts_diag.h"
#include "fcts_diag_failure_if_proc.h"
#include "fcts_in_proc.h"
#include "fcts_input_adapter.h"
#include "fcw_condition_proc.h"
#include "fcw_state.h"
#include "niodds/application/application.h"
#include "np/apps/fct_out.pb.h"
#include "np/apps/fcts_out.pb.h"
#include "np/apps/parking_outputs.pb.h"
#include "rctab_translation.h"

#if defined(__aarch64_defined__)
#include "fault_tsp_log.h"
#endif

using nio::ad::messages::ADS;
using nio::ad::messages::FctOut;
using nio::ad::messages::FctsOut;

namespace nio {
namespace ad {

APP_state_e ArbState;
APP_state_e ArbState_lf;

std::string fault_type;
std::string fault_name;
uint8_t     fault_byte;
uint8_t     fault_bit;
bool        fault_state;

#if defined(__aarch64_defined__)
DiagTsp_log fcts_tsp_log;
#endif

uint32_t init_max_cnt = 0;

uint16_t fcts_fault_cnt = 0;

extern Feature_Arbitration feature_arbi;

void arb_main(const VEH10ms& veh10ms, const VEH50ms& veh50ms, FctsOut& fctsout, nio::ad::ARBSIN* arb_sin,
              nio::ad::ARBInputAdapter* arbinput, nio::ad::AEBOutputPublisher* aeboutput, uint32_t TopicNoInit,
              uint32_t TopicLoss) {
  // std::cout << "arb_main start"<<std::endl;
  // auto ts = Time::Now();

  arbinput->MainFcn(&arb_sin->radar_info, &arb_sin->side_feature_input, &arb_sin->vision_objects, &arb_sin->vision_road,
                    &arb_sin->ehy_ego, &arb_sin->ehy_evd, &arb_sin->ehy_ha, &arb_sin->ehy_lpp, &arb_sin->ehy_rme,
                    &arb_sin->ehy_tpp, &arb_sin->ehy_tsi, &arb_sin->ehy_tse, &arb_sin->ehy_tsr, &arb_sin->fused_obj,
                    &arb_sin->vis_obj, arb_sin);
  veh_in_proc(veh10ms, veh50ms);

  aeb_main();

  rctab_trans.mainfunction(*arb_sin);

  arb_actu_if_req(AEBReq, FCWReq, AEBSm, aebrearsm, FCWSm, rctab_trans.rcta_output, fctsout, TopicNoInit, TopicLoss);
}

void fcts_init_output(FctsOut& fctsout) {
  fctsout.mutable_aeb()->set_aba_req(0);
  fctsout.mutable_aeb()->set_abalvl_req(0);
  fctsout.mutable_aeb()->set_abp_req(0);
  fctsout.mutable_aeb()->set_aeb_req(0);
  fctsout.mutable_aeb()->set_aeb_tar_decel(0);
  fctsout.mutable_aeb()->set_awb_req(0);
  fctsout.mutable_aeb()->set_awblvl_req(0);
  fctsout.mutable_aeb()->set_eba_req(0);
  fctsout.mutable_aeb()->set_aebsts(0);
  fctsout.mutable_aeb()->set_fcwsetst(0);
  fctsout.mutable_aeb()->set_prewarnreq(0);
  fctsout.mutable_aeb()->set_txtinfo(0);
  fctsout.mutable_aeb()->set_aebdecelreq_dummyfordvr(0);
  fctsout.mutable_aebrear()->set_aebrearsts(1);
  fctsout.mutable_aes()->set_aes_pncsts(0);
  fctsout.mutable_aes()->set_epsaciramprate(0);
  fctsout.mutable_aes()->set_epsacireqsae(0);
  fctsout.mutable_aes()->set_epsacisaflim_angdyn(0);
  fctsout.mutable_aes()->set_epsacisaflim_angdynoffs(0);
  fctsout.mutable_aes()->set_epsacisaflim_anglm(0);
  fctsout.mutable_aes()->set_epsacisaflim_angrm(0);
  fctsout.mutable_aes()->set_epsacisaflim_mode(0);
  fctsout.mutable_aes()->set_epsacisaflim_rate(0);
  fctsout.mutable_aes()->set_epsaciovrthr(0);
  fctsout.mutable_aes()->set_epsacitsusup(0);
  fctsout.mutable_aes()->set_epsctireqsae(0);
  fctsout.mutable_aes()->set_laneassiststs(0);
  fctsout.mutable_aes()->set_aes_sts(0);
  fctsout.mutable_aes()->set_aes_warningsts(0);
  fctsout.mutable_rctb()->set_vlc_driveoffreq(0);
  fctsout.mutable_rctb()->set_vlc_maxjerka(0);
  fctsout.mutable_rctb()->set_vlc_minjerka(0);
  fctsout.mutable_rctb()->set_vlc_mode(0);
  fctsout.mutable_rctb()->set_vlc_reqrctb(0);
  fctsout.mutable_rctb()->set_vlc_shutdownmodreq(0);
  fctsout.mutable_rctb()->set_vlc_tara(0);
  fctsout.mutable_rctb()->set_vlc_deceltostopreq(0);
  fctsout.mutable_rctb()->set_rctbbrksts(0);
}

void fcts_fail_output(FctsOut& fctsout) {
  fctsout.mutable_aeb()->set_aba_req(0);
  fctsout.mutable_aeb()->set_abalvl_req(0);
  fctsout.mutable_aeb()->set_abp_req(0);
  fctsout.mutable_aeb()->set_aeb_req(0);
  fctsout.mutable_aeb()->set_aeb_tar_decel(0);
  fctsout.mutable_aeb()->set_awb_req(0);
  fctsout.mutable_aeb()->set_awblvl_req(0);
  fctsout.mutable_aeb()->set_eba_req(0);
  fctsout.mutable_aeb()->set_aebsts(3);
  fctsout.mutable_aeb()->set_fcwsetst(0);
  fctsout.mutable_aeb()->set_prewarnreq(0);
  fctsout.mutable_aeb()->set_txtinfo(6);
  fctsout.mutable_aeb()->set_aebdecelreq_dummyfordvr(0);
  fctsout.mutable_aebrear()->set_aebrearsts(2);
  fctsout.mutable_aes()->set_aes_pncsts(0);
  fctsout.mutable_aes()->set_epsaciramprate(0);
  fctsout.mutable_aes()->set_epsacireqsae(0);
  fctsout.mutable_aes()->set_epsacisaflim_angdyn(0);
  fctsout.mutable_aes()->set_epsacisaflim_angdynoffs(0);
  fctsout.mutable_aes()->set_epsacisaflim_anglm(0);
  fctsout.mutable_aes()->set_epsacisaflim_angrm(0);
  fctsout.mutable_aes()->set_epsacisaflim_mode(0);
  fctsout.mutable_aes()->set_epsacisaflim_rate(0);
  fctsout.mutable_aes()->set_epsaciovrthr(0);
  fctsout.mutable_aes()->set_epsacitsusup(0);
  fctsout.mutable_aes()->set_epsctireqsae(0);
  fctsout.mutable_aes()->set_laneassiststs(0);
  fctsout.mutable_aes()->set_aes_sts(0);
  fctsout.mutable_aes()->set_aes_warningsts(0);
  fctsout.mutable_rctb()->set_vlc_driveoffreq(0);
  fctsout.mutable_rctb()->set_vlc_maxjerka(0);
  fctsout.mutable_rctb()->set_vlc_minjerka(0);
  fctsout.mutable_rctb()->set_vlc_mode(0);
  fctsout.mutable_rctb()->set_vlc_reqrctb(0);
  fctsout.mutable_rctb()->set_vlc_shutdownmodreq(0);
  fctsout.mutable_rctb()->set_vlc_tara(0);
  fctsout.mutable_rctb()->set_vlc_deceltostopreq(0);
  fctsout.mutable_rctb()->set_rctbbrksts(0);
}

void fcts_fault_log(FctsOut& fctsout) {
  static uint32_t last_aebsts_ = 0;
  uint8_t         tsp_disable  = 0;
  uint32_t        aebsts_      = fctsout.aeb().aebsts();
  if (3 == aebsts_) {
    fcts_fault_cnt++;
  } else {
    fcts_fault_cnt = 0;
  }
  if (fcts_fault_cnt >= 15000) {
    last_aebsts_   = 0;
    fcts_fault_cnt = 0;
    tsp_disable    = 1;
  }

  if (3 != last_aebsts_ && 3 == aebsts_) {
    fault_state = true;
    fault_type  = "AEB_Internal_Fault";

    INFO_LOG << "Fcts_Fault_Log_aeb_gAEBFaultSt: " << static_cast<uint32_t>(gAEBFaultSt);
    INFO_LOG << "Fcts_Fault_Log_aeb_gFCWFaultSt: " << static_cast<uint32_t>(gFCWFaultSt);
    INFO_LOG << "Fcts_Fault_Log_aeb_AebTopicState: " << static_cast<uint32_t>(AebState);
    INFO_LOG << "Fcts_Fault_Log_aeb_FcwTopicState: " << static_cast<uint32_t>(FcwState);

    if ((AebState != APP_state_e::FullActive) || (FcwState != APP_state_e::FullActive)) {
      INFO_LOG << "Fcts_Fault_Log_aeb_TopicLoss: " << static_cast<uint32_t>(Arb_TopicLoss);
      INFO_LOG << "Fcts_Fault_Log_aeb_TopicNoInit: " << static_cast<uint32_t>(Arb_TopicNoInit);
      if (((Arb_TopicLoss | Arb_TopicNoInit) & 0x1) != 0) {
        fault_name = "RadarObj_Topic_Los";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "common/perception/radar_object Loss";
      }
      if (((Arb_TopicLoss | Arb_TopicNoInit) & 0x4) != 0) {
        fault_name = "VisionObj_Topic_Los";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "common/perception/perception_objects Loss";
      }
      if (((Arb_TopicLoss | Arb_TopicNoInit) & 0x08) != 0) {
        fault_name = "Veh10ms_Topic_Los";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "common/vehicle_in_10 Loss";
      }
      if (((Arb_TopicLoss | Arb_TopicNoInit) & 0x10) != 0) {
        fault_name = "Veh50ms_Topic_Los";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "common/vehicle_in_50 Loss";
      }
      if (((Arb_TopicLoss | Arb_TopicNoInit) & 0x40) != 0) {
        fault_name = "EhyObj_Topic_Los";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "np/apps/ehy_obf_outputs Loss";
      }
    }

    if (AEB_FIMnum != 0) {
      fault_name = "FIM_Cause_Fault";
      for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
        if (gAEBFimByte[index] != 0) {
          for (uint8_t bit = 0; bit < 8; bit++) {
            if ((gAEBFimByte[index] & (1 << bit)) != 0) {
              fault_byte = index;
              fault_bit  = bit;
              INFO_LOG << "Fcts_Fault_Log ---"
                       << "gAEBFim  Byte Num: " << static_cast<uint32_t>(index)
                       << "  bit Num:  " << static_cast<uint32_t>(bit);
            }
          }
        } else {
          // nothing
        }
      }
    } else {
      fault_byte = 0;
      fault_bit  = 0;
    }
    if (FCW_FIMnum != 0) {
      for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
        if (gFCWFimByte[index] != 0) {
          for (uint8_t bit = 0; bit < 8; bit++) {
            if ((gFCWFimByte[index] & (1 << bit)) != 0) {
              INFO_LOG << "Fcts_Fault_Log ---"
                       << "gFCWFim  Byte Num: " << static_cast<uint32_t>(index)
                       << "  bit Num:  " << static_cast<uint32_t>(bit);
            }
          }
        } else {
          // nothing
        }
      }
    }
    if (RearAEB_FIMnum != 0) {
      for (uint8_t index = 0; index < DIAG_FIM_MAX_MASK_NUM; index++) {
        if (gRearAEBFimByte[index] != 0) {
          for (uint8_t bit = 0; bit < 8; bit++) {
            if ((gRearAEBFimByte[index] & (1 << bit)) != 0) {
              INFO_LOG << "Fcts_Fault_Log ---"
                       << "gRearAEB  Byte Num: " << static_cast<uint32_t>(index)
                       << "  bit Num:  " << static_cast<uint32_t>(bit);
            }
          }
        } else {
          // nothing
        }
      }
    }
    if ((gAEBFaultSt != FimFault_e::NoFault) && (AEB_FIMnum == 0)) {
      if (gFWfailsafe.high != 0) {
        fault_name = "FW_Failsafe";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "gFWfailsafe : " << static_cast<uint32_t>(gFWfailsafe.high);
      }
      if (gFNfailsafe.high != 0) {
        fault_name = "FN_Failsafe";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "gFNfailsafe : " << static_cast<uint32_t>(gFNfailsafe.high);
      }
      if (gLidarfailsafe.high != 0) {
        fault_name = "Lidar_Failsafe";
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "gLidarfailsafe : " << static_cast<uint32_t>(gLidarfailsafe.high);
      }
    }
    if ((gRearAEBFaultSt != FimFault_e::NoFault) && (RearAEB_FIMnum == 0)) {
      if (gRearfailsafe.high != 0) {
        INFO_LOG << "Fcts_Fault_Log ---"
                 << "gRearfailsafe : " << static_cast<uint32_t>(gRearfailsafe.high);
      }
    }

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      fcts_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }

  if (3 == last_aebsts_ && 3 != aebsts_) {
    fault_state = false;
    INFO_LOG << "Fcts_Fault_Log_AEB_ Fault  : recover ";

#if defined(__aarch64_defined__)
    if (tsp_disable == 0) {
      fcts_tsp_log.FaultTspLog(fault_type, fault_name, fault_byte, fault_bit, fault_state);
    }
#endif
  }
  last_aebsts_ = aebsts_;
}

void arb_init(void) {}
}  // namespace ad
}  // namespace nio
