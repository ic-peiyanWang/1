#include "common/vehicle_out/ads.pb.h"
#include "np/apps/fct_out.pb.h"
#include <iostream>
#include "fcts_actuif_proc.h"
#include "fcts_loc_cfg.h"
#include "aeb_calibration.h"
//#include "AesPNC.h"

using nio::ad::messages::FctsOut;

namespace nio {
namespace ad {
extern unsigned char fcwsetst;

void arb_actu_if_req(nio::ad::AEBREQ& aebreq,nio::ad::FCWREQ& fcwreq, nio::ad::AEBSM& aebsm, AebRearSm& aebrear_sm, nio::ad::FCWSM& fcwsm, RctabOutput &rctb_out, FctsOut &fctsout, const uint32_t& TopicNoInit, const uint32_t& TopicLoss) {

  aeb_sys_req(aebreq, fcwreq, aebsm, aebrear_sm, fcwsm, fctsout);

  aes_sys_req(fctsout);

  rctab_sys_req(rctb_out, fctsout);
} 

void rctab_sys_req(RctabOutput &rctb_out, FctsOut &fctsout) {
  fctsout.mutable_rctb()->set_rctbbrksts(rctb_out.RCTABrkSts);

  fctsout.mutable_rctb()->set_vlc_driveoffreq(rctb_out.VLC_DriveOffReq);

  fctsout.mutable_rctb()->set_vlc_maxjerka(rctb_out.VLC_MaxJerkA);
  
  fctsout.mutable_rctb()->set_vlc_minjerka(rctb_out.VLC_MinJerkA);

  fctsout.mutable_rctb()->set_vlc_mode(rctb_out.VLC_Mode);

  fctsout.mutable_rctb()->set_vlc_reqrctb(rctb_out.VLC_ReqFct);

  fctsout.mutable_rctb()->set_vlc_shutdownmodreq(rctb_out.VLC_ShutdownModReq);

  fctsout.mutable_rctb()->set_vlc_tara(rctb_out.VLC_TarA);

  fctsout.mutable_rctb()->set_vlc_deceltostopreq(rctb_out.VLC_DecelToStopReq);

  fctsout.mutable_bsd()->set_bsd_hvireq(rctb_out.BSD_hviReq);
}

void aeb_sys_req(nio::ad::AEBREQ& aebreq,nio::ad::FCWREQ& fcwreq, nio::ad::AEBSM& aebsm, AebRearSm &aebrear_sm, nio::ad::FCWSM& fcwsm, FctsOut &fctsout) {
  fctsout.mutable_aeb()->set_aba_req(static_cast<uint32_t>(aebreq.get_aba_req()));

  fctsout.mutable_aeb()->set_abalvl_req(static_cast<uint32_t>(aebreq.get_abalvl_req()));

  fctsout.mutable_aeb()->set_abp_req(static_cast<uint32_t>(aebreq.get_abp_req()));

  fctsout.mutable_aeb()->set_aeb_req(static_cast<uint32_t>(aebreq.get_aeb_req()));

  fctsout.mutable_aeb()->set_aeb_tar_decel(static_cast<float>(aebreq.get_dec_req()));

  fctsout.mutable_aeb()->set_awb_req(static_cast<uint32_t>(fcwreq.get_awb_req()));

  fctsout.mutable_aeb()->set_awblvl_req(static_cast<uint32_t>(fcwreq.get_awb_lvl()));

  fctsout.mutable_aeb()->set_eba_req(static_cast<uint32_t>(aebreq.get_eba_req()));

  fctsout.mutable_aeb()->set_aebsts(static_cast<uint32_t>(aebsm.get_aeb_sys_st()));

  fctsout.mutable_aeb()->set_fcwsetst(static_cast<uint32_t>(fcwsetst));

  fctsout.mutable_aeb()->set_prewarnreq(static_cast<uint32_t>(fcwreq.get_pre_warn()));

  fctsout.mutable_aeb()->set_aebdecelreq_dummyfordvr(AEBDecelReq_Dummy);

  if(aebrear_sm.get_state() == RearSmSt::kActive || 
      aebrear_sm.get_state() == RearSmSt::kStandby ||
      aebrear_sm.get_state() == RearSmSt::kPassive){
        fctsout.mutable_aebrear()->set_aebrearsts(0);
      }
  else if(aebrear_sm.get_state() == RearSmSt::kFail){
    fctsout.mutable_aebrear()->set_aebrearsts(2);
  }
  else{
    fctsout.mutable_aebrear()->set_aebrearsts(1);
  }

  if(aebsm.get_aeb_sys_st() == aebsysst_e::inhibit){
    aeb_fault_age++;
    aebrear_fault_age = 0;
  }
  else if(aebrear_sm.get_state() == RearSmSt::kFail){
    aebrear_fault_age++;
    aeb_fault_age = 0;
  }
  else{
    aeb_fault_age = 0;
    aebrear_fault_age = 0;
  }
  aeb_fault_age = fmin(aeb_fault_age, AebWtiDelayAge);
  aebrear_fault_age = fmin(aebrear_fault_age, AebWtiDelayAge);

  if(aeb_fault_age >= AebWtiDelayAge && ego_->vehicleinfo_in.vehiclept.Gear.ActGear != 3){
    fctsout.mutable_aeb()->set_txtinfo(0x6);
  }
  else if(aebrear_fault_age >= AebWtiDelayAge && ego_->vehicleinfo_in.vehiclept.Gear.ActGear != 3){
    fctsout.mutable_aeb()->set_txtinfo(0x16);
  }
  else{
    fctsout.mutable_aeb()->set_txtinfo(0x0);
  }
}

void aes_sys_req(FctsOut &fctsout) {
  fctsout.mutable_aes()->set_aes_pncsts(0);

  fctsout.mutable_aes()->set_epsaciramprate(0);

  fctsout.mutable_aes()->set_epsacireqsae(0);

  fctsout.mutable_aes()->set_epsacisaflim_angdyn(0);

  fctsout.mutable_aes()->set_epsacisaflim_angdynoffs(0);

  fctsout.mutable_aes()->set_epsacisaflim_anglm(0);

  fctsout.mutable_aes()->set_epsacisaflim_angrm(0);

  fctsout.mutable_aes()->set_epsacisaflim_mode(0);

  fctsout.mutable_aes()->set_epsacisaflim_rate(0);

  fctsout.mutable_aes()->set_epsaciovrthr(0);

  fctsout.mutable_aes()->set_epsacitsusup(0);

  fctsout.mutable_aes()->set_epsctireqsae(0);

  fctsout.mutable_aes()->set_laneassiststs(0);
}
}  // namespace ad
}  // namespace nio
