#pragma once
#include "veh_in_type.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
using nio::ad::messages::VEH10ms;
using nio::ad::messages::VEH50ms;

namespace nio {
    namespace ad {
        extern BRKSYS BrkSys;
        extern STRSYS StrSys;
        extern VEHBODY VehBody;
        extern VEHCTRL VehCtrl;
        extern VEHDRVR VehDrvr;
        extern VEHDYN VehDyn;
        extern VEHPT VehPt;
        extern VEHSUSPN VehSuspn;
        extern VEHWHL VehWhl;

        //extern void veh_brk_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_str_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_body_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_ctrl_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_drvr_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_dyn_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_pt_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_suspn_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_upa_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        //extern void veh_whl_sys_in(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
        extern void veh_in_proc(const VEH10ms& veh10ms,const VEH50ms& veh50ms);
    }
}