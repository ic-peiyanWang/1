#pragma once
#include "np/apps/fct_out.pb.h"
#include "common/vehicle_out/ads.pb.h"
// #include "aeb_type.h"
// #include "fcw_type.h"
#include "aeb_sin_struct.h"
#include "fcts_type.h"
#include "fcts_diag.h"
using nio::ad::messages::FctOut;
using nio::ad::messages::ADS;

namespace nio{
    namespace ad {
        extern void ISA_diag_failure_fill(ADS&adsout);
        extern void Pilot_diag_failure_fill(ADS&adsout);
        extern void LKA_diag_failure_fill(ADS&adsout);
        extern void ALC_diag_failure_fill(ADS&adsout);
        extern void BSD_diag_failure_fill(ADS&adsout);
        extern void AHC_diag_failure_fill(ADS&adsout);
        extern void APA_diag_failure_fill(ADS&adsout);
        extern void arb_diag_failure_fill(ADS& adsout, uint32_t TopicNoInit,uint32_t TopicLoss); 
    }
}