#pragma once
#include <iostream>
#include <memory>
#include <array>
#include "np/apps/fcts_out.pb.h"
#include "ehy_math/linear_interpolator_2d.h"
#include "ehy_math/linear_interpolator_1d.h"
#include "ehy_math/nio_vmath.h"
#include "fcts_input_adapter.h"
#include "aeb_state.h"
#include "fcw_state.h"
#include "aeb_type.h"
#include "fcw_type.h"
#include "aeb_sin_struct.h"
#include "fcts_diag.h"
#include "fcts_type.h"
#include "fcts_loc_cfg.h"
#include "rctab_type.h"

using nio::ad::messages::FctsOut;

namespace nio {
namespace ad {

extern void arb_actu_if_req(nio::ad::AEBREQ& aebreq,nio::ad::FCWREQ& fcwreq, nio::ad::AEBSM& aebsm, AebRearSm& aebrear_sm, nio::ad::FCWSM& fcwsm, RctabOutput &rctb_out, FctsOut &fctsout, const uint32_t& TopicNoInit, const uint32_t& TopicLoss);

extern void aeb_sys_req(nio::ad::AEBREQ& aebreq,nio::ad::FCWREQ& fcwreq, nio::ad::AEBSM& aebsm, AebRearSm& aebrear_sm, nio::ad::FCWSM& fcwsm, FctsOut &fctsout);

extern void aes_sys_req(FctsOut &fctsout);

extern void rctab_sys_req(RctabOutput &rctb_out, FctsOut &fctsout);

} // namespace ad
} // namespace nio