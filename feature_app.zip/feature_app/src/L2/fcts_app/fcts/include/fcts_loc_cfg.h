#pragma once
#ifdef DEBUG
  #define AEB_DEBUG 
  #define FCW_DEBUG
  // #define ARB_DEBUG  
  #define ARB_XCP_ENABLED
#endif
