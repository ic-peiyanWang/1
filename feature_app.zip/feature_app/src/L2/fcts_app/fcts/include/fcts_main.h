#pragma once
#include "common/vehicle_out/ads.pb.h"
#include "fcts_in_proc.h"
#include "np/apps/fct_out.pb.h"
#include "np/apps/fcts_out.pb.h"
#include "np/apps/parking_outputs.pb.h"

using nio::ad::messages::ADS;
using nio::ad::messages::FctOut;
using nio::ad::messages::FctsOut;
#include "aeb_in_house.h"
#include "aeb_output_publisher.h"
#include "fcts_diag.h"
#include "fcts_diag_failure_if_proc.h"
#include "fcts_input_adapter.h"

#if defined(__aarch64_defined__)
#include "fault_tsp_log.h"
#endif

#define Arb_InitMask (0x0000005C)
#define Arb_LossMask (0x003FF85D)

namespace nio {
namespace ad {
extern APP_state_e ArbState;
extern APP_state_e ArbState_lf;

#if defined(__aarch64_defined__)
extern DiagTsp_log fcts_tsp_log;
#endif

extern void     arb_main(const VEH10ms& veh10ms, const VEH50ms& veh50ms, FctsOut& fctsout, nio::ad::ARBSIN* arb_sin,
                         nio::ad::ARBInputAdapter* arbinput, nio::ad::AEBOutputPublisher* aeboutput, uint32_t TopicNoInit,
                         uint32_t TopicLoss);
extern void     arb_init(void);
extern uint32_t init_max_cnt;
extern void     fcts_init_output(FctsOut& fctsout);
extern void     fcts_fail_output(FctsOut& fctsout);
extern void     fcts_fault_log(FctsOut& fctsout);
}  // namespace ad
}  // namespace nio
