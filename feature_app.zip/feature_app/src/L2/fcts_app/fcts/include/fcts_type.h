#ifndef FCTS_TYPE_H
#define FCTS_TYPE_H

namespace nio {
namespace ad {
struct Longitude_Arbitration {
  // ADC03=============================
  uint8_t AD_CurrentMinContrSpeed = 0;
  uint8_t NAD_Lcmode              = 0;  // 0: off; 1: passive; 2: standby; 3: active; 4: brake only 5: override; 6: standstill; i/o
  uint8_t NAD_LongCtrlTar         = 0;  // 0: no target; 1: target available;
  uint8_t NAD_TauGap              = 0;  // 0: no change; 1: no change min; 2: decrease; 3:increase; 4: no change max;
  uint8_t NAD_Sts                 = 1;  // 0:defualt; 1: off; 2: passive; 3: acc standby; 4: pilot standby; 5: acc active; 6: np active;
                        // 7: np active long only; 8: nop active;
  uint8_t NAD_TauGapSet = 0;  // 0:set 0; 1: set 1; 2: set 2; 3: set 3; 4: set 4; 5: set 5; 6: np active; 7: np active
                              // long only; 8: nop active;
  uint8_t DA_FreeSpaceIntrusion = 0;

  // ADC05=============================
  uint8_t VLC_DecelToStopReq = 0;  // 0: no req; 1:request i/o
  uint8_t VLC_DriveOffReq    = 0;  // 0: no req; 1:request i/o
  float   VLC_MaxJerkA       = 0;  // i/o
  float   VLC_MinJerkA       = 0;  // i/o
  uint8_t VLC_Mode           = 0;  // 0: off; 1: passive; 2: standby; 3: active; 4: brake only 5: override; 6: standstill; i/o
  uint8_t VLC_ReqFct = 0;          // 0: off; 1: DA; 2:FCTB; 3: RCTB; 4: SSD; 5: USD i/o
  uint8_t VLC_ShutdownModReq = 0;  // 0: no req; 1:request i/o
  float   VLC_TarA           = 0;  // i/o

  // ADC1-02===============================
  uint8_t EPBReq          = 0;       // 0: undetermine; 1: no req; 2: apply; //i/o
  uint8_t LLC_CntrlModReq = 0;       // 0: No req; 1: Dist Ctrl; 2:Spd Ctrl; i/o
  uint8_t LLC_FctSeln     = 0;       // 0: default; 1: SAPA; 2: VPPS; 3: NBS; i/o
  uint8_t LLC_FctSt       = 0;       // 0: init; 1: standby; 2: active; 3: suspend; 4: abort; i/o
  uint8_t LLC_ShutdownModReq = 0;    // 0: no req; 1: comfort brak; 2: emergency brake; 3: release to take over;
  float   LLC_StopDst        = 0;    // i/o
  uint8_t LLC_TarGearReq = 0;        // 0: no req; 1: driving; 2: reverse; 3: parking; i/o
  float   LLC_TarSpd           = 0;  // i/o
  uint8_t SafeState1           = 0;  // i/o
  float   VehDstToVSlot        = 0.0;
  float   SlopeDstOffset       = 0.0;
  uint8_t CurrentMinContrSpeed = 0;

  // RAD_FC_02======================================
  uint8_t ABAReq      = 0;  // i/o
  uint8_t ABASnvtyLvl = 0;  // i/o
  uint8_t ABPReq      = 0;  // i/o
  uint8_t AEBDecelReq = 0;  // i/o
  float   AEBTarDecel = 0;  // i/o
  uint8_t AWBReq      = 0;  // i/o
  uint8_t AWBSnvtyLvl = 0;  // i/o
  uint8_t EBADecelReq = 0;  // i/o
  uint8_t PEDPDecReq  = 0;
  uint8_t SCMDecelReq = 0;
  bool    AEBDecelReq_Dummy = 0;


  // RAD_FC_03======================================
  uint8_t AEBSts                = 0;    // i/o
  uint8_t AEBRearSts            = 1;    // i/0
  uint8_t FCWSetSts             = 0;    // i/o
  uint8_t PCW_preWarningReq     = 0;    // i/o
  uint8_t GoNotifierOnOffSts    = 0;    // i/o
  uint8_t GoNotifierReq         = 0;    // i/o
  uint8_t TSRSpdLimDataOnoffSts = 0;    // i/o
  uint8_t Textinfo              = 0x0;  // i/o
  float   ClsObjDst             = 0;    // i/o
  uint8_t ClsObjTyp             = 0;    // i/o

  // ADC04=========================================
  uint8_t DA_NAD_DisplSetSpeed = 0;  // 0: no dis; 1: dis;
  float   DA_NAD_SetSpeed      = 0;  //
  uint8_t DA_NAD_Speed_Unit    = 0;  // 0: kph, 1:mph
  uint8_t DA_WTIs    = 0;  // 0: no warn; 1: sys off; 2: soft inhibit; 3: insufficient decel; 4: da activation fail
  uint8_t NAD_WTIs   = 0;  // 0: no warn; 1: take over;
  uint8_t RCTABrkSts = 0;  // i/o
};

struct Latitude_Arbitration {
  // ADC1_EPS_01==============================
  uint8_t EPSACIRampRate          = 0;  // 0-3: torque rate 1-4; i/o
  float   EPSACIReqSAE            = 0;  // i/o
  uint8_t EPSACIReqVld            = 0;  // 0: valid; 1: invalid; i/o
  float   EPSACISafLim_AngDyn     = 0;  // i/o
  float   EPSACISafLim_AngDynOffs = 0;  // 0-F:band narrow0- band wide 15; i/o
  uint8_t EPSACISafLim_AngLM      = 0;  // i/o
  uint8_t EPSACISafLim_AngRM      = 0;  // i/o
  uint8_t EPSACISafLim_Mode       = 0;  // 0: static; 1:dynamic i/o
  uint8_t EPSACISafLim_Rate       = 0;  // 0-1F rate strict 1- least 32 //i/o

  // ADC1_EPS_02================================
  uint8_t EPSACIOvrThr = 0;  // threshold 1-8;
  uint8_t EPSACITsuSup = 0;  //
  float   EPSCTIReqSAE = 0;  //
  uint8_t EPSCTIReqVal = 0;  // 0: valid; 1: invalid;
  uint8_t EPSHVIReq    = 0;  // 0: no req; 1-7: profile 1-7;
  uint8_t EPSHVIReqVal = 0;  // 0: valid; 1: invalid;
  uint8_t EPSStrIFReq  = 0;  // 0: no req; 1: ACI overlay; 2: ACI overlay+ HVI; 3: ACI overload; 4: ACI overload + HVI;
                            // 5: CTI; 6: MTI; 7: HVI;

  // CAM_FC_02===================================
  uint8_t LaneAssiHapticOnOffSts = 0;  // 0: off; 1: on;
  uint8_t LaneAssistSts          = 0;  // 0: off; 1: standby; 2: active; 3: failure; 4: cam block; i/o
  uint8_t ELKSts                 = 0;
  uint8_t ESFWarningSts          = 0;
};

struct HMI_Arbitration {
  // ADC03=============================
  uint8_t CAM_DVRFltSts  = 0;  // 0:no failure; 1: failure;
  uint8_t CAM_FrntFltSts = 0;
  uint8_t CAM_LeFltSts   = 0;
  uint8_t CAM_ReFltSts   = 0;
  uint8_t CAM_RiFltSts   = 0;
  uint8_t DA_NAD_ALCsts  = 0;  // 0: off; 1: passive; 2: active not ready; 3: ready; 4: start in left; 5: start in right;
                              // 6: ongoing touch; 7: ongoing post; 8: suppress back; 9: suppress forward; i/o
  uint8_t DA_NAD_LatCtrTarLe = 0;  // 0: no left; 1: left not use; 2: left used; 3: drift left;
  uint8_t DA_NAD_LatCtrTarRi = 0;

  // ADC01==============================
  uint8_t ADCDoorLockReq = 0;  // 0:no req; 1: all door unlock; 2: all door lock;
  uint8_t ADCHornCtrlReq = 0;  // 0: off; 1: on; 3: invalid;
  uint8_t ADDrvTypRq     = 0;  // 0: no req; 1: RMD; 2: AD; F: invalid; i/o
  uint8_t DDMReq         = 0;  // 0: no req; 1:req; 3: invalid; i/o
  uint8_t HASoundInfo    = 0;  // i/o
  uint8_t HATextInfo     = 0;  // i/o
  uint8_t NBSAbortReason = 0;
  uint8_t NBSBlkage      = 0;
  uint8_t NBSInstruction = 0;
  uint8_t WSHeatReq      = 0;
  uint8_t WSHeatReqValid = 0;

  // ADC04================================
  uint8_t AD_SysSts     = 0;               //
  uint8_t DA_HodWarnSeq = 0;               //
  uint8_t SAS_SpeedLimitAttribute = 0;     // 0: no dis; 1: warning; 2: high conf; 3: low conf;
  uint8_t SAS_SpeedLimitTakeover     = 0;  // 0: no take over; 1: manual up; 2: manual down; 3: auto adjust;
  uint8_t SAS_SpeedLimitUnit         = 0;  // 0: kph, 1:mph
  float   SAS_SpeedLimitValue        = 0;
  uint8_t SAS_SupSignAttribute       = 0;  // 0: high conf; 1: low conf;
  uint8_t SAS_SupSignType            = 0;  //
  uint8_t SAS_SLIFState              = 0;
  uint8_t SAS_SLWFWarningTrigger     = 0;
  uint8_t SAS_LocalHazards           = 0;
  uint8_t SAS_TrafficLightSts        = 0;
  uint8_t SAS_RoadFeatureWarningSign = 0;

  // CAM_FC_02==============================
  uint8_t HMAHiBeamReq = 0;  // 0: lowB; 1: highB i/o
  uint8_t HMASts       = 0;  // 0: off; 1: passive; 2: active; 3: temp fail; 4: cam block; 5: perm fail; 7: invalid; i/o
  float   LeLineDst    = 0;  // i/o
  float   RiLineDst    = 0;  // i/o
  uint8_t LeLineTyp = 0;     // 0: noline; 1:solid 2: dash; 3: other; 7: invalid; i/o
  uint8_t RiLineTyp = 0;     // 0: noline; 1:solid 2: dash; 3: other; 7: invalid; i/o
  uint8_t LaneLines = 0;     // 0: noline; 1:solid 2: dash; 3: other; 7: invalid; i/o

  // CAM_FC_03==============================
  uint8_t AdasLeline = 0;  // 0: not detect; 1: detect; 2: ldw || lka2; 3: lka1; 4: l2 pilot; 5: LC prepare; 6: LC
                           // ongoing; 7: LC abort; i/o
  uint8_t AdasRiline = 0;  // 0: not detect; 1: detect; 2: ldw || lka2; 3: lka1; 4: l2 pilot; 5: LC prepare; 6: LC
                           // ongoing; 7: LC abort; i/o
  uint8_t ADC_TurnIndicatorReq = 0;  // 0: no req; 1: hazard; 2: left; 3: right; i/o
  uint8_t ALC                  = 0;  // 0: off; 1: on turn light only; 2: on light driver torque; 3: invalid;
  uint8_t ALCsts               = 0;  // 0: off; 1: on but not all meet; 2: on ready; 3: prepare and lane change; i/o
  uint8_t DoorUnlckReq  = 0;         // 0: no req unlock door; 1: request unlock; 3: invalid; i/o
  uint8_t FCTAOnOffSts  = 0;         // 0: off; 1: on; 3: invalid;
  uint8_t LaneAssiSnvty = 0;         // 0: low; 1: normal; 2; high; 3: invalid; i/o
  uint8_t LDWLKALaneAssiTyp =
    0;  // 0: Not select; 1: LDW; 2: LKA; 3: LKS; 4: LDW and LKA; 5: LDW and LKS; 7: invalid; i/o
  uint8_t LKASteerSupportLvl = 0;  // 0: light; 1: mid; 2: strong; 3: invalid; i/o
  uint8_t LKSSnsvty = 0;           // 0: low; 1: normal; 2; high; 3: invalid; i/o
  uint8_t LKSTakeoverReq = 0;      // 0: inactive; 1: active; i/o

  // CAM_FC_04===============================
  uint8_t ACCNPStsDuplicate = 0;  // 0: off; 1: passive; 2: ready; 3: acc active; 4: standby; 5: pilot active; 6: later
                                  // unava; 7: pilot standby; i/o
  uint8_t ISAModeSts  = 0;    // 0: off; 1: manual; 2: acc; 3: pilot; 4: nop; 5: fault //i/o
  float   ISASpd      = 0;    // i/o
  uint8_t ISASpdAlert = 0;    // 0: no alert; 1: alert; i/o
  uint8_t ISASpdCfmReq = 0;   // 0: no req; 1: req high; 2: req low; 3: auto adjust; i/o
  uint8_t ISASpdUnit    = 0;  // 0: unknown; 1: kph; 2: mph; i/o
  uint8_t RemLogSts_ADC = 0;
};

struct Feature_Arbitration {
  Longitude_Arbitration long_arbi;
  Latitude_Arbitration  lat_arbi;
  HMI_Arbitration       hmi_arbi;
};

extern Feature_Arbitration feature_arbi;
}  // namespace ad
}  // namespace nio
#endif