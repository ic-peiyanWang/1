#ifndef FEATURE_fcts_input_adapter_H_
#define FEATURE_fcts_input_adapter_H_

#include "aeb_sin_struct.h"
#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_can_feature.pb.h"
#include "common/diagnostic/fim/fim_lidar.pb.h"
#include "common/diagnostic/fim/fim_mcuwithsoc_can.pb.h"
#include "common/diagnostic/fim/fim_power_rail.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"
#include "common/diagnostic/fim/fim_mcu_system.pb.h"
#include "common/diagnostic/fim/fim_perception.pb.h"
#include "common/perception/perception_objects.pb.h"
#include "common/perception/radar_object.pb.h"
#include "common/perception/side_feature.pb.h"
#include "common/perception/vision_failsafe.pb.h"
#include "common/perception/lidar_failsafe.pb.h"
#include "common/perception/vision_road_detection.pb.h"
#include "common/vehicle_in/vehicle_10ms.pb.h"
#include "common/vehicle_in/vehicle_50ms.pb.h"
#include "niodds/application/application.h"
#include "np/apps/ehy_ego_outputs.pb.h"
#include "np/apps/ehy_evd_outputs.pb.h"
#include "np/apps/ehy_ha_outputs.pb.h"
#include "np/apps/ehy_lpp_outputs.pb.h"
#include "np/apps/ehy_obf_outputs.pb.h"
#include "np/apps/ehy_rme_road_base.pb.h"
#include "np/apps/ehy_rme_road_outputs.pb.h"
#include "np/apps/ehy_target_base.pb.h"
#include "np/apps/ehy_tpp_outputs.pb.h"
#include "np/apps/ehy_tse_outputs.pb.h"
#include "np/apps/ehy_tsi_outputs.pb.h"
#include "np/apps/ehy_tsr_outputs.pb.h"
#include "np/apps/fct_out.pb.h"
#include "np/apps/parking_outputs.pb.h"
#include "common/platform/mcu_proxy/vehicle/vehicle_variant_code.pb.h"

#include "ehy_math/nio_vmath.h"
#include "ehy_obf/object.h"

namespace nio {
namespace ad {
extern ARBSIN* arb_sin;

class ARBInputAdapter {
 private:
  bool fill_vis_obj_input(const std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs,
                          EHYVisionObjects*                                          ehy_vis_obj);
  bool fill_vis_road_input(const std::shared_ptr<nio::ad::messages::RoadDetection> vis_road,
                           EHYVisionRoad*                                          ehy_vis_road);
  bool fill_rdr_input(const std::shared_ptr<nio::ad::messages::RadarSensor> rdr_info, EHYRadarSensor* ehy_rdr_sensor);
  bool fill_side_feature(const std::shared_ptr<nio::ad::messages::ForceSideFeatures> side_feature_info,
                         APSideFeature*                                              aptiv_side_feature);
  bool fill_veh_input(const std::shared_ptr<nio::ad::messages::VEH50ms> vehicle_info_50ms,
                      const std::shared_ptr<nio::ad::messages::VEH10ms> vehicle_info, ARBSIN* arb_sin);
  bool fill_veh_50_input(const std::shared_ptr<nio::ad::messages::VEH50ms> vehicle_info, ARBSIN* arb_sin);
  bool fill_obf_input(const std::shared_ptr<nio::ad::messages::EHYObfOutputs> obf_info,
                      std::vector<feature::ehy::Object>*                      fusion_object_);
  bool fill_arb_vis_obj_input(const std::shared_ptr<nio::ad::messages::ObjectsDetection> vis_obs,
                              std::vector<feature::ehy::Object>*                         vision_object_);
  bool fill_ehy_ego_input(const std::shared_ptr<nio::ad::messages::EHYEgoOutputs> ehy_ego, EHYEgo* ehyego_output);
  bool fill_ehy_evd_input(const std::shared_ptr<nio::ad::messages::EHYEvdOutputs> ehy_evd_info,
                          EHYEvdOutputs*                                          ehyevd_output);
  bool fill_ehy_ha_input(const std::shared_ptr<nio::ad::messages::EHYHaOutputs> ehy_ha_info,
                         EHYHaOutputs*                                          ehyha_output);
  bool fill_ehy_lpp_input(const std::shared_ptr<nio::ad::messages::EHYLppOutputs> ehy_lpp_info,
                          EHYLppOutputs*                                          ehylpp_output);
  bool fill_ehy_rme_input(const std::shared_ptr<nio::ad::messages::EHYRmeOutputs> ehy_rme_info,
                          EHYRmeOutputs*                                          ehyrme_output);
  bool fill_ehy_tpp_input(const std::shared_ptr<nio::ad::messages::EHYTppOutputs> ehy_tpp_info,
                          EHYTppOutputs*                                          ehytpp_output);
  bool fill_ehy_tsi_input(const std::shared_ptr<nio::ad::messages::EHYTsiOutputs> ehy_tsi_info,
                          EHYTsiOutputs*                                          ehytsi_output);
  bool fill_ehy_tse_input(const std::shared_ptr<nio::ad::messages::EHYTseOutputs> ehy_tse_info,
                          EHYTseOutputs*                                          ehytse_output);
  bool fill_ehy_tsr_input(const std::shared_ptr<nio::ad::messages::EHYTsrOutputs> ehy_tsr_info,
                          EHYTsrOutputs*                                          ehytsr_output);
  bool fill_vehstate(ARBVehicle* vehicle_input);

  bool fill_ehy_tsr_input(const std::shared_ptr<nio::ad::messages::VehVariantCode> vehicle_variant_info, VehicleProjectType& vehicle_type);

  /*std::unique_ptr<Node> m_node_;

  std::shared_ptr<Subscriber<nio::ad::messages::ObjectsDetection>> m_sub_vision_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::RadarSensor>> m_sub_radar_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::VEH10ms>> m_sub_vehicle_10_;
  std::shared_ptr<Subscriber<nio::ad::messages::VEH50ms>> m_sub_vehicle_50_;
  std::shared_ptr<Subscriber<nio::ad::messages::RoadDetection>> m_sub_road_detection_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYObfOutputs>> m_sub_fusion_object_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYEgoOutputs>> m_sub_ehy_ego_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYEvdOutputs>> m_sub_ehy_evd_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYHaOutputs>> m_sub_ehy_ha_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYLppOutputs>> m_sub_ehy_lpp_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYRmeOutputs>> m_sub_ehy_rme_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYTppOutputs>> m_sub_ehy_tpp_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYTsiOutputs>> m_sub_ehy_tsi_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYTseOutputs>> m_sub_ehy_tse_;
  std::shared_ptr<Subscriber<nio::ad::messages::EHYTsrOutputs>> m_sub_ehy_tsr_;

  std::vector<std::shared_ptr<nio::ad::messages::RadarSensor>> radar_data_;
  std::vector<std::shared_ptr<nio::ad::messages::ObjectsDetection>> vision_objects_;
  std::vector<std::shared_ptr<nio::ad::messages::VEH10ms>> vehicle_input_10_;
  std::vector<std::shared_ptr<nio::ad::messages::VEH50ms>> vehicle_input_50_;
  std::vector<std::shared_ptr<nio::ad::messages::RoadDetection>> road_detection_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYObfOutputs>> fusion_object_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYEgoOutputs>> ehy_ego_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYEvdOutputs>> ehy_evd_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYHaOutputs>> ehy_ha_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYLppOutputs>> ehy_lpp_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYRmeOutputs>> ehy_rme_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYTppOutputs>> ehy_tpp_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYTsiOutputs>> ehy_tsi_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYTseOutputs>> ehy_tse_;
  std::vector<std::shared_ptr<nio::ad::messages::EHYTsrOutputs>> ehy_tsr_;*/

  void receive_update();

 public:
  ARBInputAdapter();
  ~ARBInputAdapter();

  float coordidirection = -1;  // ISO = -1; VCS = 1;

  bool MainFcn(EHYRadarSensor* ehy_rdr_sensor, APSideFeature* aptiv_side_feature, EHYVisionObjects* ehy_vis_obj,
               EHYVisionRoad* ehy_vis_road, EHYEgo* ehy_ego_input, EHYEvdOutputs* ehy_evd_input,
               EHYHaOutputs* ehy_ha_input, EHYLppOutputs* ehy_lpp_input, EHYRmeOutputs* ehy_rme_input,
               EHYTppOutputs* ehy_tpp_input, EHYTsiOutputs* ehy_tsi_input, EHYTseOutputs* ehy_tse_input,
               EHYTsrOutputs* ehy_tsr_input, std::vector<feature::ehy::Object>* fused_obj,
               std::vector<feature::ehy::Object>* vis_obj, ARBSIN* arb_sin);
};

}  // namespace ad
}  // namespace nio

#endif
