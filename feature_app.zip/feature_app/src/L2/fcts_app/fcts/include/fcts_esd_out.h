#pragma once

#include "common/esd/esd_np_feature.pb.h"
#include "aeb_state.h"
#include "fcw_state.h"
#include "aeb_strategy_type.h"
#include "np/apps/fcts_out.pb.h"

using nio::ad::messages::esd_np_feature;
using nio::ad::messages::FctsOut;

namespace nio {
namespace ad {

extern void fcts_esd_init_output(FctsOut& fcts_esd);
extern void fcts_esd_fail_output(FctsOut& fcts_esd);
extern void fcts_esd_fill_output(FctsOut& fcts_esd);

}  // namespace ad
}  // namespace nio