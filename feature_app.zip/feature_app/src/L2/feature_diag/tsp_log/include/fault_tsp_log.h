// Copyright (c) 2022, NIO Inc. All rights reserved.
//
// Any use, reproduction, distribution, and/or transfer of this file is strictly
// prohibited without the express written permission of the current copyright
// owner.
//
// Any licensed derivative work must retain this notice.
//
// fault_tsp_log.h :
//
#pragma once

#include <string>

class DiagTsp_log {
 public:
  explicit DiagTsp_log();
  // void        SetAppName(const std::string& app_name) {appName = app_name;};
  // std::string GetAppName() {return appName;};

  std::string GetFaultJsonString(const std::string& fault_type, const std::string& fault_name, const uint8_t fault_byte,
                                 const uint8_t fault_bit, bool fault_state);
  void        FaultTspLogInit(const std::string name = "_fct_app");
  void        FaultTspLog(const std::string& fault_type, const std::string& fault_name, const uint8_t fault_byte,
                          const uint8_t fault_bit, bool fault_state);

 private:
  std::string appName;
};
