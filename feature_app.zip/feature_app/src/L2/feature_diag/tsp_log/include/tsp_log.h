// Copyright (c) 2022, NIO Inc. All rights reserved.
//
// Any use, reproduction, distribution, and/or transfer of this file is strictly
// prohibited without the express written permission of the current copyright
// owner.
//
// Any licensed derivative work must retain this notice.
//
// tsp_log.h :
//
#pragma once

#include <stdarg.h>

#include <mutex>
#include <thread>

#include "dcs_function_interface.h"  // From pd_sdk

namespace tsp_log {

// The log type enum should better be ordered by priority
// If we add a new type, please add the new config in tsp_log.cpp

// clang-format off
enum class LogType {
  kDefault      = 0, // Internal usage. For some temporary case like using TspLog utility
  kTextinfo     = 1, // A Textinfo update. comment: [text info meaning] value: [text info value]
  kFault        = 2, // A fault happended. comment: [fault json info] value: [duration]
  kCoredump     = 3, // A coredump happended. comment: [process name] value: [coredump timestamp]
  kSystem       = 4, // General system infomation
  kFeatureEvent = 5, // Simple event Trace log
  kHdmap        = 6, // Had map related log
  function_fault = 7,//fcts fault
  kMax          = 8, // type max
};
// clang-format on

class TspLog {
 public:
  virtual ~TspLog();

  /**
   * @Brief Send a tsp message, like simple log
   *
   */
  int Init(const std::string name);

  void Log(const LogType& type, int64_t value, const char* format_str, ...)
    __attribute__((__format__(__printf__, 4, 5)));

  void Log(const LogType& type, int64_t value, uint64_t timestamp, const char* format_str, ...)
    __attribute__((__format__(__printf__, 5, 6)));

  /**
   * @brief Set the Publish Interval (default = 5)
   *
   * @param interval_s
   */
  void SetPublishInterval(int interval_s);

  /**
   * @brief Test only
   *
   */
  static void PrintConfig();

 private:
  /**
   * @brief Clear tsp log list Periodic
   *
   */
  void PublishHandler();

  /**
   * @brief Do publish
   *
   */
  void DoPublish();

  /**
   * @brief Flush if type changed
   *
   */
  void FlushIfTypeChanged(const LogType& type);

  std::thread publish_thread_;
  std::mutex  log_buffer_mutex_;
  std::string vehicle_uuid_;
  std::string vehicle_id_;
  int         publish_interval_;
  bool        is_termitate_;

  DCS_DECLARE_SINGLETON(TspLog)
};

}  // namespace tsp_log
