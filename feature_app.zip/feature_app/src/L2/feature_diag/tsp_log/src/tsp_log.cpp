// Copyright (c) 2022, NIO Inc. All rights reserved.
//
// Any use, reproduction, distribution, and/or transfer of this file is strictly
// prohibited without the express written permission of the current copyright
// owner.
//
// Any licensed derivative work must retain this notice.
//
// tsp_log.cpp :
//
#include "tsp_log.h"

#include <uuid/uuid.h>

#include <chrono>
#include <list>
#include <map>
#include <memory>
#include <string>
#include <thread>
#include "niodds/application/application.h"

#include "common/dlb/dlb_message_upload.pb.h"
#include "dcs_param_interface.h"
#include "niodds/application/application.h"
#include "tsp_log.pb.h"

namespace tsp_log {

// namespace mazu_msg = nio::ad::messages;

struct Config {
  const char*        key;
  int                count_max;
  mazu_msg::LogLevel level;
};

static constexpr int     kLogBufferSizeMax    = 100;
static constexpr int     kPublishLogIntervalS = 5;
static constexpr int     kFormatStringMax     = 512;
static const std::string kNodeNamePrefix      = "tsp_log_";
// static const std::string kAppName             = "_fcts_app"; //_fct_app

static mazu_msg::TspLogList*                                                    tsp_log_list;
static std::unique_ptr<nio::ad::Node>                                           node;
static std::shared_ptr<nio::ad::Publisher<nio::ad::messages::DLBMessageUpload>> publisher;

static const std::string kPublishTopic = "common/dlb/dlb_message_upload";

// clang-format off
static const std::map<LogType, Config> config_map = {
  {LogType::kDefault,      {"Default",      1000, mazu_msg::LOG_LEVEL_DEBUG}},
  {LogType::kTextinfo,     {"Textinfo",     1000, mazu_msg::LOG_LEVEL_INFO}},
  {LogType::kFault,        {"fault_mgr",   10000, mazu_msg::LOG_LEVEL_WARNING}},
  {LogType::kCoredump,     {"coredump_msg", 1000, mazu_msg::LOG_LEVEL_CRITICAL}},
  {LogType::kSystem,       {"System",       1000, mazu_msg::LOG_LEVEL_INFO}},
  {LogType::kFeatureEvent, {"FeatureEvent", 1000, mazu_msg::LOG_LEVEL_INFO}},
  {LogType::kHdmap,        {"Hdmap",        1000, mazu_msg::LOG_LEVEL_INFO}},
  {LogType::function_fault,        {"function_fault",        1000, mazu_msg::LOG_LEVEL_WARNING}},
};
// clang-format on

static void        PublishByDds(const mazu_msg::TspLogList& log_list);
static std::string GenerateUuid();
int                TspLog::Init(const std::string name) {
  if (dcs::DcsParamInterface::Instance()->GetVehicleId().empty()) {
    vehicle_id_ = "Unknown";
    // INFO_LOG << "Get vid failed";
  } else {
    vehicle_id_ = dcs::DcsParamInterface::Instance()->GetVehicleId();
    // INFO_LOG << "Has vid, no error";
  } 

  std::string *node_name = new std::string(kNodeNamePrefix);
  node_name->append(std::to_string(static_cast<uint8_t>(dcs::DcsPdParamInterface::Instance()->GetSocIndex())));
  node_name->append(name);
  node = nio::ad::Node::CreateNode(*node_name);
  if (node == nullptr) {
    INFO_LOG << "Create node failed, should never happended";
    return -1;
  }
  // nio::ad::QoS set_qos;
  // set_qos.SetDurability(nio::ad::QoS::Durability::TRANSIENT_LOCAL);
  // set_qos.SetReliability(nio::ad::QoS::Reliability::RELIABLE);
  // publisher = node->CreatePublisher<nio::ad::messages::DLBMessageUpload>(kPublishTopic, set_qos);
  publisher = node->CreatePublisher<nio::ad::messages::DLBMessageUpload>(kPublishTopic);
  if (publisher == nullptr) {
    INFO_LOG << "Create publisher failed, should never happended";
    return -1;
  }
  tsp_log_list = new (std::nothrow) mazu_msg::TspLogList();
  if (tsp_log_list == nullptr) {
    INFO_LOG << "New tsp log failed, should never happended";
    return -1;
  }
  tsp_log_list->set_adc_version(dcs::DcsPdParamInterface::Instance()->GetSocSwVersion().commit_hash);
  tsp_log_list->set_vehicle_id(vehicle_id_);
  publish_thread_ = std::thread(&TspLog::PublishHandler, this);
  // publish_thread_.detach();
  return 0;
}
TspLog::TspLog() : publish_interval_(kPublishLogIntervalS), is_termitate_(false) {}
// TODO: SINGLETON will not run destruct, which will be lost messages when
// shutdown
TspLog::~TspLog() {
  is_termitate_ = true;
  if (publish_thread_.joinable()) {
    publish_thread_.join();
  }
  DoPublish();
  if (tsp_log_list != nullptr) {
    delete tsp_log_list;
  }
}

bool IsCountOverflow(const LogType& type, int max_count) {
  static std::map<LogType, int> count_map;
  auto                          itor = count_map.find(type);
  if (itor == count_map.end()) {
    count_map[type] = 1;
    return false;
  }
  if (itor->second < max_count) {
    itor->second += 1;
    return false;
  } else if (itor->second == max_count) {
    INFO_LOG << "The {} count out of one cycle range {}" << static_cast<int>(type) << static_cast<int>(max_count);
    itor->second += 1;
    return true;
  } else {
    return true;
  }
}

void TspLog::DoPublish() {
  if (tsp_log_list->log_size() == 0) {
    return;
  }
  PublishByDds(*tsp_log_list);
  tsp_log_list->clear_log();
  return;
}

static std::string GenerateUuid() {
  uuid_t    uu;
  const int kUuidMaxLength = 64;
  char      uu_out[kUuidMaxLength];
  uuid_generate(uu);
  uuid_unparse(uu, uu_out);
  return uu_out;
}

static void PublishByDds(const mazu_msg::TspLogList& log_list) {
  auto message = std::make_shared<nio::ad::messages::DLBMessageUpload>();
  INFO_LOG << "key = {}" << log_list.log(0).key();
  message->set_type(log_list.log(0).key());
  message->set_payload(log_list.SerializeAsString());
  message->set_message_type(nio::ad::messages::DATA_REPORT);
  message->set_uuid(GenerateUuid());
  if (publisher->Publish(message) == false) {
    INFO_LOG << "Publish failed";
  }
}

void TspLog::FlushIfTypeChanged(const LogType& type) {
  static LogType log_type_pre = LogType::kDefault;
  if (log_type_pre != type) {
    log_type_pre = type;
    DoPublish();
  }
}

void TspLog::Log(const LogType& type, int64_t value, const char* format_str, ...) {
  if (tsp_log_list == nullptr) {
    return;
  }

  auto config_itor = config_map.find(type);
  if (config_itor == config_map.end()) {
    INFO_LOG << "Not support type {}" << static_cast<int>(type);
    return;
  }

  std::lock_guard<std::mutex> lock(log_buffer_mutex_);
  FlushIfTypeChanged(type);

  if (IsCountOverflow(type, config_itor->second.count_max)) {
    return;
  }
  auto tsp_log = tsp_log_list->add_log();
  if (format_str != NULL) {
    va_list args;
    va_start(args, format_str);
    char log_str[kFormatStringMax];
    auto size = vsnprintf(log_str, kFormatStringMax, format_str, args);
    if (size >= kFormatStringMax) {
      INFO_LOG << "Format out of range";
    }
    va_end(args);
    tsp_log->set_comment(log_str);
  }
  tsp_log->set_value(value);
  tsp_log->set_key(config_itor->second.key);
  tsp_log->set_level(config_itor->second.level);
  tsp_log->set_timestamp(dcs::DcsTimeInterface::Instance()->TimestampGetEpochUs());

  if (tsp_log_list->log_size() >= kLogBufferSizeMax) {
    DoPublish();
  }
}

void TspLog::PublishHandler() {
  while (is_termitate_ == false) {
    std::this_thread::sleep_for(std::chrono::seconds(publish_interval_));
    std::lock_guard<std::mutex> lock(log_buffer_mutex_);
    DoPublish();
  }
}

void TspLog::SetPublishInterval(int interval_s) {
  publish_interval_ = interval_s;
}

void TspLog::PrintConfig() {
  printf("type  key              max  level\n");
  for (auto& itor : config_map) {
    printf("%4d: %-15s %5d %d\n", static_cast<int>(itor.first), itor.second.key, itor.second.count_max,
           itor.second.level);
  }
}

void TspLog::Log(const LogType& type, int64_t value, uint64_t timestamp, const char* format_str, ...) {
  if (tsp_log_list == nullptr) {
    return;
  }

  auto config_itor = config_map.find(type);
  if (config_itor == config_map.end()) {
    INFO_LOG << "Not support type {}" << static_cast<int>(type);
    return;
  }

  std::lock_guard<std::mutex> lock(log_buffer_mutex_);
  FlushIfTypeChanged(type);

  if (IsCountOverflow(type, config_itor->second.count_max)) {
    return;
  }
  auto tsp_log = tsp_log_list->add_log();
  if (format_str != NULL) {
    va_list args;
    va_start(args, format_str);
    char log_str[kFormatStringMax];
    auto size = vsnprintf(log_str, kFormatStringMax, format_str, args);
    if (size >= kFormatStringMax) {
      INFO_LOG << "Format out of range";
    }
    va_end(args);
    tsp_log->set_comment(log_str);
  }
  tsp_log->set_value(value);
  tsp_log->set_key(config_itor->second.key);
  tsp_log->set_level(config_itor->second.level);
  tsp_log->set_timestamp(timestamp);

  if (tsp_log_list->log_size() >= kLogBufferSizeMax) {
    DoPublish();
  }
}

}  // namespace tsp_log
