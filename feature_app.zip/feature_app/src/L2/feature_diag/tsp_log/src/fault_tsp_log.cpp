// Copyright (c) 2022, NIO Inc. All rights reserved.
//
// Any use, reproduction, distribution, and/or transfer of this file is strictly
// prohibited without the express written permission of the current copyright
// owner.
//
// Any licensed derivative work must retain this notice.
//
// fault_tsp_log.cpp :
//
#include "fault_tsp_log.h"

#include <uuid/uuid.h>

// #include <format>
#include <map>

#include "tsp_log.h"

#include "niodds/application/application.h"

DiagTsp_log::DiagTsp_log() {}

static std::string GenerateUuid();

static std::string GenerateUuid() {
  uuid_t    uu;
  const int kUuidMaxLength         = 64;
  char      uu_out[kUuidMaxLength] = {};
  uuid_generate(uu);
  uuid_unparse(uu, uu_out);
  return uu_out;
}

std::string DiagTsp_log::GetFaultJsonString(const std::string& fault_type, const std::string& fault_name,
                                            uint8_t fault_byte, uint8_t fault_bit, bool fault_state) {

  static std::string fault_uuid;
  static std::string fault_flag;

  char buf[1024];

  if (fault_state) {
    fault_flag = "occur";
    fault_uuid = GenerateUuid();
  } else {
    fault_flag = "recover";
  }

  // return fmt::format("{{\"Type\":\"{}\",\"status\":\"{}\",\"uuid\":\"{}\",\"FIM_NUM\":\"{}.{}\",\"reason\":\"{}\"}}",
  //                    fault_type, fault_status, fault_uuid, fault_byte, fault_bit, fault_reason);

  sprintf(buf,
          "{\"type\":\"%s\",\"internal_fault_name\":\"%s\",\"fim_byte_bit\":\"%d.%d\",\"flag\":\"%s\",\"uuid\":\"%s\"}",
          fault_type.c_str(), fault_name.c_str(), fault_byte, fault_bit, fault_flag.c_str(), fault_uuid.c_str());
  INFO_LOG << "tsp_log_buf" << buf;
  return buf;
}

// Construct instances early in the program to prevent the constructor from affecting program timing.
void DiagTsp_log::FaultTspLogInit(const std::string name) {
  tsp_log::TspLog::Instance()->Init(name);
}

void DiagTsp_log::FaultTspLog(const std::string& fault_type, const std::string& fault_name, const uint8_t fault_byte,
                              const uint8_t fault_bit, bool fault_state) {
  tsp_log::TspLog::Instance()->Log(
    tsp_log::LogType::function_fault, 0,
    GetFaultJsonString(fault_type, fault_name, fault_byte, fault_bit, fault_state).c_str());
}
