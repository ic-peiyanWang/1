#pragma once

#include <stdint.h>

#include "common/perception/lidar_failsafe.pb.h"
#include "common/perception/vision_failsafe.pb.h"

namespace nio {
namespace ad {

typedef struct {
  uint16_t none   = 0;
  uint16_t low    = 0;
  uint16_t middle = 0;
  uint16_t high   = 0;
} T_FS;

class DiagFailsafe {
 public:
  explicit DiagFailsafe();

  void vision_FailsafeEncoder(const nio::ad::messages::FailSafe& failsafe_info, T_FS& fim_failsafe);
  void lidar_FailsafeEncoder(const nio::ad::messages::Lidar_FailSafe& failsafe_info, T_FS& fim_failsafe);

 private:
};
}  // namespace ad
}  // namespace nio
