#pragma once

#include <math.h>
#include <stdint.h>
#include <string>
#include "niodds/application/application.h"

namespace nio {
namespace ad {
// namespace diaglib
//     {
enum class APP_state_e : uint8_t { Init = 0, Suspend = 1, PartialActive = 2, FullActive = 3, Failure = 4, exit = 5 };

enum class DiagStatus_e {
  NoFault  = 0,
  NoInit   = 1,
  LossComm = 2,
};

struct TopicStatus {
  uint64_t     publish_ptp_ts_lf;
  bool         InitDone  = false;
  DiagStatus_e DiaStatus = DiagStatus_e::NoInit; /*result of test circle*/
  int16_t      FltCntr;                          /*fault detection counter*/
};

struct FltThreshold {
  int16_t PassedThreshold;
  int16_t FailedThreshold;
  int8_t  Jumpupstep;
  int8_t  Jumpdownstep;
}; /*fault detection counter configuration*/

template <class MessageT> uint8_t update_topic_status(MessageT msg_vet, TopicStatus& tp_st, FltThreshold tp_cfg) {

  if (true == tp_st.InitDone && msg_vet.size() > 0) {
    if (msg_vet.back()->publish_ptp_ts() < tp_st.publish_ptp_ts_lf + 10000) {
      tp_st.FltCntr = tp_st.FltCntr + tp_cfg.Jumpupstep;
      tp_st.FltCntr = fmin(tp_st.FltCntr, tp_cfg.FailedThreshold);
    } else {
      tp_st.FltCntr = tp_st.FltCntr - tp_cfg.Jumpdownstep;
      tp_st.FltCntr = fmax(tp_st.FltCntr, tp_cfg.PassedThreshold);
    }

    if (tp_st.FltCntr <= tp_cfg.PassedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else if (tp_st.FltCntr >= tp_cfg.FailedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::LossComm;
      WARN_LOG << "topic :" << msg_vet.back()->GetTypeName()               //
               << " current ptp ts: " << msg_vet.back()->publish_ptp_ts()  //
               << " last ptp ts" << tp_st.publish_ptp_ts_lf                //
               << " diff ptp ts" << msg_vet.back()->publish_ptp_ts() - tp_st.publish_ptp_ts_lf;
    }

    tp_st.publish_ptp_ts_lf = msg_vet.back()->publish_ptp_ts();

  } else {
    tp_st.InitDone = msg_vet.size() > 0 ? true : false;
    if (true == tp_st.InitDone) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else {
      tp_st.DiaStatus = DiagStatus_e::NoInit;
    }
  }

  return true;
}

template <class MessageT> uint8_t update_topic_status_nop_sub(MessageT msg_vet, TopicStatus& tp_st, FltThreshold tp_cfg) {

  if (true == tp_st.InitDone && msg_vet.size() > 0) {
    if (msg_vet.back()->time_meas() < tp_st.publish_ptp_ts_lf + 10000) {
      tp_st.FltCntr = tp_st.FltCntr + tp_cfg.Jumpupstep;
      tp_st.FltCntr = fmin(tp_st.FltCntr, tp_cfg.FailedThreshold);
    } else {
      tp_st.FltCntr = tp_st.FltCntr - tp_cfg.Jumpdownstep;
      tp_st.FltCntr = fmax(tp_st.FltCntr, tp_cfg.PassedThreshold);
    }

    if (tp_st.FltCntr <= tp_cfg.PassedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else if (tp_st.FltCntr >= tp_cfg.FailedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::LossComm;
      WARN_LOG << "topic :" << msg_vet.back()->GetTypeName()               //
               << " current ptp ts: " << msg_vet.back()->time_meas()  //
               << " last ptp ts" << tp_st.publish_ptp_ts_lf                //
               << " diff ptp ts" << msg_vet.back()->time_meas() - tp_st.publish_ptp_ts_lf;
    }

    tp_st.publish_ptp_ts_lf = msg_vet.back()->time_meas();

  } else {
    tp_st.InitDone = msg_vet.size() > 0 ? true : false;
    if (true == tp_st.InitDone) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else {
      tp_st.DiaStatus = DiagStatus_e::NoInit;
    }
  }

  return true;
}

template <class MessageT> uint8_t update_topic_status_nop_veh10(MessageT msg_vet, TopicStatus& tp_st, FltThreshold tp_cfg) {

  if (true == tp_st.InitDone && msg_vet.size() > 0) {
    if (msg_vet.back()->veh10ms_time_pub() < tp_st.publish_ptp_ts_lf + 10000) {
      tp_st.FltCntr = tp_st.FltCntr + tp_cfg.Jumpupstep;
      tp_st.FltCntr = fmin(tp_st.FltCntr, tp_cfg.FailedThreshold);
    } else {
      tp_st.FltCntr = tp_st.FltCntr - tp_cfg.Jumpdownstep;
      tp_st.FltCntr = fmax(tp_st.FltCntr, tp_cfg.PassedThreshold);
    }

    if (tp_st.FltCntr <= tp_cfg.PassedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else if (tp_st.FltCntr >= tp_cfg.FailedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::LossComm;
      WARN_LOG << "topic : car_info_veh10ms"//
               << " current ptp ts: " << msg_vet.back()->veh10ms_time_pub()  //
               << " last ptp ts" << tp_st.publish_ptp_ts_lf                //
               << " diff ptp ts" << msg_vet.back()->veh10ms_time_pub() - tp_st.publish_ptp_ts_lf;
    }

    tp_st.publish_ptp_ts_lf = msg_vet.back()->veh10ms_time_pub();

  } else {
    tp_st.InitDone = (msg_vet.size() > 0 && msg_vet.back()->veh10ms_time_pub() != 0)? true : false;
    if (true == tp_st.InitDone) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else {
      tp_st.DiaStatus = DiagStatus_e::NoInit;
    }
  }

  return true;
}

template <class MessageT> uint8_t update_topic_status_nop_veh50(MessageT msg_vet, TopicStatus& tp_st, FltThreshold tp_cfg) {

  if (true == tp_st.InitDone && msg_vet.size() > 0) {
    if (msg_vet.back()->veh50ms_time_pub() < tp_st.publish_ptp_ts_lf + 10000) {
      tp_st.FltCntr = tp_st.FltCntr + tp_cfg.Jumpupstep;
      tp_st.FltCntr = fmin(tp_st.FltCntr, tp_cfg.FailedThreshold);
    } else {
      tp_st.FltCntr = tp_st.FltCntr - tp_cfg.Jumpdownstep;
      tp_st.FltCntr = fmax(tp_st.FltCntr, tp_cfg.PassedThreshold);
    }

    if (tp_st.FltCntr <= tp_cfg.PassedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else if (tp_st.FltCntr >= tp_cfg.FailedThreshold) {
      tp_st.DiaStatus = DiagStatus_e::LossComm;
      WARN_LOG << "topic : car_info_veh50ms"//
               << " current ptp ts: " << msg_vet.back()->veh50ms_time_pub()  //
               << " last ptp ts" << tp_st.publish_ptp_ts_lf                //
               << " diff ptp ts" << msg_vet.back()->veh50ms_time_pub() - tp_st.publish_ptp_ts_lf;
    }

    tp_st.publish_ptp_ts_lf = msg_vet.back()->veh50ms_time_pub();

  } else {
    tp_st.InitDone = (msg_vet.size() > 0 && msg_vet.back()->veh50ms_time_pub() !=0) ? true : false;
    if (true == tp_st.InitDone) {
      tp_st.DiaStatus = DiagStatus_e::NoFault;
    } else {
      tp_st.DiaStatus = DiagStatus_e::NoInit;
    }
  }

  return true;
}

// extern const uint64_t P_TsLossCommThres;
// extern DiagStatus_e update_topic_status(MessageT msg_vet,TopicStatus& tp_st, FltThreshold & tp_cfg);
extern uint32_t    Diag_InitOutput(TopicStatus tp_st[], uint8_t tp_max);
extern uint32_t    Diag_FailedOutput(TopicStatus tp_st[], uint8_t tp_max);
extern APP_state_e APP_StateManage(uint32_t TopicNoInit, uint32_t InitMask, uint32_t TopicLoss, uint32_t LossMask);
// }
}  // namespace ad
}  // namespace nio
