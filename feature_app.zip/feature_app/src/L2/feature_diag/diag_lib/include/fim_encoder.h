#pragma once

#include <stdint.h>

#include "common/diagnostic/fim/fim_cameras.pb.h"
#include "common/diagnostic/fim/fim_can.pb.h"
#include "common/diagnostic/fim/fim_can_feature.pb.h"
#include "common/diagnostic/fim/fim_lidar.pb.h"
#include "common/diagnostic/fim/fim_mcu_system.pb.h"
#include "common/diagnostic/fim/fim_mcuwithsoc_can.pb.h"
#include "common/diagnostic/fim/fim_perception.pb.h"
#include "common/diagnostic/fim/fim_power_rail.pb.h"
#include "common/diagnostic/fim/fim_software.pb.h"

namespace nio {
namespace ad {
enum class FimFault_e {
  NoFault     = 0,
  RevFault    = 1,
  NonRevFault = 2,
};

#define DIAG_FIM_MAX_MASK_NUM 160U

extern uint8_t kGlobFimMskByte[DIAG_FIM_MAX_MASK_NUM];

class DiagFim {
 public:
  explicit DiagFim();

  uint8_t fim_encoder_byte[DIAG_FIM_MAX_MASK_NUM] = { 0 };

  void FimEncoder(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&     fim_camera_info,
                  const std::shared_ptr<nio::ad::messages::FimCanInfo>&        fim_can_info,
                  const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&   fim_sw_info,
                  const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                  const std::shared_ptr<nio::ad::messages::PowerFimInfo>&      fim_power_info,
                  const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&  fim_mcu_sys_info,
                  const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>& fim_mcu_soc_info,
                  const std::shared_ptr<nio::ad::messages::LidarFimInfo>&      fim_lidar_info,
                  const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>& fim_perception_info);

  inline uint8_t pack_fim_to_byte(const uint8_t& mask, const bool& bit0 = false, const bool& bit1 = false,
                                  const bool& bit2 = false, const bool& bit3 = false, const bool& bit4 = false,
                                  const bool& bit5 = false, const bool& bit6 = false, const bool& bit7 = false) {
    uint8_t fim_byte = 0U;
    fim_byte = (static_cast<uint8_t>(bit0)) + (static_cast<uint8_t>(bit1) << 1) + (static_cast<uint8_t>(bit2) << 2)
               + (static_cast<uint8_t>(bit3) << 3) + (static_cast<uint8_t>(bit4) << 4)
               + (static_cast<uint8_t>(bit5) << 5) + (static_cast<uint8_t>(bit6) << 6)
               + (static_cast<uint8_t>(bit7) << 7);
    return fim_byte & ~mask;
  }

  inline uint8_t get_relative_fim_byte(const uint8_t& mask, const uint8_t& byte_num) {
    return fim_encoder_byte[byte_num] & ~mask;
  }

  inline bool get_valid_data(const bool& has_valid_data, const bool& sig, bool& sig_ll) {
    if (true == has_valid_data) {
      sig_ll = sig;
      return sig;
    } else {
      return sig_ll;
    }
  }

 private:
  bool fim_mcu1tos1_ethcan_msgerror_ll = false;
  bool fim_mcu2tos1_ethcan_msgerror_ll = false;
  bool fim_s1tomcu1_ethcan_msgerror_ll = false;
  bool fim_s1tomcu2_ethcan_msgerror_ll = false;
  bool fim_mcu1tos1_mrr_msgerror_ll    = false;
  bool fim_mcu2tos1_mrr_msgerror_ll    = false;
};
}  // namespace ad
}  // namespace nio
