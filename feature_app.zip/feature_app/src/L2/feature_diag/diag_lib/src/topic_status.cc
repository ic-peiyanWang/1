#include "topic_status.h"

namespace nio
{
    namespace ad
    {
        // namespace diaglib
        //     {
            uint32_t Diag_InitOutput(TopicStatus tp_st[], uint8_t tp_max)
            {
                uint32_t TopicNoInit = 0;
                for(uint8_t  i = 0; i < tp_max;i++)
                {
                    if(tp_st[i].DiaStatus == DiagStatus_e::NoInit)
                    {
                        TopicNoInit =  TopicNoInit | (1<<i);
                    }
                    else
                    {
                        TopicNoInit =  TopicNoInit &(~(1<<i));
                    }
                }
                return TopicNoInit;
            }

            uint32_t Diag_FailedOutput(TopicStatus tp_st[], uint8_t tp_max)
            {
                uint32_t TopicLoss= 0;
                for(uint8_t  i = 0; i < tp_max;i++)
                {
                    if(tp_st[i].DiaStatus == DiagStatus_e::LossComm)
                    {
                        TopicLoss =  TopicLoss | (1<<i);
                    }
                    else
                    {
                        TopicLoss =  TopicLoss &(~(1<<i));
                    }
                }
                return TopicLoss;
            }

            APP_state_e APP_StateManage(uint32_t TopicNoInit, uint32_t InitMask, uint32_t TopicLoss,uint32_t LossMask)
            {
                APP_state_e Appstate_tmp;
                if((TopicNoInit & InitMask) != 0)
                {
                    Appstate_tmp = APP_state_e::Suspend;
                }
                else if(((TopicLoss |TopicNoInit)& LossMask )!= 0)
                {
                    if(((TopicLoss |TopicNoInit) & LossMask) == LossMask)
                    {
                        Appstate_tmp = APP_state_e::Failure;
                    }
                    else
                    {
                        Appstate_tmp = APP_state_e::PartialActive;
                    }
                }
                else
                {
                    Appstate_tmp = APP_state_e::FullActive;
                }
                return Appstate_tmp;
            }
        // } 
    }
}
