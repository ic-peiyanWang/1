#include <iostream>
#include "fim_encoder.h"

namespace nio {
namespace ad {
uint8_t kGlobFimMskByte[DIAG_FIM_MAX_MASK_NUM] = { 0 };

DiagFim::DiagFim() {}

void DiagFim::FimEncoder(const std::shared_ptr<nio::ad::messages::CameraFimInfo>&     fim_camera_info,
                         const std::shared_ptr<nio::ad::messages::FimCanInfo>&        fim_can_info,
                         const std::shared_ptr<nio::ad::messages::FimSoftwareInfo>&   fim_sw_info,
                         const std::shared_ptr<nio::ad::messages::CanFeatureFimInfo>& fim_can_fea_info,
                         const std::shared_ptr<nio::ad::messages::PowerFimInfo>&      fim_power_info,
                         const std::shared_ptr<nio::ad::messages::McuSystemFimInfo>&  fim_mcu_sys_info,
                         const std::shared_ptr<nio::ad::messages::MCUWithSOCFimInfo>& fim_mcu_soc_info,
                         const std::shared_ptr<nio::ad::messages::LidarFimInfo>&      fim_lidar_info,
                         const std::shared_ptr<nio::ad::messages::PerceptionFimInfo>& fim_perception_info) {

  fim_encoder_byte[1] = pack_fim_to_byte(
    kGlobFimMskByte[1], fim_can_fea_info->acm_feature_fim_info().fim_chs1_acm_yawratevalsts_invalid(),
    fim_can_fea_info->acm_feature_fim_info().fim_chs1_acm_latavalsts_invalid(),
    fim_can_fea_info->acm_feature_fim_info().fim_chs1_acm_lgtavalsts_invalid(),
    fim_can_fea_info->acm_feature_fim_info().fim_chs1_acm_axayyrscalsts_invalid(),
    fim_can_info->acm_fim_info().fim_chs1_acm_01_msgerror(), fim_can_info->acm_fim_info().fim_chs1_acm_02_msgerror(),
    fim_can_info->acm_fim_info().fim_chs1_acm_03_msgerror(), fim_can_info->acm_fim_info().fim_chs1_acm_can_error());

  fim_encoder_byte[2] = pack_fim_to_byte(
    kGlobFimMskByte[2], fim_can_info->apa_fim_info().fim_adas_apa_01_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_02_msgerror(), fim_can_info->apa_fim_info().fim_adas_apa_03_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_04_msgerror(), fim_can_info->apa_fim_info().fim_adas_apa_05_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_01_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_02_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_03_msgerror());

  fim_encoder_byte[3] = pack_fim_to_byte(
    kGlobFimMskByte[3], fim_can_info->apa_fim_info().fim_adas_apa_adc_04_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_05_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_06_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_07_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_08_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_09_msgerror(),
    fim_can_info->apa_fim_info().fim_adas_apa_adc_10_msgerror(), fim_can_info->apa_fim_info().fim_adas_apa_can_error());

  fim_encoder_byte[4] =
    pack_fim_to_byte(kGlobFimMskByte[4], fim_can_info->apa_fim_info().fim_adas_apa_slot01_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot01obj1_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot01obj2_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot02_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot02obj1_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot02obj2_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot03_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot03obj1_msgerror());

  fim_encoder_byte[5] =
    pack_fim_to_byte(kGlobFimMskByte[5], fim_can_info->apa_fim_info().fim_adas_apa_slot03obj2_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot04_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot04obj1_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot04obj2_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot05_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot05obj1_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot05obj2_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot06_msgerror());

  fim_encoder_byte[6] =
    pack_fim_to_byte(kGlobFimMskByte[6], fim_can_info->apa_fim_info().fim_adas_apa_slot06obj1_msgerror(),
                     fim_can_info->apa_fim_info().fim_adas_apa_slot06obj2_msgerror(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_upasyssts_f_invalid(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_upasyssts_r_invalid(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_frntsnsrfltst_invalid(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_resnsrfltst_invalid(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_upasysdrv_service(),
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_upasysdi_systemdisabled());

  fim_encoder_byte[7] =
    pack_fim_to_byte(kGlobFimMskByte[7], fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_apasts_failure(),
                     false,  //  fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_upasyssts_sna() obsolete
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_mapobjsts_invalid(),//NT2ADR-605
                     fim_can_fea_info->apa_feature_fim_info().fim_adas_apa_sdwsts_invalid());

  fim_encoder_byte[8] = pack_fim_to_byte(kGlobFimMskByte[8], fim_can_info->asdm_fim_info().fim_chs1_asdm_can_error(),
                                         fim_can_info->asdm_fim_info().fim_chs1_asdm_msgerror());

  fim_encoder_byte[9] =
    pack_fim_to_byte(kGlobFimMskByte[9], fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_hibeamsts_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_lobeamsts_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_frntwiprsts_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_leturnindcrlists_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_riturnindcrlists_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_seatoccpfrntlests_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_hoodajarsts_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_doorajarsts_invalid());

  fim_encoder_byte[10] =
    pack_fim_to_byte(kGlobFimMskByte[10], fim_can_info->bcm_fim_info().fim_chs1_bcm_can_error(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_frontfoglight_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_bcm_rearfoglight_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_trajarsts_invalid(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_seatoccpfrntlefail_failure(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_lgterrturnindcnfrntle_outage(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_lgterrturnindcnfrntri_outage(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_releturnindcn_outage());

  fim_encoder_byte[11] =
    pack_fim_to_byte(kGlobFimMskByte[11], fim_can_fea_info->bcm_feature_fim_info().fim_chs1_bcm_reriturnindcn_outage(),
                     fim_can_fea_info->bcm_feature_fim_info().fim_adas_wsheaterror_bcm());

  fim_encoder_byte[12] =
    pack_fim_to_byte(kGlobFimMskByte[12],
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_whlspdmovgdir_invalid(),  // 12.0
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_whlspdsts_invalid(),      // 12.1
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_01_msgerror(),                        // 12.2
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_02_msgerror(),                        // 12.3
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_03_msgerror(),                        // 12.4
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_04_msgerror(),                        // 12.5
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_07_msgerror(),                        // 12.6
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_08_msgerror()                         // 12.7
    );

  fim_encoder_byte[13] =
    pack_fim_to_byte(kGlobFimMskByte[13],
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_09_msgerror(),                       // 13.0
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_16_msgerror(),                       // 13.1
                     fim_can_info->bcu_fim_info().fim_chs1_bcu_can_error(),                         // 13.2
                     fim_can_info->bcu_fim_info().fim_chs2_bcu_16_msgerror(),                       // 13.3
                     fim_can_info->bcu_fim_info().fim_chs2_bcu_can_error(),                         // 13.4
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_whlplscntr_invalid(),    // 13.5
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_vehspdsts_invalid(),     // 13.6
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_brkpressvalid_invalid()  // 13.7
    );

  fim_encoder_byte[14] =
    pack_fim_to_byte(kGlobFimMskByte[14],
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_brkpedlsts_invalid(),  // 14.0
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_vehmovgdir_invalid(),  // 14.1
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_autobrkgavl_invalid(),     // 14.2
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_awbavl_invalid(),          // 14.3
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_vdctcsfaillampreq()        // 14.4
    );

  fim_encoder_byte[15] = pack_fim_to_byte(
    kGlobFimMskByte[15], fim_can_fea_info->epb1_feature_fim_info().fim_chs1_epb1_epb1_swtsts_invalid(),
    fim_can_fea_info->epb1_feature_fim_info().fim_chs1_epb1_epbsts_invalid(),
    fim_can_fea_info->epb1_feature_fim_info().fim_chs1_epb1_epbfaillampreq_invalid(),
    fim_can_fea_info->epb1_feature_fim_info().fim_chs1_epb1_epb1_mod_invalid(),
    fim_can_info->epb1_fim_info().fim_chs1_epb1_01_msgerror(), fim_can_info->epb1_fim_info().fim_chs1_epb1_can_error(),
    fim_can_fea_info->epb2_feature_fim_info().fim_chs2_epb2_epb2_swtsts_invalid(),
    fim_can_fea_info->epb2_feature_fim_info().fim_chs2_epb2_epbsts_invalid());

  fim_encoder_byte[16] = pack_fim_to_byte(
    kGlobFimMskByte[16], fim_can_fea_info->epb2_feature_fim_info().fim_chs2_epb2_epbfaillampreq_invalid(),
    fim_can_info->epb2_fim_info().fim_chs2_epb2_01_msgerror(), fim_can_info->epb2_fim_info().fim_chs2_epb2_can_error(),
    fim_can_fea_info->epb2_feature_fim_info().fim_chs2_epb2_epb2_mod_invalid());

  fim_encoder_byte[17] = pack_fim_to_byte(
    kGlobFimMskByte[17], fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_estrackforceval_invalid(),
    fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_acimotortqval_invalid(),
    fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_totmotortqval_invalid(),
    fim_can_info->eps1_fim_info().fim_chs1_eps1_01_msgerror(),
    fim_can_info->eps1_fim_info().fim_chs1_eps1_02_msgerror(), fim_can_info->eps1_fim_info().fim_chs1_eps1_error(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_sts_invalid(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_actvextif_invalid());

  fim_encoder_byte[18] = pack_fim_to_byte(
    kGlobFimMskByte[18], fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_pinangval_invalid(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_torsbartqval_invalid(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_estrackforceval_invalid(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_acimotortqval_invalid(),
    fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_eps2_totmotortqval_invalid(),
    fim_can_info->eps2_fim_info().fim_chs2_eps2_01_msgerror(),
    fim_can_info->eps2_fim_info().fim_chs2_eps2_02_msgerror(), fim_can_info->eps2_fim_info().fim_chs2_eps2_error());

  fim_encoder_byte[19] = pack_fim_to_byte(kGlobFimMskByte[19], fim_can_info->radfc_fim_info().fim_rad_error(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_canversion_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_header_alignmentstate_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_header_sensorcoverage_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_header_timestamps_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_mrr_status_radar_msgerror(),
                                          fim_can_info->radfc_fim_info().fim_rad_blindness());

  fim_encoder_byte[20] =
    pack_fim_to_byte(kGlobFimMskByte[20],
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs2_vcu_vcu_vlcavl_invalid(),   // 20.0
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_vcuvehdispspd_error(),  // 20.1
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_llcfctst_error(),       // 20.2
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_cdc_328_msgerror()                  // 20.3
    );

  fim_encoder_byte[21] =
    pack_fim_to_byte(kGlobFimMskByte[21], fim_sw_info->s1_process_fim_info().fim_can_rx_exited_abnormal(),
                     fim_sw_info->s1_process_fim_info().fim_can_tx_exited_abnormal(),
                     fim_sw_info->s1_process_fim_info().fim_radar_app_exited_abnormal(),
                     fim_sw_info->s1_process_fim_info().fim_camera_sal_exited_abnormal(),
                     fim_sw_info->s1_process_fim_info().fim_position_app_exited_abnormal(),
                     fim_sw_info->s2_process_fim_info().fim_can_rx_exited_abnormal(),
                     fim_sw_info->s2_process_fim_info().fim_can_tx_exited_abnormal(),
                     fim_sw_info->s2_process_fim_info().fim_radar_app_exited_abnormal());

  fim_encoder_byte[22] =
    pack_fim_to_byte(kGlobFimMskByte[22], fim_sw_info->s2_process_fim_info().fim_camera_sal_exited_abnormal(),
                     fim_sw_info->s2_process_fim_info().fim_position_app_exited_abnormal(),
                     fim_sw_info->s3_process_fim_info().fim_can_rx_exited_abnormal(),
                     fim_sw_info->s3_process_fim_info().fim_can_tx_exited_abnormal(),
                     fim_sw_info->s3_process_fim_info().fim_radar_app_exited_abnormal(),
                     fim_sw_info->s3_process_fim_info().fim_camera_sal_exited_abnormal(),
                     fim_sw_info->s3_process_fim_info().fim_position_app_exited_abnormal(),
                     fim_sw_info->s4_process_fim_info().fim_can_rx_exited_abnormal());

  fim_encoder_byte[23] =
    pack_fim_to_byte(kGlobFimMskByte[23], fim_sw_info->s4_process_fim_info().fim_can_tx_exited_abnormal(),
                     fim_sw_info->s4_process_fim_info().fim_radar_app_exited_abnormal(),
                     fim_sw_info->s4_process_fim_info().fim_camera_sal_exited_abnormal(),
                     fim_sw_info->s4_process_fim_info().fim_position_app_exited_abnormal());

  fim_encoder_byte[24] =
    pack_fim_to_byte(kGlobFimMskByte[24], fim_camera_info->fw_adc_fim_info().fim_fwphysicallinkage_error(),
                     fim_camera_info->oms_adc_fim_info().fim_omsphysicallinkage_error(),
                     fim_camera_info->dms_adc_fim_info().fim_dmsphysicallinkage_error(),
                     fim_camera_info->fn_adc_fim_info().fim_fnphysicallinkage_error(),
                     fim_camera_info->rn_adc_fim_info().fim_rnphysicallinkage_error(),
                     fim_camera_info->svcleft_adc_fim_info().fim_svcleftphysicallinkage_error(),
                     fim_camera_info->svcright_adc_fim_info().fim_svcrightphysicallinkage_error(),
                     fim_camera_info->svcfront_adc_fim_info().fim_svcfrontphysicallinkage_error());

  fim_encoder_byte[25] =
    pack_fim_to_byte(kGlobFimMskByte[25], fim_camera_info->svcrear_adc_fim_info().fim_svcrearphysicallinkage_error(),
                     fim_camera_info->sidefl_adc_fim_info().fim_sideflphysicallinkage_error(),
                     fim_camera_info->sidefr_adc_fim_info().fim_sidefrphysicallinkage_error(),
                     fim_camera_info->siderl_adc_fim_info().fim_siderlphysicallinkage_error(),
                     fim_camera_info->siderr_adc_fim_info().fim_siderrphysicallinkage_error());

  fim_encoder_byte[26] = pack_fim_to_byte(
    kGlobFimMskByte[26], fim_power_info->primary_power_fim_info().fim_primary_battery_input_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_primary_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_misc_battery_abnormal(),
    fim_power_info->primary_power_fim_info().fim_s1_battery_input_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_s1_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_gnssa_battery_input_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_gnssa_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_gnssb_imu_battery_input_overvoltage());

  fim_encoder_byte[27] = pack_fim_to_byte(
    kGlobFimMskByte[27], fim_power_info->primary_power_fim_info().fim_gnssb_imu_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_gnss_imu_battery_input_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_gnss_imu_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_s2_battery_input_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_s2_battery_input_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_primary_cameras_battery_overvoltage(),
    fim_power_info->primary_power_fim_info().fim_primary_cameras_battery_undervoltage(),
    fim_power_info->primary_power_fim_info().fim_bat_in21_vsense_overvoltage());

  fim_encoder_byte[28] =
    pack_fim_to_byte(kGlobFimMskByte[28], fim_power_info->primary_power_fim_info().fim_bat_in21_vsense_undervoltage(),
                     fim_power_info->primary_power_fim_info().fim_p3v3_mcu21_vsense_overvoltage(),
                     fim_power_info->primary_power_fim_info().fim_p3v3_mcu21_vsense_undervoltage(),
                     fim_power_info->secondary_power_fim_info().fim_bat_in12_vsense_overvoltage(),
                     fim_power_info->secondary_power_fim_info().fim_bat_in12_vsense_undervoltage(),
                     fim_power_info->secondary_power_fim_info().fim_p3v3_mcu12_vsense_overvoltage(),
                     fim_power_info->secondary_power_fim_info().fim_p3v3_mcu12_vsense_undervoltage(),
                     fim_power_info->secondary_power_fim_info().fim_secondary_battery_input_overvoltage());

  fim_encoder_byte[29] = pack_fim_to_byte(
    kGlobFimMskByte[29], fim_power_info->secondary_power_fim_info().fim_secondary_battery_input_undervoltage(),
    fim_power_info->secondary_power_fim_info().fim_s3_battery_input_overvoltage(),
    fim_power_info->secondary_power_fim_info().fim_s3_battery_input_undervoltage(),
    fim_power_info->secondary_power_fim_info().fim_s4_battery_input_overvoltage(),
    fim_power_info->secondary_power_fim_info().fim_s4_battery_input_undervoltage(),
    fim_power_info->secondary_power_fim_info().fim_secondary_cameras_battery_overvoltage(),
    fim_power_info->secondary_power_fim_info().fim_secondary_cameras_battery_undervoltage());

  fim_encoder_byte[30] = pack_fim_to_byte(
    kGlobFimMskByte[30], fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_steeragsnsrfailsts_error(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_steeragsnsrcalsts_notcalibrated(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_steerwhlagandspdvalid_invalid(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_turnindcrswtsts_invalid(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_hilowbeampushswtsts_invalid(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_wiprautmodpushswtsts_invalid(),
    fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_frntwiprswtsts_invalid(),
    fim_can_info->scm_fim_info().fim_chs1_scm_01_msgerror());

  fim_encoder_byte[31] =
    pack_fim_to_byte(kGlobFimMskByte[31], fim_can_info->scm_fim_info().fim_chs1_scm_02_msgerror(),
                     fim_can_info->scm_fim_info().fim_chs1_scm_can_error(),
                     fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_foglipushswtsts_invalid(),
                     fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_wshrandrewiprpushswtsts_invalid(),
                     fim_can_fea_info->scm_feature_fim_info().fim_chs1_scm_frntwiprinterspd_invalid());

  fim_encoder_byte[32] =
    pack_fim_to_byte(kGlobFimMskByte[32], fim_can_info->swc_fim_info().fim_chs1_swc_01_msgerror(),
                     fim_can_info->swc_fim_info().fim_chs1_swc_can_error(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_centpushswtsts_invalid(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcle_dwnpushswtsts_invalid(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcle_lepushswtsts_invalid(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcle_ripushswtsts_invalid(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcle_uppushswtsts_invalid(),
                     fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcri_centpushswtsts_invalid());

  fim_encoder_byte[33] = pack_fim_to_byte(
    kGlobFimMskByte[33], fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcri_dwnpushswtsts_invalid(),
    fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcri_lepushswtsts_invalid(),
    fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcri_ripushswtsts_invalid(),
    fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcle_swcri_uppushswtsts_invalid(),
    fim_can_fea_info->swc_feature_fim_info().fim_chs1_swc_swcfailsts_invalid());

  fim_encoder_byte[34] =
    pack_fim_to_byte(kGlobFimMskByte[34],
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_vcuactgearvalid_invalid(),       // 34.0
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_accrpedlactposnvalid_invalid(),  // 34.1
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_vcutargetgearvalid_invalid(),    // 34.2
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_accrpedlefcposnvalid_invalid(),  // 34.3
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_02_msgerror(),                               // 34.4
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_05_msgerror(),                               // 34.5
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_13_msgerror(),                               // 34.6
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_can_error()                                  // 34.7
    );

  fim_encoder_byte[35] =
    pack_fim_to_byte(kGlobFimMskByte[35],
                     fim_can_info->vcu_fim_info().fim_chs1_vcu_healthmngt_msgerror(),                         // 35.0
                     fim_can_info->vcu_fim_info().fim_chs2_vcu_13_msgerror(),                                 // 35.1
                     fim_can_info->vcu_fim_info().fim_chs2_vcu_can_error(),                                   // 35.2
                     fim_can_info->vcu_fim_info().fim_chs2_vcu_healthmngt_msgerror(),                         // 35.3
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_vcugearselectorposnvld_invalid(),  // 35.4
                     fim_can_fea_info->vcu_feature_fim_info().fim_chs1_vcu_vcu_vlcavl_invalid()               // 35.5
    );

  fim_encoder_byte[36] = pack_fim_to_byte(
    kGlobFimMskByte[36],
    fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_brkpressoffsetvalid_invalid(),  // 36.0
    fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_hdcsts_invalid(),               // 36.1
    fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_avhsts_invalid(),               // 36.2
    false,  // fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_autobrkavl_notavailable() obsolete 36.3
    fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_vehspdsts_asild_invalid(),  // 36.4
    fim_can_fea_info->bcu_feature_fim_info().fim_chs1_bcu_absfaillampreq_lampon()     // 36.5
  );

  fim_encoder_byte[37] = pack_fim_to_byte(kGlobFimMskByte[37], fim_can_info->bgw_fim_info().fim_adas_bgw_can_error(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_power_swap_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_scu_d_02_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_scu_p_01_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_scu_p_02_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_snsr_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_adas_bgw_steerwhl_cmd_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_01_msgerror());

  fim_encoder_byte[38] = pack_fim_to_byte(kGlobFimMskByte[38], fim_can_info->bgw_fim_info().fim_chs1_bgw_02_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_03_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_can_error(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_li_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_tcu_01_msgerror(),
                                          fim_can_info->bgw_fim_info().fim_chs1_bgw_wipr_msgerror(),
                                          fim_can_fea_info->bgw_feature_fim_info().fim_chs1_bgw_vehstate_invalid(),
                                          fim_can_fea_info->bgw_feature_fim_info().fim_adas_bgw_fogliscmcmd_invalid());

  fim_encoder_byte[39] =
    pack_fim_to_byte(kGlobFimMskByte[39], fim_can_fea_info->bgw_feature_fim_info().fim_adas_bgw_hibeamscmcmd_invalid(),
                     fim_can_fea_info->cdc_feature_fim_info().fim_adas_bgw_vehprepreq_invalid());

  fim_encoder_byte[40] = pack_fim_to_byte(
    kGlobFimMskByte[40], fim_can_info->can_fim_info().fim_adas_can_busoff(),
    fim_can_info->can_fim_info().fim_chs1_can_busoff(), fim_can_info->can_fim_info().fim_chs2_can_busoff(),
    fim_can_info->can_fim_info().fim_frontrad_can_busoff(), fim_can_info->can_fim_info().fim_frontsiderad_can_busoff(),
    fim_can_info->can_fim_info().fim_rearsiderad_can_busoff(), fim_can_info->ccu_fim_info().fim_chs1_ccu_can_error());

  fim_encoder_byte[41] = pack_fim_to_byte(
    kGlobFimMskByte[41], fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_setlaneassiaidtyp_invalid(),
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_setlaneassisnvty_invalid(),
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_cdc_failsts_failure(),
    false,  // fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_cdc_adas_failsts_failure() obsolete
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_sethma_invalid(),
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_mailiset_invalid(),
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_aebonoffreq_invalid());

  fim_encoder_byte[42] = pack_fim_to_byte(
    kGlobFimMskByte[42], fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_danadtaugapstored_invalid(),
    false,  // fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_gonotifieronoff_invalid() obsolete
    fim_can_fea_info->cdc_feature_fim_info().fim_chs1_cdc_swcadjmodreq_invalid(),
    fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_laneassisttactileonoff_invalid(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_adc_03_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_adc_04_msgerror(), fim_can_info->cdc_fim_info().fim_adas_cdc_can_error(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_dms_01_msgerror());

  fim_encoder_byte[43] = pack_fim_to_byte(
    kGlobFimMskByte[43], fim_can_info->cdc_fim_info().fim_adas_cdc_dms_02_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_hu_03_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_hu_07_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_hu_08_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_hu_09_msgerror(),
    fim_can_info->cdc_fim_info().fim_adas_cdc_hu_19_msgerror(),
    fim_can_info->cdc_fim_info().fim_chs1_cdc_adc_01_msgerror(), fim_can_info->cdc_fim_info().fim_chs1_cdc_can_error());

  fim_encoder_byte[44] =
    pack_fim_to_byte(kGlobFimMskByte[44], fim_can_info->cdc_fim_info().fim_chs1_cdc_hu_04_msgerror(),
                     fim_can_info->cdc_fim_info().fim_chs1_cdc_hu_09_msgerror(),
                     fim_can_info->cdc_fim_info().fim_chs1_cdc_hu_12_msgerror(),
                     fim_can_info->cdc_fim_info().fim_chs1_cdc_ic_01_msgerror(),
                     fim_can_info->cdc_fim_info().fim_chs1_cdc_ic_04_msgerror(),
                     fim_can_info->cdc_fim_info().fim_chs2_cdc_hu_04_msgerror(),
                     fim_can_fea_info->cdc_feature_fim_info().fim_chs1_cdc_sapaprkgmodreq_invalid(),
                     fim_can_fea_info->cdc_feature_fim_info().fim_adas_cdc_setalc_invalid());

  fim_encoder_byte[45] = pack_fim_to_byte(kGlobFimMskByte[45],
                                          fim_lidar_info->fim_lidar_com_error(),         // 45.0
                                          fim_lidar_info->fim_lidar_internal_fault1(),   // 45.1
                                          fim_lidar_info->fim_lidar_window_blockage1(),  // 45.2
                                          fim_lidar_info->fim_lidar_window_blockage2(),  // 45.3
                                          fim_lidar_info->fim_lidar_window_blockage3(),  // 45.4
                                          fim_lidar_info->fim_lidar_window_blockage4(),  // 45.5
                                          false,                                         // 45.6
                                          fim_lidar_info->fim_lidar_overheat1()          // 45.7
  );

  fim_encoder_byte[46] = pack_fim_to_byte(kGlobFimMskByte[46],
                                          fim_lidar_info->fim_lidar_overheat2(),  // 46
                                          fim_lidar_info->fim_lidar_overheat3()   // 46.1
  );

  fim_encoder_byte[47] =
    pack_fim_to_byte(kGlobFimMskByte[47], fim_can_fea_info->ccu_feature_fim_info().fim_chs1_ccu_ambtempvalid_invalid(),
                     fim_can_fea_info->ccu_feature_fim_info().fim_adas_intrtempvalid_ccu());

  fim_encoder_byte[48] = pack_fim_to_byte(
    kGlobFimMskByte[48],
    get_valid_data(fim_mcu_soc_info->has_fim_mcu1tos1_ethcan_msgerror(),
                   fim_mcu_soc_info->fim_mcu1tos1_ethcan_msgerror(), fim_mcu1tos1_ethcan_msgerror_ll),  // 48.0
    get_valid_data(fim_mcu_soc_info->has_fim_mcu2tos1_ethcan_msgerror(),
                   fim_mcu_soc_info->fim_mcu2tos1_ethcan_msgerror(), fim_mcu2tos1_ethcan_msgerror_ll),  // 48.1
    get_valid_data(fim_mcu_soc_info->has_fim_s1tomcu1_ethcan_msgerror(),
                   fim_mcu_soc_info->fim_s1tomcu1_ethcan_msgerror(), fim_s1tomcu1_ethcan_msgerror_ll),  // 48.2
    get_valid_data(fim_mcu_soc_info->has_fim_s1tomcu2_ethcan_msgerror(),
                   fim_mcu_soc_info->fim_s1tomcu2_ethcan_msgerror(), fim_s1tomcu2_ethcan_msgerror_ll)  // 48.3
  );

  fim_encoder_byte[49] =
    pack_fim_to_byte(kGlobFimMskByte[49], fim_can_fea_info->eps2_feature_fim_info().fim_chs2_eps2_adcacioravl(),
                     fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_adcacioravl(),
                     fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_sts_invalid(),
                     fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_actvextif_invalid(),
                     fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_pinangval_invalid(),
                     fim_can_fea_info->eps1_feature_fim_info().fim_chs1_eps1_eps1_torsbartqval_invalid());

  fim_encoder_byte[50] = pack_fim_to_byte(kGlobFimMskByte[50], fim_can_info->radfl_fim_info().fim_rad_error(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_canversion_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_header_alignmentstate_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_header_sensorcoverage_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_header_timestamps_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_mrr_status_radar_msgerror(),
                                          fim_can_info->radfl_fim_info().fim_rad_blindness());

  fim_encoder_byte[51] = pack_fim_to_byte(kGlobFimMskByte[51], fim_can_info->radfr_fim_info().fim_rad_error(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_canversion_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_header_alignmentstate_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_header_sensorcoverage_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_header_timestamps_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_mrr_status_radar_msgerror(),
                                          fim_can_info->radfr_fim_info().fim_rad_blindness());

  fim_encoder_byte[52] = pack_fim_to_byte(kGlobFimMskByte[52], fim_can_info->radrl_fim_info().fim_rad_error(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_canversion_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_header_alignmentstate_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_header_sensorcoverage_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_header_timestamps_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_mrr_status_radar_msgerror(),
                                          fim_can_info->radrl_fim_info().fim_rad_blindness());

  fim_encoder_byte[53] = pack_fim_to_byte(kGlobFimMskByte[53], fim_can_info->radrr_fim_info().fim_rad_error(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_canversion_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_header_alignmentstate_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_header_sensorcoverage_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_header_timestamps_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_mrr_status_radar_msgerror(),
                                          fim_can_info->radrr_fim_info().fim_rad_blindness());

  fim_encoder_byte[54] = pack_fim_to_byte(kGlobFimMskByte[54],
                                          fim_can_info->radfc_fim_info().fim_rad_error(),  //	54
                                          fim_can_info->radrr_fim_info().fim_rad_error(),  //	54.1
                                          fim_lidar_info->fim_lidar_internal_fault2(),     //	54.2
                                          false,                                           //	54.3
                                          false,                                           //	54.4
                                          false,                                           //	54.5
                                          false,                                           //	54.6
                                          false);                                          //	54.7

  fim_encoder_byte[55] = pack_fim_to_byte(kGlobFimMskByte[55],
                                          false,   //	55
                                          false,   //	55.1
                                          false,   //	55.2
                                          false,   //	55.3
                                          false,   //	55.4
                                          false,   //	55.5
                                          false,   //	55.6
                                          false);  //	55.7

  fim_encoder_byte[56] = pack_fim_to_byte(kGlobFimMskByte[56],
                                          false,                                        // 56
                                          false,                                        // obsolete 56.1
                                          false,                                        // obsolete 56.2
                                          false,                                        // obsolete 56.3
                                          false,                                        // obsolete 56.4
                                          fim_lidar_info->fim_lidar_internal_fault2(),  // obsolete 56.5
                                          false,                                        // obsolete 56.6
                                          false);                                       // obsolete 56.7

  fim_encoder_byte[57] = pack_fim_to_byte(kGlobFimMskByte[57],
                                          false,   // obsolete 57
                                          false,   // 57.1
                                          false,   // obsolete 57.2
                                          false,   // obsolete 57.3
                                          false,   // obsolete 57.4
                                          false,   // obsolete 57.5
                                          false,   // obsolete 57.6
                                          false);  // obsolete 57.7

  fim_encoder_byte[58] = pack_fim_to_byte(kGlobFimMskByte[58],
                                          false,                                             // obsolete 58
                                          false,                                             // obsolete 58.1
                                          false,                                             // obsolete 58.2
                                          false,                                             // obsolete 58.3
                                          false,                                             // obsolete 58.4
                                          false,                                             // reject 58.5
                                          false,                                             // reject 58.6
                                          fim_perception_info->fim_fw_camera_data_error());  // 58.7

  fim_encoder_byte[59] = pack_fim_to_byte(kGlobFimMskByte[59],
                                          fim_perception_info->fim_fn_camera_data_error(),         // 59
                                          fim_perception_info->fim_fl_camera_data_error(),         //	59.1
                                          fim_perception_info->fim_fr_camera_data_error(),         //	59.2
                                          fim_perception_info->fim_rl_camera_data_error(),         //	59.3
                                          fim_perception_info->fim_rr_camera_data_error(),         //	59.4
                                          fim_perception_info->fim_svcleft_camera_data_error(),    //	59.5
                                          fim_perception_info->fim_svcright_camera_data_error(),   //	59.6
                                          fim_perception_info->fim_svcfront_camera_data_error());  //	59.7

  fim_encoder_byte[60] = pack_fim_to_byte(kGlobFimMskByte[60],
                                          fim_perception_info->fim_svcrear_camera_data_error(),  // 60
                                          fim_perception_info->fim_rn_camera_data_error(),       //	60.1
                                          fim_perception_info->fim_fw_camera_data_error(),       //	60.2
                                          fim_perception_info->fim_fn_camera_data_error(),       //	60.3
                                          fim_perception_info->fim_fl_camera_data_error(),       //	60.4
                                          fim_perception_info->fim_fr_camera_data_error(),       //	60.5
                                          fim_perception_info->fim_rl_camera_data_error(),       //	60.6
                                          fim_perception_info->fim_rr_camera_data_error());      //	60.7

  fim_encoder_byte[61] = pack_fim_to_byte(kGlobFimMskByte[61],
                                          fim_perception_info->fim_svcleft_camera_data_error(),   // 61
                                          fim_perception_info->fim_svcright_camera_data_error(),  //	61.1
                                          fim_perception_info->fim_svcfront_camera_data_error(),  //	61.2
                                          fim_perception_info->fim_svcrear_camera_data_error(),   //	61.3
                                          fim_perception_info->fim_rn_camera_data_error(),        //	61.4
                                          fim_perception_info->fim_imu_data_error(),              //	61.5
                                          false,                                                  //	61.6
                                          false);                                                 //	61.7

  fim_encoder_byte[62] = pack_fim_to_byte(kGlobFimMskByte[62],
                                          fim_perception_info->fim_lidar_data_error(),       // 62
                                          fim_perception_info->fim_can_data_error(),         //	62.1
                                          false,                                             //	62.2
                                          false,                                             //	62.3
                                          false,                                             //	62.4
                                          fim_perception_info->fim_fw_camera_data_error(),   //	62.5
                                          fim_perception_info->fim_fn_camera_data_error(),   //	62.6
                                          fim_perception_info->fim_fl_camera_data_error());  //	62.7

  fim_encoder_byte[63] = pack_fim_to_byte(kGlobFimMskByte[63],
                                          fim_perception_info->fim_fr_camera_data_error(),        // 63
                                          fim_perception_info->fim_rl_camera_data_error(),        //	63.1
                                          fim_perception_info->fim_rr_camera_data_error(),        //	63.2
                                          fim_perception_info->fim_svcleft_camera_data_error(),   //	63.3
                                          fim_perception_info->fim_svcright_camera_data_error(),  //	63.4
                                          fim_perception_info->fim_svcfront_camera_data_error(),  //	63.5
                                          fim_perception_info->fim_svcrear_camera_data_error(),   //	63.6
                                          fim_perception_info->fim_rn_camera_data_error());       //	63.7

  fim_encoder_byte[64] = pack_fim_to_byte(kGlobFimMskByte[64],
                                          fim_perception_info->fim_imu_data_error(),    // 64
                                          fim_perception_info->fim_rtk_data_error(),    //	64.1
                                          fim_perception_info->fim_can_data_error(),    //	64.2
                                          fim_perception_info->fim_lidar_data_error(),  //	64.3
                                          fim_perception_info->fim_lidar_data_error(),  //	64.4
                                          false,                                        // obsolete 64.5
                                          false,                                        // obsolete 64.6
                                          false);                                       // obsolete 64.7

  fim_encoder_byte[65] = pack_fim_to_byte(kGlobFimMskByte[65],
                                          false,             // obsolete 65
                                          false,                // obsolete 65.1
                                          false,   // obsolete 65.2
                                          false,   // obsolete 65.3
                                          false,   // obsolete 65.4
                                          false,   // obsolete 65.5
                                          false,                  // obsolete 65.6
                                          false);                  // obsolete 65.7

  fim_encoder_byte[66] = pack_fim_to_byte(kGlobFimMskByte[66],
                                          false,             // obsolete 66
                                          false,                // obsolete 66.1
                                          false,   // obsolete 66.2
                                          false,   // obsolete 66.3
                                          false,   // obsolete 66.4
                                          false,   // obsolete 66.5
                                          false,                  // obsolete 66.6
                                          false);                  // obsolete 66.7

  fim_encoder_byte[67] = pack_fim_to_byte(kGlobFimMskByte[67],
                                          false,  // obsolete 67
                                          false,  // obsolete 67.1
                                          false,  // obsolete 67.2
                                          fim_camera_info->fw_adc_fim_info().fim_fw_camera_cal_error(),       //	67.3
                                          fim_camera_info->fn_adc_fim_info().fim_fn_camera_cal_error(),       //	67.4
                                          fim_camera_info->sidefl_adc_fim_info().fim_fl_camera_cal_error(),   //	67.5
                                          fim_camera_info->sidefr_adc_fim_info().fim_fr_camera_cal_error(),   //	67.6
                                          fim_camera_info->siderl_adc_fim_info().fim_rl_camera_cal_error());  //	67.7

  fim_encoder_byte[68] =
    pack_fim_to_byte(kGlobFimMskByte[68],
                     fim_camera_info->siderr_adc_fim_info().fim_rr_camera_cal_error(),          // 68
                     fim_camera_info->svcleft_adc_fim_info().fim_svcleft_camera_cal_error(),    // 68.1
                     fim_camera_info->svcright_adc_fim_info().fim_svcright_camera_cal_error(),  // 68.2
                     fim_camera_info->svcfront_adc_fim_info().fim_svcfront_camera_cal_error(),  // 68.3
                     fim_camera_info->svcrear_adc_fim_info().fim_svcrear_camera_cal_error(),    // 68.4
                     fim_camera_info->rn_adc_fim_info().fim_rn_camera_cal_error(),              // 68.5
                     false,                                                                     // 68.6 duplicate 67.3
                     false);                                                                    // 68.7 duplicate 67.4

  fim_encoder_byte[69] = pack_fim_to_byte(kGlobFimMskByte[69],
                                          false,   // 69
                                          false,   //	69.1
                                          false,   //	69.2
                                          false,   //	69.3
                                          false,   //	69.4
                                          false,   //	69.5
                                          false,   //	69.6
                                          false);  //	69.7

  fim_encoder_byte[70] = pack_fim_to_byte(kGlobFimMskByte[70],
                                          false,                                   // 70
                                          fim_lidar_info->fim_lidar_cal_error(),   //	70.1
                                          fim_camera_info->fw_adc_fim_info().fim_windshield_cal_error(),//	70.2
                                          fim_perception_info->fim_hdmap_error(),  //	70.3
                                          false,                                   //	70.4
                                          false,                                   //	70.5
                                          false,                                   //	70.6
                                          false);                                  //	70.7

  fim_encoder_byte[71] = pack_fim_to_byte(kGlobFimMskByte[71],
                                          false,   // fim_s2_sys_timesync_error(),  // 71
                                          false,   // fim_s2_ptp_timesync_error(),  //	71.1
                                          false,   // fim_s3_sys_timesync_error(),  //	71.2
                                          false,   // fim_s3_ptp_timesync_error(),  //	71.3
                                          false,   // fim_s4_sys_timesync_error(),  //	71.4
                                          false,   // fim_s4_ptp_timesync_error(),  //	71.5
                                          false,   // fim_lidar_timesync_error(),   //	71.6
                                          false);  // fim_mcu1_timesync_error());   //	71.7

  fim_encoder_byte[72] = pack_fim_to_byte(kGlobFimMskByte[72],
                                          false,   // fim_mcu2_timesync_error(),            // 72
                                          false,   // fim_imu_timesync_error(),  //	72.1
                                          false,   // 72.2
                                          false,   //	72.3
                                          false,   //	72.4
                                          false,   //	72.5
                                          false,   //	72.6
                                          false);  //	72.7

  fim_encoder_byte[73] = pack_fim_to_byte(kGlobFimMskByte[73],
                                          false,                                 // 73
                                          false,                                 //	73.1
                                          false,                                 //	73.2
                                          false,                                 //	73.3
                                          false,                                 //	73.4
                                          false,                                 //	73.5
                                          false,                                 //	73.6
                                          fim_mcu_sys_info->fim_s1_hw_error());  //	73.7

  fim_encoder_byte[74] = pack_fim_to_byte(kGlobFimMskByte[74],
                                          false,                                // 74
                                          fim_mcu_sys_info->fim_s2_hw_error(),  //	74.1
                                          false,                                //	74.2
                                          fim_mcu_sys_info->fim_s3_hw_error(),  //	74.3
                                          false,                                //	74.4
                                          fim_mcu_sys_info->fim_s4_hw_error(),  //	74.5
                                          false,                                //	74.6
                                          false);                               //	74.7

  fim_encoder_byte[75] = pack_fim_to_byte(kGlobFimMskByte[75],
                                          false,   // 75
                                          false,   //	75.1
                                          false,   //	75.2
                                          false,   //	75.3
                                          false,   //	75.4
                                          false,   //	75.5
                                          false,   //	75.6
                                          false);  //	75.7

  fim_encoder_byte[76] = pack_fim_to_byte(kGlobFimMskByte[76],
                                          false,   // 76
                                          false,   //	76.1
                                          false,   //	76.2
                                          false,   //	76.3
                                          false,   //	76.4
                                          false,   //	76.5
                                          false,   //	76.6
                                          false);  //	76.7

  fim_encoder_byte[77] = pack_fim_to_byte(kGlobFimMskByte[77],
                                          false,   // 77
                                          false,   //	77.1
                                          false,   //	77.2
                                          false,   //	77.3
                                          false,   //	77.4
                                          false,   //	77.5
                                          false,   //	77.6
                                          false);  //	77.7

  fim_encoder_byte[78] = pack_fim_to_byte(kGlobFimMskByte[78],
                                          false,   // 78
                                          false,   //	78.1
                                          false,   //	78.2
                                          false,   //	78.3
                                          false,   //	78.4
                                          false,   //	78.5
                                          false,   //	78.6
                                          false);  //	78.7

  fim_encoder_byte[79] = pack_fim_to_byte(kGlobFimMskByte[79],
                                          false,   // 79
                                          false,   //	79.1
                                          false,   //	79.2
                                          false,   //	79.3
                                          false,   //	79.4
                                          false,   //	79.5
                                          false,   //	79.6
                                          false);  //	79.7

  fim_encoder_byte[80] = pack_fim_to_byte(kGlobFimMskByte[80],
                                          false,   // 80
                                          false,   //	80.1
                                          false,   //	80.2
                                          false,   //	80.3
                                          false,   //	80.4
                                          false,   //	80.5
                                          false,   //	80.6
                                          false);  //	80.7

  fim_encoder_byte[81] = pack_fim_to_byte(kGlobFimMskByte[81],
                                          false,   // 81
                                          false,   //	81.1
                                          false,   //	81.2
                                          false,   //	81.3
                                          false,   //	81.4
                                          false,   //	81.5
                                          false,   //	81.6
                                          false);  //	81.7

  fim_encoder_byte[82] = pack_fim_to_byte(kGlobFimMskByte[82],
                                          false,   // 82
                                          false,   //	82.1
                                          false,   //	82.2
                                          false,   //	82.3
                                          false,   //	82.4
                                          false,   //	82.5
                                          false,   //	82.6
                                          false);  //	82.7

  fim_encoder_byte[83] = pack_fim_to_byte(kGlobFimMskByte[83],
                                          false,   // 83
                                          false,   //	83.1
                                          false,   //	83.2
                                          false,   //	83.3
                                          false,   //	83.4
                                          false,   //	83.5
                                          false,   //	83.6
                                          false);  //	83.7

  fim_encoder_byte[84] = pack_fim_to_byte(kGlobFimMskByte[84],
                                          false,   // 84
                                          false,   //	84.1
                                          false,   //	84.2
                                          false,   //	84.3
                                          false,   //	84.4
                                          false,   //	84.5
                                          false,   //	84.6
                                          false);  //	84.7

  fim_encoder_byte[85] = pack_fim_to_byte(kGlobFimMskByte[85],
                                          false,   // 85
                                          false,   //	85.1
                                          false,   //	85.2
                                          false,   //	85.3
                                          false,   //	85.4
                                          false,   //	85.5
                                          false,   //	85.6
                                          false);  //	85.7

  fim_encoder_byte[86] = pack_fim_to_byte(kGlobFimMskByte[86],
                                          false,   // 86
                                          false,   //	86.1
                                          false,   //	86.2
                                          false,   //	86.3
                                          false,   //	86.4
                                          false,   //	86.5
                                          false,   //	86.6
                                          false);  //	86.7

  fim_encoder_byte[87] = pack_fim_to_byte(kGlobFimMskByte[87],
                                          false,   // 87
                                          false,   //	87.1
                                          false,   //	87.2
                                          false,   //	87.3
                                          false,   //	87.4
                                          false,   //	87.5
                                          false,   //	87.6
                                          false);  //	87.7

  fim_encoder_byte[88] = pack_fim_to_byte(kGlobFimMskByte[88],
                                          false,   // 88
                                          false,   //	88.1
                                          false,   //	88.2
                                          false,   //	88.3
                                          false,   //	88.4
                                          false,   //	88.5
                                          false,   //	88.6
                                          false);  //	88.7

  fim_encoder_byte[89] = pack_fim_to_byte(kGlobFimMskByte[89],
                                          false,   // 89
                                          false,   //	89.1
                                          false,   //	89.2
                                          false,   //	89.3
                                          false,   //	89.4
                                          false,   //	89.5
                                          false,   //	89.6
                                          false);  //	89.7

  fim_encoder_byte[90] = pack_fim_to_byte(kGlobFimMskByte[90],
                                          false,   // 90
                                          false,   //	90.1
                                          false,   //	90.2
                                          false,   //	90.3
                                          false,   //	90.4
                                          false,   //	90.5
                                          false,   //	90.6
                                          false);  //	90.7

  fim_encoder_byte[91] = pack_fim_to_byte(kGlobFimMskByte[91],
                                          fim_camera_info->sidefl_adc_fim_info().fim_fl_camera_cal_error(),   // 91
                                          fim_camera_info->sidefr_adc_fim_info().fim_fr_camera_cal_error(),   //	91.1
                                          fim_camera_info->siderl_adc_fim_info().fim_rl_camera_cal_error(),   //	91.2
                                          fim_camera_info->siderr_adc_fim_info().fim_rr_camera_cal_error(),   //	91.3
                                          fim_camera_info->svcleft_adc_fim_info().fim_svcleft_camera_cal_error(),   //	91.4
                                          fim_camera_info->svcright_adc_fim_info().fim_svcright_camera_cal_error(),   //	91.5
                                          false,   //	91.6
                                          false);  //	91.7

  fim_encoder_byte[92] = pack_fim_to_byte(
    kGlobFimMskByte[92],
    fim_camera_info->rn_adc_fim_info().fim_rn_camera_cal_error(),                                                                    // 92
    false,                                                                    //	92.1
    fim_camera_info->fw_adc_fim_info().fim_windshield_cal_error(),            //	92.2
    fim_can_fea_info->bgw_feature_fim_info().fim_adas_bgw_hoderrsts_error(),  //	92.3
    get_valid_data(fim_mcu_soc_info->has_fim_mcu1tos1_mrr_msgerror(), fim_mcu_soc_info->fim_mcu1tos1_mrr_msgerror(),
                   fim_mcu1tos1_mrr_msgerror_ll),  //	92.4
    get_valid_data(fim_mcu_soc_info->has_fim_mcu2tos1_mrr_msgerror(), fim_mcu_soc_info->fim_mcu2tos1_mrr_msgerror(),
                   fim_mcu2tos1_mrr_msgerror_ll),  //	92.5
    false,                                         // fim_gnss1_msgerror(),  92.6
    false);                                        // fim_gnss1_msgerror()); 92.7

  fim_encoder_byte[93] = pack_fim_to_byte(kGlobFimMskByte[93],
                                          false,   // fim_gnss1_msgerror(),   // 93
                                          false,   // fim_gnss1_msgerror(),   //	93.1
                                          false,   // fim_gnss1_msgerror(),   //	93.2
                                          false,   // fim_gnss1_msgerror(),   //	93.3
                                          false,   // fim_gnss1_msgerror(),   //	93.4
                                          false,   // fim_gnss1_msgerror(),   //	93.5
                                          false,   // fim_gnss2_msgerror(),   //	93.6
                                          false);  // fim_gnss2_msgerror());  //	93.7

  fim_encoder_byte[94] = pack_fim_to_byte(kGlobFimMskByte[94],
                                          false,   // fim_gnss2_msgerror(),          // 94
                                          false,   // fim_gnss2_msgerror(),          //	94.1
                                          false,   // fim_gnss2_msgerror(),          //	94.2
                                          false,   // fim_gnss2_msgerror(),          //	94.3
                                          false,   // fim_gnss2_msgerror(),          //	94.4
                                          false,   // fim_gnss2_msgerror(),          //	94.5
                                          false,   // fim_rtk_data_msgerror(),       //	94.6
                                          false);  // fim_main_antenna_abnormal());  //	94.7

  fim_encoder_byte[95] =
    pack_fim_to_byte(kGlobFimMskByte[95],
                     false,  // 95
                     false,  // fim_wheelspd_data_error(),           //	95.1
                     false,  // fim_imu_msgerror(),  //	95.2
                     false,  // fim_wheelspd_imu_timestamp_error(),  //	95.3
                     fim_camera_info->dms_adc_fim_info().fim_dms_license_notavailable(),       //	95.4
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_abaavl_notavailable(),  //	95.5
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_abpavl_notavailable(),  //	95.6
                     fim_can_fea_info->bcu_feature_fim_info().fim_chs1_brkoverheat());         //	95.7

  fim_encoder_byte[96] = pack_fim_to_byte(kGlobFimMskByte[96],
                                          false,  // fim_gnsscal_imu_timestamp_error());  // 96
                                          fim_lidar_info->fim_lidar_temphigh_inhibit());  //  96.1

  fim_encoder_byte[97]  = pack_fim_to_byte(kGlobFimMskByte[97],
                                          fim_mcu_sys_info->fim_mcu1_temporary_error(),   // 97
                                          false,                                     // 97.1
                                          false,                                     // 97.2
                                          false,                                     // 97.3
                                          false,                                     // 97.4
                                          fim_mcu_sys_info->fim_mcu2_temp_error());  // 97.5
  fim_encoder_byte[98]  = pack_fim_to_byte(kGlobFimMskByte[98],
                                          false,   // fim_mcu2_temp_error(),          // 98
                                          false,   // fim_s1_error(),                //	98.1
                                          false,   // fim_s2_error(),                //	98.2
                                          false,   // fim_s3_error(),                //	98.3
                                          false,   // fim_s4_error(),                //	98.4
                                          fim_camera_info->dms_adc_fim_info().fim_dms_function_notavailable(),   //	98.5
                                          false,   //                                //	98.6
                                          false);  //                                //	98.7
  fim_encoder_byte[99]  = pack_fim_to_byte(kGlobFimMskByte[99],
                                          false,   //                                // 99
                                          false,   //                                //	99.1
                                          false,   //                                //	99.2
                                          false,   //                                //	99.3
                                          false,   //                                //	99.4
                                          false,   //                                //	99.5
                                          false,   //                                //	99.6
                                          false);  //                                //	99.7
  fim_encoder_byte[100] = pack_fim_to_byte(kGlobFimMskByte[100],
                                           fim_sw_info->s1_process_fim_info().fim_aa_app_exited_abnormal(),    // 100
                                           fim_sw_info->s1_process_fim_info().fim_ehy_app_exited_abnormal(),   //	100.1
                                           fim_sw_info->s1_process_fim_info().fim_fct_app_exited_abnormal(),   //	100.2
                                           fim_sw_info->s1_process_fim_info().fim_fcts_app_exited_abnormal(),  //	100.3
                                           fim_sw_info->s1_process_fim_info().fim_fam_extied_abnoraml(),       //	100.4
                                           fim_sw_info->s2_process_fim_info().fim_aa_app_exited_abnormal(),    //	100.5
                                           fim_sw_info->s2_process_fim_info().fim_ehy_app_exited_abnormal(),   //	100.6
                                           fim_sw_info->s2_process_fim_info().fim_fct_app_exited_abnormal());  //	100.7
  fim_encoder_byte[101] = pack_fim_to_byte(kGlobFimMskByte[101],
                                           fim_sw_info->s2_process_fim_info().fim_fcts_app_exited_abnormal(),  // 101
                                           fim_sw_info->s2_process_fim_info().fim_fam_extied_abnoraml(),       //	101.1
                                           fim_sw_info->s3_process_fim_info().fim_aa_app_exited_abnormal(),    //	101.2
                                           fim_sw_info->s3_process_fim_info().fim_ehy_app_exited_abnormal(),   //	101.3
                                           fim_sw_info->s3_process_fim_info().fim_fct_app_exited_abnormal(),   //	101.4
                                           fim_sw_info->s3_process_fim_info().fim_fcts_app_exited_abnormal(),  //	101.5
                                           fim_sw_info->s3_process_fim_info().fim_fam_extied_abnoraml(),       //	101.6
                                           false);                                                             //	101.7

  fim_encoder_byte[105] = pack_fim_to_byte(kGlobFimMskByte[105],
                                           fim_camera_info->fw_adc_fim_info().fim_fwphysicallinkage_error(),  // 105
                                           fim_camera_info->fn_adc_fim_info().fim_fnphysicallinkage_error(),  // 105.1
                                           fim_camera_info->sidefl_adc_fim_info().fim_sideflphysicallinkage_error(),                                                             // 105.2
                                           fim_camera_info->sidefr_adc_fim_info().fim_sidefrphysicallinkage_error(),                                                             // 105.3
                                           fim_camera_info->siderl_adc_fim_info().fim_siderlphysicallinkage_error(),                                                             // 105.4
                                           fim_camera_info->siderr_adc_fim_info().fim_siderrphysicallinkage_error(),                                                             // 105.5
                                           fim_camera_info->svcleft_adc_fim_info().fim_svcleftphysicallinkage_error(),                                                             // 105.6
                                           fim_camera_info->svcright_adc_fim_info().fim_svcrightphysicallinkage_error());                                                            // 105.7

  fim_encoder_byte[106]  = pack_fim_to_byte(kGlobFimMskByte[106],
                                          false,   //                                // 106
                                          false,   //                                //	106.1
                                          fim_camera_info->rn_adc_fim_info().fim_rnphysicallinkage_error(),   //                                //	106.2
                                          false,   //                                //	106.3
                                          false,   //                                //	106.4
                                          false,   //                                //	106.5
                                          false,   //                                //	106.6
                                          false);  //                                //	106.7

  fim_encoder_byte[110] =
    pack_fim_to_byte(kGlobFimMskByte[110],
                     fim_perception_info->fim_nop_plus_internal_error().stop_vehicle_standstil(),            // 111
                     fim_perception_info->fim_nop_plus_internal_error().deactivate_function(),               //	111.1
                     fim_perception_info->fim_nop_plus_internal_error().lateral_control_suppression(),       //	111.2
                     fim_perception_info->fim_nop_plus_internal_error().longitudinal_control_suppression(),  //	111.3
                     fim_perception_info->fim_nop_plus_internal_error().lane_change_suppression(),           //	111.4
                     fim_perception_info->fim_nop_plus_internal_error().takeover_warning(),                  //	111.5
                     fim_perception_info->fim_nop_plus_internal_error().attention_warning(),                 //	111.6
                     false);

  fim_encoder_byte[111] =
    pack_fim_to_byte(kGlobFimMskByte[111],
                     fim_perception_info->fim_da_internal_error().stop_vehicle_standstil(),            // 111
                     fim_perception_info->fim_da_internal_error().deactivate_function(),               //	111.1
                     fim_perception_info->fim_da_internal_error().lateral_control_suppression(),       //	111.2
                     fim_perception_info->fim_da_internal_error().longitudinal_control_suppression(),  //	111.3
                     fim_perception_info->fim_da_internal_error().lane_change_suppression(),           //	111.4
                     fim_perception_info->fim_da_internal_error().takeover_warning(),                  //	111.5
                     fim_perception_info->fim_da_internal_error().attention_warning(),                 //	111.6
                     false);

  fim_encoder_byte[112] =
    pack_fim_to_byte(kGlobFimMskByte[112],
                     false,                                                                // 112
                     fim_perception_info->fim_aeb_internal_error().deactivate_function(),  //	112.1
                     false,                                                                //	112.2
                     false,                                                                //	112.3
                     false,                                                                //	112.4
                     false,                                                                //	112.5
                     false,                                                                //	112.6
                     false);                                                               //	112.7
  fim_encoder_byte[113] =
    pack_fim_to_byte(kGlobFimMskByte[113],
                     false,                                                                // 113
                     fim_perception_info->fim_elk_internal_error().deactivate_function(),  //	113.1
                     false,                                                                //	113.2
                     false,                                                                //	113.3
                     false,                                                                //	113.4
                     false,                                                                //	113.5
                     false,                                                                //	113.6
                     false);                                                               //	113.7
  fim_encoder_byte[114] =
    pack_fim_to_byte(kGlobFimMskByte[114],
                     false,                                                                // 114
                     fim_perception_info->fim_lka_internal_error().deactivate_function(),  //	114.1
                     false,                                                                //	114.2
                     false,                                                                //	114.3
                     false,                                                                //	114.4
                     false,                                                                //	114.5
                     false,                                                                //	114.6
                     false);                                                               //	114.7
  fim_encoder_byte[115] =
    pack_fim_to_byte(kGlobFimMskByte[115],
                     false,                                                                // 115
                     fim_perception_info->fim_eas_internal_error().deactivate_function(),  //	115.1
                     false,                                                                //	115.2
                     false,                                                                //	115.3
                     false,                                                                //	115.4
                     false,                                                                //	115.5
                     false,                                                                //	115.6
                     false);                                                               //	115.7
  fim_encoder_byte[116] = pack_fim_to_byte(kGlobFimMskByte[116],
                                           false,   // 116
                                           false,   //	116.1
                                           false,   //	116.2
                                           false,   //	116.3
                                           false,   //	116.4
                                           false,   //	116.5
                                           false,   //	116.6
                                           false);  //	116.7
  fim_encoder_byte[117] = pack_fim_to_byte(kGlobFimMskByte[117],
                                           false,   // 117
                                           false,   //	117.1
                                           false,   //	117.2
                                           false,   //	117.3
                                           false,   //	117.4
                                           false,   //	117.5
                                           false,   //	117.6
                                           false);  //	117.7
  fim_encoder_byte[118] = pack_fim_to_byte(kGlobFimMskByte[118],
                                           false,   // 118
                                           false,   //	118.1
                                           false,   //	118.2
                                           false,   //	118.3
                                           false,   //	118.4
                                           false,   //	118.5
                                           false,   //	118.6
                                           false);  //	118.7
  fim_encoder_byte[119] = pack_fim_to_byte(kGlobFimMskByte[119],
                                           false,   // 119
                                           false,   //	119.1
                                           false,   //	119.2
                                           false,   //	119.3
                                           false,   //	119.4
                                           false,   //	119.5
                                           false,   //	119.6
                                           false);  //	119.7
  fim_encoder_byte[120] = pack_fim_to_byte(kGlobFimMskByte[120],
                                           false,   // 120
                                           false,   //	120.1
                                           false,   //	120.2
                                           false,   //	120.3
                                           false,   //	120.4
                                           false,   //	120.5
                                           false,   //	120.6
                                           false);  //	120.7
  fim_encoder_byte[121] = pack_fim_to_byte(kGlobFimMskByte[121],
                                           fim_can_info->bcm_fim_info().fim_adas_bcm_can_error(),          // 121
                                           fim_camera_info->dms_adc_fim_info().fim_dms_camera_occluded(),  //	121.1
                                           fim_camera_info->dms_adc_fim_info().fim_dms_no_image_recv(),    //	121.2
                                           false,                                                          //	121.3
                                           false,                                                          //	121.4
                                           false,                                                          //	121.5
                                           false,                                                          //	121.6
                                           false);                                                         //	121.7
  fim_encoder_byte[122] = pack_fim_to_byte(kGlobFimMskByte[122],
                                           false,   // 122
                                           false,   //	122.1
                                           false,   //	122.2
                                           false,   //	122.3
                                           false,   //	122.4
                                           false,   //	122.5
                                           false,   //	122.6
                                           false);  //	122.7
  fim_encoder_byte[123] = pack_fim_to_byte(kGlobFimMskByte[123],
                                           false,   // 123
                                           false,   //	123.1
                                           false,   //	123.2
                                           false,   //	123.3
                                           false,   //	123.4
                                           false,   //	123.5
                                           false,   //	123.6
                                           false);  //	123.7
  fim_encoder_byte[124] = pack_fim_to_byte(kGlobFimMskByte[124],
                                           false,   // 124
                                           false,   //	124.1
                                           false,   //	124.2
                                           false,   //	124.3
                                           false,   //	124.4
                                           false,   //	124.5
                                           false,   //	124.6
                                           false);  //	124.7
  fim_encoder_byte[125] = pack_fim_to_byte(kGlobFimMskByte[125],
                                           false,   // 125
                                           false,   //	125.1
                                           false,   //	125.2
                                           false,   //	125.3
                                           false,   //	125.4
                                           false,   //	125.5
                                           false,   //	125.6
                                           false);  //	125.7
  fim_encoder_byte[126] = pack_fim_to_byte(kGlobFimMskByte[126],
                                           false,   // 126
                                           false,   //	126.1
                                           false,   //	126.2
                                           false,   //	126.3
                                           false,   //	126.4
                                           false,   //	126.5
                                           false,   //	126.6
                                           false);  //	126.7
  fim_encoder_byte[127] = pack_fim_to_byte(kGlobFimMskByte[127],
                                           false,   // 127
                                           false,   //	127.1
                                           false,   //	127.2
                                           false,   //	127.3
                                           false,   //	127.4
                                           false,   //	127.5
                                           false,   //	127.6
                                           false);  //	127.7
  fim_encoder_byte[128] = pack_fim_to_byte(kGlobFimMskByte[128],
                                           false,   // 128
                                           fim_sw_info->s1_process_fim_info().fim_nopdelta_control_exited_abnoraml(),   //	128.1
                                           fim_sw_info->s1_process_fim_info().fim_nopdelta_canbus_exited_abnoraml(),   //	128.2
                                           fim_sw_info->s1_process_fim_info().fim_nopdelta_wm_exited_abnoraml(),   //	128.3
                                           fim_sw_info->s1_process_fim_info().fim_rel_loc_app_exited_abnoraml(),   //	128.4
                                           fim_sw_info->s2_process_fim_info().fim_map_loc_app_exited_abnormal(),   //	128.5
                                           false,   //	128.6
                                           false);  //	128.7
  fim_encoder_byte[129] = pack_fim_to_byte(kGlobFimMskByte[129],
                                           fim_lidar_info->fim_lidar_abnormal_status(), //fim_lidar_info->fim_lidar_bnormal_status(),   // 129
                                           fim_perception_info->fim_psp_internal_error().deactivate_function(),   //	129.1
                                           fim_perception_info->fim_psp_internal_error().takeover_warning(),   //	129.2
                                           false,   //	129.3
                                           false,   //	129.4
                                           false,   //	129.5
                                           false,   //	129.6
                                           false);  //	129.7
  fim_encoder_byte[153] = pack_fim_to_byte(kGlobFimMskByte[153],
                                           false,   //  153
                                           fim_perception_info->fim_imu_hw_perpetual_error(), // 153.1
                                           false,   //  153.2
                                           false,   //	153.3
                                           false,   //	153.4
                                           false,   //	153.5
                                           false,   //	153.6
                                           false);  //	153.7
  fim_encoder_byte[154] = pack_fim_to_byte(kGlobFimMskByte[154],
                                           fim_mcu_sys_info->fim_s1_hw_temporary_error(),   //  154
                                           false,    // 154.1
                                           fim_mcu_sys_info->fim_s3_hw_temporary_error(),   //  154.2
                                           false,   //	154.3
                                           false,   //	154.4
                                           false,   //	154.5
                                           false,   //	154.6
                                           false);  //	154.7
  fim_encoder_byte[155] = pack_fim_to_byte(kGlobFimMskByte[155],
                                           fim_mcu_sys_info->fim_mcu1_hw_error(), // 155
                                           false,   //  155.1
                                           false,   //  155.2
                                           false,   //	155.3
                                           false,   //	155.4
                                           false,   //	155.5
                                           false,   //	155.6
                                           false);  //	155.7
  fim_encoder_byte[156] = pack_fim_to_byte(kGlobFimMskByte[156],
                                           fim_perception_info->fim_reloc_general_error(), // 156
                                           fim_perception_info->fim_global_loc_general_error(),   //  156.1
                                           fim_perception_info->fim_perception_general_error(),   //  156.2
                                           fim_perception_info->fim_perception_road_error(),   //	156.3
                                           fim_perception_info->fim_perception_od_error(),   //	156.4
                                           false,   //	156.5
                                           false,   //	156.6
                                           false);  //	156.7
}

}  // namespace ad
}  // namespace nio
