#include <iostream>
#include "failsafe_encoder.h"

namespace nio {
namespace ad {

DiagFailsafe::DiagFailsafe() {}

inline void FailsafeBitEncoder(uint32_t value, bool has, uint32_t index, T_FS& fim_failsafe) {
  if (has) {
    fim_failsafe.none &= ~(static_cast<uint16_t>(0x01) << index);
    fim_failsafe.low &= ~(static_cast<uint16_t>(0x01) << index);
    fim_failsafe.middle &= ~(static_cast<uint16_t>(0x01) << index);
    fim_failsafe.high &= ~(static_cast<uint16_t>(0x01) << index);
    switch (value) {
    case 0:
      fim_failsafe.none |= (0x01 << index);
      break;
    case 1:
      fim_failsafe.low |= (0x01 << index);
      break;
    case 2:
      fim_failsafe.middle |= (0x01 << index);
      break;
    case 3:
      fim_failsafe.high |= (0x01 << index);
      break;
    default:
      break;
    }
  }
}

void DiagFailsafe::vision_FailsafeEncoder(const nio::ad::messages::FailSafe& failsafe_info, T_FS& fim_failsafe) {
  FailsafeBitEncoder(failsafe_info.fs_rain(), failsafe_info.has_fs_rain(), 0, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_fog(), failsafe_info.has_fs_fog(), 1, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_snow(), failsafe_info.has_fs_snow(), 2, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_full_blockage(), failsafe_info.has_fs_full_blockage(), 3, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_partial_blockage(), failsafe_info.has_fs_partial_blockage(), 4, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_lowsun(), failsafe_info.has_fs_lowsun(), 5, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_sunray(), failsafe_info.has_fs_sunray(), 6, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_splash(), failsafe_info.has_fs_splash(), 7, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_windshield_frozen(), failsafe_info.has_fs_windshield_frozen(), 8, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_out_of_calibration(), failsafe_info.has_fs_out_of_calibration(), 9, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_out_of_focus(), failsafe_info.has_fs_out_of_focus(), 10, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_blur(), failsafe_info.has_fs_blur(), 11, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_smeared_halo(), failsafe_info.has_fs_smeared_halo(), 12, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_illuminance(), failsafe_info.has_fs_illuminance(), 13, fim_failsafe);
}

void DiagFailsafe::lidar_FailsafeEncoder(const nio::ad::messages::Lidar_FailSafe& failsafe_info, T_FS& fim_failsafe) {
  FailsafeBitEncoder(failsafe_info.fs_window_blockage(), failsafe_info.has_fs_window_blockage(), 0, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_dust(), failsafe_info.has_fs_dust(), 1, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_wet_road(), failsafe_info.has_fs_wet_road(), 2, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_rain_snow(), failsafe_info.has_fs_rain_snow(), 3, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_intrinsic_calibration(), failsafe_info.has_fs_intrinsic_calibration(), 4,
                     fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_hw(), failsafe_info.has_fs_hw(), 5, fim_failsafe);
  FailsafeBitEncoder(failsafe_info.fs_out_of_calibration(), failsafe_info.has_fs_out_of_calibration(), 6, fim_failsafe);
}
}  // namespace ad
}  // namespace nio