#ifndef ASIMOV_COMPILER_H
#define ASIMOV_COMPILER_H

#define CAL_VAR __attribute__((section(".calsec")))
#define MES_VAR __attribute__((section(".messec")))
#define IDS_IN
#define IDS_OUT

#endif
