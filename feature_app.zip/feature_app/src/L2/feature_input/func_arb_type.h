#pragma once

#include <stdint.h>
#include <string>

enum class FunctionRequest_e {
  ReqOff      = 0,  // request to unload function app // not in BL07X
  ReqLoaded   = 1,  // request to load function app into RAM, but do not execute it
  ReqChecking = 2,  // request to execution of app
  ReqSandby   = 3,  // request function to go standby
  ReqRunning  = 4,  // request function to run
};

enum class FuncId_e : uint16_t {
  NONE       = 0,
  FCW        = 1,
  FCTA       = 2,
  RCTA       = 3,
  LDW        = 21,
  SLIF       = 41,
  SLWF       = 42,
  BSD        = 50,
  LCA        = 51,
  SDOW       = 60,
  AEB        = 101,
  AEBreverse = 102,
  LKA        = 141,
  ELK        = 151,
  AES        = 161,
  AHB        = 171,
  EAS        = 181,
  DaMain     = 201,
  DaResume   = 202,
  DaSdc      = 211,
  DaIsa      = 221,
  DaPsc      = 231,
  DaLcc      = 261,
  DaAs       = 271,
  DaAlcs     = 281,
  DaNbc      = 291,
  NAD        = 304,
  SapaMain   = 401,
  SapaIn     = 402,
  SapaOut    = 403,
  PsapMain   = 411,
  PsapIn     = 412,
  PsapOut    = 413,
};

struct FunctionXrequest_s {
  // string FunctionName;	// name	of Function	// redundant to IC
  // Note: Simulink 2017b not support string type parameter
  int32_t           FunctionID;  // ID 	of Function	// redundant to name
  FunctionRequest_e FuncReq;
};

struct FunctionStatus_s {
  FuncId_e          id;
  FunctionRequest_e sts;
};

class FUNCARB {
  // private:
 public:
  /* data */
  FunctionXrequest_s FunctionReq[20];  // 0:DA_Main 1:ELK 2:AHB 3:EAS 4:DA_SDC 5:DA_LCC 6:DA_NBC 7:SAPA_Main
                                       // 8:PSAP_Main;
  FunctionStatus_s FunctionStatus[10]; // 0:PSAP 

 public:
  FUNCARB(/* args */);
  ~FUNCARB();
};