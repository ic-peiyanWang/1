#pragma once
#include "veh_enum_type.h"

enum class VcuCruiseSt_e{
	Fault   = 0 , //Cruise Fault
	Off     = 1 , //Cruise Off
	Stdby   = 2 , //Cruise Standby (Enabled but not functioning)
	Actv    = 3 , //Cruise Active
	Ovrd    = 4 , //Cruise Override
	Rsrvd5 	= 5 , //Reserved
	Rsrvd6 	= 6 , //Reserved
	Rsrvd7 	= 7 , //Reserved
	Rsrvd8 	= 8 , //Reserved
	Rsrvd9 	= 9 , //Reserved
	Rsrvd10	= 10, //Reserved
	Rsrvd11	= 11, //Reserved
	Rsrvd12	= 12, //Reserved
	Rsrvd13	= 13, //Reserved
	Rsrvd14 = 14, //Reserved
	Invld   = 15, //Invalid
};
enum class VcuEpbReq_e{
	Undtrmnd = 0,	//Undetermined
	NoReq    = 1,	//No request
	Apply    = 2,	//Apply Request
	Release  = 3,	//Release Request
};
struct AccrPedalInfo_s{
	QfZeroVld_e 	EfcPosnVld ;				//@Channel:CHASSIS @Message:0x45 @Signal:AccrPedlEfcPosnValid
	float 	EfcPosn			   ;				//@Channel:CHASSIS @Message:0x45 @Signal:AccrPedlEfcPosn
	QfZeroVld_e 	ActPosnVld ;				//@Channel:CHASSIS @Message:0x45 @Signal:AccrPedlActPosnValid
	float 	ActPosn			   ;				//@Channel:CHASSIS @Message:0x45 @Signal:AccrPedlActPosn
	float   ActPosnRate;
	bool 	PedlOvrd		   ;				//@Channel:CHASSIS @Message:0x45 @Signal:VCUAccrPedlOvrd
};
struct GearInfo_s{
	QfZeroVld_e SlctrPosnVld  ;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUGearSelectorPosnVld
	unsigned int SlctrPosn 			;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUGearSelectorPosn
	QfZeroVld_e ActGearVld 	;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUActGearValid
	unsigned int ActGear				;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUActGear
	QfZeroVld_e TrgtGearVld	;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUTargetGearValid
	unsigned int TrgtGear		    	;			//@Channel:CHASSIS @Message:0x217 @Signal:VCUTargetGear
};
struct MotorInfo_s{
	QfZeroVld_e  IntdMotTqVld;			//@Channel:CHASSIS @Message:0x45 @Signal:VCUIntdFrntMotTqValid 
														//@Channel:CHASSIS @Message:0x45 @Signal:VCUIntdReMotTqValid
	float IntdMotTq			 ;			//@Channel:CHASSIS @Message:0x45 @Signal:VCUIntdFrntMotTq
														//@Channel:CHASSIS @Message:0x45 @Signal:VCUIntdReMotTq	
	QfZeroVld_e  ActMotTqVld	 ;			//@Channel:CHASSIS @Message:0x84 @Signal:PEUFMotActTqValid 
														//@Channel:CHASSIS @Message:0x8C @Signal:PEURMotActTqValid
	float ActMotTq				 ;			//@Channel:CHASSIS @Message:0x84 @Signal:PEUFMotActTq 
														//@Channel:CHASSIS @Message:0x8C @Signal:PEURMotActTq
	QfZeroVld_e  MotSpdVld	 ;			//@Channel:CHASSIS @Message:0x84 @Signal:PEUFMotSpdValid
														//@Channel:CHASSIS @Message:0x8C @Signal:PEURMotSpdValid
	float MotSpd				 ;			//@Channel:CHASSIS @Message:0x84 @Signal:PEUFMotSpd 
														//@Channel:CHASSIS @Message:0x84 @Signal:PEURMotSpd
};

class VEHPT
{
private:
public:
    /* data */
	AccrPedalInfo_s AccrPedal;
	GearInfo_s Gear;
	MotorInfo_s Motor[2];//0:Front 1:Rear
	bool VCUTqAvl 	;						//@Channel:CHASSIS @Message:0x217 @Signal:VCUTqAvl
	bool CTABrkAvl  ;						//@Channel:CHASSIS @Message:0x45  @Signal:CTABrkAvl
	bool VCURvsLampReq;						//@Channel:CHASSIS @Message:0x217 @Signal:VCURvsLampReq
	bool VCUBrkLampReq;						//@Channel:CHASSIS @Message:0x217 @Signal:VCUBrkLampReq
	VcuCruiseSt_e CruiseStatus;			//@Channel:CHASSIS @Message:0x217 @Signal:CruiseStatus
	VcuEpbReq_e VCUEPBReq;					//@Channel:CHASSIS @Message:0x217 @Signal:VCUEPBReq
	unsigned int CruiseStoredSpeed;				//@Channel:CHASSIS @Message:0x217 @Signal:CruiseStoredSpeed
	bool VCUPtWakeupReq      ;				//@Channel:CHASSIS @Message:0x217 @Signal:VCUPtWakeupReq
	unsigned int VCUHealthMngt1;				//@Channel:CHASSIS @Message:0x109 @Signal:VCU_HealthMngt1
public:
    VEHPT(/* args */);
    ~VEHPT();
};

