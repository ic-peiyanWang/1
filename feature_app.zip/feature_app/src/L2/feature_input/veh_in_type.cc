#include "veh_in_type.h"
BRKSYS::BRKSYS(/* args */) {}

BRKSYS::~BRKSYS() {}

STRSYS::STRSYS(/* args */) {}

STRSYS::~STRSYS() {}
VEHBODY::VEHBODY(/* args */) {}

VEHBODY::~VEHBODY() {}

VEHCTRL::VEHCTRL(/* args */) {}

VEHCTRL::~VEHCTRL() {}

VEHDRVR::VEHDRVR(/* args */) {}

VEHDRVR::~VEHDRVR() {}
VEHPT::VEHPT(/* args */) {}

VEHPT::~VEHPT() {}
VEHSUSPN::VEHSUSPN(/* args */) {}

VEHSUSPN::~VEHSUSPN() {}
VEHUPA::VEHUPA(/* args */) {}

VEHUPA::~VEHUPA() {}
VEHWHL::VEHWHL(/* args */) {}

VEHWHL::~VEHWHL() {}
VEHDYN::VEHDYN() {}
VEHDYN::~VEHDYN() {}
EHYVisionRoad::EHYVisionRoad(/* args */) {}
EHYVisionRoad::~EHYVisionRoad() {}
VisionRoadSign::VisionRoadSign(/* args */) {}
VisionRoadSign::~VisionRoadSign() {}
EHYEVD::EHYEVD() {}
EHYEVD::~EHYEVD() {}
EHYHA::EHYHA() {}
EHYHA::~EHYHA() {}
EHYTSI::EHYTSI() {}
EHYTSI::~EHYTSI() {}
EHYTSE::EHYTSE() {}
EHYTSE::~EHYTSE() {}
EHYRME::EHYRME() {}
EHYRME::~EHYRME() {}
EHYTPP::EHYTPP() {}
EHYTPP::~EHYTPP() {}
EHYLPP::EHYLPP() {}
EHYLPP::~EHYLPP() {}
EHYOBF::EHYOBF() {}
EHYOBF::~EHYOBF() {}

DMS::DMS() {}
DMS::~DMS() {}
VisionFailSafe::VisionFailSafe() {}
VisionFailSafe::~VisionFailSafe() {}

CAMFIMINFO::CAMFIMINFO() {}
CAMFIMINFO::~CAMFIMINFO() {}

VEHPARAM::VEHPARAM() {}
VEHPARAM::~VEHPARAM() {}

BSDSTS::BSDSTS() {}
BSDSTS::~BSDSTS() {}

SDMAP::SDMAP() {}
SDMAP::~SDMAP() {}

NopVehicleOut::NopVehicleOut() {}
NopVehicleOut::~NopVehicleOut() {}
NopFunctionstatus::NopFunctionstatus() {}
NopFunctionstatus::~NopFunctionstatus() {}

NopSpeed::NopSpeed() {}
NopSpeed::~NopSpeed() {}
NopSpeedLimitValue::NopSpeedLimitValue() {}
NopSpeedLimitValue::~NopSpeedLimitValue() {}

NopChassisControl::NopChassisControl() {}
NopChassisControl::~NopChassisControl() {}
LIDARFAULTINFO::LIDARFAULTINFO() {}
LIDARFAULTINFO::~LIDARFAULTINFO() {}
AEBOUT::AEBOUT() {}
AEBOUT::~AEBOUT() {}
CfgTskSwt::CfgTskSwt() {}
CfgTskSwt::~CfgTskSwt() {}
// SpeedController_Info::SpeedController_Info() {}
// SpeedController_Info::~SpeedController_Info() {}

CommonProc_Info::CommonProc_Info() {}
CommonProc_Info::~CommonProc_Info() {}

DANOPSM::DANOPSM() {}
DANOPSM::~DANOPSM() {}

NopPowerPilotState::NopPowerPilotState() {}
NopPowerPilotState::~NopPowerPilotState() {}

GLOBALLOCALIZATION::GLOBALLOCALIZATION() {}
GLOBALLOCALIZATION::~GLOBALLOCALIZATION() {}

GlobalLocation::GlobalLocation() {}
GlobalLocation::~GlobalLocation() {}

HDLINK::HDLINK() {}
HDLINK::~HDLINK() {}

EsdNpFeature::EsdNpFeature() {}
EsdNpFeature::~EsdNpFeature() {}

ADSOUT::ADSOUT() {}
ADSOUT::~ADSOUT() {}

DASM_Info::DASM_Info() {}
DASM_Info::~DASM_Info() {}

PERCEPTIONFIMINFO::PERCEPTIONFIMINFO() {}
PERCEPTIONFIMINFO::~PERCEPTIONFIMINFO() {}

LIDARFIMINFO::LIDARFIMINFO() {}
LIDARFIMINFO::~LIDARFIMINFO() {}
