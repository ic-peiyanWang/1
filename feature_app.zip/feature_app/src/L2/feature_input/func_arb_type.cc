#include "func_arb_type.h"
FUNCARB::FUNCARB() {}

FUNCARB::~FUNCARB() {}