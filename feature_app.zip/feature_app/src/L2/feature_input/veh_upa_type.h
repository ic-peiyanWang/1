#pragma once

enum class SlotObj_e {
  None = 0,
  Virtual = 1,
  Real = 2,
  Sna = 3,
};

enum class SlotSts_e {
  None = 0,
  Unsuitable = 1,
  Ok = 2,
  Rsrvd3 = 3,
};

enum class Slot_e {
  None = 0,
  LeParallel = 1,
  RiParallel = 2,
  LeCross = 3,
  RiCross = 4,
  Rsrvd5 = 5,
  Rsrvd6 = 6,
  Sna = 7,
};

enum class SlotDepthRef_e {
  None = 0,
  Curb = 1,
  Wall = 2,
  Virtual = 3,
  Low = 4,
  High = 5,
  Unknow = 6,
  Rsrvd7 = 7,
};

enum class MapObj_e {
  None = 0,
  Point = 1,
  Straight0Corner = 2,
  Straight1Corner = 3,
  Reserved4 = 4,
  Straight2Corner = 5,
  Rsrvd6 = 6,
  Sna = 7,
};

enum class MapObjHei_e {
  Low = 0,
  High = 1,
  Traversable = 2,
  Unknow3 = 3,
};

enum class UsSnsrFltSt_e {
  NoFail = 0,    // NoFailure
  PrmntFail = 1, // PermanentFailure
  TempFail = 2,  // TemporaryFailure
  Sna = 3,       // Sna
};

enum class UsSDWSts_e {
  Disable = 0,
  Standby = 1,
  Active = 2,
  Failure = 3,
};

enum class APASts_e {
  Disabled = 0,
  Standby = 1,
  Searching = 2,
  Tracking = 3,
  Failure = 4,
  Rsrvd5 = 5,
  Rsrvd6 = 6,
  Rsrvd7 = 7,
};

enum class MapObjSts_e {
  Off = 0,
  Standby = 1,
  Active = 2,
  ReFail = 3,   // FrontActive and RearFailure
  FrntFail = 4, // RearActive and FrontFailure
  SysFail = 5,  // SystemFailure
  Rsrvd6 = 6,
  Rsrvd7 = 7,
};

enum class UpaSysSts_e {
  Off = 0,
  Standby = 1,
  Active = 2,
  ReFail = 3,   // FrontActive and RearFailure
  FrntFail = 4, // RearActive and FrontFailure
  SysFail = 5,  // SystemFailure
  Rsrvd6 = 6,
  Rsrvd7 = 7,
};

struct USSlotInfo_s {
  unsigned int SlotSizeX; //@Channel:ADAS @Message:0x1E9 @Signal:Slot01SizeX
                          //@Channel:ADAS @Message:0x1EC @Signal:Slot02SizeX
                          //@Channel:ADAS @Message:0x1EF @Signal:Slot03SizeX
                          //@Channel:ADAS @Message:0x1F2 @Signal:Slot04SizeX
                          //@Channel:ADAS @Message:0x1F5 @Signal:Slot05SizeX
                          //@Channel:ADAS @Message:0x1F8 @Signal:Slot06SizeX

  unsigned int SlotSizeY; //@Channel:ADAS @Message:0x1E9 @Signal:Slot01SizeY
                          //@Channel:ADAS @Message:0x1EC @Signal:Slot02SizeY
                          //@Channel:ADAS @Message:0x1EF @Signal:Slot03SizeY
                          //@Channel:ADAS @Message:0x1F2 @Signal:Slot04SizeY
                          //@Channel:ADAS @Message:0x1F5 @Signal:Slot05SizeY
                          //@Channel:ADAS @Message:0x1F8 @Signal:Slot06SizeY

  unsigned int SlotVehX; //@Channel:ADAS @Message:0x1E9 @Signal:Slot01VehX
                         //@Channel:ADAS @Message:0x1EC @Signal:Slot02VehX
                         //@Channel:ADAS @Message:0x1EF @Signal:Slot03VehX
                         //@Channel:ADAS @Message:0x1F2 @Signal:Slot04VehX
                         //@Channel:ADAS @Message:0x1F5 @Signal:Slot05VehX
                         //@Channel:ADAS @Message:0x1F8 @Signal:Slot06VehX

  unsigned int SlotVehY; //@Channel:ADAS @Message:0x1E9 @Signal:Slot01VehY
                         //@Channel:ADAS @Message:0x1EC @Signal:Slot02VehY
                         //@Channel:ADAS @Message:0x1EF @Signal:Slot03VehY
                         //@Channel:ADAS @Message:0x1F2 @Signal:Slot04VehY
                         //@Channel:ADAS @Message:0x1F5 @Signal:Slot05VehY
                         //@Channel:ADAS @Message:0x1F8 @Signal:Slot06VehY

  unsigned int SlotVehPsi; //@Channel:ADAS @Message:0x1E9 @Signal:Slot01VehPsi
                           //@Channel:ADAS @Message:0x1EC @Signal:Slot02VehPsi
                           //@Channel:ADAS @Message:0x1EF @Signal:Slot03VehPsi
                           //@Channel:ADAS @Message:0x1F2 @Signal:Slot04VehPsi
                           //@Channel:ADAS @Message:0x1F5 @Signal:Slot05VehPsi
                           //@Channel:ADAS @Message:0x1F8 @Signal:Slot06VehPsi

  SlotDepthRef_e
      SlotDepthRef; //@Channel:ADAS @Message:0x1EA @Signal:Slot01DepthRef
                    //@Channel:ADAS @Message:0x1ED @Signal:Slot02DepthRef
                    //@Channel:ADAS @Message:0x1F0 @Signal:Slot03DepthRef
                    //@Channel:ADAS @Message:0x1F3 @Signal:Slot04DepthRef
                    //@Channel:ADAS @Message:0x1F6 @Signal:Slot05DepthRef
                    //@Channel:ADAS @Message:0x1F9 @Signal:Slot06DepthRef

  unsigned int SlotIndex; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Index
                          //@Channel:ADAS @Message:0x1ED @Signal:Slot02Index
                          //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Index
                          //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Index
                          //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Index
                          //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Index

  Slot_e SlotType; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Type
                   //@Channel:ADAS @Message:0x1ED @Signal:Slot02Type
                   //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Type
                   //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Type
                   //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Type
                   //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Type

  SlotSts_e SlotSts; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Sts
                     //@Channel:ADAS @Message:0x1ED @Signal:Slot02Sts
                     //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Sts
                     //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Sts
                     //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Sts
                     //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Sts

  SlotObj_e SlotObj1Typ; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Obj1Typ
                         //@Channel:ADAS @Message:0x1ED @Signal:Slot02Obj1Typ
                         //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Obj1Typ
                         //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Obj1Typ
                         //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Obj1Typ
                         //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Obj1Typ

  unsigned int SlotObj1X; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Obj1X
                          //@Channel:ADAS @Message:0x1ED @Signal:Slot02Obj1X
                          //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Obj1X
                          //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Obj1X
                          //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Obj1X
                          //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Obj1X

  unsigned int SlotObj1Y; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Obj1Y
                          //@Channel:ADAS @Message:0x1ED @Signal:Slot02Obj1Y
                          //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Obj1Y
                          //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Obj1Y
                          //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Obj1Y
                          //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Obj1Y

  unsigned int
      SlotObj1Alpha; //@Channel:ADAS @Message:0x1EA @Signal:Slot01Obj1Alpha
                     //@Channel:ADAS @Message:0x1ED @Signal:Slot02Obj1Alpha
                     //@Channel:ADAS @Message:0x1F0 @Signal:Slot03Obj1Alpha
                     //@Channel:ADAS @Message:0x1F3 @Signal:Slot04Obj1Alpha
                     //@Channel:ADAS @Message:0x1F6 @Signal:Slot05Obj1Alpha
                     //@Channel:ADAS @Message:0x1F9 @Signal:Slot06Obj1Alpha

  SlotObj_e SlotObj2Typ; //@Channel:CHASSIA @Message:0x1EB @Signal:Slot01Obj2Typ
                         //@Channel:CHASSIA @Message:0x1EE @Signal:Slot02Obj2Typ
                         //@Channel:CHASSIA @Message:0x1F1 @Signal:Slot03Obj2Typ
                         //@Channel:CHASSIA @Message:0x1F4 @Signal:Slot04Obj2Typ
                         //@Channel:CHASSIA @Message:0x1F7 @Signal:Slot05Obj2Typ
                         //@Channel:CHASSIA @Message:0x1FA @Signal:Slot06Obj2Typ

  unsigned int SlotObj2X; //@Channel:CHASSIA @Message:0x1EB @Signal:Slot01Obj2X
                          //@Channel:CHASSIA @Message:0x1EE @Signal:Slot02Obj2X
                          //@Channel:CHASSIA @Message:0x1F1 @Signal:Slot03Obj2X
                          //@Channel:CHASSIA @Message:0x1F4 @Signal:Slot04Obj2X
                          //@Channel:CHASSIA @Message:0x1F7 @Signal:Slot05Obj2X
                          //@Channel:CHASSIA @Message:0x1FA @Signal:Slot06Obj2X

  unsigned int SlotObj2Y; //@Channel:CHASSIA @Message:0x1EB @Signal:Slot01Obj2Y
                          //@Channel:CHASSIA @Message:0x1EE @Signal:Slot02Obj2Y
                          //@Channel:CHASSIA @Message:0x1F1 @Signal:Slot03Obj2Y
                          //@Channel:CHASSIA @Message:0x1F4 @Signal:Slot04Obj2Y
                          //@Channel:CHASSIA @Message:0x1F7 @Signal:Slot05Obj2Y
                          //@Channel:CHASSIA @Message:0x1FA @Signal:Slot06Obj2Y

  unsigned int
      SlotObj2Alpha; //@Channel:CHASSIA @Message:0x1EB @Signal:Slot01Obj2Alpha
                     //@Channel:CHASSIA @Message:0x1EE @Signal:Slot02Obj2Alpha
                     //@Channel:CHASSIA @Message:0x1F1 @Signal:Slot03Obj2Alpha
                     //@Channel:CHASSIA @Message:0x1F4 @Signal:Slot04Obj2Alpha
                     //@Channel:CHASSIA @Message:0x1F7 @Signal:Slot05Obj2Alpha
                     //@Channel:CHASSIA @Message:0x1FA @Signal:Slot06Obj2Alpha
};

struct MapObjBaseType_s {
  MapObj_e MapObjTyp; //@Channel:ADAS @Message:0x15A @Signal:MapObj00Typ
                      //@Channel:ADAS @Message:0x15B @Signal:MapObj01Typ
                      //@Channel:ADAS @Message:0x15E @Signal:MapObj02Typ
                      //@Channel:ADAS @Message:0x15F @Signal:MapObj03Typ
                      //@Channel:ADAS @Message:0x160 @Signal:MapObj04Typ
                      //@Channel:ADAS @Message:0x161 @Signal:MapObj05Typ
                      //@Channel:ADAS @Message:0x162 @Signal:MapObj06Typ
                      //@Channel:ADAS @Message:0x163 @Signal:MapObj07Typ
                      //@Channel:ADAS @Message:0x164 @Signal:MapObj08Typ
                      //@Channel:ADAS @Message:0x165 @Signal:MapObj09Typ
                      //@Channel:ADAS @Message:0x15A @Signal:MapObj10Typ
                      //@Channel:ADAS @Message:0x15B @Signal:MapObj11Typ
                      //@Channel:ADAS @Message:0x15E @Signal:MapObj12Typ
                      //@Channel:ADAS @Message:0x15F @Signal:MapObj13Typ
                      //@Channel:ADAS @Message:0x160 @Signal:MapObj14Typ
                      //@Channel:ADAS @Message:0x161 @Signal:MapObj15Typ
                      //@Channel:ADAS @Message:0x162 @Signal:MapObj16Typ
                      //@Channel:ADAS @Message:0x163 @Signal:MapObj17Typ
                      //@Channel:ADAS @Message:0x164 @Signal:MapObj18Typ
                      //@Channel:ADAS @Message:0x165 @Signal:MapObj19Typ

  unsigned int MapObjP1X; //@Channel:ADAS @Message:0x15A @Signal:MapObj00P1X
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj01P1X
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj02P1X
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj03P1X
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj04P1X
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj05P1X
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj06P1X
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj07P1X
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj08P1X
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj09P1X
                          //@Channel:ADAS @Message:0x15A @Signal:MapObj10P1X
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj11P1X
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj12P1X
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj13P1X
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj14P1X
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj15P1X
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj16P1X
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj17P1X
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj18P1X
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj19P1X

  unsigned int MapObjP1Y; //@Channel:ADAS @Message:0x15A @Signal:MapObj00P1Y
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj01P1Y
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj02P1Y
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj03P1Y
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj04P1Y
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj05P1Y
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj06P1Y
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj07P1Y
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj08P1Y
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj09P1Y
                          //@Channel:ADAS @Message:0x15A @Signal:MapObj10P1Y
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj11P1Y
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj12P1Y
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj13P1Y
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj14P1Y
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj15P1Y
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj16P1Y
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj17P1Y
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj18P1Y
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj19P1Y

  unsigned int MapObjP2X; //@Channel:ADAS @Message:0x15A @Signal:MapObj00P2X
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj01P2X
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj02P2X
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj03P2X
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj04P2X
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj05P2X
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj06P2X
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj07P2X
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj08P2X
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj09P2X
                          //@Channel:ADAS @Message:0x15A @Signal:MapObj10P2X
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj11P2X
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj12P2X
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj13P2X
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj14P2X
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj15P2X
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj16P2X
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj17P2X
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj18P2X
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj19P2X

  unsigned int MapObjP2Y; //@Channel:ADAS @Message:0x15A @Signal:MapObj00P2Y
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj01P2Y
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj02P2Y
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj03P2Y
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj04P2Y
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj05P2Y
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj06P2Y
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj07P2Y
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj08P2Y
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj09P2Y
                          //@Channel:ADAS @Message:0x15A @Signal:MapObj10P2Y
                          //@Channel:ADAS @Message:0x15B @Signal:MapObj11P2Y
                          //@Channel:ADAS @Message:0x15E @Signal:MapObj12P2Y
                          //@Channel:ADAS @Message:0x15F @Signal:MapObj13P2Y
                          //@Channel:ADAS @Message:0x160 @Signal:MapObj14P2Y
                          //@Channel:ADAS @Message:0x161 @Signal:MapObj15P2Y
                          //@Channel:ADAS @Message:0x162 @Signal:MapObj16P2Y
                          //@Channel:ADAS @Message:0x163 @Signal:MapObj17P2Y
                          //@Channel:ADAS @Message:0x164 @Signal:MapObj18P2Y
                          //@Channel:ADAS @Message:0x165 @Signal:MapObj19P2Y

  unsigned int
      MapObjProblty; //@Channel:ADAS @Message:0x15A @Signal:MapObj00Problty
                     //@Channel:ADAS @Message:0x15B @Signal:MapObj01Problty
                     //@Channel:ADAS @Message:0x15E @Signal:MapObj02Problty
                     //@Channel:ADAS @Message:0x15F @Signal:MapObj03Problty
                     //@Channel:ADAS @Message:0x160 @Signal:MapObj04Problty
                     //@Channel:ADAS @Message:0x161 @Signal:MapObj05Problty
                     //@Channel:ADAS @Message:0x162 @Signal:MapObj06Problty
                     //@Channel:ADAS @Message:0x163 @Signal:MapObj07Problty
                     //@Channel:ADAS @Message:0x164 @Signal:MapObj08Problty
                     //@Channel:ADAS @Message:0x165 @Signal:MapObj09Problty
                     //@Channel:ADAS @Message:0x15A @Signal:MapObj10Problty
                     //@Channel:ADAS @Message:0x15B @Signal:MapObj11Problty
                     //@Channel:ADAS @Message:0x15E @Signal:MapObj12Problty
                     //@Channel:ADAS @Message:0x15F @Signal:MapObj13Problty
                     //@Channel:ADAS @Message:0x160 @Signal:MapObj14Problty
                     //@Channel:ADAS @Message:0x161 @Signal:MapObj15Problty
                     //@Channel:ADAS @Message:0x162 @Signal:MapObj16Problty
                     //@Channel:ADAS @Message:0x163 @Signal:MapObj17Problty
                     //@Channel:ADAS @Message:0x164 @Signal:MapObj18Problty
                     //@Channel:ADAS @Message:0x165 @Signal:MapObj19Problty

  MapObjHei_e
      MapObjHeiWarn; //@Channel:ADAS @Message:0x15A @Signal:MapObj00HeiWarn
                     //@Channel:ADAS @Message:0x15B @Signal:MapObj01HeiWarn
                     //@Channel:ADAS @Message:0x15E @Signal:MapObj02HeiWarn
                     //@Channel:ADAS @Message:0x15F @Signal:MapObj03HeiWarn
                     //@Channel:ADAS @Message:0x160 @Signal:MapObj04HeiWarn
                     //@Channel:ADAS @Message:0x161 @Signal:MapObj05HeiWarn
                     //@Channel:ADAS @Message:0x162 @Signal:MapObj06HeiWarn
                     //@Channel:ADAS @Message:0x163 @Signal:MapObj07HeiWarn
                     //@Channel:ADAS @Message:0x164 @Signal:MapObj08HeiWarn
                     //@Channel:ADAS @Message:0x165 @Signal:MapObj09HeiWarn
                     //@Channel:ADAS @Message:0x15A @Signal:MapObj10HeiWarn
                     //@Channel:ADAS @Message:0x15B @Signal:MapObj11HeiWarn
                     //@Channel:ADAS @Message:0x15E @Signal:MapObj12HeiWarn
                     //@Channel:ADAS @Message:0x15F @Signal:MapObj13HeiWarn
                     //@Channel:ADAS @Message:0x160 @Signal:MapObj14HeiWarn
                     //@Channel:ADAS @Message:0x161 @Signal:MapObj15HeiWarn
                     //@Channel:ADAS @Message:0x162 @Signal:MapObj16HeiWarn
                     //@Channel:ADAS @Message:0x163 @Signal:MapObj17HeiWarn
                     //@Channel:ADAS @Message:0x164 @Signal:MapObj18HeiWarn
                     //@Channel:ADAS @Message:0x165 @Signal:MapObj19HeiWarn

  MapObjHei_e MapObjHeiProblty; //@Channel:ADAS @Message:0x15A
                                //@Signal:MapObj00HeiProblty
                                //@Channel:ADAS @Message:0x15B
                                //@Signal:MapObj01HeiProblty
                                //@Channel:ADAS @Message:0x15E
                                //@Signal:MapObj02HeiProblty
                                //@Channel:ADAS @Message:0x15F
                                //@Signal:MapObj03HeiProblty
                                //@Channel:ADAS @Message:0x160
                                //@Signal:MapObj04HeiProblty
                                //@Channel:ADAS @Message:0x161
                                //@Signal:MapObj05HeiProblty
                                //@Channel:ADAS @Message:0x162
                                //@Signal:MapObj06HeiProblty
                                //@Channel:ADAS @Message:0x163
                                //@Signal:MapObj07HeiProblty
                                //@Channel:ADAS @Message:0x164
                                //@Signal:MapObj08HeiProblty
                                //@Channel:ADAS @Message:0x165
                                //@Signal:MapObj09HeiProblty
                                //@Channel:ADAS @Message:0x15A
                                //@Signal:MapObj10HeiProblty
                                //@Channel:ADAS @Message:0x15B
                                //@Signal:MapObj11HeiProblty
                                //@Channel:ADAS @Message:0x15E
                                //@Signal:MapObj12HeiProblty
                                //@Channel:ADAS @Message:0x15F
                                //@Signal:MapObj13HeiProblty
                                //@Channel:ADAS @Message:0x160
                                //@Signal:MapObj14HeiProblty
                                //@Channel:ADAS @Message:0x161
                                //@Signal:MapObj15HeiProblty
                                //@Channel:ADAS @Message:0x162
                                //@Signal:MapObj16HeiProblty
                                //@Channel:ADAS @Message:0x163
                                //@Signal:MapObj17HeiProblty
                                //@Channel:ADAS @Message:0x164
                                //@Signal:MapObj18HeiProblty
                                //@Channel:ADAS @Message:0x165
                                //@Signal:MapObj19HeiProblty

  MapObjHei_e
      MapObjHeiBrake; //@Channel:ADAS @Message:0x15A @Signal:MapObj00HeiBrake
                      //@Channel:ADAS @Message:0x15B @Signal:MapObj01HeiBrake
                      //@Channel:ADAS @Message:0x15E @Signal:MapObj02HeiBrake
                      //@Channel:ADAS @Message:0x15F @Signal:MapObj03HeiBrake
                      //@Channel:ADAS @Message:0x160 @Signal:MapObj04HeiBrake
                      //@Channel:ADAS @Message:0x161 @Signal:MapObj05HeiBrake
                      //@Channel:ADAS @Message:0x162 @Signal:MapObj06HeiBrake
                      //@Channel:ADAS @Message:0x163 @Signal:MapObj07HeiBrake
                      //@Channel:ADAS @Message:0x164 @Signal:MapObj08HeiBrake
                      //@Channel:ADAS @Message:0x165 @Signal:MapObj09HeiBrake
                      //@Channel:ADAS @Message:0x15A @Signal:MapObj10HeiBrake
                      //@Channel:ADAS @Message:0x15B @Signal:MapObj11HeiBrake
                      //@Channel:ADAS @Message:0x15E @Signal:MapObj12HeiBrake
                      //@Channel:ADAS @Message:0x15F @Signal:MapObj13HeiBrake
                      //@Channel:ADAS @Message:0x160 @Signal:MapObj14HeiBrake
                      //@Channel:ADAS @Message:0x161 @Signal:MapObj15HeiBrake
                      //@Channel:ADAS @Message:0x162 @Signal:MapObj16HeiBrake
                      //@Channel:ADAS @Message:0x163 @Signal:MapObj17HeiBrake
                      //@Channel:ADAS @Message:0x164 @Signal:MapObj18HeiBrake
                      //@Channel:ADAS @Message:0x165 @Signal:MapObj19HeiBrake
};

struct ApaSdwType_s {
  unsigned int Dst[4]; // 0:Left 1:Middle Left 2:Middle Right 3:Right
};

struct UsRegnDstType {
  UsSnsrFltSt_e SnsrFltSt; //@Channel:ADAS @Message:0x28B @Signal:ReSnsrFltSt
                           //@Channel:ADAS @Message:0x28A @Signal:FrntSnsrFltSt

  unsigned int
      RegnDst[5]; // 0:Front
                  //@Channel:ADAS @Message:0x28A @Signal:FrntLeRegnDst
                  //@Channel:ADAS @Message:0x28A @Signal:FrntLeMidRegnDst
                  //@Channel:ADAS @Message:0x28A @Signal:FrntMidRegnDst
                  //@Channel:ADAS @Message:0x28A @Signal:FrntRiMidRegnDst
                  //@Channel:ADAS @Message:0x28A @Signal:FrntRiRegnDst
                  // 1:Rear
                  //@Channel:ADAS @Message:0x28B  @Signal:ReLeRegnDst
                  //@Channel:ADAS @Message:0x28B  @Signal:ReLeMidRegnDst
                  //@Channel:ADAS @Message:0x28B  @Signal:ReMidRegnDst
                  //@Channel:ADAS @Message:0x28B  @Signal:ReRiMidRegnDst
                  //@Channel:ADAS @Message:0x28B  @Signal:ReRiRegnDst
};
class VEHUPA {
private:
public:
  /* data */
  UsSDWSts_e SDWSts;           //@Channel:ADAS @Message:0xC4 @Signal:SDWSts
  APASts_e APASts;             //@Channel:ADAS @Message:0xC4 @Signal:APASts
  MapObjSts_e MapObjSts;       //@Channel:ADAS @Message:0xC4 @Signal:MapObjSts
  bool UpaSysDi;               //@Channel:ADAS @Message:0xC4 @Signal:UpaSysDi
  UpaSysSts_e UpaSysSts;       //@Channel:ADAS @Message:0xC4 @Signal:UpaSysSts
  bool UpaSysSrv;              //@Channel:ADAS @Message:0xC4 @Signal:UpaSysSrv
  USSlotInfo_s USSlot[6];      // 0~5 maximum 6 park lots
  MapObjBaseType_s MapObj[20]; // 0~19 maximum 20 objects
  ApaSdwType_s ApaSdw[2];      // 0:Front 1:Rear
                          //@Channel:ADAS @Message:0x1E8 @Signal:APA_SDWFLDst
                          //@Channel:ADAS @Message:0x1E8 @Signal:APA_SDWFMLDst
                          //@Channel:ADAS @Message:0x1E8 @Signal:APA_SDWFMRDst
                          //@Channel:ADAS @Message:0x1E8 @Signal:APA_SDWFRDst
                          //@Channel:ADAS @Message:0x1E7 @Signal:APA_SDWRLDst
                          //@Channel:ADAS @Message:0x1E7 @Signal:APA_SDWRMLDst
                          //@Channel:ADAS @Message:0x1E7 @Signal:APA_SDWRMRDst
                          //@Channel:ADAS @Message:0x1E7 @Signal:APA_SDWRRDst
  UsRegnDstType UsRegnDst[2]; // 0:Front 1:Rear
public:
  VEHUPA(/* args */);
  ~VEHUPA();
};
