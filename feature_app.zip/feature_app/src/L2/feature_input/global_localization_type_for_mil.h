#pragma once

#include <stdint.h>


class GlobalLocation {
 private:
 public:
  /* data */
  float confidence;

public:
  GlobalLocation(/* args */);
  ~GlobalLocation();
};
