#pragma once
#include "veh_enum_type.h"
#include <stdint.h>

enum class SwcSwSt_e {
  NotPrsd = 0,  // Not pressed
  Pressed = 1,  // Pressed
  Rsrvd2  = 2,  // Reserved
  InVld   = 3,  // Invalid
};
enum class IsaMod_e {
  Alert     = 0,  // Alert with display or sound
  CnfrmCtrl = 1,  // Control with confirmation
  Ctrl      = 2,  // Control without confirmation
  Rsrvd3    = 3,  // Reserved
};
enum class IsaOffset_e {
  Fixed  = 0,  // Fixed
  Prcntg = 1,  // Percentage
  Off    = 2,  // Off
  InVld  = 3,  // Invalid
};
enum class ISACnfrm_e {
  False  = 0,  // Not confirmed
  True   = 1,  // Confirmed
  Cncl   = 2,  // Cancelled
  Rsrvd3 = 3,  // Reserved
};
enum class SetIsa_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};

enum class FcwSet_e {
  Early  = 0,  // Early
  Normal = 1,  // Normal
  Late   = 2,  // Late
  Off    = 3,  // Off (reserved)
};
enum class HmaOnOff_e {
  Off    = 0,  // High Beam Assist (HMA) Off
  On     = 1,  // High Beam Assist (HMA) On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class NopLcCnfrmthd_e {
  TrnIndctr = 0,  // Confirmed by turn indicator switch
  Rsrvd1    = 1,  // Reserved
  NoNeed    = 2,  // No confirm
  Rsrvd3    = 3,  // Reserved
};
enum class SapaPrkMod_e {
  None   = 0,   // None
  Search = 1,   // Search
  PrllLe = 2,   // ParalleLeft
  PrllRi = 3,   // ParalleRight
  CrssLe = 4,   // CrossLeft
  CrssRi = 5,   // CrossRight
  PocLe  = 6,   // PocLeft
  PocRi  = 7,   // PocRight
  Abort  = 8,   // Abort
  Sna    = 9,   // Sna
  Resume = 10,  // Resume
  AnglLe = 11,  // AngleLeft
  AnglRi = 12,  // AngleRight
  OthrLe = 13,  // OtherLeft
  OthrRi = 14,  // OtherRight
  InVld  = 15,  // Invalid
};
enum class CdcFailSt_e {
  False  = 0,  // No failure
  True   = 1,  // Failure
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class FogLiSwtSt_e {
  Pressed = 0,  // Push switch not pressed
  NotPrsd = 1,  // Push switch pressed
  Rsrvd2  = 2,  // Reserved
  InVld   = 3,  // Invalid
};
enum class WiprSpdSet_e {
  Off    = 0,  // Reserved
  Lvl1   = 1,  // Intermediate speed 1
  lvl2   = 2,  // Intermediate speed 2
  lvl3   = 3,  // Intermediate speed 3
  lvl4   = 4,  // Intermediate speed 4
  Rsrvd5 = 5,  // Reserved
  Rsrvd6 = 6,  // Reserved
  InVld  = 7,  // Invalid
};
enum class WiprSwtSt_e {
  Off     = 0,  // Front wiper off
  LowSpd  = 1,  // Front wiper low speed
  HighSpd = 2,  // Front wiper high speed
  IntrSpd = 3,  // Front wiper intermediate speed
  OneTime = 4,  // Front wiper wipe one time
  Rsrvd5  = 5,  // Reserved
  Rsrvd6  = 6,  // Reserved
  InVld   = 7,  // Invalid
};
enum class HiBeamSwtSt_e {
  NoCmd   = 0,  // No command (Default position)
  Flash   = 1,  // Flash command
  LwOrHgh = 2,  // Low beam or high beam command
  InVLd   = 3,  // Invalid
};
enum class TrnIndcrSwSt_e {
  Default = 0,  // No turn indicator"
  Left    = 1,  // Turn indicator left"
  Right   = 2,  // Turn indicator right"
  InVld   = 3,  // Invalid"
};
enum class WiprAutoSwSt_e {
  NotPrsd = 0,  // Push switch not pressed"
  Pressed = 1,  // Push switch pressed"
  Rsrvd2  = 2,  // Reserved"
  InVld   = 3,  // Invalid"
};
enum class WshrReWiprSwtSt_e {
  Default  = 0,  // No command (default position)
  FrntWshr = 1,  // Front washer command
  RearWshr = 2,  // Rear washer command
  RearWipr = 3,  // Rear wiper command
  Rsrvd4   = 4,  // Reserved
  Rsrvd5   = 5,  // Reserved
  Rsrvd6   = 6,  // Reserved
  InVld    = 7,  // Invalid
};
enum class ScmFailSt_e {
  Nrml   = 1,  // Normal
  Fail   = 2,  // Fail
  Rsrvd2 = 3,  // Reserved
  InVld  = 4,  // Invalid
};
enum class FogLiCmd_e {
  Off    = 0,  // Fog light off
  FrntRr = 1,  // Fog light rear only
  Rr     = 2,  // Fog lights front and rear
  InVld  = 3,  // Invalid
};
enum class HiBmCmd_e {
  Low    = 0,  // Default (low beam)
  High   = 1,  // High beam
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class ReWiprCmd_e {
  Off    = 0,  // Rear wiper off
  On     = 1,  // Rear wiper on
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class SvcAvl_e {
  NotAvl = 0,  // Not available
  Avl    = 1,  // Available
  Rsrvd2 = 2,  // Reserved
  Rsrvd3 = 3,  // Reserved
};
enum class WtiDispSt_e {
  Off    = 0,  // No confirmation type from ADC
  LcReq  = 1,  // Display NOP Lane Change Request
  IsaReq = 2,  // Display ISA Speed Change Request
  Rsrvd3 = 3,  // Reserved
  Rsrvd4 = 4,  // Reserved
  Rsrvd5 = 5,  // Reserved
  Rsrvd6 = 6,  // Reserved
  Rsrvd7 = 7,  // Reserved
};
enum class NaviSpdUnit_e {
  unKnown = 0,  // Unknown
  kph     = 1,  // km/h
  Mph     = 2,  // mph
  Rsrvd3  = 3,  // Reserved
};
enum class NaviSpdLimSt_e {
  Unknown = 0,  // Unknown
  Exists  = 1,  // Exists (data available)
  NoLim   = 2,  // No limit (no limitation, e.g. Germany motor way)
  Plural  = 3,  // Plural data exsits
};
enum class NaviCrrntRd_e {
  Unknown    = 0,   // Unknown
  Ped        = 1,   // Pedestrian
  Local      = 2,   // Local
  LocalMajor = 3,   // Local major
  PrvncMajor = 4,   // Provincial major
  NtnlRoad   = 5,   // National road
  CityHw     = 6,   // City Highway
  HighWay    = 7,   // Highway
  Rsrvd8     = 8,   // Reserved
  Rsrvd9     = 9,   // Reserved
  Rsrvd10    = 10,  // Reserved
  Rsrvd11    = 11,  // Reserved
  Rsrvd12    = 12,  // Reserved
  Rsrvd13    = 13,  // Reserved
  Rsrvd14    = 14,  // Reserved
  Rsrvd15    = 15,  // Reserved
};

enum class TowModActv_e {
  kUndefined    = 0,
  kTowModInactv = 1,
  kTowModActv   = 2,
  kSigFlt       = 3,
};

enum class SetDA_StrAssType_e {
  kNoStrAss    = 0,  // No steering assist
  kWeakStrAss  = 1,  // Weak steering assist
  kStronStrAss = 2,  // Strong steering assist
  kInVld       = 3,  // Invalid
};

enum class SetSWFType_e {
  NoSpdWarn       = 0,  // No speed warning
  SpdWarnWithoSud = 1,  // Speed warning without sound
  SpdWarnWithSud  = 2,  // Speed warning with sound
  InVld           = 3,  // Invalid
};

enum class SetSpeedCtrlSts_e {
  ShrtAdjStep5kph = 0,  // short +/- 5 kph, long +/- 1 kph
  ShrtAdjStep1kph = 1,  // short +/- 1 kph, long +/- 5 kph
};

enum class CurveSpeedAssistSts_e {
  Off          = 0,
  Conservative = 1,
  Normal       = 2,
  Sporty       = 3,
};

enum SetDA_SetSpdOffs_e {
  SetDA_SetSpdOffs_Absolute = 0,  // absolute
  SetDA_NOPALC_Relative     = 1,  // relative

};

enum class VehAccrMod_e {
  kSoft       = 0,
  kEco        = 1,
  kComfort    = 2,
  kSport      = 3,
  kSportPlus  = 4,
  kRsrvd5     = 5,
  kRsrvd6     = 6,
  kInvld      = 7,
};
enum class Set360APType_e{
  Set360APType_NoLaneShift = 0,  //No lane shift
  Set360APType_LaneShift   = 1,  //Lane shift features on
};

enum class NOPtrainingType_e{
  NOPtrainingType_e_completed      = 0,  //training completed
  NOPtrainingType_e_notcompleted   = 1,  //training not completed
};

enum class VehEPModReq_e {
  None         = 0,
  Boost        = 1,
  Track        = 2,
  Drift        = 3,
  Professional = 4,
  Reserved_1   = 5,
  Reserved_2   = 6,
  Invalid      = 7,
};

struct StrWhlSwtchInfo_s {

  SwcSwSt_e AdUpSwtSts[5];  //@Channel:CHASSIS @Message:0x29F @Signal:SWCLe_UpPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_DwnPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_LePushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_RiPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_CentPushSwtSts
  SwcSwSt_e EnUpSwtSts[5];  //@Channel:CHASSIS @Message:0x29F @Signal:SWCLe_UpPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_DwnPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_LePushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_RiPushSwtSts
                            //@Channel:CHASSIS @Message:0x29e @Signal:SWCLe_CentPushSwtSts
};
struct ISACfgInfo_s {
  IsaMod_e     ISAAsstType;    //@Channel:ADAS @Message:0x2ED @Signal:ISAAsstType
  IsaOffset_e  ISAOffsetType;  //@Channel:ADAS @Message:0x2ED @Signal:ISAOffsetType
  ISACnfrm_e   ISASpdCmfResp;  //@Channel:ADAS @Message:0x2ED @Signal:ISASpdCmfResp
  SetIsa_e     SetISA;         //@Channel:ADAS @Message:0x2ED @Signal:SetISA
  unsigned int SetISAFixed;    //@Channel:ADAS @Message:0x2ED @Signal:SetISAFixed
  unsigned int SetISAPrcnt;    //@Channel:ADAS @Message:0x2ED @Signal:SetISAPercentage
};
struct AdFunCfgInfo_s {
  ISACfgInfo_s ISACfg;
  TauGap_e     ACCTauGapStored;           //@Channel:ADAS @Message:0x2A8 @Signal:ACCTauGapStored
  AdFunOnOff_e AEBOnOffReq;               //@Channel:ADAS @Message:0x2A8 @Signal:AEBOnOffReq
  AdFunOnOff_e DASTactileOnOff;           //@Channel:ADAS @Message:0x2A8 @Signal:DAS_TactileOnOff
  AdFunOnOff_e DrvAlertSysOnOff;          //@Channel:ADAS @Message:0x2A8
                                          //@Signal:DriverAlertSystemOnOff
  AdFunOnOff_e FCTAOnOffCmd;              //@Channel:ADAS @Message:0x2A8 @Signal:FCTAOnOffCmd
  FcwSet_e     FCWSetReq;                 //@Channel:ADAS @Message:0x2A8 @Signal:FCWSetReq
  GoNotifierSwitch_e GoNotifierOnOff;           //@Channel:ADAS @Message:0x2A8 @Signal:GoNotifierOnOff
  AdFunOnOff_e LnAssistTctlOnOff;         //@Channel:ADAS @Message:0x2A8
                                          //@Signal:LaneAssistTactileOnOff
  AdFunOnOff_e LCAOnOff;                  //@Channel:ADAS @Message:0x2A8 @Signal:LCAOnOff
  AdFunOnOff_e LCATctlWarnOnOff;          //@Channel:ADAS @Message:0x2A8
                                          //@Signal:LCATactileWarningOnOff
  AdFunOnOff_e    RCTAReq;                //@Channel:ADAS @Message:0x2A8 @Signal:RCTAReq
  HmaOnOff_e      SetHMA;                 //@Channel:ADAS @Message:0x2A8 @Signal:SetHMA
  LnAssistAid_e   SetLnAssiAidTyp;        //@Channel:ADAS @Message:0x2A8 @Signal:SetLaneAssiAidTyp
  LnAssistSnvty_e SetLaneAssiSnvty;       //@Channel:ADAS @Message:0x2A8 @Signal:SetLaneAssiSnvty
  AdFunOnOff_e    SetTSR;                 //@Channel:ADAS @Message:0x2A8 @Signal:SetTSR
  AdFunOnOff_e    TSRSpdLimOnOff;         //@Channel:ADAS @Message:0x2A8 @Signal:TSRSpdLimDataOnOff
  NopLcCnfrmthd_e NOPLcCnfrm;             //@Channel:ADAS @Message:0x2AD
                                          //@Signal:NOPLaneChngConfirmMethod
  LkaStrSprtLvl_e LKAStrSprtLvlSet;       //@Channel:ADAS @Message:0x2AD
                                          //@Signal:SetLKASteerSupportLvl
  LatCtrlEngage_e PilotLatCtrlEngageSet;  //@Channel:ADAS @Message:0x2AD
                                          //@Signal:SetPilotLatContAutoEngage
  bool         NOPEnable;                 //@Channel:ADAS @Message:0x2AD @Signal:NOPEnable
  AlcCnfrm_e   SetALC;                    //@Channel:ADAS @Message:0x2AD @Signal:SetALC
  AdFunOnOff_e RCTABReq;                  //@Channel:ADAS @Message:0x2AD @Signal:RCTABReq
  SapaPrkMod_e SAPAPrkgModReq;            //@Channel:CHASSIS @Message:0x1AF @Signal:SAPAPrkgModReq
  unsigned int CdcAdasFailSts;            //@Channel:ADAS @Message:0x2A8 @Signal:CDC_ADAS_FailSts
  CdcFailSt_e  CDCFailSts;                //@Channel:ADAS @Message:0x2A8 @Signal:CDC_FailSts
  AdFunOnOff_e SetDA_SpeedAssist;         //@Channel:ADAS @Message:0x255
                                          //@Signal:SetDA_SpeedAssist
  SetDA_StrAssType_e SetDA_SteerAssist;   //@Channel:ADAS @Message:0x255
                                          //@Signal:SetDA_SteerAssist
  SetSWFType_e SetSWF;                    //@Channel:ADAS @Message:0x255 @Signal:SetSWF
  SetSpeedCtrlSts_e SetSpeedCtrlSts;      //@Channel:ADAS @Message:0x255 @Signal:SetDA_SetSpeedCtrl
  CurveSpeedAssistSts_e CurveSpeedAssist; //@Channel:ADAS @Message:0x255 @Signal:SetDA_CurveSpeedAssist
  bool SetDA_PSP;                         //@Channel:ADAS @Message:0x255 @Signal:SetDA_PSP

};

class VEHDRVR {
 private:
 public:
  /* data */
  StrWhlSwtchInfo_s StrWhlSwtch;
  AdFunCfgInfo_s    AdFunCfg;
  FogLiSwtSt_e      FogLiPushSwtSts;   //@Channel:CHASSIS @Message:0x297 @Signal:FogLiPushSwtSts
  WiprSpdSet_e      FrntWiprInterSpd;  //@Channel:CHASSIS @Message:0x297
                                       //@Signal:FrntWiprInterSpd
  WiprSwtSt_e   FrntWiprSwtSts;        //@Channel:CHASSIS @Message:0x297 @Signal:FrntWiprSwtSts
  HiBeamSwtSt_e HiBeamSwtSts;          //@Channel:CHASSIS @Message:0x297
                                       //@Signal:HiLowBeamPushSwtSts
  TrnIndcrSwSt_e  TurnIndcrSwtSts;     //@Channel:CHASSIS @Message:0x297 @Signal:TurnIndcrSwtSts
  uint32_t        TurnIndcrSwtPos;     //@Channel:CHASSIS @Message:0x297 @Signal:TurnIndcrSwtPosition
  uint32_t        StalkType;           //@Channel:CHASSIS @Message:0x297 @Signal:StalkType
  WiprAutoSwSt_e  WiprAutoSwtSts;      //@Channel:CHASSIS @Message:0x297
                                       //@Signal:WiprAutModPushSwtSts
  WshrReWiprSwtSt_e WshrReWiprSwtSts;  //@Channel:CHASSIS @Message:0x297
                                       //@Signal:WshrAndReWiprPushSwtSts
  ScmFailSt_e    SCMFailSts;           //@Channel:CHASSIS @Message:0x297 @Signal:SCMFailSts
  FogLiCmd_e     FogLiSCMCmd;          //@Channel:ADAS @Message:0x2BC @Signal:FogLiSCMCmd
  HiBmCmd_e      HiBeamSCMCmd;         //@Channel:ADAS @Message:0x2BC @Signal:HiBeamSCMCmd
  ReWiprCmd_e    ReWiprSCMCmd;         //@Channel:ADAS @Message:0x2BC @Signal:ReWiprSCMCmd
  SvcAvl_e       SVCAvl;               //@Channel:ADAS @Message:0x2AD @Signal:CDC_SVC_Available
  unsigned int   NaviSpdLim;           //@Channel:ADAS @Message:0x2AD @Signal:NaviSpdLim
  WtiDispSt_e    WTIDispSt;            //@Channel:ADAS @Message:0x2AD @Signal:ADCWTIDisplaySts
  NaviSpdUnit_e  NaviSpdUnit;          //@Channel:ADAS @Message:0x2AD @Signal:NaviSpdLimUnit
  NaviSpdLimSt_e NaviSpdLimSts;        //@Channel:ADAS @Message:0x2AD @Signal:NaviSpdLimSts
  NaviCrrntRd_e  NaviCurrentRoadTyp;   //@Channel:ADAS @Message:0x2AD
                                       //@Signal:NaviCurrentRoadTyp
  unsigned int NavCtryCod;             //@Channel:ADAS @Message:0x2AD @Signal:NavCtryCod
  TowModActv_e TowModActv;             //@Channel:ADAS @Message:0x2AE @Signal:TowModActv
  bool         ELKSwtSts;              //@Channel:ADAS @Message:0x190 @Signal:ELKSwtSts

  bool         SwtichDA_NOP;              //@Channel:ADAS @Message:0x255 @Signal:SwtichDA_NOP
  SetDA_SetSpdOffs_e SetDA_SetSpdOffs;     //@Channel:ADAS @Message:0x255 @Signal:SetDA_SetSpdOffs
  int32_t           SetDA_SetSpdOffsValue;  //@Channel:ADAS @Message:0x255 @Signal:SetDA_SetSpdOffsValue
  VehAccrMod_e VehAccrMod;
  Set360APType_e Set360AP;             //@Channel:ADAS @Message:0x255 @Signal:Set360AP
  NOPtrainingType_e NOP_Training;             //@Channel:ADAS @Message:0x255 @Signal:NOPtraining
  uint32_t           VehSpdLimSts;            //@Channel:ADAS @Message:0x21E @Signal:VehSpdLimSts
  bool Aquila_OnOff;                        //@Channel:ADAS @Message:0x2AD @Signal:Aquila_OnOff

  VehEPModReq_e VehEPModReq;           //@Channel:CHASSIS @Message:0x1AF @Signal:VehEPModReq

 public:
  VEHDRVR(/* args */);
  ~VEHDRVR();
};
