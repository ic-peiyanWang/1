#pragma once

#include <stdint.h>

struct DmsFimInfo {
  bool DMSPhysicalLinkage_Error;  // 0: no fault, 1: has fault;
  bool DMS_License_NotAvailable;
  bool DMS_Function_NotAvailable;
  bool DMS_Camera_Occluded;
  bool DMS_No_Image_Recv;
};

struct FWAdcFimInfo {
  bool FIM_FWPhysicalLinkage_Error;
  bool FIM_FW_Camera_Failsafe_3;
  bool FIM_FW_Camera_Cal_Error;
  bool FIM_Windshield_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct FNAdcFimInfo {
  bool FIM_FNPhysicalLinkage_Error;
  bool FIM_FN_Camera_Failsafe_3;
  bool FIM_FN_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SideFLAdcFimInfo {
  bool FIM_SideFLPhysicalLinkage_Error;
  bool FIM_FL_Camera_Failsafe_3;
  bool FIM_FL_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SideFRAdcFimInfo {
  bool FIM_SideFRPhysicalLinkage_Error;
  bool FIM_FR_Camera_Failsafe_3;
  bool FIM_FR_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SideRLAdcFimInfo {
  bool FIM_SideRLPhysicalLinkage_Error;
  bool FIM_RL_Camera_Failsafe_3;
  bool FIM_RL_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SideRRAdcFimInfo {
  bool FIM_SideRRPhysicalLinkage_Error;
  bool FIM_RR_Camera_Failsafe_3;
  bool FIM_RR_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct RNAdcFimInfo {
  bool FIM_RNPhysicalLinkage_Error;
  bool FIM_RN_Camera_Failsafe_3;
  bool FIM_RN_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SVCFrontAdcFimInfo{
  bool FIM_SVCFrontPhysicalLinkage_Error;
  bool FIM_SVCFront_Camera_Failsafe_3;
  bool FIM_SVCFront_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SVCLeftAdcFimInfo{
  bool FIM_SVCLeftPhysicalLinkage_Error;
  bool FIM_SVCLeft_Camera_Failsafe_3;
  bool FIM_SVCLeft_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SVCRearAdcFimInfo{
  bool FIM_SVCRearPhysicalLinkage_Error;
  bool FIM_SVCRear_Camera_Failsafe_3;
  bool FIM_SVCRear_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

struct SVCRightAdcFimInfo{
  bool FIM_SVCRightPhysicalLinkage_Error;
  bool FIM_SVCRight_Camera_Failsafe_3;
  bool FIM_SVCRight_Camera_Cal_Error;
  // 0: no fault, 1: has fault;
};

class CAMFIMINFO {

 public:
  DmsFimInfo   dms_fim_info;
  FWAdcFimInfo fw_adc_fim_info;
  FNAdcFimInfo fn_adc_fim_info;
  SideFLAdcFimInfo sidefl_adc_fim_info;
  SideFRAdcFimInfo sidefr_adc_fim_info;
  SideRLAdcFimInfo siderl_adc_fim_info;
  SideRRAdcFimInfo siderr_adc_fim_info;
  RNAdcFimInfo rn_adc_fim_info;
  SVCFrontAdcFimInfo svcfront_adc_fim_info;
  SVCLeftAdcFimInfo svcleft_adc_fim_info;
  SVCRearAdcFimInfo svcrear_adc_fim_info;
  SVCRightAdcFimInfo svcright_adc_fim_info;

  CAMFIMINFO();
  ~CAMFIMINFO();
};