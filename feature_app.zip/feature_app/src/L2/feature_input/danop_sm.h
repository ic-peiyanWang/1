#pragma once
#include <stdint.h>

enum class NOP_Status_e : uint8_t {
  NOPStatus_NotAvaliable = 0,
  NOPStatus_Avaliable = 1,
  NOPStatus_RequestUrban = 2,
  NOPStatus_RequestPSP = 3,
};

enum class Urban_Status_e : uint8_t {
  UrbanStatus_NotAvaliable = 0,
  UrbanStatus_Avaliable    = 1,
  UrbanStatus_RequestNOP = 2,
  UrbanStatus_RequestPSP   = 3,
};

enum class NOP_FunctionRequest : uint8_t{
  FuncReq_NoneRequest = 0,
  FuncReq_NPLongAndLatCtrlActv = 1,
  FuncReq_NPLongCtrlOnly = 2,
  FuncReq_PilotStandby = 3,
  FuncReq_SysPsvAndEAS = 4,
  FuncReq_SysPsvAndMRM = 5,
  FuncReq_SysPsv = 6,
};

enum class PwrSwapProc_e : uint8_t {
  No_action = 0,
  PSAP = 1,
  Authen = 2,
  Info_match = 3,
  Vehicle_prepare = 4,
  Swap_prepare = 5,
  Swap_HV_battery = 6,
  Diagnose = 7,
  New_battery_info_match = 8,
  Exit_PS = 9,
  Reserved = 10,
};

enum class PSAPParkViewStatus_e : uint8_t {
  PSAPParkView_Off = 0,
  PSAPParkView_Activated = 1,
  PSAPParkView_Reserved1 = 2,
  PSAPParkView_Reserved2 = 3,
};

struct HardInhibitFlg {
  bool is_crossing_hard_inhibit_flg;
};

struct OneOrinSignals {
  bool is_open_one_orin_func;
  bool is_apps_status_actptr_flg;
};

struct DaInhibit_e {
  uint32_t m_uBitNPAdInhibitTrigger;
  uint32_t m_uBitNPTdInhibitTrigger;
  uint32_t m_uBitNPEasInhibitTrigger;
  uint32_t m_uBitNPHardInhibitTrigger;
};

class DANOPSM {
  // private:
public:
  /* data */
  uint8_t sub_function_type;
  uint8_t psp_status;
  bool nop_plus_subscribe_avail;
  bool nop_activation_trigger;
  bool nop_deactivation_trigger;
  NOP_Status_e nop_status;
  Urban_Status_e urban_status;
  bool np_activation_prevention;
  NOP_FunctionRequest nop_functionReq;
  int32_t is_in_map_area;
  uint8_t psp_status_dawti;
  bool is_nop_control_status;
  bool is_nop_trans_to_psp_failed;
  uint8_t psp_task_status;
  uint8_t psp_task_result;
  uint8_t priority_road_class;
  uint8_t distance_to_next_ramp;
  bool nop_takeover_req;
  bool nop_path_quality_check_result; //failed-false; success-true
  bool is_psp_area;
  uint8_t da_nad_avl;
  uint8_t da_nop_avl;
  bool is_lccplus_available_flg;
  bool is_nop_available_flg;
  bool is_psp_available_flg;
  bool is_in_risk_scenario_flg;
  bool is_nop_planner_status;
  bool is_in_toll_station_flg;
  bool is_path_collision_risk_flg;
  bool is_psap_active_flg;
  PwrSwapProc_e pwr_swap_proc;
  PSAPParkViewStatus_e psap_park_view_status;
  HardInhibitFlg hard_inhibit_flg;
  bool abnormal_path_trigger_inhibit_flg;
  uint8_t odd_scenario;
  OneOrinSignals one_orin_signals;
  bool is_lane_risk_scenario_flg;
  bool is_in_uturn_scenario_flg;
  DaInhibit_e da_inhibit_input;
  bool is_in_emergency_flg;
  bool is_freeze_hod_timer_req_flg;
  uint32_t m_uBitNPActPreTrigger;
  bool is_steer_override;

public:
  DANOPSM(/* args */);
  ~DANOPSM();
};