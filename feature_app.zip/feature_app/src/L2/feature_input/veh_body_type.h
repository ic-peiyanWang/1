#pragma once
#include "veh_enum_type.h"
#include <stdint.h>
enum class VehSt_e {
  Park     = 0,  // Parked vehicle(Off)
  DrvPrsnt = 1,   // Driver present(On)
  Driving  = 2,   // Driving
  SwUpdt   = 3,   // Software update
  Rsrvd3   = 4,   // Reserved
  Rsrvd4   = 5,   // Reserved
  Rsrvd5   = 6,   // Reserved
  Rsrvd6   = 7,   // Reserved
  Rsrvd7   = 8,   // Reserved
  Rsrvd8   = 9,   // Reserved
  Rsrvd9   = 10,  // Reserved
  Rsrvd10  = 11,  // Reserved
  Rsrvd11  = 12,  // Reserved
  Rsrvd12  = 13,  // Reserved
  Rsrvd13  = 14,  // Reserved
  InVld    = 15,  // Invalid
};
enum class VehMode_e {
  NotUsd0    = 0,   // Not used
  Production = 1,   // Production
  Transprot  = 2,   // Transport
  ShowRoom   = 3,   // Showroom
  Regular    = 4,   // Regular
  Driverless = 5,   // Driverless
  Rsvrd6     = 6,   // Reserved
  Rsvrd7     = 7,   // Reserved
  Rsvrd8     = 8,   // Reserved
  Rsvrd9     = 9,   // Reserved
  Rsvrd10    = 10,  // Reserved
  Rsvrd11    = 11,  // Reserved
  Rsvrd12    = 12,  // Reserved
  Rsvrd13    = 13,  // Reserved
  NotUsd14   = 14,  // Not used
  InVld      = 15,  // Invalid
};
enum class DoorAjarSts_e {
  Opened = 0,  // Opened
  Closed = 1,  // Closed
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class SeatOcupSt_e {
  False  = 0,  // No occupant
  True   = 1,  // Occupant
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class FogLiSt_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class BeamSt_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class HzrdLiSts_e {
  Off   = 0,  // Off
  Hzrd  = 1,  // On 1.25 Hz (Hazard)
  Alarm = 2,  // On 1 Hz (Alarm flash)
  InVld = 3,  // Invalid
};
enum class TurnLiSt_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class MirrLiSt_e {
  Off   = 0,  // Off
  On    = 1,  // On
  Flash = 2,  // Flash
  Fail  = 3,  // Failure
};
enum class WiprSt_e {
  Off    = 0,  // Front wiper
  LowSpd = 1,  // Front wiper low speed
  HiSpd  = 2,  // Front wiper high speed
  Rsrvd3 = 3,  // Reserved
  Rsrvd4 = 4,  // Reserved
  Rsrvd5 = 5,  // Reserved
  Rsrvd6 = 6,  // Reserved
  InVld  = 7,  // Invalid
};
enum class WiprPrkSt_e {
  True   = 0,  // Park
  False  = 1,  // No Park
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};
enum class CenLockSts_e {
  False  = 0,  // Vehicle unlocked
  Full   = 1,  // Vehicle fully locked
  Door   = 2,  // Driver door unlock only
  Rsrvd3 = 3,  // Reserved
  Rsrvd4 = 4,  // Reserved
  Rsrvd5 = 5,  // Reserved
  Rsrvd6 = 6,  // Reserved
  InVld  = 7,  // Invalid
};
enum class TpmsSt_e {
  OK         = 0,  // System OK
  NotOk      = 1,  // System Not OK
  PresAbnrml = 2,  // Pressure abnormal
  Rsrvd3     = 3,  // Reserved
};
enum class DrvSt_e {
  Unknown = 0,  // Unknown
  None    = 1,  // None
  MD      = 2,  // MD
  RD      = 3,  // RD
  AD      = 4,  // AD
  Rsrvd5  = 5,  // Reserved
  Rsrvd6  = 6,  // Reserved
  InVld   = 7,  // Invalid
};

enum class NbsMov_e {
  NoReq    = 0,  // No Request
  Fordward = 1,  // Move Forward
  BackWard = 2,  // Move Backward
  InVld    = 3,  // Invalid
};

enum class NbsReq_e {
  Off    = 0,  // No Request
  On     = 1,  // Request
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};

enum class TrlrMod_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd3 = 2,  // Reserved
  Rsrvd4 = 3,  // Reserved
};

enum class SwcAdjMod_e {
  Normal    = 0,  // Normal Mode (default)
  Mirror    = 1,  // Mirror Adjust mode
  StrColumn = 2,  // Steering column mode
  Rsrvd3    = 3,  // Reserved
  Rsrvd4    = 4,  // Reserved
  Rsrvd5    = 5,  // Reserved
  Rsrvd6    = 6,  // Reserved
  InVld     = 7,  // Invalid
};

enum class NbsDrvSt_e {
  NoAct  = 0,  // No action
  TkOvr  = 1,  // Driver take over
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};

enum class PrkSys_e {
  None   = 0,  // No parkingtype request
  APA    = 1,  // APA
  SAPA   = 2,  // SAPA
  Rsrvd3 = 3,  // Reserved
};

enum class MnLiSt_e {
  Off       = 0,  // Light off
  Pstn      = 1,  // Position light
  LowBm     = 2,  // Low Beam
  Auto      = 3,  // Automatic
  Rsrvd4    = 4,  // Reserved
  Rsrvd5    = 5,  // Reserved
  SigNotAvl = 6,  // Signal not available
  InVld     = 7,  // Invalid
};

enum class ReqZeroAsOn_e {
  On  = 0,  // On
  Off = 1,  // Off
};

struct VehStatusInfo_s {
  VehSt_e   VehState;      //@Channel:CHASSIS @Message:0x2C3 @Signal:VehState
  VehSt_e   VehStateASIL;  //@Channel:CHASSIS @Message:0x10C @Signal:VehState_ASIL
  VehMode_e VehMode;       //@Channel:CHASSIS @Message:0x10C @Signal:VehMode
};

struct DoorInfo_s {
  DoorAjarSts_e DoorAjarSts[4];  //@Channel:CHASSIS @Message:0x2BD @Signal:DoorAjarFrntLeSts
                                 //@Channel:CHASSIS @Message:0x2BD @Signal:DoorAjarFrntRiSts
                                 //@Channel:CHASSIS @Message:0x2BD @Signal:DoorAjarReLeSts
                                 //@Channel:CHASSIS @Message:0x2BD @Signal:DoorAjarReRiSts
  unsigned int HoodAjarSts;
  unsigned int TrAjarSts;
};

struct LightsInfo_s {
  FogLiSt_e FogLiSts[2];  //@Channel:ADAS @Message:0x2C0 @Signal:FogLiFrntSts
                          //@Channel:ADAS @Message:0x2C0 @Signal:FogLiReSts
  BeamSt_e BeamSts[2];    //@Channel:ADAS @Message:0x2C0 @Signal:HiBeamSts
                          //@Channel:ADAS @Message:0x2C0 @Signal:LoBeamSts

  HzrdLiSts_e HzrdWarnSts;  //@Channel:ADAS @Message:0x2C0 @Signal:HzrdWarnSts

  TurnLiSt_e TurnIndcrLiSts[2];  //@Channel:ADAS @Message:0x2C0 @Signal:LeTurnIndcrLiSts
                                 //@Channel:ADAS @Message:0x2C0 @Signal:RiTurnIndcrLiSts

  MirrLiSt_e MirrLigtSts[2];  //@Channel:ADAS @Message:0x2C2 @Signal:MirrLigtLeSts
                              //@Channel:ADAS @Message:0x2C2 @Signal:MirrLigtRiSts

  bool LgtErrBrkLi[5];  //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrBrkLiReLeSide
                        //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrBrkLiReLeMid
                        //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrBrkLiTop
                        //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrBrkLiReRiMid
                        //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrBrkLiReRiSide

  bool LgtErrTurnIndcn[6];  //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnFrntLe
                            //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnFrntRi
                            //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnReLeSide
                            //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnReLeMid
                            //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnReRiMid
                            //@Channel:CHASSIS @Message:0x3A5 @Signal:LgtErrTurnIndcnReRiSide

  FogLiSt_e FogLiFctActvSts[2];  //@Channel:CHASSIS @Message:0x2FC @Signal:FogLiFrntFctActvSts
                                 //@Channel:CHASSIS @Message:0x2FC @Signal:FogLiReFctActvSts

  unsigned int LiSnsrData;          //@Channel:ADAS @Message:0x2C1 @Signal:LiSnsrData
  bool         LiSnsrFailSts;       //@Channel:ADAS @Message:0x2C1 @Signal:LiSnsrFailSts
  bool         DowWarnAmbLeSts[2];  //@Channel:ADAS @Message:0x2C1 @Signal:DowWarnAmbLeSts
                                    //@Channel:ADAS @Message:0x2C1 @Signal:DowWarnAmbRiSts
};

struct WipperInfo_s {

  WiprSt_e FrntWiprSts;  //@Channel:ADAS @Message:0x2C2 @Signal:FrntWiprSts

  WiprPrkSt_e FrntWiperParkSts;  //@Channel:ADAS @Message:0x2C2 @Signal:FrntWiperParkSts
};
struct TimingInfo_s {
  unsigned int Yr  = 1;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Yr
  unsigned int Mth = 2;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Mth
  unsigned int Day = 3;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Day
  unsigned int Hr  = 4;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Hr
  unsigned int Min = 5;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Min
  unsigned int Sec = 6;  //@Channel:CHASSIS @Message:0x3B2 @Signal:Sec
};
struct CDCEqpmtInfo_s {
  bool AUDIOsts = 1;  //@Channel:ADAS @Message:0x255 @Signal:CDC_AUDIOsts
  bool HUDsts   = 2;  //@Channel:ADAS @Message:0x255 @Signal:CDC_HUDsts
  bool ICSsts   = 3;  //@Channel:ADAS @Message:0x255 @Signal:CDC_ICSsts
  bool ICsts    = 4;  //@Channel:ADAS @Message:0x255 @Signal:CDC_ICsts
};
class VEHBODY {
 private:
 public:
  /* data */
  VehStatusInfo_s VehStatus;

  DoorInfo_s Door;

  SeatOcupSt_e SeatOccpSts[7];  //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpFrntLeSts :
                                // SeatOccpFrntLeFail;
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccptFrntRiSts
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpt2ndLeSts
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpt2ndMidSts
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpt2ndRiSts
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpt3rdLeSts
                                //@Channel:CHASSIS @Message:0x2BD @Signal:SeatOccpt3rdRiSts

  unsigned int SeatBltSts[7];  //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltFrntLeSts
                               //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltFrntRiSts
                               //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltMidRowLeSts
                               //@Channel:CHASSIS @Message:0x3C
                               //@Signal:SeatBltMidRowMidSts
                               //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltMidRowRiSts
                               //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltReRowLeSts
                               //@Channel:CHASSIS @Message:0x3C @Signal:SeatBltReRowRiSts

  LightsInfo_s LightSts;

  WipperInfo_s WipperSts;

  TimingInfo_s Time;

  CenLockSts_e CenLockSts;  //@Channel:CHASSIS @Message:0x1B0 @Signal:CenLockUnlockSts

  TpmsSt_e TpmsSts;  //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsSts

  DrvSt_e DrvState;  //@Channel:CHASSIS @Message:0x10C @Signal:DrvState

  NbsMov_e NBSMovReq;  //@Channel:CHASSIS @Message:0x10C @Signal:NBSMovReq

  NbsReq_e NBSReq;        //@Channel:CHASSIS @Message:0x10C @Signal:NBSReq
  bool     AmbTempValid;  //@Channel:CHASSIS @Message:0x314 @Signal:AmbTempValid
  float    AmbTemp;       //@Channel:CHASSIS @Message:0x314 @Signal:AmbTemp

  TrlrMod_e TrailerModReq;  //@Channel:CHASSIS @Message:0x2EE @Signal:TrailerModReq

  SwcAdjMod_e SWCAdjModReq;  //@Channel:CHASSIS @Message:0x2AE @Signal:SWCAdjModReq

  NbsDrvSt_e NBSDrvrSts;  //@Channel:CHASSIS @Message:0x1AF @Signal:NBSDrvrSts

  PrkSys_e PrkgTyp;       //@Channel:CHASSIS @Message:0x1AF @Signal:PrkgTyp
  bool     CrashDetd;     //@Channel:CHASSIS @Message:0x3C  @Signal:CrashDetd
  bool     KeyInZnSt[3];  //@Channel:ADAS    @Message:0x3A0 @Signal:KeyInZOne
                          //@Channel:ADAS    @Message:0x3A0 @Signal:KeyInZTwo
                          //@Channel:ADAS    @Message:0x3A0 @Signal:KeyInZThree

  bool        AdsLampReq;   //@Channel:ADAS @Message:0x310 @Signal:CCU_AdsLampReq
  float       IntrTemp;     //@Channel:ADAS @Message:0x312 @Signal:IntrTemp
  QfZeroVld_e IntrTempVld;  //@Channel:ADAS @Message:0x312 @Signal:IntrTempValid

  MnLiSt_e MaiLiSet;  //@Channel:ADAS @Message:0x2AC @Signal:MaiLiSet

  ReqZeroAsOn_e       SDWReq;             //@Channel:ADAS @Message:0x2AE @Signal:SDWReq
  ReqZeroAsOn_e       UPAReq;             //@Channel:ADAS @Message:0x2AE @Signal:UPAReq
  bool                ECOPlusModSts;      //@Channel:ADAS @Message:0x2AE @Signal:ECOPlusModSts
  CDCEqpmtInfo_s      CDCEqpmtSts;
  bool                HeadLampsOn;    //@Channel:ADAS @Message:0x2C1 @Signal:HeadLampsOn
  bool                VehSpdMaxLimOnOff;  //@Channel:CHASSIS @Message:0x2EE @Signal:VehSpdMaxLimOnOff

 public:
  VEHBODY(/* args */);
  ~VEHBODY();
};
