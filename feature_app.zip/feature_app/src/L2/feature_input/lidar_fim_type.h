#pragma once

#include <stdint.h>

class LIDARFIMINFO {
 private:
 public:
  bool   FIM_Lidar_Cal_Error;

 public:
  LIDARFIMINFO();
  ~LIDARFIMINFO();
};