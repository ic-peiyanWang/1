#pragma once
#include <stdint.h>

enum class TaskState_e {
  FINISH                = 0,
  NAV_TO_QUEUE_AREA     = 1,
  NAV_TO_PSAP_LOC_BOX   = 2,
  IN_QUEUE_AREA         = 3,
  IN_PSAP_LOC_BOX       = 4,
  ON_POWER_SWAP_PARKING = 5,
  ON_POWER_SWAPING      = 6,
  NAV_TO_HIGHWAY        = 7,
};

class NopPowerPilotState {
 private:
 public:
  /* data */
  TaskState_e nop_task_state;

 public:
  NopPowerPilotState(/* args */);
  ~NopPowerPilotState();
};