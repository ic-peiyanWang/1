#pragma once
struct vision_flg_s
{
    bool HLB_decision;/* data */
};
