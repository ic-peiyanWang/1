#pragma once
#include "veh_enum_type.h"
enum class VehMovDir_e{
    Stst     = 0, //Standstill
    ForWard  = 1, //Forward
    BackWard = 2, //Backward
    InVld    = 3, //Invalid
};
enum class ImuCalSt_e{
    False  = 0, //Not Calibrated
    True   = 1, //Calibrated
    Rsrvd2 = 2, //Reserved
    NotAvl = 3, //Signal not available
};
enum class ImuSigalSt_e{
    Valid = 0, //Normal (Valid) 
    InVld = 1, //Invalid
    Rsrvd2= 2, //Reserved
    Init  = 3, //Initializing
};

struct VehSpdInfo_s{
	 QfZeroVld_e VehSpdSts;           //@Channel:CHASSIS @Message:0x5B @Signal:VehSpdSts
	 VehMovDir_e VehMovgDir;        //@Channel:CHASSIS @Message:0x5B @Signal:VehMovgDir
	 float  VehSpdkph;                  //@Channel:CHASSIS @Message:0x5B @Signal:VehSpd
	 float  VehSpdmps;      
     float  VehFiltLngAcc;   
	 QfZeroVld_e VehSpdASILDSts;      //@Channel:CHASSIS @Message:0x5F @Signal:VehSpdSts_ASILD
	 float  VehSpdASILD;	            //@Channel:CHASSIS @Message:0x5F @Signal:VehSpd_ASILD
	 float  VehDispSpd;		            //@Channel:CHASSIS @Message:0x2E1 @Signal:VehDispdSpd
	 //速度单位 0-kph 1-mph 
	 bool VehDispdSpdUnit;  //@Channel:ADAS @Message:0x155 @Signal:CDC_VehDispdSpdUnit
};

class VEHDYN
{
private:
public:
    /* data */
	VehSpdInfo_s VehSpd;
	ImuCalSt_e AxAyYrsCalSts; 	        //@Channel:CHASSIS @Message:0x3E @Signal:AxAyYrsCalSts
	ImuSigalSt_e LgtASts;		        //@Channel:CHASSIS @Message:0x3E @Signal:LgtAValSts
	float  LgtAg;			            //@Channel:CHASSIS @Message:0x3E @Signal:LgtA @Comment:LgtA
	float  LgtAmpss;		            //LgtA/9.81
	ImuSigalSt_e LatASts;		        //@Channel:CHASSIS @Message:0x3E @Signal:LatAValSts
	float  LatAg;			            //@Channel:CHASSIS @Message:0x3E @Signal:LatA @Comment:LatA*1
	float  LatAmpss;		            //LatA/9.81
	ImuSigalSt_e YawRateSts;		    //@Channel:CHASSIS @Message:0x3E @Signal:YawRateValSts
	float  YawRateRps;	                //YawRate*3.14159/180
	float  YawRateDps;	                //@Channel:CHASSIS @Message:0x3E @Signal:YawRate @Comment:YawRate*1
	float  dYawRateDpss;
	float  VehOdom;		                //@Channel:CHASSIS @Message:0x3AA @Signal:VehOdometer    
public:
    VEHDYN(/* args */);
    ~VEHDYN();
};


