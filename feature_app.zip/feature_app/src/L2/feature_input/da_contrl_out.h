#pragma once

#include <stdint.h>

class DAContrlOut {
  // private:
 public:
  /* data */
  bool             drive_off_req;
  uint32_t         da_hod_sprs;
  uint32_t         st_hzrdlireq;
  uint32_t         st_hodst;
  uint32_t         da_nop_avl;
  uint32_t         st_longintvtype;
  uint32_t         st_longintvst;
  uint32_t         st_hodwarnst;
  bool             da_flglkssprs;
  uint32_t         da_bflkssprs;
  bool             nop_flglkssprs;
  bool             flgEDALatSprs;
  bool             da_strongsteering;
  uint32_t         da_alertlvl;
  uint32_t         st_hodwarnseqarb;
  uint32_t         setspddisp;


 public:
  DAContrlOut(/* args */);
  ~DAContrlOut();
};