#pragma once

#include <stdint.h>

class NopChassisControl {
  // private:
 public:
  /* data */
  float     nop_pinion_angle_request;
  bool      nop_vlc_drive_off_req;
  uint32_t  TarGear;
  float     LON_parking_target_speed_ms;
  float     LON_parking_stop_distance_cm;
  uint32_t  LON_ctrl_mode;
  uint32_t  psp_control_mode_request;

 public:
  NopChassisControl(/* args */);
  ~NopChassisControl();
};