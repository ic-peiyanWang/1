#pragma once


class  LIDARFAULTINFO{
  // private:
 public:
  /* data */
  bool INNO_LIDAR_IN_FAULT_WINDOW_BLOCKAGE1;
  bool INNO_LIDAR_TEMPHIGH_INHIBIT;

 public:
  LIDARFAULTINFO(/* args */);
  ~LIDARFAULTINFO();
};