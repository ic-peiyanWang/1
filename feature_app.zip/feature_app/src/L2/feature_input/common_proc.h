
#pragma once
#include <stdint.h>

class CommonProc_Info {
 private:
 public:
  /* speed controller */
  uint32_t sas_speed_limit_c_value = 0;
  uint32_t sas_speed_limit_c_id = 0;
  uint32_t sas_speed_limit_out_value = 0;
  bool     sas_speed_limit_out_valid = false;
  uint32_t sas_speed_limit_out_id = 0;
  uint32_t iacc_speed_limit_out_value = 0;
  bool iacc_speed_limit_out_valid = false;
  uint32_t sas_sldf_state = 0;
  uint32_t sas_sup_sign_type = 0;
  uint32_t user_set_speed = 0;
  uint32_t user_set_speed_out = 0;
  uint32_t speed_unit = 0;
  bool     disp_set_speed_enable = false;
  uint32_t iacc_take_over_pop = 0;
  bool     rain_mode = false;
  bool     use_next_spdlmt = false;
  uint32_t set_spd_animation = 0;
  uint8_t  setspeed_decel_mode = 0; // 0: No 1:RainMode 2:Construction Deceleration
  /*tau gap*/
  uint8_t tau_gap_setting = 5;
  uint8_t tau_gap_change_disp = 0;
  uint8_t sas_speed_limit_out_value_trans = 0;
  uint8_t max_set_speed = 130;

 public:
  CommonProc_Info(/* args */);
  ~CommonProc_Info();
};
