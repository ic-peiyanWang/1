#pragma once

#include <stdint.h>

enum class FunctionStatus_e {
  Off      = 0,  // request to unload function app // not in BL07X
  Loaded   = 1,  // request to load function app into RAM, but do not execute it
  Checking = 2,  // request to execution of app
  Sandby   = 3,  // request function to go standby
  Running  = 4,  // request function to run
};

class NopFunctionstatus {
  // private:
 public:
  /* data */
  // FunctionStatus_e nop_function_status_nop_sts;
  int nop_ReqFunctionID;
  bool nop_oe_end_instant_off;

 public:
  NopFunctionstatus(/* args */);
  ~NopFunctionstatus();
};