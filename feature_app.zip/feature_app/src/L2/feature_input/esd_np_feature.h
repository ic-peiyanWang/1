#pragma once
#include <stdint.h>

constexpr int kNumEsdNopPathNum = 80;

struct EsdNopPath {
  float x[kNumEsdNopPathNum] = {0};
  float y[kNumEsdNopPathNum] = {0};
};

class EsdNpFeature {
 private:
 public:
  /* data */
  EsdNopPath esd_nop_path;
  uint32_t esd_in_PowerStation;

 public:
  EsdNpFeature(/* args */);
  ~EsdNpFeature();
};
