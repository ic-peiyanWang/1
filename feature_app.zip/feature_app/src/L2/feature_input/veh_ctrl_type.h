#pragma once
enum class LlcFctSt_e {
  Init    = 0,  // Init
  Stdby   = 1,  // Standby
  Actv    = 2,  // Active
  Intrptn = 3,  // Interruption
  ErrOr   = 4,  // Error
  Rsrvd5  = 5,  // Reserved
  Rsrvd6  = 6,  // Reserved
  Rsrvd7  = 7,  // Reserved
};
enum class LlcIntrptErr_e {
  NoErr       = 0,   // No interruption/error
  VehBlock    = 1,   // Vehicle block
  EpbIntrvntn = 2,   // Unexpected EPB intervention
  Override    = 3,   // Override
  FailByEpb   = 4,   // Fail to apply EPB
  LlcErr      = 5,   // LLC error
  Rsrvd6      = 6,   // Reserved
  Rsrvd7      = 7,   // Reserved
  Rsrvd8      = 8,   // Reserved
  Rsrvd9      = 9,   // Reserved
  Rsrvd10     = 10,  // Reserved
  Rsrvd11     = 11,  // Reserved
  Rsrvd12     = 12,  // Reserved
  Rsrvd13     = 13,  // Reserved
  Rsrvd14     = 14,  // Reserved
  Rsrvd15     = 15,  // Reserved
};
enum class AdtSt_e {
  Off    = 0,  // Off
  Stdby  = 1,  // Standby
  Actv   = 2,  // Active
  Rsrvd3 = 3,  // Reserved
  Rsrvd4 = 4,  // Reserved
  Rsrvd5 = 5,  // Reserved
  Rsrvd6 = 6,  // Reserved
  Rsrvd7 = 7,  // Reserved
};

enum class CruiseCtrlMod_e {
  CruiseCtrl_NoReq   = 0,  // Cruise control No request
  CruiseCtrl_Inc     = 1,  // Cruise control Increase
  CruiseCtrl_IncFast = 2,  // Cruise control Increase Fast
  CruiseCtrl_Dec     = 3,  // Cruise control Decrease
  CruiseCtrl_DecFast = 4,  // Cruise control Decrease Fast
  CruiseCtrl_Set     = 5,  // Cruise control Set
  CruiseCtrl_Resume  = 6,  // Cruise control Resume
};

enum class VMCBrkOvrd_e {
  VMCBrkOvrd_not_override = 0,
  VMCBrkOvrd_override     = 1,
};

enum class StrActvIf_e {
  InActv    = 0,   // No active request
  AdOvrL    = 1,   // act. [ADC]ACI (overlay) request
  AdOvrD    = 2,   // act. [ADC]ACI (override) request
  AdOvrLHvi = 3,   // act. [ADC]ACI (overlay) & HVI requests
  AdOvrDHvi = 4,   // act. [ADC]ACI (override) & HVI requests
  AdHvi     = 5,   // act. [ADC]HVI request
  AdCti     = 6,   // act. [ADC]CTI request
  VmOvrL    = 7,   // act. [VMC]ACI (overlay) request
  VmOvrD    = 8,   // act. [VMC]ACI (override) request
  VmOvrLHvi = 9,   // act. [VMC]ACI (overlay) & HVI requests
  VmOvrDHvi = 10,  // act. [VMC]ACI (override) & HVI requests
  VmHvi     = 11,  // act. [VMC]HVI request
  VmCti     = 12,  // act. [VMC]CTI request
  BcCti     = 13,  // act. [BCU]CTI request
  VmMti     = 14,  // act. [VMC]MTI request
  Rsrvd15   = 15,  // Reserved
  Rsrvd16   = 16,  // Reserved
  Rsrvd17   = 17,  // Reserved
  Rsrvd18   = 18,  // Reserved
  Rsrvd19   = 19,  // Reserved
  Rsrvd20   = 20,  // Reserved
  Rsrvd21   = 21,  // Reserved
  Rsrvd22   = 22,  // Reserved
  Rsrvd23   = 23,  // Reserved
  Rsrvd24   = 24,  // Reserved
  Rsrvd25   = 25,  // Reserved
  Rsrvd26   = 26,  // Reserved
  Rsrvd27   = 27,  // Reserved
  Rsrvd28   = 28,  // Reserved
  Rsrvd29   = 29,  // Reserved
  Rsrvd30   = 30,  // Reserved
  SigNotAvl = 31,  // Signal not available
};
enum class HldLampReq_e {
  NoReq  = 0,  // No request
  Illume = 1,  // illume lamp
};

struct LngCtrlFun_s {
  bool           VLCAvl;            //@Channel:CHASSIS @Message:0x56 @Signal:VCU_VLCAvl
  bool           VLCActv;           //@Channel:CHASSIS @Message:0x56 @Signal:VCU_VLCActv
  float          VLCTarDecel;       //@Channel:CHASSIS @Message:0x56 @Signal:VCU_VLCTarDecel
  LlcFctSt_e     LLCFctSt;          //@Channel:CHASSIS @Message:0x56 @Signal:VCU_LLCFctSt
  LlcIntrptErr_e LLCIntrrptErrTyp;  //@Channel:CHASSIS @Message:0x56 @Signal:VCU_LLCIntrrptErrTyp
  bool           AutoBrkgAvl;
  bool           AutoBrkgActv;
  AdtSt_e        ADTSts;            //@Channel:CHASSIS @Message:0x56 @Signal:VCU_ADTSts
  HldLampReq_e   HldLampReq;        //@Channel:CHASSIS @Message:0x56 @Signal:VCU_HldLampReq
  bool           FCC1_ForceFctEna;  //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_ForceFctEna
  bool           FCC1_BrkReqEna;    //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_BrkReqEna
  float FCC1_TarBrkFReq;  //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_TarBrkFReq @Comment:Target Brake Force Request
  bool  FCC1_VehHldReq;   //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_VehHldReq
  bool  FCC1_VLCActv;     //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_VLCActv
  float RVMCLgtDecCp;     //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_VMCLgtDecCp
  unsigned int    RVMCLgtSts;        //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_VMCLgtSts
  CruiseCtrlMod_e VCUCruiseCtrlMod;  //@Channel:CHASSIS @Message:0x217 @Signal:VCUCruiseCtrlMod
  VMCBrkOvrd_e    VMCBrkOvrd;        //@Channel:CHASSIS @Message:0x56 @Signal:VMCBrkOvrd
  float           VMCLgtAccCp;       //@Channel:CHASSIS @Message:0x109 @Signal:VCU_VMCLgtAccCp
  float           VMCLgtDecCp;       //@Channel:CHASSIS @Message:0x109 @Signal:VCU_VMCLgtDecCp
  unsigned int    VMCLgtSts;         //@Channel:CHASSIS @Message:0x109 @Signal:VCU_VMCLgtSts

  unsigned int VCU_VMCLLCSts;   //@Channel:CHASSIS @Message:0x109 @Signal:VCU_VMCLLCSts
  unsigned int FCC1_VMCLLCSts;  //@Channel:CHASSIS @Message:0xD5 @Signal:FCC1_VMCLLCSts
};

struct StrCtrlInfo_s {
  StrActvIf_e ActvExtIf;  //@Channel:CHASSIS @Message:0x56 @Signal:EPS1_ActvExtIf
  bool        HIAvl;      //@Channel:CHASSIS @Message:0x56 @Signal:EPS1_ADCHVIAvl
  bool        TOIAvl;     //@Channel:CHASSIS @Message:0x56 @Signal:EPS1_ADCCTIAvl
  bool        DAIAvl;     //@Channel:CHASSIS @Message:0x56 @Signal:EPS1_ADCACIOlAvl
  bool        PAIAvl;     //@Channel:CHASSIS @Message:0x56 @Signal:EPS1_ADCACIOrAvl
};
class VEHCTRL {
 private:
 public:
  /* data */
  LngCtrlFun_s  LngCtrlIf;
  StrCtrlInfo_s LatCtrlIf;

 public:
  VEHCTRL(/* args */);
  ~VEHCTRL();
};
