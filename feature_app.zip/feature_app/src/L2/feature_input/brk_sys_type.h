#pragma once
#include "veh_enum_type.h"
#include <stdint.h>

enum class BrkPdlCalSts_e {
  NotClbrt  = 0,  // Not calibrated
  Clbrted   = 1,  // Calibrated
  Rsrvd2    = 2,  // Reserved
  SgnlNtAvl = 3,  // Signal not available
};

enum class BrkPdlSts_e {
  NotPrssd = 0,  // Not pressed
  Prssd    = 1,  // Pressed
  Rsrvd2   = 2,  // Reserved
  Invld    = 3,  // Invalid (Error)
};

enum class WhlPrsRlblt_e {
  NotRlbl = 0,  // Not reliable
  Rlbl    = 1,  // Reliable
};

enum class EpbSwtSt_e {
  EpbSw_NotPrssd = 0,  // Not pressed
  EpbSw_Prssd    = 1,  // Pressed
  EpbSw_Rsrvd2   = 2,  // Reserved
  EpbSw_Invld    = 3,  // Invalid
};

enum class EpbSts_e {
  EpbSt_Unknown  = 0,  // Unknown
  EpbSt_Applied  = 1,  // EPB applied
  EpbSt_Rlsing   = 2,  // EPB releasing
  EpbSt_Rlsed    = 3,  // EPB released
  EpbSt_Applying = 4,  // EPB applying
  EpbSt_Rsrvd5   = 5,  // Reserved
  EpbSt_Rsrvd6   = 6,  // Reserved
  EpbSt_Rsrvd7   = 7,  // Reserved
};

enum class EpbMod_e {
  EpbMd_Normal     = 0,  // Normal
  EpbMd_Mntnc      = 1,  // Maintenance Mode
  EpbMd_RllrBnch   = 2,  // Roller Bench Test
  EpbMd_Tow        = 3,  // Slope over  30%
  EpbMd_SlpOvr30   = 4,  // Tow Mode
  EpbMd_HydBrkFail = 5,  // Hydraulic Brake Support Failure
  EpbMd_SlpOvr8    = 6,  // Slope over 8%
  EpbMd_Rsrvd7     = 7,  // Reserved
};
enum class BrkOvrHt_e {
  BrkTmpNotToHigh = 0,  // Brake temperature not high
  BrkTmpToHigh    = 1,  // Brake temperature too high
};

enum class BrkHazReq_e {
  BrkHaz_NoReq = 0,  // Hazard warning no request
  BrkHaz_Req   = 1,  // Hazard warning request
};

enum class BcuBrkLiReq_e {
  BrkLi_NoBcuReq  = 0,  // No request
  BrkLi_BcuReq    = 1,  // Request
  BrkLi_BcuRsrvd2 = 2,  // Reserved
  BrkLi_BcuInvld  = 3,  // Invalid
};

enum class BcuBrkF_e {
  BcuNoBrkF = 0,  // No brake force applied
  BcuBrkF   = 1,  // Brake force applied
};

enum class BcuSupInfo_e {
  Bcu_BEG_91  = 0,  // BEG (ESP 9.1)
  BCU_CC_93   = 1,  // CC (ESP 9.3)
  Bcu_Mando   = 2,  // Mando
  Bcu_Unknown = 3,  // Unknown
};

enum class BrkFldLvl_e {
  BrkFldLvl_Nrml   = 0,  // Level normal
  BrkFldLvl_Low    = 1,  // Level low
  BrkFldLvl_Rsrvd2 = 2,  // Reserved
  BrkFldLvl_Invld  = 3,  // Invalid
};

enum class BrkPdWrSts_e {
  BrkPd_Nrml   = 0,  // Normal
  BrkPd_Worn   = 1,  // Pad worn
  BrkPd_Rsrvd2 = 2,  // Reserved
  BrkPd_Invld  = 3,  // Invalid
};

enum class AvhSts_e {
  Avh_Fail  = 0,  // Failure(AVH lamp on with yellow color)
  Avh_Stdby = 1,  // Standby(AVH lamp off)
  Avh_Actv  = 2,  // Active(AVH lamp on with green color)
  Avh_Off   = 3,  // Off(F101 config disable or Switch off)
};

enum class HdcSts_e {
  Hdc_Off   = 0,  // Off(F101 config disable or Switch off)
  Hdc_Fail  = 1,  // Failure
  Hdc_Stdby = 2,  // Standby
  Hdc_Actv  = 3,  // Active
};

enum class StstSts_e {
  Stst_NoHold     = 0,  // No Hold
  Stst_TrnsToHold = 1,  // Transitino to Hold
  Stst_Hold       = 2,  // Hold
  Stst_Release    = 3,  // Release
  Stst_EPBApplyReq = 4, // EPB Apply Request nt2
  Stst_EPBHold = 5, // EPB Hold nt2
  Stst_EPBRelease = 6, // EPB release brake nt2
  Stst_EPBApplyBrk = 7, // EPB apply with brake nt2
};

enum class CDPReq_e : uint8_t {
  kCDP_NoReq = 0,
  kCDP_Req   = 1,
};

enum class BrkFldWarnReq_e : uint8_t {
  kNoWarning = 0,
  kWarning   = 1,
  kReserved  = 2,
  kInvalid   = 3,
};

enum class BrkPadWearWarnReq_e : uint8_t {
  kNoWarning = 0,
  kWarning   = 1,
  kReserved  = 2,
  kInvalid   = 3,
};

struct BrkPdlInfo_s {
  BrkPdlCalSts_e TrvlCalSts;  //@Channel:CHASSIS @Message:0x5B @Signal:BrkPedlTrvlCalSts
  float          Trvl;        //@Channel:CHASSIS @Message:0x5B @Signal:BrkPedlTrvl
  BrkPdlSts_e    BrkPedlSts;  //@Channel:CHASSIS @Message:0x5B @Signal:BrkPedlSts
  bool           BrkpedlOvrd; //@Channel:CHASSIS @Message:0x5B @Signal:BrkpedlOvrd
};

struct BrkPrsInfo_s {
  QfZeroVld_e BrkPrsVld;  //@Channel:CHASSIS @Message:0x5B @Signal:BrkPressValid
  float       BrkPrs;     //@Channel:CHASSIS @Message:0x5B @Signal:BrkPress
  float       BrkPrsGrad;
  QfZeroVld_e BrkPrsOffsetVld;  //@Channel:CHASSIS @Message:0x5B
                                //@Signal:BrkPressOffsetValid
  float BrkPrsOffset;           //@Channel:CHASSIS @Message:0x5B @Signal:BrkPressOffset
};

struct PrkBrkInfo_s {
  EpbSwtSt_e EPBSwtSts;  //@Channel:CHASSIS @Message:0x7A @Signal:EPB1_SwtSts
  EpbSts_e   EPBSts;     //@Channel:CHASSIS @Message:0x7A @Signal:EPB1_EPBSts
  EpbMod_e   EPBMod;     //@Channel:CHASSIS @Message:0x7A @Signal:EPB1_Mod
  CDPReq_e   CDPReq;     //@Channel:CHASSIS @Message:0x7A @Signal:EPB1_CDPReq
};
struct BrkFunInfo_s {
  bool     BDWActv;            //@Channel:CHASSIS @Message:0x5E @Signal:BDWActv
  bool     ABAAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:ABAAvl
  bool     ABAActv;            //@Channel:CHASSIS @Message:0x5E @Signal:ABAActv
  bool     ABPAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:ABPAvl
  bool     ABPActv;            //@Channel:CHASSIS @Message:0x5E @Signal:ABPActv
  bool     ABSActv;            //@Channel:CHASSIS @Message:0x5E @Signal:ABSActv
  AvhSts_e AVHSts;             //@Channel:CHASSIS @Message:0x5E @Signal:AVHSts
  bool     DTCActv;            //@Channel:CHASSIS @Message:0x5E @Signal:DTCActv
  bool     DTCAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:DTCAvl
  bool     DWTActv;            //@Channel:CHASSIS @Message:0x5E @Signal:DWTActv
  bool     EBAAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:EBAAvl
  bool     EBAActv;            //@Channel:CHASSIS @Message:0x5E @Signal:EBAActv
  bool     EBDActv;            //@Channel:CHASSIS @Message:0x5E @Signal:EBDActv
  bool     HBAActv;            //@Channel:CHASSIS @Message:0x5E @Signal:HBAActv
  bool     AWBActv;            //@Channel:CHASSIS @Message:0x5E  @Signal:AWBActv
  bool     AWBAvl;             //@Channel:CHASSIS @Message:0x5E  @Signal:AWBAvl
  HdcSts_e HDCSts;             //@Channel:CHASSIS @Message:0x5E @Signal:HDCSts
  bool     HHCAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:HHCAvail
  bool     HHCActv;            //@Channel:CHASSIS @Message:0x5E @Signal:HHCActv
  bool     TCSActv;            //@Channel:CHASSIS @Message:0x5E @Signal:TCSActv
  bool     TCSDeactv;          //@Channel:CHASSIS @Message:0x5E @Signal:TCSDeactv
  bool     VDCActv;            //@Channel:CHASSIS @Message:0x5E @Signal:VDCActv
  bool     VDCDeactv;          //@Channel:CHASSIS @Message:0x5E @Signal:VDCDeactv
  ZeroEn_e ARPCfgSts;          //@Channel:CHASSIS @Message:0x5E @Signal:ARPCfgSts
  bool     ARPActv;            //@Channel:CHASSIS @Message:0x5E @Signal:ARPActv
  bool     ARPAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:ARPAvl
  bool     CDPActv;            //@Channel:CHASSIS @Message:0x5E @Signal:CDPActv
  bool     CDPAvl;             //@Channel:CHASSIS @Message:0x5E @Signal:CDPAvl
  bool     EBDFailLampReq;     //@Channel:CHASSIS @Message:0x24F @Signal:EBDFailLampReq
  bool     VDCTCSLampInfo;     //@Channel:CHASSIS @Message:0x24F @Signal:VDCTCSLampInfo
  bool     VDCTCSFailLampReq;  //@Channel:CHASSIS @Message:0x24F
                               //@Signal:VDCTCSFailLampReq
  bool ABSFailLampReq;         //@Channel:CHASSIS @Message:0x24F @Signal:ABSFailLampReq
  bool VDCTCSOnOfflampReq;     //@Channel:CHASSIS @Message:0x24F @Signal:VDCTCSOnOfflampReq
};
class BRKSYS {

  // private:
 public:
  /* data */
  BrkPdlInfo_s        BrkPdl;
  BrkPrsInfo_s        BrkPrs;
  PrkBrkInfo_s        PrkBrk;
  BrkOvrHt_e          BrkOverHeat;    //@Channel:CHASSIS @Message:0x5B @Signal:BrkOverHeat
  BrkHazReq_e         BrkHAZReq;      //@Channel:CHASSIS @Message:0x5B @Signal:HAZReq
  BcuBrkLiReq_e       BCUBrkLiReq;    //@Channel:CHASSIS @Message:0x5B @Signal:BCUBrkLiReq
  BcuBrkF_e           NoBrkF;         //@Channel:CHASSIS @Message:0x5B @Signal:BCU_NoBrkF
  BcuSupInfo_e        SupInfo;        //@Channel:CHASSIS @Message:0x5B @Signal:BCU_SupInfo
  BrkFldLvl_e         BrkFldLvl;      //@Channel:CHASSIS @Message:0x39A @Signal:BrkFldLvl
  BrkPdWrSts_e        BrkPadWearSts;  //@Channel:CHASSIS @Message:0x39A @Signal:BrkPadWearSts
  BrkFunInfo_s        BrkFunSt;
  StstSts_e           StstSts;            //@Channel:CHASSIS @Message:0x56 @Signal:StandstillSts
  BrkFldWarnReq_e     BrkFldWarnReq;      //@Channel:ADAS @Message:0x39A @Signal:BrkFldWarnReq
  BrkPadWearWarnReq_e BrkPadWearWarnReq;  //@Channel:ADAS @Message:0x39A @Signal:BrkPadWearWarnReq
 public:
  BRKSYS(/* args */);
  ~BRKSYS();
};