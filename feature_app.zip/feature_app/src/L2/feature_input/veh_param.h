
#pragma once
#include "veh_enum_type.h"
enum class SalesRegionTyp_e : uint8_t {
  INVALID_SALES_REGION = 0,
  CN                   = 1,
  EU                   = 2,
};

enum class FCTVehProjectTyp_e : uint8_t {
  INVALID_VEH_PROJECT = 0,
  FORCE               = 1,
  GEMINI              = 2,
  PEGASUS             = 3,
  ARIES               = 4,
  SIRIUS              = 5,
  LIBRA               = 6,
  ORION               = 7,
  LYRA                = 8,
};

struct VariantCodeInfo_s {
  SalesRegionTyp_e sales_region;  // sales region
  FCTVehProjectTyp_e vehicle_type;   //vehicle type
  bool nop_plus_subscribe_avail;
  bool NAD_subscribe_avail;
};

class VEHPARAM {
 private:
 public:
  /* data */
  VariantCodeInfo_s VarCodeInfo;

 public:
  VEHPARAM(/* args */);
  ~VEHPARAM();
};
