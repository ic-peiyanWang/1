
#pragma once
#include <stdint.h>

class NopSpeed {
 private:
 public:
  /* data */
  uint32_t nop_now_electronic_eye_speed_limit;
  uint32_t nop_now_advisory_speed_limit;
  uint32_t nop_now_legal_speed;
  uint32_t nop_next_electronic_eye_speed_limit;
  uint32_t nop_next_advisory_speed_limit;
  uint32_t nop_next_legal_speed;
  uint32_t nop_distance_to_next;
  uint32_t nop_now_road_type;
  uint32_t nop_next_road_type;
  uint32_t nop_reserved;

public:
  NopSpeed(/* args */);
  ~NopSpeed();
};
