#pragma once
#include <stdint.h>

enum class QfZeroVld_e {
  QfVld   = 0,
  QfInvld = 1,
};

enum class ZeroEn_e : uint8_t {
  Enable  = 0,
  Disable = 1,
};

enum class AdFunOnOff_e {
  Off    = 0,  // Off
  On     = 1,  // On
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};

enum class GoNotifierSwitch_e {
  BothOff   = 0, //both off
  VehOn     = 1, //only leading vehicle on
  LightOn   = 2, //only traffic light on
  BothOn    = 3, //both on
};

enum class TauGap_e {
  TG_0      = 0,  // tauGap_0 (1.0s)
  TG_1      = 1,  // ttauGap_1 (1.4s)
  TG_2      = 2,  // tauGap_2 (1.8s)
  TG_3      = 3,  // tauGap_3 (2.2s)
  TG_4      = 4,  // tauGap_4 (2.6s)
  TG_Rsrvd5 = 5,  // Reserved
  TG_Rsrvd6 = 6,  // Reserved
  TG_Rsrvd7 = 7,  // Reserved
};

enum class LnAssistAid_e {
  Off    = 0,  // Off
  LDW    = 1,  // LDW
  LKA    = 2,  // LKA
  LKS    = 3,  // LKS
  LDWLKA = 4,  // LDW and LKA
  LDWLKS = 5,  // LDW and LKS
  Rsrvd6 = 6,  // Reserved
  InVld  = 7,  // Invalid
};

enum class LnAssistSnvty_e {
  Low    = 0,  // Low sensitivity
  Normal = 1,  // Normal sensitivity
  High   = 2,  // High sensitivity
  InVld  = 3,  // Invalid
};

enum class AccSt_e {
  Off     = 0,  // ACC/NP both not available
  Psv     = 1,  // ACC/NP state System Passive
  Stdb    = 2,  // Longitudinal Control Standby
  Actv    = 3,  // Long. Cont. in active mode
  BrkOnly = 4,  // Long. Cont. in brake-only mode
  Ovrd    = 5,  // Long. Cont. in driver override
  Stst    = 6,  // Long. Cont. in standstill mode
  Fail    = 7,  // ACC Failure
};

enum class LkaStrSprtLvl_e {
  Light  = 0,  // Light steering force
  Medium = 1,  // Medium steering force
  Strong = 2,  // Strong steering force
  InVld  = 3,  // Invalid
};

enum class LatCtrlEngage_e {
  Auto   = 0,  // Auto
  Manual = 1,  // Manual
  Rsrvd2 = 2,  // Reserved
  InVld  = 3,  // Invalid
};

enum class AlcCnfrm_e {
  Off        = 0,  // Off
  TrnIndc    = 1,  // On turn light only
  TrnIndcTrq = 2,  // On turn light and driver torque
  InVld      = 3,  // Invalid
};
