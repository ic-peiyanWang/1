#pragma once
#include <stdint.h>
#include "veh_enum_type.h"

enum class StrAgFailSts_e {
  NoFail  = 0,  // No failure
  Fail    = 1,  // Failure
  Rsrvd3  = 2,  // Reserved
  Invalid = 3,  // Invalid
};

enum class StrAgCalSts_e {
  Calibrated    = 0,
  NotCalibrated = 1,
};

enum class EPSSts_e {
  Init     = 0,  // Init (Park Status)
  Normal   = 1,  // Normal
  Dgrd     = 2,  // Degraded
  ErrTemp  = 3,  // Temporary error
  ErrPrmnt = 4,  // Permanent error
  Rsrvd5   = 5,  // Reserved_5
  Rsrvd6   = 6,  // Reserved_6
  Invalid  = 7,  // Invalid
};

enum class SWCFailSts_e {
  SWCFail_Nrml  = 0,  // Normal
  SWCFail_Fail  = 1,  // Fail
  SWCFail_Rsrvd = 2,  // Reserved
  SWCFail_InVld = 3,  // Invalid
};

enum class EpsDrvMod_e {
  lght   = 0,  // Light
  Mdm    = 1,  // Medium (default)
  Hv     = 2,  // Heavy
  Rsrvd3 = 3,  // Reserved_3
};

enum class HODSts_e {
  kHandsOff       = 0,   // Hands off  (initial and default)
  kEnrgSavingMode = 1,   // Energy saving mode
  kHandsOn        = 2,   // Hands on
  kNotAvlb        = 3,   // Not Available
  kErrExist       = 4,   // Error Exist
  kInit           = 15,  // Initialization
};

class STRSYS {
  // private:
 public:
  /* data */
  StrAgFailSts_e StrAgFailSts;  //@Channel:CHASSIS @Message:0xD4 @Signal:SteerAgSnsrFailSts
  StrAgCalSts_e  StrAgCalSts;   //@Channel:CHASSIS @Message:0xD4 @Signal:SteerAgSnsrCalSts
  float          StrWhlAg;      //@Channel:CHASSIS @Message:0xD4 @Signal:SteerWhlAg
                                //:SteerWhlAgDir
  float StrWhlAgSpd;            //@Channel:CHASSIS @Message:0xD4 @Signal:SteerWhlAgSpd
                                //:SteerWhlAgSpdDir
  QfZeroVld_e  PnnAgVld;        //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_PinAngVal
  float        PnnAg;           //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_PinAng
  float        PnnAgOffset;     //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_PinAngOffset
  unsigned int OverRideDetn;    //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_OverRideSts
  QfZeroVld_e  EstRackFrcVld;   //@Channel:CHASSIS @Message:0x75
                                //@Signal:EPS1_EstRackForceVal
  float        EstRackFrc;      //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_EstRackForce
  QfZeroVld_e  MtrTqVld;        //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_TotMotorTqVal
  float        MtrTq;           //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_TotMotorTq
  QfZeroVld_e  TorsBarTqVld;    //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_TorsBarTqVal
  float        TorsBarTq;       //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_TorsBarTq
  EPSSts_e     EPSSts;          //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_Sts
  SWCFailSts_e SWCFailSts;      //@Channel:CHASSIS @Message:0x29F @Signal:SWCFailSts
  EpsDrvMod_e  DrvngMod;        //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_DrivingMod
  bool         RampSts;         //@Channel:CHASSIS @Message:0x74 @Signal:EPS1_RampSts
  QfZeroVld_e  ACIMtrTqVld;     //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_ACIMotorTqVal
  float        ACIMtrTq;        //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_ACIMotorTq
  unsigned int Temperature;     //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_Temperature
  unsigned int SupInfo;         //@Channel:CHASSIS @Message:0x75 @Signal:EPS1_SupInf
  HODSts_e     HODSts;          //@Channel:ADAS @Message:0x2BC @Signal:HOSts
  bool         HODErrSts;       //@Channel:ADAS @Message:0x2BC @Signal:HODErrSt
  bool         DSREPSReq;       //@Channel:CHASSIS @Message:0x5F @Signal:BCU_EPSReqTyp
 public:
  STRSYS(/* args */);
  ~STRSYS();
};