#pragma once

#include <stdint.h>
#include <vector>

constexpr int kNumHdLink  = 20;
constexpr int kNumFormWay = 20;

enum class PriorityRoadClass_e {
  MOTORWAY                = 0,
  CITY_MOTORWAY           = 1,
  NATIONAL_HIGHWAY        = 2,
  PROVINCIAL_HIGHWAY      = 3,
  COUNTY_ROAD             = 4,
  TOWNSHIP_ROAD           = 5,
  OTHER_ROAD              = 6,
  SPECIAL_SERVICE         = 7,
  FERRY                   = 8,
  PEDESTRIAN_ROAD         = 9,
  PASSENGER_FERRY         = 10,
  CYCLE_TRACK             = 11,
  SERVICE_AREA_INNER_ROAD = 12,
};

enum class FormWay_e {
  FORM_WAY_NONE                     = 0,
  FORM_WAY_SEPARATE_DIRECTION       = 1,
  FORM_WAY_INTERSECTION             = 2,
  FORM_WAY_IC                       = 3,
  FORM_WAY_JCT                      = 4,
  FORM_WAY_TUNNEL                   = 5,
  FORM_WAY_SA                       = 6,
  FORM_WAY_PA                       = 7,
  FORM_WAY_RELIEF_ROAD              = 8,
  FORM_WAY_ROUNDABOUT               = 9,
  FORM_WAY_BRIDGE                   = 10,
  FORM_WAY_PEDESTRIAN_STREET        = 11,
  FORM_WAY_RAMP                     = 12,
  FORM_WAY_CONTROLLED_ACCESS        = 13,
  FORM_WAY_UNKNOWN_TRAFFIC_REGION   = 14,
  FORM_WAY_POI_LINK                 = 15,
  FORM_WAY_BUS                      = 16,
  FORM_WAY_RIGHT_TURN               = 17,
  FORM_WAY_TOURIST                  = 18,
  FORM_WAY_REGION_ROAD              = 19,
  FORM_WAY_LEFT_TURN                = 20,
  FORM_WAY_TRUCK                    = 21,
  FORM_WAY_RELIEF_ENTRANCE_OR_EXIT  = 22,
  FORM_WAY_PA_ENTRANCE_OR_EXIT      = 23,
  FORM_WAY_MOVABLE_BRIDGE           = 24,
  FORM_WAY_RESERVED                 = 25,
  FORM_WAY_MAIN_ROAD                = 26,
  FORM_WAY_TURN_LEFT_TO_BORROW_ROAD = 27,
  FORM_WAY_UTURN                    = 28,
  FORM_WAY_LINK_TO_SPECIAL          = 29,
  FORM_WAY_LINK_STEP_ROAD           = 30,
  FORM_WAY_LINK_FRONT_OF_DOOR       = 31,
};

class HDLINK {
 private:
 public:
  PriorityRoadClass_e    priority_road_class;
  std::vector<FormWay_e> form_way;

 public:
  HDLINK(/* args */);
  ~HDLINK();
};

