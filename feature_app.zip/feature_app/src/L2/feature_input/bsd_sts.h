
#pragma once
#include "veh_enum_type.h"

enum class BsdLcaWarnStType_e  : uint8_t {
    BSDlCA_Off   = 0,
    BSDlCA_InActv= 1,
    BSDlCA_Actv  = 2,
    BSDlCA_Fail  = 3,
};

enum class BsdLcaReWarnType_e  : uint8_t {
    BsdLcaReWarn_Off    = 0,
    BsdLcaReWarn_Lvl1   = 1,
    BsdLcaReWarn_Lvl2   = 2,
    BsdLcaReWarn_Rsrvd3 = 3,
};

struct BsdStsInfo_s {
  BsdLcaWarnStType_e bsdlca_left_sts;
  BsdLcaWarnStType_e bsdlca_right_sts;
  BsdLcaReWarnType_e bsdlca_left_warn_req; 
  BsdLcaReWarnType_e bsdlca_right_warn_req;
};


class BSDSTS {
 private:
 public:
  /* data */
  BsdStsInfo_s BsdSts;  

 public:
  BSDSTS(/* args */);
  ~BSDSTS();
};
