#pragma once

#include <stdint.h>

enum class TgtObjMotionStatus_e : uint8_t {
  kOBJ_STATUS_UNDEFINED = 0,  // Default value
  kOBJ_STATUS_STANDING  = 1,
  kOBJ_STATUS_STOPPED   = 2,
  kOBJ_STATUS_MOVING    = 3,
  kOBJ_STATUS_ONCOMING  = 4,
  kOBJ_STATUS_PARKED    = 5,
};

enum class TgtObjType_e : uint8_t {
  kOBJTYPE_VEHICLE       = 0,  // Default value
  kOBJTYPE_TRUCK         = 1,
  kOBJTYPE_BIKE          = 2,
  kOBJTYPE_PEDESTRAIN    = 3,
  kOBJTYPE_BICYCLE       = 4,
  kOBJTYPE_GENERALOBJECT = 5,
  kOBJTYPE_TRAIL         = 6,
  kOBJTYPE_UNDEFINED     = 7,
  kOBJTYPE_GUARDRAIL     = 8,
  kOBJTYPE_WALL          = 9,
  kOBJTYPE_PASSBY        = 10,
  kOBJTYPE_OBSTACLE      = 11,
  kOBJTYPE_ANIMAL        = 12,
  kOBJTYPE_SUV           = 13,
  kOBJTYPE_PICKUP        = 14,
  kOBJTYPE_VAN           = 15,
  kOBJTYPE_BUS           = 16,
  kOBJTYPE_SPECIALTRUCK  = 17,
  kOBJTYPE_TRICYCLE      = 18,
  kOBJTYPE_BIKE_P        = 19,
  kOBJTYPE_BICYCLE_P     = 20,
  kOBJTYPE_SPECIAL       = 21,
};

enum class TgtObjValidStatus_e : uint8_t {
  kInvalid = 0,
  kNew     = 1,
  kMature  = 2,
  kCoast   = 3,
};

enum class BlinkerType_e : uint8_t {
  kOFF         = 0,
  kTURNLEFT    = 1,
  kTURNRIGHT   = 2,
  kDOUBLEFLASH = 3,
};

enum class TgtLaneChangeDir_e : uint8_t {
  kTgtLaneChangeDirDefault = 0,
  kTgtLaneChangeDirLeft    = 1,
  kTgtLaneChangeDirRight   = 2,
};

enum class TgtFusionSrc_e : uint8_t {
  kDefault    = 0,
  kRadarOnly  = 1,
  kVisionOnly = 2,
  kRadarVison = 3,
};

struct TgtObj_s {
  uint32_t id;
  uint32_t obj_index;
  uint32_t confidence;
  float    lon_pos_ccs;      // position in frenet coordinate system
  float    lon_pos_vcs;      // vehicle coordinate system position
  float    lon_pos_vcs_std;  // add
  float    lon_vel;
  float    lon_vel_std;  // add
  float    lon_acc;
  float    lat_pos_ccs;
  float    lat_pos_vcs;
  float    lat_pos_vcs_std;  // add
  float    lat_vel;
  float    lat_vel_std;  // add
  float    lat_vel_ccs;
  float    lat_acc;
  uint8_t  status;  // TgtObjMotionStatus_e
  uint8_t  type;    // TgtObjType_e
  uint8_t  valid;   // TgtObjValidStatus_e
  uint32_t age;
  float    width;
  float    length;
  float    height;  // add
  float    phi_angle;
  float    dphi_angle_rate;
  uint8_t  fusion_source;  // TgtFusionSrc_e
  float    ttc;
  uint8_t  blinker_info;  // BlinkerType_e
  uint32_t brake_lights;  // need to find information. Could be not 0 is brake light ON.
  float    prob_lane_change;
  uint8_t  dirLaneChange;  // TgtLaneChangeDir_e
  uint32_t ageTarInPath;
  uint8_t  lane_assign_from_perception;//TGTLaneAssignment
};

struct TcaTarget_s {
  TgtObj_s tca_obj[15];
  uint32_t valid_tgt_num;
};

struct LaneAssignment_s {
  bool host_lane;
  bool left_lane;
  bool right_lane;
};

struct EHYobfout_s {
  bool obf_rear_object_detected;
  LaneAssignment_s construction_valid;
  bool construction_wti;
};


class EHYTSI {
  // private:
 public:
  /* data */
  TgtObj_s    tsi_obj[35];     // 35
  TgtObj_s    rm_tsi_out[32];  // 32
  TcaTarget_s tca_out;         // 15
  uint32_t    tsi_status;      //
  bool        tsi_flg_cipvlost;
  bool        tsi_ego_lane_changed;
  uint32_t    svc_frnt_obstacle_status;
  uint32_t    bsd_hmi_id[2];
  uint32_t    lca_hmi_id[2];

 public:
  EHYTSI(/* args */);
  ~EHYTSI();
};

class EHYTSE {
  // private:
 public:
  /* data */
  TgtObj_s tse_obj[4];  // 4
  bool     tsi_flg_cipv_lost;

 public:
  EHYTSE(/* args */);
  ~EHYTSE();
};

class EHYOBF {
 private:
 public:
  /* data */
  EHYobfout_s ehyobfout;

 public:
  EHYOBF(/* args */);
  ~EHYOBF();
};