#pragma once

#include <stdint.h>

class NopVehicleOut {
  // private:
 public:
  /* data */
  uint32_t         nop_alc_sts;
  uint32_t         nop_colllision_risk;
  bool             nop_freeSpace_intrusion_at_standstill;
  bool             nop_freeSpace_intrusion_go_notifier;
  uint32_t         nop_lat_ctrl_tarLe;
  uint32_t         nop_lat_ctrl_tarRi;
  uint32_t         nop_long_ctrl_tar;
  uint32_t         nop_turn_indicator_req;
  uint32_t         nop_wti;
  bool             nop_freespaceintrusionatstandstill;
  bool             nop_rain_mode;
  double           nop_lat_error;
  float            nop_dist_to_fork;  // reserved
  bool             nop_cutin_wti;
  bool             nop_ego_is_lane_keep;

 public:
  NopVehicleOut(/* args */);
  ~NopVehicleOut();
};