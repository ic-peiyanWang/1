#pragma once

#include <stdint.h>

enum class HaTextInfo_e : uint8_t
{
    kHA_TextInfo_Default = 1,
    kHA_TextInfo_Construction = 2,
    kHA_TextInfo_Tunnel = 3,
    kHA_TextInfo_SharpTurn = 4,
    kHA_TextInfo_BadWeature = 5,
    kHA_TextInfo_LowLaneConf = 6,
    kHA_TextInfo_LaneLineChg = 7,
};

class EHYHA
{
//private:
public:
    /* data */
    uint32_t icon_info;
    HaTextInfo_e text_info;
    uint32_t sound_info;
    uint32_t hmi_highlight_obj_id;
    bool left_lane_flash;
    bool right_lane_flash;
public:
    EHYHA(/* args */);
    ~EHYHA();
};