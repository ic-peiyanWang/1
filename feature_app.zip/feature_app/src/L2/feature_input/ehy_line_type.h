#pragma once

#include <stdint.h>

enum class LMLaneMarkClass_e : uint8_t {
  kLMLC_UNDECIDED               = 0,
  kLMLC_SOLID                   = 1,
  kLMLC_DASHED                  = 2,
  kLMLC_DOUBLELANECROSSABLE     = 3,
  kLMLC_DOUBLELANEUNCROSSABLE   = 4,
  kLMLC_MULTIPLELANECROSSABLE   = 5,
  kLMLC_MULTIPLELANEUNCROSSABLE = 6,
  kLMLC_BOTTDOTS                = 7,
  kLMLC_CURB                    = 8,
  kLMLC_SNOWEDGE                = 9,
  kLMLC_ROADEDGE                = 10,
  kLMLC_VIRTUAL                 = 11,
  kLMLC_BARRIER                 = 12,
  kLMLC_CONES                   = 13,
  kLMLC_DECEL                   = 14,
  kLMLC_INVALID                 = 15,
  kLMLC_DOUBLELANESOLIDSOLID    = 16,
  kLMLC_DOUBLELANEDASHEDDASHED  = 17,
  kLMLC_HOVLANE                 = 18,
};

enum class LMColor_e : uint8_t {
  kLMColor_White   = 0,
  kLMColor_Yellow  = 1,
  kLMColor_Blue    = 2,
  kLMColor_Invalid = 3,
};

enum class LMSource_e : uint8_t {
  kLMSource_NONE      = 0,
  kLMSource_CLM       = 1,
  kLMSource_LVLM      = 2,
  kLMSource_RLM       = 4,
  kLMSource_TF        = 8,
  kLMSource_HPP       = 16,
  kLMSource_ESTIMATE  = 32,
  kLMSource_HDMAP     = 64,
  kLMSource_FREESPACE = 128,
};

enum class LMLaneType_e : uint8_t {
  kLMLT_UNDECIDED            = 0,
  kLMLT_REGULAR              = 1,
  kLMLT_SHOULDER             = 2,
  kLMLT_OPENING              = 3,
  kLMLT_CLOSING              = 4,
  kLMLT_BICYCLE              = 5,
  kLMLT_RAMP                 = 6,
  kLMLT_CARPOOL              = 7,
  kLMLT_RESERVED             = 8,
  kLMLT_BUS                  = 9,
  kLMLT_NONE                 = 10,
  kLMLT_ACCELERATION         = 11,
  kLMLT_DECELERATION         = 12,
  kLMLT_TEMP_SHOULDER_OPEN   = 13,
  kLMLT_TEMP_SHOULDER_CLOSED = 14,
  kLMLT_DIRECT_EXIT          = 15,
};

enum class LMLaneDir_e : uint8_t {
  kLMLaneDir_UNDECIDED  = 0,
  kLMLaneDir_DIRECTE    = 1,
  kLMLaneDir_LEFTTURN   = 2,
  kLMLaneDir_RIGHTTURN  = 4,
  kLMLaneDir_LEFTCHANGE = 8,
  kLMLaneDir_RIGHCHANGE = 16,
};

enum class LMRole_e : uint8_t {
  kLMRole_NONE            = 0,
  kLMRole_HOST_LANE       = 16,
  kLMRole_HOST_LANE_LEFT  = 17,
  kLMRole_HOST_LANE_RIGHT = 18,
  kLMRole_LE_LANE         = 32,
  kLMRole_LE_LANE_LEFT    = 33,
  kLMRole_LE_LANE_RIGHT   = 34,
  kLMRole_RI_LANE         = 48,
  kLMRole_RI_LANE_LEFT    = 49,
  kLMRole_RI_LANE_RIGHT   = 50,
};

enum class LMIntPClass_e : uint8_t {
  kLMIntPClass_UNDECIDED = 0,
  kLMIntPClass_SPLIT     = 1,
  kLMIntPClass_MERGE     = 2,
  kLMIntPClass_SPD       = 3,
  kLMIntPClass_MARKCLASS = 4,
  kLMIntPClass_COLOR     = 5,
};

struct RmeLine_s {
  float             pt_conf;
  float             c0;
  float             c1;
  float             c2;
  float             c3;
  float             lrange_start;
  float             lrange_end;
  float             lm_width;
  LMColor_e         line_color;
  LMLaneMarkClass_e line_type;
  LMSource_e        line_src;
};

struct RmeLane_s {
  RmeLine_s    left_line;
  RmeLine_s    right_line;
  LMLaneType_e lane_type[2];  // 2
  float        lane_start;
  float        lane_end;
  float        map_spd_limit;
  float        lane_width;
  float        ca_lon_dst;     // construction area lon_distance
  float        cur_point[10];  // 10
  float        cur_value[10];  // 10
  LMLaneDir_e  lane_dir;
  bool         ca_valid;
  uint32_t     lane_id;
};

struct RmePoint_s {
  float conf;
  float x;
  float y;
  float z;
  float w;
  float d;
  float s;
};

struct RmeMapGP_s {
  float    gp_distance;
  uint32_t gp_type;
  float    recom_speed;
  float    link_length;
  uint32_t recom_lane_idx;
  uint32_t recom_speed_id;
  uint32_t recom_speed_src;
  uint32_t recom_speed_conf;
  bool     spd_unit;
  int32_t  sup_sign_typ;
  int32_t  sup_sign_attr;
};

struct RmeHDMap_s {
  RmeMapGP_s ngp_list[20];
};

struct RmeSpdLmt_s {
  uint32_t spd_lmt_value;
  int32_t  spd_lmt_attr;
  int32_t  sup_sign_type3;
  int32_t  sup_sign_attr;
  bool     spd_uint;
};

struct RmeIntp_s {
  RmePoint_s        point;
  int32_t           id;
  LMIntPClass_e     intp_class;
  LMSource_e        source;
  LMRole_e          role;
  LMLaneMarkClass_e far_markclass;
  LMColor_e         far_color;
  uint32_t          far_spd;
};

class EHYRME {
  // private:
 public:
  /* data */
  RmeLine_s  road_edge_left;
  RmeLine_s  road_edge_right;
  RmeLane_s  host_lane;
  RmeLane_s  left_lane;
  RmeLane_s  right_lane;
  RmeHDMap_s hdmap_info;
  RmeIntp_s  interest_point[20];
  float      road_start;
  float      road_end;
  uint32_t   total_lane_num;
  uint32_t   num_lane_id;
  uint32_t   road_type;
  uint32_t   status;

 public:
  EHYRME(/* args */);
  ~EHYRME();
};

class EHYTPP {
  // private:
 public:
  /* data */
  RmeLine_s tpp_trajectory;
  float     latctrl_pt;
  float     longctrl_pt;
  float     shift_offset;
  uint32_t  act_shift_status;
  uint32_t  shift_object_id;

 public:
  EHYTPP(/* args */);
  ~EHYTPP();
};

class EHYLPP {
  // private:
 public:
  /* data */
  RmeLine_s trajectory;  // need check
  float     latctrl_pt;
  float     lonctrl_pt;
  float     shitf_offset;
  uint32_t  act_shift_status;

 public:
  EHYLPP(/* args */);
  ~EHYLPP();
};
