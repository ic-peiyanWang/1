#pragma once
#include <stdint.h>

enum class ReliableState_e {
  RS_NONE              = 0,
  UNRELIABLE           = 1,
  UNRELIABLE_ROUTING   = 2,
  UNRELIABLE_YAWING    = 3,
  UNRELIABLE_SWITCHING = 4,
  UNRELIABLE_UNKNOWN   = 5,
  UNRELIABLE_MAX       = 6,
  RELIABLE             = 7,
};

enum class NavigationState_e {
  NS_NONE        = 0,
  ROUTE_CRUISING = 1,
  ROAMING        = 2,
  NAVIGATING     = 3,
};

struct SdMapInfo_s {
  bool              is_adasmap_valid;
  uint8_t           m_adasmap_is_highway;
  uint32_t          country_code;
  ReliableState_e   reliable_state;
  NavigationState_e navigation_state;
  uint32_t          form_of_way;
  uint32_t          offset;
  uint32_t          trafficevent_offset;
  uint32_t          trafficevent_type;
  uint32_t          speed_unit;
  uint32_t          road_class;
};

class SDMAP {
 private:
 public:
  /* data */
  SdMapInfo_s SdMapInfo;

 public:
  SDMAP(/* args */);
  ~SDMAP();
};
