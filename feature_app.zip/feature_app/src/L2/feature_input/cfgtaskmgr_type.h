#pragma once
#include <stdint.h>

enum class CfgTaskSwitch_Status_e{
  CfgTaskSwitch_Status_ON = 0,// enable mission and deal with event parameter
  CfgTaskSwitch_Status_OFF = 1, // disable a single mission with particular parameters
  CfgTaskSwitch_Status_RESERVED = 2 // delete all the mission of one sort of selector
};

struct CfgTaskSwitchInfo_s {
  CfgTaskSwitch_Status_e cfg_status;
};

class CfgTskSwt {
private:
public:
  /* data */
  CfgTaskSwitchInfo_s CfgTaskSwitchInfo;

public:
  CfgTskSwt(/* args */);
  ~CfgTskSwt();
};