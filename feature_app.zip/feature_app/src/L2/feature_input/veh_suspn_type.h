#pragma once
enum class SuspLvl_e{
    Low5 = 0,     //Low Level 5
    Low4 = 1,     //Low Level 4
    Low3 = 2,     //Low Level 3
    Low2 = 3,     //Low Level 2
    Low1 = 4,     //Low Level 1
    Nrml = 5,     //Normal Level
    Hgh1 = 6,     //High Level 1
    Hgh2 = 7,     //High Level 2
    Hgh3 = 8,     //High Level 3
    Hgh4 = 9,     //High Level 4
    Hgh5 = 10,    //High Level 5
    Rsrvd11 = 11, //(not defined)
    Rsrvd12 = 12, //(not defined)
    Rsrvd13 = 13, //(not defined)
    Init = 14,    //Init / unknown
    Invld= 15,    //Invalid
};
enum class SuspDrvMod_e{
    Stndrd = 0, //Standard (Default)
    Cmfrt  = 1, //Comfort
    Sport  = 2, //Sport
    Rsrvd3 = 3, //Reserved
    Rsrvd4 = 4, //Reserved
    Rsrvd5 = 5, //Reserved
    Rsrvd6 = 6, //Reserved
    Rsrvd7 = 7, //Reserved
};
enum class SuspAdjMod_e{
    Init   = 0, //Init / Not available
    Normal = 1, //Normal mode
    Srvc   = 2, //Service mode
    Trnsprt= 3, //Transport mode
    Rsrvd4 = 4, //Reserved
    Rsrvd5 = 5, //Reserved
    Rsrvd6 = 6, //Reserved
    Rsrvd7 = 7, //Reserved
}; 
class VEHSUSPN
{
private:
    /* data */
	 unsigned int Lvl[4];                                //@Channel:CHASSIS @Message:0xCC @Signal:FrntLeLvl 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:FrntRiLvl 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:ReLeLvl 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:ReRiLvl
	 bool LvlAdjm[4];                              //@Channel:CHASSIS @Message:0xCC @Signal:RearRiLvlAdjm 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:RearLeLvlAdjm 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:FrntRiLvlAdjm 
                                                            //@Channel:CHASSIS @Message:0xCC @Signal:FrntLeLvlAdjm
	 bool LvlCalCmptl;                          //@Channel:CHASSIS @Message:0xCC @Signal:LvlCalCmptl
	 bool CargoActv;                            //@Channel:CHASSIS @Message:0x28E @Signal:CargoActv
	 SuspLvl_e CrrntLvl;                    //@Channel:CHASSIS @Message:0x28E @Signal:Current_Lvl
	 SuspLvl_e TarLvl ;                    //@Channel:CHASSIS @Message:0x28E @Signal:TarLvl
     bool ExtraHiPosn      ;                    //@Channel:CHASSIS @Message:0x28E @Signal:ExtraHiPosn
	 bool ExtraLoPosn      ;                    //@Channel:CHASSIS @Message:0x28E @Signal:ExtraLoPosn
	 bool EasyEntryEnaSts  ;                    //@Channel:CHASSIS @Message:0x28E @Signal:LC_EasyEntryEnaSts
	 SuspDrvMod_e LvlAdjDrvgMod;           //@Channel:CHASSIS @Message:0x28E @Signal:LvlAdjDrvgMod
	 SuspAdjMod_e LvlAdjMod;               //@Channel:CHASSIS @Message:0x28E @Signal:LvlAdjMod
public:
    VEHSUSPN(/* args */);
    ~VEHSUSPN();
};


