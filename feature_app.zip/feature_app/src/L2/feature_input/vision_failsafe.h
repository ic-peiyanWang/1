#pragma once

#include <stdint.h>

struct FailSafe_s {
  uint32_t FS_Rain;
  uint32_t FS_Fog; /* Fog signal */
  uint32_t FS_Snow;
  uint32_t FS_Full_Blockage;
  uint32_t FS_Partial_Blockage;
  uint32_t FS_Lowsun;
  uint32_t FS_Sunray;
  uint32_t FS_Splash;
  uint32_t FS_Windshield_Frozen; /* Frozen signal*/
  uint32_t FS_Out_Of_Calibration;
  uint32_t FS_Out_Of_Focus;
  uint32_t FS_Blur;
  uint32_t FS_Smeared_Halo;
};

struct FailSafeDetection_s {
  uint64_t timestamp;            // Timestamp_Receive_Image
  FailSafe_s failsafe_FW;        // Front wide
  FailSafe_s failsafe_FN;        // Front narrow
  FailSafe_s failsafe_FL;        // Side front left
  FailSafe_s failsafe_FR;        // Side front right
  FailSafe_s failsafe_R;         // Rear
  FailSafe_s failsafe_RL;        // Side rear left
  FailSafe_s failsafe_RR;        // Side rear right
  FailSafe_s failsafe_SVC_Front; // SVC front
  FailSafe_s failsafe_SVC_Rear;  // SVC Rear
  FailSafe_s failsafe_SVC_Left;  // SVC Left
  FailSafe_s failsafe_SVC_Right; // SVC right

  uint64_t counter;    // message counter
  uint64_t publish_ts; // publish timestamp; unit : nanosecond
};

class VisionFailSafe {
  // private:
public:
  /* data */
  FailSafeDetection_s frontcam_failsafe; // Front camera fail safe detection
public:
  VisionFailSafe(/* args */);
  ~VisionFailSafe();
};
