#pragma once

#include <stdint.h>

class PERCEPTIONFIMINFO {
 private:
 public:
  bool   fim_imu_hw_temporary_error;
  bool fim_imu_hw_perpetual_error;

 public:
  PERCEPTIONFIMINFO();
  ~PERCEPTIONFIMINFO();
};