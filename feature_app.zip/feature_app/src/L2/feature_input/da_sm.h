
#pragma once
#include <stdint.h>

struct HWASMOPIN_S {
  uint8_t St_AccNpSts;
  uint8_t St_Dummy;
  uint8_t St_PilotSt;
  uint8_t St_LongCtrl;
  uint8_t St_LatCtrl;
  uint8_t St_NpStsD;
  uint8_t Ev_SwCruise;
  uint8_t stAccTrgr;
  uint8_t Ev_SwPilot;
  uint8_t stPilotTrgr;
  bool    isInAccMode;
  bool    isInPilotMode;
  bool    isNopActv;
  uint8_t NadSts;
  uint8_t ALCSsts;
  bool    DAActv;
  uint8_t DAFuncSts;
  uint8_t DASdcSts;
  uint8_t DALccSts;
  uint8_t Ev_SwCruise_SetSpd;
  uint8_t Ev_SwPilot_SetSpd;
  bool vlc_actprev_in_lccplus_flg;
  bool is_nop_available_flg;
  bool is_psp_available_flg;
};
class DASM_Info {
  // private:
 public:
  /* data */
  HWASMOPIN_S hwa_sm_op;
  //For EAS: Raw Output From da_state_machine
  HWASMOPIN_S da_hwa_sm_op;
  uint8_t     lat_ctrl_on;
  int32_t     da_req_func_id;
  uint8_t     dummy_da_func_sts;

 public:
  DASM_Info(/* args */);
  ~DASM_Info();
};