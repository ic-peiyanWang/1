
#pragma once
#include <stdint.h>

class NopSpeedLimitValue {
 private:
 public:
  /* data */
  uint32_t nop_speed_limit_value;
  bool     nop_speed_limit_unit;
  uint32_t nop_supsign_type;
  uint32_t nop_sldf_state;

 public:
  NopSpeedLimitValue(/* args */);
  ~NopSpeedLimitValue();
};
