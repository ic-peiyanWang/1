#pragma once

#include <stdint.h>

enum class DMSDrowsinessLevel_e : uint8_t {
  DMS_DROWSINESS_LEVEL_NONE    = 0,  // can not judge if driver is drowsy
  DMS_DROWSINESS_LEVEL_LIGHT   = 1,  // lightly drowsy
  DMS_DROWSINESS_LEVEL_MEDIUM  = 2,  // driver is drowsy in medium level
  DMS_DROWSINESS_LEVEL_HEAVY   = 3,  // driver is drowsy in heavily level
  DMS_DROWSINESS_LEVEL_INVALID = 4,  // cannot judge
};

enum class DMSDistractionLevel_e : uint8_t {
  DMS_DISTRACTION_LEVEL_NONE    = 0,  // can not judge if driver is distracted
  DMS_DISTRACTION_LEVEL_LIGHT   = 1,  // driver is lightly distracted
  DMS_DISTRACTION_LEVEL_MEDIUM  = 2,  // driver is medium distracted
  DMS_DISTRACTION_LEVEL_HEAVY   = 3,  // driver is heavily distracted
  DMS_DISTRACTION_LEVEL_INVALID = 4,  // can not judge if driver is distracted
};

enum class DMSStatus_e : uint16_t {
  NIO_DMS_SUCCESS        = 0,  //!< success
  NIO_DMS_MODULE_UNINIT  = 1,  //!< module uninit
  NIO_DMS_PARAM_INVALID  = 2,  //!< input parameter is invalid
  NIO_DMS_FILE_OPEN_FAIL = 3,  //!< open file failed

  // MDMS config errors
  NIO_DMS_CONFIG_OPEN_FAIL     = 100,  //!< config file open failed
  NIO_DMS_CONFIG_PARSE_FAIL    = 101,  //!< config parse failed
  NIO_DMS_CONFIG_PARAM_MISSING = 102,  //!< the parameter is missing in config file
  NIO_DMS_CONFIG_PARAM_INVALID = 103,  //!< the value of parameter is invalid
  NIO_DMS_CONFIG_MISSING_MODEL = 104,  //!< config missing model file; or model cannot load

  // MDMS license errors
  NIO_DMS_LICENSE_EXPIRE                     = 200,  //!< license expire
  NIO_DMS_LICENSE_UDID_MISMATCH              = 201,  //!< uuid is invalid
  NIO_DMS_LICENSE_ONLINE_ACTIVATE_FAIL       = 202,  //!< online activate failed
  NIO_DMS_LICENSE_ACTIVATIONS_RUN_OUT        = 203,  //!< no need online activate
  NIO_DMS_LICENSE_UNAUTH                     = 204,  //! module is unauthorized
  NIO_DMS_LICENSE_HARDWARE_AUTH_INIT_FAIL    = 205,  //! hardware auth init fail
  NIO_DMS_LICENSE_HARDWARE_AUTH_FAIL         = 206,  //! hardware auth fail
  NIO_DMS_LICENSE_HARDWARE_AUTH_NOTSUPPORTED = 207,  //! not support hardware auth
  NIO_DMS_LICENSE_INVALID                    = 208,  //!< license file is invalid
  NIO_DMS_LICENSE_TOKEN_INVALID              = 209,

  NIO_DMS_FUNC_HANDLE_INVALID          = 300,  //!< input invalid handle called api functions
  NIO_DMS_FUNC_PIXEL_FMT_INVALID       = 302,  //!< the format of input image is invalid
  NIO_DMS_FUNC_MODEL_FMT_INVALID       = 303,  //!< the format of loaded model is invalid
  NIO_DMS_RECOGNITION_FACE_LOW_QUALITY = 400,  //!< recongnition face low quality
  NIO_DMS_RECOGNITION_FACE_NOT_FOUND   = 401,  //!< recongnition face not found; valid face is not detected.
  NIO_DMS_MODULEMANAGER_MODULE_DISABLE = 600,  //!< the module has not been enabled.

  NIO_DMS_INTERNAL_ERROR = 1000,  //!< internal error

  NIO_DMS_NO_STEER_CALIBRATE_TEMPLATE = 1103,
  NIO_DMS_STEER_CALIBRAT_INIT_ERROR   = 1104,

  NIO_DMS_VEHICLE_PARAM_INVALID  = 1106,
  NIO_DMS_STEER_CALIBRATE_FAILED = 1107,
  NIO_DMS_STEER_COLUMN_IS_MOVING = 1108,

  NIO_DMS_IMAGE_STUCK            = 1204,
  NIO_DMS_STRABISMUS_CALIBRATING = 1205,
};
enum class DMSGazeAoi_e : uint8_t {
  DMS_GAZEAOI_FRONT_WINDOWSHILED          = 0,
  DMS_GAZEAOI_FRONT_WINDSHIELD_RIGHT_AREA = 1,
  DMS_GAZEAOI_HUD                         = 2,
  DMS_GAZEAOI_IC                          = 3,
  DMS_GAZEAOI_REAR_MIRROR                 = 4,
  DMS_GAZEAOI_ICS                         = 5,
  DMS_GAZEAOI_LEFT_MIRROR                 = 6,
  DMS_GAZEAOI_LEFT_Window                 = 7,
  DMS_GAZEAOI_RIGHT_MIRROR                = 8,
  DMS_GAZEAOI_RIGHT_Window                = 9,
  DMS_GAZEAOI_NOMI                        = 10,
  DMS_GAZEAOI_INVALID                     = 11,
};

enum class DMSEyeStatus_e : uint8_t {
  DMS_EYE_OPEN    = 0,
  DMS_EYE_CLOSE   = 1,
  DMS_EYE_INVALID = 2,
};

enum class DMSMissTurnWarning_e {
  DMSMissTurnWarning_No_Warning    = 0,
  DMSMissTurnWarning_Warning       = 1,
  DMSMissTurnWarning_Invalid       = 2,
  DMSMissTurnWarning_Reserved      = 3,
};
enum class DMSSteeringTorqueReq_e {
  DMSSteeringTorqueReq_No_Request  = 0,
  DMSSteeringTorqueReq_Request     = 1,
  DMSSteeringTorqueReq_Invalid     = 2,
  DMSSteeringTorqueReq_Reserved    = 3,
};
enum class DMSRoadRageSts_e {
  DMSRoadRageSts_Normal            = 0,
  DMSRoadRageSts_Angry             = 1,
  DMSRoadRageSts_Invalid           = 2,
  DMSRoadRageSts_Reserved          = 3,
};

enum class DMSDefensiveDriveRequest_e {
  DMSDefensiveDrivReq_No_Request                 = 0,
  DMSDefensiveDrivReq_Defensive_Driving_Request  = 1,
  DMSDefensiveDrivReq_Failure                    = 2,
};

enum class DMSDefensiveDriveReason_e {
  DMSDefensiveDriveReason_None                    = 0,
  DMSDefensiveDriveReason_ContinousDrown_Special  = 1,
  DMSDefensiveDriveReason_ContinousDrown_Normal   = 2,
  DMSDefensiveDriveReason_FrequentlyDistract      = 3,
  DMSDefensiveDriveReason_PhoneCall               = 4,
  DMSDefensiveDriveReason_Invalid                 = 15,
};

enum class DMSRiskSceneWarning_e {
  DMSRiskSceneWarning_None                = 0,
  DMSRiskSceneWarning_Warning_Level_1     = 1,
  DMSRiskSceneWarning_Warning_Level_2     = 2,
  DMSRiskSceneWarning_Invalid             = 3,
};

enum class DMSASBVabrationReq_e {
  DMSASBVabrationReq_No_Request           = 0,
  DMSASBVabrationReq_Vabration_Request    = 1,
  DMSASBVabrationReq_Invalid              = 99,
};

enum class DMSOverlayWarning_e {
    DMSOverlayWarning_No_Warning        = 0,
    DMSOverlayWarning_Warning_Level_1   = 1,
    DMSOverlayWarning_Invalid           = 3,
};

enum class DMSDriverInLoop_e {
    DMSDriverInLoopSt_InLoop        = 0,
    DMSDriverInLoopSt_NotInLoop     = 1,
    DMSDriverInLoopSt_Invalid       = 2,
};

class DMS {
  // private:
 public:
  /* data */
  DMSDrowsinessLevel_e  dms_drws_lvl;
  DMSDistractionLevel_e dms_dstr_lvl;
  DMSStatus_e           dms_status;
  bool                  dms_dstr_result_valid;
  float                 dms_dstr_result_conf;
  uint8_t               dms_drws_lvl_da;
  uint8_t               dms_dstr_lvl_da;
  uint8_t               dms_dstr_lvl_short;
  DMSGazeAoi_e          dms_gaze_aoi;
  DMSEyeStatus_e        dms_left_eye;
  DMSEyeStatus_e        dms_right_eye;
  uint8_t               dms_steer_trq_req;
  uint32_t              dms_drws_sts;
  uint32_t              dms_dstr_sts;

// DMSSteeringTorqueReq_e steering_torque_req;
  uint8_t                     dms_driver_in_loop;
  DMSMissTurnWarning_e        dms_miss_turn_warning;
	DMSRoadRageSts_e            dms_road_rage_sts;
	DMSDefensiveDriveRequest_e  dms_defensive_drive_req;
	DMSDefensiveDriveReason_e   dms_defensive_drive_reason;
	DMSRiskSceneWarning_e       dms_static_obj_warning;
	DMSRiskSceneWarning_e       dms_sharp_turn_warning;
	DMSRiskSceneWarning_e       dms_cutin_warning;
	DMSRiskSceneWarning_e       dms_contruction_redwarnsign_warning;
	DMSASBVabrationReq_e        dms_vabration_req;
	DMSOverlayWarning_e         dms_overlay_warning;

 public:
  DMS(/* args */);
  ~DMS();
};
