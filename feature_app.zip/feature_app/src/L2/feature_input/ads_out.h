#pragma once
#include <stdint.h>

struct ParkStInfo {
  uint8_t SApaStatus;     // 3 @Channel:ADAS @Message:0x1AA @Signal:SApaStatus
  uint8_t PSAPHMIStatus;  // 10004 @Channel:ADAS @Message:0x319 @Signal:PSAPHMIStatus
};

class ADSOUT {
 private:
 public:
  /* data */
  uint8_t    vlc_mode;
  ParkStInfo ParkSt;
  uint8_t    eps_req_typ;
  double     vlc_targetacc;
  uint8_t    AEBSts;

 public:
  ADSOUT(/* args */);
  ~ADSOUT();
};
