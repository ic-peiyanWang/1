#pragma once

#include <stdint.h>
#include <vector>

constexpr int kNumVisionDynmicObjects   = 40;
constexpr int kNumVisionStaticObjects   = 20;
constexpr int kNumVisionLaneMarkerPoint = 300;
constexpr int kNumVisionZebraLine       = 4;
constexpr int kNumVisionStopLine        = 4;
constexpr int kNumVisionIntPoint        = 10;
constexpr int kNumVisionRoadEdge        = 4;
constexpr int kNumVisionLaneMarker      = 20;
constexpr int kNumVisionFSPPoint        = 96;
constexpr int kNumVisionSemanticLane    = 10;
constexpr int kNumVisionNoParkZone      = 4;
constexpr int kNumVisionTrafficSign     = 20;
constexpr int kNumVisionTrafficLight    = 10;
constexpr int kNumVisionVehicleLight    = 16;
constexpr int kNumFusionObject          = 128;

enum class LDRole_e {
  LDRole_Unknown              = 0,
  LDRole_Host_Left            = 1,
  LDRole_Host_Right           = 2,
  LDRole_Adjacent_Left_Left   = 3,
  LDRole_Adjacent_Left_Right  = 4,
  LDRole_Adjacent_Right_Left  = 5,
  LDRole_Adjacent_Right_Right = 6
};
enum class LDSpecialPointType_e { LDSpecialPointType_Unknown = 0 };
enum class LDCameraSource_e { LDCameraSource_Unknown = 0 };
enum class LDMeasureStatus_e { LDMeasureStatus_Unknown = 0 };
enum class LDPredictReason_e { LDPredictReason_Unknown = 0 };
enum class LDQuality_e { LDQuality_Unknown = 0 };

enum class LDType_e { LDType_Unknown = 0 };

enum class LDColor_e {
  LDColor_Unknown = 0,
  LDColor_White = 1,
  LDColor_Yellow = 2,
  LDColor_Orange = 3,
  LDColor_Blue = 4,
  LDColor_Others = 5,
  LDColor_Green = 6,
  LDColor_Yellow_White = 7,
  LDColor_White_Yellow = 8
};

enum class LDEndReason_e { LDEndReason_Unknown = 0 };

enum class LPPSource_e { LPPSource_Unknown = 0 };

enum class LDREType_e : uint8_t {
  LDREType_Unknown        = 0,
  LDREType_Crossable      = 1,
  LDREType_Uncrossable    = 2,
  LDREType_RoadEdge       = 3,
  LDREType_Road_Fence     = 4,
  LDREType_Cone           = 5,
  LDREType_Barrier        = 6,
  LDREType_Parked_Vehicle = 7,
  LDREType_Grass          = 8

};

enum class LDREClass_e : uint8_t {
  LDREClass_Unknown        = 0,
  LDREClass_Cement_Block   = 1,   //路牙石
  LDREClass_Fence          = 2,   //护栏
  LDREClass_Cone           = 3,   //锥桶
  LDREClass_Barrel         = 4,   //圆桶
  LDREClass_Barrier        = 5,   //水马
  LDREClass_Parked_Vehicle = 6,   // reserved
  LDREClass_Parked_Cycle   = 7,   // reserved
  LDREClass_Grass          = 8,   // reserved
  LDREClass_gravel         = 9,   // reserved
  LDREClass_ShortPole      = 10,  // reserved
  LDREClass_WallFlat       = 11   //墙面
};

enum class LDRESide_e : uint8_t { LDRESide_Unknown = 0, LDRESide_Left = 1, LDRESide_Right = 2 };

enum class LDREFromHostIndex_e : uint8_t {
  LDREFromHostIndex_Unknown = 0,
  LDREFromHostIndex_First   = 1,
  LDREFromHostIndex_Second  = 2
};
struct VisionPoint_s {
  float lat;  // Lateral distance of the point in the world or x_pixel in the picture. maximum 300 point
  float lon;  // Longitudinal distance of the point in the world or y_pixel in the picture. maximum 300 point
};

struct PolyLine_s {
  float c0;
  float c1;
  float c2;
  float c3;
};

struct LineProperty_s {
  LDType_e      type;
  LDColor_e     color;
  PolyLine_s    line;
  float         start;
  float         end;
  LDEndReason_e end_reason;
};

struct LaneLine_s {
  LDRole_e             role;  //本车道左/本车道右/左左/左右/右右/右左, maximum 5 lanes and 8 lane lines
  LineProperty_s       first_line;
  bool                 is_multi_clothoid;  // Whether it is multi-polynomials
  LineProperty_s       second_line;
  bool                 special_point_is_detected;  // Whether the special point is detected
  LDSpecialPointType_e special_point_type;         // 0:Type 1:Color 2:Merge 3:Split
  VisionPoint_s        special_point;
  VisionPoint_s        point[300];        // kNumVisionLaneMarkerPoint
  VisionPoint_s        pixel_point[300];  // kNumVisionLaneMarkerPoint
  LDCameraSource_e     source;
  float                dash_average_gap;
  float                dash_average_length;
  bool                 crossing;
  unsigned int         crossing_ID;
  LDMeasureStatus_e    measure_status;
  LDPredictReason_e    predict_reason;
  unsigned int         track_ID;
  unsigned int         track_age;
  LDQuality_e          quality;
  float                confidence;
  float                marker_width;
};

struct LaneInfo_s {
  float      host_lane_width;
  bool       crossing_flag;  // The flag of  ego vehicle crosses the lane line
  LaneLine_s lines[20];       // kNumVisionLaneMarker
  bool       eu_construction_area_flag;  // eu_construction_area
};

struct LaneLPP_s {
  bool          available;
  LPPSource_e   source;
  VisionPoint_s lpp_ctrl_point;
  float         confidence;
  bool          first_valid;
  float         first_vr_end;
  PolyLine_s    first_line;
  bool          second_valid;
  float         second_vr_end;
  PolyLine_s    second_line;
};

struct Roadedge_s {
  LDREType_e          type;
  LDRESide_e          side;
  LDREFromHostIndex_e host_index;
  uint32_t            id;
  uint32_t            age;
  float               height;
  float               view_rng_start;
  float               view_rng_end;
  PolyLine_s          line;
  LDREClass_e         re_class;
};

/*
enum class SLType : uint8_t {
  SLType_Unknown               = 0,
  SLType_Normal_StopLine       = 1,
  SLType_Intersection_StopLine = 2,
  SLType_Turning_StopLine      = 3,
  SLType_Zebra_StopLine        = 4
};

enum class SLMeasureStatus : uint8_t {
  SLMeasureStatus_Unknown = 0,
  SLMeasureStatus_View    = 1,
  SLMeasureStatus_Predict = 2
};

enum class SLLaneAssessment : uint8_t {
  SLLaneAssessment_Unknown          = 0,
  SLLaneAssessment_Ego_Lane         = 1,
  SLLaneAssessment_Left_Lane        = 2,
  SLLaneAssessment_Right_Lane       = 3,
  SLLaneAssessment_Left_Left_Lane   = 4,
  SLLaneAssessment_Right_Right_Lane = 5
};
*/

struct StopLine_s {
  bool             SL_Zebra_Is_Detected;
  float            SL_Zebra_Lat_0;
  float            SL_Zebra_Long_0;
  float            SL_Zebra_Lat_1;
  float            SL_Zebra_Long_1;
  float            SL_Zebra_Lat_2;
  float            SL_Zebra_Long_2;
  float            SL_Zebra_Lat_3;
  float            SL_Zebra_Long_3;
  bool             SL_Is_Detected;
  uint32_t         SL_ID;
  uint8_t          SL_Type;
  uint8_t          SL_Measure_Status;
  float            SL_Probability;
  float            SL_Long_Dist_L;
  float            SL_Long_Dist_R;
  float            SL_Lat_Dist_L;
  float            SL_Lat_Dist_R;
  uint8_t          SL_Lane_Assessment;
};

class EHYVisionRoad {
  // private:
 public:
  /* data */
  LaneInfo_s lane;
  LaneLPP_s  lpp;
  Roadedge_s road_edge[4];
  StopLine_s stop_line[4];

 public:
  EHYVisionRoad(/* args */);
  ~EHYVisionRoad();
};

struct RoadSign {
  int roadsign_lane_assign;
  int roadsign_class;
  float center_x;

};

class VisionRoadSign {
public:
  std::vector<RoadSign> road_sign;

public:
  VisionRoadSign();
  ~VisionRoadSign();
};
