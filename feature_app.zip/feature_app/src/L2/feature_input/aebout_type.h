
#pragma once
#include <stdint.h>
/*
message AebOut{
    optional uint32 aba_req     = 1;
    optional uint32 abalvl_req  = 2;
    optional uint32 abp_req     = 3;
    optional uint32 aeb_req     = 4;
    optional float aeb_tar_decel= 5;
    optional uint32 awb_req     = 6;
    optional uint32 awblvl_req  = 7;
    optional uint32 eba_req     = 8;
    optional uint32 aebsts      = 9;
    optional uint32 fcwsetst    = 10;
    optional uint32 prewarnreq  = 11;
    optional uint32 txtinfo     = 12;
    optional uint32 AEBDecelReq_DummyForDVR = 13;
}


*/

struct AebOutInfo_s {
  uint32_t aba_req;
  uint32_t abalvl_req;
  uint32_t abp_req;
  uint32_t aeb_req;
  float    aeb_tar_decel;
  uint32_t awb_req;
  uint32_t awblvl_req;
  uint32_t eba_req;
  uint32_t aebsts;
  uint32_t fcwsetst;
  uint32_t prewarnreq;
  uint32_t txtinfo;
  uint32_t AEBDecelReq_DummyForDVR;
};

enum class Fcts_ELKSts {
  ELKOff     = 0,
  ELKStandby = 1,
  ELKActive  = 2,
  ELKFailure = 3,
};

enum class Fcts_ESFWarnSts {
  ESFNoRequest           = 0,  // no request
  ESFOncomingLeftWarn    = 1,  // Oncoming warning left
  ESFOvertakingLeftWarn  = 2,  // Overtaking warning left
  ESFOncomingRightWarn   = 3,  // Oncoming warning right
  ESFOvertakingRightWarn = 4,  // Overtaking warning right
};

struct Fcts_ELK_LKA_Out {
  Fcts_ELKSts     ELKSts;
  Fcts_ESFWarnSts ESFWarnSts;
  int             LkaSnsvty;
  int             LkaLnAsstSts;
  int             LkaHODWarnSeq;
  int             AdasLeLine;
  int             AdasRiLine;
  bool            is_elk_actv;
  bool            is_lka_actv;
  bool            is_ldw_actv;
  int             elk_intv_case;  // 1-left line, 2-right line, 3-left oncoming, 4- left overtaking, 5-left road edge,
                                  // 6-right road edge 7-right oncoming, 8-right overtaking,
  int             lka_type;       // 1-left line; 2-right line
  int             ldw_type;       // 1-left line; 2-right line
  int             esf_id;        //esf target id
};

class AEBOUT {
 private:
 public:
  /* data */
  AebOutInfo_s     AebOutInfo;
  Fcts_ELK_LKA_Out FctsElkLkaOut;

 public:
  AEBOUT(/* args */);
  ~AEBOUT();
};