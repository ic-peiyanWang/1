#pragma once
#include "veh_enum_type.h"
enum class WhlSpdSts_e{
    Vld   = 0, //Valid
    InVld = 1, //Invalid
    Init  = 2, //Initialization
    Rsrvd3= 3, //Reserved
};
enum class WhlSpdDir_e{
    Stst  = 0, //Standstill
    Frwrd = 1, //Forward
    Bckwrd= 2,//Backward
    InVld = 3, //Invalid
};      
enum class WhlTp_e{
    Nrml = 0,   //Normal Pressure         
    Rsrvd1 = 1, //Reserved         
    Low = 2,    //Low pressure         
    Rsrvd3 = 3, //Description for the value '0x3'          
};

struct WhlDynInfo_s{

	WhlSpdSts_e WhlSpdSts;             //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntLeSts
                                                            //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntRiSts
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReLeSts
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReRiSts

 
    WhlSpdDir_e WhlSpdMovgDir;         //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntLeMovgDir 
                                                            //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntRiMovgDir 
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReLeMovgDir  
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReRiMovgDir

    float  WhlSpd;                         //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntLe 
                                                            //@Channel:CHASSIS @Message:0x58 @Signal:WhlSpdFrntRi 
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReLe 
                                                            //@Channel:CHASSIS @Message:0x59 @Signal:WhlSpdReRi

    QfZeroVld_e WhlPlsCntrVld;           //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrFrntLeVld
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrFrntRiVld
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrReLeVld
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrReRiVld

    unsigned int WhlPlsCntr;                     //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrFrntLe
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrFrntRi
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrReLe
                                                            //@Channel:CHASSIS @Message:0x5A @Signal:WhlPlsCntrReRi	
};
struct WhlTpmsInfo_s{
    unsigned int Press;                          //@Channel:CHASSIS @Message:0x39B @Signal:TpmsFrntLeWhlPress  
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsFrntRiWhlPress 
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsReLeWhlPress 
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsReRiWhlPress

    unsigned int Temp;                           //@Channel:CHASSIS @Message:0x39B @Signal:TpmsFrntLeWhlTemp 
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsFrntRiWhlTemp  
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsReLeWhlTemp 
                                                            //@Channel:CHASSIS @Message:0x39B @Signal:TpmsReRiWhlTemp

    unsigned int SnsrFailSts;                    //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntLeSnsrFailSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntRiSnsrFailSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReLeSnsrFailSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReRiSnsrFailSts

    unsigned int BatSts;                         //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntLeBatSts 
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntRiBatSts 
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReLeBatSts 
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReRiBatSts


    WhlTp_e PressSts;                  //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntLeWhlPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntRiWhlPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReLeWhlPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReRiWhlPressSts

    unsigned int DeltaPressSts;                  //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntLeWhlDeltaPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntRiWhlDeltaPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReLeWhlDeltaPressSts
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReRiWhlDeltaPressSts
    unsigned int TempSts;                        //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntLeWhlTempSts 
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsFrntRiWhlTempSts  
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReLeWhlTempSts 
                                                            //@Channel:CHASSIS @Message:0x2C5 @Signal:TpmsReRiWhlTempSts
};
class VEHWHL
{
private:
public:
    /* data */
	WhlDynInfo_s WhlDyn[4]; //0:FL 1:FR 2:RL 3:RR
	WhlTpmsInfo_s WHlTpms[4]; //0:FL 1:FR 2:RL 3:RR
public:
    VEHWHL(/* args */);
    ~VEHWHL();
};
