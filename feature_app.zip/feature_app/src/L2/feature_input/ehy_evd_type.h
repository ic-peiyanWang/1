#pragma once

#include <stdint.h>

enum class EvdLaneChangeReason_e : uint8_t
{
    kEVD_LCReason_NONE = 0,
    kEVD_LCReason_NAVI = 1,
    kEVD_LCReason_RECL = 2,
    kEVD_LCReason_AVOID = 3,
};

enum class EvdDcsDir_e : uint8_t 
{
    kEVD_DIR_ST = 0,
    kEVD_DIR_LEFT = 1,
    kEVD_DIR_RIGHT = 2,
    kEVD_DIR_INVALID = 127,
};

enum class CurrSpdLmtSrc_e : uint8_t
{
    kEVD_CurrSpdLmtSrc_None = 0,
    kEVD_CurrSpdLmtSrc_Curv = 1,
    kEVD_CurrSpdLmtSrc_TraffFlow = 2,
    kEVD_CurrSpdLmtSrc_FusSt = 3,
    kEVD_CurrSpdLmtSrc_FreeSpace = 4,
    kEVD_CurrSpdLmtSrc_Cone = 5,
};

enum class GFPDirClass_e : uint8_t
{
    kEVD_GFP_Class_NONE = 0,
    kEVD_GFP_Class_IN = 1,
    kEVD_GFP_Class_OUT = 2,
};

enum class EvdDecisionName_e : uint8_t
{
    EVD_DECISION_NONE = 0,
    EVD_DECISION_PILOT = 1,
    EVD_DECISION_RAMP2HW = 2,
    EVD_DECISION_HW2RAMP = 3,
    EVD_DECISION_LANECHANGE = 4,
    EVD_DECISION_PATHSELECT = 5,
    EVD_DECISION_TAKEOVER = 6,
    EVD_DECISION_ALTERNATEPASS = 7,  // close cut-in;
    EVD_DECISION_PILOT2SPEC = 8,
    EVD_DECISION_LEADING = 9,
    EVD_DECISION_MERG2MAINRD = 10,// merging to main road
};


struct EvdParamLaneChange_s {
    EvdDcsDir_e change_dir;
    EvdLaneChangeReason_e lane_change_reason;
};

struct EvdParamPathSelect_s {
    EvdDcsDir_e path_dir;
};

struct EvdParamLeading_s {
    EvdDcsDir_e leading_dir;
};

struct EvdParamTakeover_s {
    uint32_t takeover_src;
    //Takeover source 
    //  0: VD_TAKEOVER_INFO_NONE; 
    //  1: Default
    //  2:NOMOSTRI_SPLIT,NOLANECHANGE_RI_BRANCH,NOLANECHANGE_RI_SOLIDLINE,BADLATLOC_RI_BRANCH
    //  3:NOMOSTLE_SPLIT,NOLANECHANGE_LE_BRANCH,NOLANECHANGE_LE_SOLIDLINE,BADLATLOC_LE_BRANCH 
    //  4:NOLEADING_SPLIT, BADLATLOC_LE_OFFRAMP,BADLATLOC_RI_OFFRAMP
    //  5:NOLANECHANGE_LE_MERGE, BADLATLOC_LE_MERGE 
    //  6:NOLANECHANGE_RI_MERGE, BADLATLOC_RI_MERGE 
    //  7:GEOFENCE  
};

struct EvdParamHW2Ramp_s {
    EvdDcsDir_e ramp_dir;
    float dst2leading;
};

struct EvdParam_s {
    EvdParamLaneChange_s lane_change;
    EvdParamPathSelect_s path_select;
    EvdParamLeading_s leading;
    EvdParamTakeover_s takeover;
    EvdParamHW2Ramp_s hw2ramp;
};


struct EvdGLimit_s {
    uint32_t spd;
    float dist;
    uint32_t valid;
    CurrSpdLmtSrc_e source;
    uint32_t regulation;
};

struct EvdDecsLimit_s {
    bool spd_valid;
    uint32_t spd;
    uint32_t distance_valid;
    float distance;
    uint32_t deadline_valid;
    float deadline;
    EvdGLimit_s curr_limit;
    EvdGLimit_s tar_limit;
};

struct EvdGeofence_s {
    uint32_t valid;
    GFPDirClass_e classification;
    float distance;
    uint32_t type;
};

class EHYEVD
{
//private:
public:
    /* data */
    EvdDecisionName_e decision;
    EvdParam_s parameters;
    EvdDecsLimit_s limitations;
    EvdGeofence_s gfp_info;
public:
    EHYEVD(/* args */);
    ~EHYEVD();
};