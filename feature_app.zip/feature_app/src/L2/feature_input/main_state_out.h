#pragma once

#include <stdint.h>

enum class ACCNPSt_e : uint8_t {
  NpOff = 0,
  NpPassive,
  NpStandby,
  NpAccAct,
  NpAccStby,
  NpPilotAct,
  NpLatUnAvl,
  NpPilotStby,
};
enum class NPStsD_e : uint8_t {
  NpDuOff = 0,
  NpDuPassive,
  NpDuStandby,
  NpDuAccAct,
  NpDuAccStby,
  NpDuPilotAct,
  NpDuLatUnAvl,
  NpDuPilotStby,
  NpDuFail,
  NpDuAccPsv,
  NpDuPilotPsv,
  NpDuNOPAct,
  NpDuPSPStby,
  NpDuPSPAct,
  NpDuUrbanAct
};
enum class DaNadSts_e : uint8_t {
  SysOff = 1,
  SysPsv,
  SysRdy,
  AccStdby,
  PilotStdby,
  AccActv,
  PilotActv,
  PilotLongOnly,
  DaNOPActive,
};
enum class FuncArbSts_e : uint8_t {
  Func_OFF = 0,
  Func_Loaded,
  Func_Checking,
  Func_Standby,
  Func_Running,
};

struct HWASMOP_s {
  ACCNPSt_e St_AccNpSts = ACCNPSt_e::NpOff;
  uint8_t St_Dummy = 0;
  uint8_t St_PilotSt = 0;
  uint8_t St_LongCtrl = 0;
  uint8_t St_LatCtrl = 0;
  NPStsD_e St_NpStsD = NPStsD_e::NpDuOff;
  uint8_t Ev_SwCruise = 0;
  uint8_t stAccTrgr = 0;
  uint8_t Ev_SwPilot = 0;
  uint8_t stPilotTrgr = 0;
  bool isInAccMode = false;
  bool isInPilotMode = false;
  bool isNopActv = false;
  DaNadSts_e NadSts = DaNadSts_e::SysOff;
  uint8_t ALCSsts = 0;
  bool DAActv = false;
  FuncArbSts_e DAFuncSts = FuncArbSts_e::Func_OFF;
  FuncArbSts_e DASdcSts = FuncArbSts_e::Func_OFF;
  FuncArbSts_e DALccSts = FuncArbSts_e::Func_OFF;
};

enum class ACCSt_e : uint8_t {
  AccOff = 0,
  AccPassive,
  AccStandby,
  AccActive,
  AccBrakeonly,
  AccOverride,
  AccStandstill,
  AccFailure,
};
enum class ACCSysSt_e : uint8_t {
  AS_OFF = 0,
  AS_INACT,
  AS_ACT,
  AS_FAIL,
};

struct ACC_SmCdn_s {
  bool SysOn;
  bool SysOff;
  bool SysPassive;
  bool SysStby;
  bool SysFailRev;
  bool SysFailIrrev;
  bool SysActivation;
  bool SysStSt;
  bool SysDrvOff;
  bool SysBrkOnly;
  bool SysOverride;
  bool SysStby2Ovrd;
  bool ActPrev;
  bool ResuPrev;
  bool SoftInh;
  bool HardInh;
  bool Act2Stby;
  bool NonSwStby;
  bool Act2StByStTimer;
  bool ResuByGasPdl;
  bool ImmediateOff;
  bool FaultDeact;
  bool SysStBrkOnly;
  bool LatFault;
  bool PilotFaultDeactv;
  bool NpActPrev;
  bool NpResuPrev;
  bool NpSysPsv;
  bool LcSysPsv;
  bool SysNpDirStby;
  bool Activated;
  double StstTime;
  bool DrvrCmplied;
  bool DrvOpCancelResm;
  bool flgEasHardInh;
};

struct Hwa_SmCdn_s {
  bool SwCruise = false;
  bool SwPilot = false;
  bool SwResume = false;
  bool SysInit = false;
  bool SysNoInit = false;
  bool ActPrev = false;
  bool ResuPrev = false;
  bool LonInh = false;
  bool LatInh = false;
  bool LonStby = false;
  bool Act2StByStTi = false;
  bool ResuByGasPdl = false;
  bool SysDrvOff = false;
  bool NonSwStby = false;
  bool ActByOvrd = false;
  bool SysPsv = false;
  bool FaultDeact = false;
  bool SysBrkOnly = false;
  bool LatSprAccSts = false;
  bool LatFaultDeactv = false;
  bool AccCfgd = false;
  bool PilotCfgd = false;
  bool OneButtonOn = false;
  uint8_t SwMode = 0;
  bool HodSpr = false;
  bool NpActPrev = false;
  bool NpResuPrev = false;
  bool NpSysPsv = false;
  bool LcSysPsv = false;
  bool Activated = false;
  bool LatFault = false;
  bool Pilot2Nop = false;
  bool Nop2Pilot = false;
  bool flgNopOn = false;
  bool flgMapIsRdy = false;
  bool InGeoFence = false;
  bool AmcLksOff = false;
  bool AmcLksSprs = false;
  bool SwAmcLks = false;
  bool ADCSysFailure = false;
  bool SteerAsstActv = false;
  bool DrvrDeactv = false;
  bool EasActv = false;
  bool DAEDRFaultFlg = false;
  bool Resm_DrvrDeactv = false;
  bool DrvOpCancelResm = false;
  uint8_t DAInhibitForNop = 0;
  bool CloudNopOffCmd = false;
  bool flgNotInDrive = false;
};

struct DrvPrsntWarn_s {
  uint32_t PsngDrL1;
  bool DrvDrL1;
  bool DrvStBltL1;
  bool DrvStOccL1;
  bool DrvPrsntSI;
};

enum class EDASt_e : uint8_t {
  EDAPassive = 0,
  EDAStandby,
  EDAActive,
  EDAFailure,
  EDAFault,
};

struct EDAInfo_s {
  EDASt_e EDASts;
  uint8_t EDADecSts;
  bool EDAVehStst;
  FuncArbSts_e EDAFuncSt;
  bool EDAActv;
};

struct BrkSysAD_s {
  bool ABANoAvl;
  bool ABPNoAvl;
  bool AWBNoAvl;
  bool BrkFldWarn;
  bool BrkPdlWearWarn;
  bool BrkPdlTrvlCalErr;
  bool BrkOverHeat;
  bool BrkLgtErr;
  bool EBDFailLampOn;
  bool VMCLgtDecCpLmt;
  bool VDCTCSFailLampOn;
};
struct DrvAttntAvl_s {
  bool Dstrc;
  bool Drws;
  bool Drws_lvl1;
  bool Drws_lvl2;
};
struct VehStbAD_s {
  bool TcsDeactivated;
  bool VdcDeactivated;
  bool DTCNotAvailable;
  bool ARPDisabled;
  bool VDCTCSLampOn;
};
struct FctFim_s {
  bool is_acm_fault;
  bool is_bcm_fault;
  bool is_scm_fault;
  bool is_dms_fault;
  bool is_f30_fault;
  bool is_radfc_fault;
  bool is_radfs_fault;
  bool is_radrs_fault;
  bool is_camfs_fault;
  bool is_camrs_fault;
  bool is_svc_fault;
  bool is_apa_fault;
  bool is_bgw_fault;
  bool is_failsafelidar_fault;
  bool is_gnss_fault;
  bool is_hodsensor_fault;
  bool is_DaAdClassified_fault;
};

struct SoftInhWTI_AD_s {
  uint32_t HrTrkAjar;
  bool OverMaxDispSpdLmt;
  BrkSysAD_s BrkSysAD;
  DrvAttntAvl_s DrvAttntAvl;
  VehStbAD_s VehStb;
  FctFim_s FctFim;
  bool HODErrSts;
  bool DmsHodInstFb;
  double DistrWithFt;
  bool VMCLgtAccCpAD;
  bool flgAAappFimAD;
  bool LampandWiperAD;
};

struct BrkSysTD_s {
  bool ABANoAvl;
  bool ABPNoAvl;
  bool AWBNoAvl;
  bool BrkFldWarn;
  bool BrkPdlWearWarn;
  bool BrkPdlTrvlCalErr;
  bool BrkOverHeat;
  bool BrkLgtErr;
  bool EBDFailLampOn;
  bool VMCLgtDecCpLmt;
  bool VDCTCSFailLampOn;
};
struct VehStb_s {
  bool AbsActive;
  bool TcsActive;
  bool VdcActive;
  bool DtcActive;
  bool ARPActive;
  bool TcsDeactvdEscl;
  bool VdcDeactvdEscl;
  bool DTCNotAvlEscl;
  bool ARPDisabledEscl;
  bool VDCTCSLampOnEscl;
};
struct FctFimTD_s {
  bool is_lidar_overheating;
  bool is_lidar_blocked;
  bool is_eps_fault;
  bool is_bcu_fault;
  bool is_can_bus_off;
  bool is_vcu_fault;
  bool is_swc_fault;
  bool is_cdc_fault;
  bool is_mcu_fault;
  bool is_percepapp_fault;
  bool is_power_fault;
  bool is_soc1adp_fault;
  bool is_soc2dcb_fault;
  bool is_soc3adb_fault;
  bool is_soc4ads_fault;
  bool is_othercan_fault;
  bool is_f30_fault;
  bool is_f120_fault;
  bool is_lidar_fault;
  bool is_radfc_fault;
  bool is_svc_fault;
  bool is_windcalibra_fault;
  bool is_frontCam_lidar_fault;
  bool is_acm_fault;
  bool is_bcm_fault_escl;
  bool is_scm_fault_escl;
  bool is_dms_fault_escl;
  bool is_f30_fault_escl;
  bool is_radfc_fault_escl;
  bool is_radfs_fault_escl;
  bool is_radrs_fault_escl;
  bool is_camfs_fault_escl;
  bool is_camrs_fault_escl;
  bool is_svc_fault_escl;
  bool is_apa_fault_escl;
  bool is_bgw_fault_escl;
  bool is_failsafelidar_fault_escl;
  bool is_gnss_fault_escl;
  bool is_hodsensor_fault_escl;
};
struct FctFailSafeTD_s {
  bool is_Lidar_FailSafe;
  bool is_CamFW_FailSafe;
  bool is_CamFN_FailSafe;
};
struct SoftInhWTI_TD_s {
  uint32_t PsngDrUnLock;
  bool FLDoorOpen;
  bool FLSeatBltUnbck;
  BrkSysTD_s BrkSysTD;
  DrvAttntAvl_s DrvAttntAvl;
  VehStb_s VehStb;
  FctFimTD_s FctFimTD;
  bool HODErrSts;
  bool DmsHodInstFb;
  double DistrWithFt;
  bool CDCStsNokTD;
  FctFailSafeTD_s FctFailSafeTD;
  bool DAINotAvlTD;
  bool SwcFault;
  bool VMCLgtDecCpTD;
  bool CDPActv;
  bool VMCLgtAccCpTD;
  bool flgAAappFimTD;
  bool LampandWiperTD;
};

struct SoftInhWTI_s {
  SoftInhWTI_AD_s AD;
  SoftInhWTI_TD_s TD;
};

struct AEBRelated_s {
  bool ABAActv;
  bool ABPActv;
  bool AWBActv;
};
struct ActPrevWTI_s {
  bool DriverBrake;
  AEBRelated_s AEBRelated;
  bool DmsDrvDistracted;
  bool mHandsOffDetd;
  bool ECOPlusModSts;
  bool DrvOvrdStrWhl;
  bool TowModActv;
  bool DSRActv;
  bool TrailerModSprs;
  bool ElkActv;
  bool ESPActPrev;
  bool DMSOccludedActPrev;
  bool ESPActPrevWoDAIAvl;
};

struct flgEASWTITrigger_s {
  bool flgEasHardInh;
  bool flgEASCrashDetd;
  bool flgEASDrvLeavingSeat;
};
struct NOPCdn_out_s {
  bool NOPActivationPrevention;
  bool NOPSuppression;
  bool DAMainReqDAnbc;
};

class MainStateOut {
  // private:
public:
  /* data */
  HWASMOP_s HwaStatus;
  ACCSt_e AccStatus;
  ACCSysSt_e AccSysSt;
  bool AccActivated;
  ACC_SmCdn_s Cdn;
  Hwa_SmCdn_s NpCdn;
  bool DrvSwitchedOff;
  bool NPLatFailForSymbol;
  DrvPrsntWarn_s DrvPrsntWarn;
  EDAInfo_s EDAInfo;
  bool FIM_SoftInhi;
  bool FIM_HardInhi;
  uint8_t ADCPlatformFailSts;
  bool LatCtrlOn;
  SoftInhWTI_s SoftInhWTI;
  ActPrevWTI_s ActPrevWTI;
  bool AtntDmdSoftInh;
  bool TkovDmdSoftInh;
  uint8_t VlcReqFct;
  bool EmergBrking;
  bool EasTrgHardInh;
  uint32_t DAReqFuncID;
  FuncArbSts_e DummyDAFuncSts;
  flgEASWTITrigger_s flgEASWTITrigger;
  NOPCdn_out_s NOPCdn_out;

public:
  MainStateOut(/* args */);
  ~MainStateOut();
};