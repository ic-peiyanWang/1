#pragma once

#include <stdint.h>

enum class LaneLocStatus_e {
  LaneLocStatus_Inside_Road     = 0,
  LaneLocStatus_Outside_Road    = 1,
  LaneLocStatus_Outside_Road_LE = 2,
  LaneLocStatus_Outside_Road_RI = 3,
};

struct LaneLoc_s {

  LaneLocStatus_e lane_loc_status;
  uint64_t        curr_link_id;
  uint64_t curr_lane_id;  // Actually equals to sequence_id in map engine, representing the number of current lane, the
                          // right-most lane is 0
  int32_t hdmap_version;  // Version of HDmap
  float   lane_lat_offset;  // Lateral distance to central line of current  lane
  float   link_offset;      // [0, 1] indicates the offset along current link
};

struct AuxiliaryParkingInfo_s {
  int32_t is_in_map_area;   // Whether in low-speed localization area
  int32_t lidar_mm_status;  // Lidar map matching status
  int32_t svc_mm_status;    // SVC map matching status
};

class GLOBALLOCALIZATION {
 private:
 public:
  LaneLoc_s              lane_loc;
  AuxiliaryParkingInfo_s auxiliary_parking_info;

 public:
  GLOBALLOCALIZATION(/* args */);
  ~GLOBALLOCALIZATION();
};

