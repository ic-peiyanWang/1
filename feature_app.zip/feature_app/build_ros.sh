#!/bin/bash
SCRIPTPATH="$(
	cd "$(dirname "$0")"
	pwd -P
)"

# Define the container name
CONTAINER_NAME=mazu-build-ros-msg-$(whoami)
IMAGE_NAME=adas-hub.nioint.com/ros/message_converter:proto2msg2py-0.0.1

# Clean command
if [ "$1" == "clean" ]; then
	docker stop $CONTAINER_NAME
	docker rm $CONTAINER_NAME
	rm -rf build_ros
	exit 0
fi

# Outside container: create container and execute command inside it
# Create container
docker ps | grep -c $CONTAINER_NAME >/dev/null
if [ $? -ne 0 ]; then
	echo "No ros build container found. creating..."
	#==================================================================

	set -e

	echo "container not exists"
	docker run -d -t \
		--name $CONTAINER_NAME \
		-v $SCRIPTPATH:/feature_app \
		$IMAGE_NAME

	docker exec -u root $CONTAINER_NAME bash -c " \
			mkdir -p /home/$USER && \
			groupadd -g $(id -g) mazu && \
			useradd -d /home/$USER -s /bin/bash -u $(id -u) -g $(id -g) $USER && \
			chown -R $USER /home/$USER && \
			chown -R $USER /ws && \
			chgrp -R mazu /ws && \
			echo 'Done.' \
			"

	echo "Container setup accomplished."

	set +e
	#==================================================================
fi

if [ "$1" == "shell" ]; then
	docker exec -it -u $USER -w /feature_app $CONTAINER_NAME /bin/bash
elif [ "$1" == "make" ]; then
	docker exec -u $USER -w /feature_app $CONTAINER_NAME bash /ws/convert.sh
else
	error "unknown command: $1"
	error
	exit 1
fi
