# echo "pre build proto"
# MAZU_INTEGRATION=https://mazu.nioint.com/shared/Force_BL0.7.0-RC1/integration/aarch64/integration-220128.1825-aarch64-release-96199cb.tar.gz MAZU_MESSAGES=https://mazu.nioint.com/shared/Force_BL0.7.0-RC1/mazu_messages/aarch64/mazu_messages-main-220126.1558-aarch64-release-5ea103e.tar.gz  MAZU_ARCH=aarch64 ./build_msg.sh make
# ./build_msg.sh clean
# ./build_msg.sh make aarch64 release