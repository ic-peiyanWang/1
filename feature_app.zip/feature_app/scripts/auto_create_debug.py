#!/usr/bin/env python3
# coding: utf-8

import argparse
import os
from os import close
import re

# 每一行只能定义一个变量

parser = argparse.ArgumentParser(description = 'create obsercation file',
            usage = 'python3 auto_create_observations.py -f <file1.cpp> [file2.cpp] -p <output.proto> -c <output_mapping.cpp> ')
parser.add_argument('-f', '--files', type=str, dest = 'files', help = "input file list", nargs = '+', required=True)
parser.add_argument('-p', '--proto', type=str, dest = 'proto_file', help = "output proto file", required=True)
parser.add_argument('-c', '--cpp'  , type=str, dest = 'cpp_file'  , help = "output cpp file"  , required=True)
args = parser.parse_args()

def line_correction(line):
    # 去掉注释，回车和分号
    while line[-1] != ';':
        line = line[:-1]
    line = line[:-1]
    # 去掉 MES_VAR和后面的空格
    line = line[7:]
    line = line.strip()
    return line

def generator(filename):
    output_dict = []
    output_lines = []
    with open(filename, "r") as input_file:
        input_lines = input_file.readlines()
        for line in input_lines:
            # 去掉前后的空格
            line = line.strip()
            if not re.match("^MES_VAR.*", line) == None:
                output_lines.append(line_correction(line))
        # print(*output_lines, sep='\n')
    for line in output_lines:
        # 匹配第一个空格前的type
        dict = {}
        type = re.match("([^\s]+)", line)
        dict["data_type"] = line[:type.end()]
        line = line[type.end():]
        line = line.strip()
        # 数组处理
        if (line[-1] == ']'):
            dict["is_array"] = True
            while(line[-1] != '['):
                line = line[:-1]
            line = line[:-1]
        else:
            dict["is_array"] = False
        name = re.match("(?:^|[\s/+*(-])([A-Za-z_]+[A-Za-z_0-9]*)(?=[\s+/*)-]|$)", line)
        dict["data_name"] = line[:name.end()]
        output_dict.append(dict)
    return output_dict, output_lines

total_dict = []
for item in args.files:
    output_dict, output_lines = generator(item)
    total_dict += output_dict

# 统一type name
to_bool = ['boolean_T']
to_uint32 = ['int8_T', 'uint8_T', 'int16_T', 'uint16_T', 'int32_T', 'uint32_T']
to_float = ['real32_T']
to_double = ['real_T']
for i in range(total_dict.__len__()):
    # if re.match("(ACCSA_|ACCCT_|ACCSC_|HWASM_|HWA_|LatCtrl_|Mtn_|LDW_|LKA_)", total_dict[i]['data_name']) != None:
    if to_bool.count(total_dict[i]['data_type']) != 0:
        total_dict[i]['data_type'] = "bool"
    if to_uint32.count(total_dict[i]['data_type']) != 0:
        total_dict[i]['data_type'] = "uint32"
    if to_float.count(total_dict[i]['data_type']) != 0:
        total_dict[i]['data_type'] = "float"
    if to_double.count(total_dict[i]['data_type']) != 0:
        total_dict[i]['data_type'] = "double"

key_worlds = ["ACCSA_", "ACCCT_", "ACCSC_", "HWASM_", "HWA_", "LatCtrl_","ELKCT_","ELKH_","ELKSS_","Mtn_", "LDW_", "LKA_", "ME_"]
type_worlds = ["bool", "uint32", "float", "double"]
enum_type_worlds = ['DBADrvType_e',
                    'GpTp_e',
                    'ACCSt_e',
                    'ACCSysSt_e',
                    'AccOvrtkCtlSt_e',
                    'AccOvrtkSt_e',
                    'LongCtrl_LineSource_e',
                    'EDASt_e',
                    'LohmImpsbSt_e',
                    'ACCNPSt_e',
                    'NPStsD_e',
                    'NPSwSt_e',
                    'AmcLksSysSt_e',
                    'NopSts_e',
                    'IsaSts_e',
                    'ActvLaneChgTarSt_e',
                    'NopLaneChgSm_e',
                    'ELKCase_e',
                    'ELKZone_e',
                    'ELKLaneCase_e',
                    'ELKSprsSts_e',
                    'CsfHoWS_e',
                    'LatCtrlSt_e',
                    'PilotLnDeptWarnSprsSts_e',
                    'NopMsg_e',
                    'LohLineDtctdSt_e',
                    'LohPssblSt_e',
                    'LohOccpdSt_e',
                    'ELKSts_e',
                    'LaneAssistSts_e',
                    'AlcMnvr_e',
                    'LKSSt_e',
                    'FuncArbSts_e',
                    'TauGapChgDisp_e',
                    'DaNadSts_e',
                    'ELKFAMSts_e',
                    'FuncArbReqSts_e',
		    'FuncSts_e'
                    ]

if os.path.exists(args.proto_file):
    print("the proto file is already exits, no more process")
else:
    with open("../build/auto_gen_proto/"+args.proto_file, "a") as out_file:
        out_file.writelines("syntax = \"proto2\";\n")
        out_file.writelines("package nio.ad.messages.debug;\n\n")

        for key_world in key_worlds:
            out_file.write("message " + key_world + "DebugOut{\n")
            count = 1
            for item in total_dict:
                if (item['data_type'] not in type_worlds and
                     item['data_type'] not in enum_type_worlds):
                    continue
                if (re.match("(" + key_world + ")", item['data_name']) != None):
                    if item['is_array']:
                        out_file.write("    repeated ")
                    else:
                        out_file.write("    optional ")
                    if item['data_type'] in enum_type_worlds:
                        out_file.write('uint32' + ' ' + item['data_name'] + ' = ' + str(count) + ";\n")
                    else:
                        out_file.write(item['data_type'] + ' ' + item['data_name'] + ' = ' + str(count) + ";\n")

                    count += 1
            out_file.write("}\n\n")

if os.path.exists(args.cpp_file):
    print("the proto file is already exits, no more process")
else:
    with open("../build/auto_gen_proto/"+args.cpp_file, "a") as out_file:
        out_file.writelines('#include "' + args.cpp_file[:-4] + '.h"\n\n')
        out_file.writelines("namespace nio {\n")
        out_file.writelines("namespace ad {\n")
        out_file.writelines("namespace fctapp {\n")
        out_file.writelines("\n")


        for key_world in key_worlds:
            out_file.write("void " + key_world.lower() + "debug_proc(FCTDebugOut& fct_debug_out){\n")
            for item in total_dict:
                if (item['data_type'] not in type_worlds and
                     item['data_type'] not in enum_type_worlds):
                    continue
                if (re.match("(" + key_world + ")", item['data_name']) != None):
                    out_file.write("    fct_debug_out.mutable_" + key_world.lower() + "debug_out()->")
                    if item['is_array']:
                        out_file.write("add_")
                        if item['data_type'] in enum_type_worlds:
                            # out_file.write(item['data_name'].lower() + '(static_cast<nio::ad::messages::debug::' + item['data_type'] + '>(' + item['data_name'] + '[0]));\n')
                            out_file.write(item['data_name'].lower() + '(static_cast<uint32_t>(' + item['data_name'] + '[0]));\n')
                        elif item['data_type'] is 'uint32':
                            out_file.write(item['data_name'].lower() + '(static_cast<' + item['data_type'] + '_t>(' + item['data_name'] + '[0]));\n')
                        else:
                            out_file.write(item['data_name'].lower() + '(static_cast<' + item['data_type'] + '>(' + item['data_name'] + '[0]));\n')
                    else:
                        out_file.write("set_")
                        if item['data_type'] in enum_type_worlds:
                            # out_file.write(item['data_name'].lower() + '(static_cast<nio::ad::messages::debug::' + item['data_type'] + '>(' + item['data_name'] + '));\n')
                            out_file.write(item['data_name'].lower() + '(static_cast<uint32_t>(' + item['data_name'] + '));\n')
                        elif item['data_type'] is 'uint32':
                            out_file.write(item['data_name'].lower() + '(static_cast<' + item['data_type'] + '_t>(' + item['data_name'] + '));\n')
                        else:
                            out_file.write(item['data_name'].lower() + '(static_cast<' + item['data_type'] + '>(' + item['data_name'] + '));\n')

            out_file.write('}\n\n')

        out_file.writelines("void fct_debug_output_processing(FCTDebugOut& fct_debug_out) {\n")
        for key_world in key_worlds:
            out_file.write("    " + key_world.lower() + "debug_proc(fct_debug_out);\n")
        out_file.writelines("}\n\n")

        out_file.write("}\n}\n}\n")

for item in total_dict:
    if (item['data_type'] not in type_worlds and
         item['data_type'] not in enum_type_worlds):
        print(item)
