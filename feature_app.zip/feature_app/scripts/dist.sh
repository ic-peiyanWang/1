MAZU_ARCH=$1
MAZU_TYPE=$2
CI_FLAG=$3
DIST_DIR=$4

mkdir -p ${DIST_DIR}/bin
mkdir -p ${DIST_DIR}/lib
mkdir -p ${DIST_DIR}/conf/discovery
mkdir -p ${DIST_DIR}/.debug

cp src/L2/fct_app/fct_app                       ${DIST_DIR}/bin
cp src/L2/fcts_app/fcts_app                     ${DIST_DIR}/bin
cp src/L2/feature_input/libfeature_input.so     ${DIST_DIR}/lib
cp src/L2/feature_diag/libfeature_diag.so       ${DIST_DIR}/lib
if [[ "${MAZU_ARCH}" == "aarch64" ]]; then
cp ../../src/L2/fct_app/cal/lib/aarch64/*.so            ${DIST_DIR}/lib
else
cp ../../src/L2/fct_app/cal/lib/x86/*.so            ${DIST_DIR}/lib
fi

cp ../../src/L2/fct_app/cal/conf/*.pb.txt       ${DIST_DIR}/conf
cp ../../src/L2/conf/discovery/*.pb       ${DIST_DIR}/conf/discovery

if [[ "${MAZU_TYPE}" == "debug" ]] || [[ "${MAZU_TYPE}" == "Debug" ]]; then
    mkdir -p ${DIST_DIR}/a2l
    cd ../../src/L2/fct_app/a2l/scripts/
    ./gen.sh ${MAZU_ARCH} ${MAZU_TYPE}
    ./clean.sh
    cd ../../../../../build/${MAZU_ARCH}

    cd ../../src/L2/fcts_app/a2l/scripts/
    ./gen.sh ${MAZU_ARCH} ${MAZU_TYPE}
    ./clean.sh
    cd ../../../../../build/${MAZU_ARCH}
fi

# # symbol table
# if [[ "$MAZU_SYMBOL_TABLE" == "true" ]] && [[ "${MAZU_TYPE}" == "release" ]] || [[ "${MAZU_TYPE}" == "Release" ]]; then
#     cp src/L2/fct_app/fct_app.debug                  ${DIST_DIR}/.debug
#     cp src/L2/arb_app/arb_app.debug                  ${DIST_DIR}/.debug
#     cp src/L2/feature_input/libfeature_input.debug   ${DIST_DIR}/.debug
#     cp src/L2/feature_diag/libfeature_diag.debug     ${DIST_DIR}/.debug
# fi
