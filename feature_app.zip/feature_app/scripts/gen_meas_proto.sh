# !usr/bin/bash
if [ ! -d "../build/auto_gen_proto/" ];then
  mkdir -p ../build/auto_gen_proto/
else
  rm -r ../build/auto_gen_proto/
  mkdir -p ../build/auto_gen_proto/
fi
python auto_create_debug.py -f ../src/L2/fct_app/feature_autogen/lon_ctrl/src/LongCtrl.cpp \
                               ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKS_LCA.cpp \
			       ../src/L2/fct_app/feature_autogen/ldw/src/Signal_LDW.cpp \
                               ../src/L2/fct_app/param/src/fct_me_param.cpp \
                               ../src/L2/fct_app/feature_autogen/lat_ctrl/src/ELKCore.cpp \
                               ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LCACore.cpp \
                               ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKACore.cpp \
                               ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKSCore.cpp \
                               ../src/L2/fct_app/feature_autogen/mtn_sal/src/MtnCtrl_SAL.cpp \
                               -p dgb_fct.proto -c fct_debug_out_proc.cpp
python auto_create_dlb.py -f ../src/L2/fct_app/feature_autogen/lon_ctrl/src/LongCtrl.cpp \
                             ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKS_LCA.cpp \
                             ../src/L2/fct_app/feature_autogen/ldw/src/Signal_LDW.cpp \
                             ../src/L2/fct_app/param/src/fct_me_param.cpp \
                             ../src/L2/fct_app/feature_autogen/lat_ctrl/src/ELKCore.cpp \
                             ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LCACore.cpp \
                             ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKACore.cpp \
                             ../src/L2/fct_app/feature_autogen/lat_ctrl/src/LKSCore.cpp \
                             ../src/L2/fct_app/feature_autogen/mtn_sal/src/MtnCtrl_SAL.cpp \
                             -p fct_dlb.proto -c fct_dlb_out_proc.cpp
