#pragma once
#include <functional>
#include <unordered_map>
#include <mutex>
#include <signal.h>

namespace nio {
namespace pnc {
class SignalHandler {
public:
    using HandlerFuncType = std::function<void()>;
    int32_t add(int32_t, HandlerFuncType);
private:
    void register_handler(int32_t);
    static void handler_entry(int sig, siginfo_t* info, void* ucontext);
};
}
}
