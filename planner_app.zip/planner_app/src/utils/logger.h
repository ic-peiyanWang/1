#pragma once
#include "dylog/dylog.h"

#define NIO_LOGD DYN_LOG_DEBUG("pnc_app")
#define NIO_LOGI DYN_LOG_INFO("pnc_app")
#define NIO_LOGW DYN_LOG_WARNING("pnc_app")
#define NIO_LOGE DYN_LOG_ERROR("pnc_app")
#define NIO_LOGF DYN_LOG_FATAL("pnc_app")

#define NIO_LOGD_EVERY_N(n) DYN_LOG_DEBUG_EVERY_N("pnc_app", n)
#define NIO_LOGI_EVERY_N(n) DYN_LOG_INFO_EVERY_N("pnc_app", n)
#define NIO_LOGW_EVERY_N(n) DYN_LOG_WARNING_EVERY_N("pnc_app", n)
#define NIO_LOGE_EVERY_N(n) DYN_LOG_ERROR_EVERY_N("pnc_app", n)
#define NIO_LOGF_EVERY_N(n) DYN_LOG_FATAL_EVERY_N("pnc_app", n)
