#include "signal_handler.h"
#include "logger.h"

namespace nio {
namespace pnc {
std::mutex mutex;
std::unordered_map<int32_t, SignalHandler::HandlerFuncType> handlers{};
int32_t SignalHandler::add(int32_t signal, HandlerFuncType func) {
    auto&& lock = std::unique_lock(mutex);
    auto&& ret = handlers.insert_or_assign(signal, func);
    if (ret.second)
        register_handler(signal);
    return 0;
}
void SignalHandler::register_handler(int32_t signal) {
    struct sigaction act {};
    act.sa_handler = nullptr;
    act.sa_sigaction = &handler_entry;
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, signal);
    act.sa_mask = set;
    act.sa_flags = SA_SIGINFO | SA_ONSTACK;
    auto&& ret = sigaction(signal, &act, nullptr);
    if (ret) {
        NIO_LOGE << "register signal handler for " << signal << " fail, ret " << ret;
        return;
    }
    NIO_LOGI << "register signal handler for " << signal << " succeeds";
}
void SignalHandler::handler_entry(int32_t signal, siginfo_t* info, void* ucontext) {
    auto&& lock = std::unique_lock(mutex);
    auto&& it = handlers.find(signal);
    if (handlers.end() == it)
        return;
    it->second();
}
}
}
