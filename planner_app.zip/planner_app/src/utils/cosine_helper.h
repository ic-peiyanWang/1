#pragma once
#include "cosine.hpp"
#include <stdint.h>
#include <string>
#include <future>
#include <mutex>
// #include "niodds/messaging/cyber_node.h"

namespace nio {
namespace pnc {
class CosineHelper {
public:
    int32_t initial(const std::string& dir, const std::string& pod, const std::string& node);
    int32_t stop();
    void wait();
private:
    std::string app{};
    nio::cosine::cosineService* cosine_instance;
    std::promise<void> promise;
    // std::unique_ptr<nio::ad::Node> dds_node{};
    std::once_flag stop_flag;
};
}
}
