#include "minidump.h"
#include <filesystem>
#include <set>
#include <mutex>
#include <algorithm>
#include "logger.h"
#ifndef __x86_64__
#if USE_DCS_SDK
#include "dcs_function_interface.h"
#endif
#endif

namespace nio {
namespace pnc {
#ifdef __x86_64__
int32_t Minidump::init(const std::string& , const std::string& ) { return 0; }
#else
#if USE_DCS_SDK
int32_t Minidump::init(const std::string& , const std::string& ) {
    dcs::DcsFunctionInterface::Instance()->Minidump();
    return 0;
}
#else
bool callback(const google_breakpad::MinidumpDescriptor& , void* , bool );
std::string minidump_path{}, app_name{};
std::once_flag flag;
constexpr const size_t max_minidump_file_num = 100;
constexpr const char* const minidump_file_extension = ".dmp";
int32_t Minidump::init(const std::string& path, const std::string& binary) {
    std::call_once(flag, [this, &path, &binary]() {
        std::error_code ec;
        if (!std::filesystem::create_directories(path, ec) && ec) {
            NIO_LOGE << "create_directory for minidump fail: path " << path << ", error code " << ec.value();
            return -1;
        }
        minidump_path = path;
        app_name = binary;
        google_breakpad::MinidumpDescriptor descriptor(path.c_str());
        m_handler = std::make_unique<google_breakpad::ExceptionHandler>(
            /*descriptor=*/descriptor,
            /*filter=*/nullptr,
            /*callback=*/callback,
            /*callback_context=*/nullptr,
            /*install_handler=*/true,
            /*server_fd=*/-1);
        return 0;
    });
    return 0;
}
bool callback(const google_breakpad::MinidumpDescriptor& descriptor, void* context, bool succeeded) {
    std::error_code ec;
    auto&& target_pos = minidump_path + "/" + app_name + "." + std::to_string(time(nullptr)) + minidump_file_extension;
    std::filesystem::rename(descriptor.path(), target_pos, ec);
    if (ec)
        NIO_LOGE << "move file from " << descriptor.path() << " to " << target_pos << " fail, error_code " << ec.value();
    auto&& files = std::filesystem::directory_iterator(minidump_path);
    auto&& size = static_cast<decltype(max_minidump_file_num)>(
        std::distance(std::filesystem::begin(files), std::filesystem::end(files)));
    if (max_minidump_file_num >= size)
        return succeeded;
    auto&& comp = [](auto&& lhs, auto&& rhs) {
        return lhs.last_write_time() < rhs.last_write_time();
    };
    std::set<std::filesystem::directory_entry, std::decay_t<decltype(comp)>> entries(comp);
    files = std::filesystem::directory_iterator(minidump_path);
    for(auto&& f : files) {
        if (f.is_regular_file() && minidump_file_extension == f.path().filename().extension())
            entries.emplace(f);
    }
    size = entries.size();
    std::find_if(entries.begin(), entries.end(), [&size](auto&& f) {
        if (max_minidump_file_num >= size)
            return true;
        std::error_code ec;
        if (!std::filesystem::remove(f, ec) && ec) {
            NIO_LOGE << "remove file " << f.path().filename() << " fail, error_code " << ec.value();
            return true;
        }
        size--;
        return false;
    });
    return succeeded;
}
#endif
#endif
}
}
