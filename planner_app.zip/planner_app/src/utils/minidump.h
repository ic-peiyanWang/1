#pragma once
#include <stdint.h>
#include <memory>
#include <string>
#define USE_DCS_SDK 1
#if !USE_DCS_SDK
#include "client/linux/handler/exception_handler.h"
#endif

namespace nio {
namespace pnc {
class Minidump {
public:
    Minidump() = default;
    int32_t init(const std::string&, const std::string&);
private:
#ifndef __x86_64__
#if !USE_DCS_SDK
    std::unique_ptr<google_breakpad::ExceptionHandler> m_handler{};
#endif
#endif
};
}
}
