#include "cosine_helper.h"
#include <thread>
#include "logger.h"

namespace nio {
namespace pnc {
int32_t CosineHelper::initial(const std::string& dir, const std::string& pod, const std::string& node) {
    // dds_node = nio::ad::Node::CreateNode(node);
    // if (nullptr == dds_node) {
    //     NIO_LOGE << "CreateNode " << node << " fail";
    //     return -1;
    // }
    cosine_instance = nio::cosine::cosineService::getCosineServiceInstance();
    if (nullptr == cosine_instance) {
        NIO_LOGE << node << " getCosineServiceInstance fail!";
        return -1;
    }
    if (!cosine_instance->cosineInit(dir, pod, node)) {
        NIO_LOGE << node << " cosineInit fail!";
        return -1;
    }
    app = node;
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    cosine_instance->cosineStart();
    NIO_LOGI << node << " init succeeds.";
    return 0;
}
int32_t CosineHelper::stop() {
    std::call_once(stop_flag, [this]() {
        NIO_LOGI << app << " try to stop cosine";
        cosine_instance->cosineStop();
        NIO_LOGI << app << " cosine stopped";

        NIO_LOGI << app << " try to destroy cosine";
        cosine_instance->cosineDestory();
        NIO_LOGI << app << " cosine destroyed";

        nio::cosine::cosineService::releaseCosineServiceInstance();
        promise.set_value();
    });
    return 0;
}
void CosineHelper::wait() { promise.get_future().wait(); }
}
}
