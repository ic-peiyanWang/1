#include <stdint.h>
#include <string>
#include <signal.h>
#include "minidump.h"
#include "signal_handler.h"
#include "cosine_helper.h"
#include "logger.h"

#include "niodds/common/niodds.h"

namespace {
    nio::pnc::Minidump minidump{};
    nio::pnc::SignalHandler signal_handler{};
    nio::pnc::CosineHelper cosine{};
}
int32_t main(const int32_t argc, const char* const argv[]) {
    std::string runCmd{argv[0]}, runDir{nio::ad::niodds::GetRootPath()}, podType{"pnc"};
    if (argc >= 3) {
        runDir  = argv[1];
        podType = argv[2];
    }
    auto&& index = runCmd.rfind("/");
    auto&& binary = std::string::npos != index ? runCmd.substr(index + 1) : runCmd;
    NIO_LOGI << "app run cmd:" << runCmd << ", paras:" << runDir << ", " << podType << ", main node name:" << binary;
    minidump.init(runDir + "/minidump", binary);
    cosine.initial(runDir, podType, binary);
    signal_handler.add(SIGINT, [](){ cosine.stop(); });
    signal_handler.add(SIGTERM, [](){ cosine.stop(); });
    cosine.wait();
    NIO_LOGI << binary << " exit.";
    return 0;
}
