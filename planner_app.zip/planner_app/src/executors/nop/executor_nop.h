#pragma once
#include "executor/executor_base.hpp"
#include "planner/pnc_exec.h"

namespace nio {
namespace pnc {
using namespace nio::cosine;
class ExecutorNoP : public ExecutorBaseV2 {
public:
    ExecutorNoP();
    int32_t init_v2(const std::vector<std::string>&) override;
    int32_t doProcess_v2(const InputDataType&, OutputDataType&) override;
    static ExecutorBase* createExecutorInstance();
    static void destroyExecutorInstance(ExecutorBase*);
    std::shared_ptr<nio::planner::PncHandler> pnc_handler_{};
};
}
}
