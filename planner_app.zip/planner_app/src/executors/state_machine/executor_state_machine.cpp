#include "executor_state_machine.h"
#include <algorithm>
#include <reflex/reflex>
#include "niodds/common/time.h"

namespace nio {
namespace pnc {
REGISTER_CLASS_FUNCTIONS(ExecutorStateMachine, (createExecutorInstance)(destroyExecutorInstance))
cosine::ExecutorBase* ExecutorStateMachine::createExecutorInstance() {
    return dynamic_cast<cosine::ExecutorBase*>(new ExecutorStateMachine());
}
void ExecutorStateMachine::destroyExecutorInstance(ExecutorBase* e) {
    if (nullptr != e)
        delete reinterpret_cast<ExecutorStateMachine*>(e);
}
ExecutorStateMachine::ExecutorStateMachine() {}
int32_t ExecutorStateMachine::init_v2(const std::vector<std::string>& configs) {
    pnc_handler_ = nio::planner::PncHandler::make(nio::planner::PncHandler::HandlerType::NP);
    if (pnc_handler_)
        return pnc_handler_->init(configs);
    else
        return -1;
}
int32_t ExecutorStateMachine::doProcess_v2(const InputDataType& inputs, OutputDataType& outputs) {
    planner::PncInputDataType pnc_inputs{};
    std::for_each(inputs.begin(), inputs.end(), [&pnc_inputs](auto&& i) {
        pnc_inputs.try_emplace({i.first},
            planner::PncInputDataType::mapped_type{false, const_cast<void*>(i.second.data), i.second.data_type});
    });
    planner::PncOutputDataType pnc_outputs{};
    std::for_each(outputs.begin(), outputs.end(), [&pnc_outputs](auto&& o) {
        pnc_outputs.try_emplace({o.first},
            planner::PncOutputDataType::mapped_type{false, o.second.data, o.second.data_type});
    });
    auto ret = pnc_handler_->doProcess(pnc_inputs, pnc_outputs);
    std::for_each(pnc_outputs.begin(), pnc_outputs.end(), [&outputs](auto&& o) {
        if (!o.second.valid)
            outputs.erase(o.first);
        else
            outputs[o.first].timestamp = nio::ad::Time::Ptp();   

    });
    return 0; 
}
}
}
