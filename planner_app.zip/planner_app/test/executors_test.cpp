#include <gtest/gtest.h>
#include <memory>
#include <string>

#include "executor/executor_base.hpp"
#include "dynamic_road_map/executor_dynamic_road_map.h"
#include "nop/executor_nop.h"
#include "state_machine/executor_state_machine.h"
#include "static_map/executor_static_map.h"

using namespace nio::pnc;
using namespace nio::cosine;

TEST(ExecutorsTest, dynamic_road_map_executor) {
    ExecutorDynamicRoadMap dynamic_map_exec;
    ExecutorBaseV2::InputDataType input; 
    ExecutorBaseV2::OutputDataType output;
    std::vector<std::string> configs;
    dynamic_map_exec.init_v2(configs);
    dynamic_map_exec.doProcess_v2(input, output);
}

TEST(ExecutorsTest, nop_executor) {
    ExecutorNoP nop_exec;
    ExecutorBaseV2::InputDataType input; 
    ExecutorBaseV2::OutputDataType output;
    std::vector<std::string> configs;
    nop_exec.init_v2(configs);
    nop_exec.doProcess_v2(input, output);
}

TEST(ExecutorsTest, state_machine_executor) {
    ExecutorStateMachine np_exec;
    ExecutorBaseV2::InputDataType input; 
    ExecutorBaseV2::OutputDataType output;
    std::vector<std::string> configs;
    np_exec.init_v2(configs);
    np_exec.doProcess_v2(input, output);
}

TEST(ExecutorsTest, static_map_executor) {
    ExecutorStaticMap static_map_exec;
    ExecutorBaseV2::InputDataType input; 
    ExecutorBaseV2::OutputDataType output;
    std::vector<std::string> configs;
    static_map_exec.init_v2(configs);
    static_map_exec.doProcess_v2(input, output);
}

int main(int argc, char* argv[]) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
